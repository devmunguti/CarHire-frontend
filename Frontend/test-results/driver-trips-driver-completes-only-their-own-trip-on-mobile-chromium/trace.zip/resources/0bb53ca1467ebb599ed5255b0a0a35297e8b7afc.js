import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/drivers/MyTripsPage.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport9_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=8b23c0c4";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=8b23c0c4";
import { LogOut, MessageCircle, Phone } from "/node_modules/.vite/deps/lucide-react.js?v=8b23c0c4";
import { ApiError } from "/src/api/client.ts";
import { useMyDriverTrips, useUpdateDriverTripStatus } from "/src/api/queries.ts";
import { Button, ConfirmDialog, EmptyState, ErrorState, Skeleton } from "/src/components/ui/index.ts";
import { useAuth } from "/src/hooks/AuthContext.tsx";
import { formatEat, formatKenyanPhone } from "/src/lib/index.ts";
import { SOSButton } from "/src/features/incidents/SOSButton.tsx";
var _jsxFileName = "C:/CarHire/Frontend/src/features/drivers/MyTripsPage.tsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b23c0c4";
var _s = $RefreshSig$();
const tripTransitions = [
	{
		status: "en_route_to_pickup",
		label: "En Route to Pickup"
	},
	{
		status: "customer_onboard",
		label: "Customer Onboard",
		previous: "en_route_to_pickup"
	},
	{
		status: "trip_completed",
		label: "Trip Completed",
		previous: "customer_onboard"
	}
];
function currentTripStatus(booking) {
	return booking.driverTripStatus?.replaceAll("_", " ") ?? "Assigned";
}
export function MyTripsPage() {
	_s();
	const navigate = useNavigate();
	const { user, logout } = useAuth();
	const tripsQuery = useMyDriverTrips();
	const updateStatus = useUpdateDriverTripStatus();
	const [pendingTransition, setPendingTransition] = useState(null);
	const [actionError, setActionError] = useState(null);
	async function confirmTransition() {
		if (!pendingTransition) return;
		setActionError(null);
		try {
			await updateStatus.mutateAsync({
				bookingId: pendingTransition.booking.id,
				status: pendingTransition.status
			});
			setPendingTransition(null);
		} catch (error) {
			setActionError(error instanceof ApiError && error.status === 403 ? "This trip is no longer assigned to your account." : "Trip status could not be updated. Try again.");
			setPendingTransition(null);
		}
	}
	async function signOut() {
		await logout().catch(() => undefined);
		navigate("/login", { replace: true });
	}
	if (tripsQuery.isLoading) return /* @__PURE__ */ _jsxDEV("main", {
		className: "driver-app",
		children: /* @__PURE__ */ _jsxDEV(Skeleton, { rows: 4 }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 47,
			columnNumber: 65
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 47,
		columnNumber: 36
	}, this);
	if (tripsQuery.isError) return /* @__PURE__ */ _jsxDEV("main", {
		className: "driver-app",
		children: /* @__PURE__ */ _jsxDEV(ErrorState, {
			onRetry: () => void tripsQuery.refetch(),
			retryLabel: "Retry",
			title: "Trips could not be loaded"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 48,
			columnNumber: 63
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 48,
		columnNumber: 34
	}, this);
	const trips = (tripsQuery.data ?? []).filter((booking) => booking.driver?.id === user?.id);
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "driver-app",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "driver-app-header",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("p", { children: "AutoHire KE" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 14
					}, this),
					/* @__PURE__ */ _jsxDEV("h1", { children: "My trips" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 32
					}, this),
					/* @__PURE__ */ _jsxDEV("span", { children: user?.name }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 49
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 54,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV(Button, {
					"aria-label": "Sign out",
					onClick: () => void signOut(),
					variant: "ghost",
					children: /* @__PURE__ */ _jsxDEV(LogOut, {
						"aria-hidden": "true",
						size: 18
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 86
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 55,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 7
			}, this),
			actionError && /* @__PURE__ */ _jsxDEV("p", {
				className: "driver-trip-error",
				role: "alert",
				children: actionError
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 57,
				columnNumber: 23
			}, this),
			trips.length === 0 ? /* @__PURE__ */ _jsxDEV(EmptyState, {
				description: "Assigned trips will appear here.",
				title: "No trips assigned"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 29
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: "driver-trip-list",
				children: trips.map((booking) => {
					const currentIndex = tripTransitions.findIndex((transition) => transition.status === booking.driverTripStatus);
					const nextTransition = tripTransitions[currentIndex + 1] ?? (currentIndex === -1 ? tripTransitions[0] : undefined);
					const nextButton = nextTransition && (nextTransition.previous === undefined ? !booking.driverTripStatus : booking.driverTripStatus === nextTransition.previous) ? nextTransition : undefined;
					const phone = booking.customerPhone ?? "";
					const handoverPath = booking.status === "confirmed" ? `/admin/bookings/${booking.id}/check-out` : `/admin/bookings/${booking.id}/check-in`;
					return /* @__PURE__ */ _jsxDEV("article", {
						className: "driver-trip-card",
						children: [
							/* @__PURE__ */ _jsxDEV("header", { children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "driver-trip-card__reference",
								children: booking.reference
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 72,
								columnNumber: 26
							}, this), /* @__PURE__ */ _jsxDEV("strong", { children: formatEat(booking.pickupAt) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 72,
								columnNumber: 98
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 72,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "driver-trip-card__status",
								children: currentTripStatus(booking)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 72,
								columnNumber: 150
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 72,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "driver-trip-card__vehicle",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "Vehicle plate" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 73,
									columnNumber: 56
								}, this), /* @__PURE__ */ _jsxDEV("strong", { children: booking.vehicleRegistration ?? booking.vehicleId }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 73,
									columnNumber: 82
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 73,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "driver-trip-card__contact",
								children: phone && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("a", {
									"aria-label": `Call ${formatKenyanPhone(phone)}`,
									href: `tel:${phone}`,
									children: [/* @__PURE__ */ _jsxDEV(Phone, {
										"aria-hidden": "true",
										size: 17
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 76,
										columnNumber: 90
									}, this), "Call customer"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 76,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("a", {
									"aria-label": `WhatsApp ${formatKenyanPhone(phone)}`,
									href: `https://wa.me/${phone.replace(/\D/g, "")}`,
									rel: "noreferrer",
									target: "_blank",
									children: [/* @__PURE__ */ _jsxDEV(MessageCircle, {
										"aria-hidden": "true",
										size: 17
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 77,
										columnNumber: 156
									}, this), "WhatsApp"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 77,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 75,
									columnNumber: 25
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 74,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV(Link, {
								className: "driver-trip-handover",
								to: handoverPath,
								children: "Open handover inspection"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 80,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								"aria-label": `Status actions for ${booking.reference}`,
								className: "driver-trip-actions",
								children: [/* @__PURE__ */ _jsxDEV(SOSButton, {
									source: "driver",
									vehicleId: booking.vehicleId
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 82,
									columnNumber: 15
								}, this), tripTransitions.map((transition) => /* @__PURE__ */ _jsxDEV(Button, {
									disabled: transition !== nextButton || updateStatus.isPending || booking.driverTripStatus === "trip_completed",
									onClick: () => setPendingTransition({
										booking,
										status: transition.status,
										label: transition.label
									}),
									size: "sm",
									variant: transition === nextButton ? "primary" : "secondary",
									children: transition.label
								}, transition.status, false, {
									fileName: _jsxFileName,
									lineNumber: 83,
									columnNumber: 52
								}, this))]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 81,
								columnNumber: 13
							}, this)
						]
					}, booking.id, true, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 18
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 119
			}, this),
			/* @__PURE__ */ _jsxDEV(ConfirmDialog, {
				cancelLabel: "Cancel",
				confirmLabel: "Confirm status",
				description: pendingTransition ? `Update ${pendingTransition.booking.reference} to ${pendingTransition.label}?` : "Confirm this trip status update.",
				onCancel: () => setPendingTransition(null),
				onConfirm: () => void confirmTransition(),
				open: Boolean(pendingTransition),
				title: "Confirm trip update"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 94,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 52,
		columnNumber: 5
	}, this);
}
_s(MyTripsPage, "Qrv8oReR9J+v1PymMVR2jn/sJqQ=", false, function() {
	return [
		useNavigate,
		useAuth,
		useMyDriverTrips,
		useUpdateDriverTripStatus
	];
});
_c = MyTripsPage;
var _c;
$RefreshReg$(_c, "MyTripsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/drivers/MyTripsPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/CarHire/Frontend/src/features/drivers/MyTripsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/CarHire/Frontend/src/features/drivers/MyTripsPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/CarHire/Frontend/src/features/drivers/MyTripsPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxNQUFNLG1CQUFtQjtBQUNsQyxTQUFTLFFBQVEsZUFBZSxhQUFhO0FBQzdDLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsa0JBQWtCLGlDQUFpQztBQUU1RCxTQUFTLFFBQVEsZUFBZSxZQUFZLFlBQVksZ0JBQWdCO0FBQ3hFLFNBQVMsZUFBZTtBQUN4QixTQUFTLFdBQVcseUJBQXlCO0FBQzdDLFNBQVMsaUJBQWlCOzs7O0FBRTFCLE1BQU0sa0JBQThGO0NBQ2xHO0VBQUUsUUFBUTtFQUFzQixPQUFPO0NBQXFCO0NBQzVEO0VBQUUsUUFBUTtFQUFvQixPQUFPO0VBQW9CLFVBQVU7Q0FBcUI7Q0FDeEY7RUFBRSxRQUFRO0VBQWtCLE9BQU87RUFBa0IsVUFBVTtDQUFtQjtBQUNwRjtBQUVBLFNBQVMsa0JBQWtCLFNBQWtCO0NBQzNDLE9BQU8sUUFBUSxrQkFBa0IsV0FBVyxLQUFLLEdBQUcsS0FBSztBQUMzRDtBQUVBLE9BQU8sU0FBUyxjQUFjOztDQUM1QixNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLEVBQUUsTUFBTSxXQUFXLFFBQVE7Q0FDakMsTUFBTSxhQUFhLGlCQUFpQjtDQUNwQyxNQUFNLGVBQWUsMEJBQTBCO0NBQy9DLE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQStFLElBQUk7Q0FDckksTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQXdCLElBQUk7Q0FFbEUsZUFBZSxvQkFBb0I7RUFDakMsSUFBSSxDQUFDLG1CQUFtQjtFQUN4QixlQUFlLElBQUk7RUFDbkIsSUFBSTtHQUNGLE1BQU0sYUFBYSxZQUFZO0lBQUUsV0FBVyxrQkFBa0IsUUFBUTtJQUFJLFFBQVEsa0JBQWtCO0dBQU8sQ0FBQztHQUM1RyxxQkFBcUIsSUFBSTtFQUMzQixTQUFTLE9BQU87R0FDZCxlQUFlLGlCQUFpQixZQUFZLE1BQU0sV0FBVyxNQUFNLHFEQUFxRCw4Q0FBOEM7R0FDdEsscUJBQXFCLElBQUk7RUFDM0I7Q0FDRjtDQUVBLGVBQWUsVUFBVTtFQUN2QixNQUFNLE9BQU8sQ0FBQyxDQUFDLFlBQVksU0FBUztFQUNwQyxTQUFTLFVBQVUsRUFBRSxTQUFTLEtBQUssQ0FBQztDQUN0QztDQUVBLElBQUksV0FBVyxXQUFXLE9BQU8sd0JBQUMsUUFBRDtFQUFNLFdBQVU7WUFBYSx3QkFBQyxVQUFELEVBQVUsTUFBTSxFQUFJOzs7OztDQUFPOzs7OztDQUN6RixJQUFJLFdBQVcsU0FBUyxPQUFPLHdCQUFDLFFBQUQ7RUFBTSxXQUFVO1lBQWEsd0JBQUMsWUFBRDtHQUFZLGVBQWUsS0FBSyxXQUFXLFFBQVE7R0FBRyxZQUFXO0dBQVEsT0FBTTtFQUE2Qjs7Ozs7Q0FBTzs7Ozs7Q0FFL0ssTUFBTSxTQUFTLFdBQVcsUUFBUSxDQUFDLEVBQUMsQ0FBRSxRQUFRLFlBQVksUUFBUSxRQUFRLE9BQU8sTUFBTSxFQUFFO0NBQ3pGLE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFdBQVU7WUFBaEI7R0FDRSx3QkFBQyxVQUFEO0lBQVEsV0FBVTtjQUFsQixDQUNFLHdCQUFDLE9BQUQ7S0FBSyx3QkFBQyxLQUFELFlBQUcsY0FBYzs7Ozs7S0FBQyx3QkFBQyxNQUFELFlBQUksV0FBWTs7Ozs7S0FBQyx3QkFBQyxRQUFELFlBQU8sTUFBTSxLQUFXOzs7OztJQUFNOzs7O2NBQ3RFLHdCQUFDLFFBQUQ7S0FBUSxjQUFXO0tBQVcsZUFBZSxLQUFLLFFBQVE7S0FBRyxTQUFRO2VBQVEsd0JBQUMsUUFBRDtNQUFRLGVBQVk7TUFBTyxNQUFNO0tBQUs7Ozs7O0lBQVM7Ozs7WUFDdEg7Ozs7OztHQUNQLGVBQWUsd0JBQUMsS0FBRDtJQUFHLFdBQVU7SUFBb0IsTUFBSztjQUFTO0dBQWU7Ozs7O0dBQzdFLE1BQU0sV0FBVyxJQUFJLHdCQUFDLFlBQUQ7SUFBWSxhQUFZO0lBQW1DLE9BQU07R0FBcUI7Ozs7Y0FBSSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUM1SCxNQUFNLEtBQUssWUFBWTtLQUN0QixNQUFNLGVBQWUsZ0JBQWdCLFdBQVcsZUFBZSxXQUFXLFdBQVcsUUFBUSxnQkFBZ0I7S0FDN0csTUFBTSxpQkFBaUIsZ0JBQWdCLGVBQWUsT0FBTyxpQkFBaUIsQ0FBQyxJQUFJLGdCQUFnQixLQUFLO0tBQ3hHLE1BQU0sYUFBYSxtQkFBbUIsZUFBZSxhQUFhLFlBQzlELENBQUMsUUFBUSxtQkFDVCxRQUFRLHFCQUFxQixlQUFlLFlBQzVDLGlCQUNBO0tBQ0osTUFBTSxRQUFRLFFBQVEsaUJBQWlCO0tBQ3ZDLE1BQU0sZUFBZSxRQUFRLFdBQVcsY0FDcEMsbUJBQW1CLFFBQVEsR0FBRyxjQUM5QixtQkFBbUIsUUFBUSxHQUFHO0tBQ2xDLE9BQU8sd0JBQUMsV0FBRDtNQUFTLFdBQVU7Z0JBQW5CO09BQ0wsd0JBQUMsVUFBRCxhQUFRLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBK0IsUUFBUTtPQUFnQjs7OztpQkFBQyx3QkFBQyxVQUFELFlBQVMsVUFBVSxRQUFRLFFBQVEsRUFBVTs7OztlQUFNOzs7O2lCQUFDLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUE0QixrQkFBa0IsT0FBTztPQUFROzs7O2VBQVM7Ozs7O09BQy9OLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQTJDLHdCQUFDLFFBQUQsWUFBTSxnQkFBbUI7Ozs7a0JBQUMsd0JBQUMsVUFBRCxZQUFTLFFBQVEsdUJBQXVCLFFBQVEsVUFBa0I7Ozs7Z0JBQU07Ozs7OztPQUM3SSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWixTQUFTLGdEQUNSLHdCQUFDLEtBQUQ7U0FBRyxjQUFZLFFBQVEsa0JBQWtCLEtBQUs7U0FBSyxNQUFNLE9BQU87bUJBQWhFLENBQXlFLHdCQUFDLE9BQUQ7VUFBTyxlQUFZO1VBQU8sTUFBTTtTQUFLOzs7O21CQUFDLGVBQWdCOzs7OztrQkFDL0gsd0JBQUMsS0FBRDtTQUFHLGNBQVksWUFBWSxrQkFBa0IsS0FBSztTQUFLLE1BQU0saUJBQWlCLE1BQU0sUUFBUSxPQUFPLEVBQUU7U0FBSyxLQUFJO1NBQWEsUUFBTzttQkFBbEksQ0FBMkksd0JBQUMsZUFBRDtVQUFlLGVBQVk7VUFBTyxNQUFNO1NBQUs7Ozs7bUJBQUMsVUFBVzs7Ozs7Z0JBQ3BNOzs7OztPQUNDOzs7OztPQUNMLHdCQUFDLE1BQUQ7UUFBTSxXQUFVO1FBQXVCLElBQUk7a0JBQWM7T0FBOEI7Ozs7O09BQ3ZGLHdCQUFDLE9BQUQ7UUFBSyxjQUFZLHNCQUFzQixRQUFRO1FBQWEsV0FBVTtrQkFBdEUsQ0FDRSx3QkFBQyxXQUFEO1NBQVcsUUFBTztTQUFTLFdBQVcsUUFBUTtRQUFZOzs7O2tCQUN6RCxnQkFBZ0IsS0FBSyxlQUFlLHdCQUFDLFFBQUQ7U0FDbkMsVUFBVSxlQUFlLGNBQWMsYUFBYSxhQUFhLFFBQVEscUJBQXFCO1NBRTlGLGVBQWUscUJBQXFCO1VBQUU7VUFBUyxRQUFRLFdBQVc7VUFBUSxPQUFPLFdBQVc7U0FBTSxDQUFDO1NBQ25HLE1BQUs7U0FDTCxTQUFTLGVBQWUsYUFBYSxZQUFZO21CQUNqRCxXQUFXO1FBQWMsR0FKcEIsV0FBVzs7OztlQUlTLENBQUMsQ0FDekI7Ozs7OztNQUNFO1FBcEJ5QyxRQUFROzs7O1lBb0JqRDtJQUNYLENBQUM7R0FDRTs7Ozs7R0FDTCx3QkFBQyxlQUFEO0lBQ0UsYUFBWTtJQUNaLGNBQWE7SUFDYixhQUFhLG9CQUFvQixVQUFVLGtCQUFrQixRQUFRLFVBQVUsTUFBTSxrQkFBa0IsTUFBTSxLQUFLO0lBQ2xILGdCQUFnQixxQkFBcUIsSUFBSTtJQUN6QyxpQkFBaUIsS0FBSyxrQkFBa0I7SUFDeEMsTUFBTSxRQUFRLGlCQUFpQjtJQUMvQixPQUFNO0dBQ1A7Ozs7O0VBQ0c7Ozs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk15VHJpcHNQYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBMaW5rLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXHJcbmltcG9ydCB7IExvZ091dCwgTWVzc2FnZUNpcmNsZSwgUGhvbmUgfSBmcm9tICdsdWNpZGUtcmVhY3QnXHJcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSAnLi4vLi4vYXBpL2NsaWVudCdcclxuaW1wb3J0IHsgdXNlTXlEcml2ZXJUcmlwcywgdXNlVXBkYXRlRHJpdmVyVHJpcFN0YXR1cyB9IGZyb20gJy4uLy4uL2FwaS9xdWVyaWVzJ1xyXG5pbXBvcnQgdHlwZSB7IEJvb2tpbmcsIERyaXZlclRyaXBTdGF0dXMgfSBmcm9tICcuLi8uLi9hcGkvdHlwZXMnXHJcbmltcG9ydCB7IEJ1dHRvbiwgQ29uZmlybURpYWxvZywgRW1wdHlTdGF0ZSwgRXJyb3JTdGF0ZSwgU2tlbGV0b24gfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL3VpJ1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vaG9va3MvQXV0aENvbnRleHQnXHJcbmltcG9ydCB7IGZvcm1hdEVhdCwgZm9ybWF0S2VueWFuUGhvbmUgfSBmcm9tICcuLi8uLi9saWInXHJcbmltcG9ydCB7IFNPU0J1dHRvbiB9IGZyb20gJy4uL2luY2lkZW50cy9TT1NCdXR0b24nXHJcblxyXG5jb25zdCB0cmlwVHJhbnNpdGlvbnM6IHsgc3RhdHVzOiBEcml2ZXJUcmlwU3RhdHVzOyBsYWJlbDogc3RyaW5nOyBwcmV2aW91cz86IERyaXZlclRyaXBTdGF0dXMgfVtdID0gW1xyXG4gIHsgc3RhdHVzOiAnZW5fcm91dGVfdG9fcGlja3VwJywgbGFiZWw6ICdFbiBSb3V0ZSB0byBQaWNrdXAnIH0sXHJcbiAgeyBzdGF0dXM6ICdjdXN0b21lcl9vbmJvYXJkJywgbGFiZWw6ICdDdXN0b21lciBPbmJvYXJkJywgcHJldmlvdXM6ICdlbl9yb3V0ZV90b19waWNrdXAnIH0sXHJcbiAgeyBzdGF0dXM6ICd0cmlwX2NvbXBsZXRlZCcsIGxhYmVsOiAnVHJpcCBDb21wbGV0ZWQnLCBwcmV2aW91czogJ2N1c3RvbWVyX29uYm9hcmQnIH0sXHJcbl1cclxuXHJcbmZ1bmN0aW9uIGN1cnJlbnRUcmlwU3RhdHVzKGJvb2tpbmc6IEJvb2tpbmcpIHtcclxuICByZXR1cm4gYm9va2luZy5kcml2ZXJUcmlwU3RhdHVzPy5yZXBsYWNlQWxsKCdfJywgJyAnKSA/PyAnQXNzaWduZWQnXHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBNeVRyaXBzUGFnZSgpIHtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcclxuICBjb25zdCB7IHVzZXIsIGxvZ291dCB9ID0gdXNlQXV0aCgpXHJcbiAgY29uc3QgdHJpcHNRdWVyeSA9IHVzZU15RHJpdmVyVHJpcHMoKVxyXG4gIGNvbnN0IHVwZGF0ZVN0YXR1cyA9IHVzZVVwZGF0ZURyaXZlclRyaXBTdGF0dXMoKVxyXG4gIGNvbnN0IFtwZW5kaW5nVHJhbnNpdGlvbiwgc2V0UGVuZGluZ1RyYW5zaXRpb25dID0gdXNlU3RhdGU8eyBib29raW5nOiBCb29raW5nOyBzdGF0dXM6IERyaXZlclRyaXBTdGF0dXM7IGxhYmVsOiBzdHJpbmcgfSB8IG51bGw+KG51bGwpXHJcbiAgY29uc3QgW2FjdGlvbkVycm9yLCBzZXRBY3Rpb25FcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKVxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBjb25maXJtVHJhbnNpdGlvbigpIHtcclxuICAgIGlmICghcGVuZGluZ1RyYW5zaXRpb24pIHJldHVyblxyXG4gICAgc2V0QWN0aW9uRXJyb3IobnVsbClcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IHVwZGF0ZVN0YXR1cy5tdXRhdGVBc3luYyh7IGJvb2tpbmdJZDogcGVuZGluZ1RyYW5zaXRpb24uYm9va2luZy5pZCwgc3RhdHVzOiBwZW5kaW5nVHJhbnNpdGlvbi5zdGF0dXMgfSlcclxuICAgICAgc2V0UGVuZGluZ1RyYW5zaXRpb24obnVsbClcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHNldEFjdGlvbkVycm9yKGVycm9yIGluc3RhbmNlb2YgQXBpRXJyb3IgJiYgZXJyb3Iuc3RhdHVzID09PSA0MDMgPyAnVGhpcyB0cmlwIGlzIG5vIGxvbmdlciBhc3NpZ25lZCB0byB5b3VyIGFjY291bnQuJyA6ICdUcmlwIHN0YXR1cyBjb3VsZCBub3QgYmUgdXBkYXRlZC4gVHJ5IGFnYWluLicpXHJcbiAgICAgIHNldFBlbmRpbmdUcmFuc2l0aW9uKG51bGwpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBzaWduT3V0KCkge1xyXG4gICAgYXdhaXQgbG9nb3V0KCkuY2F0Y2goKCkgPT4gdW5kZWZpbmVkKVxyXG4gICAgbmF2aWdhdGUoJy9sb2dpbicsIHsgcmVwbGFjZTogdHJ1ZSB9KVxyXG4gIH1cclxuXHJcbiAgaWYgKHRyaXBzUXVlcnkuaXNMb2FkaW5nKSByZXR1cm4gPG1haW4gY2xhc3NOYW1lPVwiZHJpdmVyLWFwcFwiPjxTa2VsZXRvbiByb3dzPXs0fSAvPjwvbWFpbj5cclxuICBpZiAodHJpcHNRdWVyeS5pc0Vycm9yKSByZXR1cm4gPG1haW4gY2xhc3NOYW1lPVwiZHJpdmVyLWFwcFwiPjxFcnJvclN0YXRlIG9uUmV0cnk9eygpID0+IHZvaWQgdHJpcHNRdWVyeS5yZWZldGNoKCl9IHJldHJ5TGFiZWw9XCJSZXRyeVwiIHRpdGxlPVwiVHJpcHMgY291bGQgbm90IGJlIGxvYWRlZFwiIC8+PC9tYWluPlxyXG5cclxuICBjb25zdCB0cmlwcyA9ICh0cmlwc1F1ZXJ5LmRhdGEgPz8gW10pLmZpbHRlcigoYm9va2luZykgPT4gYm9va2luZy5kcml2ZXI/LmlkID09PSB1c2VyPy5pZClcclxuICByZXR1cm4gKFxyXG4gICAgPG1haW4gY2xhc3NOYW1lPVwiZHJpdmVyLWFwcFwiPlxyXG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImRyaXZlci1hcHAtaGVhZGVyXCI+XHJcbiAgICAgICAgPGRpdj48cD5BdXRvSGlyZSBLRTwvcD48aDE+TXkgdHJpcHM8L2gxPjxzcGFuPnt1c2VyPy5uYW1lfTwvc3Bhbj48L2Rpdj5cclxuICAgICAgICA8QnV0dG9uIGFyaWEtbGFiZWw9XCJTaWduIG91dFwiIG9uQ2xpY2s9eygpID0+IHZvaWQgc2lnbk91dCgpfSB2YXJpYW50PVwiZ2hvc3RcIj48TG9nT3V0IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHNpemU9ezE4fSAvPjwvQnV0dG9uPlxyXG4gICAgICA8L2hlYWRlcj5cclxuICAgICAge2FjdGlvbkVycm9yICYmIDxwIGNsYXNzTmFtZT1cImRyaXZlci10cmlwLWVycm9yXCIgcm9sZT1cImFsZXJ0XCI+e2FjdGlvbkVycm9yfTwvcD59XHJcbiAgICAgIHt0cmlwcy5sZW5ndGggPT09IDAgPyA8RW1wdHlTdGF0ZSBkZXNjcmlwdGlvbj1cIkFzc2lnbmVkIHRyaXBzIHdpbGwgYXBwZWFyIGhlcmUuXCIgdGl0bGU9XCJObyB0cmlwcyBhc3NpZ25lZFwiIC8+IDogPGRpdiBjbGFzc05hbWU9XCJkcml2ZXItdHJpcC1saXN0XCI+XHJcbiAgICAgICAge3RyaXBzLm1hcCgoYm9va2luZykgPT4ge1xyXG4gICAgICAgICAgY29uc3QgY3VycmVudEluZGV4ID0gdHJpcFRyYW5zaXRpb25zLmZpbmRJbmRleCgodHJhbnNpdGlvbikgPT4gdHJhbnNpdGlvbi5zdGF0dXMgPT09IGJvb2tpbmcuZHJpdmVyVHJpcFN0YXR1cylcclxuICAgICAgICAgIGNvbnN0IG5leHRUcmFuc2l0aW9uID0gdHJpcFRyYW5zaXRpb25zW2N1cnJlbnRJbmRleCArIDFdID8/IChjdXJyZW50SW5kZXggPT09IC0xID8gdHJpcFRyYW5zaXRpb25zWzBdIDogdW5kZWZpbmVkKVxyXG4gICAgICAgICAgY29uc3QgbmV4dEJ1dHRvbiA9IG5leHRUcmFuc2l0aW9uICYmIChuZXh0VHJhbnNpdGlvbi5wcmV2aW91cyA9PT0gdW5kZWZpbmVkXHJcbiAgICAgICAgICAgID8gIWJvb2tpbmcuZHJpdmVyVHJpcFN0YXR1c1xyXG4gICAgICAgICAgICA6IGJvb2tpbmcuZHJpdmVyVHJpcFN0YXR1cyA9PT0gbmV4dFRyYW5zaXRpb24ucHJldmlvdXMpXHJcbiAgICAgICAgICAgID8gbmV4dFRyYW5zaXRpb25cclxuICAgICAgICAgICAgOiB1bmRlZmluZWRcclxuICAgICAgICAgIGNvbnN0IHBob25lID0gYm9va2luZy5jdXN0b21lclBob25lID8/ICcnXHJcbiAgICAgICAgICBjb25zdCBoYW5kb3ZlclBhdGggPSBib29raW5nLnN0YXR1cyA9PT0gJ2NvbmZpcm1lZCdcclxuICAgICAgICAgICAgPyBgL2FkbWluL2Jvb2tpbmdzLyR7Ym9va2luZy5pZH0vY2hlY2stb3V0YFxyXG4gICAgICAgICAgICA6IGAvYWRtaW4vYm9va2luZ3MvJHtib29raW5nLmlkfS9jaGVjay1pbmBcclxuICAgICAgICAgIHJldHVybiA8YXJ0aWNsZSBjbGFzc05hbWU9XCJkcml2ZXItdHJpcC1jYXJkXCIga2V5PXtib29raW5nLmlkfT5cclxuICAgICAgICAgICAgPGhlYWRlcj48ZGl2PjxzcGFuIGNsYXNzTmFtZT1cImRyaXZlci10cmlwLWNhcmRfX3JlZmVyZW5jZVwiPntib29raW5nLnJlZmVyZW5jZX08L3NwYW4+PHN0cm9uZz57Zm9ybWF0RWF0KGJvb2tpbmcucGlja3VwQXQpfTwvc3Ryb25nPjwvZGl2PjxzcGFuIGNsYXNzTmFtZT1cImRyaXZlci10cmlwLWNhcmRfX3N0YXR1c1wiPntjdXJyZW50VHJpcFN0YXR1cyhib29raW5nKX08L3NwYW4+PC9oZWFkZXI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZHJpdmVyLXRyaXAtY2FyZF9fdmVoaWNsZVwiPjxzcGFuPlZlaGljbGUgcGxhdGU8L3NwYW4+PHN0cm9uZz57Ym9va2luZy52ZWhpY2xlUmVnaXN0cmF0aW9uID8/IGJvb2tpbmcudmVoaWNsZUlkfTwvc3Ryb25nPjwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRyaXZlci10cmlwLWNhcmRfX2NvbnRhY3RcIj5cclxuICAgICAgICAgICAgICB7cGhvbmUgJiYgPD5cclxuICAgICAgICAgICAgICAgIDxhIGFyaWEtbGFiZWw9e2BDYWxsICR7Zm9ybWF0S2VueWFuUGhvbmUocGhvbmUpfWB9IGhyZWY9e2B0ZWw6JHtwaG9uZX1gfT48UGhvbmUgYXJpYS1oaWRkZW49XCJ0cnVlXCIgc2l6ZT17MTd9IC8+Q2FsbCBjdXN0b21lcjwvYT5cclxuICAgICAgICAgICAgICAgIDxhIGFyaWEtbGFiZWw9e2BXaGF0c0FwcCAke2Zvcm1hdEtlbnlhblBob25lKHBob25lKX1gfSBocmVmPXtgaHR0cHM6Ly93YS5tZS8ke3Bob25lLnJlcGxhY2UoL1xcRC9nLCAnJyl9YH0gcmVsPVwibm9yZWZlcnJlclwiIHRhcmdldD1cIl9ibGFua1wiPjxNZXNzYWdlQ2lyY2xlIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHNpemU9ezE3fSAvPldoYXRzQXBwPC9hPlxyXG4gICAgICAgICAgICAgIDwvPn1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxMaW5rIGNsYXNzTmFtZT1cImRyaXZlci10cmlwLWhhbmRvdmVyXCIgdG89e2hhbmRvdmVyUGF0aH0+T3BlbiBoYW5kb3ZlciBpbnNwZWN0aW9uPC9MaW5rPlxyXG4gICAgICAgICAgICA8ZGl2IGFyaWEtbGFiZWw9e2BTdGF0dXMgYWN0aW9ucyBmb3IgJHtib29raW5nLnJlZmVyZW5jZX1gfSBjbGFzc05hbWU9XCJkcml2ZXItdHJpcC1hY3Rpb25zXCI+XHJcbiAgICAgICAgICAgICAgPFNPU0J1dHRvbiBzb3VyY2U9XCJkcml2ZXJcIiB2ZWhpY2xlSWQ9e2Jvb2tpbmcudmVoaWNsZUlkfSAvPlxyXG4gICAgICAgICAgICAgIHt0cmlwVHJhbnNpdGlvbnMubWFwKCh0cmFuc2l0aW9uKSA9PiA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17dHJhbnNpdGlvbiAhPT0gbmV4dEJ1dHRvbiB8fCB1cGRhdGVTdGF0dXMuaXNQZW5kaW5nIHx8IGJvb2tpbmcuZHJpdmVyVHJpcFN0YXR1cyA9PT0gJ3RyaXBfY29tcGxldGVkJ31cclxuICAgICAgICAgICAgICAgIGtleT17dHJhbnNpdGlvbi5zdGF0dXN9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRQZW5kaW5nVHJhbnNpdGlvbih7IGJvb2tpbmcsIHN0YXR1czogdHJhbnNpdGlvbi5zdGF0dXMsIGxhYmVsOiB0cmFuc2l0aW9uLmxhYmVsIH0pfVxyXG4gICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcclxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9e3RyYW5zaXRpb24gPT09IG5leHRCdXR0b24gPyAncHJpbWFyeScgOiAnc2Vjb25kYXJ5J31cclxuICAgICAgICAgICAgICA+e3RyYW5zaXRpb24ubGFiZWx9PC9CdXR0b24+KX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2FydGljbGU+XHJcbiAgICAgICAgfSl9XHJcbiAgICAgIDwvZGl2Pn1cclxuICAgICAgPENvbmZpcm1EaWFsb2dcclxuICAgICAgICBjYW5jZWxMYWJlbD1cIkNhbmNlbFwiXHJcbiAgICAgICAgY29uZmlybUxhYmVsPVwiQ29uZmlybSBzdGF0dXNcIlxyXG4gICAgICAgIGRlc2NyaXB0aW9uPXtwZW5kaW5nVHJhbnNpdGlvbiA/IGBVcGRhdGUgJHtwZW5kaW5nVHJhbnNpdGlvbi5ib29raW5nLnJlZmVyZW5jZX0gdG8gJHtwZW5kaW5nVHJhbnNpdGlvbi5sYWJlbH0/YCA6ICdDb25maXJtIHRoaXMgdHJpcCBzdGF0dXMgdXBkYXRlLid9XHJcbiAgICAgICAgb25DYW5jZWw9eygpID0+IHNldFBlbmRpbmdUcmFuc2l0aW9uKG51bGwpfVxyXG4gICAgICAgIG9uQ29uZmlybT17KCkgPT4gdm9pZCBjb25maXJtVHJhbnNpdGlvbigpfVxyXG4gICAgICAgIG9wZW49e0Jvb2xlYW4ocGVuZGluZ1RyYW5zaXRpb24pfVxyXG4gICAgICAgIHRpdGxlPVwiQ29uZmlybSB0cmlwIHVwZGF0ZVwiXHJcbiAgICAgIC8+XHJcbiAgICA8L21haW4+XHJcbiAgKVxyXG59Il19
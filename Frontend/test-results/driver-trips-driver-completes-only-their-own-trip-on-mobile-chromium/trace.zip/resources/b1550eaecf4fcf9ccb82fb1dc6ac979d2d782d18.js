import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/incidents/SOSButton.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=8b23c0c4";
import { AlertTriangle, Camera, MapPin, Phone } from "/node_modules/.vite/deps/lucide-react.js?v=8b23c0c4";
import { useCreateIncident } from "/src/api/queries.ts";
import { Button, Input, Modal, Select } from "/src/components/ui/index.ts";
import { toGeoJson } from "/src/lib/geo.ts";
import { LazyGeoMap } from "/src/features/incidents/LazyGeoMap.tsx";
var _jsxFileName = "C:/CarHire/Frontend/src/features/incidents/SOSButton.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b23c0c4";
var _s = $RefreshSig$();
const nairobiFallback = toGeoJson([-1.2864, 36.8172]);
const incidentCategories = [
	{
		value: "flat_tyre",
		label: "Flat Tyre"
	},
	{
		value: "battery",
		label: "Battery"
	},
	{
		value: "overheating",
		label: "Overheating"
	},
	{
		value: "accident",
		label: "Accident"
	},
	{
		value: "strange_noise",
		label: "Strange Noise"
	}
];
function readPhoto(file) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.addEventListener("load", () => typeof reader.result === "string" ? resolve(reader.result) : reject(new Error("Photo could not be read")));
		reader.addEventListener("error", () => reject(new Error("Photo could not be read")));
		reader.readAsDataURL(file);
	});
}
export function SOSButton({ source, vehicleId, label = "SOS" }) {
	_s();
	const createIncident = useCreateIncident();
	const [open, setOpen] = useState(false);
	const [location, setLocation] = useState(null);
	const [gpsState, setGpsState] = useState("idle");
	const [locationText, setLocationText] = useState("");
	const [category, setCategory] = useState("flat_tyre");
	const [description, setDescription] = useState("");
	const [immobilising, setImmobilising] = useState(false);
	const [photos, setPhotos] = useState([]);
	const [manualPinMode, setManualPinMode] = useState(false);
	const [error, setError] = useState(null);
	function requestGps() {
		setGpsState("loading");
		if (!navigator.geolocation) {
			setGpsState("denied");
			return;
		}
		navigator.geolocation.getCurrentPosition((position) => {
			setLocation(toGeoJson([position.coords.latitude, position.coords.longitude]));
			setLocationText("GPS location");
			setGpsState("ready");
		}, () => {
			setGpsState("denied");
		}, {
			enableHighAccuracy: true,
			timeout: 1e4,
			maximumAge: 3e4
		});
	}
	function showForm() {
		setOpen(true);
		setError(null);
		setLocation(null);
		setLocationText("");
		setGpsState("idle");
		setManualPinMode(source === "desk");
		if (source !== "desk") requestGps();
	}
	function onPhotos(event) {
		setPhotos((current) => [...current, ...Array.from(event.currentTarget.files ?? [])]);
		event.currentTarget.value = "";
	}
	async function submit(event) {
		event.preventDefault();
		const submittedLocation = location ?? (locationText.trim() ? nairobiFallback : null);
		if (!submittedLocation) {
			setError("Set a GPS location, place a pin, or enter a road, landmark or town.");
			return;
		}
		setError(null);
		try {
			const photoData = await Promise.all(photos.map(readPhoto));
			await createIncident.mutateAsync({
				category,
				description: description.trim(),
				location: submittedLocation,
				locationText: locationText.trim() || (gpsState === "ready" ? "GPS location" : "Manually placed pin"),
				vehicleId,
				immobilising,
				photos: photoData,
				source
			});
			setOpen(false);
			setPhotos([]);
			setDescription("");
		} catch {
			setError("SOS could not be sent. Your details and photos are still here; try again.");
		}
	}
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Button, {
		className: "sos-trigger",
		onClick: showForm,
		variant: "danger",
		children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, {
			"aria-hidden": "true",
			size: 17
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 96,
			columnNumber: 73
		}, this), label]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 96,
		columnNumber: 5
	}, this), open && /* @__PURE__ */ _jsxDEV(Modal, {
		open: true,
		title: "Send SOS",
		onClose: () => setOpen(false),
		children: /* @__PURE__ */ _jsxDEV("form", {
			className: "sos-form",
			onSubmit: (event) => void submit(event),
			children: [
				/* @__PURE__ */ _jsxDEV(Select, {
					label: "Issue category",
					onChange: (event) => setCategory(event.target.value),
					options: incidentCategories,
					value: category
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 99,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("label", {
					className: "field",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "field__label",
						children: "Describe the issue"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 34
					}, this), /* @__PURE__ */ _jsxDEV("textarea", {
						className: "control sos-description",
						onChange: (event) => setDescription(event.target.value),
						value: description
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 90
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 100,
					columnNumber: 9
				}, this),
				gpsState === "loading" && /* @__PURE__ */ _jsxDEV("p", {
					role: "status",
					children: "Getting your GPS location…"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 101,
					columnNumber: 36
				}, this),
				gpsState === "ready" && /* @__PURE__ */ _jsxDEV("p", {
					className: "sos-location-status",
					role: "status",
					children: [/* @__PURE__ */ _jsxDEV(MapPin, {
						"aria-hidden": "true",
						size: 16
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 102,
						columnNumber: 83
					}, this), " GPS location captured"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 102,
					columnNumber: 34
				}, this),
				gpsState === "denied" && /* @__PURE__ */ _jsxDEV("div", {
					className: "sos-fallback",
					role: "alert",
					children: [/* @__PURE__ */ _jsxDEV("p", { children: "GPS location unavailable. Place a pin or enter a nearby road, landmark or town." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 103,
						columnNumber: 78
					}, this), /* @__PURE__ */ _jsxDEV("a", {
						href: "tel:+254700123456",
						children: [/* @__PURE__ */ _jsxDEV(Phone, {
							"aria-hidden": "true",
							size: 16
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 103,
							columnNumber: 192
						}, this), " Call the desk"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 103,
						columnNumber: 164
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 103,
					columnNumber: 35
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "sos-map-controls",
					children: /* @__PURE__ */ _jsxDEV(Button, {
						onClick: () => setManualPinMode(!manualPinMode),
						type: "button",
						variant: manualPinMode ? "primary" : "secondary",
						children: [/* @__PURE__ */ _jsxDEV(MapPin, {
							"aria-hidden": "true",
							size: 16
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 105,
							columnNumber: 132
						}, this), manualPinMode ? "Click map to place pin" : "Place pin manually"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 105,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 104,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(LazyGeoMap, {
					center: location ?? nairobiFallback,
					marker: location ? {
						point: location,
						label: locationText || "Incident location",
						tone: "danger"
					} : undefined,
					onPlace: (point) => {
						setLocation(point);
						setGpsState("denied");
					},
					placementEnabled: manualPinMode || gpsState === "denied",
					zoom: 13
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 107,
					columnNumber: 9
				}, this),
				(gpsState === "denied" || manualPinMode) && /* @__PURE__ */ _jsxDEV(Input, {
					label: "Location or landmark",
					onChange: (event) => setLocationText(event.target.value),
					placeholder: "Street, landmark or town",
					value: locationText
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 108,
					columnNumber: 54
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "field",
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "field__label",
							children: "Photos"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 109,
							columnNumber: 32
						}, this),
						/* @__PURE__ */ _jsxDEV("label", {
							className: "sos-photo-picker",
							children: [
								/* @__PURE__ */ _jsxDEV(Camera, {
									"aria-hidden": "true",
									size: 17
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 109,
									columnNumber: 112
								}, this),
								" Add photos",
								/* @__PURE__ */ _jsxDEV("input", {
									accept: "image/*",
									capture: "environment",
									multiple: true,
									onChange: onPhotos,
									type: "file"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 109,
									columnNumber: 162
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 109,
							columnNumber: 76
						}, this),
						photos.map((photo) => /* @__PURE__ */ _jsxDEV("small", { children: photo.name }, `${photo.name}-${photo.lastModified}`, false, {
							fileName: _jsxFileName,
							lineNumber: 109,
							columnNumber: 282
						}, this))
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 109,
					columnNumber: 9
				}, this),
				vehicleId && /* @__PURE__ */ _jsxDEV("label", {
					className: "choice",
					children: [/* @__PURE__ */ _jsxDEV("input", {
						checked: immobilising,
						onChange: (event) => setImmobilising(event.target.checked),
						type: "checkbox"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 49
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Vehicle cannot be driven" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 157
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 110,
					columnNumber: 23
				}, this),
				error && /* @__PURE__ */ _jsxDEV("p", {
					className: "field__error",
					role: "alert",
					children: error
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 111,
					columnNumber: 19
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "confirm-dialog__actions",
					children: [/* @__PURE__ */ _jsxDEV(Button, {
						onClick: () => setOpen(false),
						variant: "secondary",
						children: "Cancel"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 112,
						columnNumber: 50
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						disabled: createIncident.isPending || gpsState === "loading",
						type: "submit",
						variant: "danger",
						children: createIncident.isPending ? "Sending…" : "Send SOS"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 112,
						columnNumber: 124
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 112,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 98,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 97,
		columnNumber: 14
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 95,
		columnNumber: 10
	}, this);
}
_s(SOSButton, "7WxO8DyF/xOm85FBA+yGFMlB/gs=", false, function() {
	return [useCreateIncident];
});
_c = SOSButton;
var _c;
$RefreshReg$(_c, "SOSButton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/incidents/SOSButton.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/CarHire/Frontend/src/features/incidents/SOSButton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/CarHire/Frontend/src/features/incidents/SOSButton.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/CarHire/Frontend/src/features/incidents/SOSButton.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBa0Q7QUFDM0QsU0FBUyxlQUFlLFFBQVEsUUFBUSxhQUFhO0FBQ3JELFNBQVMseUJBQXlCO0FBRWxDLFNBQVMsUUFBUSxPQUFPLE9BQU8sY0FBYztBQUM3QyxTQUFTLGlCQUFvQztBQUM3QyxTQUFTLGtCQUFrQjs7OztBQUUzQixNQUFNLGtCQUFrQixVQUFVLENBQUMsQ0FBQyxRQUFRLE9BQU8sQ0FBQztBQUNwRCxNQUFNLHFCQUFtRTtDQUN2RTtFQUFFLE9BQU87RUFBYSxPQUFPO0NBQVk7Q0FDekM7RUFBRSxPQUFPO0VBQVcsT0FBTztDQUFVO0NBQ3JDO0VBQUUsT0FBTztFQUFlLE9BQU87Q0FBYztDQUM3QztFQUFFLE9BQU87RUFBWSxPQUFPO0NBQVc7Q0FDdkM7RUFBRSxPQUFPO0VBQWlCLE9BQU87Q0FBZ0I7QUFDbkQ7QUFFQSxTQUFTLFVBQVUsTUFBNkI7Q0FDOUMsT0FBTyxJQUFJLFNBQVMsU0FBUyxXQUFXO0VBQ3RDLE1BQU0sU0FBUyxJQUFJLFdBQVc7RUFDOUIsT0FBTyxpQkFBaUIsY0FBYyxPQUFPLE9BQU8sV0FBVyxXQUFXLFFBQVEsT0FBTyxNQUFNLElBQUksT0FBTyxJQUFJLE1BQU0seUJBQXlCLENBQUMsQ0FBQztFQUMvSSxPQUFPLGlCQUFpQixlQUFlLE9BQU8sSUFBSSxNQUFNLHlCQUF5QixDQUFDLENBQUM7RUFDbkYsT0FBTyxjQUFjLElBQUk7Q0FDM0IsQ0FBQztBQUNIO0FBRUEsT0FBTyxTQUFTLFVBQVUsRUFBRSxRQUFRLFdBQVcsUUFBUSxTQUEwRjs7Q0FDL0ksTUFBTSxpQkFBaUIsa0JBQWtCO0NBQ3pDLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxLQUFLO0NBQ3RDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBOEIsSUFBSTtDQUNsRSxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQWtELE1BQU07Q0FDeEYsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsRUFBRTtDQUNuRCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQTJCLFdBQVc7Q0FDdEUsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsRUFBRTtDQUNqRCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxLQUFLO0NBQ3RELE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBaUIsQ0FBQyxDQUFDO0NBQy9DLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLEtBQUs7Q0FDeEQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUF3QixJQUFJO0NBRXRELFNBQVMsYUFBYTtFQUNwQixZQUFZLFNBQVM7RUFDckIsSUFBSSxDQUFDLFVBQVUsYUFBYTtHQUMxQixZQUFZLFFBQVE7R0FDcEI7RUFDRjtFQUNBLFVBQVUsWUFBWSxvQkFBb0IsYUFBYTtHQUNyRCxZQUFZLFVBQVUsQ0FBQyxTQUFTLE9BQU8sVUFBVSxTQUFTLE9BQU8sU0FBUyxDQUFDLENBQUM7R0FDNUUsZ0JBQWdCLGNBQWM7R0FDOUIsWUFBWSxPQUFPO0VBQ3JCLFNBQVM7R0FDUCxZQUFZLFFBQVE7RUFDdEIsR0FBRztHQUFFLG9CQUFvQjtHQUFNLFNBQVM7R0FBUSxZQUFZO0VBQU8sQ0FBQztDQUN0RTtDQUVBLFNBQVMsV0FBVztFQUNsQixRQUFRLElBQUk7RUFDWixTQUFTLElBQUk7RUFDYixZQUFZLElBQUk7RUFDaEIsZ0JBQWdCLEVBQUU7RUFDbEIsWUFBWSxNQUFNO0VBQ2xCLGlCQUFpQixXQUFXLE1BQU07RUFDbEMsSUFBSSxXQUFXLFFBQVEsV0FBVztDQUNwQztDQUVBLFNBQVMsU0FBUyxPQUFzQztFQUN0RCxXQUFXLFlBQVksQ0FBQyxHQUFHLFNBQVMsR0FBRyxNQUFNLEtBQUssTUFBTSxjQUFjLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUNuRixNQUFNLGNBQWMsUUFBUTtDQUM5QjtDQUVBLGVBQWUsT0FBTyxPQUFtQztFQUN2RCxNQUFNLGVBQWU7RUFDckIsTUFBTSxvQkFBb0IsYUFBYSxhQUFhLEtBQUssSUFBSSxrQkFBa0I7RUFDL0UsSUFBSSxDQUFDLG1CQUFtQjtHQUFFLFNBQVMscUVBQXFFO0dBQUc7RUFBTztFQUNsSCxTQUFTLElBQUk7RUFDYixJQUFJO0dBQ0YsTUFBTSxZQUFZLE1BQU0sUUFBUSxJQUFJLE9BQU8sSUFBSSxTQUFTLENBQUM7R0FDekQsTUFBTSxlQUFlLFlBQVk7SUFDL0I7SUFDQSxhQUFhLFlBQVksS0FBSztJQUM5QixVQUFVO0lBQ1YsY0FBYyxhQUFhLEtBQUssTUFBTSxhQUFhLFVBQVUsaUJBQWlCO0lBQzlFO0lBQ0E7SUFDQSxRQUFRO0lBQ1I7R0FDRixDQUFDO0dBQ0QsUUFBUSxLQUFLO0dBQ2IsVUFBVSxDQUFDLENBQUM7R0FDWixlQUFlLEVBQUU7RUFDbkIsUUFBUTtHQUNOLFNBQVMsMkVBQTJFO0VBQ3RGO0NBQ0Y7Q0FFQSxPQUFPLGdEQUNMLHdCQUFDLFFBQUQ7RUFBUSxXQUFVO0VBQWMsU0FBUztFQUFVLFNBQVE7WUFBM0QsQ0FBb0Usd0JBQUMsZUFBRDtHQUFlLGVBQVk7R0FBTyxNQUFNO0VBQUs7Ozs7WUFBRSxLQUFjOzs7OztXQUNoSSxRQUFRLHdCQUFDLE9BQUQ7RUFBTztFQUFLLE9BQU07RUFBVyxlQUFlLFFBQVEsS0FBSztZQUNoRSx3QkFBQyxRQUFEO0dBQU0sV0FBVTtHQUFXLFdBQVcsVUFBVSxLQUFLLE9BQU8sS0FBSzthQUFqRTtJQUNFLHdCQUFDLFFBQUQ7S0FBUSxPQUFNO0tBQWlCLFdBQVcsVUFBVSxZQUFZLE1BQU0sT0FBTyxLQUF5QjtLQUFHLFNBQVM7S0FBb0IsT0FBTztJQUFXOzs7OztJQUN4Six3QkFBQyxTQUFEO0tBQU8sV0FBVTtlQUFqQixDQUF5Qix3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBZTtLQUF3Qjs7OztlQUFDLHdCQUFDLFlBQUQ7TUFBVSxXQUFVO01BQTBCLFdBQVcsVUFBVSxlQUFlLE1BQU0sT0FBTyxLQUFLO01BQUcsT0FBTztLQUFjOzs7O2FBQVE7Ozs7OztJQUNwTixhQUFhLGFBQWEsd0JBQUMsS0FBRDtLQUFHLE1BQUs7ZUFBUztJQUE2Qjs7Ozs7SUFDeEUsYUFBYSxXQUFXLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO0tBQXNCLE1BQUs7ZUFBeEMsQ0FBaUQsd0JBQUMsUUFBRDtNQUFRLGVBQVk7TUFBTyxNQUFNO0tBQUs7Ozs7ZUFBQyx3QkFBeUI7Ozs7OztJQUN6SSxhQUFhLFlBQVksd0JBQUMsT0FBRDtLQUFLLFdBQVU7S0FBZSxNQUFLO2VBQW5DLENBQTJDLHdCQUFDLEtBQUQsWUFBRyxrRkFBa0Y7Ozs7ZUFBQyx3QkFBQyxLQUFEO01BQUcsTUFBSztnQkFBUixDQUE0Qix3QkFBQyxPQUFEO09BQU8sZUFBWTtPQUFPLE1BQU07TUFBSzs7OztnQkFBQyxnQkFBaUI7Ozs7O2FBQU07Ozs7OztJQUNwUCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLFFBQUQ7TUFBUSxlQUFlLGlCQUFpQixDQUFDLGFBQWE7TUFBRyxNQUFLO01BQVMsU0FBUyxnQkFBZ0IsWUFBWTtnQkFBNUcsQ0FBeUgsd0JBQUMsUUFBRDtPQUFRLGVBQVk7T0FBTyxNQUFNO01BQUs7Ozs7Z0JBQUUsZ0JBQWdCLDJCQUEyQixvQkFBNkI7Ozs7OztJQUN0Tzs7Ozs7SUFDTCx3QkFBQyxZQUFEO0tBQVksUUFBUSxZQUFZO0tBQWlCLFFBQVEsV0FBVztNQUFFLE9BQU87TUFBVSxPQUFPLGdCQUFnQjtNQUFxQixNQUFNO0tBQVMsSUFBSTtLQUFXLFVBQVUsVUFBVTtNQUFFLFlBQVksS0FBSztNQUFHLFlBQVksUUFBUTtLQUFFO0tBQUcsa0JBQWtCLGlCQUFpQixhQUFhO0tBQVUsTUFBTTtJQUFLOzs7OztLQUN2UyxhQUFhLFlBQVksa0JBQWtCLHdCQUFDLE9BQUQ7S0FBTyxPQUFNO0tBQXVCLFdBQVcsVUFBVSxnQkFBZ0IsTUFBTSxPQUFPLEtBQUs7S0FBRyxhQUFZO0tBQTJCLE9BQU87SUFBZTs7Ozs7SUFDeE0sd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUF1Qix3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBZTtNQUFZOzs7OztNQUFDLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFqQjtRQUFvQyx3QkFBQyxRQUFEO1NBQVEsZUFBWTtTQUFPLE1BQU07UUFBSzs7Ozs7UUFBQztRQUFXLHdCQUFDLFNBQUQ7U0FBTyxRQUFPO1NBQVUsU0FBUTtTQUFjO1NBQVMsVUFBVTtTQUFVLE1BQUs7UUFBUTs7Ozs7T0FBUTs7Ozs7O01BQUUsT0FBTyxLQUFLLFVBQVUsd0JBQUMsU0FBRCxZQUFvRCxNQUFNLEtBQVksR0FBMUQsR0FBRyxNQUFNLEtBQUssR0FBRyxNQUFNOzs7O2FBQW1DLENBQUM7S0FBTzs7Ozs7O0lBQzlWLGFBQWEsd0JBQUMsU0FBRDtLQUFPLFdBQVU7ZUFBakIsQ0FBMEIsd0JBQUMsU0FBRDtNQUFPLFNBQVM7TUFBYyxXQUFXLFVBQVUsZ0JBQWdCLE1BQU0sT0FBTyxPQUFPO01BQUcsTUFBSztLQUFZOzs7O2VBQUMsd0JBQUMsUUFBRCxZQUFNLDJCQUE4Qjs7OzthQUFROzs7Ozs7SUFDL0wsU0FBUyx3QkFBQyxLQUFEO0tBQUcsV0FBVTtLQUFlLE1BQUs7ZUFBUztJQUFTOzs7OztJQUM3RCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQXlDLHdCQUFDLFFBQUQ7TUFBUSxlQUFlLFFBQVEsS0FBSztNQUFHLFNBQVE7Z0JBQVk7S0FBYzs7OztlQUFDLHdCQUFDLFFBQUQ7TUFBUSxVQUFVLGVBQWUsYUFBYSxhQUFhO01BQVcsTUFBSztNQUFTLFNBQVE7Z0JBQVUsZUFBZSxZQUFZLGFBQWE7S0FBbUI7Ozs7YUFBTTs7Ozs7O0dBQ3RSOzs7Ozs7Q0FDRDs7OztTQUNQOzs7OztBQUNKIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlNPU0J1dHRvbi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHR5cGUgQ2hhbmdlRXZlbnQsIHR5cGUgRm9ybUV2ZW50IH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IEFsZXJ0VHJpYW5nbGUsIENhbWVyYSwgTWFwUGluLCBQaG9uZSB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcclxuaW1wb3J0IHsgdXNlQ3JlYXRlSW5jaWRlbnQgfSBmcm9tICcuLi8uLi9hcGkvcXVlcmllcydcclxuaW1wb3J0IHR5cGUgeyBJbmNpZGVudENhdGVnb3J5LCBJbmNpZGVudENyZWF0ZVJlcXVlc3QgfSBmcm9tICcuLi8uLi9hcGkvdHlwZXMnXHJcbmltcG9ydCB7IEJ1dHRvbiwgSW5wdXQsIE1vZGFsLCBTZWxlY3QgfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL3VpJ1xyXG5pbXBvcnQgeyB0b0dlb0pzb24sIHR5cGUgR2VvSnNvblBvaW50IH0gZnJvbSAnLi4vLi4vbGliL2dlbydcclxuaW1wb3J0IHsgTGF6eUdlb01hcCB9IGZyb20gJy4vTGF6eUdlb01hcCdcclxuXHJcbmNvbnN0IG5haXJvYmlGYWxsYmFjayA9IHRvR2VvSnNvbihbLTEuMjg2NCwgMzYuODE3Ml0pXHJcbmNvbnN0IGluY2lkZW50Q2F0ZWdvcmllczogeyB2YWx1ZTogSW5jaWRlbnRDYXRlZ29yeTsgbGFiZWw6IHN0cmluZyB9W10gPSBbXHJcbiAgeyB2YWx1ZTogJ2ZsYXRfdHlyZScsIGxhYmVsOiAnRmxhdCBUeXJlJyB9LFxyXG4gIHsgdmFsdWU6ICdiYXR0ZXJ5JywgbGFiZWw6ICdCYXR0ZXJ5JyB9LFxyXG4gIHsgdmFsdWU6ICdvdmVyaGVhdGluZycsIGxhYmVsOiAnT3ZlcmhlYXRpbmcnIH0sXHJcbiAgeyB2YWx1ZTogJ2FjY2lkZW50JywgbGFiZWw6ICdBY2NpZGVudCcgfSxcclxuICB7IHZhbHVlOiAnc3RyYW5nZV9ub2lzZScsIGxhYmVsOiAnU3RyYW5nZSBOb2lzZScgfSxcclxuXVxyXG5cclxuZnVuY3Rpb24gcmVhZFBob3RvKGZpbGU6IEZpbGUpOiBQcm9taXNlPHN0cmluZz4ge1xyXG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpXHJcbiAgICByZWFkZXIuYWRkRXZlbnRMaXN0ZW5lcignbG9hZCcsICgpID0+IHR5cGVvZiByZWFkZXIucmVzdWx0ID09PSAnc3RyaW5nJyA/IHJlc29sdmUocmVhZGVyLnJlc3VsdCkgOiByZWplY3QobmV3IEVycm9yKCdQaG90byBjb3VsZCBub3QgYmUgcmVhZCcpKSlcclxuICAgIHJlYWRlci5hZGRFdmVudExpc3RlbmVyKCdlcnJvcicsICgpID0+IHJlamVjdChuZXcgRXJyb3IoJ1Bob3RvIGNvdWxkIG5vdCBiZSByZWFkJykpKVxyXG4gICAgcmVhZGVyLnJlYWRBc0RhdGFVUkwoZmlsZSlcclxuICB9KVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gU09TQnV0dG9uKHsgc291cmNlLCB2ZWhpY2xlSWQsIGxhYmVsID0gJ1NPUycgfTogeyBzb3VyY2U6IEluY2lkZW50Q3JlYXRlUmVxdWVzdFsnc291cmNlJ107IHZlaGljbGVJZD86IHN0cmluZzsgbGFiZWw/OiBzdHJpbmcgfSkge1xyXG4gIGNvbnN0IGNyZWF0ZUluY2lkZW50ID0gdXNlQ3JlYXRlSW5jaWRlbnQoKVxyXG4gIGNvbnN0IFtvcGVuLCBzZXRPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gIGNvbnN0IFtsb2NhdGlvbiwgc2V0TG9jYXRpb25dID0gdXNlU3RhdGU8R2VvSnNvblBvaW50IHwgbnVsbD4obnVsbClcclxuICBjb25zdCBbZ3BzU3RhdGUsIHNldEdwc1N0YXRlXSA9IHVzZVN0YXRlPCdpZGxlJyB8ICdsb2FkaW5nJyB8ICdyZWFkeScgfCAnZGVuaWVkJz4oJ2lkbGUnKVxyXG4gIGNvbnN0IFtsb2NhdGlvblRleHQsIHNldExvY2F0aW9uVGV4dF0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbY2F0ZWdvcnksIHNldENhdGVnb3J5XSA9IHVzZVN0YXRlPEluY2lkZW50Q2F0ZWdvcnk+KCdmbGF0X3R5cmUnKVxyXG4gIGNvbnN0IFtkZXNjcmlwdGlvbiwgc2V0RGVzY3JpcHRpb25dID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW2ltbW9iaWxpc2luZywgc2V0SW1tb2JpbGlzaW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gIGNvbnN0IFtwaG90b3MsIHNldFBob3Rvc10gPSB1c2VTdGF0ZTxGaWxlW10+KFtdKVxyXG4gIGNvbnN0IFttYW51YWxQaW5Nb2RlLCBzZXRNYW51YWxQaW5Nb2RlXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbClcclxuXHJcbiAgZnVuY3Rpb24gcmVxdWVzdEdwcygpIHtcclxuICAgIHNldEdwc1N0YXRlKCdsb2FkaW5nJylcclxuICAgIGlmICghbmF2aWdhdG9yLmdlb2xvY2F0aW9uKSB7XHJcbiAgICAgIHNldEdwc1N0YXRlKCdkZW5pZWQnKVxyXG4gICAgICByZXR1cm5cclxuICAgIH1cclxuICAgIG5hdmlnYXRvci5nZW9sb2NhdGlvbi5nZXRDdXJyZW50UG9zaXRpb24oKHBvc2l0aW9uKSA9PiB7XHJcbiAgICAgIHNldExvY2F0aW9uKHRvR2VvSnNvbihbcG9zaXRpb24uY29vcmRzLmxhdGl0dWRlLCBwb3NpdGlvbi5jb29yZHMubG9uZ2l0dWRlXSkpXHJcbiAgICAgIHNldExvY2F0aW9uVGV4dCgnR1BTIGxvY2F0aW9uJylcclxuICAgICAgc2V0R3BzU3RhdGUoJ3JlYWR5JylcclxuICAgIH0sICgpID0+IHtcclxuICAgICAgc2V0R3BzU3RhdGUoJ2RlbmllZCcpXHJcbiAgICB9LCB7IGVuYWJsZUhpZ2hBY2N1cmFjeTogdHJ1ZSwgdGltZW91dDogMTBfMDAwLCBtYXhpbXVtQWdlOiAzMF8wMDAgfSlcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIHNob3dGb3JtKCkge1xyXG4gICAgc2V0T3Blbih0cnVlKVxyXG4gICAgc2V0RXJyb3IobnVsbClcclxuICAgIHNldExvY2F0aW9uKG51bGwpXHJcbiAgICBzZXRMb2NhdGlvblRleHQoJycpXHJcbiAgICBzZXRHcHNTdGF0ZSgnaWRsZScpXHJcbiAgICBzZXRNYW51YWxQaW5Nb2RlKHNvdXJjZSA9PT0gJ2Rlc2snKVxyXG4gICAgaWYgKHNvdXJjZSAhPT0gJ2Rlc2snKSByZXF1ZXN0R3BzKClcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIG9uUGhvdG9zKGV2ZW50OiBDaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50Pikge1xyXG4gICAgc2V0UGhvdG9zKChjdXJyZW50KSA9PiBbLi4uY3VycmVudCwgLi4uQXJyYXkuZnJvbShldmVudC5jdXJyZW50VGFyZ2V0LmZpbGVzID8/IFtdKV0pXHJcbiAgICBldmVudC5jdXJyZW50VGFyZ2V0LnZhbHVlID0gJydcclxuICB9XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIHN1Ym1pdChldmVudDogRm9ybUV2ZW50PEhUTUxGb3JtRWxlbWVudD4pIHtcclxuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcclxuICAgIGNvbnN0IHN1Ym1pdHRlZExvY2F0aW9uID0gbG9jYXRpb24gPz8gKGxvY2F0aW9uVGV4dC50cmltKCkgPyBuYWlyb2JpRmFsbGJhY2sgOiBudWxsKVxyXG4gICAgaWYgKCFzdWJtaXR0ZWRMb2NhdGlvbikgeyBzZXRFcnJvcignU2V0IGEgR1BTIGxvY2F0aW9uLCBwbGFjZSBhIHBpbiwgb3IgZW50ZXIgYSByb2FkLCBsYW5kbWFyayBvciB0b3duLicpOyByZXR1cm4gfVxyXG4gICAgc2V0RXJyb3IobnVsbClcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHBob3RvRGF0YSA9IGF3YWl0IFByb21pc2UuYWxsKHBob3Rvcy5tYXAocmVhZFBob3RvKSlcclxuICAgICAgYXdhaXQgY3JlYXRlSW5jaWRlbnQubXV0YXRlQXN5bmMoe1xyXG4gICAgICAgIGNhdGVnb3J5LFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBkZXNjcmlwdGlvbi50cmltKCksXHJcbiAgICAgICAgbG9jYXRpb246IHN1Ym1pdHRlZExvY2F0aW9uLFxyXG4gICAgICAgIGxvY2F0aW9uVGV4dDogbG9jYXRpb25UZXh0LnRyaW0oKSB8fCAoZ3BzU3RhdGUgPT09ICdyZWFkeScgPyAnR1BTIGxvY2F0aW9uJyA6ICdNYW51YWxseSBwbGFjZWQgcGluJyksXHJcbiAgICAgICAgdmVoaWNsZUlkLFxyXG4gICAgICAgIGltbW9iaWxpc2luZyxcclxuICAgICAgICBwaG90b3M6IHBob3RvRGF0YSxcclxuICAgICAgICBzb3VyY2UsXHJcbiAgICAgIH0pXHJcbiAgICAgIHNldE9wZW4oZmFsc2UpXHJcbiAgICAgIHNldFBob3RvcyhbXSlcclxuICAgICAgc2V0RGVzY3JpcHRpb24oJycpXHJcbiAgICB9IGNhdGNoIHtcclxuICAgICAgc2V0RXJyb3IoJ1NPUyBjb3VsZCBub3QgYmUgc2VudC4gWW91ciBkZXRhaWxzIGFuZCBwaG90b3MgYXJlIHN0aWxsIGhlcmU7IHRyeSBhZ2Fpbi4nKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIDw+XHJcbiAgICA8QnV0dG9uIGNsYXNzTmFtZT1cInNvcy10cmlnZ2VyXCIgb25DbGljaz17c2hvd0Zvcm19IHZhcmlhbnQ9XCJkYW5nZXJcIj48QWxlcnRUcmlhbmdsZSBhcmlhLWhpZGRlbj1cInRydWVcIiBzaXplPXsxN30gLz57bGFiZWx9PC9CdXR0b24+XHJcbiAgICB7b3BlbiAmJiA8TW9kYWwgb3BlbiB0aXRsZT1cIlNlbmQgU09TXCIgb25DbG9zZT17KCkgPT4gc2V0T3BlbihmYWxzZSl9PlxyXG4gICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzb3MtZm9ybVwiIG9uU3VibWl0PXsoZXZlbnQpID0+IHZvaWQgc3VibWl0KGV2ZW50KX0+XHJcbiAgICAgICAgPFNlbGVjdCBsYWJlbD1cIklzc3VlIGNhdGVnb3J5XCIgb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0Q2F0ZWdvcnkoZXZlbnQudGFyZ2V0LnZhbHVlIGFzIEluY2lkZW50Q2F0ZWdvcnkpfSBvcHRpb25zPXtpbmNpZGVudENhdGVnb3JpZXN9IHZhbHVlPXtjYXRlZ29yeX0gLz5cclxuICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmllbGRcIj48c3BhbiBjbGFzc05hbWU9XCJmaWVsZF9fbGFiZWxcIj5EZXNjcmliZSB0aGUgaXNzdWU8L3NwYW4+PHRleHRhcmVhIGNsYXNzTmFtZT1cImNvbnRyb2wgc29zLWRlc2NyaXB0aW9uXCIgb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0RGVzY3JpcHRpb24oZXZlbnQudGFyZ2V0LnZhbHVlKX0gdmFsdWU9e2Rlc2NyaXB0aW9ufSAvPjwvbGFiZWw+XHJcbiAgICAgICAge2dwc1N0YXRlID09PSAnbG9hZGluZycgJiYgPHAgcm9sZT1cInN0YXR1c1wiPkdldHRpbmcgeW91ciBHUFMgbG9jYXRpb27igKY8L3A+fVxyXG4gICAgICAgIHtncHNTdGF0ZSA9PT0gJ3JlYWR5JyAmJiA8cCBjbGFzc05hbWU9XCJzb3MtbG9jYXRpb24tc3RhdHVzXCIgcm9sZT1cInN0YXR1c1wiPjxNYXBQaW4gYXJpYS1oaWRkZW49XCJ0cnVlXCIgc2l6ZT17MTZ9IC8+IEdQUyBsb2NhdGlvbiBjYXB0dXJlZDwvcD59XHJcbiAgICAgICAge2dwc1N0YXRlID09PSAnZGVuaWVkJyAmJiA8ZGl2IGNsYXNzTmFtZT1cInNvcy1mYWxsYmFja1wiIHJvbGU9XCJhbGVydFwiPjxwPkdQUyBsb2NhdGlvbiB1bmF2YWlsYWJsZS4gUGxhY2UgYSBwaW4gb3IgZW50ZXIgYSBuZWFyYnkgcm9hZCwgbGFuZG1hcmsgb3IgdG93bi48L3A+PGEgaHJlZj1cInRlbDorMjU0NzAwMTIzNDU2XCI+PFBob25lIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHNpemU9ezE2fSAvPiBDYWxsIHRoZSBkZXNrPC9hPjwvZGl2Pn1cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNvcy1tYXAtY29udHJvbHNcIj5cclxuICAgICAgICAgIDxCdXR0b24gb25DbGljaz17KCkgPT4gc2V0TWFudWFsUGluTW9kZSghbWFudWFsUGluTW9kZSl9IHR5cGU9XCJidXR0b25cIiB2YXJpYW50PXttYW51YWxQaW5Nb2RlID8gJ3ByaW1hcnknIDogJ3NlY29uZGFyeSd9PjxNYXBQaW4gYXJpYS1oaWRkZW49XCJ0cnVlXCIgc2l6ZT17MTZ9IC8+e21hbnVhbFBpbk1vZGUgPyAnQ2xpY2sgbWFwIHRvIHBsYWNlIHBpbicgOiAnUGxhY2UgcGluIG1hbnVhbGx5J308L0J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8TGF6eUdlb01hcCBjZW50ZXI9e2xvY2F0aW9uID8/IG5haXJvYmlGYWxsYmFja30gbWFya2VyPXtsb2NhdGlvbiA/IHsgcG9pbnQ6IGxvY2F0aW9uLCBsYWJlbDogbG9jYXRpb25UZXh0IHx8ICdJbmNpZGVudCBsb2NhdGlvbicsIHRvbmU6ICdkYW5nZXInIH0gOiB1bmRlZmluZWR9IG9uUGxhY2U9eyhwb2ludCkgPT4geyBzZXRMb2NhdGlvbihwb2ludCk7IHNldEdwc1N0YXRlKCdkZW5pZWQnKSB9fSBwbGFjZW1lbnRFbmFibGVkPXttYW51YWxQaW5Nb2RlIHx8IGdwc1N0YXRlID09PSAnZGVuaWVkJ30gem9vbT17MTN9IC8+XHJcbiAgICAgICAgeyhncHNTdGF0ZSA9PT0gJ2RlbmllZCcgfHwgbWFudWFsUGluTW9kZSkgJiYgPElucHV0IGxhYmVsPVwiTG9jYXRpb24gb3IgbGFuZG1hcmtcIiBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRMb2NhdGlvblRleHQoZXZlbnQudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJTdHJlZXQsIGxhbmRtYXJrIG9yIHRvd25cIiB2YWx1ZT17bG9jYXRpb25UZXh0fSAvPn1cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpZWxkXCI+PHNwYW4gY2xhc3NOYW1lPVwiZmllbGRfX2xhYmVsXCI+UGhvdG9zPC9zcGFuPjxsYWJlbCBjbGFzc05hbWU9XCJzb3MtcGhvdG8tcGlja2VyXCI+PENhbWVyYSBhcmlhLWhpZGRlbj1cInRydWVcIiBzaXplPXsxN30gLz4gQWRkIHBob3RvczxpbnB1dCBhY2NlcHQ9XCJpbWFnZS8qXCIgY2FwdHVyZT1cImVudmlyb25tZW50XCIgbXVsdGlwbGUgb25DaGFuZ2U9e29uUGhvdG9zfSB0eXBlPVwiZmlsZVwiIC8+PC9sYWJlbD57cGhvdG9zLm1hcCgocGhvdG8pID0+IDxzbWFsbCBrZXk9e2Ake3Bob3RvLm5hbWV9LSR7cGhvdG8ubGFzdE1vZGlmaWVkfWB9PntwaG90by5uYW1lfTwvc21hbGw+KX08L2Rpdj5cclxuICAgICAgICB7dmVoaWNsZUlkICYmIDxsYWJlbCBjbGFzc05hbWU9XCJjaG9pY2VcIj48aW5wdXQgY2hlY2tlZD17aW1tb2JpbGlzaW5nfSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRJbW1vYmlsaXNpbmcoZXZlbnQudGFyZ2V0LmNoZWNrZWQpfSB0eXBlPVwiY2hlY2tib3hcIiAvPjxzcGFuPlZlaGljbGUgY2Fubm90IGJlIGRyaXZlbjwvc3Bhbj48L2xhYmVsPn1cclxuICAgICAgICB7ZXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwiZmllbGRfX2Vycm9yXCIgcm9sZT1cImFsZXJ0XCI+e2Vycm9yfTwvcD59XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb25maXJtLWRpYWxvZ19fYWN0aW9uc1wiPjxCdXR0b24gb25DbGljaz17KCkgPT4gc2V0T3BlbihmYWxzZSl9IHZhcmlhbnQ9XCJzZWNvbmRhcnlcIj5DYW5jZWw8L0J1dHRvbj48QnV0dG9uIGRpc2FibGVkPXtjcmVhdGVJbmNpZGVudC5pc1BlbmRpbmcgfHwgZ3BzU3RhdGUgPT09ICdsb2FkaW5nJ30gdHlwZT1cInN1Ym1pdFwiIHZhcmlhbnQ9XCJkYW5nZXJcIj57Y3JlYXRlSW5jaWRlbnQuaXNQZW5kaW5nID8gJ1NlbmRpbmfigKYnIDogJ1NlbmQgU09TJ308L0J1dHRvbj48L2Rpdj5cclxuICAgICAgPC9mb3JtPlxyXG4gICAgPC9Nb2RhbD59XHJcbiAgPC8+XHJcbn0iXX0=
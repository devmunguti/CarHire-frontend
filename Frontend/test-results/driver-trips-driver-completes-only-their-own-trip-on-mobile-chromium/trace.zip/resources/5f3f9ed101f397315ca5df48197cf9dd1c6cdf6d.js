import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/LoginPage.tsx");const useState = __vite__cjsImport2_react["useState"];const _jsxDEV = __vite__cjsImport11_react_jsxDevRuntime["jsxDEV"];import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=b37bf19f";
import { Check, Eye, EyeOff, LoaderCircle } from "/node_modules/.vite/deps/lucide-react.js?v=b37bf19f";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=b37bf19f";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=b37bf19f";
import { Link, useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=b37bf19f";
import { z } from "/node_modules/.vite/deps/zod.js?v=b37bf19f";
import { ApiError } from "/src/api/client.ts";
import { useAuth } from "/src/hooks/AuthContext.tsx";
import { getRoleLandingPath } from "/src/hooks/roleLanding.ts";
import { t } from "/src/i18n/index.ts";
import { Button, Input } from "/src/components/ui/index.ts";
var _jsxFileName = "C:/CarHire/Frontend/src/features/auth/LoginPage.tsx";
import __vite__cjsImport11_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b37bf19f";
var _s = $RefreshSig$();
const loginSchema = z.object({
	email: z.string().email(t("auth.emailInvalid")),
	password: z.string().min(1, t("auth.passwordRequired"))
});
export function LoginPage() {
	_s();
	const { login } = useAuth();
	const navigate = useNavigate();
	const location = useLocation();
	const [showPassword, setShowPassword] = useState(false);
	const [loginError, setLoginError] = useState(null);
	const [retrying, setRetrying] = useState(false);
	const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm({
		resolver: zodResolver(loginSchema),
		defaultValues: {
			email: "",
			password: ""
		}
	});
	async function onSubmit(values) {
		setLoginError(null);
		setRetrying(false);
		try {
			const user = await login(values.email, values.password);
			const returnLocation = location.state?.from;
			const returnTo = returnLocation?.pathname ? `${returnLocation.pathname}${returnLocation.search ?? ""}${returnLocation.hash ?? ""}` : getRoleLandingPath(user.role);
			navigate(returnTo, { replace: true });
		} catch (error) {
			if (error instanceof ApiError && error.status === 401) {
				setLoginError({
					kind: "credentials",
					message: t("auth.invalidCredentials")
				});
			} else if (error instanceof ApiError && error.status === 429) {
				const seconds = error.retryAfterSeconds ?? 60;
				setLoginError({
					kind: "rateLimit",
					message: t("auth.rateLimited").replace("{seconds}", String(seconds))
				});
			} else if (error instanceof ApiError && error.code === "ACCOUNT_DEACTIVATED") {
				setLoginError({
					kind: "deactivated",
					message: t("auth.deactivated")
				});
			} else {
				setLoginError({
					kind: "network",
					message: t("auth.networkError")
				});
			}
		}
	}
	async function retryLogin() {
		setRetrying(true);
		await handleSubmit(onSubmit)();
	}
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "login-screen",
		children: [/* @__PURE__ */ _jsxDEV("section", {
			"aria-labelledby": "login-brand-headline",
			className: "login-brand-panel",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "login-brand-panel__content",
				children: [
					/* @__PURE__ */ _jsxDEV(Link, {
						"aria-label": t("admin.brand"),
						className: "brand brand--login",
						to: "/",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "brand__mark",
							children: /* @__PURE__ */ _jsxDEV("span", {
								className: "brand__mark-inner",
								children: /* @__PURE__ */ _jsxDEV(Check, {
									"aria-hidden": "true",
									size: 22
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 69,
									columnNumber: 79
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 69,
								columnNumber: 43
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 69,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "brand__name",
							children: ["AutoHire ", /* @__PURE__ */ _jsxDEV("b", { children: "KE" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 70,
								columnNumber: 52
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 70,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "login-brand-panel__copy",
						children: [
							/* @__PURE__ */ _jsxDEV("p", {
								className: "login-eyebrow",
								children: t("auth.staffPortal")
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 73,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("h1", {
								id: "login-brand-headline",
								children: t("auth.headline")
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 74,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("ul", { children: [
								"auth.benefitFleet",
								"auth.benefitBookings",
								"auth.benefitTeam"
							].map((key) => /* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("span", {
								"aria-hidden": "true",
								children: /* @__PURE__ */ _jsxDEV(Check, { size: 15 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 77,
									columnNumber: 56
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 77,
								columnNumber: 31
							}, this), t(key)] }, key, true, {
								fileName: _jsxFileName,
								lineNumber: 77,
								columnNumber: 17
							}, this)) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 75,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "login-brand-panel__footnote",
						children: t("auth.kenya")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 67,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 66,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("section", {
			"aria-labelledby": "login-title",
			className: "login-form-panel",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "login-form-wrap",
				children: [
					/* @__PURE__ */ _jsxDEV("p", {
						className: "login-form-kicker",
						children: t("auth.welcome")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 87,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", {
						id: "login-title",
						children: t("auth.signInTitle")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 88,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "login-form-description",
						children: t("auth.signInDescription")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 11
					}, this),
					loginError && /* @__PURE__ */ _jsxDEV("div", {
						className: `login-alert login-alert--${loginError.kind}`,
						role: "alert",
						children: [/* @__PURE__ */ _jsxDEV("p", { children: loginError.message }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 93,
							columnNumber: 15
						}, this), loginError.kind === "network" && /* @__PURE__ */ _jsxDEV(Button, {
							disabled: isSubmitting || retrying,
							onClick: retryLogin,
							size: "sm",
							variant: "secondary",
							children: [(isSubmitting || retrying) && /* @__PURE__ */ _jsxDEV(LoaderCircle, {
								"aria-hidden": "true",
								className: "spin",
								size: 15
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 96,
								columnNumber: 50
							}, this), t("auth.retry")]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 95,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 92,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("form", {
						className: "login-form",
						noValidate: true,
						onSubmit: handleSubmit(onSubmit),
						children: [
							/* @__PURE__ */ _jsxDEV(Input, {
								autoComplete: "username",
								error: errors.email?.message,
								label: t("auth.email"),
								placeholder: t("auth.emailPlaceholder"),
								type: "email",
								...register("email")
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 104,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "field",
								children: [
									/* @__PURE__ */ _jsxDEV("label", {
										className: "field__label",
										htmlFor: "login-password",
										children: t("auth.password")
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 106,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "login-password-control",
										children: [/* @__PURE__ */ _jsxDEV("input", {
											autoComplete: "current-password",
											className: "control",
											id: "login-password",
											type: showPassword ? "text" : "password",
											...register("password")
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 108,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											"aria-label": t(showPassword ? "auth.hidePassword" : "auth.showPassword"),
											className: "password-toggle",
											onClick: () => setShowPassword(!showPassword),
											type: "button",
											children: showPassword ? /* @__PURE__ */ _jsxDEV(EyeOff, {
												"aria-hidden": "true",
												size: 18
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 110,
												columnNumber: 35
											}, this) : /* @__PURE__ */ _jsxDEV(Eye, {
												"aria-hidden": "true",
												size: 18
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 110,
												columnNumber: 77
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 109,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 107,
										columnNumber: 15
									}, this),
									errors.password && /* @__PURE__ */ _jsxDEV("span", {
										className: "field__error",
										children: errors.password.message
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 113,
										columnNumber: 35
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 105,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV(Button, {
								className: "login-submit",
								disabled: isSubmitting,
								type: "submit",
								children: [isSubmitting && /* @__PURE__ */ _jsxDEV(LoaderCircle, {
									"aria-hidden": "true",
									className: "spin",
									size: 17
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 116,
									columnNumber: 32
								}, this), isSubmitting ? t("auth.submitting") : t("auth.signIn")]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 115,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 103,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "login-invite-note",
						children: t("auth.inviteOnly")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 120,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 86,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 85,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 65,
		columnNumber: 5
	}, this);
}
_s(LoginPage, "8mTFHP5PAXwLCdMMie1F7cQdYVE=", false, function() {
	return [
		useAuth,
		useNavigate,
		useLocation,
		useForm
	];
});
_c = LoginPage;
var _c;
$RefreshReg$(_c, "LoginPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/auth/LoginPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/CarHire/Frontend/src/features/auth/LoginPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/CarHire/Frontend/src/features/auth/LoginPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/CarHire/Frontend/src/features/auth/LoginPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxPQUFPLEtBQUssUUFBUSxvQkFBb0I7QUFDakQsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsTUFBTSxhQUFhLG1CQUFtQjtBQUMvQyxTQUFTLFNBQVM7QUFDbEIsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsMEJBQTBCO0FBQ25DLFNBQVMsU0FBUztBQUNsQixTQUFTLFFBQVEsYUFBYTs7OztBQUU5QixNQUFNLGNBQWMsRUFBRSxPQUFPO0NBQzNCLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQyxNQUFNLEVBQUUsbUJBQW1CLENBQUM7Q0FDOUMsVUFBVSxFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksR0FBRyxFQUFFLHVCQUF1QixDQUFDO0FBQ3hELENBQUM7QUFPRCxPQUFPLFNBQVMsWUFBWTs7Q0FDMUIsTUFBTSxFQUFFLFVBQVUsUUFBUTtDQUMxQixNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxLQUFLO0NBQ3RELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUF1RCxJQUFJO0NBQy9GLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxLQUFLO0NBQzlDLE1BQU0sRUFBRSxVQUFVLGNBQWMsV0FBVyxFQUFFLFFBQVEsbUJBQW1CLFFBQXFCO0VBQzNGLFVBQVUsWUFBWSxXQUFXO0VBQ2pDLGVBQWU7R0FBRSxPQUFPO0dBQUksVUFBVTtFQUFHO0NBQzNDLENBQUM7Q0FFRCxlQUFlLFNBQVMsUUFBcUI7RUFDM0MsY0FBYyxJQUFJO0VBQ2xCLFlBQVksS0FBSztFQUNqQixJQUFJO0dBQ0YsTUFBTSxPQUFPLE1BQU0sTUFBTSxPQUFPLE9BQU8sT0FBTyxRQUFRO0dBQ3RELE1BQU0saUJBQWtCLFNBQVMsT0FBaUM7R0FDbEUsTUFBTSxXQUFXLGdCQUFnQixXQUM3QixHQUFHLGVBQWUsV0FBVyxlQUFlLFVBQVUsS0FBSyxlQUFlLFFBQVEsT0FDbEYsbUJBQW1CLEtBQUssSUFBSTtHQUNoQyxTQUFTLFVBQVUsRUFBRSxTQUFTLEtBQUssQ0FBQztFQUN0QyxTQUFTLE9BQU87R0FDZCxJQUFJLGlCQUFpQixZQUFZLE1BQU0sV0FBVyxLQUFLO0lBQ3JELGNBQWM7S0FBRSxNQUFNO0tBQWUsU0FBUyxFQUFFLHlCQUF5QjtJQUFFLENBQUM7R0FDOUUsT0FBTyxJQUFJLGlCQUFpQixZQUFZLE1BQU0sV0FBVyxLQUFLO0lBQzVELE1BQU0sVUFBVSxNQUFNLHFCQUFxQjtJQUMzQyxjQUFjO0tBQUUsTUFBTTtLQUFhLFNBQVMsRUFBRSxrQkFBa0IsQ0FBQyxDQUFDLFFBQVEsYUFBYSxPQUFPLE9BQU8sQ0FBQztJQUFFLENBQUM7R0FDM0csT0FBTyxJQUFJLGlCQUFpQixZQUFZLE1BQU0sU0FBUyx1QkFBdUI7SUFDNUUsY0FBYztLQUFFLE1BQU07S0FBZSxTQUFTLEVBQUUsa0JBQWtCO0lBQUUsQ0FBQztHQUN2RSxPQUFPO0lBQ0wsY0FBYztLQUFFLE1BQU07S0FBVyxTQUFTLEVBQUUsbUJBQW1CO0lBQUUsQ0FBQztHQUNwRTtFQUNGO0NBQ0Y7Q0FFQSxlQUFlLGFBQWE7RUFDMUIsWUFBWSxJQUFJO0VBQ2hCLE1BQU0sYUFBYSxRQUFRLENBQUMsQ0FBQztDQUMvQjtDQUVBLE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFdBQVU7WUFBaEIsQ0FDRSx3QkFBQyxXQUFEO0dBQVMsbUJBQWdCO0dBQXVCLFdBQVU7YUFDeEQsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE1BQUQ7TUFBTSxjQUFZLEVBQUUsYUFBYTtNQUFHLFdBQVU7TUFBcUIsSUFBRztnQkFBdEUsQ0FDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBYyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBb0Isd0JBQUMsT0FBRDtTQUFPLGVBQVk7U0FBTyxNQUFNO1FBQUs7Ozs7O09BQU87Ozs7O01BQU87Ozs7Z0JBQ3JILHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFoQixDQUE4QixhQUFTLHdCQUFDLEtBQUQsWUFBRyxLQUFLOzs7O2VBQU87Ozs7O2NBQ2xEOzs7Ozs7S0FDTix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFpQixFQUFFLGtCQUFrQjtPQUFLOzs7OztPQUN2RCx3QkFBQyxNQUFEO1FBQUksSUFBRztrQkFBd0IsRUFBRSxlQUFlO09BQU07Ozs7O09BQ3RELHdCQUFDLE1BQUQsWUFDRztRQUFDO1FBQXFCO1FBQXdCO09BQWtCLENBQUMsQ0FBQyxLQUFLLFFBQ3RFLHdCQUFDLE1BQUQsYUFBYyx3QkFBQyxRQUFEO1FBQU0sZUFBWTtrQkFBTyx3QkFBQyxPQUFELEVBQU8sTUFBTSxHQUFLOzs7OztPQUFPOzs7O2lCQUFFLEVBQUUsR0FBRyxDQUFNLEtBQXBFOzs7O2NBQW9FLENBQzlFLEVBQ0M7Ozs7O01BQ0Q7Ozs7OztLQUNMLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUErQixFQUFFLFlBQVk7S0FBSzs7Ozs7SUFDNUQ7Ozs7OztFQUNFOzs7O1lBRVQsd0JBQUMsV0FBRDtHQUFTLG1CQUFnQjtHQUFjLFdBQVU7YUFDL0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFxQixFQUFFLGNBQWM7S0FBSzs7Ozs7S0FDdkQsd0JBQUMsTUFBRDtNQUFJLElBQUc7Z0JBQWUsRUFBRSxrQkFBa0I7S0FBTTs7Ozs7S0FDaEQsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQTBCLEVBQUUsd0JBQXdCO0tBQUs7Ozs7O0tBRXJFLGNBQ0Msd0JBQUMsT0FBRDtNQUFLLFdBQVcsNEJBQTRCLFdBQVc7TUFBUSxNQUFLO2dCQUFwRSxDQUNFLHdCQUFDLEtBQUQsWUFBSSxXQUFXLFFBQVc7Ozs7Z0JBQ3pCLFdBQVcsU0FBUyxhQUNuQix3QkFBQyxRQUFEO09BQVEsVUFBVSxnQkFBZ0I7T0FBVSxTQUFTO09BQVksTUFBSztPQUFLLFNBQVE7aUJBQW5GLEVBQ0ksZ0JBQWdCLGFBQWEsd0JBQUMsY0FBRDtRQUFjLGVBQVk7UUFBTyxXQUFVO1FBQU8sTUFBTTtPQUFLOzs7O2lCQUMzRixFQUFFLFlBQVksQ0FDVDs7Ozs7Y0FFUDs7Ozs7O0tBR1Asd0JBQUMsUUFBRDtNQUFNLFdBQVU7TUFBYTtNQUFXLFVBQVUsYUFBYSxRQUFRO2dCQUF2RTtPQUNFLHdCQUFDLE9BQUQ7UUFBTyxjQUFhO1FBQVcsT0FBTyxPQUFPLE9BQU87UUFBUyxPQUFPLEVBQUUsWUFBWTtRQUFHLGFBQWEsRUFBRSx1QkFBdUI7UUFBRyxNQUFLO1FBQVEsR0FBSSxTQUFTLE9BQU87T0FBSTs7Ozs7T0FDbkssd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtVQUFlLFNBQVE7b0JBQWtCLEVBQUUsZUFBZTtTQUFTOzs7OztTQUNwRix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEIsQ0FDRSx3QkFBQyxTQUFEO1dBQU8sY0FBYTtXQUFtQixXQUFVO1dBQVUsSUFBRztXQUFpQixNQUFNLGVBQWUsU0FBUztXQUFZLEdBQUksU0FBUyxVQUFVO1VBQUk7Ozs7b0JBQ3BKLHdCQUFDLFVBQUQ7V0FBUSxjQUFZLEVBQUUsZUFBZSxzQkFBc0IsbUJBQW1CO1dBQUcsV0FBVTtXQUFrQixlQUFlLGdCQUFnQixDQUFDLFlBQVk7V0FBRyxNQUFLO3FCQUM5SixlQUFlLHdCQUFDLFFBQUQ7WUFBUSxlQUFZO1lBQU8sTUFBTTtXQUFLOzs7O3NCQUFJLHdCQUFDLEtBQUQ7WUFBSyxlQUFZO1lBQU8sTUFBTTtXQUFLOzs7OztVQUN2Rjs7OztrQkFDSjs7Ozs7O1NBQ0wsT0FBTyxZQUFZLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFnQixPQUFPLFNBQVM7U0FBYzs7Ozs7UUFDL0U7Ozs7OztPQUNMLHdCQUFDLFFBQUQ7UUFBUSxXQUFVO1FBQWUsVUFBVTtRQUFjLE1BQUs7a0JBQTlELENBQ0csZ0JBQWdCLHdCQUFDLGNBQUQ7U0FBYyxlQUFZO1NBQU8sV0FBVTtTQUFPLE1BQU07UUFBSzs7OztrQkFDN0UsZUFBZSxFQUFFLGlCQUFpQixJQUFJLEVBQUUsYUFBYSxDQUNoRDs7Ozs7O01BQ0o7Ozs7OztLQUNOLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFxQixFQUFFLGlCQUFpQjtLQUFLOzs7OztJQUN2RDs7Ozs7O0VBQ0U7Ozs7VUFDTDs7Ozs7O0FBRVYiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTG9naW5QYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB6b2RSZXNvbHZlciB9IGZyb20gJ0Bob29rZm9ybS9yZXNvbHZlcnMvem9kJ1xyXG5pbXBvcnQgeyBDaGVjaywgRXllLCBFeWVPZmYsIExvYWRlckNpcmNsZSB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcclxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgdXNlRm9ybSB9IGZyb20gJ3JlYWN0LWhvb2stZm9ybSdcclxuaW1wb3J0IHsgTGluaywgdXNlTG9jYXRpb24sIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcclxuaW1wb3J0IHsgeiB9IGZyb20gJ3pvZCdcclxuaW1wb3J0IHsgQXBpRXJyb3IgfSBmcm9tICcuLi8uLi9hcGkvY2xpZW50J1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vaG9va3MvQXV0aENvbnRleHQnXHJcbmltcG9ydCB7IGdldFJvbGVMYW5kaW5nUGF0aCB9IGZyb20gJy4uLy4uL2hvb2tzL3JvbGVMYW5kaW5nJ1xyXG5pbXBvcnQgeyB0IH0gZnJvbSAnLi4vLi4vaTE4bidcclxuaW1wb3J0IHsgQnV0dG9uLCBJbnB1dCB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvdWknXHJcblxyXG5jb25zdCBsb2dpblNjaGVtYSA9IHoub2JqZWN0KHtcclxuICBlbWFpbDogei5zdHJpbmcoKS5lbWFpbCh0KCdhdXRoLmVtYWlsSW52YWxpZCcpKSxcclxuICBwYXNzd29yZDogei5zdHJpbmcoKS5taW4oMSwgdCgnYXV0aC5wYXNzd29yZFJlcXVpcmVkJykpLFxyXG59KVxyXG5cclxudHlwZSBMb2dpblZhbHVlcyA9IHouaW5mZXI8dHlwZW9mIGxvZ2luU2NoZW1hPlxyXG50eXBlIExvZ2luRXJyb3IgPSAnY3JlZGVudGlhbHMnIHwgJ3JhdGVMaW1pdCcgfCAnZGVhY3RpdmF0ZWQnIHwgJ25ldHdvcmsnXHJcblxyXG50eXBlIFJldHVybkxvY2F0aW9uID0geyBmcm9tPzogeyBwYXRobmFtZT86IHN0cmluZzsgc2VhcmNoPzogc3RyaW5nOyBoYXNoPzogc3RyaW5nIH0gfVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIExvZ2luUGFnZSgpIHtcclxuICBjb25zdCB7IGxvZ2luIH0gPSB1c2VBdXRoKClcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcclxuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKClcclxuICBjb25zdCBbc2hvd1Bhc3N3b3JkLCBzZXRTaG93UGFzc3dvcmRdID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgY29uc3QgW2xvZ2luRXJyb3IsIHNldExvZ2luRXJyb3JdID0gdXNlU3RhdGU8eyBraW5kOiBMb2dpbkVycm9yOyBtZXNzYWdlOiBzdHJpbmcgfSB8IG51bGw+KG51bGwpXHJcbiAgY29uc3QgW3JldHJ5aW5nLCBzZXRSZXRyeWluZ10gPSB1c2VTdGF0ZShmYWxzZSlcclxuICBjb25zdCB7IHJlZ2lzdGVyLCBoYW5kbGVTdWJtaXQsIGZvcm1TdGF0ZTogeyBlcnJvcnMsIGlzU3VibWl0dGluZyB9IH0gPSB1c2VGb3JtPExvZ2luVmFsdWVzPih7XHJcbiAgICByZXNvbHZlcjogem9kUmVzb2x2ZXIobG9naW5TY2hlbWEpLFxyXG4gICAgZGVmYXVsdFZhbHVlczogeyBlbWFpbDogJycsIHBhc3N3b3JkOiAnJyB9LFxyXG4gIH0pXHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIG9uU3VibWl0KHZhbHVlczogTG9naW5WYWx1ZXMpIHtcclxuICAgIHNldExvZ2luRXJyb3IobnVsbClcclxuICAgIHNldFJldHJ5aW5nKGZhbHNlKVxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgdXNlciA9IGF3YWl0IGxvZ2luKHZhbHVlcy5lbWFpbCwgdmFsdWVzLnBhc3N3b3JkKVxyXG4gICAgICBjb25zdCByZXR1cm5Mb2NhdGlvbiA9IChsb2NhdGlvbi5zdGF0ZSBhcyBSZXR1cm5Mb2NhdGlvbiB8IG51bGwpPy5mcm9tXHJcbiAgICAgIGNvbnN0IHJldHVyblRvID0gcmV0dXJuTG9jYXRpb24/LnBhdGhuYW1lXHJcbiAgICAgICAgPyBgJHtyZXR1cm5Mb2NhdGlvbi5wYXRobmFtZX0ke3JldHVybkxvY2F0aW9uLnNlYXJjaCA/PyAnJ30ke3JldHVybkxvY2F0aW9uLmhhc2ggPz8gJyd9YFxyXG4gICAgICAgIDogZ2V0Um9sZUxhbmRpbmdQYXRoKHVzZXIucm9sZSlcclxuICAgICAgbmF2aWdhdGUocmV0dXJuVG8sIHsgcmVwbGFjZTogdHJ1ZSB9KVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgQXBpRXJyb3IgJiYgZXJyb3Iuc3RhdHVzID09PSA0MDEpIHtcclxuICAgICAgICBzZXRMb2dpbkVycm9yKHsga2luZDogJ2NyZWRlbnRpYWxzJywgbWVzc2FnZTogdCgnYXV0aC5pbnZhbGlkQ3JlZGVudGlhbHMnKSB9KVxyXG4gICAgICB9IGVsc2UgaWYgKGVycm9yIGluc3RhbmNlb2YgQXBpRXJyb3IgJiYgZXJyb3Iuc3RhdHVzID09PSA0MjkpIHtcclxuICAgICAgICBjb25zdCBzZWNvbmRzID0gZXJyb3IucmV0cnlBZnRlclNlY29uZHMgPz8gNjBcclxuICAgICAgICBzZXRMb2dpbkVycm9yKHsga2luZDogJ3JhdGVMaW1pdCcsIG1lc3NhZ2U6IHQoJ2F1dGgucmF0ZUxpbWl0ZWQnKS5yZXBsYWNlKCd7c2Vjb25kc30nLCBTdHJpbmcoc2Vjb25kcykpIH0pXHJcbiAgICAgIH0gZWxzZSBpZiAoZXJyb3IgaW5zdGFuY2VvZiBBcGlFcnJvciAmJiBlcnJvci5jb2RlID09PSAnQUNDT1VOVF9ERUFDVElWQVRFRCcpIHtcclxuICAgICAgICBzZXRMb2dpbkVycm9yKHsga2luZDogJ2RlYWN0aXZhdGVkJywgbWVzc2FnZTogdCgnYXV0aC5kZWFjdGl2YXRlZCcpIH0pXHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0TG9naW5FcnJvcih7IGtpbmQ6ICduZXR3b3JrJywgbWVzc2FnZTogdCgnYXV0aC5uZXR3b3JrRXJyb3InKSB9KVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBhc3luYyBmdW5jdGlvbiByZXRyeUxvZ2luKCkge1xyXG4gICAgc2V0UmV0cnlpbmcodHJ1ZSlcclxuICAgIGF3YWl0IGhhbmRsZVN1Ym1pdChvblN1Ym1pdCkoKVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxtYWluIGNsYXNzTmFtZT1cImxvZ2luLXNjcmVlblwiPlxyXG4gICAgICA8c2VjdGlvbiBhcmlhLWxhYmVsbGVkYnk9XCJsb2dpbi1icmFuZC1oZWFkbGluZVwiIGNsYXNzTmFtZT1cImxvZ2luLWJyYW5kLXBhbmVsXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsb2dpbi1icmFuZC1wYW5lbF9fY29udGVudFwiPlxyXG4gICAgICAgICAgPExpbmsgYXJpYS1sYWJlbD17dCgnYWRtaW4uYnJhbmQnKX0gY2xhc3NOYW1lPVwiYnJhbmQgYnJhbmQtLWxvZ2luXCIgdG89XCIvXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJyYW5kX19tYXJrXCI+PHNwYW4gY2xhc3NOYW1lPVwiYnJhbmRfX21hcmstaW5uZXJcIj48Q2hlY2sgYXJpYS1oaWRkZW49XCJ0cnVlXCIgc2l6ZT17MjJ9IC8+PC9zcGFuPjwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYnJhbmRfX25hbWVcIj5BdXRvSGlyZSA8Yj5LRTwvYj48L3NwYW4+XHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxvZ2luLWJyYW5kLXBhbmVsX19jb3B5XCI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImxvZ2luLWV5ZWJyb3dcIj57dCgnYXV0aC5zdGFmZlBvcnRhbCcpfTwvcD5cclxuICAgICAgICAgICAgPGgxIGlkPVwibG9naW4tYnJhbmQtaGVhZGxpbmVcIj57dCgnYXV0aC5oZWFkbGluZScpfTwvaDE+XHJcbiAgICAgICAgICAgIDx1bD5cclxuICAgICAgICAgICAgICB7WydhdXRoLmJlbmVmaXRGbGVldCcsICdhdXRoLmJlbmVmaXRCb29raW5ncycsICdhdXRoLmJlbmVmaXRUZWFtJ10ubWFwKChrZXkpID0+IChcclxuICAgICAgICAgICAgICAgIDxsaSBrZXk9e2tleX0+PHNwYW4gYXJpYS1oaWRkZW49XCJ0cnVlXCI+PENoZWNrIHNpemU9ezE1fSAvPjwvc3Bhbj57dChrZXkpfTwvbGk+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImxvZ2luLWJyYW5kLXBhbmVsX19mb290bm90ZVwiPnt0KCdhdXRoLmtlbnlhJyl9PC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICA8c2VjdGlvbiBhcmlhLWxhYmVsbGVkYnk9XCJsb2dpbi10aXRsZVwiIGNsYXNzTmFtZT1cImxvZ2luLWZvcm0tcGFuZWxcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxvZ2luLWZvcm0td3JhcFwiPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibG9naW4tZm9ybS1raWNrZXJcIj57dCgnYXV0aC53ZWxjb21lJyl9PC9wPlxyXG4gICAgICAgICAgPGgyIGlkPVwibG9naW4tdGl0bGVcIj57dCgnYXV0aC5zaWduSW5UaXRsZScpfTwvaDI+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJsb2dpbi1mb3JtLWRlc2NyaXB0aW9uXCI+e3QoJ2F1dGguc2lnbkluRGVzY3JpcHRpb24nKX08L3A+XHJcblxyXG4gICAgICAgICAge2xvZ2luRXJyb3IgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGxvZ2luLWFsZXJ0IGxvZ2luLWFsZXJ0LS0ke2xvZ2luRXJyb3Iua2luZH1gfSByb2xlPVwiYWxlcnRcIj5cclxuICAgICAgICAgICAgICA8cD57bG9naW5FcnJvci5tZXNzYWdlfTwvcD5cclxuICAgICAgICAgICAgICB7bG9naW5FcnJvci5raW5kID09PSAnbmV0d29yaycgJiYgKFxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvbiBkaXNhYmxlZD17aXNTdWJtaXR0aW5nIHx8IHJldHJ5aW5nfSBvbkNsaWNrPXtyZXRyeUxvZ2lufSBzaXplPVwic21cIiB2YXJpYW50PVwic2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgIHsoaXNTdWJtaXR0aW5nIHx8IHJldHJ5aW5nKSAmJiA8TG9hZGVyQ2lyY2xlIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIGNsYXNzTmFtZT1cInNwaW5cIiBzaXplPXsxNX0gLz59XHJcbiAgICAgICAgICAgICAgICAgIHt0KCdhdXRoLnJldHJ5Jyl9XHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwibG9naW4tZm9ybVwiIG5vVmFsaWRhdGUgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdChvblN1Ym1pdCl9PlxyXG4gICAgICAgICAgICA8SW5wdXQgYXV0b0NvbXBsZXRlPVwidXNlcm5hbWVcIiBlcnJvcj17ZXJyb3JzLmVtYWlsPy5tZXNzYWdlfSBsYWJlbD17dCgnYXV0aC5lbWFpbCcpfSBwbGFjZWhvbGRlcj17dCgnYXV0aC5lbWFpbFBsYWNlaG9sZGVyJyl9IHR5cGU9XCJlbWFpbFwiIHsuLi5yZWdpc3RlcignZW1haWwnKX0gLz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaWVsZFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmaWVsZF9fbGFiZWxcIiBodG1sRm9yPVwibG9naW4tcGFzc3dvcmRcIj57dCgnYXV0aC5wYXNzd29yZCcpfTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibG9naW4tcGFzc3dvcmQtY29udHJvbFwiPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0IGF1dG9Db21wbGV0ZT1cImN1cnJlbnQtcGFzc3dvcmRcIiBjbGFzc05hbWU9XCJjb250cm9sXCIgaWQ9XCJsb2dpbi1wYXNzd29yZFwiIHR5cGU9e3Nob3dQYXNzd29yZCA/ICd0ZXh0JyA6ICdwYXNzd29yZCd9IHsuLi5yZWdpc3RlcigncGFzc3dvcmQnKX0gLz5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gYXJpYS1sYWJlbD17dChzaG93UGFzc3dvcmQgPyAnYXV0aC5oaWRlUGFzc3dvcmQnIDogJ2F1dGguc2hvd1Bhc3N3b3JkJyl9IGNsYXNzTmFtZT1cInBhc3N3b3JkLXRvZ2dsZVwiIG9uQ2xpY2s9eygpID0+IHNldFNob3dQYXNzd29yZCghc2hvd1Bhc3N3b3JkKX0gdHlwZT1cImJ1dHRvblwiPlxyXG4gICAgICAgICAgICAgICAgICB7c2hvd1Bhc3N3b3JkID8gPEV5ZU9mZiBhcmlhLWhpZGRlbj1cInRydWVcIiBzaXplPXsxOH0gLz4gOiA8RXllIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHNpemU9ezE4fSAvPn1cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICB7ZXJyb3JzLnBhc3N3b3JkICYmIDxzcGFuIGNsYXNzTmFtZT1cImZpZWxkX19lcnJvclwiPntlcnJvcnMucGFzc3dvcmQubWVzc2FnZX08L3NwYW4+fVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPEJ1dHRvbiBjbGFzc05hbWU9XCJsb2dpbi1zdWJtaXRcIiBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfSB0eXBlPVwic3VibWl0XCI+XHJcbiAgICAgICAgICAgICAge2lzU3VibWl0dGluZyAmJiA8TG9hZGVyQ2lyY2xlIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIGNsYXNzTmFtZT1cInNwaW5cIiBzaXplPXsxN30gLz59XHJcbiAgICAgICAgICAgICAge2lzU3VibWl0dGluZyA/IHQoJ2F1dGguc3VibWl0dGluZycpIDogdCgnYXV0aC5zaWduSW4nKX1cclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJsb2dpbi1pbnZpdGUtbm90ZVwiPnt0KCdhdXRoLmludml0ZU9ubHknKX08L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuICAgIDwvbWFpbj5cclxuICApXHJcbn0iXX0=
import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/incidents/LazyGeoMap.tsx");const lazy = __vite__cjsImport0_react["lazy"]; const Suspense = __vite__cjsImport0_react["Suspense"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=8b23c0c4";
var _jsxFileName = "C:/CarHire/Frontend/src/features/incidents/LazyGeoMap.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b23c0c4";
const GeoMap = lazy(_c = () => import("/src/features/incidents/GeoMap.tsx").then((module) => ({ default: module.GeoMap })));
_c2 = GeoMap;
export function LazyGeoMap(props) {
	return /* @__PURE__ */ _jsxDEV(Suspense, {
		fallback: /* @__PURE__ */ _jsxDEV("div", {
			"aria-label": "Loading map",
			className: `geo-map ${props.className ?? ""}`,
			role: "status"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 7,
			columnNumber: 30
		}, this),
		children: /* @__PURE__ */ _jsxDEV(GeoMap, { ...props }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 8,
			columnNumber: 5
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 7,
		columnNumber: 10
	}, this);
}
_c3 = LazyGeoMap;
var _c, _c2, _c3;
$RefreshReg$(_c, "GeoMap$lazy");
$RefreshReg$(_c2, "GeoMap");
$RefreshReg$(_c3, "LazyGeoMap");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/incidents/LazyGeoMap.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/CarHire/Frontend/src/features/incidents/LazyGeoMap.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/CarHire/Frontend/src/features/incidents/LazyGeoMap.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/CarHire/Frontend/src/features/incidents/LazyGeoMap.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxNQUFNLGdCQUFxQzs7O0FBR3BELE1BQU0sU0FBUyxnQkFBVyxPQUFPLFdBQVcsQ0FBQyxNQUFNLFlBQVksRUFBRSxTQUFTLE9BQU8sT0FBTyxFQUFFLENBQUM7O0FBRTNGLE9BQU8sU0FBUyxXQUFXLE9BQStDO0NBQ3hFLE9BQU8sd0JBQUMsVUFBRDtFQUFVLFVBQVUsd0JBQUMsT0FBRDtHQUFLLGNBQVc7R0FBYyxXQUFXLFdBQVcsTUFBTSxhQUFhO0dBQU0sTUFBSztFQUFVOzs7OztZQUNySCx3QkFBQyxRQUFELEVBQVEsR0FBSSxNQUFROzs7OztDQUNaOzs7OztBQUNaIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkxhenlHZW9NYXAudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGxhenksIFN1c3BlbnNlLCB0eXBlIENvbXBvbmVudFByb3BzIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB0eXBlIHsgR2VvTWFwIGFzIEdlb01hcENvbXBvbmVudCB9IGZyb20gJy4vR2VvTWFwJ1xyXG5cclxuY29uc3QgR2VvTWFwID0gbGF6eSgoKSA9PiBpbXBvcnQoJy4vR2VvTWFwJykudGhlbigobW9kdWxlKSA9PiAoeyBkZWZhdWx0OiBtb2R1bGUuR2VvTWFwIH0pKSlcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBMYXp5R2VvTWFwKHByb3BzOiBDb21wb25lbnRQcm9wczx0eXBlb2YgR2VvTWFwQ29tcG9uZW50Pikge1xyXG4gIHJldHVybiA8U3VzcGVuc2UgZmFsbGJhY2s9ezxkaXYgYXJpYS1sYWJlbD1cIkxvYWRpbmcgbWFwXCIgY2xhc3NOYW1lPXtgZ2VvLW1hcCAke3Byb3BzLmNsYXNzTmFtZSA/PyAnJ31gfSByb2xlPVwic3RhdHVzXCIgLz59PlxyXG4gICAgPEdlb01hcCB7Li4ucHJvcHN9IC8+XHJcbiAgPC9TdXNwZW5zZT5cclxufVxyXG4iXX0=
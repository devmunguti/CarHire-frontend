import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/dashboard/DashboardPage.tsx");const _jsxDEV = __vite__cjsImport10_react_jsxDevRuntime["jsxDEV"];import { Activity, AlertTriangle, ArrowUpRight, CarFront, ClipboardCheck, Clock3 } from "/node_modules/.vite/deps/lucide-react.js?v=d6f2c477";
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "/node_modules/.vite/deps/recharts.js?v=d6f2c477";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=d6f2c477";
import { useDashboard } from "/src/api/queries.ts";
import { DataTable, EmptyState } from "/src/components/ui/index.ts";
import { t } from "/src/i18n/index.ts";
import { useAuth } from "/src/hooks/AuthContext.tsx";
import { formatEat, formatKes } from "/src/lib/index.ts";
import { vehicles } from "/src/mocks/fixtures.ts";
import { DashboardKpiCard } from "/src/features/dashboard/DashboardKpiCard.tsx";
var _jsxFileName = "C:/CarHire/Frontend/src/features/dashboard/DashboardPage.tsx";
import __vite__cjsImport10_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d6f2c477";
var _s = $RefreshSig$();
const metricLabels = {
	vehiclesOutToday: "dashboard.vehiclesOut",
	pickupsDueToday: "dashboard.pickupsDue",
	returnsDueToday: "dashboard.returnsDue",
	overdueVehicles: "dashboard.overdue",
	pendingApprovals: "dashboard.pendingApprovals",
	activeBreakdowns: "dashboard.activeBreakdowns",
	monthlyRevenue: "dashboard.monthlyRevenue"
};
const fleetColors = {
	available: "#0f766e",
	rented: "#f97316",
	reserved: "#2563eb",
	maintenance: "#b91c1c"
};
const vehicleById = new Map(vehicles.map((vehicle) => [vehicle.id, vehicle]));
function BookingTable({ rows, type }) {
	const isPickup = type === "pickup";
	const columns = [
		{
			key: "time",
			header: t("dashboard.time"),
			render: (booking) => formatEat(isPickup ? booking.pickupAt : booking.returnAt).split(", ")[1]
		},
		{
			key: "customer",
			header: t("dashboard.customer"),
			render: (booking) => booking.customerName ?? "—"
		},
		{
			key: "vehicle",
			header: t("dashboard.vehicle"),
			render: (booking) => {
				const vehicle = vehicleById.get(booking.vehicleId);
				return vehicle ? `${vehicle.make} ${vehicle.model}` : "—";
			}
		},
		{
			key: "action",
			header: "",
			render: (booking) => /* @__PURE__ */ _jsxDEV(Link, {
				className: "button button--secondary button--sm",
				to: `/admin/bookings/${booking.id}/${isPickup ? "check-out" : "check-in"}`,
				children: t(isPickup ? "dashboard.checkOut" : "dashboard.checkIn")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 7
			}, this)
		}
	];
	const empty = /* @__PURE__ */ _jsxDEV(EmptyState, {
		action: /* @__PURE__ */ _jsxDEV(Link, {
			className: "text-button",
			to: "/admin/bookings",
			children: t("dashboard.viewBookings")
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 50,
			columnNumber: 15
		}, this),
		description: t(isPickup ? "dashboard.noPickups" : "dashboard.noReturns"),
		title: t(isPickup ? "dashboard.noPickups" : "dashboard.noReturns")
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 49,
		columnNumber: 5
	}, this);
	return /* @__PURE__ */ _jsxDEV(DataTable, {
		columns,
		empty,
		rowKey: (booking) => booking.id,
		rows
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 55,
		columnNumber: 10
	}, this);
}
_c = BookingTable;
function FleetStatus({ data }) {
	const chartData = Object.entries(data).map(([name, value]) => ({
		name: t(`dashboard.${name}`),
		value,
		color: fleetColors[name]
	}));
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fleet-status",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			"aria-label": t("dashboard.fleetStatus"),
			className: "fleet-status__chart",
			role: "img",
			children: /* @__PURE__ */ _jsxDEV(ResponsiveContainer, {
				height: "100%",
				width: "100%",
				children: /* @__PURE__ */ _jsxDEV(PieChart, { children: [/* @__PURE__ */ _jsxDEV(Pie, {
					data: chartData,
					dataKey: "value",
					innerRadius: "62%",
					isAnimationActive: false,
					outerRadius: "88%",
					stroke: "none",
					children: chartData.map((item) => /* @__PURE__ */ _jsxDEV(Cell, { fill: item.color }, item.name, false, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 40
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV(Tooltip, { formatter: (value) => [value, t("dashboard.vehicleCount")] }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 68,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 63,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 62,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("ul", {
			className: "fleet-status__legend",
			children: chartData.map((item) => /* @__PURE__ */ _jsxDEV("li", { children: [
				/* @__PURE__ */ _jsxDEV("span", { style: { backgroundColor: item.color } }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 54
				}, this),
				item.name,
				/* @__PURE__ */ _jsxDEV("b", { children: item.value }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 113
				}, this)
			] }, item.name, true, {
				fileName: _jsxFileName,
				lineNumber: 73,
				columnNumber: 34
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 72,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 61,
		columnNumber: 5
	}, this);
}
_c2 = FleetStatus;
function DashboardPanel({ title, icon, children, href }) {
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "dashboard-panel",
		children: [/* @__PURE__ */ _jsxDEV("header", { children: [/* @__PURE__ */ _jsxDEV("span", {
			className: "dashboard-panel__title",
			children: [icon, title]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 82,
			columnNumber: 15
		}, this), href && /* @__PURE__ */ _jsxDEV(Link, {
			"aria-label": `${t("dashboard.viewBookings")}: ${title}`,
			to: href,
			children: /* @__PURE__ */ _jsxDEV(ArrowUpRight, { size: 17 }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 82,
				columnNumber: 157
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 82,
			columnNumber: 85
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 82,
			columnNumber: 7
		}, this), children]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 81,
		columnNumber: 5
	}, this);
}
_c3 = DashboardPanel;
export function DashboardView({ data, role, loading, failed, onRetry }) {
	const keys = [
		"vehiclesOutToday",
		"pickupsDueToday",
		"returnsDueToday",
		"overdueVehicles",
		"pendingApprovals",
		"activeBreakdowns",
		"monthlyRevenue"
	];
	const visibleKeys = role === "owner" || role === "manager" ? keys : keys.filter((key) => key !== "monthlyRevenue");
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "dashboard-page",
		children: [
			/* @__PURE__ */ _jsxDEV("p", {
				className: "dashboard-subtitle",
				children: t("dashboard.subtitle")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 109,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				"aria-label": t("dashboard.title"),
				className: "dashboard-kpi-grid",
				children: visibleKeys.map((key) => {
					const value = data?.metrics[key];
					const error = data?.cardErrors?.[key] ?? (failed && !data ? t("dashboard.metricError") : undefined);
					return /* @__PURE__ */ _jsxDEV(DashboardKpiCard, {
						danger: key === "overdueVehicles",
						error,
						loading: loading && !data,
						metricKey: key,
						onRetry,
						title: t(metricLabels[key]),
						value: key === "monthlyRevenue" ? formatKes(value ?? 0) : String(value ?? 0)
					}, key, false, {
						fileName: _jsxFileName,
						lineNumber: 115,
						columnNumber: 13
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 110,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "dashboard-panel-grid",
				children: [
					/* @__PURE__ */ _jsxDEV(DashboardPanel, {
						href: "/admin/bookings?pickup=due-today",
						icon: /* @__PURE__ */ _jsxDEV(Clock3, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 130,
							columnNumber: 71
						}, this),
						title: t("dashboard.todayPickups"),
						children: /* @__PURE__ */ _jsxDEV(BookingTable, {
							rows: data?.pickups ?? [],
							type: "pickup"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 131,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 130,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(DashboardPanel, {
						href: "/admin/bookings?return=due-today",
						icon: /* @__PURE__ */ _jsxDEV(ClipboardCheck, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 133,
							columnNumber: 71
						}, this),
						title: t("dashboard.todayReturns"),
						children: /* @__PURE__ */ _jsxDEV(BookingTable, {
							rows: data?.returns ?? [],
							type: "return"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 134,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 133,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(DashboardPanel, {
						icon: /* @__PURE__ */ _jsxDEV(CarFront, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 136,
							columnNumber: 31
						}, this),
						title: t("dashboard.fleetStatus"),
						children: data ? /* @__PURE__ */ _jsxDEV(FleetStatus, { data: data.fleetStatus }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 137,
							columnNumber: 19
						}, this) : /* @__PURE__ */ _jsxDEV("div", { className: "dashboard-panel__skeleton" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 137,
							columnNumber: 61
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(DashboardPanel, {
						href: "/admin/bookings?sort=updatedAt",
						icon: /* @__PURE__ */ _jsxDEV(ActivityIcon, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 139,
							columnNumber: 69
						}, this),
						title: t("dashboard.recentActivity"),
						children: data?.recentActivity.length ? /* @__PURE__ */ _jsxDEV("ol", {
							className: "activity-feed",
							children: data.recentActivity.map((activity) => /* @__PURE__ */ _jsxDEV("li", { children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: `activity-feed__icon activity-feed__icon--${activity.kind}`,
									children: /* @__PURE__ */ _jsxDEV(AlertTriangle, {
										"aria-hidden": "true",
										size: 15
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 144,
										columnNumber: 97
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 144,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("b", { children: t(`dashboard.activity${activity.kind[0].toUpperCase()}${activity.kind.slice(1)}`) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 145,
									columnNumber: 25
								}, this), /* @__PURE__ */ _jsxDEV("small", { children: activity.reference }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 145,
									columnNumber: 115
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 145,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("time", {
									dateTime: activity.timestamp,
									children: formatEat(activity.timestamp)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 146,
									columnNumber: 19
								}, this)
							] }, activity.id, true, {
								fileName: _jsxFileName,
								lineNumber: 143,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 141,
							columnNumber: 13
						}, this) : /* @__PURE__ */ _jsxDEV(EmptyState, {
							description: t("dashboard.noActivity"),
							title: t("dashboard.recentActivity")
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 150,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 139,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 129,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 108,
		columnNumber: 5
	}, this);
}
_c4 = DashboardView;
function ActivityIcon() {
	return /* @__PURE__ */ _jsxDEV(Activity, {
		"aria-hidden": "true",
		size: 18
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 158,
		columnNumber: 10
	}, this);
}
_c5 = ActivityIcon;
export function DashboardPage() {
	_s();
	const { data, isLoading, isError, refetch } = useDashboard();
	const { role } = useAuth();
	return /* @__PURE__ */ _jsxDEV(DashboardView, {
		data,
		failed: isError,
		loading: isLoading,
		onRetry: () => void refetch(),
		role: role ?? "agent"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 164,
		columnNumber: 10
	}, this);
}
_s(DashboardPage, "pOmmYC0+YyUQPnBih4OZNatbfNY=", false, function() {
	return [useDashboard, useAuth];
});
_c6 = DashboardPage;
var _c, _c2, _c3, _c4, _c5, _c6;
$RefreshReg$(_c, "BookingTable");
$RefreshReg$(_c2, "FleetStatus");
$RefreshReg$(_c3, "DashboardPanel");
$RefreshReg$(_c4, "DashboardView");
$RefreshReg$(_c5, "ActivityIcon");
$RefreshReg$(_c6, "DashboardPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/dashboard/DashboardPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/CarHire/Frontend/src/features/dashboard/DashboardPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/CarHire/Frontend/src/features/dashboard/DashboardPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/CarHire/Frontend/src/features/dashboard/DashboardPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLGVBQWUsY0FBYyxVQUFVLGdCQUFnQixjQUFjO0FBQ3hGLFNBQVMsTUFBTSxLQUFLLFVBQVUscUJBQXFCLGVBQWU7QUFDbEUsU0FBUyxZQUFZO0FBR3JCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsV0FBVyxrQkFBa0I7QUFDdEMsU0FBUyxTQUFTO0FBQ2xCLFNBQVMsZUFBZTtBQUN4QixTQUFTLFdBQVcsaUJBQWlCO0FBQ3JDLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsd0JBQXdCOzs7O0FBRWpDLE1BQU0sZUFBaUQ7Q0FDckQsa0JBQWtCO0NBQ2xCLGlCQUFpQjtDQUNqQixpQkFBaUI7Q0FDakIsaUJBQWlCO0NBQ2pCLGtCQUFrQjtDQUNsQixrQkFBa0I7Q0FDbEIsZ0JBQWdCO0FBQ2xCO0FBRUEsTUFBTSxjQUFjO0NBQ2xCLFdBQVc7Q0FDWCxRQUFRO0NBQ1IsVUFBVTtDQUNWLGFBQWE7QUFDZjtBQUVBLE1BQU0sY0FBYyxJQUFJLElBQUksU0FBUyxLQUFLLFlBQVksQ0FBQyxRQUFRLElBQUksT0FBTyxDQUFDLENBQUM7QUFFNUUsU0FBUyxhQUFhLEVBQUUsTUFBTSxRQUF3RDtDQUNwRixNQUFNLFdBQVcsU0FBUztDQUMxQixNQUFNLFVBQVU7RUFDZDtHQUFFLEtBQUs7R0FBUSxRQUFRLEVBQUUsZ0JBQWdCO0dBQUcsU0FBUyxZQUFxQixVQUFVLFdBQVcsUUFBUSxXQUFXLFFBQVEsUUFBUSxDQUFDLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQztFQUFHO0VBQ25KO0dBQUUsS0FBSztHQUFZLFFBQVEsRUFBRSxvQkFBb0I7R0FBRyxTQUFTLFlBQXFCLFFBQVEsZ0JBQWdCO0VBQUk7RUFDOUc7R0FBRSxLQUFLO0dBQVcsUUFBUSxFQUFFLG1CQUFtQjtHQUFHLFNBQVMsWUFBcUI7SUFDOUUsTUFBTSxVQUFVLFlBQVksSUFBSSxRQUFRLFNBQVM7SUFDakQsT0FBTyxVQUFVLEdBQUcsUUFBUSxLQUFLLEdBQUcsUUFBUSxVQUFVO0dBQ3hEO0VBQUU7RUFDRjtHQUFFLEtBQUs7R0FBVSxRQUFRO0dBQUksU0FBUyxZQUNwQyx3QkFBQyxNQUFEO0lBQU0sV0FBVTtJQUFzQyxJQUFJLG1CQUFtQixRQUFRLEdBQUcsR0FBRyxXQUFXLGNBQWM7Y0FDakgsRUFBRSxXQUFXLHVCQUF1QixtQkFBbUI7R0FDcEQ7Ozs7O0VBQ047Q0FDSjtDQUNBLE1BQU0sUUFDSix3QkFBQyxZQUFEO0VBQ0UsUUFBUSx3QkFBQyxNQUFEO0dBQU0sV0FBVTtHQUFjLElBQUc7YUFBbUIsRUFBRSx3QkFBd0I7RUFBUTs7Ozs7RUFDOUYsYUFBYSxFQUFFLFdBQVcsd0JBQXdCLHFCQUFxQjtFQUN2RSxPQUFPLEVBQUUsV0FBVyx3QkFBd0IscUJBQXFCO0NBQ2xFOzs7OztDQUVILE9BQU8sd0JBQUMsV0FBRDtFQUFvQjtFQUFnQjtFQUFPLFNBQVMsWUFBWSxRQUFRO0VBQVU7Q0FBTzs7Ozs7QUFDbEc7O0FBRUEsU0FBUyxZQUFZLEVBQUUsUUFBZ0Q7Q0FDckUsTUFBTSxZQUFZLE9BQU8sUUFBUSxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxZQUFZO0VBQUUsTUFBTSxFQUFFLGFBQWEsTUFBTTtFQUFHO0VBQU8sT0FBTyxZQUFZO0NBQWtDLEVBQUU7Q0FDN0osT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Usd0JBQUMsT0FBRDtHQUFLLGNBQVksRUFBRSx1QkFBdUI7R0FBRyxXQUFVO0dBQXNCLE1BQUs7YUFDaEYsd0JBQUMscUJBQUQ7SUFBcUIsUUFBTztJQUFPLE9BQU07Y0FDdkMsd0JBQUMsVUFBRCxhQUNFLHdCQUFDLEtBQUQ7S0FBSyxNQUFNO0tBQVcsU0FBUTtLQUFRLGFBQVk7S0FBTSxtQkFBbUI7S0FBTyxhQUFZO0tBQU0sUUFBTztlQUN4RyxVQUFVLEtBQUssU0FBUyx3QkFBQyxNQUFELEVBQU0sTUFBTSxLQUFLLE1BQXdCLEdBQVosS0FBSzs7OztZQUFPLENBQUM7SUFDaEU7Ozs7Y0FDTCx3QkFBQyxTQUFELEVBQVMsWUFBWSxVQUFVLENBQUMsT0FBTyxFQUFFLHdCQUF3QixDQUFDLEVBQUk7Ozs7WUFDOUQ7Ozs7O0dBQ1M7Ozs7O0VBQ2xCOzs7O1lBQ0wsd0JBQUMsTUFBRDtHQUFJLFdBQVU7YUFDWCxVQUFVLEtBQUssU0FBUyx3QkFBQyxNQUFEO0lBQW9CLHdCQUFDLFFBQUQsRUFBTSxPQUFPLEVBQUUsaUJBQWlCLEtBQUssTUFBTSxFQUFJOzs7OztJQUFFLEtBQUs7SUFBSyx3QkFBQyxLQUFELFlBQUksS0FBSyxNQUFTOzs7OztHQUFLLEtBQTdGLEtBQUs7Ozs7VUFBd0YsQ0FBQztFQUM5SDs7OztVQUNEOzs7Ozs7QUFFVDs7QUFFQSxTQUFTLGVBQWUsRUFBRSxPQUFPLE1BQU0sVUFBVSxRQUFnRjtDQUMvSCxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQW5CLENBQ0Usd0JBQUMsVUFBRCxhQUFRLHdCQUFDLFFBQUQ7R0FBTSxXQUFVO2FBQWhCLENBQTBDLE1BQU0sS0FBWTs7Ozs7WUFBRSxRQUFRLHdCQUFDLE1BQUQ7R0FBTSxjQUFZLEdBQUcsRUFBRSx3QkFBd0IsRUFBRSxJQUFJO0dBQVMsSUFBSTthQUFNLHdCQUFDLGNBQUQsRUFBYyxNQUFNLEdBQUs7Ozs7O0VBQU87Ozs7VUFBVTs7OztZQUMvTCxRQUNNOzs7Ozs7QUFFYjs7QUFFQSxPQUFPLFNBQVMsY0FBYyxFQUM1QixNQUNBLE1BQ0EsU0FDQSxRQUNBLFdBT0M7Q0FDRCxNQUFNLE9BQTJCO0VBQy9CO0VBQW9CO0VBQW1CO0VBQW1CO0VBQzFEO0VBQW9CO0VBQW9CO0NBQzFDO0NBQ0EsTUFBTSxjQUFjLFNBQVMsV0FBVyxTQUFTLFlBQVksT0FBTyxLQUFLLFFBQVEsUUFBUSxRQUFRLGdCQUFnQjtDQUVqSCxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFzQixFQUFFLG9CQUFvQjtHQUFLOzs7OztHQUM5RCx3QkFBQyxXQUFEO0lBQVMsY0FBWSxFQUFFLGlCQUFpQjtJQUFHLFdBQVU7Y0FDbEQsWUFBWSxLQUFLLFFBQVE7S0FDeEIsTUFBTSxRQUFRLE1BQU0sUUFBUTtLQUM1QixNQUFNLFFBQVEsTUFBTSxhQUFhLFNBQVMsVUFBVSxDQUFDLE9BQU8sRUFBRSx1QkFBdUIsSUFBSTtLQUN6RixPQUNFLHdCQUFDLGtCQUFEO01BQ0UsUUFBUSxRQUFRO01BQ1Q7TUFFUCxTQUFTLFdBQVcsQ0FBQztNQUNyQixXQUFXO01BQ0Y7TUFDVCxPQUFPLEVBQUUsYUFBYSxJQUFJO01BQzFCLE9BQU8sUUFBUSxtQkFBbUIsVUFBVSxTQUFTLENBQUMsSUFBSSxPQUFPLFNBQVMsQ0FBQztLQUM1RSxHQU5NOzs7O1lBTU47SUFFTCxDQUFDO0dBQ007Ozs7O0dBRVQsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLGdCQUFEO01BQWdCLE1BQUs7TUFBbUMsTUFBTSx3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7OztNQUFHLE9BQU8sRUFBRSx3QkFBd0I7Z0JBQ25ILHdCQUFDLGNBQUQ7T0FBYyxNQUFNLE1BQU0sV0FBVyxDQUFDO09BQUcsTUFBSztNQUFVOzs7OztLQUMxQzs7Ozs7S0FDaEIsd0JBQUMsZ0JBQUQ7TUFBZ0IsTUFBSztNQUFtQyxNQUFNLHdCQUFDLGdCQUFELEVBQWdCLE1BQU0sR0FBSzs7Ozs7TUFBRyxPQUFPLEVBQUUsd0JBQXdCO2dCQUMzSCx3QkFBQyxjQUFEO09BQWMsTUFBTSxNQUFNLFdBQVcsQ0FBQztPQUFHLE1BQUs7TUFBVTs7Ozs7S0FDMUM7Ozs7O0tBQ2hCLHdCQUFDLGdCQUFEO01BQWdCLE1BQU0sd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7Ozs7TUFBRyxPQUFPLEVBQUUsdUJBQXVCO2dCQUMzRSxPQUFPLHdCQUFDLGFBQUQsRUFBYSxNQUFNLEtBQUssWUFBYzs7OztpQkFBSSx3QkFBQyxPQUFELEVBQUssV0FBVSw0QkFBNkI7Ozs7O0tBQ2hGOzs7OztLQUNoQix3QkFBQyxnQkFBRDtNQUFnQixNQUFLO01BQWlDLE1BQU0sd0JBQUMsY0FBRCxDQUFlOzs7OztNQUFHLE9BQU8sRUFBRSwwQkFBMEI7Z0JBQzlHLE1BQU0sZUFBZSxTQUNwQix3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFDWCxLQUFLLGVBQWUsS0FBSyxhQUN4Qix3QkFBQyxNQUFEO1FBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVcsNENBQTRDLFNBQVM7bUJBQVEsd0JBQUMsZUFBRDtVQUFlLGVBQVk7VUFBTyxNQUFNO1NBQUs7Ozs7O1FBQU87Ozs7O1FBQ2xJLHdCQUFDLFFBQUQsYUFBTSx3QkFBQyxLQUFELFlBQUksRUFBRSxxQkFBcUIsU0FBUyxLQUFLLEVBQUUsQ0FBQyxZQUFZLElBQUksU0FBUyxLQUFLLE1BQU0sQ0FBQyxHQUFHLEVBQUs7Ozs7a0JBQUMsd0JBQUMsU0FBRCxZQUFRLFNBQVMsVUFBaUI7Ozs7Z0JBQU87Ozs7O1FBQ3pJLHdCQUFDLFFBQUQ7U0FBTSxVQUFVLFNBQVM7bUJBQVksVUFBVSxTQUFTLFNBQVM7UUFBUTs7Ozs7T0FDdkUsS0FKSyxTQUFTOzs7O2NBSWQsQ0FDTDtNQUNDOzs7O2lCQUNGLHdCQUFDLFlBQUQ7T0FBWSxhQUFhLEVBQUUsc0JBQXNCO09BQUcsT0FBTyxFQUFFLDBCQUEwQjtNQUFJOzs7OztLQUNqRjs7Ozs7SUFDYjs7Ozs7O0VBQ0Y7Ozs7OztBQUVUOztBQUVBLFNBQVMsZUFBZTtDQUN0QixPQUFPLHdCQUFDLFVBQUQ7RUFBVSxlQUFZO0VBQU8sTUFBTTtDQUFLOzs7OztBQUNqRDs7QUFFQSxPQUFPLFNBQVMsZ0JBQWdCOztDQUM5QixNQUFNLEVBQUUsTUFBTSxXQUFXLFNBQVMsWUFBWSxhQUFhO0NBQzNELE1BQU0sRUFBRSxTQUFTLFFBQVE7Q0FDekIsT0FBTyx3QkFBQyxlQUFEO0VBQXFCO0VBQU0sUUFBUTtFQUFTLFNBQVM7RUFBVyxlQUFlLEtBQUssUUFBUTtFQUFHLE1BQU0sUUFBUTtDQUFVOzs7OztBQUNoSSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJEYXNoYm9hcmRQYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBY3Rpdml0eSwgQWxlcnRUcmlhbmdsZSwgQXJyb3dVcFJpZ2h0LCBDYXJGcm9udCwgQ2xpcGJvYXJkQ2hlY2ssIENsb2NrMyB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcclxuaW1wb3J0IHsgQ2VsbCwgUGllLCBQaWVDaGFydCwgUmVzcG9uc2l2ZUNvbnRhaW5lciwgVG9vbHRpcCB9IGZyb20gJ3JlY2hhcnRzJ1xyXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcclxuaW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHR5cGUgeyBCb29raW5nLCBEYXNoYm9hcmRDYXJkS2V5LCBEYXNoYm9hcmREYXRhLCBVc2VyUm9sZSB9IGZyb20gJy4uLy4uL2FwaS90eXBlcydcclxuaW1wb3J0IHsgdXNlRGFzaGJvYXJkIH0gZnJvbSAnLi4vLi4vYXBpL3F1ZXJpZXMnXHJcbmltcG9ydCB7IERhdGFUYWJsZSwgRW1wdHlTdGF0ZSB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvdWknXHJcbmltcG9ydCB7IHQgfSBmcm9tICcuLi8uLi9pMThuJ1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vaG9va3MvQXV0aENvbnRleHQnXHJcbmltcG9ydCB7IGZvcm1hdEVhdCwgZm9ybWF0S2VzIH0gZnJvbSAnLi4vLi4vbGliJ1xyXG5pbXBvcnQgeyB2ZWhpY2xlcyB9IGZyb20gJy4uLy4uL21vY2tzL2ZpeHR1cmVzJ1xyXG5pbXBvcnQgeyBEYXNoYm9hcmRLcGlDYXJkIH0gZnJvbSAnLi9EYXNoYm9hcmRLcGlDYXJkJ1xyXG5cclxuY29uc3QgbWV0cmljTGFiZWxzOiBSZWNvcmQ8RGFzaGJvYXJkQ2FyZEtleSwgc3RyaW5nPiA9IHtcclxuICB2ZWhpY2xlc091dFRvZGF5OiAnZGFzaGJvYXJkLnZlaGljbGVzT3V0JyxcclxuICBwaWNrdXBzRHVlVG9kYXk6ICdkYXNoYm9hcmQucGlja3Vwc0R1ZScsXHJcbiAgcmV0dXJuc0R1ZVRvZGF5OiAnZGFzaGJvYXJkLnJldHVybnNEdWUnLFxyXG4gIG92ZXJkdWVWZWhpY2xlczogJ2Rhc2hib2FyZC5vdmVyZHVlJyxcclxuICBwZW5kaW5nQXBwcm92YWxzOiAnZGFzaGJvYXJkLnBlbmRpbmdBcHByb3ZhbHMnLFxyXG4gIGFjdGl2ZUJyZWFrZG93bnM6ICdkYXNoYm9hcmQuYWN0aXZlQnJlYWtkb3ducycsXHJcbiAgbW9udGhseVJldmVudWU6ICdkYXNoYm9hcmQubW9udGhseVJldmVudWUnLFxyXG59XHJcblxyXG5jb25zdCBmbGVldENvbG9ycyA9IHtcclxuICBhdmFpbGFibGU6ICcjMGY3NjZlJyxcclxuICByZW50ZWQ6ICcjZjk3MzE2JyxcclxuICByZXNlcnZlZDogJyMyNTYzZWInLFxyXG4gIG1haW50ZW5hbmNlOiAnI2I5MWMxYycsXHJcbn1cclxuXHJcbmNvbnN0IHZlaGljbGVCeUlkID0gbmV3IE1hcCh2ZWhpY2xlcy5tYXAoKHZlaGljbGUpID0+IFt2ZWhpY2xlLmlkLCB2ZWhpY2xlXSkpXHJcblxyXG5mdW5jdGlvbiBCb29raW5nVGFibGUoeyByb3dzLCB0eXBlIH06IHsgcm93czogQm9va2luZ1tdOyB0eXBlOiAncGlja3VwJyB8ICdyZXR1cm4nIH0pIHtcclxuICBjb25zdCBpc1BpY2t1cCA9IHR5cGUgPT09ICdwaWNrdXAnXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiAndGltZScsIGhlYWRlcjogdCgnZGFzaGJvYXJkLnRpbWUnKSwgcmVuZGVyOiAoYm9va2luZzogQm9va2luZykgPT4gZm9ybWF0RWF0KGlzUGlja3VwID8gYm9va2luZy5waWNrdXBBdCA6IGJvb2tpbmcucmV0dXJuQXQpLnNwbGl0KCcsICcpWzFdIH0sXHJcbiAgICB7IGtleTogJ2N1c3RvbWVyJywgaGVhZGVyOiB0KCdkYXNoYm9hcmQuY3VzdG9tZXInKSwgcmVuZGVyOiAoYm9va2luZzogQm9va2luZykgPT4gYm9va2luZy5jdXN0b21lck5hbWUgPz8gJ+KAlCcgfSxcclxuICAgIHsga2V5OiAndmVoaWNsZScsIGhlYWRlcjogdCgnZGFzaGJvYXJkLnZlaGljbGUnKSwgcmVuZGVyOiAoYm9va2luZzogQm9va2luZykgPT4ge1xyXG4gICAgICBjb25zdCB2ZWhpY2xlID0gdmVoaWNsZUJ5SWQuZ2V0KGJvb2tpbmcudmVoaWNsZUlkKVxyXG4gICAgICByZXR1cm4gdmVoaWNsZSA/IGAke3ZlaGljbGUubWFrZX0gJHt2ZWhpY2xlLm1vZGVsfWAgOiAn4oCUJ1xyXG4gICAgfSB9LFxyXG4gICAgeyBrZXk6ICdhY3Rpb24nLCBoZWFkZXI6ICcnLCByZW5kZXI6IChib29raW5nOiBCb29raW5nKSA9PiAoXHJcbiAgICAgIDxMaW5rIGNsYXNzTmFtZT1cImJ1dHRvbiBidXR0b24tLXNlY29uZGFyeSBidXR0b24tLXNtXCIgdG89e2AvYWRtaW4vYm9va2luZ3MvJHtib29raW5nLmlkfS8ke2lzUGlja3VwID8gJ2NoZWNrLW91dCcgOiAnY2hlY2staW4nfWB9PlxyXG4gICAgICAgIHt0KGlzUGlja3VwID8gJ2Rhc2hib2FyZC5jaGVja091dCcgOiAnZGFzaGJvYXJkLmNoZWNrSW4nKX1cclxuICAgICAgPC9MaW5rPlxyXG4gICAgKSB9LFxyXG4gIF1cclxuICBjb25zdCBlbXB0eSA9IChcclxuICAgIDxFbXB0eVN0YXRlXHJcbiAgICAgIGFjdGlvbj17PExpbmsgY2xhc3NOYW1lPVwidGV4dC1idXR0b25cIiB0bz1cIi9hZG1pbi9ib29raW5nc1wiPnt0KCdkYXNoYm9hcmQudmlld0Jvb2tpbmdzJyl9PC9MaW5rPn1cclxuICAgICAgZGVzY3JpcHRpb249e3QoaXNQaWNrdXAgPyAnZGFzaGJvYXJkLm5vUGlja3VwcycgOiAnZGFzaGJvYXJkLm5vUmV0dXJucycpfVxyXG4gICAgICB0aXRsZT17dChpc1BpY2t1cCA/ICdkYXNoYm9hcmQubm9QaWNrdXBzJyA6ICdkYXNoYm9hcmQubm9SZXR1cm5zJyl9XHJcbiAgICAvPlxyXG4gIClcclxuICByZXR1cm4gPERhdGFUYWJsZSBjb2x1bW5zPXtjb2x1bW5zfSBlbXB0eT17ZW1wdHl9IHJvd0tleT17KGJvb2tpbmcpID0+IGJvb2tpbmcuaWR9IHJvd3M9e3Jvd3N9IC8+XHJcbn1cclxuXHJcbmZ1bmN0aW9uIEZsZWV0U3RhdHVzKHsgZGF0YSB9OiB7IGRhdGE6IERhc2hib2FyZERhdGFbJ2ZsZWV0U3RhdHVzJ10gfSkge1xyXG4gIGNvbnN0IGNoYXJ0RGF0YSA9IE9iamVjdC5lbnRyaWVzKGRhdGEpLm1hcCgoW25hbWUsIHZhbHVlXSkgPT4gKHsgbmFtZTogdChgZGFzaGJvYXJkLiR7bmFtZX1gKSwgdmFsdWUsIGNvbG9yOiBmbGVldENvbG9yc1tuYW1lIGFzIGtleW9mIHR5cGVvZiBmbGVldENvbG9yc10gfSkpXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxlZXQtc3RhdHVzXCI+XHJcbiAgICAgIDxkaXYgYXJpYS1sYWJlbD17dCgnZGFzaGJvYXJkLmZsZWV0U3RhdHVzJyl9IGNsYXNzTmFtZT1cImZsZWV0LXN0YXR1c19fY2hhcnRcIiByb2xlPVwiaW1nXCI+XHJcbiAgICAgICAgPFJlc3BvbnNpdmVDb250YWluZXIgaGVpZ2h0PVwiMTAwJVwiIHdpZHRoPVwiMTAwJVwiPlxyXG4gICAgICAgICAgPFBpZUNoYXJ0PlxyXG4gICAgICAgICAgICA8UGllIGRhdGE9e2NoYXJ0RGF0YX0gZGF0YUtleT1cInZhbHVlXCIgaW5uZXJSYWRpdXM9XCI2MiVcIiBpc0FuaW1hdGlvbkFjdGl2ZT17ZmFsc2V9IG91dGVyUmFkaXVzPVwiODglXCIgc3Ryb2tlPVwibm9uZVwiPlxyXG4gICAgICAgICAgICAgIHtjaGFydERhdGEubWFwKChpdGVtKSA9PiA8Q2VsbCBmaWxsPXtpdGVtLmNvbG9yfSBrZXk9e2l0ZW0ubmFtZX0gLz4pfVxyXG4gICAgICAgICAgICA8L1BpZT5cclxuICAgICAgICAgICAgPFRvb2x0aXAgZm9ybWF0dGVyPXsodmFsdWUpID0+IFt2YWx1ZSwgdCgnZGFzaGJvYXJkLnZlaGljbGVDb3VudCcpXX0gLz5cclxuICAgICAgICAgIDwvUGllQ2hhcnQ+XHJcbiAgICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPHVsIGNsYXNzTmFtZT1cImZsZWV0LXN0YXR1c19fbGVnZW5kXCI+XHJcbiAgICAgICAge2NoYXJ0RGF0YS5tYXAoKGl0ZW0pID0+IDxsaSBrZXk9e2l0ZW0ubmFtZX0+PHNwYW4gc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBpdGVtLmNvbG9yIH19IC8+e2l0ZW0ubmFtZX08Yj57aXRlbS52YWx1ZX08L2I+PC9saT4pfVxyXG4gICAgICA8L3VsPlxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcblxyXG5mdW5jdGlvbiBEYXNoYm9hcmRQYW5lbCh7IHRpdGxlLCBpY29uLCBjaGlsZHJlbiwgaHJlZiB9OiB7IHRpdGxlOiBzdHJpbmc7IGljb246IFJlYWN0Tm9kZTsgY2hpbGRyZW46IFJlYWN0Tm9kZTsgaHJlZj86IHN0cmluZyB9KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImRhc2hib2FyZC1wYW5lbFwiPlxyXG4gICAgICA8aGVhZGVyPjxzcGFuIGNsYXNzTmFtZT1cImRhc2hib2FyZC1wYW5lbF9fdGl0bGVcIj57aWNvbn17dGl0bGV9PC9zcGFuPntocmVmICYmIDxMaW5rIGFyaWEtbGFiZWw9e2Ake3QoJ2Rhc2hib2FyZC52aWV3Qm9va2luZ3MnKX06ICR7dGl0bGV9YH0gdG89e2hyZWZ9PjxBcnJvd1VwUmlnaHQgc2l6ZT17MTd9IC8+PC9MaW5rPn08L2hlYWRlcj5cclxuICAgICAge2NoaWxkcmVufVxyXG4gICAgPC9zZWN0aW9uPlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIERhc2hib2FyZFZpZXcoe1xyXG4gIGRhdGEsXHJcbiAgcm9sZSxcclxuICBsb2FkaW5nLFxyXG4gIGZhaWxlZCxcclxuICBvblJldHJ5LFxyXG59OiB7XHJcbiAgZGF0YT86IERhc2hib2FyZERhdGFcclxuICByb2xlOiBVc2VyUm9sZVxyXG4gIGxvYWRpbmc6IGJvb2xlYW5cclxuICBmYWlsZWQ6IGJvb2xlYW5cclxuICBvblJldHJ5OiAoKSA9PiB2b2lkXHJcbn0pIHtcclxuICBjb25zdCBrZXlzOiBEYXNoYm9hcmRDYXJkS2V5W10gPSBbXHJcbiAgICAndmVoaWNsZXNPdXRUb2RheScsICdwaWNrdXBzRHVlVG9kYXknLCAncmV0dXJuc0R1ZVRvZGF5JywgJ292ZXJkdWVWZWhpY2xlcycsXHJcbiAgICAncGVuZGluZ0FwcHJvdmFscycsICdhY3RpdmVCcmVha2Rvd25zJywgJ21vbnRobHlSZXZlbnVlJyxcclxuICBdXHJcbiAgY29uc3QgdmlzaWJsZUtleXMgPSByb2xlID09PSAnb3duZXInIHx8IHJvbGUgPT09ICdtYW5hZ2VyJyA/IGtleXMgOiBrZXlzLmZpbHRlcigoa2V5KSA9PiBrZXkgIT09ICdtb250aGx5UmV2ZW51ZScpXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImRhc2hib2FyZC1wYWdlXCI+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cImRhc2hib2FyZC1zdWJ0aXRsZVwiPnt0KCdkYXNoYm9hcmQuc3VidGl0bGUnKX08L3A+XHJcbiAgICAgIDxzZWN0aW9uIGFyaWEtbGFiZWw9e3QoJ2Rhc2hib2FyZC50aXRsZScpfSBjbGFzc05hbWU9XCJkYXNoYm9hcmQta3BpLWdyaWRcIj5cclxuICAgICAgICB7dmlzaWJsZUtleXMubWFwKChrZXkpID0+IHtcclxuICAgICAgICAgIGNvbnN0IHZhbHVlID0gZGF0YT8ubWV0cmljc1trZXldXHJcbiAgICAgICAgICBjb25zdCBlcnJvciA9IGRhdGE/LmNhcmRFcnJvcnM/LltrZXldID8/IChmYWlsZWQgJiYgIWRhdGEgPyB0KCdkYXNoYm9hcmQubWV0cmljRXJyb3InKSA6IHVuZGVmaW5lZClcclxuICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIDxEYXNoYm9hcmRLcGlDYXJkXHJcbiAgICAgICAgICAgICAgZGFuZ2VyPXtrZXkgPT09ICdvdmVyZHVlVmVoaWNsZXMnfVxyXG4gICAgICAgICAgICAgIGVycm9yPXtlcnJvcn1cclxuICAgICAgICAgICAgICBrZXk9e2tleX1cclxuICAgICAgICAgICAgICBsb2FkaW5nPXtsb2FkaW5nICYmICFkYXRhfVxyXG4gICAgICAgICAgICAgIG1ldHJpY0tleT17a2V5fVxyXG4gICAgICAgICAgICAgIG9uUmV0cnk9e29uUmV0cnl9XHJcbiAgICAgICAgICAgICAgdGl0bGU9e3QobWV0cmljTGFiZWxzW2tleV0pfVxyXG4gICAgICAgICAgICAgIHZhbHVlPXtrZXkgPT09ICdtb250aGx5UmV2ZW51ZScgPyBmb3JtYXRLZXModmFsdWUgPz8gMCkgOiBTdHJpbmcodmFsdWUgPz8gMCl9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICApXHJcbiAgICAgICAgfSl9XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGFzaGJvYXJkLXBhbmVsLWdyaWRcIj5cclxuICAgICAgICA8RGFzaGJvYXJkUGFuZWwgaHJlZj1cIi9hZG1pbi9ib29raW5ncz9waWNrdXA9ZHVlLXRvZGF5XCIgaWNvbj17PENsb2NrMyBzaXplPXsxOH0gLz59IHRpdGxlPXt0KCdkYXNoYm9hcmQudG9kYXlQaWNrdXBzJyl9PlxyXG4gICAgICAgICAgPEJvb2tpbmdUYWJsZSByb3dzPXtkYXRhPy5waWNrdXBzID8/IFtdfSB0eXBlPVwicGlja3VwXCIgLz5cclxuICAgICAgICA8L0Rhc2hib2FyZFBhbmVsPlxyXG4gICAgICAgIDxEYXNoYm9hcmRQYW5lbCBocmVmPVwiL2FkbWluL2Jvb2tpbmdzP3JldHVybj1kdWUtdG9kYXlcIiBpY29uPXs8Q2xpcGJvYXJkQ2hlY2sgc2l6ZT17MTh9IC8+fSB0aXRsZT17dCgnZGFzaGJvYXJkLnRvZGF5UmV0dXJucycpfT5cclxuICAgICAgICAgIDxCb29raW5nVGFibGUgcm93cz17ZGF0YT8ucmV0dXJucyA/PyBbXX0gdHlwZT1cInJldHVyblwiIC8+XHJcbiAgICAgICAgPC9EYXNoYm9hcmRQYW5lbD5cclxuICAgICAgICA8RGFzaGJvYXJkUGFuZWwgaWNvbj17PENhckZyb250IHNpemU9ezE4fSAvPn0gdGl0bGU9e3QoJ2Rhc2hib2FyZC5mbGVldFN0YXR1cycpfT5cclxuICAgICAgICAgIHtkYXRhID8gPEZsZWV0U3RhdHVzIGRhdGE9e2RhdGEuZmxlZXRTdGF0dXN9IC8+IDogPGRpdiBjbGFzc05hbWU9XCJkYXNoYm9hcmQtcGFuZWxfX3NrZWxldG9uXCIgLz59XHJcbiAgICAgICAgPC9EYXNoYm9hcmRQYW5lbD5cclxuICAgICAgICA8RGFzaGJvYXJkUGFuZWwgaHJlZj1cIi9hZG1pbi9ib29raW5ncz9zb3J0PXVwZGF0ZWRBdFwiIGljb249ezxBY3Rpdml0eUljb24gLz59IHRpdGxlPXt0KCdkYXNoYm9hcmQucmVjZW50QWN0aXZpdHknKX0+XHJcbiAgICAgICAgICB7ZGF0YT8ucmVjZW50QWN0aXZpdHkubGVuZ3RoID8gKFxyXG4gICAgICAgICAgICA8b2wgY2xhc3NOYW1lPVwiYWN0aXZpdHktZmVlZFwiPlxyXG4gICAgICAgICAgICAgIHtkYXRhLnJlY2VudEFjdGl2aXR5Lm1hcCgoYWN0aXZpdHkpID0+IChcclxuICAgICAgICAgICAgICAgIDxsaSBrZXk9e2FjdGl2aXR5LmlkfT5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgYWN0aXZpdHktZmVlZF9faWNvbiBhY3Rpdml0eS1mZWVkX19pY29uLS0ke2FjdGl2aXR5LmtpbmR9YH0+PEFsZXJ0VHJpYW5nbGUgYXJpYS1oaWRkZW49XCJ0cnVlXCIgc2l6ZT17MTV9IC8+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3Bhbj48Yj57dChgZGFzaGJvYXJkLmFjdGl2aXR5JHthY3Rpdml0eS5raW5kWzBdLnRvVXBwZXJDYXNlKCl9JHthY3Rpdml0eS5raW5kLnNsaWNlKDEpfWApfTwvYj48c21hbGw+e2FjdGl2aXR5LnJlZmVyZW5jZX08L3NtYWxsPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHRpbWUgZGF0ZVRpbWU9e2FjdGl2aXR5LnRpbWVzdGFtcH0+e2Zvcm1hdEVhdChhY3Rpdml0eS50aW1lc3RhbXApfTwvdGltZT5cclxuICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvb2w+XHJcbiAgICAgICAgICApIDogPEVtcHR5U3RhdGUgZGVzY3JpcHRpb249e3QoJ2Rhc2hib2FyZC5ub0FjdGl2aXR5Jyl9IHRpdGxlPXt0KCdkYXNoYm9hcmQucmVjZW50QWN0aXZpdHknKX0gLz59XHJcbiAgICAgICAgPC9EYXNoYm9hcmRQYW5lbD5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbmZ1bmN0aW9uIEFjdGl2aXR5SWNvbigpIHtcclxuICByZXR1cm4gPEFjdGl2aXR5IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHNpemU9ezE4fSAvPlxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gRGFzaGJvYXJkUGFnZSgpIHtcclxuICBjb25zdCB7IGRhdGEsIGlzTG9hZGluZywgaXNFcnJvciwgcmVmZXRjaCB9ID0gdXNlRGFzaGJvYXJkKClcclxuICBjb25zdCB7IHJvbGUgfSA9IHVzZUF1dGgoKVxyXG4gIHJldHVybiA8RGFzaGJvYXJkVmlldyBkYXRhPXtkYXRhfSBmYWlsZWQ9e2lzRXJyb3J9IGxvYWRpbmc9e2lzTG9hZGluZ30gb25SZXRyeT17KCkgPT4gdm9pZCByZWZldGNoKCl9IHJvbGU9e3JvbGUgPz8gJ2FnZW50J30gLz5cclxufSJdfQ==
import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/dashboard/DashboardKpiCard.tsx");const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=d6f2c477";
import { Badge, ErrorState, KpiCard, Skeleton } from "/src/components/ui/index.ts";
import { t } from "/src/i18n/index.ts";
import { DASHBOARD_KPI_ROUTES } from "/src/features/dashboard/dashboardConfig.ts";
var _jsxFileName = "C:/CarHire/Frontend/src/features/dashboard/DashboardKpiCard.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d6f2c477";
export function DashboardKpiCard({ metricKey, title, value, loading = false, error, danger = false, onRetry }) {
	if (loading) {
		return /* @__PURE__ */ _jsxDEV("article", {
			"aria-label": title,
			className: "dashboard-kpi dashboard-kpi--loading",
			children: [/* @__PURE__ */ _jsxDEV("p", { children: title }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 89
			}, this), /* @__PURE__ */ _jsxDEV(Skeleton, { rows: 2 }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 103
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 12
		}, this);
	}
	if (error) {
		return /* @__PURE__ */ _jsxDEV("article", {
			className: "dashboard-kpi dashboard-kpi--error",
			children: [/* @__PURE__ */ _jsxDEV("p", { children: title }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV(ErrorState, {
				onRetry,
				retryLabel: t("styleguide.retry"),
				title: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 30,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV(Link, {
		"aria-label": `${title}, ${value}`,
		className: `dashboard-kpi-link${danger ? " dashboard-kpi-link--danger" : ""}`,
		to: DASHBOARD_KPI_ROUTES[metricKey],
		children: [/* @__PURE__ */ _jsxDEV(KpiCard, {
			label: title,
			value
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 7
		}, this), danger && /* @__PURE__ */ _jsxDEV(Badge, {
			tone: "danger",
			children: t("dashboard.overdueLabel")
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 40,
			columnNumber: 18
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 38,
		columnNumber: 5
	}, this);
}
_c = DashboardKpiCard;
var _c;
$RefreshReg$(_c, "DashboardKpiCard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/dashboard/DashboardKpiCard.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/CarHire/Frontend/src/features/dashboard/DashboardKpiCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/CarHire/Frontend/src/features/dashboard/DashboardKpiCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/CarHire/Frontend/src/features/dashboard/DashboardKpiCard.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBRXJCLFNBQVMsT0FBTyxZQUFZLFNBQVMsZ0JBQWdCO0FBQ3JELFNBQVMsU0FBUztBQUNsQixTQUFTLDRCQUE0Qjs7O0FBRXJDLE9BQU8sU0FBUyxpQkFBaUIsRUFDL0IsV0FDQSxPQUNBLE9BQ0EsVUFBVSxPQUNWLE9BQ0EsU0FBUyxPQUNULFdBU0M7Q0FDRCxJQUFJLFNBQVM7RUFDWCxPQUFPLHdCQUFDLFdBQUQ7R0FBUyxjQUFZO0dBQU8sV0FBVTthQUF0QyxDQUE2RSx3QkFBQyxLQUFELFlBQUksTUFBUzs7OzthQUFDLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEVBQUk7Ozs7V0FBVTs7Ozs7O0NBQ2xJO0NBRUEsSUFBSSxPQUFPO0VBQ1QsT0FDRSx3QkFBQyxXQUFEO0dBQVMsV0FBVTthQUFuQixDQUNFLHdCQUFDLEtBQUQsWUFBSSxNQUFTOzs7O2FBQ2Isd0JBQUMsWUFBRDtJQUFxQjtJQUFTLFlBQVksRUFBRSxrQkFBa0I7SUFBRyxPQUFPO0dBQVE7Ozs7V0FDekU7Ozs7OztDQUViO0NBRUEsT0FDRSx3QkFBQyxNQUFEO0VBQU0sY0FBWSxHQUFHLE1BQU0sSUFBSTtFQUFTLFdBQVcscUJBQXFCLFNBQVMsZ0NBQWdDO0VBQU0sSUFBSSxxQkFBcUI7WUFBaEosQ0FDRSx3QkFBQyxTQUFEO0dBQVMsT0FBTztHQUFjO0VBQVE7Ozs7WUFDckMsVUFBVSx3QkFBQyxPQUFEO0dBQU8sTUFBSzthQUFVLEVBQUUsd0JBQXdCO0VBQVM7Ozs7VUFDaEU7Ozs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkRhc2hib2FyZEtwaUNhcmQudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xyXG5pbXBvcnQgdHlwZSB7IERhc2hib2FyZENhcmRLZXkgfSBmcm9tICcuLi8uLi9hcGkvdHlwZXMnXHJcbmltcG9ydCB7IEJhZGdlLCBFcnJvclN0YXRlLCBLcGlDYXJkLCBTa2VsZXRvbiB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvdWknXHJcbmltcG9ydCB7IHQgfSBmcm9tICcuLi8uLi9pMThuJ1xyXG5pbXBvcnQgeyBEQVNIQk9BUkRfS1BJX1JPVVRFUyB9IGZyb20gJy4vZGFzaGJvYXJkQ29uZmlnJ1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIERhc2hib2FyZEtwaUNhcmQoe1xyXG4gIG1ldHJpY0tleSxcclxuICB0aXRsZSxcclxuICB2YWx1ZSxcclxuICBsb2FkaW5nID0gZmFsc2UsXHJcbiAgZXJyb3IsXHJcbiAgZGFuZ2VyID0gZmFsc2UsXHJcbiAgb25SZXRyeSxcclxufToge1xyXG4gIG1ldHJpY0tleTogRGFzaGJvYXJkQ2FyZEtleVxyXG4gIHRpdGxlOiBzdHJpbmdcclxuICB2YWx1ZTogc3RyaW5nXHJcbiAgbG9hZGluZz86IGJvb2xlYW5cclxuICBlcnJvcj86IHN0cmluZ1xyXG4gIGRhbmdlcj86IGJvb2xlYW5cclxuICBvblJldHJ5OiAoKSA9PiB2b2lkXHJcbn0pIHtcclxuICBpZiAobG9hZGluZykge1xyXG4gICAgcmV0dXJuIDxhcnRpY2xlIGFyaWEtbGFiZWw9e3RpdGxlfSBjbGFzc05hbWU9XCJkYXNoYm9hcmQta3BpIGRhc2hib2FyZC1rcGktLWxvYWRpbmdcIj48cD57dGl0bGV9PC9wPjxTa2VsZXRvbiByb3dzPXsyfSAvPjwvYXJ0aWNsZT5cclxuICB9XHJcblxyXG4gIGlmIChlcnJvcikge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGFydGljbGUgY2xhc3NOYW1lPVwiZGFzaGJvYXJkLWtwaSBkYXNoYm9hcmQta3BpLS1lcnJvclwiPlxyXG4gICAgICAgIDxwPnt0aXRsZX08L3A+XHJcbiAgICAgICAgPEVycm9yU3RhdGUgb25SZXRyeT17b25SZXRyeX0gcmV0cnlMYWJlbD17dCgnc3R5bGVndWlkZS5yZXRyeScpfSB0aXRsZT17ZXJyb3J9IC8+XHJcbiAgICAgIDwvYXJ0aWNsZT5cclxuICAgIClcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8TGluayBhcmlhLWxhYmVsPXtgJHt0aXRsZX0sICR7dmFsdWV9YH0gY2xhc3NOYW1lPXtgZGFzaGJvYXJkLWtwaS1saW5rJHtkYW5nZXIgPyAnIGRhc2hib2FyZC1rcGktbGluay0tZGFuZ2VyJyA6ICcnfWB9IHRvPXtEQVNIQk9BUkRfS1BJX1JPVVRFU1ttZXRyaWNLZXldfT5cclxuICAgICAgPEtwaUNhcmQgbGFiZWw9e3RpdGxlfSB2YWx1ZT17dmFsdWV9IC8+XHJcbiAgICAgIHtkYW5nZXIgJiYgPEJhZGdlIHRvbmU9XCJkYW5nZXJcIj57dCgnZGFzaGJvYXJkLm92ZXJkdWVMYWJlbCcpfTwvQmFkZ2U+fVxyXG4gICAgPC9MaW5rPlxyXG4gIClcclxufSJdfQ==
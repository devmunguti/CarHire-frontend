import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/dashboard/DashboardPage.tsx");const _jsxDEV = __vite__cjsImport10_react_jsxDevRuntime["jsxDEV"];import { Activity, AlertTriangle, ArrowUpRight, CarFront, ClipboardCheck, Clock3 } from "/node_modules/.vite/deps/lucide-react.js?v=8b23c0c4";
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "/node_modules/.vite/deps/recharts.js?v=8b23c0c4";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=8b23c0c4";
import { useDashboard } from "/src/api/queries.ts";
import { DataTable, EmptyState } from "/src/components/ui/index.ts";
import { t } from "/src/i18n/index.ts";
import { useAuth } from "/src/hooks/AuthContext.tsx";
import { formatEat, formatKes } from "/src/lib/index.ts";
import { vehicles } from "/src/mocks/fixtures.ts";
import { DashboardKpiCard } from "/src/features/dashboard/DashboardKpiCard.tsx";
var _jsxFileName = "C:/CarHire/Frontend/src/features/dashboard/DashboardPage.tsx";
import __vite__cjsImport10_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b23c0c4";
var _s = $RefreshSig$();
const metricLabels = {
	vehiclesOutToday: "dashboard.vehiclesOut",
	pickupsDueToday: "dashboard.pickupsDue",
	returnsDueToday: "dashboard.returnsDue",
	overdueVehicles: "dashboard.overdue",
	pendingApprovals: "dashboard.pendingApprovals",
	activeBreakdowns: "dashboard.activeBreakdowns",
	monthlyRevenue: "dashboard.monthlyRevenue"
};
const fleetColors = {
	available: "#0f766e",
	rented: "#f97316",
	reserved: "#2563eb",
	maintenance: "#b91c1c"
};
const vehicleById = new Map(vehicles.map((vehicle) => [vehicle.id, vehicle]));
function BookingTable({ rows, type }) {
	const isPickup = type === "pickup";
	const columns = [
		{
			key: "time",
			header: t("dashboard.time"),
			render: (booking) => formatEat(isPickup ? booking.pickupAt : booking.returnAt).split(", ")[1]
		},
		{
			key: "customer",
			header: t("dashboard.customer"),
			render: (booking) => booking.customerName ?? "—"
		},
		{
			key: "vehicle",
			header: t("dashboard.vehicle"),
			render: (booking) => {
				const vehicle = vehicleById.get(booking.vehicleId);
				return vehicle ? `${vehicle.make} ${vehicle.model}` : "—";
			}
		},
		{
			key: "action",
			header: "",
			render: (booking) => /* @__PURE__ */ _jsxDEV(Link, {
				className: "button button--secondary button--sm",
				to: `/admin/bookings/${booking.id}/${isPickup ? "check-out" : "check-in"}`,
				children: t(isPickup ? "dashboard.checkOut" : "dashboard.checkIn")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 7
			}, this)
		}
	];
	const empty = /* @__PURE__ */ _jsxDEV(EmptyState, {
		action: /* @__PURE__ */ _jsxDEV(Link, {
			className: "text-button",
			to: "/admin/bookings",
			children: t("dashboard.viewBookings")
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 50,
			columnNumber: 15
		}, this),
		description: t(isPickup ? "dashboard.noPickups" : "dashboard.noReturns"),
		title: t(isPickup ? "dashboard.noPickups" : "dashboard.noReturns")
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 49,
		columnNumber: 5
	}, this);
	return /* @__PURE__ */ _jsxDEV(DataTable, {
		columns,
		empty,
		rowKey: (booking) => booking.id,
		rows
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 55,
		columnNumber: 10
	}, this);
}
_c = BookingTable;
function FleetStatus({ data }) {
	const chartData = Object.entries(data).map(([name, value]) => ({
		name: t(`dashboard.${name}`),
		value,
		color: fleetColors[name]
	}));
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fleet-status",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			"aria-label": t("dashboard.fleetStatus"),
			className: "fleet-status__chart",
			role: "img",
			children: /* @__PURE__ */ _jsxDEV(ResponsiveContainer, {
				height: "100%",
				width: "100%",
				children: /* @__PURE__ */ _jsxDEV(PieChart, { children: [/* @__PURE__ */ _jsxDEV(Pie, {
					data: chartData,
					dataKey: "value",
					innerRadius: "62%",
					isAnimationActive: false,
					outerRadius: "88%",
					stroke: "none",
					children: chartData.map((item) => /* @__PURE__ */ _jsxDEV(Cell, { fill: item.color }, item.name, false, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 40
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV(Tooltip, { formatter: (value) => [value, t("dashboard.vehicleCount")] }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 68,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 63,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 62,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("ul", {
			className: "fleet-status__legend",
			children: chartData.map((item) => /* @__PURE__ */ _jsxDEV("li", { children: [
				/* @__PURE__ */ _jsxDEV("span", { style: { backgroundColor: item.color } }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 54
				}, this),
				item.name,
				/* @__PURE__ */ _jsxDEV("b", { children: item.value }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 113
				}, this)
			] }, item.name, true, {
				fileName: _jsxFileName,
				lineNumber: 73,
				columnNumber: 34
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 72,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 61,
		columnNumber: 5
	}, this);
}
_c2 = FleetStatus;
function DashboardPanel({ title, icon, children, href }) {
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "dashboard-panel",
		children: [/* @__PURE__ */ _jsxDEV("header", { children: [/* @__PURE__ */ _jsxDEV("h2", {
			className: "dashboard-panel__title",
			children: [icon, title]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 82,
			columnNumber: 15
		}, this), href && /* @__PURE__ */ _jsxDEV(Link, {
			"aria-label": `${t("dashboard.viewBookings")}: ${title}`,
			to: href,
			children: /* @__PURE__ */ _jsxDEV(ArrowUpRight, { size: 17 }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 82,
				columnNumber: 153
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 82,
			columnNumber: 81
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 82,
			columnNumber: 7
		}, this), children]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 81,
		columnNumber: 5
	}, this);
}
_c3 = DashboardPanel;
export function DashboardView({ data, role, loading, failed, onRetry }) {
	const keys = [
		"vehiclesOutToday",
		"pickupsDueToday",
		"returnsDueToday",
		"overdueVehicles",
		"pendingApprovals",
		"activeBreakdowns",
		"monthlyRevenue"
	];
	const visibleKeys = role === "owner" || role === "manager" ? keys : keys.filter((key) => key !== "monthlyRevenue");
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "dashboard-page",
		children: [
			/* @__PURE__ */ _jsxDEV("p", {
				className: "dashboard-subtitle",
				children: t("dashboard.subtitle")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 109,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				"aria-label": t("dashboard.title"),
				className: "dashboard-kpi-grid",
				children: visibleKeys.map((key) => {
					const value = data?.metrics[key];
					const error = data?.cardErrors?.[key] ?? (failed && !data ? t("dashboard.metricError") : undefined);
					return /* @__PURE__ */ _jsxDEV(DashboardKpiCard, {
						danger: key === "overdueVehicles",
						error,
						loading: loading && !data,
						metricKey: key,
						onRetry,
						title: t(metricLabels[key]),
						value: key === "monthlyRevenue" ? formatKes(value ?? 0) : String(value ?? 0)
					}, key, false, {
						fileName: _jsxFileName,
						lineNumber: 115,
						columnNumber: 13
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 110,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "dashboard-panel-grid",
				children: [
					/* @__PURE__ */ _jsxDEV(DashboardPanel, {
						href: "/admin/bookings?pickup=due-today",
						icon: /* @__PURE__ */ _jsxDEV(Clock3, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 130,
							columnNumber: 71
						}, this),
						title: t("dashboard.todayPickups"),
						children: /* @__PURE__ */ _jsxDEV(BookingTable, {
							rows: data?.pickups ?? [],
							type: "pickup"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 131,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 130,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(DashboardPanel, {
						href: "/admin/bookings?return=due-today",
						icon: /* @__PURE__ */ _jsxDEV(ClipboardCheck, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 133,
							columnNumber: 71
						}, this),
						title: t("dashboard.todayReturns"),
						children: /* @__PURE__ */ _jsxDEV(BookingTable, {
							rows: data?.returns ?? [],
							type: "return"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 134,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 133,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(DashboardPanel, {
						icon: /* @__PURE__ */ _jsxDEV(CarFront, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 136,
							columnNumber: 31
						}, this),
						title: t("dashboard.fleetStatus"),
						children: data ? /* @__PURE__ */ _jsxDEV(FleetStatus, { data: data.fleetStatus }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 137,
							columnNumber: 19
						}, this) : /* @__PURE__ */ _jsxDEV("div", { className: "dashboard-panel__skeleton" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 137,
							columnNumber: 61
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(DashboardPanel, {
						href: "/admin/bookings?sort=updatedAt",
						icon: /* @__PURE__ */ _jsxDEV(ActivityIcon, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 139,
							columnNumber: 69
						}, this),
						title: t("dashboard.recentActivity"),
						children: data?.recentActivity.length ? /* @__PURE__ */ _jsxDEV("ol", {
							className: "activity-feed",
							children: data.recentActivity.map((activity) => /* @__PURE__ */ _jsxDEV("li", { children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: `activity-feed__icon activity-feed__icon--${activity.kind}`,
									children: /* @__PURE__ */ _jsxDEV(AlertTriangle, {
										"aria-hidden": "true",
										size: 15
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 144,
										columnNumber: 97
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 144,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("b", { children: t(`dashboard.activity${activity.kind[0].toUpperCase()}${activity.kind.slice(1)}`) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 145,
									columnNumber: 25
								}, this), /* @__PURE__ */ _jsxDEV("small", { children: activity.reference }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 145,
									columnNumber: 115
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 145,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("time", {
									dateTime: activity.timestamp,
									children: formatEat(activity.timestamp)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 146,
									columnNumber: 19
								}, this)
							] }, activity.id, true, {
								fileName: _jsxFileName,
								lineNumber: 143,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 141,
							columnNumber: 13
						}, this) : /* @__PURE__ */ _jsxDEV(EmptyState, {
							description: t("dashboard.noActivity"),
							title: t("dashboard.recentActivity")
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 150,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 139,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 129,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 108,
		columnNumber: 5
	}, this);
}
_c4 = DashboardView;
function ActivityIcon() {
	return /* @__PURE__ */ _jsxDEV(Activity, {
		"aria-hidden": "true",
		size: 18
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 158,
		columnNumber: 10
	}, this);
}
_c5 = ActivityIcon;
export function DashboardPage() {
	_s();
	const { data, isLoading, isError, refetch } = useDashboard();
	const { role } = useAuth();
	return /* @__PURE__ */ _jsxDEV(DashboardView, {
		data,
		failed: isError,
		loading: isLoading,
		onRetry: () => void refetch(),
		role: role ?? "agent"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 164,
		columnNumber: 10
	}, this);
}
_s(DashboardPage, "pOmmYC0+YyUQPnBih4OZNatbfNY=", false, function() {
	return [useDashboard, useAuth];
});
_c6 = DashboardPage;
var _c, _c2, _c3, _c4, _c5, _c6;
$RefreshReg$(_c, "BookingTable");
$RefreshReg$(_c2, "FleetStatus");
$RefreshReg$(_c3, "DashboardPanel");
$RefreshReg$(_c4, "DashboardView");
$RefreshReg$(_c5, "ActivityIcon");
$RefreshReg$(_c6, "DashboardPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/dashboard/DashboardPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/CarHire/Frontend/src/features/dashboard/DashboardPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/CarHire/Frontend/src/features/dashboard/DashboardPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/CarHire/Frontend/src/features/dashboard/DashboardPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLGVBQWUsY0FBYyxVQUFVLGdCQUFnQixjQUFjO0FBQ3hGLFNBQVMsTUFBTSxLQUFLLFVBQVUscUJBQXFCLGVBQWU7QUFDbEUsU0FBUyxZQUFZO0FBR3JCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsV0FBVyxrQkFBa0I7QUFDdEMsU0FBUyxTQUFTO0FBQ2xCLFNBQVMsZUFBZTtBQUN4QixTQUFTLFdBQVcsaUJBQWlCO0FBQ3JDLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsd0JBQXdCOzs7O0FBRWpDLE1BQU0sZUFBaUQ7Q0FDckQsa0JBQWtCO0NBQ2xCLGlCQUFpQjtDQUNqQixpQkFBaUI7Q0FDakIsaUJBQWlCO0NBQ2pCLGtCQUFrQjtDQUNsQixrQkFBa0I7Q0FDbEIsZ0JBQWdCO0FBQ2xCO0FBRUEsTUFBTSxjQUFjO0NBQ2xCLFdBQVc7Q0FDWCxRQUFRO0NBQ1IsVUFBVTtDQUNWLGFBQWE7QUFDZjtBQUVBLE1BQU0sY0FBYyxJQUFJLElBQUksU0FBUyxLQUFLLFlBQVksQ0FBQyxRQUFRLElBQUksT0FBTyxDQUFDLENBQUM7QUFFNUUsU0FBUyxhQUFhLEVBQUUsTUFBTSxRQUF3RDtDQUNwRixNQUFNLFdBQVcsU0FBUztDQUMxQixNQUFNLFVBQVU7RUFDZDtHQUFFLEtBQUs7R0FBUSxRQUFRLEVBQUUsZ0JBQWdCO0dBQUcsU0FBUyxZQUFxQixVQUFVLFdBQVcsUUFBUSxXQUFXLFFBQVEsUUFBUSxDQUFDLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQztFQUFHO0VBQ25KO0dBQUUsS0FBSztHQUFZLFFBQVEsRUFBRSxvQkFBb0I7R0FBRyxTQUFTLFlBQXFCLFFBQVEsZ0JBQWdCO0VBQUk7RUFDOUc7R0FBRSxLQUFLO0dBQVcsUUFBUSxFQUFFLG1CQUFtQjtHQUFHLFNBQVMsWUFBcUI7SUFDOUUsTUFBTSxVQUFVLFlBQVksSUFBSSxRQUFRLFNBQVM7SUFDakQsT0FBTyxVQUFVLEdBQUcsUUFBUSxLQUFLLEdBQUcsUUFBUSxVQUFVO0dBQ3hEO0VBQUU7RUFDRjtHQUFFLEtBQUs7R0FBVSxRQUFRO0dBQUksU0FBUyxZQUNwQyx3QkFBQyxNQUFEO0lBQU0sV0FBVTtJQUFzQyxJQUFJLG1CQUFtQixRQUFRLEdBQUcsR0FBRyxXQUFXLGNBQWM7Y0FDakgsRUFBRSxXQUFXLHVCQUF1QixtQkFBbUI7R0FDcEQ7Ozs7O0VBQ047Q0FDSjtDQUNBLE1BQU0sUUFDSix3QkFBQyxZQUFEO0VBQ0UsUUFBUSx3QkFBQyxNQUFEO0dBQU0sV0FBVTtHQUFjLElBQUc7YUFBbUIsRUFBRSx3QkFBd0I7RUFBUTs7Ozs7RUFDOUYsYUFBYSxFQUFFLFdBQVcsd0JBQXdCLHFCQUFxQjtFQUN2RSxPQUFPLEVBQUUsV0FBVyx3QkFBd0IscUJBQXFCO0NBQ2xFOzs7OztDQUVILE9BQU8sd0JBQUMsV0FBRDtFQUFvQjtFQUFnQjtFQUFPLFNBQVMsWUFBWSxRQUFRO0VBQVU7Q0FBTzs7Ozs7QUFDbEc7O0FBRUEsU0FBUyxZQUFZLEVBQUUsUUFBZ0Q7Q0FDckUsTUFBTSxZQUFZLE9BQU8sUUFBUSxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxZQUFZO0VBQUUsTUFBTSxFQUFFLGFBQWEsTUFBTTtFQUFHO0VBQU8sT0FBTyxZQUFZO0NBQWtDLEVBQUU7Q0FDN0osT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Usd0JBQUMsT0FBRDtHQUFLLGNBQVksRUFBRSx1QkFBdUI7R0FBRyxXQUFVO0dBQXNCLE1BQUs7YUFDaEYsd0JBQUMscUJBQUQ7SUFBcUIsUUFBTztJQUFPLE9BQU07Y0FDdkMsd0JBQUMsVUFBRCxhQUNFLHdCQUFDLEtBQUQ7S0FBSyxNQUFNO0tBQVcsU0FBUTtLQUFRLGFBQVk7S0FBTSxtQkFBbUI7S0FBTyxhQUFZO0tBQU0sUUFBTztlQUN4RyxVQUFVLEtBQUssU0FBUyx3QkFBQyxNQUFELEVBQU0sTUFBTSxLQUFLLE1BQXdCLEdBQVosS0FBSzs7OztZQUFPLENBQUM7SUFDaEU7Ozs7Y0FDTCx3QkFBQyxTQUFELEVBQVMsWUFBWSxVQUFVLENBQUMsT0FBTyxFQUFFLHdCQUF3QixDQUFDLEVBQUk7Ozs7WUFDOUQ7Ozs7O0dBQ1M7Ozs7O0VBQ2xCOzs7O1lBQ0wsd0JBQUMsTUFBRDtHQUFJLFdBQVU7YUFDWCxVQUFVLEtBQUssU0FBUyx3QkFBQyxNQUFEO0lBQW9CLHdCQUFDLFFBQUQsRUFBTSxPQUFPLEVBQUUsaUJBQWlCLEtBQUssTUFBTSxFQUFJOzs7OztJQUFFLEtBQUs7SUFBSyx3QkFBQyxLQUFELFlBQUksS0FBSyxNQUFTOzs7OztHQUFLLEtBQTdGLEtBQUs7Ozs7VUFBd0YsQ0FBQztFQUM5SDs7OztVQUNEOzs7Ozs7QUFFVDs7QUFFQSxTQUFTLGVBQWUsRUFBRSxPQUFPLE1BQU0sVUFBVSxRQUFnRjtDQUMvSCxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQW5CLENBQ0Usd0JBQUMsVUFBRCxhQUFRLHdCQUFDLE1BQUQ7R0FBSSxXQUFVO2FBQWQsQ0FBd0MsTUFBTSxLQUFVOzs7OztZQUFFLFFBQVEsd0JBQUMsTUFBRDtHQUFNLGNBQVksR0FBRyxFQUFFLHdCQUF3QixFQUFFLElBQUk7R0FBUyxJQUFJO2FBQU0sd0JBQUMsY0FBRCxFQUFjLE1BQU0sR0FBSzs7Ozs7RUFBTzs7OztVQUFVOzs7O1lBQzNMLFFBQ007Ozs7OztBQUViOztBQUVBLE9BQU8sU0FBUyxjQUFjLEVBQzVCLE1BQ0EsTUFDQSxTQUNBLFFBQ0EsV0FPQztDQUNELE1BQU0sT0FBMkI7RUFDL0I7RUFBb0I7RUFBbUI7RUFBbUI7RUFDMUQ7RUFBb0I7RUFBb0I7Q0FDMUM7Q0FDQSxNQUFNLGNBQWMsU0FBUyxXQUFXLFNBQVMsWUFBWSxPQUFPLEtBQUssUUFBUSxRQUFRLFFBQVEsZ0JBQWdCO0NBRWpILE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNFLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQXNCLEVBQUUsb0JBQW9CO0dBQUs7Ozs7O0dBQzlELHdCQUFDLFdBQUQ7SUFBUyxjQUFZLEVBQUUsaUJBQWlCO0lBQUcsV0FBVTtjQUNsRCxZQUFZLEtBQUssUUFBUTtLQUN4QixNQUFNLFFBQVEsTUFBTSxRQUFRO0tBQzVCLE1BQU0sUUFBUSxNQUFNLGFBQWEsU0FBUyxVQUFVLENBQUMsT0FBTyxFQUFFLHVCQUF1QixJQUFJO0tBQ3pGLE9BQ0Usd0JBQUMsa0JBQUQ7TUFDRSxRQUFRLFFBQVE7TUFDVDtNQUVQLFNBQVMsV0FBVyxDQUFDO01BQ3JCLFdBQVc7TUFDRjtNQUNULE9BQU8sRUFBRSxhQUFhLElBQUk7TUFDMUIsT0FBTyxRQUFRLG1CQUFtQixVQUFVLFNBQVMsQ0FBQyxJQUFJLE9BQU8sU0FBUyxDQUFDO0tBQzVFLEdBTk07Ozs7WUFNTjtJQUVMLENBQUM7R0FDTTs7Ozs7R0FFVCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsZ0JBQUQ7TUFBZ0IsTUFBSztNQUFtQyxNQUFNLHdCQUFDLFFBQUQsRUFBUSxNQUFNLEdBQUs7Ozs7O01BQUcsT0FBTyxFQUFFLHdCQUF3QjtnQkFDbkgsd0JBQUMsY0FBRDtPQUFjLE1BQU0sTUFBTSxXQUFXLENBQUM7T0FBRyxNQUFLO01BQVU7Ozs7O0tBQzFDOzs7OztLQUNoQix3QkFBQyxnQkFBRDtNQUFnQixNQUFLO01BQW1DLE1BQU0sd0JBQUMsZ0JBQUQsRUFBZ0IsTUFBTSxHQUFLOzs7OztNQUFHLE9BQU8sRUFBRSx3QkFBd0I7Z0JBQzNILHdCQUFDLGNBQUQ7T0FBYyxNQUFNLE1BQU0sV0FBVyxDQUFDO09BQUcsTUFBSztNQUFVOzs7OztLQUMxQzs7Ozs7S0FDaEIsd0JBQUMsZ0JBQUQ7TUFBZ0IsTUFBTSx3QkFBQyxVQUFELEVBQVUsTUFBTSxHQUFLOzs7OztNQUFHLE9BQU8sRUFBRSx1QkFBdUI7Z0JBQzNFLE9BQU8sd0JBQUMsYUFBRCxFQUFhLE1BQU0sS0FBSyxZQUFjOzs7O2lCQUFJLHdCQUFDLE9BQUQsRUFBSyxXQUFVLDRCQUE2Qjs7Ozs7S0FDaEY7Ozs7O0tBQ2hCLHdCQUFDLGdCQUFEO01BQWdCLE1BQUs7TUFBaUMsTUFBTSx3QkFBQyxjQUFELENBQWU7Ozs7O01BQUcsT0FBTyxFQUFFLDBCQUEwQjtnQkFDOUcsTUFBTSxlQUFlLFNBQ3BCLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUNYLEtBQUssZUFBZSxLQUFLLGFBQ3hCLHdCQUFDLE1BQUQ7UUFDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVyw0Q0FBNEMsU0FBUzttQkFBUSx3QkFBQyxlQUFEO1VBQWUsZUFBWTtVQUFPLE1BQU07U0FBSzs7Ozs7UUFBTzs7Ozs7UUFDbEksd0JBQUMsUUFBRCxhQUFNLHdCQUFDLEtBQUQsWUFBSSxFQUFFLHFCQUFxQixTQUFTLEtBQUssRUFBRSxDQUFDLFlBQVksSUFBSSxTQUFTLEtBQUssTUFBTSxDQUFDLEdBQUcsRUFBSzs7OztrQkFBQyx3QkFBQyxTQUFELFlBQVEsU0FBUyxVQUFpQjs7OztnQkFBTzs7Ozs7UUFDekksd0JBQUMsUUFBRDtTQUFNLFVBQVUsU0FBUzttQkFBWSxVQUFVLFNBQVMsU0FBUztRQUFROzs7OztPQUN2RSxLQUpLLFNBQVM7Ozs7Y0FJZCxDQUNMO01BQ0M7Ozs7aUJBQ0Ysd0JBQUMsWUFBRDtPQUFZLGFBQWEsRUFBRSxzQkFBc0I7T0FBRyxPQUFPLEVBQUUsMEJBQTBCO01BQUk7Ozs7O0tBQ2pGOzs7OztJQUNiOzs7Ozs7RUFDRjs7Ozs7O0FBRVQ7O0FBRUEsU0FBUyxlQUFlO0NBQ3RCLE9BQU8sd0JBQUMsVUFBRDtFQUFVLGVBQVk7RUFBTyxNQUFNO0NBQUs7Ozs7O0FBQ2pEOztBQUVBLE9BQU8sU0FBUyxnQkFBZ0I7O0NBQzlCLE1BQU0sRUFBRSxNQUFNLFdBQVcsU0FBUyxZQUFZLGFBQWE7Q0FDM0QsTUFBTSxFQUFFLFNBQVMsUUFBUTtDQUN6QixPQUFPLHdCQUFDLGVBQUQ7RUFBcUI7RUFBTSxRQUFRO0VBQVMsU0FBUztFQUFXLGVBQWUsS0FBSyxRQUFRO0VBQUcsTUFBTSxRQUFRO0NBQVU7Ozs7O0FBQ2hJIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkRhc2hib2FyZFBhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFjdGl2aXR5LCBBbGVydFRyaWFuZ2xlLCBBcnJvd1VwUmlnaHQsIENhckZyb250LCBDbGlwYm9hcmRDaGVjaywgQ2xvY2szIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xyXG5pbXBvcnQgeyBDZWxsLCBQaWUsIFBpZUNoYXJ0LCBSZXNwb25zaXZlQ29udGFpbmVyLCBUb29sdGlwIH0gZnJvbSAncmVjaGFydHMnXHJcbmltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xyXG5pbXBvcnQgdHlwZSB7IFJlYWN0Tm9kZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgdHlwZSB7IEJvb2tpbmcsIERhc2hib2FyZENhcmRLZXksIERhc2hib2FyZERhdGEsIFVzZXJSb2xlIH0gZnJvbSAnLi4vLi4vYXBpL3R5cGVzJ1xyXG5pbXBvcnQgeyB1c2VEYXNoYm9hcmQgfSBmcm9tICcuLi8uLi9hcGkvcXVlcmllcydcclxuaW1wb3J0IHsgRGF0YVRhYmxlLCBFbXB0eVN0YXRlIH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy91aSdcclxuaW1wb3J0IHsgdCB9IGZyb20gJy4uLy4uL2kxOG4nXHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi8uLi9ob29rcy9BdXRoQ29udGV4dCdcclxuaW1wb3J0IHsgZm9ybWF0RWF0LCBmb3JtYXRLZXMgfSBmcm9tICcuLi8uLi9saWInXHJcbmltcG9ydCB7IHZlaGljbGVzIH0gZnJvbSAnLi4vLi4vbW9ja3MvZml4dHVyZXMnXHJcbmltcG9ydCB7IERhc2hib2FyZEtwaUNhcmQgfSBmcm9tICcuL0Rhc2hib2FyZEtwaUNhcmQnXHJcblxyXG5jb25zdCBtZXRyaWNMYWJlbHM6IFJlY29yZDxEYXNoYm9hcmRDYXJkS2V5LCBzdHJpbmc+ID0ge1xyXG4gIHZlaGljbGVzT3V0VG9kYXk6ICdkYXNoYm9hcmQudmVoaWNsZXNPdXQnLFxyXG4gIHBpY2t1cHNEdWVUb2RheTogJ2Rhc2hib2FyZC5waWNrdXBzRHVlJyxcclxuICByZXR1cm5zRHVlVG9kYXk6ICdkYXNoYm9hcmQucmV0dXJuc0R1ZScsXHJcbiAgb3ZlcmR1ZVZlaGljbGVzOiAnZGFzaGJvYXJkLm92ZXJkdWUnLFxyXG4gIHBlbmRpbmdBcHByb3ZhbHM6ICdkYXNoYm9hcmQucGVuZGluZ0FwcHJvdmFscycsXHJcbiAgYWN0aXZlQnJlYWtkb3duczogJ2Rhc2hib2FyZC5hY3RpdmVCcmVha2Rvd25zJyxcclxuICBtb250aGx5UmV2ZW51ZTogJ2Rhc2hib2FyZC5tb250aGx5UmV2ZW51ZScsXHJcbn1cclxuXHJcbmNvbnN0IGZsZWV0Q29sb3JzID0ge1xyXG4gIGF2YWlsYWJsZTogJyMwZjc2NmUnLFxyXG4gIHJlbnRlZDogJyNmOTczMTYnLFxyXG4gIHJlc2VydmVkOiAnIzI1NjNlYicsXHJcbiAgbWFpbnRlbmFuY2U6ICcjYjkxYzFjJyxcclxufVxyXG5cclxuY29uc3QgdmVoaWNsZUJ5SWQgPSBuZXcgTWFwKHZlaGljbGVzLm1hcCgodmVoaWNsZSkgPT4gW3ZlaGljbGUuaWQsIHZlaGljbGVdKSlcclxuXHJcbmZ1bmN0aW9uIEJvb2tpbmdUYWJsZSh7IHJvd3MsIHR5cGUgfTogeyByb3dzOiBCb29raW5nW107IHR5cGU6ICdwaWNrdXAnIHwgJ3JldHVybicgfSkge1xyXG4gIGNvbnN0IGlzUGlja3VwID0gdHlwZSA9PT0gJ3BpY2t1cCdcclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6ICd0aW1lJywgaGVhZGVyOiB0KCdkYXNoYm9hcmQudGltZScpLCByZW5kZXI6IChib29raW5nOiBCb29raW5nKSA9PiBmb3JtYXRFYXQoaXNQaWNrdXAgPyBib29raW5nLnBpY2t1cEF0IDogYm9va2luZy5yZXR1cm5BdCkuc3BsaXQoJywgJylbMV0gfSxcclxuICAgIHsga2V5OiAnY3VzdG9tZXInLCBoZWFkZXI6IHQoJ2Rhc2hib2FyZC5jdXN0b21lcicpLCByZW5kZXI6IChib29raW5nOiBCb29raW5nKSA9PiBib29raW5nLmN1c3RvbWVyTmFtZSA/PyAn4oCUJyB9LFxyXG4gICAgeyBrZXk6ICd2ZWhpY2xlJywgaGVhZGVyOiB0KCdkYXNoYm9hcmQudmVoaWNsZScpLCByZW5kZXI6IChib29raW5nOiBCb29raW5nKSA9PiB7XHJcbiAgICAgIGNvbnN0IHZlaGljbGUgPSB2ZWhpY2xlQnlJZC5nZXQoYm9va2luZy52ZWhpY2xlSWQpXHJcbiAgICAgIHJldHVybiB2ZWhpY2xlID8gYCR7dmVoaWNsZS5tYWtlfSAke3ZlaGljbGUubW9kZWx9YCA6ICfigJQnXHJcbiAgICB9IH0sXHJcbiAgICB7IGtleTogJ2FjdGlvbicsIGhlYWRlcjogJycsIHJlbmRlcjogKGJvb2tpbmc6IEJvb2tpbmcpID0+IChcclxuICAgICAgPExpbmsgY2xhc3NOYW1lPVwiYnV0dG9uIGJ1dHRvbi0tc2Vjb25kYXJ5IGJ1dHRvbi0tc21cIiB0bz17YC9hZG1pbi9ib29raW5ncy8ke2Jvb2tpbmcuaWR9LyR7aXNQaWNrdXAgPyAnY2hlY2stb3V0JyA6ICdjaGVjay1pbid9YH0+XHJcbiAgICAgICAge3QoaXNQaWNrdXAgPyAnZGFzaGJvYXJkLmNoZWNrT3V0JyA6ICdkYXNoYm9hcmQuY2hlY2tJbicpfVxyXG4gICAgICA8L0xpbms+XHJcbiAgICApIH0sXHJcbiAgXVxyXG4gIGNvbnN0IGVtcHR5ID0gKFxyXG4gICAgPEVtcHR5U3RhdGVcclxuICAgICAgYWN0aW9uPXs8TGluayBjbGFzc05hbWU9XCJ0ZXh0LWJ1dHRvblwiIHRvPVwiL2FkbWluL2Jvb2tpbmdzXCI+e3QoJ2Rhc2hib2FyZC52aWV3Qm9va2luZ3MnKX08L0xpbms+fVxyXG4gICAgICBkZXNjcmlwdGlvbj17dChpc1BpY2t1cCA/ICdkYXNoYm9hcmQubm9QaWNrdXBzJyA6ICdkYXNoYm9hcmQubm9SZXR1cm5zJyl9XHJcbiAgICAgIHRpdGxlPXt0KGlzUGlja3VwID8gJ2Rhc2hib2FyZC5ub1BpY2t1cHMnIDogJ2Rhc2hib2FyZC5ub1JldHVybnMnKX1cclxuICAgIC8+XHJcbiAgKVxyXG4gIHJldHVybiA8RGF0YVRhYmxlIGNvbHVtbnM9e2NvbHVtbnN9IGVtcHR5PXtlbXB0eX0gcm93S2V5PXsoYm9va2luZykgPT4gYm9va2luZy5pZH0gcm93cz17cm93c30gLz5cclxufVxyXG5cclxuZnVuY3Rpb24gRmxlZXRTdGF0dXMoeyBkYXRhIH06IHsgZGF0YTogRGFzaGJvYXJkRGF0YVsnZmxlZXRTdGF0dXMnXSB9KSB7XHJcbiAgY29uc3QgY2hhcnREYXRhID0gT2JqZWN0LmVudHJpZXMoZGF0YSkubWFwKChbbmFtZSwgdmFsdWVdKSA9PiAoeyBuYW1lOiB0KGBkYXNoYm9hcmQuJHtuYW1lfWApLCB2YWx1ZSwgY29sb3I6IGZsZWV0Q29sb3JzW25hbWUgYXMga2V5b2YgdHlwZW9mIGZsZWV0Q29sb3JzXSB9KSlcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGVldC1zdGF0dXNcIj5cclxuICAgICAgPGRpdiBhcmlhLWxhYmVsPXt0KCdkYXNoYm9hcmQuZmxlZXRTdGF0dXMnKX0gY2xhc3NOYW1lPVwiZmxlZXQtc3RhdHVzX19jaGFydFwiIHJvbGU9XCJpbWdcIj5cclxuICAgICAgICA8UmVzcG9uc2l2ZUNvbnRhaW5lciBoZWlnaHQ9XCIxMDAlXCIgd2lkdGg9XCIxMDAlXCI+XHJcbiAgICAgICAgICA8UGllQ2hhcnQ+XHJcbiAgICAgICAgICAgIDxQaWUgZGF0YT17Y2hhcnREYXRhfSBkYXRhS2V5PVwidmFsdWVcIiBpbm5lclJhZGl1cz1cIjYyJVwiIGlzQW5pbWF0aW9uQWN0aXZlPXtmYWxzZX0gb3V0ZXJSYWRpdXM9XCI4OCVcIiBzdHJva2U9XCJub25lXCI+XHJcbiAgICAgICAgICAgICAge2NoYXJ0RGF0YS5tYXAoKGl0ZW0pID0+IDxDZWxsIGZpbGw9e2l0ZW0uY29sb3J9IGtleT17aXRlbS5uYW1lfSAvPil9XHJcbiAgICAgICAgICAgIDwvUGllPlxyXG4gICAgICAgICAgICA8VG9vbHRpcCBmb3JtYXR0ZXI9eyh2YWx1ZSkgPT4gW3ZhbHVlLCB0KCdkYXNoYm9hcmQudmVoaWNsZUNvdW50JyldfSAvPlxyXG4gICAgICAgICAgPC9QaWVDaGFydD5cclxuICAgICAgICA8L1Jlc3BvbnNpdmVDb250YWluZXI+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8dWwgY2xhc3NOYW1lPVwiZmxlZXQtc3RhdHVzX19sZWdlbmRcIj5cclxuICAgICAgICB7Y2hhcnREYXRhLm1hcCgoaXRlbSkgPT4gPGxpIGtleT17aXRlbS5uYW1lfT48c3BhbiBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IGl0ZW0uY29sb3IgfX0gLz57aXRlbS5uYW1lfTxiPntpdGVtLnZhbHVlfTwvYj48L2xpPil9XHJcbiAgICAgIDwvdWw+XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbmZ1bmN0aW9uIERhc2hib2FyZFBhbmVsKHsgdGl0bGUsIGljb24sIGNoaWxkcmVuLCBocmVmIH06IHsgdGl0bGU6IHN0cmluZzsgaWNvbjogUmVhY3ROb2RlOyBjaGlsZHJlbjogUmVhY3ROb2RlOyBocmVmPzogc3RyaW5nIH0pIHtcclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiZGFzaGJvYXJkLXBhbmVsXCI+XHJcbiAgICAgIDxoZWFkZXI+PGgyIGNsYXNzTmFtZT1cImRhc2hib2FyZC1wYW5lbF9fdGl0bGVcIj57aWNvbn17dGl0bGV9PC9oMj57aHJlZiAmJiA8TGluayBhcmlhLWxhYmVsPXtgJHt0KCdkYXNoYm9hcmQudmlld0Jvb2tpbmdzJyl9OiAke3RpdGxlfWB9IHRvPXtocmVmfT48QXJyb3dVcFJpZ2h0IHNpemU9ezE3fSAvPjwvTGluaz59PC9oZWFkZXI+XHJcbiAgICAgIHtjaGlsZHJlbn1cclxuICAgIDwvc2VjdGlvbj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBEYXNoYm9hcmRWaWV3KHtcclxuICBkYXRhLFxyXG4gIHJvbGUsXHJcbiAgbG9hZGluZyxcclxuICBmYWlsZWQsXHJcbiAgb25SZXRyeSxcclxufToge1xyXG4gIGRhdGE/OiBEYXNoYm9hcmREYXRhXHJcbiAgcm9sZTogVXNlclJvbGVcclxuICBsb2FkaW5nOiBib29sZWFuXHJcbiAgZmFpbGVkOiBib29sZWFuXHJcbiAgb25SZXRyeTogKCkgPT4gdm9pZFxyXG59KSB7XHJcbiAgY29uc3Qga2V5czogRGFzaGJvYXJkQ2FyZEtleVtdID0gW1xyXG4gICAgJ3ZlaGljbGVzT3V0VG9kYXknLCAncGlja3Vwc0R1ZVRvZGF5JywgJ3JldHVybnNEdWVUb2RheScsICdvdmVyZHVlVmVoaWNsZXMnLFxyXG4gICAgJ3BlbmRpbmdBcHByb3ZhbHMnLCAnYWN0aXZlQnJlYWtkb3ducycsICdtb250aGx5UmV2ZW51ZScsXHJcbiAgXVxyXG4gIGNvbnN0IHZpc2libGVLZXlzID0gcm9sZSA9PT0gJ293bmVyJyB8fCByb2xlID09PSAnbWFuYWdlcicgPyBrZXlzIDoga2V5cy5maWx0ZXIoKGtleSkgPT4ga2V5ICE9PSAnbW9udGhseVJldmVudWUnKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJkYXNoYm9hcmQtcGFnZVwiPlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJkYXNoYm9hcmQtc3VidGl0bGVcIj57dCgnZGFzaGJvYXJkLnN1YnRpdGxlJyl9PC9wPlxyXG4gICAgICA8c2VjdGlvbiBhcmlhLWxhYmVsPXt0KCdkYXNoYm9hcmQudGl0bGUnKX0gY2xhc3NOYW1lPVwiZGFzaGJvYXJkLWtwaS1ncmlkXCI+XHJcbiAgICAgICAge3Zpc2libGVLZXlzLm1hcCgoa2V5KSA9PiB7XHJcbiAgICAgICAgICBjb25zdCB2YWx1ZSA9IGRhdGE/Lm1ldHJpY3Nba2V5XVxyXG4gICAgICAgICAgY29uc3QgZXJyb3IgPSBkYXRhPy5jYXJkRXJyb3JzPy5ba2V5XSA/PyAoZmFpbGVkICYmICFkYXRhID8gdCgnZGFzaGJvYXJkLm1ldHJpY0Vycm9yJykgOiB1bmRlZmluZWQpXHJcbiAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICA8RGFzaGJvYXJkS3BpQ2FyZFxyXG4gICAgICAgICAgICAgIGRhbmdlcj17a2V5ID09PSAnb3ZlcmR1ZVZlaGljbGVzJ31cclxuICAgICAgICAgICAgICBlcnJvcj17ZXJyb3J9XHJcbiAgICAgICAgICAgICAga2V5PXtrZXl9XHJcbiAgICAgICAgICAgICAgbG9hZGluZz17bG9hZGluZyAmJiAhZGF0YX1cclxuICAgICAgICAgICAgICBtZXRyaWNLZXk9e2tleX1cclxuICAgICAgICAgICAgICBvblJldHJ5PXtvblJldHJ5fVxyXG4gICAgICAgICAgICAgIHRpdGxlPXt0KG1ldHJpY0xhYmVsc1trZXldKX1cclxuICAgICAgICAgICAgICB2YWx1ZT17a2V5ID09PSAnbW9udGhseVJldmVudWUnID8gZm9ybWF0S2VzKHZhbHVlID8/IDApIDogU3RyaW5nKHZhbHVlID8/IDApfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgKVxyXG4gICAgICAgIH0pfVxyXG4gICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImRhc2hib2FyZC1wYW5lbC1ncmlkXCI+XHJcbiAgICAgICAgPERhc2hib2FyZFBhbmVsIGhyZWY9XCIvYWRtaW4vYm9va2luZ3M/cGlja3VwPWR1ZS10b2RheVwiIGljb249ezxDbG9jazMgc2l6ZT17MTh9IC8+fSB0aXRsZT17dCgnZGFzaGJvYXJkLnRvZGF5UGlja3VwcycpfT5cclxuICAgICAgICAgIDxCb29raW5nVGFibGUgcm93cz17ZGF0YT8ucGlja3VwcyA/PyBbXX0gdHlwZT1cInBpY2t1cFwiIC8+XHJcbiAgICAgICAgPC9EYXNoYm9hcmRQYW5lbD5cclxuICAgICAgICA8RGFzaGJvYXJkUGFuZWwgaHJlZj1cIi9hZG1pbi9ib29raW5ncz9yZXR1cm49ZHVlLXRvZGF5XCIgaWNvbj17PENsaXBib2FyZENoZWNrIHNpemU9ezE4fSAvPn0gdGl0bGU9e3QoJ2Rhc2hib2FyZC50b2RheVJldHVybnMnKX0+XHJcbiAgICAgICAgICA8Qm9va2luZ1RhYmxlIHJvd3M9e2RhdGE/LnJldHVybnMgPz8gW119IHR5cGU9XCJyZXR1cm5cIiAvPlxyXG4gICAgICAgIDwvRGFzaGJvYXJkUGFuZWw+XHJcbiAgICAgICAgPERhc2hib2FyZFBhbmVsIGljb249ezxDYXJGcm9udCBzaXplPXsxOH0gLz59IHRpdGxlPXt0KCdkYXNoYm9hcmQuZmxlZXRTdGF0dXMnKX0+XHJcbiAgICAgICAgICB7ZGF0YSA/IDxGbGVldFN0YXR1cyBkYXRhPXtkYXRhLmZsZWV0U3RhdHVzfSAvPiA6IDxkaXYgY2xhc3NOYW1lPVwiZGFzaGJvYXJkLXBhbmVsX19za2VsZXRvblwiIC8+fVxyXG4gICAgICAgIDwvRGFzaGJvYXJkUGFuZWw+XHJcbiAgICAgICAgPERhc2hib2FyZFBhbmVsIGhyZWY9XCIvYWRtaW4vYm9va2luZ3M/c29ydD11cGRhdGVkQXRcIiBpY29uPXs8QWN0aXZpdHlJY29uIC8+fSB0aXRsZT17dCgnZGFzaGJvYXJkLnJlY2VudEFjdGl2aXR5Jyl9PlxyXG4gICAgICAgICAge2RhdGE/LnJlY2VudEFjdGl2aXR5Lmxlbmd0aCA/IChcclxuICAgICAgICAgICAgPG9sIGNsYXNzTmFtZT1cImFjdGl2aXR5LWZlZWRcIj5cclxuICAgICAgICAgICAgICB7ZGF0YS5yZWNlbnRBY3Rpdml0eS5tYXAoKGFjdGl2aXR5KSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8bGkga2V5PXthY3Rpdml0eS5pZH0+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGFjdGl2aXR5LWZlZWRfX2ljb24gYWN0aXZpdHktZmVlZF9faWNvbi0tJHthY3Rpdml0eS5raW5kfWB9PjxBbGVydFRyaWFuZ2xlIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHNpemU9ezE1fSAvPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4+PGI+e3QoYGRhc2hib2FyZC5hY3Rpdml0eSR7YWN0aXZpdHkua2luZFswXS50b1VwcGVyQ2FzZSgpfSR7YWN0aXZpdHkua2luZC5zbGljZSgxKX1gKX08L2I+PHNtYWxsPnthY3Rpdml0eS5yZWZlcmVuY2V9PC9zbWFsbD48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDx0aW1lIGRhdGVUaW1lPXthY3Rpdml0eS50aW1lc3RhbXB9Pntmb3JtYXRFYXQoYWN0aXZpdHkudGltZXN0YW1wKX08L3RpbWU+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L29sPlxyXG4gICAgICAgICAgKSA6IDxFbXB0eVN0YXRlIGRlc2NyaXB0aW9uPXt0KCdkYXNoYm9hcmQubm9BY3Rpdml0eScpfSB0aXRsZT17dCgnZGFzaGJvYXJkLnJlY2VudEFjdGl2aXR5Jyl9IC8+fVxyXG4gICAgICAgIDwvRGFzaGJvYXJkUGFuZWw+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcblxyXG5mdW5jdGlvbiBBY3Rpdml0eUljb24oKSB7XHJcbiAgcmV0dXJuIDxBY3Rpdml0eSBhcmlhLWhpZGRlbj1cInRydWVcIiBzaXplPXsxOH0gLz5cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIERhc2hib2FyZFBhZ2UoKSB7XHJcbiAgY29uc3QgeyBkYXRhLCBpc0xvYWRpbmcsIGlzRXJyb3IsIHJlZmV0Y2ggfSA9IHVzZURhc2hib2FyZCgpXHJcbiAgY29uc3QgeyByb2xlIH0gPSB1c2VBdXRoKClcclxuICByZXR1cm4gPERhc2hib2FyZFZpZXcgZGF0YT17ZGF0YX0gZmFpbGVkPXtpc0Vycm9yfSBsb2FkaW5nPXtpc0xvYWRpbmd9IG9uUmV0cnk9eygpID0+IHZvaWQgcmVmZXRjaCgpfSByb2xlPXtyb2xlID8/ICdhZ2VudCd9IC8+XHJcbn0iXX0=
import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/dashboard/DashboardKpiCard.tsx");const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=8b23c0c4";
import { Badge, ErrorState, KpiCard, Skeleton } from "/src/components/ui/index.ts";
import { t } from "/src/i18n/index.ts";
import { DASHBOARD_KPI_ROUTES } from "/src/features/dashboard/dashboardConfig.ts";
var _jsxFileName = "C:/CarHire/Frontend/src/features/dashboard/DashboardKpiCard.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b23c0c4";
export function DashboardKpiCard({ metricKey, title, value, loading = false, error, danger = false, onRetry }) {
	if (loading) {
		return /* @__PURE__ */ _jsxDEV("article", {
			"aria-label": title,
			className: "dashboard-kpi dashboard-kpi--loading",
			children: [/* @__PURE__ */ _jsxDEV("p", { children: title }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 89
			}, this), /* @__PURE__ */ _jsxDEV(Skeleton, { rows: 2 }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 103
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 12
		}, this);
	}
	if (error) {
		return /* @__PURE__ */ _jsxDEV("article", {
			className: "dashboard-kpi dashboard-kpi--error",
			children: [/* @__PURE__ */ _jsxDEV("p", { children: title }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV(ErrorState, {
				onRetry,
				retryLabel: t("styleguide.retry"),
				title: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 30,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV(Link, {
		className: `dashboard-kpi-link${danger ? " dashboard-kpi-link--danger" : ""}`,
		to: DASHBOARD_KPI_ROUTES[metricKey],
		children: [/* @__PURE__ */ _jsxDEV(KpiCard, {
			label: title,
			value
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 7
		}, this), danger && /* @__PURE__ */ _jsxDEV(Badge, {
			tone: "danger",
			children: t("dashboard.overdueLabel")
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 40,
			columnNumber: 18
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 38,
		columnNumber: 5
	}, this);
}
_c = DashboardKpiCard;
var _c;
$RefreshReg$(_c, "DashboardKpiCard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/dashboard/DashboardKpiCard.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/CarHire/Frontend/src/features/dashboard/DashboardKpiCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/CarHire/Frontend/src/features/dashboard/DashboardKpiCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/CarHire/Frontend/src/features/dashboard/DashboardKpiCard.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBRXJCLFNBQVMsT0FBTyxZQUFZLFNBQVMsZ0JBQWdCO0FBQ3JELFNBQVMsU0FBUztBQUNsQixTQUFTLDRCQUE0Qjs7O0FBRXJDLE9BQU8sU0FBUyxpQkFBaUIsRUFDL0IsV0FDQSxPQUNBLE9BQ0EsVUFBVSxPQUNWLE9BQ0EsU0FBUyxPQUNULFdBU0M7Q0FDRCxJQUFJLFNBQVM7RUFDWCxPQUFPLHdCQUFDLFdBQUQ7R0FBUyxjQUFZO0dBQU8sV0FBVTthQUF0QyxDQUE2RSx3QkFBQyxLQUFELFlBQUksTUFBUzs7OzthQUFDLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEVBQUk7Ozs7V0FBVTs7Ozs7O0NBQ2xJO0NBRUEsSUFBSSxPQUFPO0VBQ1QsT0FDRSx3QkFBQyxXQUFEO0dBQVMsV0FBVTthQUFuQixDQUNFLHdCQUFDLEtBQUQsWUFBSSxNQUFTOzs7O2FBQ2Isd0JBQUMsWUFBRDtJQUFxQjtJQUFTLFlBQVksRUFBRSxrQkFBa0I7SUFBRyxPQUFPO0dBQVE7Ozs7V0FDekU7Ozs7OztDQUViO0NBRUEsT0FDRSx3QkFBQyxNQUFEO0VBQU0sV0FBVyxxQkFBcUIsU0FBUyxnQ0FBZ0M7RUFBTSxJQUFJLHFCQUFxQjtZQUE5RyxDQUNFLHdCQUFDLFNBQUQ7R0FBUyxPQUFPO0dBQWM7RUFBUTs7OztZQUNyQyxVQUFVLHdCQUFDLE9BQUQ7R0FBTyxNQUFLO2FBQVUsRUFBRSx3QkFBd0I7RUFBUzs7OztVQUNoRTs7Ozs7O0FBRVYiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRGFzaGJvYXJkS3BpQ2FyZC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXHJcbmltcG9ydCB0eXBlIHsgRGFzaGJvYXJkQ2FyZEtleSB9IGZyb20gJy4uLy4uL2FwaS90eXBlcydcclxuaW1wb3J0IHsgQmFkZ2UsIEVycm9yU3RhdGUsIEtwaUNhcmQsIFNrZWxldG9uIH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy91aSdcclxuaW1wb3J0IHsgdCB9IGZyb20gJy4uLy4uL2kxOG4nXHJcbmltcG9ydCB7IERBU0hCT0FSRF9LUElfUk9VVEVTIH0gZnJvbSAnLi9kYXNoYm9hcmRDb25maWcnXHJcblxyXG5leHBvcnQgZnVuY3Rpb24gRGFzaGJvYXJkS3BpQ2FyZCh7XHJcbiAgbWV0cmljS2V5LFxyXG4gIHRpdGxlLFxyXG4gIHZhbHVlLFxyXG4gIGxvYWRpbmcgPSBmYWxzZSxcclxuICBlcnJvcixcclxuICBkYW5nZXIgPSBmYWxzZSxcclxuICBvblJldHJ5LFxyXG59OiB7XHJcbiAgbWV0cmljS2V5OiBEYXNoYm9hcmRDYXJkS2V5XHJcbiAgdGl0bGU6IHN0cmluZ1xyXG4gIHZhbHVlOiBzdHJpbmdcclxuICBsb2FkaW5nPzogYm9vbGVhblxyXG4gIGVycm9yPzogc3RyaW5nXHJcbiAgZGFuZ2VyPzogYm9vbGVhblxyXG4gIG9uUmV0cnk6ICgpID0+IHZvaWRcclxufSkge1xyXG4gIGlmIChsb2FkaW5nKSB7XHJcbiAgICByZXR1cm4gPGFydGljbGUgYXJpYS1sYWJlbD17dGl0bGV9IGNsYXNzTmFtZT1cImRhc2hib2FyZC1rcGkgZGFzaGJvYXJkLWtwaS0tbG9hZGluZ1wiPjxwPnt0aXRsZX08L3A+PFNrZWxldG9uIHJvd3M9ezJ9IC8+PC9hcnRpY2xlPlxyXG4gIH1cclxuXHJcbiAgaWYgKGVycm9yKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8YXJ0aWNsZSBjbGFzc05hbWU9XCJkYXNoYm9hcmQta3BpIGRhc2hib2FyZC1rcGktLWVycm9yXCI+XHJcbiAgICAgICAgPHA+e3RpdGxlfTwvcD5cclxuICAgICAgICA8RXJyb3JTdGF0ZSBvblJldHJ5PXtvblJldHJ5fSByZXRyeUxhYmVsPXt0KCdzdHlsZWd1aWRlLnJldHJ5Jyl9IHRpdGxlPXtlcnJvcn0gLz5cclxuICAgICAgPC9hcnRpY2xlPlxyXG4gICAgKVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxMaW5rIGNsYXNzTmFtZT17YGRhc2hib2FyZC1rcGktbGluayR7ZGFuZ2VyID8gJyBkYXNoYm9hcmQta3BpLWxpbmstLWRhbmdlcicgOiAnJ31gfSB0bz17REFTSEJPQVJEX0tQSV9ST1VURVNbbWV0cmljS2V5XX0+XHJcbiAgICAgIDxLcGlDYXJkIGxhYmVsPXt0aXRsZX0gdmFsdWU9e3ZhbHVlfSAvPlxyXG4gICAgICB7ZGFuZ2VyICYmIDxCYWRnZSB0b25lPVwiZGFuZ2VyXCI+e3QoJ2Rhc2hib2FyZC5vdmVyZHVlTGFiZWwnKX08L0JhZGdlPn1cclxuICAgIDwvTGluaz5cclxuICApXHJcbn0iXX0=
import AxeBuilder from '@axe-core/playwright'
import { expect, test } from '@playwright/test'
import { DEMO_PASSWORD, users } from '../src/mocks/fixtures'

const destinations = {
  owner: { path: '/admin', heading: 'Dashboard' },
  manager: { path: '/admin', heading: 'Dashboard' },
  agent: { path: '/admin', heading: 'Dashboard' },
  driver: { path: '/admin/my-trips', heading: 'My trips' },
  mechanic: { path: '/admin/incidents', heading: 'Incidents' },
}

for (const user of users) {
  const destination = destinations[user.role]
  test(`${user.role} lands on the correct staff page`, async ({ page }) => {
    await page.goto('/login')
    await page.getByLabel('Work email').fill(user.email)
    await page.getByLabel('Password', { exact: true }).fill(DEMO_PASSWORD)
    await page.getByRole('button', { name: 'Sign in' }).click()
    await expect(page).toHaveURL(new RegExp(`${destination.path.replaceAll('/', '\\/')}$`))
    await expect(page.getByRole('heading', { name: destination.heading })).toBeVisible()
  })
}

test('login page has no Axe accessibility violations', async ({ page }) => {
  await page.goto('/login')
  const results = await new AxeBuilder({ page }).analyze()
  expect(results.violations).toEqual([])
})

test('an agent sees 403 on a manager-only route', async ({ page }) => {
  const agent = users.find((user) => user.role === 'agent')!
  await page.goto('/login')
  await page.getByLabel('Work email').fill(agent.email)
  await page.getByLabel('Password', { exact: true }).fill(DEMO_PASSWORD)
  await page.getByRole('button', { name: 'Sign in' }).click()
  await page.goto('/admin/staff')
  await expect(page).toHaveURL(/\/403$/)
  await expect(page.getByRole('heading', { name: 'Access denied' })).toBeVisible()
})
import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=bb1d9b35";
import { t as require_react } from "/node_modules/.vite/deps/react-4hkZzRew.js?v=bb1d9b35";
// node_modules/react-hook-form/dist/index.esm.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var isCheckBoxInput = (element) => element.type === "checkbox";
var isFileInput = (element) => element.type === "file";
var isDateObject = (value) => value instanceof Date;
var isNullOrUndefined = (value) => value == null;
var isObjectType = (value) => typeof value === "object";
var isObject = (value) => !isNullOrUndefined(value) && !Array.isArray(value) && isObjectType(value) && !isDateObject(value);
var getEventValue = (event) => isObject(event) && event.target ? isCheckBoxInput(event.target) ? event.target.checked : isFileInput(event.target) ? event.target.files : event.target.value : event;
var FIELD_PATH_RE = /[.[\]'"]/;
var stringToPath = (input) => input.split(FIELD_PATH_RE).filter(Boolean);
function getNullAncestorValue(control, name) {
	const segments = stringToPath(name);
	let formValues = control._formValues;
	let defaultValues = control._defaultValues;
	for (let i = 0; i < segments.length - 1; i++) {
		const key = segments[i];
		formValues = formValues == null ? formValues : formValues[key];
		defaultValues = defaultValues == null ? defaultValues : defaultValues[key];
		if (formValues === null || defaultValues === null) return null;
	}
}
var isNameInFieldArray = (names, name) => name.split(".").some((part, index, arr) => !isNaN(Number(part)) && names.has(arr.slice(0, index).join(".")));
var isWeb = typeof window !== "undefined" && typeof window.HTMLElement !== "undefined" && typeof document !== "undefined";
function cloneObject(data) {
	if (data === null || typeof data !== "object") return data;
	if (data instanceof Date) return new Date(data);
	const isBlobInstance = typeof Blob !== "undefined" && data instanceof Blob;
	const isFileListInstance = typeof FileList !== "undefined" && data instanceof FileList;
	if (isWeb && (isBlobInstance || isFileListInstance)) return data;
	const isArray = Array.isArray(data);
	const prototype = Object.getPrototypeOf(data);
	if (!isArray && prototype && prototype.constructor !== Object) return data;
	const copy = isArray ? new Array(data.length) : Object.create(prototype);
	for (const key in data) if (Object.prototype.hasOwnProperty.call(data, key)) copy[key] = cloneObject(data[key]);
	return copy;
}
var EVENTS = {
	BLUR: "blur",
	FOCUS_OUT: "focusout",
	CHANGE: "change",
	SUBMIT: "submit",
	TRIGGER: "trigger",
	VALID: "valid"
};
var VALIDATION_MODE = {
	onBlur: "onBlur",
	onChange: "onChange",
	onSubmit: "onSubmit",
	onTouched: "onTouched",
	all: "all"
};
var INPUT_VALIDATION_RULES = {
	max: "max",
	min: "min",
	maxLength: "maxLength",
	minLength: "minLength",
	pattern: "pattern",
	required: "required",
	validate: "validate"
};
var REGISTER_VALIDATION_RULES = [
	INPUT_VALIDATION_RULES.required,
	INPUT_VALIDATION_RULES.min,
	INPUT_VALIDATION_RULES.max,
	INPUT_VALIDATION_RULES.minLength,
	INPUT_VALIDATION_RULES.maxLength,
	INPUT_VALIDATION_RULES.pattern,
	INPUT_VALIDATION_RULES.validate
];
var FORM_ERROR_TYPE = "form";
var ROOT_ERROR_TYPE = "root";
var PROTOTYPE_KEYWORDS = [
	"__proto__",
	"constructor",
	"prototype"
];
var IS_KEY_RE = /^\w*$/;
var isKey = (value) => IS_KEY_RE.test(value);
var isUndefined = (val) => val === void 0;
var get = (object, path, defaultValue) => {
	if (!path || !isObject(object)) return defaultValue;
	const paths = isKey(path) ? [path] : stringToPath(path);
	if (paths.some((key) => PROTOTYPE_KEYWORDS.includes(key))) return defaultValue;
	const result = paths.reduce((result, key) => {
		return isNullOrUndefined(result) ? void 0 : result[key];
	}, object);
	return isUndefined(result) || result === object ? isUndefined(object[path]) ? defaultValue : object[path] : result;
};
var isBoolean = (value) => typeof value === "boolean";
var isFunction = (value) => typeof value === "function";
var set = (object, path, value) => {
	let index = -1;
	const tempPath = isKey(path) ? [path] : stringToPath(path);
	const length = tempPath.length;
	const lastIndex = length - 1;
	while (++index < length) {
		const key = tempPath[index];
		let newValue = value;
		if (index !== lastIndex) {
			const objValue = object[key];
			newValue = isObject(objValue) || Array.isArray(objValue) ? objValue : !isNaN(+tempPath[index + 1]) ? [] : {};
		}
		if (PROTOTYPE_KEYWORDS.includes(key)) return;
		object[key] = newValue;
		object = object[key];
	}
};
/**
* Separate context for `control` to prevent unnecessary rerenders.
* Internal hooks that only need control use this instead of full form context.
*/
var HookFormControlContext = import_react.createContext(null);
HookFormControlContext.displayName = "HookFormControlContext";
/**
* @internal Internal hook to access only control from context.
*/
var useFormControlContext = () => import_react.useContext(HookFormControlContext);
var getProxyFormState = (formState, control, localProxyFormState, isRoot = true) => {
	const result = {};
	for (const key in formState) Object.defineProperty(result, key, { get: () => {
		const _key = key;
		if (control._proxyFormState[_key] !== VALIDATION_MODE.all) control._proxyFormState[_key] = !isRoot || VALIDATION_MODE.all;
		localProxyFormState && (localProxyFormState[_key] = true);
		return formState[_key];
	} });
	return result;
};
var useIsomorphicLayoutEffect = typeof window !== "undefined" ? import_react.useLayoutEffect : import_react.useEffect;
var isPlainObject = (tempObject) => {
	const prototypeCopy = tempObject.constructor && tempObject.constructor.prototype;
	return isObject(prototypeCopy) && prototypeCopy.hasOwnProperty("isPrototypeOf");
};
var isPrimitive = (value) => isNullOrUndefined(value) || !isObjectType(value);
var isEmptyObjectWithCustomPrototype = (object, keys) => keys.length === 0 && !Array.isArray(object) && Object.getPrototypeOf(object) !== null && !isPlainObject(object);
function deepEqual(object1, object2, isErrorObject = false, visited = /* @__PURE__ */ new WeakMap()) {
	if (object1 === object2) return true;
	if (isPrimitive(object1) || isPrimitive(object2)) return Object.is(object1, object2);
	if (isDateObject(object1) && isDateObject(object2)) return Object.is(object1.getTime(), object2.getTime());
	if (Array.isArray(object1) && Array.isArray(object2) && object1.length !== object2.length) return false;
	const keys1 = Object.keys(object1);
	const keys2 = Object.keys(object2);
	if (keys1.length !== keys2.length) return false;
	if (isEmptyObjectWithCustomPrototype(object1, keys1) || isEmptyObjectWithCustomPrototype(object2, keys2)) return Object.is(object1, object2);
	if (!keys1.length && Array.isArray(object1) !== Array.isArray(object2)) return false;
	const visitedPairs = visited.get(object1);
	if (visitedPairs && visitedPairs.has(object2)) return true;
	if (visitedPairs) visitedPairs.add(object2);
	else {
		const ws = /* @__PURE__ */ new WeakSet();
		ws.add(object2);
		visited.set(object1, ws);
	}
	for (const key of keys1) {
		const val1 = object1[key];
		if (!Object.prototype.hasOwnProperty.call(object2, key)) return false;
		if (!isErrorObject || key !== "ref") {
			const val2 = object2[key];
			if (isDateObject(val1) && isDateObject(val2) || (isObject(val1) || Array.isArray(val1)) && (isObject(val2) || Array.isArray(val2)) ? !deepEqual(val1, val2, isErrorObject, visited) : !Object.is(val1, val2)) return false;
		}
	}
	return true;
}
var cloneFormState = ({ defaultValues, ...formState }) => ({
	...cloneObject(formState),
	defaultValues
});
function useResyncOnReconnect(getInitialValue, clone = cloneObject) {
	const _connected = import_react.useRef(false);
	const _initialized = import_react.useRef(false);
	const _prevValue = import_react.useRef(void 0);
	const _renderCount = import_react.useRef(0);
	_renderCount.current++;
	if (!_initialized.current && getInitialValue) {
		_initialized.current = true;
		_prevValue.current = clone(getInitialValue());
	}
	return {
		resyncIfNeeded: import_react.useCallback((enabled, getCurrentValue, setValue) => {
			if (enabled && (_connected.current || _initialized.current && _renderCount.current > 1)) {
				const currentValue = getCurrentValue();
				if (!deepEqual(_prevValue.current, currentValue)) setValue(currentValue);
			}
			_connected.current = true;
		}, []),
		snapshot: import_react.useCallback((enabled, getCurrentValue) => {
			if (enabled) _prevValue.current = clone(getCurrentValue());
		}, [clone])
	};
}
/**
* Subscribes to form state with re-renders isolated to this hook.
* Optionally scope to specific field names to minimize re-render surface.
*
* @see [API](https://react-hook-form.com/docs/useformstate)
*
* @example
* ```tsx
* const { errors, isDirty } = useFormState({ control, name: "email" });
* ```
*/
function useFormState(props) {
	const formControl = useFormControlContext();
	const { control = formControl, disabled, name, exact } = props || {};
	const getCurrentFormState = () => ({
		...control._formState,
		defaultValues: control._defaultValues
	});
	const [formState, updateFormState] = import_react.useState(getCurrentFormState);
	const _localProxyFormState = import_react.useRef({
		isDirty: false,
		isLoading: false,
		dirtyFields: false,
		touchedFields: false,
		validatingFields: false,
		isValidating: false,
		isValid: false,
		errors: false
	});
	const { resyncIfNeeded, snapshot } = useResyncOnReconnect(getCurrentFormState, cloneFormState);
	useIsomorphicLayoutEffect(() => {
		resyncIfNeeded(!disabled, getCurrentFormState, updateFormState);
		const unsubscribe = control._subscribe({
			name,
			formState: _localProxyFormState.current,
			exact,
			callback: (formState) => {
				!disabled && updateFormState({
					...control._formState,
					...formState,
					defaultValues: control._defaultValues
				});
			}
		});
		return () => {
			unsubscribe();
			snapshot(!disabled, getCurrentFormState);
		};
	}, [
		control,
		name,
		disabled,
		exact,
		resyncIfNeeded,
		snapshot
	]);
	import_react.useEffect(() => {
		_localProxyFormState.current.isValid && control._setValid(true);
	}, [control]);
	return import_react.useMemo(() => getProxyFormState(formState, control, _localProxyFormState.current, false), [formState, control]);
}
var isString = (value) => typeof value === "string";
var generateWatchOutput = (names, _names, formValues, isGlobal, defaultValue) => {
	if (isString(names)) {
		isGlobal && _names.watch.add(names);
		return get(formValues, names, defaultValue);
	}
	if (Array.isArray(names)) return names.map((fieldName) => (isGlobal && _names.watch.add(fieldName), get(formValues, fieldName, get(defaultValue, fieldName))));
	isGlobal && (_names.watchAll = true);
	return formValues;
};
/**
* Subscribes to field value changes and isolates re-renders to the hook level.
*
* @see [API](https://react-hook-form.com/docs/usewatch)
*
* @example
* ```tsx
* const email = useWatch({ control, name: "email" });
* const all   = useWatch({ control });
* const adult = useWatch({ control, name: "age", compute: (v) => v >= 18 });
* ```
*/
function useWatch(props) {
	const formControl = useFormControlContext();
	const { control = formControl, name, defaultValue, disabled, exact, compute } = props || {};
	const _defaultValue = import_react.useRef(defaultValue);
	const _compute = import_react.useRef(compute);
	const _prevControl = import_react.useRef(control);
	const _prevName = import_react.useRef(name);
	_compute.current = compute;
	const getInitialOutput = () => {
		const defaultValue = control._getWatch(name, _defaultValue.current);
		return _compute.current ? _compute.current(defaultValue) : defaultValue;
	};
	const [value, updateValue] = import_react.useState(getInitialOutput);
	const _computeFormValues = import_react.useRef(value);
	const getCurrentOutput = import_react.useCallback((values) => {
		const formValues = generateWatchOutput(name, control._names, values || control._formValues, false, _defaultValue.current);
		return _compute.current ? _compute.current(formValues) : formValues;
	}, [
		control._formValues,
		control._names,
		name
	]);
	const refreshValue = import_react.useCallback((values) => {
		if (!disabled) {
			const formValues = generateWatchOutput(name, control._names, values || control._formValues, false, _defaultValue.current);
			if (_compute.current) {
				const computedFormValues = _compute.current(formValues);
				if (!deepEqual(computedFormValues, _computeFormValues.current)) {
					updateValue(computedFormValues);
					_computeFormValues.current = computedFormValues;
				}
			} else {
				updateValue(formValues);
				_computeFormValues.current = formValues;
			}
		}
	}, [
		control._formValues,
		control._names,
		disabled,
		name
	]);
	const { resyncIfNeeded, snapshot } = useResyncOnReconnect(getInitialOutput);
	const _refreshValue = import_react.useRef(refreshValue);
	_refreshValue.current = refreshValue;
	const _getCurrentOutput = import_react.useRef(getCurrentOutput);
	_getCurrentOutput.current = getCurrentOutput;
	useIsomorphicLayoutEffect(() => {
		if (_prevControl.current !== control || !deepEqual(_prevName.current, name)) {
			_prevControl.current = control;
			_prevName.current = name;
			_refreshValue.current();
		} else resyncIfNeeded(!disabled, () => _getCurrentOutput.current(), (currentValue) => {
			const nextValue = cloneObject(currentValue);
			updateValue(nextValue);
			_computeFormValues.current = nextValue;
		});
		const unsubscribe = control._subscribe({
			name,
			formState: { values: true },
			exact,
			callback: (formState) => {
				_refreshValue.current(formState.values);
			}
		});
		return () => {
			unsubscribe();
			snapshot(!disabled, () => _getCurrentOutput.current());
		};
	}, [
		control,
		exact,
		name,
		disabled,
		resyncIfNeeded,
		snapshot
	]);
	import_react.useEffect(() => control._removeUnmounted());
	const controlChanged = _prevControl.current !== control;
	const prevName = _prevName.current;
	const nameChanged = import_react.useMemo(() => !controlChanged && !deepEqual(prevName, name), [
		controlChanged,
		name,
		prevName
	]);
	if (controlChanged || nameChanged) _defaultValue.current = defaultValue;
	return !disabled && (controlChanged || nameChanged) ? getCurrentOutput() : value;
}
/**
* Hook for controlled inputs. Returns `field`, `fieldState`, and `formState`.
* Re-renders are isolated to the hook level.
*
* @see [API](https://react-hook-form.com/docs/usecontroller)
*
* @example
* ```tsx
* const { field, fieldState } = useController({ control, name: "email" });
* return <input {...field} />;
* ```
*/
function useController(props) {
	const formControl = useFormControlContext();
	const { name, disabled, control = formControl, shouldUnregister, defaultValue, exact = true } = props;
	const isArrayField = isNameInFieldArray(control._names.array, name);
	const value = useWatch({
		control,
		name,
		defaultValue: import_react.useMemo(() => {
			const resolved = get(control._formValues, name, get(control._defaultValues, name, defaultValue));
			return isUndefined(resolved) ? getNullAncestorValue(control, name) : resolved;
		}, [
			control,
			name,
			defaultValue
		]),
		exact
	});
	const formState = useFormState({
		control,
		name,
		exact
	});
	const _props = import_react.useRef(props);
	const _shouldUnregister = import_react.useRef(shouldUnregister);
	const _proxyRef = import_react.useRef(null);
	const _registeredName = import_react.useRef(void 0);
	const _registerProps = import_react.useRef(control.register(name, {
		...props.rules,
		value: _registeredName.current === name && !get(control._fields, name) ? void 0 : value,
		...isBoolean(props.disabled) ? { disabled: props.disabled } : {}
	}));
	_registeredName.current = name;
	_props.current = props;
	const fieldState = import_react.useMemo(() => Object.defineProperties({}, {
		invalid: {
			enumerable: true,
			get: () => !!get(formState.errors, name)
		},
		isDirty: {
			enumerable: true,
			get: () => !!get(formState.dirtyFields, name)
		},
		isTouched: {
			enumerable: true,
			get: () => !!get(formState.touchedFields, name)
		},
		isValidating: {
			enumerable: true,
			get: () => !!get(formState.validatingFields, name)
		},
		error: {
			enumerable: true,
			get: () => get(formState.errors, name)
		}
	}), [formState, name]);
	const onChange = import_react.useCallback((event) => {
		const value = getEventValue(event);
		if (!get(control._fields, name)) _registerProps.current = control.register(name, {
			..._props.current.rules,
			value
		});
		return _registerProps.current.onChange({
			target: {
				value: getEventValue(event),
				name
			},
			type: EVENTS.CHANGE
		});
	}, [name, control]);
	const onBlur = import_react.useCallback(() => {
		const value = get(control._formValues, name);
		if (!get(control._fields, name)) _registerProps.current = control.register(name, {
			..._props.current.rules,
			value
		});
		return _registerProps.current.onBlur({
			target: {
				value,
				name
			},
			type: EVENTS.BLUR
		});
	}, [name, control]);
	const ref = import_react.useCallback((elm) => {
		if (elm) _proxyRef.current = {
			focus: () => isFunction(elm.focus) && elm.focus(),
			select: () => isFunction(elm.select) && elm.select(),
			setCustomValidity: (message) => isFunction(elm.setCustomValidity) && elm.setCustomValidity(message),
			reportValidity: () => isFunction(elm.reportValidity) && elm.reportValidity()
		};
		const field = get(control._fields, name);
		if (field && field._f && elm) {
			field._f.ref = _proxyRef.current;
			field._f._c = true;
		}
	}, [control._fields, name]);
	const field = import_react.useMemo(() => ({
		name,
		value,
		...isBoolean(disabled) || formState.disabled ? { disabled: formState.disabled || disabled } : {},
		onChange,
		onBlur,
		ref
	}), [
		name,
		disabled,
		formState.disabled,
		onChange,
		onBlur,
		ref,
		value
	]);
	import_react.useEffect(() => {
		_shouldUnregister.current = shouldUnregister;
		if (control._options.shouldUnregister || shouldUnregister) {
			const value = cloneObject(get(shouldUnregister ? control._defaultValues : control._options.values || control._defaultValues, name, get(control._options.defaultValues, name, _props.current.defaultValue)));
			set(control._defaultValues, name, value);
			if (isUndefined(get(control._formValues, name))) set(control._formValues, name, value);
		} else if (!isArrayField && !isUndefined(_props.current.defaultValue) && isUndefined(get(control._defaultValues, name))) {
			set(control._defaultValues, name, cloneObject(_props.current.defaultValue));
			control._subjects.state.next({ defaultValues: control._defaultValues });
		}
	}, [
		control,
		name,
		isArrayField,
		shouldUnregister
	]);
	import_react.useEffect(() => {
		_registerProps.current = control.register(name, {
			..._props.current.rules,
			...isBoolean(_props.current.disabled) ? { disabled: _props.current.disabled } : {}
		});
		const updateMounted = (name, value) => {
			const field = get(control._fields, name);
			if (field && field._f) {
				field._f.mount = value;
				field._f._c = value;
			}
		};
		updateMounted(name, true);
		!isArrayField && control.register(name, {
			..._props.current.rules,
			...isBoolean(_props.current.disabled) ? { disabled: _props.current.disabled } : {}
		});
		if (_proxyRef.current) {
			const field = get(control._fields, name);
			if (field && field._f) field._f.ref = _proxyRef.current;
		}
		return () => {
			const shouldUnregisterField = control._options.shouldUnregister || _shouldUnregister.current;
			(isArrayField ? shouldUnregisterField && !control._state.action : shouldUnregisterField) ? control.unregister(name) : updateMounted(name, false);
		};
	}, [
		name,
		control,
		isArrayField
	]);
	import_react.useEffect(() => {
		control._setDisabledField({
			disabled,
			name
		});
	}, [
		disabled,
		name,
		control
	]);
	return import_react.useMemo(() => ({
		field,
		formState,
		fieldState
	}), [
		field,
		formState,
		fieldState
	]);
}
/**
* Component wrapper around `useController` for controlled inputs.
*
* @see [API](https://react-hook-form.com/docs/usecontroller/controller)
*
* @example
* ```tsx
* <Controller
*   control={control}
*   name="test"
*   render={({ field, fieldState, formState }) => <input {...field} />}
* />
* ```
*/
var Controller = (props) => props.render(useController(props));
/**
* Displays the validation error for a single field.
* Reads from `control` when provided, otherwise from the nearest `FormProvider`.
*
* @see [API](https://react-hook-form.com/docs/useformstate/errormessage)
*
* @example
* ```tsx
* <ErrorMessage control={control} name="email" as="p" />
* <ErrorMessage name="email" as="span" />
* <ErrorMessage control={control} name="email"
*   render={({ message }) => <Alert>{message}</Alert>} />
* ```
*/
var ErrorMessage = ({ as, control, name, render }) => {
	const { errors } = useFormState({
		control,
		name
	});
	const error = get(errors, name);
	if (!error) return null;
	const message = error.message || "";
	if (render) return render({
		message,
		messages: error.types
	});
	return import_react.createElement(as || import_react.Fragment, null, message);
};
var generateId = () => typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
	const r = Math.random() * 16 | 0;
	return (c === "x" ? r : r & 3 | 8).toString(16);
});
var getFocusFieldName = (name, index, options = {}) => options.shouldFocus || isUndefined(options.shouldFocus) ? options.focusName || `${name}.${isUndefined(options.focusIndex) ? index : options.focusIndex}.` : "";
var getValidationModes = (mode) => ({
	isOnSubmit: !mode || mode === VALIDATION_MODE.onSubmit,
	isOnBlur: mode === VALIDATION_MODE.onBlur,
	isOnChange: mode === VALIDATION_MODE.onChange,
	isOnAll: mode === VALIDATION_MODE.all,
	isOnTouch: mode === VALIDATION_MODE.onTouched
});
var isWatched = (name, _names, isBlurEvent) => {
	if (isBlurEvent) return false;
	if (_names.watchAll || _names.watch.has(name)) return true;
	for (const watchName of _names.watch) if (name.startsWith(watchName) && name.charAt(watchName.length) === ".") return true;
	return false;
};
var iterateFieldsByAction = (fields, action, fieldsNames) => {
	var _a;
	for (const key of fieldsNames || Object.keys(fields)) {
		if (key === "_f") continue;
		const field = fieldsNames ? get(fields, key) : fields[key];
		if (field) {
			const { _f } = field;
			if (_f) {
				const groupRef = (_a = _f.refs) === null || _a === void 0 ? void 0 : _a.find((ref) => !ref.disabled);
				if (groupRef && action(groupRef, _f.name)) return true;
				else if (_f.ref && action(_f.ref, _f.name)) return true;
				else if (iterateFieldsByAction(field, action)) return true;
			} else if (isObject(field) || Array.isArray(field)) {
				if (iterateFieldsByAction(field, action)) return true;
			}
		}
	}
};
var updateFieldArrayRootError = (errors, error, name) => {
	const existingErrors = get(errors, name);
	const fieldArrayErrors = Array.isArray(existingErrors) ? existingErrors : [];
	set(fieldArrayErrors, ROOT_ERROR_TYPE, get(error[name], ROOT_ERROR_TYPE, error[name]));
	set(errors, name, fieldArrayErrors);
	return errors;
};
var isEmptyObject = (value) => isObject(value) && !Object.keys(value).length;
var isHTMLElement = (value) => {
	if (!isWeb) return false;
	const owner = value ? value.ownerDocument : 0;
	return value instanceof (owner && owner.defaultView ? owner.defaultView.HTMLElement : HTMLElement);
};
var isRadioInput = (element) => element.type === "radio";
var isRegex = (value) => value instanceof RegExp;
var appendErrors = (name, validateAllFieldCriteria, errors, type, message) => validateAllFieldCriteria ? {
	...errors[name],
	types: {
		...errors[name] && errors[name].types ? errors[name].types : {},
		[type]: message || true
	}
} : {};
var defaultResult = {
	value: false,
	isValid: false
};
var validResult = {
	value: true,
	isValid: true
};
var getCheckboxValue = (options) => {
	if (!Array.isArray(options)) return defaultResult;
	if (options.length > 1) {
		const values = options.filter((option) => option && option.checked && !option.disabled).map((option) => option.value);
		return {
			value: values,
			isValid: !!values.length
		};
	}
	const option = options[0];
	if (!option || !option.checked || option.disabled) return defaultResult;
	if (!option.attributes || !("value" in option.attributes)) return validResult;
	return isUndefined(option.value) || option.value === "" ? validResult : {
		value: option.value,
		isValid: true
	};
};
var defaultReturn = {
	isValid: false,
	value: null
};
var getRadioValue = (options) => Array.isArray(options) ? options.reduce((previous, option) => option && option.checked && !option.disabled ? {
	isValid: true,
	value: option.value
} : previous, defaultReturn) : defaultReturn;
function getValidateError(result, ref, type = "validate") {
	if (isString(result) || Array.isArray(result) && !!result.length && result.every(isString) || isBoolean(result) && !result) return {
		type,
		message: isString(result) ? result : "",
		ref
	};
}
var getValueAndMessage = (validationData) => isObject(validationData) && !isRegex(validationData) ? validationData : {
	value: validationData,
	message: ""
};
var validateField = async (field, disabledFieldNames, formValues, validateAllFieldCriteria, shouldUseNativeValidation, isFieldArray) => {
	const { ref, refs, required, maxLength, minLength, min, max, pattern, validate, name, valueAsNumber, mount, _c } = field._f;
	const inputValue = get(formValues, name);
	if (!mount || disabledFieldNames.has(name)) return {};
	const inputRef = refs ? refs[0] : ref;
	const setCustomValidity = (message) => {
		if (shouldUseNativeValidation && inputRef.reportValidity) {
			const validityMessage = isBoolean(message) ? "" : message || "";
			if (refs) refs.forEach((ref) => isFunction(ref.setCustomValidity) && ref.setCustomValidity(validityMessage));
			else inputRef.setCustomValidity(validityMessage);
			inputRef.reportValidity();
		}
	};
	const error = {};
	const isRadio = !_c && isRadioInput(ref);
	const isCheckBox = !_c && isCheckBoxInput(ref);
	const isRadioOrCheckbox = isRadio || isCheckBox;
	const isEmpty = (valueAsNumber || isFileInput(ref)) && isUndefined(ref.value) && isUndefined(inputValue) || isHTMLElement(ref) && ref.value === "" && !_c || inputValue === "" || Array.isArray(inputValue) && !inputValue.length;
	const appendErrorsCurry = appendErrors.bind(null, name, validateAllFieldCriteria, error);
	const getMinMaxMessage = (exceedMax, maxLengthMessage, minLengthMessage, maxType = INPUT_VALIDATION_RULES.maxLength, minType = INPUT_VALIDATION_RULES.minLength) => {
		const message = exceedMax ? maxLengthMessage : minLengthMessage;
		error[name] = {
			type: exceedMax ? maxType : minType,
			message,
			ref,
			...appendErrorsCurry(exceedMax ? maxType : minType, message)
		};
	};
	if (isFieldArray ? !Array.isArray(inputValue) || !inputValue.length : required && (!isRadioOrCheckbox && (isEmpty || isNullOrUndefined(inputValue)) || isBoolean(inputValue) && !inputValue || isCheckBox && !getCheckboxValue(refs).isValid || isRadio && !getRadioValue(refs).isValid)) {
		const { value, message } = isString(required) ? {
			value: !!required,
			message: required
		} : getValueAndMessage(required);
		if (value) {
			error[name] = {
				type: INPUT_VALIDATION_RULES.required,
				message,
				ref: inputRef,
				...appendErrorsCurry(INPUT_VALIDATION_RULES.required, message)
			};
			if (!validateAllFieldCriteria) {
				setCustomValidity(message);
				return error;
			}
		}
	}
	if (!isEmpty && (!isNullOrUndefined(min) || !isNullOrUndefined(max))) {
		let exceedMax;
		let exceedMin;
		const maxOutput = getValueAndMessage(max);
		const minOutput = getValueAndMessage(min);
		if (!isNullOrUndefined(inputValue) && !isDateObject(inputValue) && !isNaN(inputValue)) {
			const valueNumber = !_c && ref.valueAsNumber || (inputValue ? +inputValue : inputValue);
			if (!isNullOrUndefined(maxOutput.value)) exceedMax = valueNumber > maxOutput.value;
			if (!isNullOrUndefined(minOutput.value)) exceedMin = valueNumber < minOutput.value;
		} else {
			const valueDate = !_c && ref.valueAsDate || new Date(inputValue);
			const convertTimeToDate = (time) => /* @__PURE__ */ new Date((/* @__PURE__ */ new Date()).toDateString() + " " + time);
			const isTime = ref.type == "time";
			const isWeek = ref.type == "week";
			if (isString(maxOutput.value) && inputValue) exceedMax = isTime ? convertTimeToDate(inputValue) > convertTimeToDate(maxOutput.value) : isWeek ? inputValue > maxOutput.value : valueDate > new Date(maxOutput.value);
			if (isString(minOutput.value) && inputValue) exceedMin = isTime ? convertTimeToDate(inputValue) < convertTimeToDate(minOutput.value) : isWeek ? inputValue < minOutput.value : valueDate < new Date(minOutput.value);
		}
		if (exceedMax || exceedMin) {
			getMinMaxMessage(!!exceedMax, maxOutput.message, minOutput.message, INPUT_VALIDATION_RULES.max, INPUT_VALIDATION_RULES.min);
			if (!validateAllFieldCriteria) {
				setCustomValidity(error[name].message);
				return error;
			}
		}
	}
	if ((!isNullOrUndefined(maxLength) || !isNullOrUndefined(minLength)) && !isEmpty && (isString(inputValue) || isFieldArray && Array.isArray(inputValue))) {
		const maxLengthOutput = getValueAndMessage(maxLength);
		const minLengthOutput = getValueAndMessage(minLength);
		const exceedMax = !isNullOrUndefined(maxLengthOutput.value) && inputValue.length > +maxLengthOutput.value;
		const exceedMin = !isNullOrUndefined(minLengthOutput.value) && inputValue.length < +minLengthOutput.value;
		if (exceedMax || exceedMin) {
			getMinMaxMessage(exceedMax, maxLengthOutput.message, minLengthOutput.message);
			if (!validateAllFieldCriteria) {
				setCustomValidity(error[name].message);
				return error;
			}
		}
	}
	if (pattern && !isEmpty && isString(inputValue)) {
		const { value: patternValue, message } = getValueAndMessage(pattern);
		if (isRegex(patternValue) && !inputValue.match(patternValue)) {
			error[name] = {
				type: INPUT_VALIDATION_RULES.pattern,
				message,
				ref,
				...appendErrorsCurry(INPUT_VALIDATION_RULES.pattern, message)
			};
			if (!validateAllFieldCriteria) {
				setCustomValidity(message);
				return error;
			}
		}
	}
	if (validate) {
		if (isFunction(validate)) {
			const validateError = getValidateError(await validate(inputValue, formValues), inputRef);
			if (validateError) {
				error[name] = {
					...validateError,
					...appendErrorsCurry(INPUT_VALIDATION_RULES.validate, validateError.message)
				};
				if (!validateAllFieldCriteria) {
					setCustomValidity(validateError.message);
					return error;
				}
			}
		} else if (isObject(validate)) {
			let validationResult = {};
			for (const key in validate) {
				if (!isEmptyObject(validationResult) && !validateAllFieldCriteria) break;
				const validateError = getValidateError(await validate[key](inputValue, formValues), inputRef, key);
				if (validateError) {
					validationResult = {
						...validateError,
						...appendErrorsCurry(key, validateError.message)
					};
					if (!validateAllFieldCriteria) setCustomValidity(validateError.message);
					if (validateAllFieldCriteria) error[name] = validationResult;
				}
			}
			if (!isEmptyObject(validationResult)) {
				error[name] = {
					ref: inputRef,
					...validationResult
				};
				if (!validateAllFieldCriteria) return error;
			}
		}
	}
	const fieldError = error[name];
	setCustomValidity(fieldError ? fieldError.message : true);
	return error;
};
var convertToArrayPayload = (value) => Array.isArray(value) ? value : [value];
var appendAt = (data, value) => [...data, ...convertToArrayPayload(value)];
var fillEmptyArray = (value) => Array.isArray(value) ? value.map(() => void 0) : void 0;
function insert(data, index, value) {
	return [
		...data.slice(0, index),
		...convertToArrayPayload(value),
		...data.slice(index)
	];
}
var moveArrayAt = (data, from, to) => {
	if (!Array.isArray(data)) return [];
	if (isUndefined(data[to])) data[to] = void 0;
	data.splice(to, 0, data.splice(from, 1)[0]);
	return data;
};
var prependAt = (data, value) => [...convertToArrayPayload(value), ...convertToArrayPayload(data)];
var compact = (value) => Array.isArray(value) ? value.filter(Boolean) : [];
function removeAtIndexes(data, indexes) {
	let i = 0;
	const temp = [...data];
	for (const index of indexes) {
		temp.splice(index - i, 1);
		i++;
	}
	return compact(temp).length ? temp : [];
}
var removeArrayAt = (data, index) => isUndefined(index) ? [] : removeAtIndexes(data, [...new Set(convertToArrayPayload(index))].sort((a, b) => a - b));
var swapArrayAt = (data, indexA, indexB) => {
	[data[indexA], data[indexB]] = [data[indexB], data[indexA]];
};
function baseGet(object, updatePath) {
	const length = updatePath.length - 1;
	let index = 0;
	while (index < length) {
		if (isNullOrUndefined(object)) {
			object = void 0;
			break;
		}
		object = object[updatePath[index]];
		index++;
	}
	return object;
}
function isEmptyArray(obj) {
	for (const key in obj) if (obj.hasOwnProperty(key) && !isUndefined(obj[key])) return false;
	return true;
}
function unset(object, path) {
	if (!isObject(object) && !Array.isArray(object)) return object;
	if (isString(path) && Object.prototype.hasOwnProperty.call(object, path)) {
		delete object[path];
		return object;
	}
	const paths = Array.isArray(path) ? path : isKey(path) ? [path] : stringToPath(path);
	if (paths.some((segment) => PROTOTYPE_KEYWORDS.includes(String(segment)))) return object;
	const childObject = paths.length === 1 ? object : baseGet(object, paths);
	const index = paths.length - 1;
	const key = paths[index];
	if (childObject && (isObject(childObject) || Array.isArray(childObject))) delete childObject[key];
	if (index !== 0 && (isObject(childObject) && isEmptyObject(childObject) || Array.isArray(childObject) && isEmptyArray(childObject))) unset(object, paths.slice(0, -1));
	return object;
}
var updateAt = (fieldValues, index, value) => {
	fieldValues[index] = value;
	return fieldValues;
};
/**
* Hook for dynamic field arrays. Provides `fields` and mutation methods:
* `append`, `prepend`, `remove`, `insert`, `swap`, `move`, `update`, `replace`.
*
* @see [API](https://react-hook-form.com/docs/usefieldarray)
*
* @example
* ```tsx
* const { fields, append } = useFieldArray({ control, name: "items" });
* return fields.map((f, i) => <input key={f.id} {...register(`items.${i}.name`)} />);
* ```
*/
function useFieldArray(props) {
	const formControl = useFormControlContext();
	const { control = formControl, name, keyName = "id", disabled, shouldUnregister, rules } = props;
	const getCurrentFieldArray = () => control._getFieldArray(name);
	const [fields, setFields] = import_react.useState(getCurrentFieldArray);
	const ids = import_react.useRef(control._getFieldArray(name).map(generateId));
	const _actioned = import_react.useRef(false);
	const { resyncIfNeeded, snapshot } = useResyncOnReconnect(getCurrentFieldArray);
	const _prevControl = import_react.useRef(control);
	const _prevName = import_react.useRef(name);
	const _rules = import_react.useRef({
		control,
		name,
		rules
	});
	if (!disabled) control._names.array.add(name);
	import_react.useMemo(() => {
		if (!disabled && fields) {
			if (rules || _rules.current.rules && _rules.current.control === control && _rules.current.name === name) control.register(name, rules);
			_rules.current = {
				control,
				name,
				rules
			};
		}
	}, [
		control,
		name,
		fields,
		rules,
		disabled
	]);
	useIsomorphicLayoutEffect(() => {
		if (disabled) return;
		if (_prevControl.current === control && _prevName.current === name) resyncIfNeeded(true, getCurrentFieldArray, (fieldValues) => {
			setFields(fieldValues);
			ids.current = fieldValues.map(generateId);
		});
		else {
			_prevControl.current = control;
			_prevName.current = name;
			const fieldValues = getCurrentFieldArray();
			if (!deepEqual(fields, fieldValues)) {
				setFields(fieldValues);
				ids.current = fieldValues.map(generateId);
			}
			snapshot(true, getCurrentFieldArray);
		}
		const unsubscribe = control._subjects.array.subscribe({ next: ({ values, name: fieldArrayName }) => {
			if (fieldArrayName === name || !fieldArrayName) {
				const fieldValues = get(values, name);
				if (Array.isArray(fieldValues)) {
					setFields(fieldValues);
					ids.current = fieldValues.map(generateId);
				} else if (!fieldArrayName) {
					setFields([]);
					ids.current = [];
				}
			}
		} }).unsubscribe;
		return () => {
			unsubscribe();
			snapshot(true, getCurrentFieldArray);
		};
	}, [
		control,
		name,
		disabled,
		resyncIfNeeded,
		snapshot
	]);
	const updateValues = import_react.useCallback((updatedFieldArrayValues) => {
		_actioned.current = true;
		control._setFieldArray(name, updatedFieldArrayValues);
	}, [control, name]);
	const append = (value, options) => {
		if (disabled) return;
		const appendValue = convertToArrayPayload(cloneObject(value));
		const updatedFieldArrayValues = appendAt(control._getFieldArray(name), appendValue);
		control._names.focus = getFocusFieldName(name, updatedFieldArrayValues.length - 1, options);
		ids.current = appendAt(ids.current, appendValue.map(generateId));
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, appendAt, { argA: fillEmptyArray(value) });
	};
	const prepend = (value, options) => {
		if (disabled) return;
		const prependValue = convertToArrayPayload(cloneObject(value));
		const updatedFieldArrayValues = prependAt(control._getFieldArray(name), prependValue);
		control._names.focus = getFocusFieldName(name, 0, options);
		ids.current = prependAt(ids.current, prependValue.map(generateId));
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, prependAt, { argA: fillEmptyArray(value) });
	};
	const remove = (index) => {
		if (disabled) return;
		const updatedFieldArrayValues = removeArrayAt(control._getFieldArray(name), index);
		ids.current = removeArrayAt(ids.current, index);
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		!Array.isArray(get(control._fields, name)) && set(control._fields, name, void 0);
		control._setFieldArray(name, updatedFieldArrayValues, removeArrayAt, { argA: index });
	};
	const insert$1 = (index, value, options) => {
		if (disabled) return;
		const insertValue = convertToArrayPayload(cloneObject(value));
		const updatedFieldArrayValues = insert(control._getFieldArray(name), index, insertValue);
		control._names.focus = getFocusFieldName(name, index, options);
		ids.current = insert(ids.current, index, insertValue.map(generateId));
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, insert, {
			argA: index,
			argB: fillEmptyArray(value)
		});
	};
	const swap = (indexA, indexB) => {
		if (disabled) return;
		const updatedFieldArrayValues = control._getFieldArray(name);
		swapArrayAt(updatedFieldArrayValues, indexA, indexB);
		swapArrayAt(ids.current, indexA, indexB);
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, swapArrayAt, {
			argA: indexA,
			argB: indexB
		}, false);
	};
	const move = (from, to) => {
		if (disabled) return;
		const updatedFieldArrayValues = control._getFieldArray(name);
		moveArrayAt(updatedFieldArrayValues, from, to);
		moveArrayAt(ids.current, from, to);
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, moveArrayAt, {
			argA: from,
			argB: to
		}, false);
	};
	const update = (index, value) => {
		if (disabled) return;
		const updateValue = cloneObject(value);
		const updatedFieldArrayValues = updateAt(control._getFieldArray(name), index, updateValue);
		ids.current = [...updatedFieldArrayValues].map((item, i) => !item || i === index ? generateId() : ids.current[i]);
		updateValues(updatedFieldArrayValues);
		setFields([...updatedFieldArrayValues]);
		control._setFieldArray(name, updatedFieldArrayValues, updateAt, {
			argA: index,
			argB: fillEmptyArray(value)
		});
	};
	const replace = (value) => {
		if (disabled) return;
		const updatedFieldArrayValues = convertToArrayPayload(cloneObject(value));
		ids.current = updatedFieldArrayValues.map(generateId);
		updateValues([...updatedFieldArrayValues]);
		setFields([...updatedFieldArrayValues]);
		control._setFieldArray(name, [...updatedFieldArrayValues], (data) => Array.isArray(data) ? data.slice(0, updatedFieldArrayValues.length) : data, {});
	};
	import_react.useEffect(() => {
		if (disabled) {
			control._state.actionArrayLengths.delete(name);
			return;
		}
		control._state.action = false;
		control._state.actionArrayLengths.delete(name);
		isWatched(name, control._names) && control._subjects.state.next({ ...control._formState });
		const validationModes = getValidationModes(control._options.mode);
		const reValidateModes = getValidationModes(control._options.reValidateMode);
		if (_actioned.current && (!validationModes.isOnSubmit || control._formState.isSubmitted) && !(control._formState.isSubmitted && reValidateModes.isOnSubmit) && (!validationModes.isOnBlur || control._formState.isSubmitted && reValidateModes.isOnChange)) {
			const fieldArrayValues = get(control._formValues, name);
			if (control._options.resolver) control._runSchema([name]).then((result) => {
				control._updateIsValidating([name]);
				if (fieldArrayValues !== get(control._formValues, name)) return;
				const error = get(result.errors, name);
				if (!deepEqual(get(control._formState.errors, name), error, true)) {
					if (error) isObject(error) && !Object.keys(error).some((key) => !Number.isNaN(+key)) ? updateFieldArrayRootError(control._formState.errors, { [name]: error }, name) : set(control._formState.errors, name, error);
					else unset(control._formState.errors, name);
					control._formState.errors = { ...control._formState.errors };
					control._subjects.state.next({ errors: control._formState.errors });
				}
			});
			else {
				const field = get(control._fields, name);
				if (field && field._f) validateField(field, control._names.disabled, control._formValues, control._options.criteriaMode === VALIDATION_MODE.all, control._options.shouldUseNativeValidation, true).then((error) => {
					if (fieldArrayValues !== get(control._formValues, name)) return;
					if (!isEmptyObject(error)) {
						updateFieldArrayRootError(control._formState.errors, error, name);
						control._formState.errors = { ...control._formState.errors };
						control._subjects.state.next({ errors: control._formState.errors });
					} else {
						const existingError = get(control._formState.errors, name);
						if (existingError && existingError[ROOT_ERROR_TYPE]) {
							unset(control._formState.errors, `${name}.${ROOT_ERROR_TYPE}`);
							control._formState.errors = { ...control._formState.errors };
							control._subjects.state.next({ errors: control._formState.errors });
						}
					}
				});
			}
		}
		_actioned.current && control._subjects.state.next({
			name,
			values: cloneObject(control._formValues)
		});
		control._names.focus && iterateFieldsByAction(control._fields, (ref, key) => {
			if (control._names.focus && key.startsWith(control._names.focus) && ref.focus) {
				ref.focus();
				return 1;
			}
		});
		control._names.focus = "";
		control._setValid();
		_actioned.current = false;
	}, [
		fields,
		name,
		control,
		disabled
	]);
	import_react.useEffect(() => {
		if (!disabled) isUndefined(get(control._formValues, name)) && control._setFieldArray(name);
		return () => {
			control._state.actionArrayLengths.delete(name);
			control._state.actionArrayLengths.size || (control._state.action = false);
			if (disabled) return;
			const shouldKeepFieldArrayValues = !(control._options.shouldUnregister || shouldUnregister);
			const updateMounted = (name, value) => {
				const field = get(control._fields, name);
				if (field && field._f) field._f.mount = value;
			};
			if (_actioned.current && shouldKeepFieldArrayValues) control._subjects.state.next({
				name,
				values: cloneObject(control._formValues)
			});
			if (!shouldKeepFieldArrayValues && control._state.action && [...control._state.actionArrayLengths.keys()].some((arrayName) => name.startsWith(arrayName + "."))) return;
			shouldKeepFieldArrayValues ? updateMounted(name, false) : control.unregister(name);
		};
	}, [
		name,
		control,
		keyName,
		shouldUnregister,
		disabled
	]);
	return {
		swap: import_react.useCallback(swap, [
			updateValues,
			name,
			control,
			disabled
		]),
		move: import_react.useCallback(move, [
			updateValues,
			name,
			control,
			disabled
		]),
		prepend: import_react.useCallback(prepend, [
			updateValues,
			name,
			control,
			disabled
		]),
		append: import_react.useCallback(append, [
			updateValues,
			name,
			control,
			disabled
		]),
		remove: import_react.useCallback(remove, [
			updateValues,
			name,
			control,
			disabled
		]),
		insert: import_react.useCallback(insert$1, [
			updateValues,
			name,
			control,
			disabled
		]),
		update: import_react.useCallback(update, [
			updateValues,
			name,
			control,
			disabled
		]),
		replace: import_react.useCallback(replace, [
			updateValues,
			name,
			control,
			disabled
		]),
		fields: import_react.useMemo(() => fields.map((field, index) => ({
			...field,
			...isBoolean(disabled) ? { disabled } : {},
			[keyName]: ids.current[index] || generateId()
		})), [
			fields,
			keyName,
			disabled
		])
	};
}
/**
* Component based on `useFieldArray` hook to work with controlled component.
*
* @example
* ```tsx
* function App() {
*   const { control, register } = useForm<FormValues>({
*     defaultValues: {
*       test: [
*         {
*           value: '',
*         },
*       ],
*     },
*   });
*
*   return (
*     <form>
*       <FieldArray
*         control={control}
*         name="test"
*         render={({ fields }) =>
*           fields.map((field, index) => (
*             <input key={field.id} {...register(`test.${index}.value`)} />
*           ))
*         }
*       />
*     </form>
*   );
* }
* ```
*/
var FieldArray = (props) => props.render(useFieldArray(props));
var isFileLike = (value) => typeof Blob !== "undefined" && value instanceof Blob || typeof File !== "undefined" && value instanceof File;
var isFileListLike = (value) => typeof FileList !== "undefined" && value instanceof FileList;
var flatten = (obj) => {
	const output = {};
	for (const key of Object.keys(obj)) if (isObjectType(obj[key]) && obj[key] !== null && !isDateObject(obj[key]) && !isFileLike(obj[key]) && !isFileListLike(obj[key])) {
		const nested = flatten(obj[key]);
		for (const nestedKey of Object.keys(nested)) output[`${key}.${nestedKey}`] = nested[nestedKey];
	} else output[key] = obj[key];
	return output;
};
function jsonToFormData(json) {
	const result = new FormData();
	const flattenFormValues = flatten(json);
	for (const key in flattenFormValues) {
		const value = flattenFormValues[key];
		if (isUndefined(value)) continue;
		if (typeof FileList !== "undefined" && value instanceof FileList) {
			for (let index = 0; index < value.length; index++) {
				const file = value[index];
				file && result.append(key, file);
			}
			continue;
		}
		result.append(key, value);
	}
	return result;
}
function safeJSONStringify(value) {
	try {
		return JSON.stringify(value);
	} catch (_a) {
		return "";
	}
}
function noop() {}
var POST_REQUEST = "post";
function defaultValidateStatus(status) {
	return status >= 200 && status < 300;
}
/**
* Form component that handles submission, including optional `action` fetch and server error wiring.
*
* @see [API](https://react-hook-form.com/docs/useform/form)
*
* @example
* ```tsx
* <Form action="/api" control={control}>
*   <input {...register("name")} />
*   <p>{errors?.root?.server && 'Server error'}</p>
*   <button>Submit</button>
* </Form>
* ```
*/
function Form(props) {
	const formControl = useFormControlContext();
	const [mounted, setMounted] = import_react.useState(false);
	const { control = formControl, onSubmit = noop, children, action, method = POST_REQUEST, headers, encType, onError = noop, render, onSuccess = noop, validateStatus = defaultValidateStatus, ...rest } = props;
	const handleSubmit = import_react.useMemo(() => {
		return control.handleSubmit(async (data, event) => {
			const formData = jsonToFormData(data);
			const formDataJson = safeJSONStringify(data);
			if (onSubmit) await onSubmit({
				data,
				event,
				method,
				formData,
				formDataJson
			});
			if (isString(action)) try {
				const isMultipart = (value) => /^\s*multipart\/form-data\s*(;|$)/i.test(value);
				const contentType = encType && !isMultipart(encType) ? encType : void 0;
				const hasContentType = (type) => contentType ? type.test(contentType) : headers && Object.entries(headers).some(([name, value]) => name.toLowerCase() === "content-type" && type.test(value)) || encType && type.test(encType);
				let body = formData;
				if (hasContentType(/json/i)) body = formDataJson;
				else if (hasContentType(/^\s*application\/x-www-form-urlencoded\s*(;|$)/i)) body = new URLSearchParams(Array.from(formData, ([name, value]) => [name, isString(value) ? value : value.name]));
				else if (hasContentType(/^\s*text\/plain\s*(;|$)/i)) body = Array.from(formData, ([name, value]) => `${name}=${isString(value) ? value : value.name}\r\n`).join("");
				const response = await fetch(action, {
					method,
					headers: {
						...Object.fromEntries(Object.entries(headers || {}).filter(([name, value]) => name.toLowerCase() !== "content-type" || !contentType && !isMultipart(value))),
						...contentType && { "Content-Type": contentType }
					},
					body
				});
				if (response && !validateStatus(response.status)) {
					onError({ response });
					return { type: String(response.status) };
				} else onSuccess({ response });
			} catch (error) {
				onError({ error });
				return { type: "" };
			}
			if (isFunction(action)) try {
				await action(formData);
			} catch (error) {
				onError({ error });
				return { type: "" };
			}
		});
	}, [
		control,
		onSubmit,
		method,
		action,
		headers,
		encType,
		validateStatus,
		onError,
		onSuccess
	]);
	const submit = import_react.useCallback(async (event) => {
		const err = await handleSubmit(event);
		if (err && control) {
			control._subjects.state.next({ isSubmitSuccessful: false });
			control.setError("root.server", err);
		}
	}, [handleSubmit, control]);
	import_react.useEffect(() => {
		setMounted(true);
	}, []);
	if (render) return render({ submit });
	return import_react.createElement("form", {
		noValidate: mounted,
		action,
		...!isFunction(action) && {
			method,
			encType
		},
		onSubmit: submit,
		...rest
	}, children);
}
var FormState = ({ control, disabled, exact, name, render }) => render(useFormState({
	control,
	name,
	disabled,
	exact
}));
/** @deprecated Use `FormState` instead. Kept as an alias for backward compatibility. */
var FormStateSubscribe = FormState;
var createSubject = () => {
	let _observers = /* @__PURE__ */ new Set();
	let _iterationCount = 0;
	const next = (value) => {
		const observers = _observers;
		_iterationCount++;
		for (const observer of observers) observer.next && observer.next(value);
		observers === _observers && _iterationCount--;
	};
	const subscribe = (observer) => {
		_observers.add(observer);
		return { unsubscribe: () => {
			if (_iterationCount) {
				_observers = new Set(_observers);
				_iterationCount = 0;
			}
			_observers.delete(observer);
		} };
	};
	const unsubscribe = () => {
		_observers = /* @__PURE__ */ new Set();
		_iterationCount = 0;
	};
	return {
		get observers() {
			return Array.from(_observers);
		},
		next,
		subscribe,
		unsubscribe
	};
};
function extractFormValues(fieldsState, formValues) {
	const values = Array.isArray(fieldsState) ? [] : {};
	for (const key in fieldsState) if (Object.prototype.hasOwnProperty.call(fieldsState, key)) {
		const fieldState = fieldsState[key];
		const fieldValue = formValues[key];
		if (fieldState && (isObject(fieldState) || Array.isArray(fieldState)) && fieldValue) values[key] = extractFormValues(fieldState, fieldValue);
		else if (fieldsState[key]) values[key] = fieldValue;
	}
	return values;
}
var hasOwn = (value, key) => value !== null && isObjectType(value) && Object.prototype.hasOwnProperty.call(value, key);
var has = (object, path) => {
	if (!path) return false;
	let result = object;
	for (const key of isKey(path) ? [path] : stringToPath(path)) {
		if (!hasOwn(result, key)) return hasOwn(object, path);
		result = result[key];
	}
	return true;
};
var isMultipleSelect = (element) => element.type === `select-multiple`;
var isSelectEdited = (select) => {
	const options = [...select.options];
	return !select.multiple && select.size < 2 && !options.some((option) => option.defaultSelected) ? select.selectedIndex !== options.findIndex((option) => {
		var _a;
		return !option.disabled && !((_a = option.parentElement) === null || _a === void 0 ? void 0 : _a.matches("optgroup[disabled]"));
	}) : options.some((option) => option.selected !== option.defaultSelected);
};
var isEdited = (ref) => isCheckBoxInput(ref) ? ref.checked !== ref.defaultChecked : ref.type === "select-one" || isMultipleSelect(ref) ? isSelectEdited(ref) : !isRadioInput(ref) && ref.type !== "range" && ref.type !== "color" && "defaultValue" in ref && ref.value !== ref.defaultValue;
var isRadioOrCheckbox = (ref) => isRadioInput(ref) || isCheckBoxInput(ref);
var live = (ref) => isHTMLElement(ref) && ref.isConnected;
function isDirtyContainer(value) {
	return Array.isArray(value) || isObject(value);
}
function collectDirtyFieldNames(dirtyTree, cachedDirtyFields, prefix = "", names = []) {
	for (const key in dirtyTree) {
		const path = prefix ? `${prefix}.${key}` : key;
		const value = dirtyTree[key];
		if (isDirtyContainer(value) && isDirtyContainer(get(cachedDirtyFields, path))) collectDirtyFieldNames(value, cachedDirtyFields, path, names);
		else if (value) names.push(path);
	}
	return names;
}
var objectHasFunction = (data) => {
	for (const key in data) if (isFunction(data[key])) return true;
	return false;
};
function isTraversable(value) {
	return Array.isArray(value) || isObject(value) && !objectHasFunction(value);
}
function isRegisteredLeaf(fieldRef) {
	return !!(fieldRef && "_f" in fieldRef);
}
function isEmptyDirtyContainer(value) {
	return Array.isArray(value) ? !value.some((item) => !isUndefined(item)) : !Object.keys(value).length;
}
function clearDirtyField(container, key) {
	if (Array.isArray(container)) container[key] = void 0;
	else delete container[key];
}
function markFieldsDirty(data, fields = {}, fieldRefs) {
	for (const key in data) {
		const value = data[key];
		const fieldRef = fieldRefs && fieldRefs[key];
		if (isTraversable(value) && (!Array.isArray(value) || !isRegisteredLeaf(fieldRef))) {
			fields[key] = Array.isArray(value) ? [] : {};
			markFieldsDirty(value, fields[key], fieldRef);
			if (isEmptyDirtyContainer(fields[key])) clearDirtyField(fields, key);
		} else if (!isUndefined(value)) fields[key] = true;
	}
	return fields;
}
function getDirtyFields(data, formValues, dirtyFieldsFromValues, fieldRefs) {
	if (!dirtyFieldsFromValues) dirtyFieldsFromValues = markFieldsDirty(formValues, Array.isArray(isNullOrUndefined(formValues) ? data : formValues) ? [] : {}, fieldRefs);
	for (const key in data) {
		const value = data[key];
		const fieldRef = fieldRefs && fieldRefs[key];
		if (isTraversable(value) && (!Array.isArray(value) || !isRegisteredLeaf(fieldRef))) {
			if (isUndefined(formValues) || isPrimitive(dirtyFieldsFromValues[key])) dirtyFieldsFromValues[key] = markFieldsDirty(value, Array.isArray(value) ? [] : {}, fieldRef);
			else getDirtyFields(value, isNullOrUndefined(formValues) ? {} : formValues[key], dirtyFieldsFromValues[key], fieldRef);
			if (isEmptyDirtyContainer(dirtyFieldsFromValues[key])) clearDirtyField(dirtyFieldsFromValues, key);
		} else if (deepEqual(value, isNullOrUndefined(formValues) ? void 0 : formValues[key])) clearDirtyField(dirtyFieldsFromValues, key);
		else dirtyFieldsFromValues[key] = true;
	}
	return dirtyFieldsFromValues;
}
var getFieldArrayItemNames = (names, name) => {
	const segments = name.split(".");
	const matches = [];
	let prefix = segments[0];
	for (let i = 1; i < segments.length; prefix += "." + segments[i++]) if (!isNaN(+segments[i]) && names.has(prefix)) matches.push(`${prefix}.${segments[i]}`);
	return matches;
};
var getFieldValueAs = (value, { valueAsNumber, valueAsDate, setValueAs }) => isUndefined(value) ? value : valueAsNumber ? value === "" ? NaN : value ? +value : value : valueAsDate && isString(value) ? new Date(value) : setValueAs ? setValueAs(value) : value;
function getFieldValue(_f) {
	const ref = _f.ref;
	if (isFileInput(ref)) return ref.files;
	if (isRadioInput(ref)) return getRadioValue(_f.refs).value;
	if (isMultipleSelect(ref)) return [...ref.selectedOptions].filter((option) => {
		var _a;
		return !option.disabled && !((_a = option.closest) === null || _a === void 0 ? void 0 : _a.call(option, "optgroup[disabled]"));
	}).map(({ value }) => value);
	if (isCheckBoxInput(ref)) return getCheckboxValue(_f.refs).value;
	return getFieldValueAs(ref.value, _f);
}
var getResolverOptions = (fieldsNames, _fields, criteriaMode, shouldUseNativeValidation) => {
	const fields = {};
	for (const name of fieldsNames) {
		const field = get(_fields, name);
		field && set(fields, name, cloneObject(field._f));
	}
	return {
		criteriaMode,
		names: [...fieldsNames],
		fields,
		shouldUseNativeValidation
	};
};
var getRuleValue = (rule) => isUndefined(rule) ? rule : isRegex(rule) ? rule.source : isObject(rule) ? isRegex(rule.value) ? rule.value.source : rule.value : rule;
var ASYNC_FUNCTION = "AsyncFunction";
var hasPromiseValidation = (fieldReference) => {
	if (!fieldReference || !fieldReference.validate) return false;
	if (isFunction(fieldReference.validate)) return fieldReference.validate.constructor.name === ASYNC_FUNCTION;
	if (isObject(fieldReference.validate)) {
		for (const key in fieldReference.validate) if (fieldReference.validate[key].constructor.name === ASYNC_FUNCTION) return true;
	}
	return false;
};
var hasValidation = (options) => options.mount && (options.required || !isUndefined(options.required) && options.required !== false || !isUndefined(options.min) || !isUndefined(options.max) || !isUndefined(options.maxLength) || !isUndefined(options.minLength) || options.pattern || options.validate);
function schemaErrorLookup(errors, _fields, name) {
	const error = get(errors, name);
	if (error && (error.type || error.message) || Array.isArray(error)) return {
		error,
		name
	};
	const names = name.split(".");
	while (names.length) {
		const fieldName = names.join(".");
		const field = get(_fields, fieldName);
		const foundError = get(errors, fieldName);
		if (field && !Array.isArray(field) && name !== fieldName) return { name };
		if (foundError && foundError.type) return {
			name: fieldName,
			error: foundError
		};
		if (foundError && foundError.root && foundError.root.type) return {
			name: `${fieldName}.root`,
			error: foundError.root
		};
		names.pop();
	}
	return { name };
}
var shouldRenderFormState = (formStateData, _proxyFormState, isRoot) => {
	const keys = Object.keys(formStateData).filter((key) => key !== "name");
	return !keys.length || isRoot && keys.length >= Object.keys(_proxyFormState).length || keys.find((key) => _proxyFormState[key] === (!isRoot || VALIDATION_MODE.all));
};
var isNameMatch = (currentName, signalName, exact) => exact ? currentName === signalName || currentName.startsWith(signalName + ".") : currentName.startsWith(signalName) || signalName.startsWith(currentName);
var shouldSubscribeByName = (name, signalName, exact) => {
	if (!name || !signalName || name === signalName) return true;
	if (!Array.isArray(name)) return isNameMatch(name, signalName, exact);
	for (const currentName of name) if (currentName && isNameMatch(currentName, signalName, exact)) return true;
	return false;
};
var skipValidation = (isBlurEvent, isTouched, isSubmitted, reValidateMode, mode) => {
	if (mode.isOnAll) return false;
	else if (!isSubmitted && mode.isOnTouch) return !(isTouched || isBlurEvent);
	else if (isSubmitted ? reValidateMode.isOnBlur : mode.isOnBlur) return !isBlurEvent;
	else if (isSubmitted ? reValidateMode.isOnChange : mode.isOnChange) return isBlurEvent;
	return true;
};
var unsetEmptyArray = (ref, name) => {
	const array = get(ref, name);
	!compact(array).length && !(array && array.root) && unset(ref, name);
};
var defaultOptions = {
	mode: VALIDATION_MODE.onSubmit,
	reValidateMode: VALIDATION_MODE.onChange,
	shouldFocusError: true
};
var replaceDirtyFieldsInPlace = (dirtyFields, nextDirtyFields) => {
	for (const key in dirtyFields) delete dirtyFields[key];
	Object.assign(dirtyFields, nextDirtyFields);
};
var DEFAULT_FORM_STATE = {
	submitCount: 0,
	isDirty: false,
	isReady: false,
	isValidating: false,
	isSubmitted: false,
	isSubmitting: false,
	isSubmitSuccessful: false,
	isValid: false,
	touchedFields: {},
	dirtyFields: {},
	validatingFields: {}
};
function createFormControl(props = {}) {
	let _options = {
		...defaultOptions,
		...props
	};
	let _formState = {
		...cloneObject(DEFAULT_FORM_STATE),
		isLoading: isFunction(_options.defaultValues),
		errors: cloneObject(_options.errors) || {},
		disabled: _options.disabled || false
	};
	let _fields = {};
	let _defaultValues = isObject(_options.defaultValues) || isObject(_options.values) ? cloneObject(_options.defaultValues || _options.values) || {} : {};
	let _formValues = _options.shouldUnregister ? {} : cloneObject(_defaultValues);
	let _state = {
		action: false,
		actionArrayLengths: /* @__PURE__ */ new Map(),
		mount: false,
		watch: false,
		keepIsValid: false
	};
	let _dirtyFieldsStale = false;
	let _names = {
		mount: /* @__PURE__ */ new Set(),
		disabled: /* @__PURE__ */ new Set(),
		unMount: /* @__PURE__ */ new Set(),
		array: /* @__PURE__ */ new Set(),
		watch: /* @__PURE__ */ new Set(),
		registerName: /* @__PURE__ */ new Set()
	};
	const delayErrorCallbacks = {};
	const timers = {};
	const _valuesSubscribers = /* @__PURE__ */ new Set();
	let _validationModeBeforeSubmit = getValidationModes(_options.mode);
	let _validationModeAfterSubmit = getValidationModes(_options.reValidateMode);
	const defaultProxyFormState = {
		isDirty: false,
		dirtyFields: false,
		validatingFields: false,
		touchedFields: false,
		isValidating: false,
		isValid: false,
		errors: false
	};
	const _proxyFormState = { ...defaultProxyFormState };
	const _proxySubscribeFormState = {};
	const _isTracked = (...keys) => keys.some((key) => _proxyFormState[key] || _proxySubscribeFormState[key]);
	const _hasValuesSubscriber = (name) => {
		for (const subscriber of _valuesSubscribers) if (shouldSubscribeByName(subscriber.name, name, subscriber.exact)) return true;
		return false;
	};
	const _subjects = {
		array: createSubject(),
		state: createSubject()
	};
	let _setValidCallId = 0;
	let _validateFormCallId = 0;
	let _resetCallId = 0;
	let _registerCallId = 0;
	const _registerCallIds = {};
	let shouldDisplayAllAssociatedErrors = _options.criteriaMode === VALIDATION_MODE.all;
	const debounce = (name, callback) => (wait) => {
		clearTimeout(timers[name]);
		timers[name] = setTimeout(callback, wait);
	};
	const cancelDelayedError = (name) => {
		clearTimeout(timers[name]);
		delete timers[name];
		delete delayErrorCallbacks[name];
	};
	const cancelDelayedErrorTree = (name) => {
		cancelDelayedError(name);
		const prefix = `${name}.`;
		for (const key of Object.keys(delayErrorCallbacks)) key.startsWith(prefix) && cancelDelayedError(key);
	};
	const _setValid = async (shouldUpdateValid) => {
		if (_state.keepIsValid) return;
		if (!_options.disabled && (_isTracked("isValid") || shouldUpdateValid)) {
			const callId = ++_setValidCallId;
			const resetCallId = _resetCallId;
			let isValid;
			if (_options.resolver) {
				isValid = isEmptyObject((await _runSchema()).errors);
				callId === _setValidCallId && _updateIsValidating();
			} else isValid = await executeBuiltInValidation({
				fields: _fields,
				onlyCheckValid: true,
				eventType: EVENTS.VALID
			});
			if (callId !== _setValidCallId) return;
			if (resetCallId !== _resetCallId) return _setValid(shouldUpdateValid);
			if (isValid !== _formState.isValid) _subjects.state.next({ isValid });
		}
	};
	const _updateValidatingFields = (names, isValidating) => {
		const fieldNames = [...names];
		if (!fieldNames.some((name) => name && (isValidating ? get(_formState.validatingFields, name) !== true : has(_formState.validatingFields, name)))) return;
		const validatingFields = cloneObject(_formState.validatingFields);
		for (const name of fieldNames) if (name) isValidating ? set(validatingFields, name, true) : unset(validatingFields, name);
		if (!deepEqual(_formState.validatingFields, validatingFields)) _formState.validatingFields = validatingFields;
	};
	const _updateIsValidating = (names, isValidating) => {
		if (!_options.disabled && _isTracked("isValidating", "validatingFields")) {
			_updateValidatingFields(names || _names.mount, isValidating);
			_subjects.state.next({
				validatingFields: _formState.validatingFields,
				isValidating: !isEmptyObject(_formState.validatingFields)
			});
		}
	};
	const _updateDirtyFields = () => {
		_formState.dirtyFields = getDirtyFields(_defaultValues, _formValues, void 0, _fields);
	};
	const _setFieldArray = (name, values = [], method, args, shouldSetValues = true, shouldUpdateFieldsAndState = true) => {
		if (args && method && !_options.disabled) {
			_state.action = true;
			_state.keepIsValid = false;
			const field = get(_fields, name);
			const rootField = field && field._f;
			const fields = rootField ? Object.assign([], field) : field;
			if (!_state.actionArrayLengths.has(name)) _state.actionArrayLengths.set(name, Array.isArray(fields) ? fields.length : 0);
			if (shouldUpdateFieldsAndState && Array.isArray(fields)) {
				const fieldValues = method(fields, args.argA, args.argB) || fields;
				rootField ? set(_fields, name, {
					...fieldValues,
					_f: rootField
				}) : shouldSetValues && set(_fields, name, fieldValues);
			}
			const fieldArrayErrors = get(_formState.errors, name);
			if (shouldUpdateFieldsAndState && Array.isArray(fieldArrayErrors)) {
				const rootError = fieldArrayErrors.root;
				const errors = method(fieldArrayErrors, args.argA, args.argB) || fieldArrayErrors;
				if (rootError) errors.root = rootError;
				shouldSetValues && set(_formState.errors, name, errors);
				unsetEmptyArray(_formState.errors, name);
				_formState.errors = { ..._formState.errors };
			}
			const touchedFieldsArray = get(_formState.touchedFields, name);
			const shouldUpdateTouchedFields = shouldUpdateFieldsAndState && Array.isArray(touchedFieldsArray);
			if (shouldUpdateTouchedFields) {
				const touchedFields = method(touchedFieldsArray, args.argA, args.argB);
				shouldSetValues && set(_formState.touchedFields, name, touchedFields);
			}
			const dirtyFieldsArray = get(_formState.dirtyFields, name);
			if (shouldUpdateFieldsAndState && Array.isArray(dirtyFieldsArray)) {
				const dirtyFields = method(dirtyFieldsArray, args.argA, args.argB) || dirtyFieldsArray;
				shouldSetValues && set(_formState.dirtyFields, name, dirtyFields);
			}
			if (_isTracked("dirtyFields")) _updateDirtyFields();
			else _dirtyFieldsStale = true;
			_subjects.state.next({
				name,
				isDirty: _getDirty(name, values),
				dirtyFields: _formState.dirtyFields,
				...shouldUpdateTouchedFields && { touchedFields: _formState.touchedFields },
				errors: _formState.errors,
				isValid: _formState.isValid
			});
		} else set(_formValues, name, values);
	};
	const updateErrors = (name, error) => {
		set(_formState.errors, name, error);
		_formState.errors = { ..._formState.errors };
		_subjects.state.next({ errors: _formState.errors });
	};
	const _setErrors = (errors) => {
		Object.keys(delayErrorCallbacks).forEach(cancelDelayedError);
		const hasErrors = !isEmptyObject(errors);
		_formState.errors = cloneObject(errors);
		_subjects.state.next({
			errors: _formState.errors,
			...hasErrors ? { isValid: false } : {}
		});
		!hasErrors && _state.mount && _setValid();
	};
	const toPath = (name) => isKey(name) ? [name] : stringToPath(name);
	const hasExplicitNullIntermediate = (name) => {
		const segments = toPath(name);
		let formValues = _formValues;
		let defaultValues = _defaultValues;
		for (let i = 0; i < segments.length - 1; i++) {
			const key = segments[i];
			formValues = isNullOrUndefined(formValues) ? formValues : formValues[key];
			defaultValues = isNullOrUndefined(defaultValues) ? defaultValues : defaultValues[key];
			if (formValues === null && defaultValues !== null) return true;
		}
		return false;
	};
	const isStaleArrayField = (name) => {
		if (!_state.actionArrayLengths.size) return false;
		const segments = toPath(name);
		let node = _formValues;
		let path = "";
		let ownerDepth = -1;
		let ownerPreActionLength = 0;
		for (let i = 0; i < segments.length; i++) {
			if (isNullOrUndefined(node)) return false;
			const key = segments[i];
			path = path ? `${path}.${key}` : key;
			if (Array.isArray(node) && +key >= node.length) return ownerDepth === -1 ? false : i === ownerDepth ? +key < ownerPreActionLength : true;
			if (_state.actionArrayLengths.has(path)) {
				ownerDepth = i + 1;
				ownerPreActionLength = _state.actionArrayLengths.get(path);
			}
			node = node[key];
			if (isUndefined(node) && ownerDepth !== -1 && i > ownerDepth && +segments[ownerDepth] < ownerPreActionLength) return true;
		}
		return false;
	};
	const isPastArrayEnd = (name) => {
		let node = _formValues;
		for (const key of toPath(name)) {
			if (Array.isArray(node) && +key >= node.length) return true;
			node = node && node[key];
		}
		return false;
	};
	const updateValidAndValue = (name, shouldSkipSetValueAs, value, ref) => {
		const field = get(_fields, name);
		if (field) {
			if (hasExplicitNullIntermediate(name) || isStaleArrayField(name)) return;
			const wasUnsetInFormValues = isUndefined(get(_formValues, name));
			const defaultValue = get(_formValues, name, isUndefined(value) ? get(_defaultValues, name) : value);
			const isEditedBeforeReady = !!ref && !_formState.isReady && isEdited(ref);
			if (isUndefined(defaultValue) || ref && ref.defaultChecked || isEditedBeforeReady || shouldSkipSetValueAs) {
				const fieldValue = shouldSkipSetValueAs ? defaultValue : getFieldValue(field._f);
				if (!isUndefined(fieldValue) || !isPastArrayEnd(name)) {
					if (_isTracked("dirtyFields") && !deepEqual(get(_formValues, name), fieldValue)) _dirtyFieldsStale = true;
					set(_formValues, name, fieldValue);
					if (isEditedBeforeReady) updateTouchAndDirty(name, fieldValue);
				}
			} else setFieldValue(name, defaultValue);
			if (_state.mount && !_state.action) {
				if (_options.resolver && _isTracked("isValidating", "validatingFields")) Promise.resolve().then(() => _setValid());
				else _setValid();
				if (wasUnsetInFormValues && _formState.isDirty && _isTracked("isDirty")) {
					if (!_getDirty()) {
						_formState.isDirty = false;
						_subjects.state.next({ ..._formState });
					}
				}
				if (_options.shouldUnregister && wasUnsetInFormValues && !isUndefined(get(_formValues, name)) && isWatched(name, _names)) _state.watch = true;
			}
		}
	};
	const updateTouchAndDirty = (name, fieldValue, isBlurEvent, shouldDirty, shouldRender) => {
		let shouldUpdateField = false;
		let isPreviousDirty = false;
		const output = { name };
		if (!_options.disabled || shouldDirty === true) {
			if (!isBlurEvent || shouldDirty) {
				const isCurrentFieldPristine = deepEqual(get(_defaultValues, name), fieldValue);
				if (_isTracked("isDirty")) {
					isPreviousDirty = _formState.isDirty;
					_formState.isDirty = output.isDirty = !isCurrentFieldPristine || _getDirty();
					shouldUpdateField = isPreviousDirty !== output.isDirty;
				}
				isPreviousDirty = !!get(_formState.dirtyFields, name);
				if (isCurrentFieldPristine) unset(_formState.dirtyFields, name);
				else {
					const defaultFieldValue = get(_defaultValues, name);
					const field = get(_fields, name);
					const dirtyValue = !(field && field._f) && (isObject(defaultFieldValue) || Array.isArray(defaultFieldValue)) ? getDirtyFields(defaultFieldValue, fieldValue, void 0, field) : true;
					set(_formState.dirtyFields, name, dirtyValue);
				}
				let didResyncDirtyFields = false;
				if (_dirtyFieldsStale || isCurrentFieldPristine && (_isTracked("isDirty") ? _formState.isDirty : _getDirty())) {
					_dirtyFieldsStale = false;
					const nextDirtyFields = getDirtyFields(_defaultValues, _formValues, void 0, _fields);
					if (!deepEqual(_formState.dirtyFields, nextDirtyFields)) {
						didResyncDirtyFields = true;
						replaceDirtyFieldsInPlace(_formState.dirtyFields, nextDirtyFields);
					}
				}
				output.dirtyFields = _formState.dirtyFields;
				shouldUpdateField = shouldUpdateField || _isTracked("dirtyFields") && (didResyncDirtyFields || isPreviousDirty !== !isCurrentFieldPristine);
			}
			if (isBlurEvent) {
				const isPreviousFieldTouched = has(_formState.touchedFields, name) ? get(_formState.touchedFields, name) : void 0;
				if (!isPreviousFieldTouched) {
					set(_formState.touchedFields, name, isBlurEvent);
					output.touchedFields = _formState.touchedFields;
					shouldUpdateField = shouldUpdateField || _isTracked("touchedFields") && isPreviousFieldTouched !== isBlurEvent;
				}
			}
			shouldUpdateField && shouldRender && _subjects.state.next(output);
		}
		return shouldUpdateField ? output : {};
	};
	const shouldRenderByError = (name, isValid, error, fieldState) => {
		const previousFieldError = get(_formState.errors, name);
		const shouldUpdateValid = _isTracked("isValid") && isBoolean(isValid) && _formState.isValid !== isValid;
		if (_options.delayError && error) {
			delayErrorCallbacks[name] = debounce(name, () => updateErrors(name, error));
			delayErrorCallbacks[name](_options.delayError);
		} else {
			cancelDelayedError(name);
			error ? set(_formState.errors, name, error) : unset(_formState.errors, name);
			_formState.errors = { ..._formState.errors };
		}
		if ((error ? !deepEqual(previousFieldError, error, true) : previousFieldError) || !isEmptyObject(fieldState) || shouldUpdateValid) {
			const updatedFormState = {
				...fieldState,
				...shouldUpdateValid && isBoolean(isValid) ? { isValid } : {},
				errors: _formState.errors,
				name
			};
			_subjects.state.next(updatedFormState);
		}
	};
	const _runSchema = async (name) => {
		_updateIsValidating(name, true);
		return await _options.resolver(_formValues, _options.context, getResolverOptions(name || _names.mount, _fields, _options.criteriaMode, _options.shouldUseNativeValidation));
	};
	const executeSchemaAndUpdateState = async (names) => {
		const resetCallId = _resetCallId;
		const registerCallId = _registerCallId;
		const registeredNames = names ? names.filter((name) => get(_fields, name)) : [];
		const { errors } = await _runSchema(names);
		if (resetCallId !== _resetCallId) return errors;
		_updateIsValidating(names);
		if (names) {
			for (const name of names) {
				if (registeredNames.includes(name) && (!get(_fields, name) || _registerCallIds[name] > registerCallId)) {
					unset(errors, name);
					continue;
				}
				const error = get(errors, name);
				cancelDelayedErrorTree(name);
				const isFieldArrayRootError = _names.array.has(name) && isObject(error) && !Object.keys(error).some((key) => !Number.isNaN(Number(key)));
				const field = get(_fields, name);
				const hasNestedFields = isObject(field) && Object.keys(field).some((key) => key !== "_f");
				isFieldArrayRootError ? updateFieldArrayRootError(_formState.errors, { [name]: error }, name) : error && (error.type || error.message) || Array.isArray(error) || isObject(error) && hasNestedFields ? set(_formState.errors, name, error) : unset(_formState.errors, name);
			}
			_formState.errors = { ..._formState.errors };
		} else {
			Object.keys(delayErrorCallbacks).forEach(cancelDelayedError);
			_formState.errors = errors;
		}
		return errors;
	};
	const validateForm = async ({ name, eventType, onlyCheckValid }) => {
		if (_options.validate) {
			const resetCallId = _resetCallId;
			const validateFormCallId = ++_validateFormCallId;
			const result = await _options.validate({
				formValues: _formValues,
				formState: _formState,
				name,
				eventType
			});
			if (resetCallId !== _resetCallId || eventType !== EVENTS.SUBMIT && validateFormCallId !== _validateFormCallId) return true;
			if (onlyCheckValid && (isObject(result) ? Object.values(result).some(Boolean) : isString(result) || !result)) return false;
			if (isObject(result)) {
				let isValid = true;
				clearErrors(FORM_ERROR_TYPE);
				for (const key in result) {
					const error = result[key];
					if (error) {
						isValid = false;
						setError(`${FORM_ERROR_TYPE}.${key}`, {
							message: isString(error.message) ? error.message : "",
							type: error.type || INPUT_VALIDATION_RULES.validate
						});
					}
				}
				return isValid;
			} else if (isString(result) || !result) {
				clearErrors(FORM_ERROR_TYPE);
				setError(FORM_ERROR_TYPE, {
					message: result || "",
					type: INPUT_VALIDATION_RULES.validate
				});
				return false;
			} else {
				clearErrors(FORM_ERROR_TYPE);
				return true;
			}
		}
		return true;
	};
	const executeBuiltInValidation = async ({ fields, onlyCheckValid, name, eventType, context = {
		valid: true,
		runRootValidation: false
	} }) => {
		const resetCallId = _resetCallId;
		if (_options.validate && !context.runRootValidation) {
			context.runRootValidation = true;
			if (!await validateForm({
				name,
				eventType,
				onlyCheckValid
			})) {
				context.valid = false;
				if (onlyCheckValid) return context.valid;
			}
		}
		for (const name in fields) {
			const field = fields[name];
			if (field) {
				const { _f, ...fieldValue } = field;
				if (_f) {
					const isFieldArrayRoot = _names.array.has(_f.name);
					const isPromiseFunction = field._f && hasPromiseValidation(field._f);
					const shouldTrackIsValidatingState = _isTracked("isValidating", "validatingFields");
					if (isPromiseFunction && shouldTrackIsValidatingState) _updateIsValidating([_f.name], true);
					const registerCallId = _registerCallId;
					const fieldError = await validateField(field, _names.disabled, _formValues, shouldDisplayAllAssociatedErrors, _options.shouldUseNativeValidation && !onlyCheckValid, isFieldArrayRoot);
					if (resetCallId !== _resetCallId) return context.valid;
					if (isPromiseFunction && shouldTrackIsValidatingState) _updateIsValidating([_f.name]);
					if (!get(_fields, _f.name) || _registerCallIds[_f.name] > registerCallId) continue;
					if (fieldError[_f.name]) {
						context.valid = false;
						if (onlyCheckValid) break;
					}
					if (!onlyCheckValid) {
						cancelDelayedError(_f.name);
						get(fieldError, _f.name) ? isFieldArrayRoot ? updateFieldArrayRootError(_formState.errors, fieldError, _f.name) : set(_formState.errors, _f.name, fieldError[_f.name]) : unset(_formState.errors, _f.name);
					}
					if (_options.shouldUseNativeValidation && fieldError[_f.name]) break;
				}
				!isEmptyObject(fieldValue) && await executeBuiltInValidation({
					context,
					onlyCheckValid,
					fields: fieldValue,
					name,
					eventType
				});
			}
		}
		return context.valid;
	};
	const _removeUnmounted = () => {
		for (const name of _names.unMount) {
			const field = get(_fields, name);
			field && (field._f.refs ? field._f.refs.every((ref) => !live(ref)) : !live(field._f.ref)) && unregister(name);
		}
		_names.unMount = /* @__PURE__ */ new Set();
	};
	const _getDirty = (name, data) => (name && !isUndefined(data) && set(_formValues, name, data), !deepEqual(_state.mount ? _formValues : _defaultValues, _defaultValues));
	const _getWatch = (names, defaultValue, isGlobal) => {
		const values = _state.mount ? _formValues : isUndefined(defaultValue) || !isUndefined(names) ? _defaultValues : defaultValue;
		return generateWatchOutput(names, _names, isUndefined(names) ? { ...values } : values, isGlobal, defaultValue);
	};
	const _getFieldArray = (name) => compact(get(_state.mount ? _formValues : _defaultValues, name, _options.shouldUnregister ? get(_defaultValues, name, []) : []));
	const setFieldValue = (name, value, options = {}, skipClone = false, skipRender = false, skipValueRender = false) => {
		const field = get(_fields, name);
		let fieldValue = value;
		if (field) {
			const fieldReference = field._f;
			if (fieldReference) {
				!fieldReference.disabled && set(_formValues, name, getFieldValueAs(value, fieldReference));
				fieldValue = isHTMLElement(fieldReference.ref) && isNullOrUndefined(value) ? "" : value;
				if (isMultipleSelect(fieldReference.ref)) [...fieldReference.ref.options].forEach((optionRef) => optionRef.selected = fieldValue.includes(optionRef.value));
				else if (fieldReference.refs) {
					if (isCheckBoxInput(fieldReference.ref)) fieldReference.refs.forEach((checkboxRef) => {
						if (!checkboxRef.defaultChecked || !checkboxRef.disabled) {
							if (Array.isArray(fieldValue)) checkboxRef.checked = !isUndefined(checkboxRef.value) && fieldValue.includes(checkboxRef.value);
							else checkboxRef.checked = fieldValue === checkboxRef.value || !!fieldValue;
						}
					});
					else fieldReference.refs.forEach((radioRef) => radioRef.checked = radioRef.value === fieldValue);
				} else if (isFileInput(fieldReference.ref)) fieldReference.ref.value = "";
				else {
					fieldReference.ref.value = fieldValue;
					if (!fieldReference.ref.type && !skipRender && !skipValueRender) _subjects.state.next({
						name,
						values: skipClone ? _formValues : _hasValuesSubscriber(name) ? cloneObject(_formValues) : void 0
					});
				}
			}
		}
		(options.shouldDirty || options.shouldTouch) && updateTouchAndDirty(name, field && field._f && !field._f.disabled && (field._f.valueAsNumber || field._f.valueAsDate || field._f.setValueAs) ? getFieldValueAs(value, field._f) : fieldValue, options.shouldTouch, options.shouldDirty, !skipRender);
		options.shouldValidate && trigger(name, { delayError: options.delayError });
		if (options.shouldValidate && field && field._f && field._f.deps && (!Array.isArray(field._f.deps) || field._f.deps.length > 0)) trigger(field._f.deps);
	};
	const setFieldValues = (name, value, options, skipClone = false, skipRender = false, skipValueRender = false) => {
		for (const fieldKey in value) {
			if (!Object.prototype.hasOwnProperty.call(value, fieldKey)) continue;
			const fieldValue = value[fieldKey];
			const fieldName = name + "." + fieldKey;
			const field = get(_fields, fieldName);
			if (_names.array.has(fieldName)) _subjects.array.next({
				name: fieldName,
				values: skipClone ? _formValues : cloneObject(_formValues)
			});
			(_names.array.has(name) || isObject(fieldValue) || field && !field._f) && !isDateObject(fieldValue) ? setFieldValues(fieldName, fieldValue, options, skipClone, skipRender, skipValueRender) : setFieldValue(fieldName, fieldValue, options, skipClone, skipRender, skipValueRender);
		}
	};
	const _setValue = (name, value, options, skipClone, skipStateEmit = false) => {
		const field = get(_fields, name);
		const isFieldArray = _names.array.has(name);
		const cloneValue = skipClone ? value : cloneObject(value);
		const isValueUnchanged = deepEqual(get(_formValues, name), cloneValue);
		if (!isValueUnchanged) set(_formValues, name, cloneValue);
		if (isFieldArray) {
			_subjects.array.next({
				name,
				values: skipClone ? _formValues : cloneObject(_formValues)
			});
			if (_isTracked("isDirty", "dirtyFields") && options.shouldDirty) {
				_updateDirtyFields();
				_formState.isDirty = _getDirty(name, cloneValue);
				if (!skipStateEmit) _subjects.state.next({
					name,
					dirtyFields: _formState.dirtyFields,
					isDirty: _formState.isDirty
				});
			}
			options.shouldValidate && trigger(name, { delayError: options.delayError });
		} else {
			const isEmpty = Array.isArray(cloneValue) && !cloneValue.length || isEmptyObject(cloneValue);
			const skipValueRender = !isValueUnchanged && !skipStateEmit;
			if (!field || field._f || isNullOrUndefined(cloneValue) || isEmpty) setFieldValue(name, cloneValue, options, skipClone, skipStateEmit, skipValueRender);
			else setFieldValues(name, cloneValue, options, skipClone, skipStateEmit, skipValueRender);
		}
		if (!isValueUnchanged && !skipStateEmit) {
			const watched = isWatched(name, _names);
			const emittedName = _state.mount || watched ? name : void 0;
			const fieldArrayItemNames = isFieldArray ? [] : getFieldArrayItemNames(_names.array, name);
			const values = skipClone ? _formValues : _hasValuesSubscriber(emittedName) || fieldArrayItemNames.some(_hasValuesSubscriber) ? cloneObject(_formValues) : void 0;
			_subjects.state.next({
				...watched && _formState,
				name: emittedName,
				values
			});
			for (const itemName of fieldArrayItemNames) _subjects.state.next({
				name: itemName,
				values: values && cloneObject(_formValues)
			});
		}
	};
	const setValue = (name, value, options = {}) => _setValue(name, value, options, false);
	const setValues = (formValues, options = {}) => {
		const updatedFormValues = isFunction(formValues) ? formValues(_formValues) : formValues;
		if (!deepEqual(_formValues, updatedFormValues) || options.shouldValidate || options.shouldDirty || options.shouldTouch) {
			_formValues = {
				..._formValues,
				...updatedFormValues
			};
			for (const fieldName of /* @__PURE__ */ new Set([..._names.mount, ..._names.array])) if (has(updatedFormValues, fieldName)) _setValue(fieldName, get(updatedFormValues, fieldName), options, true, true);
			if (options.shouldDirty && _isTracked("isDirty", "dirtyFields")) for (const name of Object.keys(updatedFormValues)) updateTouchAndDirty(name, _formValues[name], false, true);
			_subjects.state.next({
				..._formState,
				name: void 0,
				type: void 0,
				..._valuesSubscribers.size ? { values: _formValues } : {}
			});
			if (options.shouldValidate) _setValid();
		}
	};
	const onChange = async (event) => {
		_state.mount = true;
		const target = event.target;
		let name = target.name;
		let isFieldValueUpdated = true;
		const field = get(_fields, name);
		const registerCallId = _registerCallId;
		const _updateIsFieldValueUpdated = (fieldValue) => {
			isFieldValueUpdated = !!get(_fields, name) && !(_registerCallIds[name] > registerCallId) && deepEqual(fieldValue, get(_formValues, name, fieldValue));
		};
		if (field) {
			_state.keepIsValid = false;
			let error;
			let isValid;
			let shouldFlushError = false;
			const fieldValue = target.type ? getFieldValue(field._f) : getEventValue(event);
			const isBlurEvent = event.type === EVENTS.BLUR || event.type === EVENTS.FOCUS_OUT;
			const hasNoValidationEffect = !hasValidation(field._f) && !_options.validate && !_options.resolver && !get(_formState.errors, name) && !field._f.deps;
			const shouldSkipValidation = hasNoValidationEffect || skipValidation(isBlurEvent, get(_formState.touchedFields, name), _formState.isSubmitted, _validationModeAfterSubmit, _validationModeBeforeSubmit);
			const watched = isWatched(name, _names, isBlurEvent);
			set(_formValues, name, cloneObject(fieldValue));
			if (isBlurEvent) {
				if (!target || !target.readOnly) {
					field._f.onBlur && field._f.onBlur(event);
					if (Object.prototype.hasOwnProperty.call(delayErrorCallbacks, name)) {
						shouldFlushError = true;
						delayErrorCallbacks[name](0);
					}
				}
			} else if (field._f.onChange) field._f.onChange(event);
			const fieldState = updateTouchAndDirty(name, fieldValue, isBlurEvent);
			const shouldRender = !isEmptyObject(fieldState) || watched;
			!isBlurEvent && _subjects.state.next({
				name,
				type: event.type,
				..._hasValuesSubscriber(name) ? { values: cloneObject(_formValues) } : {}
			});
			if (shouldSkipValidation) {
				if ((!hasNoValidationEffect || !_formState.isValid) && _isTracked("isValid")) {
					if (_options.mode === "onBlur") {
						if (isBlurEvent) _setValid();
					} else if (!isBlurEvent) _setValid();
				}
				return shouldRender && _subjects.state.next({
					name,
					...watched ? {} : fieldState
				});
			}
			if (!_options.resolver && _options.validate) await validateForm({
				name,
				eventType: event.type
			});
			!isBlurEvent && watched && _subjects.state.next({ ..._formState });
			if (_options.resolver) {
				const resetCallId = _resetCallId;
				const { errors } = await _runSchema([name]);
				if (resetCallId !== _resetCallId) return;
				_updateIsValidating([name]);
				_updateIsFieldValueUpdated(fieldValue);
				if (!isFieldValueUpdated) {
					!isEmptyObject(fieldState) && _subjects.state.next(fieldState);
					return;
				}
				const previousErrorLookupResult = schemaErrorLookup(_formState.errors, _fields, name);
				const errorLookupResult = schemaErrorLookup(errors, _fields, previousErrorLookupResult.name || name);
				error = errorLookupResult.error;
				name = errorLookupResult.name;
				isValid = isEmptyObject(errors);
			} else {
				const resetCallId = _resetCallId;
				const setValidCallId = ++_setValidCallId;
				_updateIsValidating([name], true);
				error = (await validateField(field, _names.disabled, _formValues, shouldDisplayAllAssociatedErrors, _options.shouldUseNativeValidation))[name];
				if (resetCallId !== _resetCallId) return;
				_updateIsValidating([name]);
				_updateIsFieldValueUpdated(fieldValue);
				if (isFieldValueUpdated) {
					if (error) isValid = false;
					else if (_isTracked("isValid")) {
						isValid = await executeBuiltInValidation({
							fields: _fields,
							onlyCheckValid: true,
							name,
							eventType: event.type
						});
						if (resetCallId !== _resetCallId) return;
						_updateIsFieldValueUpdated(fieldValue);
						if (setValidCallId !== _setValidCallId) isValid = void 0;
					}
				}
			}
			if (isFieldValueUpdated) {
				field._f.deps && (!Array.isArray(field._f.deps) || field._f.deps.length > 0) && trigger(field._f.deps);
				shouldRenderByError(name, isValid, error, fieldState);
				shouldFlushError && Object.prototype.hasOwnProperty.call(delayErrorCallbacks, name) && delayErrorCallbacks[name](0);
			}
		}
	};
	const _focusInput = (ref, key) => {
		if (get(_formState.errors, key) && ref.focus) {
			ref.focus();
			return 1;
		}
	};
	const trigger = async (name, options = {}) => {
		_state.keepIsValid = false;
		let isValid;
		let validationResult;
		const fieldNames = convertToArrayPayload(name);
		const resetCallId = _resetCallId;
		if (_options.resolver) {
			const errors = await executeSchemaAndUpdateState(isUndefined(name) ? name : fieldNames);
			isValid = isEmptyObject(errors);
			validationResult = name ? !fieldNames.some((name) => get(errors, name)) : isValid;
		} else if (name) {
			validationResult = (await Promise.all(fieldNames.map(async (fieldName) => {
				const field = get(_fields, fieldName);
				return await executeBuiltInValidation({
					fields: field && field._f ? { [fieldName]: field } : field,
					eventType: EVENTS.TRIGGER
				});
			}))).every(Boolean);
			(validationResult || _formState.isValid) && _setValid();
		} else validationResult = isValid = await executeBuiltInValidation({
			fields: _fields,
			name,
			eventType: EVENTS.TRIGGER
		});
		if (resetCallId !== _resetCallId) return validationResult;
		if (options.delayError && _options.delayError && isString(name)) {
			const error = get(_formState.errors, name);
			if (error) {
				unset(_formState.errors, name);
				delayErrorCallbacks[name] = debounce(name, () => updateErrors(name, error));
				delayErrorCallbacks[name](_options.delayError);
			} else cancelDelayedError(name);
		}
		if (options.shouldTouch) {
			const touchField = (fieldName) => {
				!_names.array.has(fieldName) && set(_formState.touchedFields, fieldName, true);
			};
			for (const fieldName of name ? fieldNames : _names.mount) {
				const field = get(_fields, fieldName);
				isObject(field) || Array.isArray(field) ? iterateFieldsByAction(_fields, (_, key) => touchField(key), [fieldName]) : touchField(fieldName);
			}
		}
		_formState.errors = { ..._formState.errors };
		_subjects.state.next({
			...!isString(name) || _isTracked("isValid") && isValid !== _formState.isValid ? {} : { name },
			..._options.resolver || !name ? { isValid } : {},
			...options.shouldTouch && _isTracked("touchedFields") ? { touchedFields: _formState.touchedFields } : {},
			errors: _formState.errors
		});
		options.shouldFocus && !validationResult && iterateFieldsByAction(_fields, _focusInput, name ? fieldNames : _names.mount);
		return validationResult;
	};
	const getValues = ((fieldNames, config) => {
		let values = isUndefined(fieldNames) && !config ? { ..._state.mount ? _formValues : _defaultValues } : _state.mount ? _formValues : _defaultValues;
		if (config) values = extractFormValues(config.dirtyFields ? _formState.dirtyFields : _formState.touchedFields, values);
		return isUndefined(fieldNames) ? values : isString(fieldNames) ? get(values, fieldNames) : fieldNames.map((name) => get(values, name));
	});
	const getErrors = ((fieldNames) => isUndefined(fieldNames) ? { ..._formState.errors } : isString(fieldNames) ? get(_formState.errors, fieldNames) : fieldNames.map((name) => get(_formState.errors, name)));
	const getFieldState = (name, formState) => {
		const targetFormState = formState || _formState;
		const error = get(targetFormState.errors, name);
		return {
			invalid: !!error,
			isDirty: !!get(targetFormState.dirtyFields, name),
			error,
			isValidating: !!get(targetFormState.validatingFields, name),
			isTouched: !!get(targetFormState.touchedFields, name)
		};
	};
	const clearErrors = (name) => {
		const names = name ? convertToArrayPayload(name) : void 0;
		if (names) names.forEach((inputName) => {
			cancelDelayedErrorTree(inputName);
			unset(_formState.errors, inputName);
			_formState.errors = { ..._formState.errors };
			_subjects.state.next({
				name: inputName,
				errors: _formState.errors
			});
		});
		else {
			Object.keys(delayErrorCallbacks).forEach(cancelDelayedError);
			_formState.errors = {};
			_subjects.state.next({ errors: _formState.errors });
		}
	};
	const setError = (name, error, options) => {
		var _a;
		cancelDelayedErrorTree(name);
		const field = get(_fields, name, { _f: {} });
		const ref = field._f && field._f.ref;
		const { ref: currentRef, message, type, types, ...restOfErrorTree } = get(_formState.errors, name) || {};
		set(_formState.errors, name, {
			...restOfErrorTree,
			...error,
			ref
		});
		_formState.errors = { ..._formState.errors };
		_subjects.state.next({
			name,
			errors: _formState.errors,
			isValid: false
		});
		if (options && options.shouldFocus) {
			const fieldRef = ((_a = field._f) === null || _a === void 0 ? void 0 : _a.refs) ? field._f.refs.find((ref) => !ref.disabled) || field._f.refs[0] : ref;
			fieldRef && fieldRef.focus && fieldRef.focus();
		}
	};
	const watch = (name, defaultValue) => {
		if (isFunction(name)) {
			const valuesSubscriber = {};
			_valuesSubscribers.add(valuesSubscriber);
			const { unsubscribe } = _subjects.state.subscribe({ next: (payload) => "values" in payload && name(payload.values || _getWatch(void 0, defaultValue), payload) });
			return { unsubscribe: () => {
				_valuesSubscribers.delete(valuesSubscriber);
				unsubscribe();
			} };
		}
		return _getWatch(name, defaultValue, true);
	};
	const _subscribe = (props) => {
		const valuesSubscriber = {
			name: props.name,
			exact: props.exact
		};
		props.formState && props.formState.values && _valuesSubscribers.add(valuesSubscriber);
		const { unsubscribe } = _subjects.state.subscribe({ next: (formState) => {
			if (shouldSubscribeByName(props.name, formState.name, props.exact) && shouldRenderFormState(formState, props.formState || _proxyFormState, props.reRenderRoot)) {
				const values = formState.values || { ..._formValues };
				props.callback({
					..._formState,
					...formState,
					validatingFields: _formState.validatingFields,
					isValidating: _formState.isValidating,
					values,
					defaultValues: _defaultValues
				});
			}
		} });
		return () => {
			_valuesSubscribers.delete(valuesSubscriber);
			unsubscribe();
		};
	};
	const subscribe = (props) => {
		_state.mount = true;
		const trackedKeys = Object.keys(props.formState || {}).filter((key) => props.formState && props.formState[key]);
		for (const key of trackedKeys) _proxySubscribeFormState[key] = (_proxySubscribeFormState[key] || 0) + 1;
		const unsubscribe = _subscribe({
			...props,
			formState: {
				...defaultProxyFormState,
				...props.formState
			}
		});
		return () => {
			for (const key of trackedKeys.splice(0)) _proxySubscribeFormState[key]--;
			unsubscribe();
		};
	};
	const unregister = (name, options = {}) => {
		const requestedNames = name ? convertToArrayPayload(name) : [..._names.mount];
		const fieldNames = new Set(requestedNames);
		if (name) {
			for (const fieldName of _names.mount) if (requestedNames.some((parent) => fieldName.startsWith(`${parent}.`))) fieldNames.add(fieldName);
		}
		if (!options.keepIsValidating) _updateValidatingFields(fieldNames);
		for (const fieldName of fieldNames) {
			_names.mount.delete(fieldName);
			_names.array.delete(fieldName);
			_names.disabled.delete(fieldName);
			unset(_fields, fieldName);
			!options.keepValue && unset(_formValues, fieldName);
			if (!options.keepError) {
				cancelDelayedErrorTree(fieldName);
				unset(_formState.errors, fieldName);
			}
			!options.keepDirty && unset(_formState.dirtyFields, fieldName);
			!options.keepTouched && unset(_formState.touchedFields, fieldName);
			!_options.shouldUnregister && !options.keepDefaultValue && unset(_defaultValues, fieldName);
		}
		if (!options.keepError) _formState.errors = { ..._formState.errors };
		_valuesSubscribers.size && _subjects.state.next({ values: cloneObject(_formValues) });
		_subjects.state.next({
			..._formState,
			...options.keepDirty ? {} : { isDirty: _getDirty() },
			...options.keepIsValidating ? {} : { isValidating: !isEmptyObject(_formState.validatingFields) }
		});
		!options.keepIsValid && _setValid();
	};
	const _setDisabledField = ({ disabled, name }) => {
		if (isBoolean(disabled) && _state.mount || !!disabled || _names.disabled.has(name)) {
			const disabledStateChanged = _names.disabled.has(name) !== !!disabled;
			disabled ? _names.disabled.add(name) : _names.disabled.delete(name);
			disabledStateChanged && _state.mount && !_state.action && _setValid();
		}
	};
	const register = (name, options = {}) => {
		let field = get(_fields, name);
		const disabledIsDefined = isBoolean(options.disabled) || isBoolean(_options.disabled);
		const shouldRevalidateRemount = !_names.registerName.has(name) && field && field._f && !field._f.mount;
		if (!field || !field._f) _registerCallIds[name] = ++_registerCallId;
		set(_fields, name, {
			...field || {},
			_f: {
				...field && field._f ? field._f : { ref: { name } },
				name,
				mount: true,
				...options
			}
		});
		_names.mount.add(name);
		if (field && field._f) {
			const nextField = get(_fields, name);
			for (const rule of REGISTER_VALIDATION_RULES) if (!(rule in options)) delete nextField._f[rule];
		}
		if (field && !shouldRevalidateRemount) _setDisabledField({
			disabled: isBoolean(options.disabled) ? options.disabled : _options.disabled,
			name
		});
		else updateValidAndValue(name, true, options.value);
		return {
			...disabledIsDefined ? { disabled: options.disabled || _options.disabled } : {},
			..._options.progressive ? {
				required: !!getRuleValue(options.required),
				min: getRuleValue(options.min),
				max: getRuleValue(options.max),
				minLength: getRuleValue(options.minLength),
				maxLength: getRuleValue(options.maxLength),
				pattern: getRuleValue(options.pattern)
			} : {},
			name,
			onChange,
			onBlur: onChange,
			ref: (ref) => {
				if (ref) {
					_names.registerName.add(name);
					register(name, options);
					_names.registerName.delete(name);
					field = get(_fields, name);
					const fieldRef = isUndefined(ref.value) ? ref.querySelectorAll ? ref.querySelectorAll("input,select,textarea")[0] || ref : ref : ref;
					const radioOrCheckbox = isRadioOrCheckbox(fieldRef);
					const refs = field._f.refs || [];
					if (radioOrCheckbox ? refs.find((option) => option === fieldRef) : fieldRef === field._f.ref) return;
					const newField = { ...field._f };
					if (radioOrCheckbox) {
						newField.refs = [
							...refs.filter(live),
							fieldRef,
							...Array.isArray(get(_defaultValues, name)) ? [{}] : []
						];
						newField.ref = {
							type: fieldRef.type,
							name
						};
					} else {
						newField.ref = fieldRef;
						delete newField.refs;
					}
					set(_fields, name, { _f: newField });
					updateValidAndValue(name, false, void 0, fieldRef);
				} else {
					field = get(_fields, name, {});
					if (field._f) field._f.mount = false;
					(_options.shouldUnregister || options.shouldUnregister) && !(isNameInFieldArray(_names.array, name) && _state.action) && _names.unMount.add(name);
				}
			}
		};
	};
	const _focusError = () => _options.shouldFocusError && !_options.shouldUseNativeValidation && iterateFieldsByAction(_fields, _focusInput, _names.mount);
	const _disableForm = (disabled) => {
		if (isBoolean(disabled)) {
			_subjects.state.next({ disabled });
			iterateFieldsByAction(_fields, (ref, name) => {
				const currentField = get(_fields, name);
				if (currentField) {
					ref.disabled = currentField._f.disabled || disabled;
					if (Array.isArray(currentField._f.refs)) currentField._f.refs.forEach((inputRef) => {
						inputRef.disabled = currentField._f.disabled || disabled;
					});
				}
			}, 0);
		}
	};
	const handleSubmit = (onValid, onInvalid) => async (e) => {
		let result = void 0;
		let onValidError = void 0;
		let onValidFailed = false;
		if (e) {
			e.preventDefault && e.preventDefault();
			e.persist && e.persist();
		}
		let fieldValues = cloneObject(_formValues);
		_subjects.state.next({ isSubmitting: true });
		const resetCallId = _resetCallId;
		const onSubmitError = (error) => {
			if (resetCallId === _resetCallId) _subjects.state.next({ isSubmitting: false });
			throw error;
		};
		if (_options.resolver) {
			let validationResult;
			try {
				validationResult = await _runSchema();
			} catch (error) {
				onSubmitError(error);
			}
			const { errors, values } = validationResult;
			if (resetCallId !== _resetCallId) return;
			_updateIsValidating();
			Object.keys(delayErrorCallbacks).forEach(cancelDelayedError);
			_formState.errors = errors;
			fieldValues = cloneObject(values);
		} else {
			try {
				await executeBuiltInValidation({
					fields: _fields,
					eventType: EVENTS.SUBMIT
				});
			} catch (error) {
				onSubmitError(error);
			}
			if (resetCallId !== _resetCallId) return;
			unset(_formState.errors, ROOT_ERROR_TYPE);
			_formState.errors = { ..._formState.errors };
		}
		if (_names.disabled.size && (isObject(fieldValues) || Array.isArray(fieldValues))) for (const name of _names.disabled) unset(fieldValues, name);
		if (isEmptyObject(_formState.errors)) {
			_subjects.state.next({ errors: {} });
			try {
				result = await onValid(fieldValues, e);
			} catch (error) {
				onValidFailed = true;
				onValidError = error;
			}
		} else {
			if (onInvalid) try {
				await onInvalid({ ..._formState.errors }, e);
			} catch (error) {
				onSubmitError(error);
			}
			if (resetCallId === _resetCallId) {
				_focusError();
				setTimeout(_focusError);
			}
		}
		if (resetCallId === _resetCallId) _subjects.state.next({
			isSubmitted: true,
			isSubmitting: false,
			isSubmitSuccessful: isEmptyObject(_formState.errors) && !onValidFailed,
			submitCount: _formState.submitCount + 1,
			errors: _formState.errors
		});
		if (onValidFailed) throw onValidError;
		return result;
	};
	const resetField = (name, options = {}) => {
		if (get(_fields, name)) {
			_updateValidatingFields([name]);
			if (isUndefined(options.defaultValue)) setValue(name, cloneObject(get(_defaultValues, name)));
			else {
				setValue(name, options.defaultValue);
				_defaultValues = cloneObject(_defaultValues);
				set(_defaultValues, name, cloneObject(options.defaultValue));
			}
			if (!options.keepTouched) unset(_formState.touchedFields, name);
			if (!options.keepDirty) {
				unset(_formState.dirtyFields, name);
				_formState.isDirty = !isUndefined(options.defaultValue) ? _getDirty(name, cloneObject(get(_defaultValues, name))) : _getDirty();
			}
			if (!options.keepError) {
				cancelDelayedErrorTree(name);
				unset(_formState.errors, name);
				_formState.errors = { ..._formState.errors };
				_setValid();
			}
			_subjects.state.next({
				..._formState,
				isValidating: !isEmptyObject(_formState.validatingFields)
			});
		}
	};
	const _reset = (formValues, keepStateOptions = {}) => {
		_resetCallId++;
		const updatedValues = formValues ? cloneObject(formValues) : _defaultValues;
		const cloneUpdatedValues = cloneObject(updatedValues);
		const isEmptyResetValues = isEmptyObject(formValues);
		const values = cloneUpdatedValues;
		const fieldRefs = _fields;
		Object.keys(delayErrorCallbacks).forEach(cancelDelayedError);
		if (!keepStateOptions.keepDefaultValues) _defaultValues = updatedValues;
		if (!keepStateOptions.keepValues) {
			if (keepStateOptions.keepDirtyValues) {
				const fieldsToCheck = /* @__PURE__ */ new Set([..._names.mount, ...collectDirtyFieldNames(getDirtyFields(_defaultValues, _formValues, void 0, fieldRefs), _formState.dirtyFields)]);
				for (const fieldName of fieldsToCheck) {
					const isDirty = get(_formState.dirtyFields, fieldName);
					const existingValue = get(_formValues, fieldName);
					const newValue = get(values, fieldName);
					if (isDirty && !isUndefined(existingValue)) set(values, fieldName, existingValue);
					else if (!isDirty && !isUndefined(newValue)) setValue(fieldName, newValue);
				}
			} else {
				if (isWeb && isUndefined(formValues)) for (const name of _names.mount) {
					const field = get(_fields, name);
					if (field && field._f) {
						const fieldReference = Array.isArray(field._f.refs) ? field._f.refs[0] : field._f.ref;
						if (isHTMLElement(fieldReference)) {
							const form = fieldReference.closest("form");
							if (form) {
								form.reset();
								break;
							}
						}
					}
				}
				if (keepStateOptions.keepFieldsRef) for (const fieldName of _names.mount) setValue(fieldName, get(values, fieldName));
				else _fields = {};
			}
			if (_options.shouldUnregister) {
				_formValues = keepStateOptions.keepDefaultValues ? cloneObject(_defaultValues) : {};
				if (keepStateOptions.keepFieldsRef) for (const fieldName of _names.mount) set(_formValues, fieldName, get(values, fieldName));
			} else _formValues = cloneObject(values);
			_subjects.array.next({ values: { ...values } });
			_subjects.state.next({
				name: void 0,
				type: void 0,
				values: { ...values }
			});
		}
		_names = {
			mount: keepStateOptions.keepDirtyValues || keepStateOptions.keepFieldsRef ? _names.mount : /* @__PURE__ */ new Set(),
			unMount: /* @__PURE__ */ new Set(),
			array: /* @__PURE__ */ new Set(),
			registerName: /* @__PURE__ */ new Set(),
			disabled: keepStateOptions.keepValues || keepStateOptions.keepDirtyValues || keepStateOptions.keepFieldsRef ? new Set([..._names.disabled].filter((name) => get(_fields, name))) : /* @__PURE__ */ new Set(),
			watch: /* @__PURE__ */ new Set(),
			watchAll: false,
			focus: ""
		};
		_state.mount = !_proxyFormState.isValid || !!keepStateOptions.keepIsValid || !!keepStateOptions.keepDirtyValues || !_options.shouldUnregister && !isEmptyObject(values);
		_state.watch = !!_options.shouldUnregister;
		_state.keepIsValid = !!keepStateOptions.keepIsValid;
		_state.action = false;
		_state.actionArrayLengths.clear();
		_dirtyFieldsStale = false;
		if (!keepStateOptions.keepErrors) _formState.errors = {};
		_subjects.state.next({
			submitCount: keepStateOptions.keepSubmitCount ? _formState.submitCount : 0,
			isDirty: isEmptyResetValues ? false : keepStateOptions.keepDirty ? _formState.isDirty : keepStateOptions.keepValues ? _getDirty() : !!(keepStateOptions.keepDefaultValues && formValues && !deepEqual(formValues, _defaultValues)),
			isSubmitted: keepStateOptions.keepIsSubmitted ? _formState.isSubmitted : false,
			dirtyFields: isEmptyResetValues ? {} : keepStateOptions.keepDirtyValues ? keepStateOptions.keepDefaultValues && _formValues ? getDirtyFields(_defaultValues, _formValues, void 0, fieldRefs) : _formState.dirtyFields : keepStateOptions.keepDefaultValues && formValues ? getDirtyFields(_defaultValues, formValues, void 0, fieldRefs) : keepStateOptions.keepDirty ? _formState.dirtyFields : keepStateOptions.keepValues ? getDirtyFields(_defaultValues, _formValues, void 0, fieldRefs) : {},
			touchedFields: keepStateOptions.keepTouched ? _formState.touchedFields : {},
			...!keepStateOptions.keepIsValidating && (_formState.isValidating || !isEmptyObject(_formState.validatingFields)) ? {
				validatingFields: {},
				isValidating: false
			} : null,
			errors: keepStateOptions.keepErrors ? _formState.errors : {},
			isSubmitSuccessful: keepStateOptions.keepIsSubmitSuccessful ? _formState.isSubmitSuccessful : false,
			isSubmitting: false,
			defaultValues: _defaultValues
		});
	};
	const reset = (formValues, keepStateOptions) => _reset(isFunction(formValues) ? formValues(_formValues) : formValues, {
		..._options.resetOptions,
		...keepStateOptions
	});
	const setFocus = (name, options = {}) => {
		const field = get(_fields, name);
		const fieldReference = field && field._f;
		if (fieldReference) {
			const fieldRef = fieldReference.refs ? fieldReference.refs.find((ref) => !ref.disabled) || fieldReference.refs[0] : fieldReference.ref;
			if (fieldRef.focus) setTimeout(() => {
				fieldRef.focus();
				options.shouldSelect && isFunction(fieldRef.select) && fieldRef.select();
			});
		}
	};
	const _setFormState = (updatedFormState) => {
		const { name, type, values, ...formState } = updatedFormState;
		if (Object.keys(formState).length) _formState = {
			..._formState,
			...formState
		};
	};
	_subjects.state.subscribe({ next: _setFormState });
	const _resetDefaultValues = () => isFunction(_options.defaultValues) && _options.defaultValues().then((values) => {
		reset(values, _options.resetOptions);
		_subjects.state.next({ isLoading: false });
	});
	const resetDefaultValues = (values, options = {}) => {
		_defaultValues = cloneObject(values);
		if (!options.keepDirty) {
			const newDirtyFields = getDirtyFields(_defaultValues, _formValues, void 0, _fields);
			_formState.dirtyFields = newDirtyFields;
			_formState.isDirty = !isEmptyObject(newDirtyFields);
		}
		if (!options.keepIsValid) _setValid();
		_subjects.state.next({
			..._formState,
			defaultValues: _defaultValues
		});
	};
	const methods = {
		control: {
			register,
			unregister,
			getFieldState,
			handleSubmit,
			setError,
			_subscribe,
			_runSchema,
			_updateIsValidating,
			_focusError,
			_getWatch,
			_getDirty,
			_setValid,
			_setFieldArray,
			_setDisabledField,
			_setErrors,
			_getFieldArray,
			_reset,
			_resetDefaultValues,
			_removeUnmounted,
			_disableForm,
			_subjects,
			_proxyFormState,
			get _fields() {
				return _fields;
			},
			get _formValues() {
				return _formValues;
			},
			get _state() {
				return _state;
			},
			set _state(value) {
				_state = value;
			},
			get _defaultValues() {
				return _defaultValues;
			},
			get _names() {
				return _names;
			},
			set _names(value) {
				_names = value;
			},
			get _formState() {
				return _formState;
			},
			get _options() {
				return _options;
			},
			set _options(value) {
				_options = {
					..._options,
					...value
				};
				_validationModeBeforeSubmit = getValidationModes(_options.mode);
				_validationModeAfterSubmit = getValidationModes(_options.reValidateMode);
				shouldDisplayAllAssociatedErrors = _options.criteriaMode === VALIDATION_MODE.all;
			}
		},
		subscribe,
		trigger,
		register,
		handleSubmit,
		watch,
		setValue,
		setValues,
		getValues,
		getErrors,
		reset,
		resetField,
		resetDefaultValues,
		clearErrors,
		unregister,
		setError,
		setFocus,
		getFieldState
	};
	return {
		...methods,
		formControl: methods
	};
}
var RESET_OPTIONS = {
	mode: defaultOptions.mode,
	reValidateMode: defaultOptions.reValidateMode,
	shouldFocusError: defaultOptions.shouldFocusError,
	resolver: void 0,
	criteriaMode: void 0,
	delayError: void 0,
	shouldUnregister: void 0,
	shouldUseNativeValidation: void 0,
	context: void 0,
	progressive: void 0,
	resetOptions: void 0
};
/**
* Core hook for managing a form. Returns all methods and state for
* registration, validation, and submission.
*
* @see [API](https://react-hook-form.com/docs/useform)
*
* @example
* ```tsx
* const { register, handleSubmit, formState: { errors } } = useForm<FormValues>();
* <form onSubmit={handleSubmit(onSubmit)}>
*   <input {...register("email", { required: true })} />
* </form>
* ```
*/
function useForm(props = {}) {
	const _formControl = import_react.useRef(void 0);
	const _values = import_react.useRef(void 0);
	const _formControlProp = import_react.useRef(props.formControl);
	const _hadDisabled = import_react.useRef(false);
	const _hadValidate = import_react.useRef(!!props.validate);
	const _hadErrors = import_react.useRef(!!props.errors);
	const _isMounted = import_react.useRef(false);
	const [formState, updateFormState] = import_react.useState(() => ({
		...cloneObject(DEFAULT_FORM_STATE),
		isLoading: isFunction(props.defaultValues),
		errors: props.errors || {},
		disabled: props.disabled || false,
		defaultValues: isFunction(props.defaultValues) ? void 0 : props.defaultValues
	}));
	if (!_formControl.current || props.formControl && _formControlProp.current !== props.formControl) {
		_formControlProp.current = props.formControl;
		_hadDisabled.current = false;
		if (props.formControl) {
			_formControl.current = {
				...props.formControl,
				formState
			};
			if (props.defaultValues && !isFunction(props.defaultValues)) props.formControl.reset(props.defaultValues, props.resetOptions);
		} else {
			const { formControl, ...rest } = createFormControl(props);
			_formControl.current = {
				...rest,
				formState
			};
		}
	}
	const control = _formControl.current.control;
	const previousOptions = control._options;
	const removedOptions = {};
	for (const key in RESET_OPTIONS) if (key in previousOptions && !(key in props)) removedOptions[key] = RESET_OPTIONS[key];
	if (_hadDisabled.current && !props.disabled) removedOptions.disabled = false;
	control._options = {
		...removedOptions,
		...props,
		validate: props.validate
	};
	const getCurrentFormState = () => ({
		...control._formState,
		defaultValues: control._defaultValues
	});
	const { resyncIfNeeded, snapshot } = useResyncOnReconnect(getCurrentFormState, cloneFormState);
	useIsomorphicLayoutEffect(() => {
		resyncIfNeeded(true, getCurrentFormState, updateFormState);
		const unsubscribe = control._subscribe({
			formState: control._proxyFormState,
			callback: () => updateFormState({
				...control._formState,
				defaultValues: control._defaultValues
			}),
			reRenderRoot: true
		});
		updateFormState((data) => ({
			...data,
			isReady: true
		}));
		control._formState.isReady = true;
		control._subjects.state.next({ isReady: true });
		return () => {
			unsubscribe();
			snapshot(true, getCurrentFormState);
		};
	}, [
		control,
		resyncIfNeeded,
		snapshot
	]);
	import_react.useEffect(() => {
		control._disableForm(_hadDisabled.current && !props.disabled ? false : props.disabled);
		_hadDisabled.current = !!props.disabled;
	}, [control, props.disabled]);
	import_react.useEffect(() => {
		if (props.mode) control._options.mode = props.mode;
		if (props.reValidateMode) control._options.reValidateMode = props.reValidateMode;
	}, [
		control,
		props.mode,
		props.reValidateMode
	]);
	import_react.useEffect(() => {
		if (props.errors) {
			control._setErrors(props.errors);
			control._focusError();
		} else if (_hadErrors.current) control._setErrors({});
		_hadErrors.current = !!props.errors;
	}, [control, props.errors]);
	import_react.useEffect(() => {
		if (_hadValidate.current && !props.validate) _formControl.current && _formControl.current.clearErrors(FORM_ERROR_TYPE);
		_hadValidate.current = !!props.validate;
	}, [props.validate]);
	import_react.useEffect(() => {
		props.shouldUnregister && control._subjects.state.next({ values: control._getWatch() });
	}, [control, props.shouldUnregister]);
	import_react.useEffect(() => {
		if (control._proxyFormState.isDirty) {
			const isDirty = control._getDirty();
			if (isDirty !== formState.isDirty) control._subjects.state.next({ isDirty });
		}
	}, [control, formState.isDirty]);
	import_react.useEffect(() => {
		if (props.values && !deepEqual(props.values, _values.current)) {
			control._reset(props.values, {
				keepFieldsRef: true,
				...control._options.resetOptions
			});
			if (!(control._options.resetOptions && control._options.resetOptions.keepIsValid)) control._setValid();
			_values.current = props.values;
			updateFormState((state) => ({ ...state }));
		} else control._resetDefaultValues();
	}, [control, props.values]);
	import_react.useEffect(() => {
		if (!control._state.mount || !_isMounted.current && !props.values) {
			control._setValid();
			control._state.mount = true;
		}
		_isMounted.current = true;
		if (control._state.watch) {
			control._state.watch = false;
			control._subjects.state.next({ ...control._formState });
		}
		control._removeUnmounted();
	});
	_formControl.current.formState = import_react.useMemo(() => getProxyFormState(formState, control), [control, formState]);
	return _formControl.current;
}
var HookFormContext = import_react.createContext(null);
HookFormContext.displayName = "HookFormContext";
/**
* Retrieves all `useForm` methods from the nearest `FormProvider`.
* Use in deeply nested components to avoid prop-drilling.
*
* @see [API](https://react-hook-form.com/docs/useformcontext)
*
* @example
* ```tsx
* const { register } = useFormContext<FormValues>();
* ```
*/
var useFormContext = () => import_react.useContext(HookFormContext);
/**
* Provides all `useForm` methods to the component tree via React Context.
* Pair with `useFormContext` to consume them in any descendant.
*
* @see [API](https://react-hook-form.com/docs/useformcontext)
*
* @example
* ```tsx
* <FormProvider {...methods}>
*   <form onSubmit={methods.handleSubmit(onSubmit)}>{children}</form>
* </FormProvider>
* ```
*/
var FormProvider = ({ children, watch, getValues, getErrors, getFieldState, setError, clearErrors, setValue, setValues, trigger, formState, resetField, reset, resetDefaultValues, handleSubmit, unregister, control, register, setFocus, subscribe }) => {
	const memoizedValue = import_react.useMemo(() => ({
		watch,
		getValues,
		getErrors,
		getFieldState,
		setError,
		clearErrors,
		setValue,
		setValues,
		trigger,
		formState,
		resetField,
		reset,
		resetDefaultValues,
		handleSubmit,
		unregister,
		control,
		register,
		setFocus,
		subscribe
	}), [
		clearErrors,
		control,
		formState,
		getErrors,
		getFieldState,
		getValues,
		handleSubmit,
		register,
		reset,
		resetDefaultValues,
		resetField,
		setError,
		setFocus,
		setValue,
		setValues,
		subscribe,
		trigger,
		unregister,
		watch
	]);
	return import_react.createElement(HookFormContext.Provider, { value: memoizedValue }, import_react.createElement(HookFormControlContext.Provider, { value: memoizedValue.control }, children));
};
/**
* Component wrapper around `useWatch`. Re-renders only when watched fields change.
*
* @see [API](https://react-hook-form.com/docs/usewatch)
*
* @example
* ```tsx
* <Watch
*   control={control}
*   names={["foo", "bar"]}
*   render={([foo, bar]) => <span>{foo} {bar}</span>}
* />
* ```
*/
var Watch = (props) => props.render(useWatch({
	name: props.names,
	...props
}));
export { Controller, ErrorMessage, FieldArray, Form, FormProvider, FormState, FormStateSubscribe, Watch, appendErrors, createFormControl, get, set, useController, useFieldArray, useForm, useFormContext, useFormState, useWatch };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVhY3QtaG9vay1mb3JtLmpzIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIi4uLy4uL3JlYWN0LWhvb2stZm9ybS9kaXN0L2luZGV4LmVzbS5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcblxudmFyIGlzQ2hlY2tCb3hJbnB1dCA9IChlbGVtZW50KSA9PiBlbGVtZW50LnR5cGUgPT09ICdjaGVja2JveCc7XG5cbnZhciBpc0ZpbGVJbnB1dCA9IChlbGVtZW50KSA9PiBlbGVtZW50LnR5cGUgPT09ICdmaWxlJztcblxudmFyIGlzRGF0ZU9iamVjdCA9ICh2YWx1ZSkgPT4gdmFsdWUgaW5zdGFuY2VvZiBEYXRlO1xuXG52YXIgaXNOdWxsT3JVbmRlZmluZWQgPSAodmFsdWUpID0+IHZhbHVlID09IG51bGw7XG5cbmNvbnN0IGlzT2JqZWN0VHlwZSA9ICh2YWx1ZSkgPT4gdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JztcbnZhciBpc09iamVjdCA9ICh2YWx1ZSkgPT4gIWlzTnVsbE9yVW5kZWZpbmVkKHZhbHVlKSAmJlxuICAgICFBcnJheS5pc0FycmF5KHZhbHVlKSAmJlxuICAgIGlzT2JqZWN0VHlwZSh2YWx1ZSkgJiZcbiAgICAhaXNEYXRlT2JqZWN0KHZhbHVlKTtcblxudmFyIGdldEV2ZW50VmFsdWUgPSAoZXZlbnQpID0+IGlzT2JqZWN0KGV2ZW50KSAmJiBldmVudC50YXJnZXRcbiAgICA/IGlzQ2hlY2tCb3hJbnB1dChldmVudC50YXJnZXQpXG4gICAgICAgID8gZXZlbnQudGFyZ2V0LmNoZWNrZWRcbiAgICAgICAgOiBpc0ZpbGVJbnB1dChldmVudC50YXJnZXQpXG4gICAgICAgICAgICA/IGV2ZW50LnRhcmdldC5maWxlc1xuICAgICAgICAgICAgOiBldmVudC50YXJnZXQudmFsdWVcbiAgICA6IGV2ZW50O1xuXG5jb25zdCBGSUVMRF9QQVRIX1JFID0gL1suW1xcXSdcIl0vO1xudmFyIHN0cmluZ1RvUGF0aCA9IChpbnB1dCkgPT4gaW5wdXQuc3BsaXQoRklFTERfUEFUSF9SRSkuZmlsdGVyKEJvb2xlYW4pO1xuXG5mdW5jdGlvbiBnZXROdWxsQW5jZXN0b3JWYWx1ZShjb250cm9sLCBuYW1lKSB7XG4gICAgY29uc3Qgc2VnbWVudHMgPSBzdHJpbmdUb1BhdGgobmFtZSk7XG4gICAgbGV0IGZvcm1WYWx1ZXMgPSBjb250cm9sLl9mb3JtVmFsdWVzO1xuICAgIGxldCBkZWZhdWx0VmFsdWVzID0gY29udHJvbC5fZGVmYXVsdFZhbHVlcztcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNlZ21lbnRzLmxlbmd0aCAtIDE7IGkrKykge1xuICAgICAgICBjb25zdCBrZXkgPSBzZWdtZW50c1tpXTtcbiAgICAgICAgZm9ybVZhbHVlcyA9XG4gICAgICAgICAgICBmb3JtVmFsdWVzID09IG51bGxcbiAgICAgICAgICAgICAgICA/IGZvcm1WYWx1ZXNcbiAgICAgICAgICAgICAgICA6IGZvcm1WYWx1ZXNba2V5XTtcbiAgICAgICAgZGVmYXVsdFZhbHVlcyA9XG4gICAgICAgICAgICBkZWZhdWx0VmFsdWVzID09IG51bGxcbiAgICAgICAgICAgICAgICA/IGRlZmF1bHRWYWx1ZXNcbiAgICAgICAgICAgICAgICA6IGRlZmF1bHRWYWx1ZXNba2V5XTtcbiAgICAgICAgaWYgKGZvcm1WYWx1ZXMgPT09IG51bGwgfHwgZGVmYXVsdFZhbHVlcyA9PT0gbnVsbCkge1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbn1cblxudmFyIGlzTmFtZUluRmllbGRBcnJheSA9IChuYW1lcywgbmFtZSkgPT4gbmFtZVxuICAgIC5zcGxpdCgnLicpXG4gICAgLnNvbWUoKHBhcnQsIGluZGV4LCBhcnIpID0+ICFpc05hTihOdW1iZXIocGFydCkpICYmIG5hbWVzLmhhcyhhcnIuc2xpY2UoMCwgaW5kZXgpLmpvaW4oJy4nKSkpO1xuXG52YXIgaXNXZWIgPSB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJlxuICAgIHR5cGVvZiB3aW5kb3cuSFRNTEVsZW1lbnQgIT09ICd1bmRlZmluZWQnICYmXG4gICAgdHlwZW9mIGRvY3VtZW50ICE9PSAndW5kZWZpbmVkJztcblxuZnVuY3Rpb24gY2xvbmVPYmplY3QoZGF0YSkge1xuICAgIGlmIChkYXRhID09PSBudWxsIHx8IHR5cGVvZiBkYXRhICE9PSAnb2JqZWN0Jykge1xuICAgICAgICByZXR1cm4gZGF0YTtcbiAgICB9XG4gICAgaWYgKGRhdGEgaW5zdGFuY2VvZiBEYXRlKSB7XG4gICAgICAgIHJldHVybiBuZXcgRGF0ZShkYXRhKTtcbiAgICB9XG4gICAgY29uc3QgaXNCbG9iSW5zdGFuY2UgPSB0eXBlb2YgQmxvYiAhPT0gJ3VuZGVmaW5lZCcgJiYgZGF0YSBpbnN0YW5jZW9mIEJsb2I7XG4gICAgY29uc3QgaXNGaWxlTGlzdEluc3RhbmNlID0gdHlwZW9mIEZpbGVMaXN0ICE9PSAndW5kZWZpbmVkJyAmJiBkYXRhIGluc3RhbmNlb2YgRmlsZUxpc3Q7XG4gICAgaWYgKGlzV2ViICYmIChpc0Jsb2JJbnN0YW5jZSB8fCBpc0ZpbGVMaXN0SW5zdGFuY2UpKSB7XG4gICAgICAgIHJldHVybiBkYXRhO1xuICAgIH1cbiAgICBjb25zdCBpc0FycmF5ID0gQXJyYXkuaXNBcnJheShkYXRhKTtcbiAgICBjb25zdCBwcm90b3R5cGUgPSBPYmplY3QuZ2V0UHJvdG90eXBlT2YoZGF0YSk7XG4gICAgaWYgKCFpc0FycmF5ICYmIHByb3RvdHlwZSAmJiBwcm90b3R5cGUuY29uc3RydWN0b3IgIT09IE9iamVjdCkge1xuICAgICAgICByZXR1cm4gZGF0YTtcbiAgICB9XG4gICAgY29uc3QgY29weSA9IGlzQXJyYXkgPyBuZXcgQXJyYXkoZGF0YS5sZW5ndGgpIDogT2JqZWN0LmNyZWF0ZShwcm90b3R5cGUpO1xuICAgIGZvciAoY29uc3Qga2V5IGluIGRhdGEpIHtcbiAgICAgICAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChkYXRhLCBrZXkpKSB7XG4gICAgICAgICAgICBjb3B5W2tleV0gPSBjbG9uZU9iamVjdChkYXRhW2tleV0pO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBjb3B5O1xufVxuXG5jb25zdCBFVkVOVFMgPSB7XG4gICAgQkxVUjogJ2JsdXInLFxuICAgIEZPQ1VTX09VVDogJ2ZvY3Vzb3V0JyxcbiAgICBDSEFOR0U6ICdjaGFuZ2UnLFxuICAgIFNVQk1JVDogJ3N1Ym1pdCcsXG4gICAgVFJJR0dFUjogJ3RyaWdnZXInLFxuICAgIFZBTElEOiAndmFsaWQnLFxufTtcbmNvbnN0IFZBTElEQVRJT05fTU9ERSA9IHtcbiAgICBvbkJsdXI6ICdvbkJsdXInLFxuICAgIG9uQ2hhbmdlOiAnb25DaGFuZ2UnLFxuICAgIG9uU3VibWl0OiAnb25TdWJtaXQnLFxuICAgIG9uVG91Y2hlZDogJ29uVG91Y2hlZCcsXG4gICAgYWxsOiAnYWxsJyxcbn07XG5jb25zdCBJTlBVVF9WQUxJREFUSU9OX1JVTEVTID0ge1xuICAgIG1heDogJ21heCcsXG4gICAgbWluOiAnbWluJyxcbiAgICBtYXhMZW5ndGg6ICdtYXhMZW5ndGgnLFxuICAgIG1pbkxlbmd0aDogJ21pbkxlbmd0aCcsXG4gICAgcGF0dGVybjogJ3BhdHRlcm4nLFxuICAgIHJlcXVpcmVkOiAncmVxdWlyZWQnLFxuICAgIHZhbGlkYXRlOiAndmFsaWRhdGUnLFxufTtcbmNvbnN0IFJFR0lTVEVSX1ZBTElEQVRJT05fUlVMRVMgPSBbXG4gICAgSU5QVVRfVkFMSURBVElPTl9SVUxFUy5yZXF1aXJlZCxcbiAgICBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLm1pbixcbiAgICBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLm1heCxcbiAgICBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLm1pbkxlbmd0aCxcbiAgICBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLm1heExlbmd0aCxcbiAgICBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLnBhdHRlcm4sXG4gICAgSU5QVVRfVkFMSURBVElPTl9SVUxFUy52YWxpZGF0ZSxcbl07XG5jb25zdCBGT1JNX0VSUk9SX1RZUEUgPSAnZm9ybSc7XG5jb25zdCBST09UX0VSUk9SX1RZUEUgPSAncm9vdCc7XG5jb25zdCBQUk9UT1RZUEVfS0VZV09SRFMgPSBbJ19fcHJvdG9fXycsICdjb25zdHJ1Y3RvcicsICdwcm90b3R5cGUnXTtcblxuY29uc3QgSVNfS0VZX1JFID0gL15cXHcqJC87XG52YXIgaXNLZXkgPSAodmFsdWUpID0+IElTX0tFWV9SRS50ZXN0KHZhbHVlKTtcblxudmFyIGlzVW5kZWZpbmVkID0gKHZhbCkgPT4gdmFsID09PSB1bmRlZmluZWQ7XG5cbnZhciBnZXQgPSAob2JqZWN0LCBwYXRoLCBkZWZhdWx0VmFsdWUpID0+IHtcbiAgICBpZiAoIXBhdGggfHwgIWlzT2JqZWN0KG9iamVjdCkpIHtcbiAgICAgICAgcmV0dXJuIGRlZmF1bHRWYWx1ZTtcbiAgICB9XG4gICAgY29uc3QgcGF0aHMgPSBpc0tleShwYXRoKSA/IFtwYXRoXSA6IHN0cmluZ1RvUGF0aChwYXRoKTtcbiAgICBpZiAocGF0aHMuc29tZSgoa2V5KSA9PiBQUk9UT1RZUEVfS0VZV09SRFMuaW5jbHVkZXMoa2V5KSkpIHtcbiAgICAgICAgcmV0dXJuIGRlZmF1bHRWYWx1ZTtcbiAgICB9XG4gICAgY29uc3QgcmVzdWx0ID0gcGF0aHMucmVkdWNlKChyZXN1bHQsIGtleSkgPT4ge1xuICAgICAgICByZXR1cm4gaXNOdWxsT3JVbmRlZmluZWQocmVzdWx0KVxuICAgICAgICAgICAgPyB1bmRlZmluZWRcbiAgICAgICAgICAgIDogcmVzdWx0W2tleV07XG4gICAgfSwgb2JqZWN0KTtcbiAgICByZXR1cm4gKGlzVW5kZWZpbmVkKHJlc3VsdCkgfHwgcmVzdWx0ID09PSBvYmplY3RcbiAgICAgICAgPyBpc1VuZGVmaW5lZChvYmplY3RbcGF0aF0pXG4gICAgICAgICAgICA/IGRlZmF1bHRWYWx1ZVxuICAgICAgICAgICAgOiBvYmplY3RbcGF0aF1cbiAgICAgICAgOiByZXN1bHQpO1xufTtcblxudmFyIGlzQm9vbGVhbiA9ICh2YWx1ZSkgPT4gdHlwZW9mIHZhbHVlID09PSAnYm9vbGVhbic7XG5cbnZhciBpc0Z1bmN0aW9uID0gKHZhbHVlKSA9PiB0eXBlb2YgdmFsdWUgPT09ICdmdW5jdGlvbic7XG5cbnZhciBzZXQgPSAob2JqZWN0LCBwYXRoLCB2YWx1ZSkgPT4ge1xuICAgIGxldCBpbmRleCA9IC0xO1xuICAgIGNvbnN0IHRlbXBQYXRoID0gaXNLZXkocGF0aCkgPyBbcGF0aF0gOiBzdHJpbmdUb1BhdGgocGF0aCk7XG4gICAgY29uc3QgbGVuZ3RoID0gdGVtcFBhdGgubGVuZ3RoO1xuICAgIGNvbnN0IGxhc3RJbmRleCA9IGxlbmd0aCAtIDE7XG4gICAgd2hpbGUgKCsraW5kZXggPCBsZW5ndGgpIHtcbiAgICAgICAgY29uc3Qga2V5ID0gdGVtcFBhdGhbaW5kZXhdO1xuICAgICAgICBsZXQgbmV3VmFsdWUgPSB2YWx1ZTtcbiAgICAgICAgaWYgKGluZGV4ICE9PSBsYXN0SW5kZXgpIHtcbiAgICAgICAgICAgIGNvbnN0IG9ialZhbHVlID0gb2JqZWN0W2tleV07XG4gICAgICAgICAgICBuZXdWYWx1ZSA9XG4gICAgICAgICAgICAgICAgaXNPYmplY3Qob2JqVmFsdWUpIHx8IEFycmF5LmlzQXJyYXkob2JqVmFsdWUpXG4gICAgICAgICAgICAgICAgICAgID8gb2JqVmFsdWVcbiAgICAgICAgICAgICAgICAgICAgOiAhaXNOYU4oK3RlbXBQYXRoW2luZGV4ICsgMV0pXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFtdXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHt9O1xuICAgICAgICB9XG4gICAgICAgIGlmIChQUk9UT1RZUEVfS0VZV09SRFMuaW5jbHVkZXMoa2V5KSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIG9iamVjdFtrZXldID0gbmV3VmFsdWU7XG4gICAgICAgIG9iamVjdCA9IG9iamVjdFtrZXldO1xuICAgIH1cbn07XG5cbi8qKlxuICogU2VwYXJhdGUgY29udGV4dCBmb3IgYGNvbnRyb2xgIHRvIHByZXZlbnQgdW5uZWNlc3NhcnkgcmVyZW5kZXJzLlxuICogSW50ZXJuYWwgaG9va3MgdGhhdCBvbmx5IG5lZWQgY29udHJvbCB1c2UgdGhpcyBpbnN0ZWFkIG9mIGZ1bGwgZm9ybSBjb250ZXh0LlxuICovXG5jb25zdCBIb29rRm9ybUNvbnRyb2xDb250ZXh0ID0gUmVhY3QuY3JlYXRlQ29udGV4dChudWxsKTtcbkhvb2tGb3JtQ29udHJvbENvbnRleHQuZGlzcGxheU5hbWUgPSAnSG9va0Zvcm1Db250cm9sQ29udGV4dCc7XG4vKipcbiAqIEBpbnRlcm5hbCBJbnRlcm5hbCBob29rIHRvIGFjY2VzcyBvbmx5IGNvbnRyb2wgZnJvbSBjb250ZXh0LlxuICovXG5jb25zdCB1c2VGb3JtQ29udHJvbENvbnRleHQgPSAoKSA9PiBSZWFjdC51c2VDb250ZXh0KEhvb2tGb3JtQ29udHJvbENvbnRleHQpO1xuXG52YXIgZ2V0UHJveHlGb3JtU3RhdGUgPSAoZm9ybVN0YXRlLCBjb250cm9sLCBsb2NhbFByb3h5Rm9ybVN0YXRlLCBpc1Jvb3QgPSB0cnVlKSA9PiB7XG4gICAgY29uc3QgcmVzdWx0ID0ge307XG4gICAgZm9yIChjb25zdCBrZXkgaW4gZm9ybVN0YXRlKSB7XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShyZXN1bHQsIGtleSwge1xuICAgICAgICAgICAgZ2V0OiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgX2tleSA9IGtleTtcbiAgICAgICAgICAgICAgICBpZiAoY29udHJvbC5fcHJveHlGb3JtU3RhdGVbX2tleV0gIT09IFZBTElEQVRJT05fTU9ERS5hbGwpIHtcbiAgICAgICAgICAgICAgICAgICAgY29udHJvbC5fcHJveHlGb3JtU3RhdGVbX2tleV0gPSAhaXNSb290IHx8IFZBTElEQVRJT05fTU9ERS5hbGw7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGxvY2FsUHJveHlGb3JtU3RhdGUgJiYgKGxvY2FsUHJveHlGb3JtU3RhdGVbX2tleV0gPSB0cnVlKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZm9ybVN0YXRlW19rZXldO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG59O1xuXG5jb25zdCB1c2VJc29tb3JwaGljTGF5b3V0RWZmZWN0ID0gdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgPyBSZWFjdC51c2VMYXlvdXRFZmZlY3QgOiBSZWFjdC51c2VFZmZlY3Q7XG5cbnZhciBpc1BsYWluT2JqZWN0ID0gKHRlbXBPYmplY3QpID0+IHtcbiAgICBjb25zdCBwcm90b3R5cGVDb3B5ID0gdGVtcE9iamVjdC5jb25zdHJ1Y3RvciAmJiB0ZW1wT2JqZWN0LmNvbnN0cnVjdG9yLnByb3RvdHlwZTtcbiAgICByZXR1cm4gKGlzT2JqZWN0KHByb3RvdHlwZUNvcHkpICYmIHByb3RvdHlwZUNvcHkuaGFzT3duUHJvcGVydHkoJ2lzUHJvdG90eXBlT2YnKSk7XG59O1xuXG52YXIgaXNQcmltaXRpdmUgPSAodmFsdWUpID0+IGlzTnVsbE9yVW5kZWZpbmVkKHZhbHVlKSB8fCAhaXNPYmplY3RUeXBlKHZhbHVlKTtcblxuY29uc3QgaXNFbXB0eU9iamVjdFdpdGhDdXN0b21Qcm90b3R5cGUgPSAob2JqZWN0LCBrZXlzKSA9PiBrZXlzLmxlbmd0aCA9PT0gMCAmJlxuICAgICFBcnJheS5pc0FycmF5KG9iamVjdCkgJiZcbiAgICBPYmplY3QuZ2V0UHJvdG90eXBlT2Yob2JqZWN0KSAhPT0gbnVsbCAmJlxuICAgICFpc1BsYWluT2JqZWN0KG9iamVjdCk7XG5mdW5jdGlvbiBkZWVwRXF1YWwob2JqZWN0MSwgb2JqZWN0MiwgaXNFcnJvck9iamVjdCA9IGZhbHNlLCB2aXNpdGVkID0gbmV3IFdlYWtNYXAoKSkge1xuICAgIGlmIChvYmplY3QxID09PSBvYmplY3QyKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAoaXNQcmltaXRpdmUob2JqZWN0MSkgfHwgaXNQcmltaXRpdmUob2JqZWN0MikpIHtcbiAgICAgICAgcmV0dXJuIE9iamVjdC5pcyhvYmplY3QxLCBvYmplY3QyKTtcbiAgICB9XG4gICAgaWYgKGlzRGF0ZU9iamVjdChvYmplY3QxKSAmJiBpc0RhdGVPYmplY3Qob2JqZWN0MikpIHtcbiAgICAgICAgcmV0dXJuIE9iamVjdC5pcyhvYmplY3QxLmdldFRpbWUoKSwgb2JqZWN0Mi5nZXRUaW1lKCkpO1xuICAgIH1cbiAgICBpZiAoQXJyYXkuaXNBcnJheShvYmplY3QxKSAmJlxuICAgICAgICBBcnJheS5pc0FycmF5KG9iamVjdDIpICYmXG4gICAgICAgIG9iamVjdDEubGVuZ3RoICE9PSBvYmplY3QyLmxlbmd0aCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IGtleXMxID0gT2JqZWN0LmtleXMob2JqZWN0MSk7XG4gICAgY29uc3Qga2V5czIgPSBPYmplY3Qua2V5cyhvYmplY3QyKTtcbiAgICBpZiAoa2V5czEubGVuZ3RoICE9PSBrZXlzMi5sZW5ndGgpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBpZiAoaXNFbXB0eU9iamVjdFdpdGhDdXN0b21Qcm90b3R5cGUob2JqZWN0MSwga2V5czEpIHx8XG4gICAgICAgIGlzRW1wdHlPYmplY3RXaXRoQ3VzdG9tUHJvdG90eXBlKG9iamVjdDIsIGtleXMyKSkge1xuICAgICAgICByZXR1cm4gT2JqZWN0LmlzKG9iamVjdDEsIG9iamVjdDIpO1xuICAgIH1cbiAgICBpZiAoIWtleXMxLmxlbmd0aCAmJiBBcnJheS5pc0FycmF5KG9iamVjdDEpICE9PSBBcnJheS5pc0FycmF5KG9iamVjdDIpKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgY29uc3QgdmlzaXRlZFBhaXJzID0gdmlzaXRlZC5nZXQob2JqZWN0MSk7XG4gICAgaWYgKHZpc2l0ZWRQYWlycyAmJiB2aXNpdGVkUGFpcnMuaGFzKG9iamVjdDIpKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAodmlzaXRlZFBhaXJzKSB7XG4gICAgICAgIHZpc2l0ZWRQYWlycy5hZGQob2JqZWN0Mik7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBjb25zdCB3cyA9IG5ldyBXZWFrU2V0KCk7XG4gICAgICAgIHdzLmFkZChvYmplY3QyKTtcbiAgICAgICAgdmlzaXRlZC5zZXQob2JqZWN0MSwgd3MpO1xuICAgIH1cbiAgICBmb3IgKGNvbnN0IGtleSBvZiBrZXlzMSkge1xuICAgICAgICBjb25zdCB2YWwxID0gb2JqZWN0MVtrZXldO1xuICAgICAgICBpZiAoIU9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QyLCBrZXkpKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFpc0Vycm9yT2JqZWN0IHx8IGtleSAhPT0gJ3JlZicpIHtcbiAgICAgICAgICAgIGNvbnN0IHZhbDIgPSBvYmplY3QyW2tleV07XG4gICAgICAgICAgICBpZiAoKGlzRGF0ZU9iamVjdCh2YWwxKSAmJiBpc0RhdGVPYmplY3QodmFsMikpIHx8XG4gICAgICAgICAgICAgICAgKChpc09iamVjdCh2YWwxKSB8fCBBcnJheS5pc0FycmF5KHZhbDEpKSAmJlxuICAgICAgICAgICAgICAgICAgICAoaXNPYmplY3QodmFsMikgfHwgQXJyYXkuaXNBcnJheSh2YWwyKSkpXG4gICAgICAgICAgICAgICAgPyAhZGVlcEVxdWFsKHZhbDEsIHZhbDIsIGlzRXJyb3JPYmplY3QsIHZpc2l0ZWQpXG4gICAgICAgICAgICAgICAgOiAhT2JqZWN0LmlzKHZhbDEsIHZhbDIpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xufVxuXG5jb25zdCBjbG9uZUZvcm1TdGF0ZSA9ICh7IGRlZmF1bHRWYWx1ZXMsIC4uLmZvcm1TdGF0ZSB9KSA9PiAoeyAuLi5jbG9uZU9iamVjdChmb3JtU3RhdGUpLCBkZWZhdWx0VmFsdWVzIH0pO1xuZnVuY3Rpb24gdXNlUmVzeW5jT25SZWNvbm5lY3QoZ2V0SW5pdGlhbFZhbHVlLCBjbG9uZSA9IGNsb25lT2JqZWN0KSB7XG4gICAgY29uc3QgX2Nvbm5lY3RlZCA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gICAgY29uc3QgX2luaXRpYWxpemVkID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgICBjb25zdCBfcHJldlZhbHVlID0gUmVhY3QudXNlUmVmKHVuZGVmaW5lZCk7XG4gICAgY29uc3QgX3JlbmRlckNvdW50ID0gUmVhY3QudXNlUmVmKDApO1xuICAgIF9yZW5kZXJDb3VudC5jdXJyZW50Kys7XG4gICAgaWYgKCFfaW5pdGlhbGl6ZWQuY3VycmVudCAmJiBnZXRJbml0aWFsVmFsdWUpIHtcbiAgICAgICAgX2luaXRpYWxpemVkLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICBfcHJldlZhbHVlLmN1cnJlbnQgPSBjbG9uZShnZXRJbml0aWFsVmFsdWUoKSk7XG4gICAgfVxuICAgIGNvbnN0IHJlc3luY0lmTmVlZGVkID0gUmVhY3QudXNlQ2FsbGJhY2soKGVuYWJsZWQsIGdldEN1cnJlbnRWYWx1ZSwgc2V0VmFsdWUpID0+IHtcbiAgICAgICAgaWYgKGVuYWJsZWQgJiZcbiAgICAgICAgICAgIChfY29ubmVjdGVkLmN1cnJlbnQgfHxcbiAgICAgICAgICAgICAgICAoX2luaXRpYWxpemVkLmN1cnJlbnQgJiYgX3JlbmRlckNvdW50LmN1cnJlbnQgPiAxKSkpIHtcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRWYWx1ZSA9IGdldEN1cnJlbnRWYWx1ZSgpO1xuICAgICAgICAgICAgaWYgKCFkZWVwRXF1YWwoX3ByZXZWYWx1ZS5jdXJyZW50LCBjdXJyZW50VmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgc2V0VmFsdWUoY3VycmVudFZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBfY29ubmVjdGVkLmN1cnJlbnQgPSB0cnVlO1xuICAgIH0sIFtdKTtcbiAgICBjb25zdCBzbmFwc2hvdCA9IFJlYWN0LnVzZUNhbGxiYWNrKChlbmFibGVkLCBnZXRDdXJyZW50VmFsdWUpID0+IHtcbiAgICAgICAgaWYgKGVuYWJsZWQpIHtcbiAgICAgICAgICAgIF9wcmV2VmFsdWUuY3VycmVudCA9IGNsb25lKGdldEN1cnJlbnRWYWx1ZSgpKTtcbiAgICAgICAgfVxuICAgIH0sIFtjbG9uZV0pO1xuICAgIHJldHVybiB7IHJlc3luY0lmTmVlZGVkLCBzbmFwc2hvdCB9O1xufVxuXG4vKipcbiAqIFN1YnNjcmliZXMgdG8gZm9ybSBzdGF0ZSB3aXRoIHJlLXJlbmRlcnMgaXNvbGF0ZWQgdG8gdGhpcyBob29rLlxuICogT3B0aW9uYWxseSBzY29wZSB0byBzcGVjaWZpYyBmaWVsZCBuYW1lcyB0byBtaW5pbWl6ZSByZS1yZW5kZXIgc3VyZmFjZS5cbiAqXG4gKiBAc2VlIFtBUEldKGh0dHBzOi8vcmVhY3QtaG9vay1mb3JtLmNvbS9kb2NzL3VzZWZvcm1zdGF0ZSlcbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiBjb25zdCB7IGVycm9ycywgaXNEaXJ0eSB9ID0gdXNlRm9ybVN0YXRlKHsgY29udHJvbCwgbmFtZTogXCJlbWFpbFwiIH0pO1xuICogYGBgXG4gKi9cbmZ1bmN0aW9uIHVzZUZvcm1TdGF0ZShwcm9wcykge1xuICAgIGNvbnN0IGZvcm1Db250cm9sID0gdXNlRm9ybUNvbnRyb2xDb250ZXh0KCk7XG4gICAgY29uc3QgeyBjb250cm9sID0gZm9ybUNvbnRyb2wsIGRpc2FibGVkLCBuYW1lLCBleGFjdCB9ID0gcHJvcHMgfHwge307XG4gICAgY29uc3QgZ2V0Q3VycmVudEZvcm1TdGF0ZSA9ICgpID0+ICh7XG4gICAgICAgIC4uLmNvbnRyb2wuX2Zvcm1TdGF0ZSxcbiAgICAgICAgZGVmYXVsdFZhbHVlczogY29udHJvbC5fZGVmYXVsdFZhbHVlcyxcbiAgICB9KTtcbiAgICBjb25zdCBbZm9ybVN0YXRlLCB1cGRhdGVGb3JtU3RhdGVdID0gUmVhY3QudXNlU3RhdGUoZ2V0Q3VycmVudEZvcm1TdGF0ZSk7XG4gICAgY29uc3QgX2xvY2FsUHJveHlGb3JtU3RhdGUgPSBSZWFjdC51c2VSZWYoe1xuICAgICAgICBpc0RpcnR5OiBmYWxzZSxcbiAgICAgICAgaXNMb2FkaW5nOiBmYWxzZSxcbiAgICAgICAgZGlydHlGaWVsZHM6IGZhbHNlLFxuICAgICAgICB0b3VjaGVkRmllbGRzOiBmYWxzZSxcbiAgICAgICAgdmFsaWRhdGluZ0ZpZWxkczogZmFsc2UsXG4gICAgICAgIGlzVmFsaWRhdGluZzogZmFsc2UsXG4gICAgICAgIGlzVmFsaWQ6IGZhbHNlLFxuICAgICAgICBlcnJvcnM6IGZhbHNlLFxuICAgIH0pO1xuICAgIGNvbnN0IHsgcmVzeW5jSWZOZWVkZWQsIHNuYXBzaG90IH0gPSB1c2VSZXN5bmNPblJlY29ubmVjdChnZXRDdXJyZW50Rm9ybVN0YXRlLCBjbG9uZUZvcm1TdGF0ZSk7XG4gICAgdXNlSXNvbW9ycGhpY0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgICAgIHJlc3luY0lmTmVlZGVkKCFkaXNhYmxlZCwgZ2V0Q3VycmVudEZvcm1TdGF0ZSwgdXBkYXRlRm9ybVN0YXRlKTtcbiAgICAgICAgY29uc3QgdW5zdWJzY3JpYmUgPSBjb250cm9sLl9zdWJzY3JpYmUoe1xuICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgIGZvcm1TdGF0ZTogX2xvY2FsUHJveHlGb3JtU3RhdGUuY3VycmVudCxcbiAgICAgICAgICAgIGV4YWN0LFxuICAgICAgICAgICAgY2FsbGJhY2s6IChmb3JtU3RhdGUpID0+IHtcbiAgICAgICAgICAgICAgICAhZGlzYWJsZWQgJiZcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybVN0YXRlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmNvbnRyb2wuX2Zvcm1TdGF0ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1TdGF0ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZXM6IGNvbnRyb2wuX2RlZmF1bHRWYWx1ZXMsXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICB1bnN1YnNjcmliZSgpO1xuICAgICAgICAgICAgc25hcHNob3QoIWRpc2FibGVkLCBnZXRDdXJyZW50Rm9ybVN0YXRlKTtcbiAgICAgICAgfTtcbiAgICB9LCBbY29udHJvbCwgbmFtZSwgZGlzYWJsZWQsIGV4YWN0LCByZXN5bmNJZk5lZWRlZCwgc25hcHNob3RdKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBfbG9jYWxQcm94eUZvcm1TdGF0ZS5jdXJyZW50LmlzVmFsaWQgJiYgY29udHJvbC5fc2V0VmFsaWQodHJ1ZSk7XG4gICAgfSwgW2NvbnRyb2xdKTtcbiAgICByZXR1cm4gUmVhY3QudXNlTWVtbygoKSA9PiBnZXRQcm94eUZvcm1TdGF0ZShmb3JtU3RhdGUsIGNvbnRyb2wsIF9sb2NhbFByb3h5Rm9ybVN0YXRlLmN1cnJlbnQsIGZhbHNlKSwgW2Zvcm1TdGF0ZSwgY29udHJvbF0pO1xufVxuXG52YXIgaXNTdHJpbmcgPSAodmFsdWUpID0+IHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZyc7XG5cbnZhciBnZW5lcmF0ZVdhdGNoT3V0cHV0ID0gKG5hbWVzLCBfbmFtZXMsIGZvcm1WYWx1ZXMsIGlzR2xvYmFsLCBkZWZhdWx0VmFsdWUpID0+IHtcbiAgICBpZiAoaXNTdHJpbmcobmFtZXMpKSB7XG4gICAgICAgIGlzR2xvYmFsICYmIF9uYW1lcy53YXRjaC5hZGQobmFtZXMpO1xuICAgICAgICByZXR1cm4gZ2V0KGZvcm1WYWx1ZXMsIG5hbWVzLCBkZWZhdWx0VmFsdWUpO1xuICAgIH1cbiAgICBpZiAoQXJyYXkuaXNBcnJheShuYW1lcykpIHtcbiAgICAgICAgcmV0dXJuIG5hbWVzLm1hcCgoZmllbGROYW1lKSA9PiAoaXNHbG9iYWwgJiYgX25hbWVzLndhdGNoLmFkZChmaWVsZE5hbWUpLFxuICAgICAgICAgICAgZ2V0KGZvcm1WYWx1ZXMsIGZpZWxkTmFtZSwgZ2V0KGRlZmF1bHRWYWx1ZSwgZmllbGROYW1lKSkpKTtcbiAgICB9XG4gICAgaXNHbG9iYWwgJiYgKF9uYW1lcy53YXRjaEFsbCA9IHRydWUpO1xuICAgIHJldHVybiBmb3JtVmFsdWVzO1xufTtcblxuLyoqXG4gKiBTdWJzY3JpYmVzIHRvIGZpZWxkIHZhbHVlIGNoYW5nZXMgYW5kIGlzb2xhdGVzIHJlLXJlbmRlcnMgdG8gdGhlIGhvb2sgbGV2ZWwuXG4gKlxuICogQHNlZSBbQVBJXShodHRwczovL3JlYWN0LWhvb2stZm9ybS5jb20vZG9jcy91c2V3YXRjaClcbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiBjb25zdCBlbWFpbCA9IHVzZVdhdGNoKHsgY29udHJvbCwgbmFtZTogXCJlbWFpbFwiIH0pO1xuICogY29uc3QgYWxsICAgPSB1c2VXYXRjaCh7IGNvbnRyb2wgfSk7XG4gKiBjb25zdCBhZHVsdCA9IHVzZVdhdGNoKHsgY29udHJvbCwgbmFtZTogXCJhZ2VcIiwgY29tcHV0ZTogKHYpID0+IHYgPj0gMTggfSk7XG4gKiBgYGBcbiAqL1xuZnVuY3Rpb24gdXNlV2F0Y2gocHJvcHMpIHtcbiAgICBjb25zdCBmb3JtQ29udHJvbCA9IHVzZUZvcm1Db250cm9sQ29udGV4dCgpO1xuICAgIGNvbnN0IHsgY29udHJvbCA9IGZvcm1Db250cm9sLCBuYW1lLCBkZWZhdWx0VmFsdWUsIGRpc2FibGVkLCBleGFjdCwgY29tcHV0ZSwgfSA9IHByb3BzIHx8IHt9O1xuICAgIGNvbnN0IF9kZWZhdWx0VmFsdWUgPSBSZWFjdC51c2VSZWYoZGVmYXVsdFZhbHVlKTtcbiAgICBjb25zdCBfY29tcHV0ZSA9IFJlYWN0LnVzZVJlZihjb21wdXRlKTtcbiAgICBjb25zdCBfcHJldkNvbnRyb2wgPSBSZWFjdC51c2VSZWYoY29udHJvbCk7XG4gICAgY29uc3QgX3ByZXZOYW1lID0gUmVhY3QudXNlUmVmKG5hbWUpO1xuICAgIF9jb21wdXRlLmN1cnJlbnQgPSBjb21wdXRlO1xuICAgIGNvbnN0IGdldEluaXRpYWxPdXRwdXQgPSAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGRlZmF1bHRWYWx1ZSA9IGNvbnRyb2wuX2dldFdhdGNoKG5hbWUsIF9kZWZhdWx0VmFsdWUuY3VycmVudCk7XG4gICAgICAgIHJldHVybiBfY29tcHV0ZS5jdXJyZW50ID8gX2NvbXB1dGUuY3VycmVudChkZWZhdWx0VmFsdWUpIDogZGVmYXVsdFZhbHVlO1xuICAgIH07XG4gICAgY29uc3QgW3ZhbHVlLCB1cGRhdGVWYWx1ZV0gPSBSZWFjdC51c2VTdGF0ZShnZXRJbml0aWFsT3V0cHV0KTtcbiAgICBjb25zdCBfY29tcHV0ZUZvcm1WYWx1ZXMgPSBSZWFjdC51c2VSZWYodmFsdWUpO1xuICAgIGNvbnN0IGdldEN1cnJlbnRPdXRwdXQgPSBSZWFjdC51c2VDYWxsYmFjaygodmFsdWVzKSA9PiB7XG4gICAgICAgIGNvbnN0IGZvcm1WYWx1ZXMgPSBnZW5lcmF0ZVdhdGNoT3V0cHV0KG5hbWUsIGNvbnRyb2wuX25hbWVzLCB2YWx1ZXMgfHwgY29udHJvbC5fZm9ybVZhbHVlcywgZmFsc2UsIF9kZWZhdWx0VmFsdWUuY3VycmVudCk7XG4gICAgICAgIHJldHVybiBfY29tcHV0ZS5jdXJyZW50XG4gICAgICAgICAgICA/IF9jb21wdXRlLmN1cnJlbnQoZm9ybVZhbHVlcylcbiAgICAgICAgICAgIDogZm9ybVZhbHVlcztcbiAgICB9LCBbY29udHJvbC5fZm9ybVZhbHVlcywgY29udHJvbC5fbmFtZXMsIG5hbWVdKTtcbiAgICBjb25zdCByZWZyZXNoVmFsdWUgPSBSZWFjdC51c2VDYWxsYmFjaygodmFsdWVzKSA9PiB7XG4gICAgICAgIGlmICghZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIGNvbnN0IGZvcm1WYWx1ZXMgPSBnZW5lcmF0ZVdhdGNoT3V0cHV0KG5hbWUsIGNvbnRyb2wuX25hbWVzLCB2YWx1ZXMgfHwgY29udHJvbC5fZm9ybVZhbHVlcywgZmFsc2UsIF9kZWZhdWx0VmFsdWUuY3VycmVudCk7XG4gICAgICAgICAgICBpZiAoX2NvbXB1dGUuY3VycmVudCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGNvbXB1dGVkRm9ybVZhbHVlcyA9IF9jb21wdXRlLmN1cnJlbnQoZm9ybVZhbHVlcyk7XG4gICAgICAgICAgICAgICAgaWYgKCFkZWVwRXF1YWwoY29tcHV0ZWRGb3JtVmFsdWVzLCBfY29tcHV0ZUZvcm1WYWx1ZXMuY3VycmVudCkpIHtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlVmFsdWUoY29tcHV0ZWRGb3JtVmFsdWVzKTtcbiAgICAgICAgICAgICAgICAgICAgX2NvbXB1dGVGb3JtVmFsdWVzLmN1cnJlbnQgPSBjb21wdXRlZEZvcm1WYWx1ZXM7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgdXBkYXRlVmFsdWUoZm9ybVZhbHVlcyk7XG4gICAgICAgICAgICAgICAgX2NvbXB1dGVGb3JtVmFsdWVzLmN1cnJlbnQgPSBmb3JtVmFsdWVzO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSwgW2NvbnRyb2wuX2Zvcm1WYWx1ZXMsIGNvbnRyb2wuX25hbWVzLCBkaXNhYmxlZCwgbmFtZV0pO1xuICAgIGNvbnN0IHsgcmVzeW5jSWZOZWVkZWQsIHNuYXBzaG90IH0gPSB1c2VSZXN5bmNPblJlY29ubmVjdChnZXRJbml0aWFsT3V0cHV0KTtcbiAgICBjb25zdCBfcmVmcmVzaFZhbHVlID0gUmVhY3QudXNlUmVmKHJlZnJlc2hWYWx1ZSk7XG4gICAgX3JlZnJlc2hWYWx1ZS5jdXJyZW50ID0gcmVmcmVzaFZhbHVlO1xuICAgIGNvbnN0IF9nZXRDdXJyZW50T3V0cHV0ID0gUmVhY3QudXNlUmVmKGdldEN1cnJlbnRPdXRwdXQpO1xuICAgIF9nZXRDdXJyZW50T3V0cHV0LmN1cnJlbnQgPSBnZXRDdXJyZW50T3V0cHV0O1xuICAgIHVzZUlzb21vcnBoaWNMYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoX3ByZXZDb250cm9sLmN1cnJlbnQgIT09IGNvbnRyb2wgfHxcbiAgICAgICAgICAgICFkZWVwRXF1YWwoX3ByZXZOYW1lLmN1cnJlbnQsIG5hbWUpKSB7XG4gICAgICAgICAgICBfcHJldkNvbnRyb2wuY3VycmVudCA9IGNvbnRyb2w7XG4gICAgICAgICAgICBfcHJldk5hbWUuY3VycmVudCA9IG5hbWU7XG4gICAgICAgICAgICBfcmVmcmVzaFZhbHVlLmN1cnJlbnQoKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHJlc3luY0lmTmVlZGVkKCFkaXNhYmxlZCwgKCkgPT4gX2dldEN1cnJlbnRPdXRwdXQuY3VycmVudCgpLCAoY3VycmVudFZhbHVlKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgbmV4dFZhbHVlID0gY2xvbmVPYmplY3QoY3VycmVudFZhbHVlKTtcbiAgICAgICAgICAgICAgICB1cGRhdGVWYWx1ZShuZXh0VmFsdWUpO1xuICAgICAgICAgICAgICAgIF9jb21wdXRlRm9ybVZhbHVlcy5jdXJyZW50ID0gbmV4dFZhbHVlO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdW5zdWJzY3JpYmUgPSBjb250cm9sLl9zdWJzY3JpYmUoe1xuICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgIGZvcm1TdGF0ZToge1xuICAgICAgICAgICAgICAgIHZhbHVlczogdHJ1ZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBleGFjdCxcbiAgICAgICAgICAgIGNhbGxiYWNrOiAoZm9ybVN0YXRlKSA9PiB7XG4gICAgICAgICAgICAgICAgX3JlZnJlc2hWYWx1ZS5jdXJyZW50KGZvcm1TdGF0ZS52YWx1ZXMpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICB1bnN1YnNjcmliZSgpO1xuICAgICAgICAgICAgc25hcHNob3QoIWRpc2FibGVkLCAoKSA9PiBfZ2V0Q3VycmVudE91dHB1dC5jdXJyZW50KCkpO1xuICAgICAgICB9O1xuICAgIH0sIFtjb250cm9sLCBleGFjdCwgbmFtZSwgZGlzYWJsZWQsIHJlc3luY0lmTmVlZGVkLCBzbmFwc2hvdF0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiBjb250cm9sLl9yZW1vdmVVbm1vdW50ZWQoKSk7XG4gICAgLy8gSWYgbmFtZSBvciBjb250cm9sIGNoYW5nZWQgZm9yIHRoaXMgcmVuZGVyLCBzeW5jaHJvbm91c2x5IHJlZmxlY3QgdGhlXG4gICAgLy8gbGF0ZXN0IHZhbHVlIHNvIGNhbGxlcnMgKGxpa2UgdXNlQ29udHJvbGxlcikgc2VlIHRoZSBjb3JyZWN0IHZhbHVlXG4gICAgLy8gaW1tZWRpYXRlbHkgb24gdGhlIHNhbWUgcmVuZGVyLlxuICAgIC8vIE9wdGltaXplOiBDaGVjayBjb250cm9sIHJlZmVyZW5jZSBmaXJzdCBiZWZvcmUgZXhwZW5zaXZlIGRlZXBFcXVhbFxuICAgIGNvbnN0IGNvbnRyb2xDaGFuZ2VkID0gX3ByZXZDb250cm9sLmN1cnJlbnQgIT09IGNvbnRyb2w7XG4gICAgY29uc3QgcHJldk5hbWUgPSBfcHJldk5hbWUuY3VycmVudDtcbiAgICBjb25zdCBuYW1lQ2hhbmdlZCA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gIWNvbnRyb2xDaGFuZ2VkICYmICFkZWVwRXF1YWwocHJldk5hbWUsIG5hbWUpLCBbY29udHJvbENoYW5nZWQsIG5hbWUsIHByZXZOYW1lXSk7XG4gICAgaWYgKGNvbnRyb2xDaGFuZ2VkIHx8IG5hbWVDaGFuZ2VkKSB7XG4gICAgICAgIF9kZWZhdWx0VmFsdWUuY3VycmVudCA9IGRlZmF1bHRWYWx1ZTtcbiAgICB9XG4gICAgY29uc3Qgc2hvdWxkUmV0dXJuSW1tZWRpYXRlID0gIWRpc2FibGVkICYmIChjb250cm9sQ2hhbmdlZCB8fCBuYW1lQ2hhbmdlZCk7XG4gICAgcmV0dXJuIHNob3VsZFJldHVybkltbWVkaWF0ZSA/IGdldEN1cnJlbnRPdXRwdXQoKSA6IHZhbHVlO1xufVxuXG4vKipcbiAqIEhvb2sgZm9yIGNvbnRyb2xsZWQgaW5wdXRzLiBSZXR1cm5zIGBmaWVsZGAsIGBmaWVsZFN0YXRlYCwgYW5kIGBmb3JtU3RhdGVgLlxuICogUmUtcmVuZGVycyBhcmUgaXNvbGF0ZWQgdG8gdGhlIGhvb2sgbGV2ZWwuXG4gKlxuICogQHNlZSBbQVBJXShodHRwczovL3JlYWN0LWhvb2stZm9ybS5jb20vZG9jcy91c2Vjb250cm9sbGVyKVxuICpcbiAqIEBleGFtcGxlXG4gKiBgYGB0c3hcbiAqIGNvbnN0IHsgZmllbGQsIGZpZWxkU3RhdGUgfSA9IHVzZUNvbnRyb2xsZXIoeyBjb250cm9sLCBuYW1lOiBcImVtYWlsXCIgfSk7XG4gKiByZXR1cm4gPGlucHV0IHsuLi5maWVsZH0gLz47XG4gKiBgYGBcbiAqL1xuZnVuY3Rpb24gdXNlQ29udHJvbGxlcihwcm9wcykge1xuICAgIGNvbnN0IGZvcm1Db250cm9sID0gdXNlRm9ybUNvbnRyb2xDb250ZXh0KCk7XG4gICAgY29uc3QgeyBuYW1lLCBkaXNhYmxlZCwgY29udHJvbCA9IGZvcm1Db250cm9sLCBzaG91bGRVbnJlZ2lzdGVyLCBkZWZhdWx0VmFsdWUsIGV4YWN0ID0gdHJ1ZSwgfSA9IHByb3BzO1xuICAgIGNvbnN0IGlzQXJyYXlGaWVsZCA9IGlzTmFtZUluRmllbGRBcnJheShjb250cm9sLl9uYW1lcy5hcnJheSwgbmFtZSk7XG4gICAgY29uc3QgZGVmYXVsdFZhbHVlTWVtbyA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBjb25zdCByZXNvbHZlZCA9IGdldChjb250cm9sLl9mb3JtVmFsdWVzLCBuYW1lLCBnZXQoY29udHJvbC5fZGVmYXVsdFZhbHVlcywgbmFtZSwgZGVmYXVsdFZhbHVlKSk7XG4gICAgICAgIHJldHVybiAoaXNVbmRlZmluZWQocmVzb2x2ZWQpID8gZ2V0TnVsbEFuY2VzdG9yVmFsdWUoY29udHJvbCwgbmFtZSkgOiByZXNvbHZlZCk7XG4gICAgfSwgW2NvbnRyb2wsIG5hbWUsIGRlZmF1bHRWYWx1ZV0pO1xuICAgIGNvbnN0IHZhbHVlID0gdXNlV2F0Y2goe1xuICAgICAgICBjb250cm9sLFxuICAgICAgICBuYW1lLFxuICAgICAgICBkZWZhdWx0VmFsdWU6IGRlZmF1bHRWYWx1ZU1lbW8sXG4gICAgICAgIGV4YWN0LFxuICAgIH0pO1xuICAgIGNvbnN0IGZvcm1TdGF0ZSA9IHVzZUZvcm1TdGF0ZSh7XG4gICAgICAgIGNvbnRyb2wsXG4gICAgICAgIG5hbWUsXG4gICAgICAgIGV4YWN0LFxuICAgIH0pO1xuICAgIGNvbnN0IF9wcm9wcyA9IFJlYWN0LnVzZVJlZihwcm9wcyk7XG4gICAgY29uc3QgX3Nob3VsZFVucmVnaXN0ZXIgPSBSZWFjdC51c2VSZWYoc2hvdWxkVW5yZWdpc3Rlcik7XG4gICAgY29uc3QgX3Byb3h5UmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICAgIGNvbnN0IF9yZWdpc3RlcmVkTmFtZSA9IFJlYWN0LnVzZVJlZih1bmRlZmluZWQpO1xuICAgIGNvbnN0IF9yZWdpc3RlclByb3BzID0gUmVhY3QudXNlUmVmKGNvbnRyb2wucmVnaXN0ZXIobmFtZSwge1xuICAgICAgICAuLi5wcm9wcy5ydWxlcyxcbiAgICAgICAgdmFsdWU6IF9yZWdpc3RlcmVkTmFtZS5jdXJyZW50ID09PSBuYW1lICYmICFnZXQoY29udHJvbC5fZmllbGRzLCBuYW1lKVxuICAgICAgICAgICAgPyB1bmRlZmluZWRcbiAgICAgICAgICAgIDogdmFsdWUsXG4gICAgICAgIC4uLihpc0Jvb2xlYW4ocHJvcHMuZGlzYWJsZWQpID8geyBkaXNhYmxlZDogcHJvcHMuZGlzYWJsZWQgfSA6IHt9KSxcbiAgICB9KSk7XG4gICAgX3JlZ2lzdGVyZWROYW1lLmN1cnJlbnQgPSBuYW1lO1xuICAgIF9wcm9wcy5jdXJyZW50ID0gcHJvcHM7XG4gICAgY29uc3QgZmllbGRTdGF0ZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gT2JqZWN0LmRlZmluZVByb3BlcnRpZXMoe30sIHtcbiAgICAgICAgaW52YWxpZDoge1xuICAgICAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIGdldDogKCkgPT4gISFnZXQoZm9ybVN0YXRlLmVycm9ycywgbmFtZSksXG4gICAgICAgIH0sXG4gICAgICAgIGlzRGlydHk6IHtcbiAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICBnZXQ6ICgpID0+ICEhZ2V0KGZvcm1TdGF0ZS5kaXJ0eUZpZWxkcywgbmFtZSksXG4gICAgICAgIH0sXG4gICAgICAgIGlzVG91Y2hlZDoge1xuICAgICAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIGdldDogKCkgPT4gISFnZXQoZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHMsIG5hbWUpLFxuICAgICAgICB9LFxuICAgICAgICBpc1ZhbGlkYXRpbmc6IHtcbiAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICBnZXQ6ICgpID0+ICEhZ2V0KGZvcm1TdGF0ZS52YWxpZGF0aW5nRmllbGRzLCBuYW1lKSxcbiAgICAgICAgfSxcbiAgICAgICAgZXJyb3I6IHtcbiAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICBnZXQ6ICgpID0+IGdldChmb3JtU3RhdGUuZXJyb3JzLCBuYW1lKSxcbiAgICAgICAgfSxcbiAgICB9KSwgW2Zvcm1TdGF0ZSwgbmFtZV0pO1xuICAgIGNvbnN0IG9uQ2hhbmdlID0gUmVhY3QudXNlQ2FsbGJhY2soKGV2ZW50KSA9PiB7XG4gICAgICAgIGNvbnN0IHZhbHVlID0gZ2V0RXZlbnRWYWx1ZShldmVudCk7XG4gICAgICAgIGlmICghZ2V0KGNvbnRyb2wuX2ZpZWxkcywgbmFtZSkpIHtcbiAgICAgICAgICAgIF9yZWdpc3RlclByb3BzLmN1cnJlbnQgPSBjb250cm9sLnJlZ2lzdGVyKG5hbWUsIHtcbiAgICAgICAgICAgICAgICAuLi5fcHJvcHMuY3VycmVudC5ydWxlcyxcbiAgICAgICAgICAgICAgICB2YWx1ZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBfcmVnaXN0ZXJQcm9wcy5jdXJyZW50Lm9uQ2hhbmdlKHtcbiAgICAgICAgICAgIHRhcmdldDoge1xuICAgICAgICAgICAgICAgIHZhbHVlOiBnZXRFdmVudFZhbHVlKGV2ZW50KSxcbiAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHR5cGU6IEVWRU5UUy5DSEFOR0UsXG4gICAgICAgIH0pO1xuICAgIH0sIFtuYW1lLCBjb250cm9sXSk7XG4gICAgY29uc3Qgb25CbHVyID0gUmVhY3QudXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgICAgICBjb25zdCB2YWx1ZSA9IGdldChjb250cm9sLl9mb3JtVmFsdWVzLCBuYW1lKTtcbiAgICAgICAgaWYgKCFnZXQoY29udHJvbC5fZmllbGRzLCBuYW1lKSkge1xuICAgICAgICAgICAgX3JlZ2lzdGVyUHJvcHMuY3VycmVudCA9IGNvbnRyb2wucmVnaXN0ZXIobmFtZSwge1xuICAgICAgICAgICAgICAgIC4uLl9wcm9wcy5jdXJyZW50LnJ1bGVzLFxuICAgICAgICAgICAgICAgIHZhbHVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIF9yZWdpc3RlclByb3BzLmN1cnJlbnQub25CbHVyKHtcbiAgICAgICAgICAgIHRhcmdldDoge1xuICAgICAgICAgICAgICAgIHZhbHVlLFxuICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgdHlwZTogRVZFTlRTLkJMVVIsXG4gICAgICAgIH0pO1xuICAgIH0sIFtuYW1lLCBjb250cm9sXSk7XG4gICAgY29uc3QgcmVmID0gUmVhY3QudXNlQ2FsbGJhY2soKGVsbSkgPT4ge1xuICAgICAgICBpZiAoZWxtKSB7XG4gICAgICAgICAgICBfcHJveHlSZWYuY3VycmVudCA9IHtcbiAgICAgICAgICAgICAgICBmb2N1czogKCkgPT4gaXNGdW5jdGlvbihlbG0uZm9jdXMpICYmIGVsbS5mb2N1cygpLFxuICAgICAgICAgICAgICAgIHNlbGVjdDogKCkgPT4gaXNGdW5jdGlvbihlbG0uc2VsZWN0KSAmJiBlbG0uc2VsZWN0KCksXG4gICAgICAgICAgICAgICAgc2V0Q3VzdG9tVmFsaWRpdHk6IChtZXNzYWdlKSA9PiBpc0Z1bmN0aW9uKGVsbS5zZXRDdXN0b21WYWxpZGl0eSkgJiYgZWxtLnNldEN1c3RvbVZhbGlkaXR5KG1lc3NhZ2UpLFxuICAgICAgICAgICAgICAgIHJlcG9ydFZhbGlkaXR5OiAoKSA9PiBpc0Z1bmN0aW9uKGVsbS5yZXBvcnRWYWxpZGl0eSkgJiYgZWxtLnJlcG9ydFZhbGlkaXR5KCksXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KGNvbnRyb2wuX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgIGlmIChmaWVsZCAmJiBmaWVsZC5fZiAmJiBlbG0pIHtcbiAgICAgICAgICAgIGZpZWxkLl9mLnJlZiA9IF9wcm94eVJlZi5jdXJyZW50O1xuICAgICAgICAgICAgZmllbGQuX2YuX2MgPSB0cnVlO1xuICAgICAgICB9XG4gICAgfSwgW2NvbnRyb2wuX2ZpZWxkcywgbmFtZV0pO1xuICAgIGNvbnN0IGZpZWxkID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgICAgICBuYW1lLFxuICAgICAgICB2YWx1ZSxcbiAgICAgICAgLi4uKGlzQm9vbGVhbihkaXNhYmxlZCkgfHwgZm9ybVN0YXRlLmRpc2FibGVkXG4gICAgICAgICAgICA/IHsgZGlzYWJsZWQ6IGZvcm1TdGF0ZS5kaXNhYmxlZCB8fCBkaXNhYmxlZCB9XG4gICAgICAgICAgICA6IHt9KSxcbiAgICAgICAgb25DaGFuZ2UsXG4gICAgICAgIG9uQmx1cixcbiAgICAgICAgcmVmLFxuICAgIH0pLCBbbmFtZSwgZGlzYWJsZWQsIGZvcm1TdGF0ZS5kaXNhYmxlZCwgb25DaGFuZ2UsIG9uQmx1ciwgcmVmLCB2YWx1ZV0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIF9zaG91bGRVbnJlZ2lzdGVyLmN1cnJlbnQgPSBzaG91bGRVbnJlZ2lzdGVyO1xuICAgICAgICBpZiAoY29udHJvbC5fb3B0aW9ucy5zaG91bGRVbnJlZ2lzdGVyIHx8IHNob3VsZFVucmVnaXN0ZXIpIHtcbiAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gY2xvbmVPYmplY3QoZ2V0KHNob3VsZFVucmVnaXN0ZXJcbiAgICAgICAgICAgICAgICA/IGNvbnRyb2wuX2RlZmF1bHRWYWx1ZXNcbiAgICAgICAgICAgICAgICA6IGNvbnRyb2wuX29wdGlvbnMudmFsdWVzIHx8IGNvbnRyb2wuX2RlZmF1bHRWYWx1ZXMsIG5hbWUsIGdldChjb250cm9sLl9vcHRpb25zLmRlZmF1bHRWYWx1ZXMsIG5hbWUsIF9wcm9wcy5jdXJyZW50LmRlZmF1bHRWYWx1ZSkpKTtcbiAgICAgICAgICAgIHNldChjb250cm9sLl9kZWZhdWx0VmFsdWVzLCBuYW1lLCB2YWx1ZSk7XG4gICAgICAgICAgICBpZiAoaXNVbmRlZmluZWQoZ2V0KGNvbnRyb2wuX2Zvcm1WYWx1ZXMsIG5hbWUpKSkge1xuICAgICAgICAgICAgICAgIHNldChjb250cm9sLl9mb3JtVmFsdWVzLCBuYW1lLCB2YWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoIWlzQXJyYXlGaWVsZCAmJlxuICAgICAgICAgICAgIWlzVW5kZWZpbmVkKF9wcm9wcy5jdXJyZW50LmRlZmF1bHRWYWx1ZSkgJiZcbiAgICAgICAgICAgIGlzVW5kZWZpbmVkKGdldChjb250cm9sLl9kZWZhdWx0VmFsdWVzLCBuYW1lKSkpIHtcbiAgICAgICAgICAgIHNldChjb250cm9sLl9kZWZhdWx0VmFsdWVzLCBuYW1lLCBjbG9uZU9iamVjdChfcHJvcHMuY3VycmVudC5kZWZhdWx0VmFsdWUpKTtcbiAgICAgICAgICAgIGNvbnRyb2wuX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZXM6IGNvbnRyb2wuX2RlZmF1bHRWYWx1ZXMsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH0sIFtjb250cm9sLCBuYW1lLCBpc0FycmF5RmllbGQsIHNob3VsZFVucmVnaXN0ZXJdKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBfcmVnaXN0ZXJQcm9wcy5jdXJyZW50ID0gY29udHJvbC5yZWdpc3RlcihuYW1lLCB7XG4gICAgICAgICAgICAuLi5fcHJvcHMuY3VycmVudC5ydWxlcyxcbiAgICAgICAgICAgIC4uLihpc0Jvb2xlYW4oX3Byb3BzLmN1cnJlbnQuZGlzYWJsZWQpXG4gICAgICAgICAgICAgICAgPyB7IGRpc2FibGVkOiBfcHJvcHMuY3VycmVudC5kaXNhYmxlZCB9XG4gICAgICAgICAgICAgICAgOiB7fSksXG4gICAgICAgIH0pO1xuICAgICAgICBjb25zdCB1cGRhdGVNb3VudGVkID0gKG5hbWUsIHZhbHVlKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBmaWVsZCA9IGdldChjb250cm9sLl9maWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgaWYgKGZpZWxkICYmIGZpZWxkLl9mKSB7XG4gICAgICAgICAgICAgICAgZmllbGQuX2YubW91bnQgPSB2YWx1ZTtcbiAgICAgICAgICAgICAgICBmaWVsZC5fZi5fYyA9IHZhbHVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICB1cGRhdGVNb3VudGVkKG5hbWUsIHRydWUpO1xuICAgICAgICAhaXNBcnJheUZpZWxkICYmXG4gICAgICAgICAgICBjb250cm9sLnJlZ2lzdGVyKG5hbWUsIHtcbiAgICAgICAgICAgICAgICAuLi5fcHJvcHMuY3VycmVudC5ydWxlcyxcbiAgICAgICAgICAgICAgICAuLi4oaXNCb29sZWFuKF9wcm9wcy5jdXJyZW50LmRpc2FibGVkKVxuICAgICAgICAgICAgICAgICAgICA/IHsgZGlzYWJsZWQ6IF9wcm9wcy5jdXJyZW50LmRpc2FibGVkIH1cbiAgICAgICAgICAgICAgICAgICAgOiB7fSksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgaWYgKF9wcm94eVJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgICBjb25zdCBmaWVsZCA9IGdldChjb250cm9sLl9maWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgaWYgKGZpZWxkICYmIGZpZWxkLl9mKSB7XG4gICAgICAgICAgICAgICAgZmllbGQuX2YucmVmID0gX3Byb3h5UmVmLmN1cnJlbnQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHNob3VsZFVucmVnaXN0ZXJGaWVsZCA9IGNvbnRyb2wuX29wdGlvbnMuc2hvdWxkVW5yZWdpc3RlciB8fCBfc2hvdWxkVW5yZWdpc3Rlci5jdXJyZW50O1xuICAgICAgICAgICAgKGlzQXJyYXlGaWVsZFxuICAgICAgICAgICAgICAgID8gc2hvdWxkVW5yZWdpc3RlckZpZWxkICYmICFjb250cm9sLl9zdGF0ZS5hY3Rpb25cbiAgICAgICAgICAgICAgICA6IHNob3VsZFVucmVnaXN0ZXJGaWVsZClcbiAgICAgICAgICAgICAgICA/IGNvbnRyb2wudW5yZWdpc3RlcihuYW1lKVxuICAgICAgICAgICAgICAgIDogdXBkYXRlTW91bnRlZChuYW1lLCBmYWxzZSk7XG4gICAgICAgIH07XG4gICAgfSwgW25hbWUsIGNvbnRyb2wsIGlzQXJyYXlGaWVsZF0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGNvbnRyb2wuX3NldERpc2FibGVkRmllbGQoe1xuICAgICAgICAgICAgZGlzYWJsZWQsXG4gICAgICAgICAgICBuYW1lLFxuICAgICAgICB9KTtcbiAgICB9LCBbZGlzYWJsZWQsIG5hbWUsIGNvbnRyb2xdKTtcbiAgICByZXR1cm4gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgICAgICBmaWVsZCxcbiAgICAgICAgZm9ybVN0YXRlLFxuICAgICAgICBmaWVsZFN0YXRlLFxuICAgIH0pLCBbZmllbGQsIGZvcm1TdGF0ZSwgZmllbGRTdGF0ZV0pO1xufVxuXG4vKipcbiAqIENvbXBvbmVudCB3cmFwcGVyIGFyb3VuZCBgdXNlQ29udHJvbGxlcmAgZm9yIGNvbnRyb2xsZWQgaW5wdXRzLlxuICpcbiAqIEBzZWUgW0FQSV0oaHR0cHM6Ly9yZWFjdC1ob29rLWZvcm0uY29tL2RvY3MvdXNlY29udHJvbGxlci9jb250cm9sbGVyKVxuICpcbiAqIEBleGFtcGxlXG4gKiBgYGB0c3hcbiAqIDxDb250cm9sbGVyXG4gKiAgIGNvbnRyb2w9e2NvbnRyb2x9XG4gKiAgIG5hbWU9XCJ0ZXN0XCJcbiAqICAgcmVuZGVyPXsoeyBmaWVsZCwgZmllbGRTdGF0ZSwgZm9ybVN0YXRlIH0pID0+IDxpbnB1dCB7Li4uZmllbGR9IC8+fVxuICogLz5cbiAqIGBgYFxuICovXG5jb25zdCBDb250cm9sbGVyID0gKHByb3BzKSA9PiBwcm9wcy5yZW5kZXIodXNlQ29udHJvbGxlcihwcm9wcykpO1xuXG4vKipcbiAqIERpc3BsYXlzIHRoZSB2YWxpZGF0aW9uIGVycm9yIGZvciBhIHNpbmdsZSBmaWVsZC5cbiAqIFJlYWRzIGZyb20gYGNvbnRyb2xgIHdoZW4gcHJvdmlkZWQsIG90aGVyd2lzZSBmcm9tIHRoZSBuZWFyZXN0IGBGb3JtUHJvdmlkZXJgLlxuICpcbiAqIEBzZWUgW0FQSV0oaHR0cHM6Ly9yZWFjdC1ob29rLWZvcm0uY29tL2RvY3MvdXNlZm9ybXN0YXRlL2Vycm9ybWVzc2FnZSlcbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiA8RXJyb3JNZXNzYWdlIGNvbnRyb2w9e2NvbnRyb2x9IG5hbWU9XCJlbWFpbFwiIGFzPVwicFwiIC8+XG4gKiA8RXJyb3JNZXNzYWdlIG5hbWU9XCJlbWFpbFwiIGFzPVwic3BhblwiIC8+XG4gKiA8RXJyb3JNZXNzYWdlIGNvbnRyb2w9e2NvbnRyb2x9IG5hbWU9XCJlbWFpbFwiXG4gKiAgIHJlbmRlcj17KHsgbWVzc2FnZSB9KSA9PiA8QWxlcnQ+e21lc3NhZ2V9PC9BbGVydD59IC8+XG4gKiBgYGBcbiAqL1xuY29uc3QgRXJyb3JNZXNzYWdlID0gKHsgYXMsIGNvbnRyb2wsIG5hbWUsIHJlbmRlciwgfSkgPT4ge1xuICAgIGNvbnN0IHsgZXJyb3JzIH0gPSB1c2VGb3JtU3RhdGUoe1xuICAgICAgICBjb250cm9sLFxuICAgICAgICBuYW1lOiBuYW1lLFxuICAgIH0pO1xuICAgIGNvbnN0IGVycm9yID0gZ2V0KGVycm9ycywgbmFtZSk7XG4gICAgaWYgKCFlcnJvcikge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgY29uc3QgbWVzc2FnZSA9IGVycm9yLm1lc3NhZ2UgfHwgJyc7XG4gICAgaWYgKHJlbmRlcikge1xuICAgICAgICByZXR1cm4gcmVuZGVyKHsgbWVzc2FnZSwgbWVzc2FnZXM6IGVycm9yLnR5cGVzIH0pO1xuICAgIH1cbiAgICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChhcyB8fCBSZWFjdC5GcmFnbWVudCwgbnVsbCwgbWVzc2FnZSk7XG59O1xuXG52YXIgZ2VuZXJhdGVJZCA9ICgpID0+IHR5cGVvZiBjcnlwdG8gIT09ICd1bmRlZmluZWQnICYmIGNyeXB0by5yYW5kb21VVUlEXG4gICAgPyBjcnlwdG8ucmFuZG9tVVVJRCgpXG4gICAgOiAneHh4eHh4eHgteHh4eC00eHh4LXl4eHgteHh4eHh4eHh4eHh4Jy5yZXBsYWNlKC9beHldL2csIChjKSA9PiB7XG4gICAgICAgIGNvbnN0IHIgPSAoTWF0aC5yYW5kb20oKSAqIDE2KSB8IDA7XG4gICAgICAgIHJldHVybiAoYyA9PT0gJ3gnID8gciA6IChyICYgMHgzKSB8IDB4OCkudG9TdHJpbmcoMTYpO1xuICAgIH0pO1xuXG52YXIgZ2V0Rm9jdXNGaWVsZE5hbWUgPSAobmFtZSwgaW5kZXgsIG9wdGlvbnMgPSB7fSkgPT4gb3B0aW9ucy5zaG91bGRGb2N1cyB8fCBpc1VuZGVmaW5lZChvcHRpb25zLnNob3VsZEZvY3VzKVxuICAgID8gb3B0aW9ucy5mb2N1c05hbWUgfHxcbiAgICAgICAgYCR7bmFtZX0uJHtpc1VuZGVmaW5lZChvcHRpb25zLmZvY3VzSW5kZXgpID8gaW5kZXggOiBvcHRpb25zLmZvY3VzSW5kZXh9LmBcbiAgICA6ICcnO1xuXG52YXIgZ2V0VmFsaWRhdGlvbk1vZGVzID0gKG1vZGUpID0+ICh7XG4gICAgaXNPblN1Ym1pdDogIW1vZGUgfHwgbW9kZSA9PT0gVkFMSURBVElPTl9NT0RFLm9uU3VibWl0LFxuICAgIGlzT25CbHVyOiBtb2RlID09PSBWQUxJREFUSU9OX01PREUub25CbHVyLFxuICAgIGlzT25DaGFuZ2U6IG1vZGUgPT09IFZBTElEQVRJT05fTU9ERS5vbkNoYW5nZSxcbiAgICBpc09uQWxsOiBtb2RlID09PSBWQUxJREFUSU9OX01PREUuYWxsLFxuICAgIGlzT25Ub3VjaDogbW9kZSA9PT0gVkFMSURBVElPTl9NT0RFLm9uVG91Y2hlZCxcbn0pO1xuXG52YXIgaXNXYXRjaGVkID0gKG5hbWUsIF9uYW1lcywgaXNCbHVyRXZlbnQpID0+IHtcbiAgICBpZiAoaXNCbHVyRXZlbnQpXG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICBpZiAoX25hbWVzLndhdGNoQWxsIHx8IF9uYW1lcy53YXRjaC5oYXMobmFtZSkpXG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIGZvciAoY29uc3Qgd2F0Y2hOYW1lIG9mIF9uYW1lcy53YXRjaCkge1xuICAgICAgICBpZiAobmFtZS5zdGFydHNXaXRoKHdhdGNoTmFtZSkgJiYgbmFtZS5jaGFyQXQod2F0Y2hOYW1lLmxlbmd0aCkgPT09ICcuJylcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG59O1xuXG5jb25zdCBpdGVyYXRlRmllbGRzQnlBY3Rpb24gPSAoZmllbGRzLCBhY3Rpb24sIGZpZWxkc05hbWVzKSA9PiB7XG4gICAgdmFyIF9hO1xuICAgIGZvciAoY29uc3Qga2V5IG9mIGZpZWxkc05hbWVzIHx8IE9iamVjdC5rZXlzKGZpZWxkcykpIHtcbiAgICAgICAgaWYgKGtleSA9PT0gJ19mJykge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZmllbGQgPSAoZmllbGRzTmFtZXMgPyBnZXQoZmllbGRzLCBrZXkpIDogZmllbGRzW2tleV0pO1xuICAgICAgICBpZiAoZmllbGQpIHtcbiAgICAgICAgICAgIGNvbnN0IHsgX2YgfSA9IGZpZWxkO1xuICAgICAgICAgICAgaWYgKF9mKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZ3JvdXBSZWYgPSAoX2EgPSBfZi5yZWZzKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2EuZmluZCgocmVmKSA9PiAhcmVmLmRpc2FibGVkKTtcbiAgICAgICAgICAgICAgICBpZiAoZ3JvdXBSZWYgJiYgYWN0aW9uKGdyb3VwUmVmLCBfZi5uYW1lKSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoX2YucmVmICYmIGFjdGlvbihfZi5yZWYsIF9mLm5hbWUpKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGl0ZXJhdGVGaWVsZHNCeUFjdGlvbihmaWVsZCwgYWN0aW9uKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChpc09iamVjdChmaWVsZCkgfHwgQXJyYXkuaXNBcnJheShmaWVsZCkpIHtcbiAgICAgICAgICAgICAgICBpZiAoaXRlcmF0ZUZpZWxkc0J5QWN0aW9uKGZpZWxkLCBhY3Rpb24pKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm47XG59O1xuXG52YXIgdXBkYXRlRmllbGRBcnJheVJvb3RFcnJvciA9IChlcnJvcnMsIGVycm9yLCBuYW1lKSA9PiB7XG4gICAgY29uc3QgZXhpc3RpbmdFcnJvcnMgPSBnZXQoZXJyb3JzLCBuYW1lKTtcbiAgICBjb25zdCBmaWVsZEFycmF5RXJyb3JzID0gQXJyYXkuaXNBcnJheShleGlzdGluZ0Vycm9ycykgPyBleGlzdGluZ0Vycm9ycyA6IFtdO1xuICAgIHNldChmaWVsZEFycmF5RXJyb3JzLCBST09UX0VSUk9SX1RZUEUsIGdldChlcnJvcltuYW1lXSwgUk9PVF9FUlJPUl9UWVBFLCBlcnJvcltuYW1lXSkpO1xuICAgIHNldChlcnJvcnMsIG5hbWUsIGZpZWxkQXJyYXlFcnJvcnMpO1xuICAgIHJldHVybiBlcnJvcnM7XG59O1xuXG52YXIgaXNFbXB0eU9iamVjdCA9ICh2YWx1ZSkgPT4gaXNPYmplY3QodmFsdWUpICYmICFPYmplY3Qua2V5cyh2YWx1ZSkubGVuZ3RoO1xuXG52YXIgaXNIVE1MRWxlbWVudCA9ICh2YWx1ZSkgPT4ge1xuICAgIGlmICghaXNXZWIpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCBvd25lciA9IHZhbHVlID8gdmFsdWUub3duZXJEb2N1bWVudCA6IDA7XG4gICAgcmV0dXJuICh2YWx1ZSBpbnN0YW5jZW9mXG4gICAgICAgIChvd25lciAmJiBvd25lci5kZWZhdWx0VmlldyA/IG93bmVyLmRlZmF1bHRWaWV3LkhUTUxFbGVtZW50IDogSFRNTEVsZW1lbnQpKTtcbn07XG5cbnZhciBpc1JhZGlvSW5wdXQgPSAoZWxlbWVudCkgPT4gZWxlbWVudC50eXBlID09PSAncmFkaW8nO1xuXG52YXIgaXNSZWdleCA9ICh2YWx1ZSkgPT4gdmFsdWUgaW5zdGFuY2VvZiBSZWdFeHA7XG5cbnZhciBhcHBlbmRFcnJvcnMgPSAobmFtZSwgdmFsaWRhdGVBbGxGaWVsZENyaXRlcmlhLCBlcnJvcnMsIHR5cGUsIG1lc3NhZ2UpID0+IHZhbGlkYXRlQWxsRmllbGRDcml0ZXJpYVxuICAgID8ge1xuICAgICAgICAuLi5lcnJvcnNbbmFtZV0sXG4gICAgICAgIHR5cGVzOiB7XG4gICAgICAgICAgICAuLi4oZXJyb3JzW25hbWVdICYmIGVycm9yc1tuYW1lXS50eXBlcyA/IGVycm9yc1tuYW1lXS50eXBlcyA6IHt9KSxcbiAgICAgICAgICAgIFt0eXBlXTogbWVzc2FnZSB8fCB0cnVlLFxuICAgICAgICB9LFxuICAgIH1cbiAgICA6IHt9O1xuXG5jb25zdCBkZWZhdWx0UmVzdWx0ID0ge1xuICAgIHZhbHVlOiBmYWxzZSxcbiAgICBpc1ZhbGlkOiBmYWxzZSxcbn07XG5jb25zdCB2YWxpZFJlc3VsdCA9IHsgdmFsdWU6IHRydWUsIGlzVmFsaWQ6IHRydWUgfTtcbnZhciBnZXRDaGVja2JveFZhbHVlID0gKG9wdGlvbnMpID0+IHtcbiAgICBpZiAoIUFycmF5LmlzQXJyYXkob3B0aW9ucykpIHtcbiAgICAgICAgcmV0dXJuIGRlZmF1bHRSZXN1bHQ7XG4gICAgfVxuICAgIGlmIChvcHRpb25zLmxlbmd0aCA+IDEpIHtcbiAgICAgICAgY29uc3QgdmFsdWVzID0gb3B0aW9uc1xuICAgICAgICAgICAgLmZpbHRlcigob3B0aW9uKSA9PiBvcHRpb24gJiYgb3B0aW9uLmNoZWNrZWQgJiYgIW9wdGlvbi5kaXNhYmxlZClcbiAgICAgICAgICAgIC5tYXAoKG9wdGlvbikgPT4gb3B0aW9uLnZhbHVlKTtcbiAgICAgICAgcmV0dXJuIHsgdmFsdWU6IHZhbHVlcywgaXNWYWxpZDogISF2YWx1ZXMubGVuZ3RoIH07XG4gICAgfVxuICAgIGNvbnN0IG9wdGlvbiA9IG9wdGlvbnNbMF07XG4gICAgaWYgKCFvcHRpb24gfHwgIW9wdGlvbi5jaGVja2VkIHx8IG9wdGlvbi5kaXNhYmxlZCkge1xuICAgICAgICByZXR1cm4gZGVmYXVsdFJlc3VsdDtcbiAgICB9XG4gICAgaWYgKCFvcHRpb24uYXR0cmlidXRlcyB8fCAhKCd2YWx1ZScgaW4gb3B0aW9uLmF0dHJpYnV0ZXMpKSB7XG4gICAgICAgIHJldHVybiB2YWxpZFJlc3VsdDtcbiAgICB9XG4gICAgcmV0dXJuIGlzVW5kZWZpbmVkKG9wdGlvbi52YWx1ZSkgfHwgb3B0aW9uLnZhbHVlID09PSAnJ1xuICAgICAgICA/IHZhbGlkUmVzdWx0XG4gICAgICAgIDogeyB2YWx1ZTogb3B0aW9uLnZhbHVlLCBpc1ZhbGlkOiB0cnVlIH07XG59O1xuXG5jb25zdCBkZWZhdWx0UmV0dXJuID0ge1xuICAgIGlzVmFsaWQ6IGZhbHNlLFxuICAgIHZhbHVlOiBudWxsLFxufTtcbnZhciBnZXRSYWRpb1ZhbHVlID0gKG9wdGlvbnMpID0+IEFycmF5LmlzQXJyYXkob3B0aW9ucylcbiAgICA/IG9wdGlvbnMucmVkdWNlKChwcmV2aW91cywgb3B0aW9uKSA9PiBvcHRpb24gJiYgb3B0aW9uLmNoZWNrZWQgJiYgIW9wdGlvbi5kaXNhYmxlZFxuICAgICAgICA/IHtcbiAgICAgICAgICAgIGlzVmFsaWQ6IHRydWUsXG4gICAgICAgICAgICB2YWx1ZTogb3B0aW9uLnZhbHVlLFxuICAgICAgICB9XG4gICAgICAgIDogcHJldmlvdXMsIGRlZmF1bHRSZXR1cm4pXG4gICAgOiBkZWZhdWx0UmV0dXJuO1xuXG5mdW5jdGlvbiBnZXRWYWxpZGF0ZUVycm9yKHJlc3VsdCwgcmVmLCB0eXBlID0gJ3ZhbGlkYXRlJykge1xuICAgIGlmIChpc1N0cmluZyhyZXN1bHQpIHx8XG4gICAgICAgIChBcnJheS5pc0FycmF5KHJlc3VsdCkgJiYgISFyZXN1bHQubGVuZ3RoICYmIHJlc3VsdC5ldmVyeShpc1N0cmluZykpIHx8XG4gICAgICAgIChpc0Jvb2xlYW4ocmVzdWx0KSAmJiAhcmVzdWx0KSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgdHlwZSxcbiAgICAgICAgICAgIG1lc3NhZ2U6IGlzU3RyaW5nKHJlc3VsdCkgPyByZXN1bHQgOiAnJyxcbiAgICAgICAgICAgIHJlZixcbiAgICAgICAgfTtcbiAgICB9XG59XG5cbnZhciBnZXRWYWx1ZUFuZE1lc3NhZ2UgPSAodmFsaWRhdGlvbkRhdGEpID0+IGlzT2JqZWN0KHZhbGlkYXRpb25EYXRhKSAmJiAhaXNSZWdleCh2YWxpZGF0aW9uRGF0YSlcbiAgICA/IHZhbGlkYXRpb25EYXRhXG4gICAgOiB7XG4gICAgICAgIHZhbHVlOiB2YWxpZGF0aW9uRGF0YSxcbiAgICAgICAgbWVzc2FnZTogJycsXG4gICAgfTtcblxudmFyIHZhbGlkYXRlRmllbGQgPSBhc3luYyAoZmllbGQsIGRpc2FibGVkRmllbGROYW1lcywgZm9ybVZhbHVlcywgdmFsaWRhdGVBbGxGaWVsZENyaXRlcmlhLCBzaG91bGRVc2VOYXRpdmVWYWxpZGF0aW9uLCBpc0ZpZWxkQXJyYXkpID0+IHtcbiAgICBjb25zdCB7IHJlZiwgcmVmcywgcmVxdWlyZWQsIG1heExlbmd0aCwgbWluTGVuZ3RoLCBtaW4sIG1heCwgcGF0dGVybiwgdmFsaWRhdGUsIG5hbWUsIHZhbHVlQXNOdW1iZXIsIG1vdW50LCBfYywgfSA9IGZpZWxkLl9mO1xuICAgIGNvbnN0IGlucHV0VmFsdWUgPSBnZXQoZm9ybVZhbHVlcywgbmFtZSk7XG4gICAgaWYgKCFtb3VudCB8fCBkaXNhYmxlZEZpZWxkTmFtZXMuaGFzKG5hbWUpKSB7XG4gICAgICAgIHJldHVybiB7fTtcbiAgICB9XG4gICAgY29uc3QgaW5wdXRSZWYgPSByZWZzID8gcmVmc1swXSA6IHJlZjtcbiAgICBjb25zdCBzZXRDdXN0b21WYWxpZGl0eSA9IChtZXNzYWdlKSA9PiB7XG4gICAgICAgIGlmIChzaG91bGRVc2VOYXRpdmVWYWxpZGF0aW9uICYmIGlucHV0UmVmLnJlcG9ydFZhbGlkaXR5KSB7XG4gICAgICAgICAgICBjb25zdCB2YWxpZGl0eU1lc3NhZ2UgPSBpc0Jvb2xlYW4obWVzc2FnZSkgPyAnJyA6IG1lc3NhZ2UgfHwgJyc7XG4gICAgICAgICAgICBpZiAocmVmcykge1xuICAgICAgICAgICAgICAgIHJlZnMuZm9yRWFjaCgocmVmKSA9PiBpc0Z1bmN0aW9uKHJlZi5zZXRDdXN0b21WYWxpZGl0eSkgJiZcbiAgICAgICAgICAgICAgICAgICAgcmVmLnNldEN1c3RvbVZhbGlkaXR5KHZhbGlkaXR5TWVzc2FnZSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgaW5wdXRSZWYuc2V0Q3VzdG9tVmFsaWRpdHkodmFsaWRpdHlNZXNzYWdlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlucHV0UmVmLnJlcG9ydFZhbGlkaXR5KCk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IGVycm9yID0ge307XG4gICAgY29uc3QgaXNSYWRpbyA9ICFfYyAmJiBpc1JhZGlvSW5wdXQocmVmKTtcbiAgICBjb25zdCBpc0NoZWNrQm94ID0gIV9jICYmIGlzQ2hlY2tCb3hJbnB1dChyZWYpO1xuICAgIGNvbnN0IGlzUmFkaW9PckNoZWNrYm94ID0gaXNSYWRpbyB8fCBpc0NoZWNrQm94O1xuICAgIGNvbnN0IGlzRW1wdHkgPSAoKHZhbHVlQXNOdW1iZXIgfHwgaXNGaWxlSW5wdXQocmVmKSkgJiZcbiAgICAgICAgaXNVbmRlZmluZWQocmVmLnZhbHVlKSAmJlxuICAgICAgICBpc1VuZGVmaW5lZChpbnB1dFZhbHVlKSkgfHxcbiAgICAgICAgKGlzSFRNTEVsZW1lbnQocmVmKSAmJiByZWYudmFsdWUgPT09ICcnICYmICFfYykgfHxcbiAgICAgICAgaW5wdXRWYWx1ZSA9PT0gJycgfHxcbiAgICAgICAgKEFycmF5LmlzQXJyYXkoaW5wdXRWYWx1ZSkgJiYgIWlucHV0VmFsdWUubGVuZ3RoKTtcbiAgICBjb25zdCBhcHBlbmRFcnJvcnNDdXJyeSA9IGFwcGVuZEVycm9ycy5iaW5kKG51bGwsIG5hbWUsIHZhbGlkYXRlQWxsRmllbGRDcml0ZXJpYSwgZXJyb3IpO1xuICAgIGNvbnN0IGdldE1pbk1heE1lc3NhZ2UgPSAoZXhjZWVkTWF4LCBtYXhMZW5ndGhNZXNzYWdlLCBtaW5MZW5ndGhNZXNzYWdlLCBtYXhUeXBlID0gSU5QVVRfVkFMSURBVElPTl9SVUxFUy5tYXhMZW5ndGgsIG1pblR5cGUgPSBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLm1pbkxlbmd0aCkgPT4ge1xuICAgICAgICBjb25zdCBtZXNzYWdlID0gZXhjZWVkTWF4ID8gbWF4TGVuZ3RoTWVzc2FnZSA6IG1pbkxlbmd0aE1lc3NhZ2U7XG4gICAgICAgIGVycm9yW25hbWVdID0ge1xuICAgICAgICAgICAgdHlwZTogZXhjZWVkTWF4ID8gbWF4VHlwZSA6IG1pblR5cGUsXG4gICAgICAgICAgICBtZXNzYWdlLFxuICAgICAgICAgICAgcmVmLFxuICAgICAgICAgICAgLi4uYXBwZW5kRXJyb3JzQ3VycnkoZXhjZWVkTWF4ID8gbWF4VHlwZSA6IG1pblR5cGUsIG1lc3NhZ2UpLFxuICAgICAgICB9O1xuICAgIH07XG4gICAgaWYgKGlzRmllbGRBcnJheVxuICAgICAgICA/ICFBcnJheS5pc0FycmF5KGlucHV0VmFsdWUpIHx8ICFpbnB1dFZhbHVlLmxlbmd0aFxuICAgICAgICA6IHJlcXVpcmVkICYmXG4gICAgICAgICAgICAoKCFpc1JhZGlvT3JDaGVja2JveCAmJiAoaXNFbXB0eSB8fCBpc051bGxPclVuZGVmaW5lZChpbnB1dFZhbHVlKSkpIHx8XG4gICAgICAgICAgICAgICAgKGlzQm9vbGVhbihpbnB1dFZhbHVlKSAmJiAhaW5wdXRWYWx1ZSkgfHxcbiAgICAgICAgICAgICAgICAoaXNDaGVja0JveCAmJiAhZ2V0Q2hlY2tib3hWYWx1ZShyZWZzKS5pc1ZhbGlkKSB8fFxuICAgICAgICAgICAgICAgIChpc1JhZGlvICYmICFnZXRSYWRpb1ZhbHVlKHJlZnMpLmlzVmFsaWQpKSkge1xuICAgICAgICBjb25zdCB7IHZhbHVlLCBtZXNzYWdlIH0gPSBpc1N0cmluZyhyZXF1aXJlZClcbiAgICAgICAgICAgID8geyB2YWx1ZTogISFyZXF1aXJlZCwgbWVzc2FnZTogcmVxdWlyZWQgfVxuICAgICAgICAgICAgOiBnZXRWYWx1ZUFuZE1lc3NhZ2UocmVxdWlyZWQpO1xuICAgICAgICBpZiAodmFsdWUpIHtcbiAgICAgICAgICAgIGVycm9yW25hbWVdID0ge1xuICAgICAgICAgICAgICAgIHR5cGU6IElOUFVUX1ZBTElEQVRJT05fUlVMRVMucmVxdWlyZWQsXG4gICAgICAgICAgICAgICAgbWVzc2FnZSxcbiAgICAgICAgICAgICAgICByZWY6IGlucHV0UmVmLFxuICAgICAgICAgICAgICAgIC4uLmFwcGVuZEVycm9yc0N1cnJ5KElOUFVUX1ZBTElEQVRJT05fUlVMRVMucmVxdWlyZWQsIG1lc3NhZ2UpLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGlmICghdmFsaWRhdGVBbGxGaWVsZENyaXRlcmlhKSB7XG4gICAgICAgICAgICAgICAgc2V0Q3VzdG9tVmFsaWRpdHkobWVzc2FnZSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGVycm9yO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIGlmICghaXNFbXB0eSAmJiAoIWlzTnVsbE9yVW5kZWZpbmVkKG1pbikgfHwgIWlzTnVsbE9yVW5kZWZpbmVkKG1heCkpKSB7XG4gICAgICAgIGxldCBleGNlZWRNYXg7XG4gICAgICAgIGxldCBleGNlZWRNaW47XG4gICAgICAgIGNvbnN0IG1heE91dHB1dCA9IGdldFZhbHVlQW5kTWVzc2FnZShtYXgpO1xuICAgICAgICBjb25zdCBtaW5PdXRwdXQgPSBnZXRWYWx1ZUFuZE1lc3NhZ2UobWluKTtcbiAgICAgICAgaWYgKCFpc051bGxPclVuZGVmaW5lZChpbnB1dFZhbHVlKSAmJlxuICAgICAgICAgICAgIWlzRGF0ZU9iamVjdChpbnB1dFZhbHVlKSAmJlxuICAgICAgICAgICAgIWlzTmFOKGlucHV0VmFsdWUpKSB7XG4gICAgICAgICAgICBjb25zdCB2YWx1ZU51bWJlciA9ICghX2MgJiYgcmVmLnZhbHVlQXNOdW1iZXIpIHx8XG4gICAgICAgICAgICAgICAgKGlucHV0VmFsdWUgPyAraW5wdXRWYWx1ZSA6IGlucHV0VmFsdWUpO1xuICAgICAgICAgICAgaWYgKCFpc051bGxPclVuZGVmaW5lZChtYXhPdXRwdXQudmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgZXhjZWVkTWF4ID0gdmFsdWVOdW1iZXIgPiBtYXhPdXRwdXQudmFsdWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIWlzTnVsbE9yVW5kZWZpbmVkKG1pbk91dHB1dC52YWx1ZSkpIHtcbiAgICAgICAgICAgICAgICBleGNlZWRNaW4gPSB2YWx1ZU51bWJlciA8IG1pbk91dHB1dC52YWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IHZhbHVlRGF0ZSA9ICghX2MgJiYgcmVmLnZhbHVlQXNEYXRlKSB8fFxuICAgICAgICAgICAgICAgIG5ldyBEYXRlKGlucHV0VmFsdWUpO1xuICAgICAgICAgICAgY29uc3QgY29udmVydFRpbWVUb0RhdGUgPSAodGltZSkgPT4gbmV3IERhdGUobmV3IERhdGUoKS50b0RhdGVTdHJpbmcoKSArICcgJyArIHRpbWUpO1xuICAgICAgICAgICAgY29uc3QgaXNUaW1lID0gcmVmLnR5cGUgPT0gJ3RpbWUnO1xuICAgICAgICAgICAgY29uc3QgaXNXZWVrID0gcmVmLnR5cGUgPT0gJ3dlZWsnO1xuICAgICAgICAgICAgaWYgKGlzU3RyaW5nKG1heE91dHB1dC52YWx1ZSkgJiYgaW5wdXRWYWx1ZSkge1xuICAgICAgICAgICAgICAgIGV4Y2VlZE1heCA9IGlzVGltZVxuICAgICAgICAgICAgICAgICAgICA/IGNvbnZlcnRUaW1lVG9EYXRlKGlucHV0VmFsdWUpID4gY29udmVydFRpbWVUb0RhdGUobWF4T3V0cHV0LnZhbHVlKVxuICAgICAgICAgICAgICAgICAgICA6IGlzV2Vla1xuICAgICAgICAgICAgICAgICAgICAgICAgPyBpbnB1dFZhbHVlID4gbWF4T3V0cHV0LnZhbHVlXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHZhbHVlRGF0ZSA+IG5ldyBEYXRlKG1heE91dHB1dC52YWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaXNTdHJpbmcobWluT3V0cHV0LnZhbHVlKSAmJiBpbnB1dFZhbHVlKSB7XG4gICAgICAgICAgICAgICAgZXhjZWVkTWluID0gaXNUaW1lXG4gICAgICAgICAgICAgICAgICAgID8gY29udmVydFRpbWVUb0RhdGUoaW5wdXRWYWx1ZSkgPCBjb252ZXJ0VGltZVRvRGF0ZShtaW5PdXRwdXQudmFsdWUpXG4gICAgICAgICAgICAgICAgICAgIDogaXNXZWVrXG4gICAgICAgICAgICAgICAgICAgICAgICA/IGlucHV0VmFsdWUgPCBtaW5PdXRwdXQudmFsdWVcbiAgICAgICAgICAgICAgICAgICAgICAgIDogdmFsdWVEYXRlIDwgbmV3IERhdGUobWluT3V0cHV0LnZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoZXhjZWVkTWF4IHx8IGV4Y2VlZE1pbikge1xuICAgICAgICAgICAgZ2V0TWluTWF4TWVzc2FnZSghIWV4Y2VlZE1heCwgbWF4T3V0cHV0Lm1lc3NhZ2UsIG1pbk91dHB1dC5tZXNzYWdlLCBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLm1heCwgSU5QVVRfVkFMSURBVElPTl9SVUxFUy5taW4pO1xuICAgICAgICAgICAgaWYgKCF2YWxpZGF0ZUFsbEZpZWxkQ3JpdGVyaWEpIHtcbiAgICAgICAgICAgICAgICBzZXRDdXN0b21WYWxpZGl0eShlcnJvcltuYW1lXS5tZXNzYWdlKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZXJyb3I7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgaWYgKCghaXNOdWxsT3JVbmRlZmluZWQobWF4TGVuZ3RoKSB8fCAhaXNOdWxsT3JVbmRlZmluZWQobWluTGVuZ3RoKSkgJiZcbiAgICAgICAgIWlzRW1wdHkgJiZcbiAgICAgICAgKGlzU3RyaW5nKGlucHV0VmFsdWUpIHx8IChpc0ZpZWxkQXJyYXkgJiYgQXJyYXkuaXNBcnJheShpbnB1dFZhbHVlKSkpKSB7XG4gICAgICAgIGNvbnN0IG1heExlbmd0aE91dHB1dCA9IGdldFZhbHVlQW5kTWVzc2FnZShtYXhMZW5ndGgpO1xuICAgICAgICBjb25zdCBtaW5MZW5ndGhPdXRwdXQgPSBnZXRWYWx1ZUFuZE1lc3NhZ2UobWluTGVuZ3RoKTtcbiAgICAgICAgY29uc3QgZXhjZWVkTWF4ID0gIWlzTnVsbE9yVW5kZWZpbmVkKG1heExlbmd0aE91dHB1dC52YWx1ZSkgJiZcbiAgICAgICAgICAgIGlucHV0VmFsdWUubGVuZ3RoID4gK21heExlbmd0aE91dHB1dC52YWx1ZTtcbiAgICAgICAgY29uc3QgZXhjZWVkTWluID0gIWlzTnVsbE9yVW5kZWZpbmVkKG1pbkxlbmd0aE91dHB1dC52YWx1ZSkgJiZcbiAgICAgICAgICAgIGlucHV0VmFsdWUubGVuZ3RoIDwgK21pbkxlbmd0aE91dHB1dC52YWx1ZTtcbiAgICAgICAgaWYgKGV4Y2VlZE1heCB8fCBleGNlZWRNaW4pIHtcbiAgICAgICAgICAgIGdldE1pbk1heE1lc3NhZ2UoZXhjZWVkTWF4LCBtYXhMZW5ndGhPdXRwdXQubWVzc2FnZSwgbWluTGVuZ3RoT3V0cHV0Lm1lc3NhZ2UpO1xuICAgICAgICAgICAgaWYgKCF2YWxpZGF0ZUFsbEZpZWxkQ3JpdGVyaWEpIHtcbiAgICAgICAgICAgICAgICBzZXRDdXN0b21WYWxpZGl0eShlcnJvcltuYW1lXS5tZXNzYWdlKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZXJyb3I7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgaWYgKHBhdHRlcm4gJiYgIWlzRW1wdHkgJiYgaXNTdHJpbmcoaW5wdXRWYWx1ZSkpIHtcbiAgICAgICAgY29uc3QgeyB2YWx1ZTogcGF0dGVyblZhbHVlLCBtZXNzYWdlIH0gPSBnZXRWYWx1ZUFuZE1lc3NhZ2UocGF0dGVybik7XG4gICAgICAgIGlmIChpc1JlZ2V4KHBhdHRlcm5WYWx1ZSkgJiYgIWlucHV0VmFsdWUubWF0Y2gocGF0dGVyblZhbHVlKSkge1xuICAgICAgICAgICAgZXJyb3JbbmFtZV0gPSB7XG4gICAgICAgICAgICAgICAgdHlwZTogSU5QVVRfVkFMSURBVElPTl9SVUxFUy5wYXR0ZXJuLFxuICAgICAgICAgICAgICAgIG1lc3NhZ2UsXG4gICAgICAgICAgICAgICAgcmVmLFxuICAgICAgICAgICAgICAgIC4uLmFwcGVuZEVycm9yc0N1cnJ5KElOUFVUX1ZBTElEQVRJT05fUlVMRVMucGF0dGVybiwgbWVzc2FnZSksXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgaWYgKCF2YWxpZGF0ZUFsbEZpZWxkQ3JpdGVyaWEpIHtcbiAgICAgICAgICAgICAgICBzZXRDdXN0b21WYWxpZGl0eShtZXNzYWdlKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZXJyb3I7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgaWYgKHZhbGlkYXRlKSB7XG4gICAgICAgIGlmIChpc0Z1bmN0aW9uKHZhbGlkYXRlKSkge1xuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdmFsaWRhdGUoaW5wdXRWYWx1ZSwgZm9ybVZhbHVlcyk7XG4gICAgICAgICAgICBjb25zdCB2YWxpZGF0ZUVycm9yID0gZ2V0VmFsaWRhdGVFcnJvcihyZXN1bHQsIGlucHV0UmVmKTtcbiAgICAgICAgICAgIGlmICh2YWxpZGF0ZUVycm9yKSB7XG4gICAgICAgICAgICAgICAgZXJyb3JbbmFtZV0gPSB7XG4gICAgICAgICAgICAgICAgICAgIC4uLnZhbGlkYXRlRXJyb3IsXG4gICAgICAgICAgICAgICAgICAgIC4uLmFwcGVuZEVycm9yc0N1cnJ5KElOUFVUX1ZBTElEQVRJT05fUlVMRVMudmFsaWRhdGUsIHZhbGlkYXRlRXJyb3IubWVzc2FnZSksXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICBpZiAoIXZhbGlkYXRlQWxsRmllbGRDcml0ZXJpYSkge1xuICAgICAgICAgICAgICAgICAgICBzZXRDdXN0b21WYWxpZGl0eSh2YWxpZGF0ZUVycm9yLm1lc3NhZ2UpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZXJyb3I7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGlzT2JqZWN0KHZhbGlkYXRlKSkge1xuICAgICAgICAgICAgbGV0IHZhbGlkYXRpb25SZXN1bHQgPSB7fTtcbiAgICAgICAgICAgIGZvciAoY29uc3Qga2V5IGluIHZhbGlkYXRlKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFpc0VtcHR5T2JqZWN0KHZhbGlkYXRpb25SZXN1bHQpICYmICF2YWxpZGF0ZUFsbEZpZWxkQ3JpdGVyaWEpIHtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IHZhbGlkYXRlRXJyb3IgPSBnZXRWYWxpZGF0ZUVycm9yKGF3YWl0IHZhbGlkYXRlW2tleV0oaW5wdXRWYWx1ZSwgZm9ybVZhbHVlcyksIGlucHV0UmVmLCBrZXkpO1xuICAgICAgICAgICAgICAgIGlmICh2YWxpZGF0ZUVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRpb25SZXN1bHQgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAuLi52YWxpZGF0ZUVycm9yLFxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uYXBwZW5kRXJyb3JzQ3Vycnkoa2V5LCB2YWxpZGF0ZUVycm9yLm1lc3NhZ2UpLFxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBpZiAoIXZhbGlkYXRlQWxsRmllbGRDcml0ZXJpYSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q3VzdG9tVmFsaWRpdHkodmFsaWRhdGVFcnJvci5tZXNzYWdlKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAodmFsaWRhdGVBbGxGaWVsZENyaXRlcmlhKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBlcnJvcltuYW1lXSA9IHZhbGlkYXRpb25SZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIWlzRW1wdHlPYmplY3QodmFsaWRhdGlvblJlc3VsdCkpIHtcbiAgICAgICAgICAgICAgICBlcnJvcltuYW1lXSA9IHtcbiAgICAgICAgICAgICAgICAgICAgcmVmOiBpbnB1dFJlZixcbiAgICAgICAgICAgICAgICAgICAgLi4udmFsaWRhdGlvblJlc3VsdCxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIGlmICghdmFsaWRhdGVBbGxGaWVsZENyaXRlcmlhKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBlcnJvcjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgZmllbGRFcnJvciA9IGVycm9yW25hbWVdO1xuICAgIHNldEN1c3RvbVZhbGlkaXR5KGZpZWxkRXJyb3IgPyBmaWVsZEVycm9yLm1lc3NhZ2UgOiB0cnVlKTtcbiAgICByZXR1cm4gZXJyb3I7XG59O1xuXG52YXIgY29udmVydFRvQXJyYXlQYXlsb2FkID0gKHZhbHVlKSA9PiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkgPyB2YWx1ZSA6IFt2YWx1ZV0pO1xuXG52YXIgYXBwZW5kQXQgPSAoZGF0YSwgdmFsdWUpID0+IFtcbiAgICAuLi5kYXRhLFxuICAgIC4uLmNvbnZlcnRUb0FycmF5UGF5bG9hZCh2YWx1ZSksXG5dO1xuXG52YXIgZmlsbEVtcHR5QXJyYXkgPSAodmFsdWUpID0+IEFycmF5LmlzQXJyYXkodmFsdWUpID8gdmFsdWUubWFwKCgpID0+IHVuZGVmaW5lZCkgOiB1bmRlZmluZWQ7XG5cbmZ1bmN0aW9uIGluc2VydChkYXRhLCBpbmRleCwgdmFsdWUpIHtcbiAgICByZXR1cm4gW1xuICAgICAgICAuLi5kYXRhLnNsaWNlKDAsIGluZGV4KSxcbiAgICAgICAgLi4uY29udmVydFRvQXJyYXlQYXlsb2FkKHZhbHVlKSxcbiAgICAgICAgLi4uZGF0YS5zbGljZShpbmRleCksXG4gICAgXTtcbn1cblxudmFyIG1vdmVBcnJheUF0ID0gKGRhdGEsIGZyb20sIHRvKSA9PiB7XG4gICAgaWYgKCFBcnJheS5pc0FycmF5KGRhdGEpKSB7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG4gICAgaWYgKGlzVW5kZWZpbmVkKGRhdGFbdG9dKSkge1xuICAgICAgICBkYXRhW3RvXSA9IHVuZGVmaW5lZDtcbiAgICB9XG4gICAgZGF0YS5zcGxpY2UodG8sIDAsIGRhdGEuc3BsaWNlKGZyb20sIDEpWzBdKTtcbiAgICByZXR1cm4gZGF0YTtcbn07XG5cbnZhciBwcmVwZW5kQXQgPSAoZGF0YSwgdmFsdWUpID0+IFtcbiAgICAuLi5jb252ZXJ0VG9BcnJheVBheWxvYWQodmFsdWUpLFxuICAgIC4uLmNvbnZlcnRUb0FycmF5UGF5bG9hZChkYXRhKSxcbl07XG5cbnZhciBjb21wYWN0ID0gKHZhbHVlKSA9PiBBcnJheS5pc0FycmF5KHZhbHVlKSA/IHZhbHVlLmZpbHRlcihCb29sZWFuKSA6IFtdO1xuXG5mdW5jdGlvbiByZW1vdmVBdEluZGV4ZXMoZGF0YSwgaW5kZXhlcykge1xuICAgIGxldCBpID0gMDtcbiAgICBjb25zdCB0ZW1wID0gWy4uLmRhdGFdO1xuICAgIGZvciAoY29uc3QgaW5kZXggb2YgaW5kZXhlcykge1xuICAgICAgICB0ZW1wLnNwbGljZShpbmRleCAtIGksIDEpO1xuICAgICAgICBpKys7XG4gICAgfVxuICAgIHJldHVybiBjb21wYWN0KHRlbXApLmxlbmd0aCA/IHRlbXAgOiBbXTtcbn1cbnZhciByZW1vdmVBcnJheUF0ID0gKGRhdGEsIGluZGV4KSA9PiBpc1VuZGVmaW5lZChpbmRleClcbiAgICA/IFtdXG4gICAgOiByZW1vdmVBdEluZGV4ZXMoZGF0YSwgWy4uLm5ldyBTZXQoY29udmVydFRvQXJyYXlQYXlsb2FkKGluZGV4KSldLnNvcnQoKGEsIGIpID0+IGEgLSBiKSk7XG5cbnZhciBzd2FwQXJyYXlBdCA9IChkYXRhLCBpbmRleEEsIGluZGV4QikgPT4ge1xuICAgIFtkYXRhW2luZGV4QV0sIGRhdGFbaW5kZXhCXV0gPSBbZGF0YVtpbmRleEJdLCBkYXRhW2luZGV4QV1dO1xufTtcblxuZnVuY3Rpb24gYmFzZUdldChvYmplY3QsIHVwZGF0ZVBhdGgpIHtcbiAgICBjb25zdCBsZW5ndGggPSB1cGRhdGVQYXRoLmxlbmd0aCAtIDE7XG4gICAgbGV0IGluZGV4ID0gMDtcbiAgICB3aGlsZSAoaW5kZXggPCBsZW5ndGgpIHtcbiAgICAgICAgaWYgKGlzTnVsbE9yVW5kZWZpbmVkKG9iamVjdCkpIHtcbiAgICAgICAgICAgIG9iamVjdCA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIG9iamVjdCA9IG9iamVjdFt1cGRhdGVQYXRoW2luZGV4XV07XG4gICAgICAgIGluZGV4Kys7XG4gICAgfVxuICAgIHJldHVybiBvYmplY3Q7XG59XG5mdW5jdGlvbiBpc0VtcHR5QXJyYXkob2JqKSB7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gb2JqKSB7XG4gICAgICAgIGlmIChvYmouaGFzT3duUHJvcGVydHkoa2V5KSAmJiAhaXNVbmRlZmluZWQob2JqW2tleV0pKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiB1bnNldChvYmplY3QsIHBhdGgpIHtcbiAgICBpZiAoIWlzT2JqZWN0KG9iamVjdCkgJiYgIUFycmF5LmlzQXJyYXkob2JqZWN0KSkge1xuICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgIH1cbiAgICBpZiAoaXNTdHJpbmcocGF0aCkgJiYgT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iamVjdCwgcGF0aCkpIHtcbiAgICAgICAgZGVsZXRlIG9iamVjdFtwYXRoXTtcbiAgICAgICAgcmV0dXJuIG9iamVjdDtcbiAgICB9XG4gICAgY29uc3QgcGF0aHMgPSBBcnJheS5pc0FycmF5KHBhdGgpXG4gICAgICAgID8gcGF0aFxuICAgICAgICA6IGlzS2V5KHBhdGgpXG4gICAgICAgICAgICA/IFtwYXRoXVxuICAgICAgICAgICAgOiBzdHJpbmdUb1BhdGgocGF0aCk7XG4gICAgaWYgKHBhdGhzLnNvbWUoKHNlZ21lbnQpID0+IFBST1RPVFlQRV9LRVlXT1JEUy5pbmNsdWRlcyhTdHJpbmcoc2VnbWVudCkpKSkge1xuICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgIH1cbiAgICBjb25zdCBjaGlsZE9iamVjdCA9IHBhdGhzLmxlbmd0aCA9PT0gMSA/IG9iamVjdCA6IGJhc2VHZXQob2JqZWN0LCBwYXRocyk7XG4gICAgY29uc3QgaW5kZXggPSBwYXRocy5sZW5ndGggLSAxO1xuICAgIGNvbnN0IGtleSA9IHBhdGhzW2luZGV4XTtcbiAgICBpZiAoY2hpbGRPYmplY3QgJiYgKGlzT2JqZWN0KGNoaWxkT2JqZWN0KSB8fCBBcnJheS5pc0FycmF5KGNoaWxkT2JqZWN0KSkpIHtcbiAgICAgICAgZGVsZXRlIGNoaWxkT2JqZWN0W2tleV07XG4gICAgfVxuICAgIGlmIChpbmRleCAhPT0gMCAmJlxuICAgICAgICAoKGlzT2JqZWN0KGNoaWxkT2JqZWN0KSAmJiBpc0VtcHR5T2JqZWN0KGNoaWxkT2JqZWN0KSkgfHxcbiAgICAgICAgICAgIChBcnJheS5pc0FycmF5KGNoaWxkT2JqZWN0KSAmJiBpc0VtcHR5QXJyYXkoY2hpbGRPYmplY3QpKSkpIHtcbiAgICAgICAgdW5zZXQob2JqZWN0LCBwYXRocy5zbGljZSgwLCAtMSkpO1xuICAgIH1cbiAgICByZXR1cm4gb2JqZWN0O1xufVxuXG52YXIgdXBkYXRlQXQgPSAoZmllbGRWYWx1ZXMsIGluZGV4LCB2YWx1ZSkgPT4ge1xuICAgIGZpZWxkVmFsdWVzW2luZGV4XSA9IHZhbHVlO1xuICAgIHJldHVybiBmaWVsZFZhbHVlcztcbn07XG5cbi8qKlxuICogSG9vayBmb3IgZHluYW1pYyBmaWVsZCBhcnJheXMuIFByb3ZpZGVzIGBmaWVsZHNgIGFuZCBtdXRhdGlvbiBtZXRob2RzOlxuICogYGFwcGVuZGAsIGBwcmVwZW5kYCwgYHJlbW92ZWAsIGBpbnNlcnRgLCBgc3dhcGAsIGBtb3ZlYCwgYHVwZGF0ZWAsIGByZXBsYWNlYC5cbiAqXG4gKiBAc2VlIFtBUEldKGh0dHBzOi8vcmVhY3QtaG9vay1mb3JtLmNvbS9kb2NzL3VzZWZpZWxkYXJyYXkpXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogY29uc3QgeyBmaWVsZHMsIGFwcGVuZCB9ID0gdXNlRmllbGRBcnJheSh7IGNvbnRyb2wsIG5hbWU6IFwiaXRlbXNcIiB9KTtcbiAqIHJldHVybiBmaWVsZHMubWFwKChmLCBpKSA9PiA8aW5wdXQga2V5PXtmLmlkfSB7Li4ucmVnaXN0ZXIoYGl0ZW1zLiR7aX0ubmFtZWApfSAvPik7XG4gKiBgYGBcbiAqL1xuZnVuY3Rpb24gdXNlRmllbGRBcnJheShwcm9wcykge1xuICAgIGNvbnN0IGZvcm1Db250cm9sID0gdXNlRm9ybUNvbnRyb2xDb250ZXh0KCk7XG4gICAgY29uc3QgeyBjb250cm9sID0gZm9ybUNvbnRyb2wsIG5hbWUsIGtleU5hbWUgPSAnaWQnLCBkaXNhYmxlZCwgc2hvdWxkVW5yZWdpc3RlciwgcnVsZXMsIH0gPSBwcm9wcztcbiAgICBjb25zdCBnZXRDdXJyZW50RmllbGRBcnJheSA9ICgpID0+IGNvbnRyb2wuX2dldEZpZWxkQXJyYXkobmFtZSk7XG4gICAgY29uc3QgW2ZpZWxkcywgc2V0RmllbGRzXSA9IFJlYWN0LnVzZVN0YXRlKGdldEN1cnJlbnRGaWVsZEFycmF5KTtcbiAgICBjb25zdCBpZHMgPSBSZWFjdC51c2VSZWYoY29udHJvbC5fZ2V0RmllbGRBcnJheShuYW1lKS5tYXAoZ2VuZXJhdGVJZCkpO1xuICAgIGNvbnN0IF9hY3Rpb25lZCA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gICAgY29uc3QgeyByZXN5bmNJZk5lZWRlZCwgc25hcHNob3QgfSA9IHVzZVJlc3luY09uUmVjb25uZWN0KGdldEN1cnJlbnRGaWVsZEFycmF5KTtcbiAgICBjb25zdCBfcHJldkNvbnRyb2wgPSBSZWFjdC51c2VSZWYoY29udHJvbCk7XG4gICAgY29uc3QgX3ByZXZOYW1lID0gUmVhY3QudXNlUmVmKG5hbWUpO1xuICAgIGNvbnN0IF9ydWxlcyA9IFJlYWN0LnVzZVJlZih7IGNvbnRyb2wsIG5hbWUsIHJ1bGVzIH0pO1xuICAgIGlmICghZGlzYWJsZWQpIHtcbiAgICAgICAgY29udHJvbC5fbmFtZXMuYXJyYXkuYWRkKG5hbWUpO1xuICAgIH1cbiAgICBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICAgICAgaWYgKCFkaXNhYmxlZCAmJiBmaWVsZHMpIHtcbiAgICAgICAgICAgIGlmIChydWxlcyB8fFxuICAgICAgICAgICAgICAgIChfcnVsZXMuY3VycmVudC5ydWxlcyAmJlxuICAgICAgICAgICAgICAgICAgICBfcnVsZXMuY3VycmVudC5jb250cm9sID09PSBjb250cm9sICYmXG4gICAgICAgICAgICAgICAgICAgIF9ydWxlcy5jdXJyZW50Lm5hbWUgPT09IG5hbWUpKSB7XG4gICAgICAgICAgICAgICAgY29udHJvbC5yZWdpc3RlcihuYW1lLCBydWxlcyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBfcnVsZXMuY3VycmVudCA9IHsgY29udHJvbCwgbmFtZSwgcnVsZXMgfTtcbiAgICAgICAgfVxuICAgIH0sIFtjb250cm9sLCBuYW1lLCBmaWVsZHMsIHJ1bGVzLCBkaXNhYmxlZF0pO1xuICAgIHVzZUlzb21vcnBoaWNMYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoX3ByZXZDb250cm9sLmN1cnJlbnQgPT09IGNvbnRyb2wgJiYgX3ByZXZOYW1lLmN1cnJlbnQgPT09IG5hbWUpIHtcbiAgICAgICAgICAgIHJlc3luY0lmTmVlZGVkKHRydWUsIGdldEN1cnJlbnRGaWVsZEFycmF5LCAoZmllbGRWYWx1ZXMpID0+IHtcbiAgICAgICAgICAgICAgICBzZXRGaWVsZHMoZmllbGRWYWx1ZXMpO1xuICAgICAgICAgICAgICAgIGlkcy5jdXJyZW50ID0gZmllbGRWYWx1ZXMubWFwKGdlbmVyYXRlSWQpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBfcHJldkNvbnRyb2wuY3VycmVudCA9IGNvbnRyb2w7XG4gICAgICAgICAgICBfcHJldk5hbWUuY3VycmVudCA9IG5hbWU7XG4gICAgICAgICAgICBjb25zdCBmaWVsZFZhbHVlcyA9IGdldEN1cnJlbnRGaWVsZEFycmF5KCk7XG4gICAgICAgICAgICBpZiAoIWRlZXBFcXVhbChmaWVsZHMsIGZpZWxkVmFsdWVzKSkge1xuICAgICAgICAgICAgICAgIHNldEZpZWxkcyhmaWVsZFZhbHVlcyk7XG4gICAgICAgICAgICAgICAgaWRzLmN1cnJlbnQgPSBmaWVsZFZhbHVlcy5tYXAoZ2VuZXJhdGVJZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzbmFwc2hvdCh0cnVlLCBnZXRDdXJyZW50RmllbGRBcnJheSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdW5zdWJzY3JpYmUgPSBjb250cm9sLl9zdWJqZWN0cy5hcnJheS5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgbmV4dDogKHsgdmFsdWVzLCBuYW1lOiBmaWVsZEFycmF5TmFtZSwgfSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChmaWVsZEFycmF5TmFtZSA9PT0gbmFtZSB8fCAhZmllbGRBcnJheU5hbWUpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZmllbGRWYWx1ZXMgPSBnZXQodmFsdWVzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoZmllbGRWYWx1ZXMpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRGaWVsZHMoZmllbGRWYWx1ZXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWRzLmN1cnJlbnQgPSBmaWVsZFZhbHVlcy5tYXAoZ2VuZXJhdGVJZCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoIWZpZWxkQXJyYXlOYW1lKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRGaWVsZHMoW10pO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWRzLmN1cnJlbnQgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pLnVuc3Vic2NyaWJlO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgdW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgIHNuYXBzaG90KHRydWUsIGdldEN1cnJlbnRGaWVsZEFycmF5KTtcbiAgICAgICAgfTtcbiAgICB9LCBbY29udHJvbCwgbmFtZSwgZGlzYWJsZWQsIHJlc3luY0lmTmVlZGVkLCBzbmFwc2hvdF0pO1xuICAgIGNvbnN0IHVwZGF0ZVZhbHVlcyA9IFJlYWN0LnVzZUNhbGxiYWNrKCh1cGRhdGVkRmllbGRBcnJheVZhbHVlcykgPT4ge1xuICAgICAgICBfYWN0aW9uZWQuY3VycmVudCA9IHRydWU7XG4gICAgICAgIGNvbnRyb2wuX3NldEZpZWxkQXJyYXkobmFtZSwgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgIH0sIFtjb250cm9sLCBuYW1lXSk7XG4gICAgY29uc3QgYXBwZW5kID0gKHZhbHVlLCBvcHRpb25zKSA9PiB7XG4gICAgICAgIGlmIChkaXNhYmxlZCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGFwcGVuZFZhbHVlID0gY29udmVydFRvQXJyYXlQYXlsb2FkKGNsb25lT2JqZWN0KHZhbHVlKSk7XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzID0gYXBwZW5kQXQoY29udHJvbC5fZ2V0RmllbGRBcnJheShuYW1lKSwgYXBwZW5kVmFsdWUpO1xuICAgICAgICBjb250cm9sLl9uYW1lcy5mb2N1cyA9IGdldEZvY3VzRmllbGROYW1lKG5hbWUsIHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLmxlbmd0aCAtIDEsIG9wdGlvbnMpO1xuICAgICAgICBpZHMuY3VycmVudCA9IGFwcGVuZEF0KGlkcy5jdXJyZW50LCBhcHBlbmRWYWx1ZS5tYXAoZ2VuZXJhdGVJZCkpO1xuICAgICAgICB1cGRhdGVWYWx1ZXModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBzZXRGaWVsZHModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBjb250cm9sLl9zZXRGaWVsZEFycmF5KG5hbWUsIHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLCBhcHBlbmRBdCwge1xuICAgICAgICAgICAgYXJnQTogZmlsbEVtcHR5QXJyYXkodmFsdWUpLFxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IHByZXBlbmQgPSAodmFsdWUsIG9wdGlvbnMpID0+IHtcbiAgICAgICAgaWYgKGRpc2FibGVkKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcHJlcGVuZFZhbHVlID0gY29udmVydFRvQXJyYXlQYXlsb2FkKGNsb25lT2JqZWN0KHZhbHVlKSk7XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzID0gcHJlcGVuZEF0KGNvbnRyb2wuX2dldEZpZWxkQXJyYXkobmFtZSksIHByZXBlbmRWYWx1ZSk7XG4gICAgICAgIGNvbnRyb2wuX25hbWVzLmZvY3VzID0gZ2V0Rm9jdXNGaWVsZE5hbWUobmFtZSwgMCwgb3B0aW9ucyk7XG4gICAgICAgIGlkcy5jdXJyZW50ID0gcHJlcGVuZEF0KGlkcy5jdXJyZW50LCBwcmVwZW5kVmFsdWUubWFwKGdlbmVyYXRlSWQpKTtcbiAgICAgICAgdXBkYXRlVmFsdWVzKHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzKTtcbiAgICAgICAgc2V0RmllbGRzKHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzKTtcbiAgICAgICAgY29udHJvbC5fc2V0RmllbGRBcnJheShuYW1lLCB1cGRhdGVkRmllbGRBcnJheVZhbHVlcywgcHJlcGVuZEF0LCB7XG4gICAgICAgICAgICBhcmdBOiBmaWxsRW1wdHlBcnJheSh2YWx1ZSksXG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgY29uc3QgcmVtb3ZlID0gKGluZGV4KSA9PiB7XG4gICAgICAgIGlmIChkaXNhYmxlZCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzID0gcmVtb3ZlQXJyYXlBdChjb250cm9sLl9nZXRGaWVsZEFycmF5KG5hbWUpLCBpbmRleCk7XG4gICAgICAgIGlkcy5jdXJyZW50ID0gcmVtb3ZlQXJyYXlBdChpZHMuY3VycmVudCwgaW5kZXgpO1xuICAgICAgICB1cGRhdGVWYWx1ZXModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBzZXRGaWVsZHModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICAhQXJyYXkuaXNBcnJheShnZXQoY29udHJvbC5fZmllbGRzLCBuYW1lKSkgJiZcbiAgICAgICAgICAgIHNldChjb250cm9sLl9maWVsZHMsIG5hbWUsIHVuZGVmaW5lZCk7XG4gICAgICAgIGNvbnRyb2wuX3NldEZpZWxkQXJyYXkobmFtZSwgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMsIHJlbW92ZUFycmF5QXQsIHtcbiAgICAgICAgICAgIGFyZ0E6IGluZGV4LFxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IGluc2VydCQxID0gKGluZGV4LCB2YWx1ZSwgb3B0aW9ucykgPT4ge1xuICAgICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBpbnNlcnRWYWx1ZSA9IGNvbnZlcnRUb0FycmF5UGF5bG9hZChjbG9uZU9iamVjdCh2YWx1ZSkpO1xuICAgICAgICBjb25zdCB1cGRhdGVkRmllbGRBcnJheVZhbHVlcyA9IGluc2VydChjb250cm9sLl9nZXRGaWVsZEFycmF5KG5hbWUpLCBpbmRleCwgaW5zZXJ0VmFsdWUpO1xuICAgICAgICBjb250cm9sLl9uYW1lcy5mb2N1cyA9IGdldEZvY3VzRmllbGROYW1lKG5hbWUsIGluZGV4LCBvcHRpb25zKTtcbiAgICAgICAgaWRzLmN1cnJlbnQgPSBpbnNlcnQoaWRzLmN1cnJlbnQsIGluZGV4LCBpbnNlcnRWYWx1ZS5tYXAoZ2VuZXJhdGVJZCkpO1xuICAgICAgICB1cGRhdGVWYWx1ZXModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBzZXRGaWVsZHModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBjb250cm9sLl9zZXRGaWVsZEFycmF5KG5hbWUsIHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLCBpbnNlcnQsIHtcbiAgICAgICAgICAgIGFyZ0E6IGluZGV4LFxuICAgICAgICAgICAgYXJnQjogZmlsbEVtcHR5QXJyYXkodmFsdWUpLFxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IHN3YXAgPSAoaW5kZXhBLCBpbmRleEIpID0+IHtcbiAgICAgICAgaWYgKGRpc2FibGVkKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMgPSBjb250cm9sLl9nZXRGaWVsZEFycmF5KG5hbWUpO1xuICAgICAgICBzd2FwQXJyYXlBdCh1cGRhdGVkRmllbGRBcnJheVZhbHVlcywgaW5kZXhBLCBpbmRleEIpO1xuICAgICAgICBzd2FwQXJyYXlBdChpZHMuY3VycmVudCwgaW5kZXhBLCBpbmRleEIpO1xuICAgICAgICB1cGRhdGVWYWx1ZXModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBzZXRGaWVsZHModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBjb250cm9sLl9zZXRGaWVsZEFycmF5KG5hbWUsIHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLCBzd2FwQXJyYXlBdCwge1xuICAgICAgICAgICAgYXJnQTogaW5kZXhBLFxuICAgICAgICAgICAgYXJnQjogaW5kZXhCLFxuICAgICAgICB9LCBmYWxzZSk7XG4gICAgfTtcbiAgICBjb25zdCBtb3ZlID0gKGZyb20sIHRvKSA9PiB7XG4gICAgICAgIGlmIChkaXNhYmxlZCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzID0gY29udHJvbC5fZ2V0RmllbGRBcnJheShuYW1lKTtcbiAgICAgICAgbW92ZUFycmF5QXQodXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMsIGZyb20sIHRvKTtcbiAgICAgICAgbW92ZUFycmF5QXQoaWRzLmN1cnJlbnQsIGZyb20sIHRvKTtcbiAgICAgICAgdXBkYXRlVmFsdWVzKHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzKTtcbiAgICAgICAgc2V0RmllbGRzKHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzKTtcbiAgICAgICAgY29udHJvbC5fc2V0RmllbGRBcnJheShuYW1lLCB1cGRhdGVkRmllbGRBcnJheVZhbHVlcywgbW92ZUFycmF5QXQsIHtcbiAgICAgICAgICAgIGFyZ0E6IGZyb20sXG4gICAgICAgICAgICBhcmdCOiB0byxcbiAgICAgICAgfSwgZmFsc2UpO1xuICAgIH07XG4gICAgY29uc3QgdXBkYXRlID0gKGluZGV4LCB2YWx1ZSkgPT4ge1xuICAgICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB1cGRhdGVWYWx1ZSA9IGNsb25lT2JqZWN0KHZhbHVlKTtcbiAgICAgICAgY29uc3QgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMgPSB1cGRhdGVBdChjb250cm9sLl9nZXRGaWVsZEFycmF5KG5hbWUpLCBpbmRleCwgdXBkYXRlVmFsdWUpO1xuICAgICAgICBpZHMuY3VycmVudCA9IFsuLi51cGRhdGVkRmllbGRBcnJheVZhbHVlc10ubWFwKChpdGVtLCBpKSA9PiAhaXRlbSB8fCBpID09PSBpbmRleCA/IGdlbmVyYXRlSWQoKSA6IGlkcy5jdXJyZW50W2ldKTtcbiAgICAgICAgdXBkYXRlVmFsdWVzKHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzKTtcbiAgICAgICAgc2V0RmllbGRzKFsuLi51cGRhdGVkRmllbGRBcnJheVZhbHVlc10pO1xuICAgICAgICBjb250cm9sLl9zZXRGaWVsZEFycmF5KG5hbWUsIHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLCB1cGRhdGVBdCwge1xuICAgICAgICAgICAgYXJnQTogaW5kZXgsXG4gICAgICAgICAgICBhcmdCOiBmaWxsRW1wdHlBcnJheSh2YWx1ZSksXG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgY29uc3QgcmVwbGFjZSA9ICh2YWx1ZSkgPT4ge1xuICAgICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB1cGRhdGVkRmllbGRBcnJheVZhbHVlcyA9IGNvbnZlcnRUb0FycmF5UGF5bG9hZChjbG9uZU9iamVjdCh2YWx1ZSkpO1xuICAgICAgICBpZHMuY3VycmVudCA9IHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLm1hcChnZW5lcmF0ZUlkKTtcbiAgICAgICAgdXBkYXRlVmFsdWVzKFsuLi51cGRhdGVkRmllbGRBcnJheVZhbHVlc10pO1xuICAgICAgICBzZXRGaWVsZHMoWy4uLnVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzXSk7XG4gICAgICAgIGNvbnRyb2wuX3NldEZpZWxkQXJyYXkobmFtZSwgWy4uLnVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzXSwgKGRhdGEpID0+IEFycmF5LmlzQXJyYXkoZGF0YSlcbiAgICAgICAgICAgID8gZGF0YS5zbGljZSgwLCB1cGRhdGVkRmllbGRBcnJheVZhbHVlcy5sZW5ndGgpXG4gICAgICAgICAgICA6IGRhdGEsIHt9KTtcbiAgICB9O1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChkaXNhYmxlZCkge1xuICAgICAgICAgICAgY29udHJvbC5fc3RhdGUuYWN0aW9uQXJyYXlMZW5ndGhzLmRlbGV0ZShuYW1lKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb250cm9sLl9zdGF0ZS5hY3Rpb24gPSBmYWxzZTtcbiAgICAgICAgY29udHJvbC5fc3RhdGUuYWN0aW9uQXJyYXlMZW5ndGhzLmRlbGV0ZShuYW1lKTtcbiAgICAgICAgaXNXYXRjaGVkKG5hbWUsIGNvbnRyb2wuX25hbWVzKSAmJlxuICAgICAgICAgICAgY29udHJvbC5fc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgLi4uY29udHJvbC5fZm9ybVN0YXRlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IHZhbGlkYXRpb25Nb2RlcyA9IGdldFZhbGlkYXRpb25Nb2Rlcyhjb250cm9sLl9vcHRpb25zLm1vZGUpO1xuICAgICAgICBjb25zdCByZVZhbGlkYXRlTW9kZXMgPSBnZXRWYWxpZGF0aW9uTW9kZXMoY29udHJvbC5fb3B0aW9ucy5yZVZhbGlkYXRlTW9kZSk7XG4gICAgICAgIGlmIChfYWN0aW9uZWQuY3VycmVudCAmJlxuICAgICAgICAgICAgKCF2YWxpZGF0aW9uTW9kZXMuaXNPblN1Ym1pdCB8fCBjb250cm9sLl9mb3JtU3RhdGUuaXNTdWJtaXR0ZWQpICYmXG4gICAgICAgICAgICAhKGNvbnRyb2wuX2Zvcm1TdGF0ZS5pc1N1Ym1pdHRlZCAmJiByZVZhbGlkYXRlTW9kZXMuaXNPblN1Ym1pdCkgJiZcbiAgICAgICAgICAgICghdmFsaWRhdGlvbk1vZGVzLmlzT25CbHVyIHx8XG4gICAgICAgICAgICAgICAgKGNvbnRyb2wuX2Zvcm1TdGF0ZS5pc1N1Ym1pdHRlZCAmJiByZVZhbGlkYXRlTW9kZXMuaXNPbkNoYW5nZSkpKSB7XG4gICAgICAgICAgICBjb25zdCBmaWVsZEFycmF5VmFsdWVzID0gZ2V0KGNvbnRyb2wuX2Zvcm1WYWx1ZXMsIG5hbWUpO1xuICAgICAgICAgICAgaWYgKGNvbnRyb2wuX29wdGlvbnMucmVzb2x2ZXIpIHtcbiAgICAgICAgICAgICAgICBjb250cm9sLl9ydW5TY2hlbWEoW25hbWVdKS50aGVuKChyZXN1bHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29udHJvbC5fdXBkYXRlSXNWYWxpZGF0aW5nKFtuYW1lXSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChmaWVsZEFycmF5VmFsdWVzICE9PSBnZXQoY29udHJvbC5fZm9ybVZhbHVlcywgbmFtZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjb25zdCBlcnJvciA9IGdldChyZXN1bHQuZXJyb3JzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFkZWVwRXF1YWwoZ2V0KGNvbnRyb2wuX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpLCBlcnJvciwgdHJ1ZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzT2JqZWN0KGVycm9yKSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAhT2JqZWN0LmtleXMoZXJyb3IpLnNvbWUoKGtleSkgPT4gIU51bWJlci5pc05hTigra2V5KSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB1cGRhdGVGaWVsZEFycmF5Um9vdEVycm9yKGNvbnRyb2wuX2Zvcm1TdGF0ZS5lcnJvcnMsIHsgW25hbWVdOiBlcnJvciB9LCBuYW1lKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHNldChjb250cm9sLl9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lLCBlcnJvcik7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1bnNldChjb250cm9sLl9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2wuX2Zvcm1TdGF0ZS5lcnJvcnMgPSB7IC4uLmNvbnRyb2wuX2Zvcm1TdGF0ZS5lcnJvcnMgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2wuX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yczogY29udHJvbC5fZm9ybVN0YXRlLmVycm9ycyxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBjb25zdCBmaWVsZCA9IGdldChjb250cm9sLl9maWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgICAgIGlmIChmaWVsZCAmJiBmaWVsZC5fZikge1xuICAgICAgICAgICAgICAgICAgICB2YWxpZGF0ZUZpZWxkKGZpZWxkLCBjb250cm9sLl9uYW1lcy5kaXNhYmxlZCwgY29udHJvbC5fZm9ybVZhbHVlcywgY29udHJvbC5fb3B0aW9ucy5jcml0ZXJpYU1vZGUgPT09IFZBTElEQVRJT05fTU9ERS5hbGwsIGNvbnRyb2wuX29wdGlvbnMuc2hvdWxkVXNlTmF0aXZlVmFsaWRhdGlvbiwgdHJ1ZSkudGhlbigoZXJyb3IpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaWVsZEFycmF5VmFsdWVzICE9PSBnZXQoY29udHJvbC5fZm9ybVZhbHVlcywgbmFtZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWlzRW1wdHlPYmplY3QoZXJyb3IpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRmllbGRBcnJheVJvb3RFcnJvcihjb250cm9sLl9mb3JtU3RhdGUuZXJyb3JzLCBlcnJvciwgbmFtZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbC5fZm9ybVN0YXRlLmVycm9ycyA9IHsgLi4uY29udHJvbC5fZm9ybVN0YXRlLmVycm9ycyB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2wuX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlcnJvcnM6IGNvbnRyb2wuX2Zvcm1TdGF0ZS5lcnJvcnMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBleGlzdGluZ0Vycm9yID0gZ2V0KGNvbnRyb2wuX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChleGlzdGluZ0Vycm9yICYmIGV4aXN0aW5nRXJyb3JbUk9PVF9FUlJPUl9UWVBFXSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1bnNldChjb250cm9sLl9mb3JtU3RhdGUuZXJyb3JzLCBgJHtuYW1lfS4ke1JPT1RfRVJST1JfVFlQRX1gKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbC5fZm9ybVN0YXRlLmVycm9ycyA9IHsgLi4uY29udHJvbC5fZm9ybVN0YXRlLmVycm9ycyB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sLl9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yczogY29udHJvbC5fZm9ybVN0YXRlLmVycm9ycyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgLy8gRXh0ZXJuYWwgdXBkYXRlcyB0aGF0IGNoYW5nZSBgZmllbGRzYCAoZS5nLiByZXNldCgpIG9yIHNldFZhbHVlKCkgb25cbiAgICAgICAgLy8gdGhlIGFycmF5KSBhbHJlYWR5IG5vdGlmeSBzdWJzY3JpYmVycyB3aXRoIHRoZSB1cC10by1kYXRlIHZhbHVlc1xuICAgICAgICAvLyB0aGVtc2VsdmVzLCBzbyBvbmx5IHJlLWJyb2FkY2FzdCBoZXJlIGZvciBnZW51aW5lIGFycmF5IG1ldGhvZCBjYWxscy5cbiAgICAgICAgX2FjdGlvbmVkLmN1cnJlbnQgJiZcbiAgICAgICAgICAgIGNvbnRyb2wuX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICAgICAgdmFsdWVzOiBjbG9uZU9iamVjdChjb250cm9sLl9mb3JtVmFsdWVzKSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICBjb250cm9sLl9uYW1lcy5mb2N1cyAmJlxuICAgICAgICAgICAgaXRlcmF0ZUZpZWxkc0J5QWN0aW9uKGNvbnRyb2wuX2ZpZWxkcywgKHJlZiwga2V5KSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKGNvbnRyb2wuX25hbWVzLmZvY3VzICYmXG4gICAgICAgICAgICAgICAgICAgIGtleS5zdGFydHNXaXRoKGNvbnRyb2wuX25hbWVzLmZvY3VzKSAmJlxuICAgICAgICAgICAgICAgICAgICByZWYuZm9jdXMpIHtcbiAgICAgICAgICAgICAgICAgICAgcmVmLmZvY3VzKCk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAxO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgY29udHJvbC5fbmFtZXMuZm9jdXMgPSAnJztcbiAgICAgICAgY29udHJvbC5fc2V0VmFsaWQoKTtcbiAgICAgICAgX2FjdGlvbmVkLmN1cnJlbnQgPSBmYWxzZTtcbiAgICB9LCBbZmllbGRzLCBuYW1lLCBjb250cm9sLCBkaXNhYmxlZF0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmICghZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIGlzVW5kZWZpbmVkKGdldChjb250cm9sLl9mb3JtVmFsdWVzLCBuYW1lKSkgJiZcbiAgICAgICAgICAgICAgICBjb250cm9sLl9zZXRGaWVsZEFycmF5KG5hbWUpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICBjb250cm9sLl9zdGF0ZS5hY3Rpb25BcnJheUxlbmd0aHMuZGVsZXRlKG5hbWUpO1xuICAgICAgICAgICAgY29udHJvbC5fc3RhdGUuYWN0aW9uQXJyYXlMZW5ndGhzLnNpemUgfHwgKGNvbnRyb2wuX3N0YXRlLmFjdGlvbiA9IGZhbHNlKTtcbiAgICAgICAgICAgIGlmIChkaXNhYmxlZCkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IHNob3VsZEtlZXBGaWVsZEFycmF5VmFsdWVzID0gIShjb250cm9sLl9vcHRpb25zLnNob3VsZFVucmVnaXN0ZXIgfHwgc2hvdWxkVW5yZWdpc3Rlcik7XG4gICAgICAgICAgICBjb25zdCB1cGRhdGVNb3VudGVkID0gKG5hbWUsIHZhbHVlKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoY29udHJvbC5fZmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICBpZiAoZmllbGQgJiYgZmllbGQuX2YpIHtcbiAgICAgICAgICAgICAgICAgICAgZmllbGQuX2YubW91bnQgPSB2YWx1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgaWYgKF9hY3Rpb25lZC5jdXJyZW50ICYmIHNob3VsZEtlZXBGaWVsZEFycmF5VmFsdWVzKSB7XG4gICAgICAgICAgICAgICAgY29udHJvbC5fc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlczogY2xvbmVPYmplY3QoY29udHJvbC5fZm9ybVZhbHVlcyksXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIXNob3VsZEtlZXBGaWVsZEFycmF5VmFsdWVzICYmXG4gICAgICAgICAgICAgICAgY29udHJvbC5fc3RhdGUuYWN0aW9uICYmXG4gICAgICAgICAgICAgICAgWy4uLmNvbnRyb2wuX3N0YXRlLmFjdGlvbkFycmF5TGVuZ3Rocy5rZXlzKCldLnNvbWUoKGFycmF5TmFtZSkgPT4gbmFtZS5zdGFydHNXaXRoKGFycmF5TmFtZSArICcuJykpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2hvdWxkS2VlcEZpZWxkQXJyYXlWYWx1ZXNcbiAgICAgICAgICAgICAgICA/IHVwZGF0ZU1vdW50ZWQobmFtZSwgZmFsc2UpXG4gICAgICAgICAgICAgICAgOiBjb250cm9sLnVucmVnaXN0ZXIobmFtZSk7XG4gICAgICAgIH07XG4gICAgfSwgW25hbWUsIGNvbnRyb2wsIGtleU5hbWUsIHNob3VsZFVucmVnaXN0ZXIsIGRpc2FibGVkXSk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgc3dhcDogUmVhY3QudXNlQ2FsbGJhY2soc3dhcCwgW3VwZGF0ZVZhbHVlcywgbmFtZSwgY29udHJvbCwgZGlzYWJsZWRdKSxcbiAgICAgICAgbW92ZTogUmVhY3QudXNlQ2FsbGJhY2sobW92ZSwgW3VwZGF0ZVZhbHVlcywgbmFtZSwgY29udHJvbCwgZGlzYWJsZWRdKSxcbiAgICAgICAgcHJlcGVuZDogUmVhY3QudXNlQ2FsbGJhY2socHJlcGVuZCwgW1xuICAgICAgICAgICAgdXBkYXRlVmFsdWVzLFxuICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgIGNvbnRyb2wsXG4gICAgICAgICAgICBkaXNhYmxlZCxcbiAgICAgICAgXSksXG4gICAgICAgIGFwcGVuZDogUmVhY3QudXNlQ2FsbGJhY2soYXBwZW5kLCBbdXBkYXRlVmFsdWVzLCBuYW1lLCBjb250cm9sLCBkaXNhYmxlZF0pLFxuICAgICAgICByZW1vdmU6IFJlYWN0LnVzZUNhbGxiYWNrKHJlbW92ZSwgW3VwZGF0ZVZhbHVlcywgbmFtZSwgY29udHJvbCwgZGlzYWJsZWRdKSxcbiAgICAgICAgaW5zZXJ0OiBSZWFjdC51c2VDYWxsYmFjayhpbnNlcnQkMSwgW3VwZGF0ZVZhbHVlcywgbmFtZSwgY29udHJvbCwgZGlzYWJsZWRdKSxcbiAgICAgICAgdXBkYXRlOiBSZWFjdC51c2VDYWxsYmFjayh1cGRhdGUsIFt1cGRhdGVWYWx1ZXMsIG5hbWUsIGNvbnRyb2wsIGRpc2FibGVkXSksXG4gICAgICAgIHJlcGxhY2U6IFJlYWN0LnVzZUNhbGxiYWNrKHJlcGxhY2UsIFtcbiAgICAgICAgICAgIHVwZGF0ZVZhbHVlcyxcbiAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICBjb250cm9sLFxuICAgICAgICAgICAgZGlzYWJsZWQsXG4gICAgICAgIF0pLFxuICAgICAgICBmaWVsZHM6IFJlYWN0LnVzZU1lbW8oKCkgPT4gZmllbGRzLm1hcCgoZmllbGQsIGluZGV4KSA9PiAoe1xuICAgICAgICAgICAgLi4uZmllbGQsXG4gICAgICAgICAgICAuLi4oaXNCb29sZWFuKGRpc2FibGVkKSA/IHsgZGlzYWJsZWQgfSA6IHt9KSxcbiAgICAgICAgICAgIFtrZXlOYW1lXTogaWRzLmN1cnJlbnRbaW5kZXhdIHx8IGdlbmVyYXRlSWQoKSxcbiAgICAgICAgfSkpLCBbZmllbGRzLCBrZXlOYW1lLCBkaXNhYmxlZF0pLFxuICAgIH07XG59XG5cbi8qKlxuICogQ29tcG9uZW50IGJhc2VkIG9uIGB1c2VGaWVsZEFycmF5YCBob29rIHRvIHdvcmsgd2l0aCBjb250cm9sbGVkIGNvbXBvbmVudC5cbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiBmdW5jdGlvbiBBcHAoKSB7XG4gKiAgIGNvbnN0IHsgY29udHJvbCwgcmVnaXN0ZXIgfSA9IHVzZUZvcm08Rm9ybVZhbHVlcz4oe1xuICogICAgIGRlZmF1bHRWYWx1ZXM6IHtcbiAqICAgICAgIHRlc3Q6IFtcbiAqICAgICAgICAge1xuICogICAgICAgICAgIHZhbHVlOiAnJyxcbiAqICAgICAgICAgfSxcbiAqICAgICAgIF0sXG4gKiAgICAgfSxcbiAqICAgfSk7XG4gKlxuICogICByZXR1cm4gKFxuICogICAgIDxmb3JtPlxuICogICAgICAgPEZpZWxkQXJyYXlcbiAqICAgICAgICAgY29udHJvbD17Y29udHJvbH1cbiAqICAgICAgICAgbmFtZT1cInRlc3RcIlxuICogICAgICAgICByZW5kZXI9eyh7IGZpZWxkcyB9KSA9PlxuICogICAgICAgICAgIGZpZWxkcy5tYXAoKGZpZWxkLCBpbmRleCkgPT4gKFxuICogICAgICAgICAgICAgPGlucHV0IGtleT17ZmllbGQuaWR9IHsuLi5yZWdpc3RlcihgdGVzdC4ke2luZGV4fS52YWx1ZWApfSAvPlxuICogICAgICAgICAgICkpXG4gKiAgICAgICAgIH1cbiAqICAgICAgIC8+XG4gKiAgICAgPC9mb3JtPlxuICogICApO1xuICogfVxuICogYGBgXG4gKi9cbmNvbnN0IEZpZWxkQXJyYXkgPSAocHJvcHMpID0+IHByb3BzLnJlbmRlcih1c2VGaWVsZEFycmF5KHByb3BzKSk7XG5cbmNvbnN0IGlzRmlsZUxpa2UgPSAodmFsdWUpID0+ICh0eXBlb2YgQmxvYiAhPT0gJ3VuZGVmaW5lZCcgJiYgdmFsdWUgaW5zdGFuY2VvZiBCbG9iKSB8fFxuICAgICh0eXBlb2YgRmlsZSAhPT0gJ3VuZGVmaW5lZCcgJiYgdmFsdWUgaW5zdGFuY2VvZiBGaWxlKTtcbmNvbnN0IGlzRmlsZUxpc3RMaWtlID0gKHZhbHVlKSA9PiB0eXBlb2YgRmlsZUxpc3QgIT09ICd1bmRlZmluZWQnICYmIHZhbHVlIGluc3RhbmNlb2YgRmlsZUxpc3Q7XG5jb25zdCBmbGF0dGVuID0gKG9iaikgPT4ge1xuICAgIGNvbnN0IG91dHB1dCA9IHt9O1xuICAgIGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKG9iaikpIHtcbiAgICAgICAgaWYgKGlzT2JqZWN0VHlwZShvYmpba2V5XSkgJiZcbiAgICAgICAgICAgIG9ialtrZXldICE9PSBudWxsICYmXG4gICAgICAgICAgICAhaXNEYXRlT2JqZWN0KG9ialtrZXldKSAmJlxuICAgICAgICAgICAgIWlzRmlsZUxpa2Uob2JqW2tleV0pICYmXG4gICAgICAgICAgICAhaXNGaWxlTGlzdExpa2Uob2JqW2tleV0pKSB7XG4gICAgICAgICAgICBjb25zdCBuZXN0ZWQgPSBmbGF0dGVuKG9ialtrZXldKTtcbiAgICAgICAgICAgIGZvciAoY29uc3QgbmVzdGVkS2V5IG9mIE9iamVjdC5rZXlzKG5lc3RlZCkpIHtcbiAgICAgICAgICAgICAgICBvdXRwdXRbYCR7a2V5fS4ke25lc3RlZEtleX1gXSA9IG5lc3RlZFtuZXN0ZWRLZXldO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgb3V0cHV0W2tleV0gPSBvYmpba2V5XTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gb3V0cHV0O1xufTtcblxuZnVuY3Rpb24ganNvblRvRm9ybURhdGEoanNvbikge1xuICAgIGNvbnN0IHJlc3VsdCA9IG5ldyBGb3JtRGF0YSgpO1xuICAgIGNvbnN0IGZsYXR0ZW5Gb3JtVmFsdWVzID0gZmxhdHRlbihqc29uKTtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBmbGF0dGVuRm9ybVZhbHVlcykge1xuICAgICAgICBjb25zdCB2YWx1ZSA9IGZsYXR0ZW5Gb3JtVmFsdWVzW2tleV07XG4gICAgICAgIGlmIChpc1VuZGVmaW5lZCh2YWx1ZSkpIHtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0eXBlb2YgRmlsZUxpc3QgIT09ICd1bmRlZmluZWQnICYmIHZhbHVlIGluc3RhbmNlb2YgRmlsZUxpc3QpIHtcbiAgICAgICAgICAgIGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCB2YWx1ZS5sZW5ndGg7IGluZGV4KyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBmaWxlID0gdmFsdWVbaW5kZXhdO1xuICAgICAgICAgICAgICAgIGZpbGUgJiYgcmVzdWx0LmFwcGVuZChrZXksIGZpbGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgcmVzdWx0LmFwcGVuZChrZXksIHZhbHVlKTtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbn1cblxuZnVuY3Rpb24gc2FmZUpTT05TdHJpbmdpZnkodmFsdWUpIHtcbiAgICB0cnkge1xuICAgICAgICByZXR1cm4gSlNPTi5zdHJpbmdpZnkodmFsdWUpO1xuICAgIH1cbiAgICBjYXRjaCAoX2EpIHtcbiAgICAgICAgcmV0dXJuICcnO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gbm9vcCgpIHsgfVxuXG5jb25zdCBQT1NUX1JFUVVFU1QgPSAncG9zdCc7XG5mdW5jdGlvbiBkZWZhdWx0VmFsaWRhdGVTdGF0dXMoc3RhdHVzKSB7XG4gICAgcmV0dXJuIHN0YXR1cyA+PSAyMDAgJiYgc3RhdHVzIDwgMzAwO1xufVxuLyoqXG4gKiBGb3JtIGNvbXBvbmVudCB0aGF0IGhhbmRsZXMgc3VibWlzc2lvbiwgaW5jbHVkaW5nIG9wdGlvbmFsIGBhY3Rpb25gIGZldGNoIGFuZCBzZXJ2ZXIgZXJyb3Igd2lyaW5nLlxuICpcbiAqIEBzZWUgW0FQSV0oaHR0cHM6Ly9yZWFjdC1ob29rLWZvcm0uY29tL2RvY3MvdXNlZm9ybS9mb3JtKVxuICpcbiAqIEBleGFtcGxlXG4gKiBgYGB0c3hcbiAqIDxGb3JtIGFjdGlvbj1cIi9hcGlcIiBjb250cm9sPXtjb250cm9sfT5cbiAqICAgPGlucHV0IHsuLi5yZWdpc3RlcihcIm5hbWVcIil9IC8+XG4gKiAgIDxwPntlcnJvcnM/LnJvb3Q/LnNlcnZlciAmJiAnU2VydmVyIGVycm9yJ308L3A+XG4gKiAgIDxidXR0b24+U3VibWl0PC9idXR0b24+XG4gKiA8L0Zvcm0+XG4gKiBgYGBcbiAqL1xuZnVuY3Rpb24gRm9ybShwcm9wcykge1xuICAgIGNvbnN0IGZvcm1Db250cm9sID0gdXNlRm9ybUNvbnRyb2xDb250ZXh0KCk7XG4gICAgY29uc3QgW21vdW50ZWQsIHNldE1vdW50ZWRdID0gUmVhY3QudXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IHsgY29udHJvbCA9IGZvcm1Db250cm9sLCBvblN1Ym1pdCA9IG5vb3AsIGNoaWxkcmVuLCBhY3Rpb24sIG1ldGhvZCA9IFBPU1RfUkVRVUVTVCwgaGVhZGVycywgZW5jVHlwZSwgb25FcnJvciA9IG5vb3AsIHJlbmRlciwgb25TdWNjZXNzID0gbm9vcCwgdmFsaWRhdGVTdGF0dXMgPSBkZWZhdWx0VmFsaWRhdGVTdGF0dXMsIC4uLnJlc3QgfSA9IHByb3BzO1xuICAgIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgICAgICByZXR1cm4gY29udHJvbC5oYW5kbGVTdWJtaXQoYXN5bmMgKGRhdGEsIGV2ZW50KSA9PiB7XG4gICAgICAgICAgICBjb25zdCBmb3JtRGF0YSA9IGpzb25Ub0Zvcm1EYXRhKGRhdGEpO1xuICAgICAgICAgICAgY29uc3QgZm9ybURhdGFKc29uID0gc2FmZUpTT05TdHJpbmdpZnkoZGF0YSk7XG4gICAgICAgICAgICBpZiAob25TdWJtaXQpIHtcbiAgICAgICAgICAgICAgICBhd2FpdCBvblN1Ym1pdCh7XG4gICAgICAgICAgICAgICAgICAgIGRhdGEsXG4gICAgICAgICAgICAgICAgICAgIGV2ZW50LFxuICAgICAgICAgICAgICAgICAgICBtZXRob2QsXG4gICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLFxuICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YUpzb24sXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaXNTdHJpbmcoYWN0aW9uKSkge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzTXVsdGlwYXJ0ID0gKHZhbHVlKSA9PiAvXlxccyptdWx0aXBhcnRcXC9mb3JtLWRhdGFcXHMqKDt8JCkvaS50ZXN0KHZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY29udGVudFR5cGUgPSBlbmNUeXBlICYmICFpc011bHRpcGFydChlbmNUeXBlKSA/IGVuY1R5cGUgOiB1bmRlZmluZWQ7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGhhc0NvbnRlbnRUeXBlID0gKHR5cGUpID0+IGNvbnRlbnRUeXBlXG4gICAgICAgICAgICAgICAgICAgICAgICA/IHR5cGUudGVzdChjb250ZW50VHlwZSlcbiAgICAgICAgICAgICAgICAgICAgICAgIDogKGhlYWRlcnMgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBPYmplY3QuZW50cmllcyhoZWFkZXJzKS5zb21lKChbbmFtZSwgdmFsdWVdKSA9PiBuYW1lLnRvTG93ZXJDYXNlKCkgPT09ICdjb250ZW50LXR5cGUnICYmIHR5cGUudGVzdCh2YWx1ZSkpKSB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIChlbmNUeXBlICYmIHR5cGUudGVzdChlbmNUeXBlKSk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBib2R5ID0gZm9ybURhdGE7XG4gICAgICAgICAgICAgICAgICAgIGlmIChoYXNDb250ZW50VHlwZSgvanNvbi9pKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgYm9keSA9IGZvcm1EYXRhSnNvbjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChoYXNDb250ZW50VHlwZSgvXlxccyphcHBsaWNhdGlvblxcL3gtd3d3LWZvcm0tdXJsZW5jb2RlZFxccyooO3wkKS9pKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgYm9keSA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoQXJyYXkuZnJvbShmb3JtRGF0YSwgKFtuYW1lLCB2YWx1ZV0pID0+IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzU3RyaW5nKHZhbHVlKSA/IHZhbHVlIDogdmFsdWUubmFtZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF0pKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChoYXNDb250ZW50VHlwZSgvXlxccyp0ZXh0XFwvcGxhaW5cXHMqKDt8JCkvaSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvZHkgPSBBcnJheS5mcm9tKGZvcm1EYXRhLCAoW25hbWUsIHZhbHVlXSkgPT4gYCR7bmFtZX09JHtpc1N0cmluZyh2YWx1ZSkgPyB2YWx1ZSA6IHZhbHVlLm5hbWV9XFxyXFxuYCkuam9pbignJyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChhY3Rpb24sIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG1ldGhvZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5PYmplY3QuZnJvbUVudHJpZXMoT2JqZWN0LmVudHJpZXMoaGVhZGVycyB8fCB7fSkuZmlsdGVyKChbbmFtZSwgdmFsdWVdKSA9PiBuYW1lLnRvTG93ZXJDYXNlKCkgIT09ICdjb250ZW50LXR5cGUnIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICghY29udGVudFR5cGUgJiYgIWlzTXVsdGlwYXJ0KHZhbHVlKSkpKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi4oY29udGVudFR5cGUgJiYgeyAnQ29udGVudC1UeXBlJzogY29udGVudFR5cGUgfSksXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgYm9keSxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZSAmJiAhdmFsaWRhdGVTdGF0dXMocmVzcG9uc2Uuc3RhdHVzKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgb25FcnJvcih7IHJlc3BvbnNlIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHsgdHlwZTogU3RyaW5nKHJlc3BvbnNlLnN0YXR1cykgfTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uU3VjY2Vzcyh7IHJlc3BvbnNlIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICBvbkVycm9yKHsgZXJyb3IgfSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7IHR5cGU6ICcnIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGlzRnVuY3Rpb24oYWN0aW9uKSkge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IGFjdGlvbihmb3JtRGF0YSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICBvbkVycm9yKHsgZXJyb3IgfSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7IHR5cGU6ICcnIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gUmV0dXJuIG5vdGhpbmcgd2hlbiBzdWNjZXNzZnVsLlxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9KTtcbiAgICB9LCBbXG4gICAgICAgIGNvbnRyb2wsXG4gICAgICAgIG9uU3VibWl0LFxuICAgICAgICBtZXRob2QsXG4gICAgICAgIGFjdGlvbixcbiAgICAgICAgaGVhZGVycyxcbiAgICAgICAgZW5jVHlwZSxcbiAgICAgICAgdmFsaWRhdGVTdGF0dXMsXG4gICAgICAgIG9uRXJyb3IsXG4gICAgICAgIG9uU3VjY2VzcyxcbiAgICBdKTtcbiAgICBjb25zdCBzdWJtaXQgPSBSZWFjdC51c2VDYWxsYmFjayhhc3luYyAoZXZlbnQpID0+IHtcbiAgICAgICAgY29uc3QgZXJyID0gYXdhaXQgaGFuZGxlU3VibWl0KGV2ZW50KTtcbiAgICAgICAgaWYgKGVyciAmJiBjb250cm9sKSB7XG4gICAgICAgICAgICBjb250cm9sLl9zdWJqZWN0cy5zdGF0ZS5uZXh0KHsgaXNTdWJtaXRTdWNjZXNzZnVsOiBmYWxzZSB9KTtcbiAgICAgICAgICAgIGNvbnRyb2wuc2V0RXJyb3IoJ3Jvb3Quc2VydmVyJywgZXJyKTtcbiAgICAgICAgfVxuICAgIH0sIFtoYW5kbGVTdWJtaXQsIGNvbnRyb2xdKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBzZXRNb3VudGVkKHRydWUpO1xuICAgIH0sIFtdKTtcbiAgICBpZiAocmVuZGVyKSB7XG4gICAgICAgIHJldHVybiByZW5kZXIoeyBzdWJtaXQgfSk7XG4gICAgfVxuICAgIC8vIFJlYWN0IGZvcmJpZHMgcGFzc2luZyBgbWV0aG9kYC9gZW5jVHlwZWAgYWxvbmdzaWRlIGEgZnVuY3Rpb24gYGFjdGlvbmBcbiAgICAvLyAoYSBTZXJ2ZXItQWN0aW9uLXN0eWxlIHN1Ym1pc3Npb24pIC0tIGl0IG1hbmFnZXMgdGhvc2UgaXRzZWxmIGFuZCB3YXJuc1xuICAgIC8vIGlmIHRoZXkncmUgcHJlc2VudCwgc28gdGhleSdyZSBvbmx5IHJlbmRlcmVkIGZvciBzdHJpbmcvVVJMIGFjdGlvbnMuXG4gICAgcmV0dXJuIChSZWFjdC5jcmVhdGVFbGVtZW50KFwiZm9ybVwiLCB7IG5vVmFsaWRhdGU6IG1vdW50ZWQsIGFjdGlvbjogYWN0aW9uLCAuLi4oIWlzRnVuY3Rpb24oYWN0aW9uKSAmJiB7IG1ldGhvZCwgZW5jVHlwZSB9KSwgb25TdWJtaXQ6IHN1Ym1pdCwgLi4ucmVzdCB9LCBjaGlsZHJlbikpO1xufVxuXG5jb25zdCBGb3JtU3RhdGUgPSAoeyBjb250cm9sLCBkaXNhYmxlZCwgZXhhY3QsIG5hbWUsIHJlbmRlciwgfSkgPT4gcmVuZGVyKHVzZUZvcm1TdGF0ZSh7IGNvbnRyb2wsIG5hbWUsIGRpc2FibGVkLCBleGFjdCB9KSk7XG4vKiogQGRlcHJlY2F0ZWQgVXNlIGBGb3JtU3RhdGVgIGluc3RlYWQuIEtlcHQgYXMgYW4gYWxpYXMgZm9yIGJhY2t3YXJkIGNvbXBhdGliaWxpdHkuICovXG5jb25zdCBGb3JtU3RhdGVTdWJzY3JpYmUgPSBGb3JtU3RhdGU7XG5cbnZhciBjcmVhdGVTdWJqZWN0ID0gKCkgPT4ge1xuICAgIGxldCBfb2JzZXJ2ZXJzID0gbmV3IFNldCgpO1xuICAgIGxldCBfaXRlcmF0aW9uQ291bnQgPSAwO1xuICAgIGNvbnN0IG5leHQgPSAodmFsdWUpID0+IHtcbiAgICAgICAgY29uc3Qgb2JzZXJ2ZXJzID0gX29ic2VydmVycztcbiAgICAgICAgX2l0ZXJhdGlvbkNvdW50Kys7XG4gICAgICAgIGZvciAoY29uc3Qgb2JzZXJ2ZXIgb2Ygb2JzZXJ2ZXJzKSB7XG4gICAgICAgICAgICBvYnNlcnZlci5uZXh0ICYmIG9ic2VydmVyLm5leHQodmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIG9ic2VydmVycyA9PT0gX29ic2VydmVycyAmJiBfaXRlcmF0aW9uQ291bnQtLTtcbiAgICB9O1xuICAgIGNvbnN0IHN1YnNjcmliZSA9IChvYnNlcnZlcikgPT4ge1xuICAgICAgICBfb2JzZXJ2ZXJzLmFkZChvYnNlcnZlcik7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICB1bnN1YnNjcmliZTogKCkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChfaXRlcmF0aW9uQ291bnQpIHtcbiAgICAgICAgICAgICAgICAgICAgX29ic2VydmVycyA9IG5ldyBTZXQoX29ic2VydmVycyk7XG4gICAgICAgICAgICAgICAgICAgIF9pdGVyYXRpb25Db3VudCA9IDA7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIF9vYnNlcnZlcnMuZGVsZXRlKG9ic2VydmVyKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH07XG4gICAgfTtcbiAgICBjb25zdCB1bnN1YnNjcmliZSA9ICgpID0+IHtcbiAgICAgICAgX29ic2VydmVycyA9IG5ldyBTZXQoKTtcbiAgICAgICAgX2l0ZXJhdGlvbkNvdW50ID0gMDtcbiAgICB9O1xuICAgIHJldHVybiB7XG4gICAgICAgIGdldCBvYnNlcnZlcnMoKSB7XG4gICAgICAgICAgICByZXR1cm4gQXJyYXkuZnJvbShfb2JzZXJ2ZXJzKTtcbiAgICAgICAgfSxcbiAgICAgICAgbmV4dCxcbiAgICAgICAgc3Vic2NyaWJlLFxuICAgICAgICB1bnN1YnNjcmliZSxcbiAgICB9O1xufTtcblxuZnVuY3Rpb24gZXh0cmFjdEZvcm1WYWx1ZXMoZmllbGRzU3RhdGUsIGZvcm1WYWx1ZXMpIHtcbiAgICBjb25zdCB2YWx1ZXMgPSAoQXJyYXkuaXNBcnJheShmaWVsZHNTdGF0ZSkgPyBbXSA6IHt9KTtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBmaWVsZHNTdGF0ZSkge1xuICAgICAgICBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKGZpZWxkc1N0YXRlLCBrZXkpKSB7XG4gICAgICAgICAgICBjb25zdCBmaWVsZFN0YXRlID0gZmllbGRzU3RhdGVba2V5XTtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkVmFsdWUgPSBmb3JtVmFsdWVzW2tleV07XG4gICAgICAgICAgICBpZiAoZmllbGRTdGF0ZSAmJlxuICAgICAgICAgICAgICAgIChpc09iamVjdChmaWVsZFN0YXRlKSB8fCBBcnJheS5pc0FycmF5KGZpZWxkU3RhdGUpKSAmJlxuICAgICAgICAgICAgICAgIGZpZWxkVmFsdWUpIHtcbiAgICAgICAgICAgICAgICB2YWx1ZXNba2V5XSA9IGV4dHJhY3RGb3JtVmFsdWVzKGZpZWxkU3RhdGUsIGZpZWxkVmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoZmllbGRzU3RhdGVba2V5XSkge1xuICAgICAgICAgICAgICAgIHZhbHVlc1trZXldID0gZmllbGRWYWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdmFsdWVzO1xufVxuXG5jb25zdCBoYXNPd24gPSAodmFsdWUsIGtleSkgPT4gdmFsdWUgIT09IG51bGwgJiZcbiAgICBpc09iamVjdFR5cGUodmFsdWUpICYmXG4gICAgT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHZhbHVlLCBrZXkpO1xudmFyIGhhcyA9IChvYmplY3QsIHBhdGgpID0+IHtcbiAgICBpZiAoIXBhdGgpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBsZXQgcmVzdWx0ID0gb2JqZWN0O1xuICAgIGZvciAoY29uc3Qga2V5IG9mIGlzS2V5KHBhdGgpID8gW3BhdGhdIDogc3RyaW5nVG9QYXRoKHBhdGgpKSB7XG4gICAgICAgIGlmICghaGFzT3duKHJlc3VsdCwga2V5KSkge1xuICAgICAgICAgICAgLy8gYGdldGAgYWxzbyByZXNvbHZlcyBhIHBhdGggaGVsZCBhcyBhIHNpbmdsZSBsaXRlcmFsIGtleSwgZWcgYHsgJ2EuYic6IDEgfWBcbiAgICAgICAgICAgIHJldHVybiBoYXNPd24ob2JqZWN0LCBwYXRoKTtcbiAgICAgICAgfVxuICAgICAgICByZXN1bHQgPSByZXN1bHRba2V5XTtcbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG59O1xuXG52YXIgaXNNdWx0aXBsZVNlbGVjdCA9IChlbGVtZW50KSA9PiBlbGVtZW50LnR5cGUgPT09IGBzZWxlY3QtbXVsdGlwbGVgO1xuXG5jb25zdCBpc1NlbGVjdEVkaXRlZCA9IChzZWxlY3QpID0+IHtcbiAgICBjb25zdCBvcHRpb25zID0gWy4uLnNlbGVjdC5vcHRpb25zXTtcbiAgICByZXR1cm4gIXNlbGVjdC5tdWx0aXBsZSAmJlxuICAgICAgICBzZWxlY3Quc2l6ZSA8IDIgJiZcbiAgICAgICAgIW9wdGlvbnMuc29tZSgob3B0aW9uKSA9PiBvcHRpb24uZGVmYXVsdFNlbGVjdGVkKVxuICAgICAgICA/IHNlbGVjdC5zZWxlY3RlZEluZGV4ICE9PVxuICAgICAgICAgICAgb3B0aW9ucy5maW5kSW5kZXgoKG9wdGlvbikgPT4ge1xuICAgICAgICAgICAgICAgIHZhciBfYTtcbiAgICAgICAgICAgICAgICByZXR1cm4gIW9wdGlvbi5kaXNhYmxlZCAmJlxuICAgICAgICAgICAgICAgICAgICAhKChfYSA9IG9wdGlvbi5wYXJlbnRFbGVtZW50KSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2EubWF0Y2hlcygnb3B0Z3JvdXBbZGlzYWJsZWRdJykpO1xuICAgICAgICAgICAgfSlcbiAgICAgICAgOiBvcHRpb25zLnNvbWUoKG9wdGlvbikgPT4gb3B0aW9uLnNlbGVjdGVkICE9PSBvcHRpb24uZGVmYXVsdFNlbGVjdGVkKTtcbn07XG52YXIgaXNFZGl0ZWQgPSAocmVmKSA9PiBpc0NoZWNrQm94SW5wdXQocmVmKVxuICAgID8gcmVmLmNoZWNrZWQgIT09IHJlZi5kZWZhdWx0Q2hlY2tlZFxuICAgIDogcmVmLnR5cGUgPT09ICdzZWxlY3Qtb25lJyB8fCBpc011bHRpcGxlU2VsZWN0KHJlZilcbiAgICAgICAgPyBpc1NlbGVjdEVkaXRlZChyZWYpXG4gICAgICAgIDogIWlzUmFkaW9JbnB1dChyZWYpICYmXG4gICAgICAgICAgICByZWYudHlwZSAhPT0gJ3JhbmdlJyAmJlxuICAgICAgICAgICAgcmVmLnR5cGUgIT09ICdjb2xvcicgJiZcbiAgICAgICAgICAgICdkZWZhdWx0VmFsdWUnIGluIHJlZiAmJlxuICAgICAgICAgICAgcmVmLnZhbHVlICE9PSByZWYuZGVmYXVsdFZhbHVlO1xuXG52YXIgaXNSYWRpb09yQ2hlY2tib3ggPSAocmVmKSA9PiBpc1JhZGlvSW5wdXQocmVmKSB8fCBpc0NoZWNrQm94SW5wdXQocmVmKTtcblxudmFyIGxpdmUgPSAocmVmKSA9PiBpc0hUTUxFbGVtZW50KHJlZikgJiYgcmVmLmlzQ29ubmVjdGVkO1xuXG5mdW5jdGlvbiBpc0RpcnR5Q29udGFpbmVyKHZhbHVlKSB7XG4gICAgcmV0dXJuIEFycmF5LmlzQXJyYXkodmFsdWUpIHx8IGlzT2JqZWN0KHZhbHVlKTtcbn1cbmZ1bmN0aW9uIGNvbGxlY3REaXJ0eUZpZWxkTmFtZXMoZGlydHlUcmVlLCBjYWNoZWREaXJ0eUZpZWxkcywgcHJlZml4ID0gJycsIG5hbWVzID0gW10pIHtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBkaXJ0eVRyZWUpIHtcbiAgICAgICAgY29uc3QgcGF0aCA9IHByZWZpeCA/IGAke3ByZWZpeH0uJHtrZXl9YCA6IGtleTtcbiAgICAgICAgY29uc3QgdmFsdWUgPSBkaXJ0eVRyZWVba2V5XTtcbiAgICAgICAgaWYgKGlzRGlydHlDb250YWluZXIodmFsdWUpICYmXG4gICAgICAgICAgICBpc0RpcnR5Q29udGFpbmVyKGdldChjYWNoZWREaXJ0eUZpZWxkcywgcGF0aCkpKSB7XG4gICAgICAgICAgICBjb2xsZWN0RGlydHlGaWVsZE5hbWVzKHZhbHVlLCBjYWNoZWREaXJ0eUZpZWxkcywgcGF0aCwgbmFtZXMpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHZhbHVlKSB7XG4gICAgICAgICAgICBuYW1lcy5wdXNoKHBhdGgpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBuYW1lcztcbn1cblxudmFyIG9iamVjdEhhc0Z1bmN0aW9uID0gKGRhdGEpID0+IHtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBkYXRhKSB7XG4gICAgICAgIGlmIChpc0Z1bmN0aW9uKGRhdGFba2V5XSkpIHtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbn07XG5cbmZ1bmN0aW9uIGlzVHJhdmVyc2FibGUodmFsdWUpIHtcbiAgICByZXR1cm4gQXJyYXkuaXNBcnJheSh2YWx1ZSkgfHwgKGlzT2JqZWN0KHZhbHVlKSAmJiAhb2JqZWN0SGFzRnVuY3Rpb24odmFsdWUpKTtcbn1cbmZ1bmN0aW9uIGlzUmVnaXN0ZXJlZExlYWYoZmllbGRSZWYpIHtcbiAgICByZXR1cm4gISEoZmllbGRSZWYgJiYgJ19mJyBpbiBmaWVsZFJlZik7XG59XG5mdW5jdGlvbiBpc0VtcHR5RGlydHlDb250YWluZXIodmFsdWUpIHtcbiAgICByZXR1cm4gQXJyYXkuaXNBcnJheSh2YWx1ZSlcbiAgICAgICAgPyAhdmFsdWUuc29tZSgoaXRlbSkgPT4gIWlzVW5kZWZpbmVkKGl0ZW0pKVxuICAgICAgICA6ICFPYmplY3Qua2V5cyh2YWx1ZSkubGVuZ3RoO1xufVxuZnVuY3Rpb24gY2xlYXJEaXJ0eUZpZWxkKGNvbnRhaW5lciwga2V5KSB7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkoY29udGFpbmVyKSkge1xuICAgICAgICBjb250YWluZXJba2V5XSA9IHVuZGVmaW5lZDtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGRlbGV0ZSBjb250YWluZXJba2V5XTtcbiAgICB9XG59XG5mdW5jdGlvbiBtYXJrRmllbGRzRGlydHkoZGF0YSwgZmllbGRzID0ge30sIGZpZWxkUmVmcykge1xuICAgIGZvciAoY29uc3Qga2V5IGluIGRhdGEpIHtcbiAgICAgICAgY29uc3QgdmFsdWUgPSBkYXRhW2tleV07XG4gICAgICAgIGNvbnN0IGZpZWxkUmVmID0gZmllbGRSZWZzICYmIGZpZWxkUmVmc1trZXldO1xuICAgICAgICBpZiAoaXNUcmF2ZXJzYWJsZSh2YWx1ZSkgJiZcbiAgICAgICAgICAgICghQXJyYXkuaXNBcnJheSh2YWx1ZSkgfHwgIWlzUmVnaXN0ZXJlZExlYWYoZmllbGRSZWYpKSkge1xuICAgICAgICAgICAgZmllbGRzW2tleV0gPSBBcnJheS5pc0FycmF5KHZhbHVlKSA/IFtdIDoge307XG4gICAgICAgICAgICBtYXJrRmllbGRzRGlydHkodmFsdWUsIGZpZWxkc1trZXldLCBmaWVsZFJlZik7XG4gICAgICAgICAgICBpZiAoaXNFbXB0eURpcnR5Q29udGFpbmVyKGZpZWxkc1trZXldKSkge1xuICAgICAgICAgICAgICAgIGNsZWFyRGlydHlGaWVsZChmaWVsZHMsIGtleSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoIWlzVW5kZWZpbmVkKHZhbHVlKSkge1xuICAgICAgICAgICAgZmllbGRzW2tleV0gPSB0cnVlO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBmaWVsZHM7XG59XG5mdW5jdGlvbiBnZXREaXJ0eUZpZWxkcyhkYXRhLCBmb3JtVmFsdWVzLCBkaXJ0eUZpZWxkc0Zyb21WYWx1ZXMsIGZpZWxkUmVmcykge1xuICAgIGlmICghZGlydHlGaWVsZHNGcm9tVmFsdWVzKSB7XG4gICAgICAgIGRpcnR5RmllbGRzRnJvbVZhbHVlcyA9IG1hcmtGaWVsZHNEaXJ0eShmb3JtVmFsdWVzLCAoQXJyYXkuaXNBcnJheShpc051bGxPclVuZGVmaW5lZChmb3JtVmFsdWVzKSA/IGRhdGEgOiBmb3JtVmFsdWVzKVxuICAgICAgICAgICAgPyBbXVxuICAgICAgICAgICAgOiB7fSksIGZpZWxkUmVmcyk7XG4gICAgfVxuICAgIGZvciAoY29uc3Qga2V5IGluIGRhdGEpIHtcbiAgICAgICAgY29uc3QgdmFsdWUgPSBkYXRhW2tleV07XG4gICAgICAgIGNvbnN0IGZpZWxkUmVmID0gZmllbGRSZWZzICYmIGZpZWxkUmVmc1trZXldO1xuICAgICAgICBpZiAoaXNUcmF2ZXJzYWJsZSh2YWx1ZSkgJiZcbiAgICAgICAgICAgICghQXJyYXkuaXNBcnJheSh2YWx1ZSkgfHwgIWlzUmVnaXN0ZXJlZExlYWYoZmllbGRSZWYpKSkge1xuICAgICAgICAgICAgaWYgKGlzVW5kZWZpbmVkKGZvcm1WYWx1ZXMpIHx8IGlzUHJpbWl0aXZlKGRpcnR5RmllbGRzRnJvbVZhbHVlc1trZXldKSkge1xuICAgICAgICAgICAgICAgIGRpcnR5RmllbGRzRnJvbVZhbHVlc1trZXldID0gbWFya0ZpZWxkc0RpcnR5KHZhbHVlLCAoQXJyYXkuaXNBcnJheSh2YWx1ZSkgPyBbXSA6IHt9KSwgZmllbGRSZWYpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgZ2V0RGlydHlGaWVsZHModmFsdWUsIGlzTnVsbE9yVW5kZWZpbmVkKGZvcm1WYWx1ZXMpID8ge30gOiBmb3JtVmFsdWVzW2tleV0sIGRpcnR5RmllbGRzRnJvbVZhbHVlc1trZXldLCBmaWVsZFJlZik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaXNFbXB0eURpcnR5Q29udGFpbmVyKGRpcnR5RmllbGRzRnJvbVZhbHVlc1trZXldKSkge1xuICAgICAgICAgICAgICAgIGNsZWFyRGlydHlGaWVsZChkaXJ0eUZpZWxkc0Zyb21WYWx1ZXMsIGtleSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoZGVlcEVxdWFsKHZhbHVlLCBpc051bGxPclVuZGVmaW5lZChmb3JtVmFsdWVzKSA/IHVuZGVmaW5lZCA6IGZvcm1WYWx1ZXNba2V5XSkpIHtcbiAgICAgICAgICAgIGNsZWFyRGlydHlGaWVsZChkaXJ0eUZpZWxkc0Zyb21WYWx1ZXMsIGtleSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBkaXJ0eUZpZWxkc0Zyb21WYWx1ZXNba2V5XSA9IHRydWU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGRpcnR5RmllbGRzRnJvbVZhbHVlcztcbn1cblxudmFyIGdldEZpZWxkQXJyYXlJdGVtTmFtZXMgPSAobmFtZXMsIG5hbWUpID0+IHtcbiAgICBjb25zdCBzZWdtZW50cyA9IG5hbWUuc3BsaXQoJy4nKTtcbiAgICBjb25zdCBtYXRjaGVzID0gW107XG4gICAgbGV0IHByZWZpeCA9IHNlZ21lbnRzWzBdO1xuICAgIGZvciAobGV0IGkgPSAxOyBpIDwgc2VnbWVudHMubGVuZ3RoOyBwcmVmaXggKz0gJy4nICsgc2VnbWVudHNbaSsrXSkge1xuICAgICAgICBpZiAoIWlzTmFOKCtzZWdtZW50c1tpXSkgJiYgbmFtZXMuaGFzKHByZWZpeCkpIHtcbiAgICAgICAgICAgIG1hdGNoZXMucHVzaChgJHtwcmVmaXh9LiR7c2VnbWVudHNbaV19YCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG1hdGNoZXM7XG59O1xuXG52YXIgZ2V0RmllbGRWYWx1ZUFzID0gKHZhbHVlLCB7IHZhbHVlQXNOdW1iZXIsIHZhbHVlQXNEYXRlLCBzZXRWYWx1ZUFzIH0pID0+IGlzVW5kZWZpbmVkKHZhbHVlKVxuICAgID8gdmFsdWVcbiAgICA6IHZhbHVlQXNOdW1iZXJcbiAgICAgICAgPyB2YWx1ZSA9PT0gJydcbiAgICAgICAgICAgID8gTmFOXG4gICAgICAgICAgICA6IHZhbHVlXG4gICAgICAgICAgICAgICAgPyArdmFsdWVcbiAgICAgICAgICAgICAgICA6IHZhbHVlXG4gICAgICAgIDogdmFsdWVBc0RhdGUgJiYgaXNTdHJpbmcodmFsdWUpXG4gICAgICAgICAgICA/IG5ldyBEYXRlKHZhbHVlKVxuICAgICAgICAgICAgOiBzZXRWYWx1ZUFzXG4gICAgICAgICAgICAgICAgPyBzZXRWYWx1ZUFzKHZhbHVlKVxuICAgICAgICAgICAgICAgIDogdmFsdWU7XG5cbmZ1bmN0aW9uIGdldEZpZWxkVmFsdWUoX2YpIHtcbiAgICBjb25zdCByZWYgPSBfZi5yZWY7XG4gICAgaWYgKGlzRmlsZUlucHV0KHJlZikpIHtcbiAgICAgICAgcmV0dXJuIHJlZi5maWxlcztcbiAgICB9XG4gICAgaWYgKGlzUmFkaW9JbnB1dChyZWYpKSB7XG4gICAgICAgIHJldHVybiBnZXRSYWRpb1ZhbHVlKF9mLnJlZnMpLnZhbHVlO1xuICAgIH1cbiAgICBpZiAoaXNNdWx0aXBsZVNlbGVjdChyZWYpKSB7XG4gICAgICAgIHJldHVybiBbLi4ucmVmLnNlbGVjdGVkT3B0aW9uc11cbiAgICAgICAgICAgIC5maWx0ZXIoKG9wdGlvbikgPT4geyB2YXIgX2E7IHJldHVybiAhb3B0aW9uLmRpc2FibGVkICYmICEoKF9hID0gb3B0aW9uLmNsb3Nlc3QpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5jYWxsKG9wdGlvbiwgJ29wdGdyb3VwW2Rpc2FibGVkXScpKTsgfSlcbiAgICAgICAgICAgIC5tYXAoKHsgdmFsdWUgfSkgPT4gdmFsdWUpO1xuICAgIH1cbiAgICBpZiAoaXNDaGVja0JveElucHV0KHJlZikpIHtcbiAgICAgICAgcmV0dXJuIGdldENoZWNrYm94VmFsdWUoX2YucmVmcykudmFsdWU7XG4gICAgfVxuICAgIHJldHVybiBnZXRGaWVsZFZhbHVlQXMocmVmLnZhbHVlLCBfZik7XG59XG5cbnZhciBnZXRSZXNvbHZlck9wdGlvbnMgPSAoZmllbGRzTmFtZXMsIF9maWVsZHMsIGNyaXRlcmlhTW9kZSwgc2hvdWxkVXNlTmF0aXZlVmFsaWRhdGlvbikgPT4ge1xuICAgIGNvbnN0IGZpZWxkcyA9IHt9O1xuICAgIGZvciAoY29uc3QgbmFtZSBvZiBmaWVsZHNOYW1lcykge1xuICAgICAgICBjb25zdCBmaWVsZCA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgZmllbGQgJiYgc2V0KGZpZWxkcywgbmFtZSwgY2xvbmVPYmplY3QoZmllbGQuX2YpKTtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgICAgY3JpdGVyaWFNb2RlLFxuICAgICAgICBuYW1lczogWy4uLmZpZWxkc05hbWVzXSxcbiAgICAgICAgZmllbGRzLFxuICAgICAgICBzaG91bGRVc2VOYXRpdmVWYWxpZGF0aW9uLFxuICAgIH07XG59O1xuXG52YXIgZ2V0UnVsZVZhbHVlID0gKHJ1bGUpID0+IGlzVW5kZWZpbmVkKHJ1bGUpXG4gICAgPyBydWxlXG4gICAgOiBpc1JlZ2V4KHJ1bGUpXG4gICAgICAgID8gcnVsZS5zb3VyY2VcbiAgICAgICAgOiBpc09iamVjdChydWxlKVxuICAgICAgICAgICAgPyBpc1JlZ2V4KHJ1bGUudmFsdWUpXG4gICAgICAgICAgICAgICAgPyBydWxlLnZhbHVlLnNvdXJjZVxuICAgICAgICAgICAgICAgIDogcnVsZS52YWx1ZVxuICAgICAgICAgICAgOiBydWxlO1xuXG5jb25zdCBBU1lOQ19GVU5DVElPTiA9ICdBc3luY0Z1bmN0aW9uJztcbnZhciBoYXNQcm9taXNlVmFsaWRhdGlvbiA9IChmaWVsZFJlZmVyZW5jZSkgPT4ge1xuICAgIGlmICghZmllbGRSZWZlcmVuY2UgfHwgIWZpZWxkUmVmZXJlbmNlLnZhbGlkYXRlKVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgaWYgKGlzRnVuY3Rpb24oZmllbGRSZWZlcmVuY2UudmFsaWRhdGUpKSB7XG4gICAgICAgIHJldHVybiBmaWVsZFJlZmVyZW5jZS52YWxpZGF0ZS5jb25zdHJ1Y3Rvci5uYW1lID09PSBBU1lOQ19GVU5DVElPTjtcbiAgICB9XG4gICAgaWYgKGlzT2JqZWN0KGZpZWxkUmVmZXJlbmNlLnZhbGlkYXRlKSkge1xuICAgICAgICBmb3IgKGNvbnN0IGtleSBpbiBmaWVsZFJlZmVyZW5jZS52YWxpZGF0ZSkge1xuICAgICAgICAgICAgaWYgKGZpZWxkUmVmZXJlbmNlLnZhbGlkYXRlW2tleV0uY29uc3RydWN0b3IubmFtZSA9PT0gQVNZTkNfRlVOQ1RJT04pIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG59O1xuXG52YXIgaGFzVmFsaWRhdGlvbiA9IChvcHRpb25zKSA9PiBvcHRpb25zLm1vdW50ICYmXG4gICAgKG9wdGlvbnMucmVxdWlyZWQgfHxcbiAgICAgICAgKCFpc1VuZGVmaW5lZChvcHRpb25zLnJlcXVpcmVkKSAmJiBvcHRpb25zLnJlcXVpcmVkICE9PSBmYWxzZSkgfHxcbiAgICAgICAgIWlzVW5kZWZpbmVkKG9wdGlvbnMubWluKSB8fFxuICAgICAgICAhaXNVbmRlZmluZWQob3B0aW9ucy5tYXgpIHx8XG4gICAgICAgICFpc1VuZGVmaW5lZChvcHRpb25zLm1heExlbmd0aCkgfHxcbiAgICAgICAgIWlzVW5kZWZpbmVkKG9wdGlvbnMubWluTGVuZ3RoKSB8fFxuICAgICAgICBvcHRpb25zLnBhdHRlcm4gfHxcbiAgICAgICAgb3B0aW9ucy52YWxpZGF0ZSk7XG5cbmZ1bmN0aW9uIHNjaGVtYUVycm9yTG9va3VwKGVycm9ycywgX2ZpZWxkcywgbmFtZSkge1xuICAgIGNvbnN0IGVycm9yID0gZ2V0KGVycm9ycywgbmFtZSk7XG4gICAgaWYgKChlcnJvciAmJiAoZXJyb3IudHlwZSB8fCBlcnJvci5tZXNzYWdlKSkgfHwgQXJyYXkuaXNBcnJheShlcnJvcikpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGVycm9yLFxuICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgY29uc3QgbmFtZXMgPSBuYW1lLnNwbGl0KCcuJyk7XG4gICAgd2hpbGUgKG5hbWVzLmxlbmd0aCkge1xuICAgICAgICBjb25zdCBmaWVsZE5hbWUgPSBuYW1lcy5qb2luKCcuJyk7XG4gICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KF9maWVsZHMsIGZpZWxkTmFtZSk7XG4gICAgICAgIGNvbnN0IGZvdW5kRXJyb3IgPSBnZXQoZXJyb3JzLCBmaWVsZE5hbWUpO1xuICAgICAgICBpZiAoZmllbGQgJiYgIUFycmF5LmlzQXJyYXkoZmllbGQpICYmIG5hbWUgIT09IGZpZWxkTmFtZSkge1xuICAgICAgICAgICAgcmV0dXJuIHsgbmFtZSB9O1xuICAgICAgICB9XG4gICAgICAgIGlmIChmb3VuZEVycm9yICYmIGZvdW5kRXJyb3IudHlwZSkge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICBuYW1lOiBmaWVsZE5hbWUsXG4gICAgICAgICAgICAgICAgZXJyb3I6IGZvdW5kRXJyb3IsXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIGlmIChmb3VuZEVycm9yICYmIGZvdW5kRXJyb3Iucm9vdCAmJiBmb3VuZEVycm9yLnJvb3QudHlwZSkge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICBuYW1lOiBgJHtmaWVsZE5hbWV9LnJvb3RgLFxuICAgICAgICAgICAgICAgIGVycm9yOiBmb3VuZEVycm9yLnJvb3QsXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIG5hbWVzLnBvcCgpO1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICBuYW1lLFxuICAgIH07XG59XG5cbnZhciBzaG91bGRSZW5kZXJGb3JtU3RhdGUgPSAoZm9ybVN0YXRlRGF0YSwgX3Byb3h5Rm9ybVN0YXRlLCBpc1Jvb3QpID0+IHtcbiAgICBjb25zdCBrZXlzID0gT2JqZWN0LmtleXMoZm9ybVN0YXRlRGF0YSkuZmlsdGVyKChrZXkpID0+IGtleSAhPT0gJ25hbWUnKTtcbiAgICByZXR1cm4gKCFrZXlzLmxlbmd0aCB8fFxuICAgICAgICAoaXNSb290ICYmIGtleXMubGVuZ3RoID49IE9iamVjdC5rZXlzKF9wcm94eUZvcm1TdGF0ZSkubGVuZ3RoKSB8fFxuICAgICAgICBrZXlzLmZpbmQoKGtleSkgPT4gX3Byb3h5Rm9ybVN0YXRlW2tleV0gPT09XG4gICAgICAgICAgICAoIWlzUm9vdCB8fCBWQUxJREFUSU9OX01PREUuYWxsKSkpO1xufTtcblxuY29uc3QgaXNOYW1lTWF0Y2ggPSAoY3VycmVudE5hbWUsIHNpZ25hbE5hbWUsIGV4YWN0KSA9PiBleGFjdFxuICAgID8gY3VycmVudE5hbWUgPT09IHNpZ25hbE5hbWUgfHwgY3VycmVudE5hbWUuc3RhcnRzV2l0aChzaWduYWxOYW1lICsgJy4nKVxuICAgIDogY3VycmVudE5hbWUuc3RhcnRzV2l0aChzaWduYWxOYW1lKSB8fCBzaWduYWxOYW1lLnN0YXJ0c1dpdGgoY3VycmVudE5hbWUpO1xudmFyIHNob3VsZFN1YnNjcmliZUJ5TmFtZSA9IChuYW1lLCBzaWduYWxOYW1lLCBleGFjdCkgPT4ge1xuICAgIGlmICghbmFtZSB8fCAhc2lnbmFsTmFtZSB8fCBuYW1lID09PSBzaWduYWxOYW1lKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAoIUFycmF5LmlzQXJyYXkobmFtZSkpIHtcbiAgICAgICAgcmV0dXJuIGlzTmFtZU1hdGNoKG5hbWUsIHNpZ25hbE5hbWUsIGV4YWN0KTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBjdXJyZW50TmFtZSBvZiBuYW1lKSB7XG4gICAgICAgIGlmIChjdXJyZW50TmFtZSAmJiBpc05hbWVNYXRjaChjdXJyZW50TmFtZSwgc2lnbmFsTmFtZSwgZXhhY3QpKSB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG59O1xuXG52YXIgc2tpcFZhbGlkYXRpb24gPSAoaXNCbHVyRXZlbnQsIGlzVG91Y2hlZCwgaXNTdWJtaXR0ZWQsIHJlVmFsaWRhdGVNb2RlLCBtb2RlKSA9PiB7XG4gICAgaWYgKG1vZGUuaXNPbkFsbCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGVsc2UgaWYgKCFpc1N1Ym1pdHRlZCAmJiBtb2RlLmlzT25Ub3VjaCkge1xuICAgICAgICByZXR1cm4gIShpc1RvdWNoZWQgfHwgaXNCbHVyRXZlbnQpO1xuICAgIH1cbiAgICBlbHNlIGlmIChpc1N1Ym1pdHRlZCA/IHJlVmFsaWRhdGVNb2RlLmlzT25CbHVyIDogbW9kZS5pc09uQmx1cikge1xuICAgICAgICByZXR1cm4gIWlzQmx1ckV2ZW50O1xuICAgIH1cbiAgICBlbHNlIGlmIChpc1N1Ym1pdHRlZCA/IHJlVmFsaWRhdGVNb2RlLmlzT25DaGFuZ2UgOiBtb2RlLmlzT25DaGFuZ2UpIHtcbiAgICAgICAgcmV0dXJuIGlzQmx1ckV2ZW50O1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbn07XG5cbnZhciB1bnNldEVtcHR5QXJyYXkgPSAocmVmLCBuYW1lKSA9PiB7XG4gICAgY29uc3QgYXJyYXkgPSBnZXQocmVmLCBuYW1lKTtcbiAgICAhY29tcGFjdChhcnJheSkubGVuZ3RoICYmXG4gICAgICAgICEoYXJyYXkgJiYgYXJyYXkucm9vdCkgJiZcbiAgICAgICAgdW5zZXQocmVmLCBuYW1lKTtcbn07XG5cbmNvbnN0IGRlZmF1bHRPcHRpb25zID0ge1xuICAgIG1vZGU6IFZBTElEQVRJT05fTU9ERS5vblN1Ym1pdCxcbiAgICByZVZhbGlkYXRlTW9kZTogVkFMSURBVElPTl9NT0RFLm9uQ2hhbmdlLFxuICAgIHNob3VsZEZvY3VzRXJyb3I6IHRydWUsXG59O1xuY29uc3QgcmVwbGFjZURpcnR5RmllbGRzSW5QbGFjZSA9IChkaXJ0eUZpZWxkcywgbmV4dERpcnR5RmllbGRzKSA9PiB7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gZGlydHlGaWVsZHMpIHtcbiAgICAgICAgZGVsZXRlIGRpcnR5RmllbGRzW2tleV07XG4gICAgfVxuICAgIE9iamVjdC5hc3NpZ24oZGlydHlGaWVsZHMsIG5leHREaXJ0eUZpZWxkcyk7XG59O1xuY29uc3QgREVGQVVMVF9GT1JNX1NUQVRFID0ge1xuICAgIHN1Ym1pdENvdW50OiAwLFxuICAgIGlzRGlydHk6IGZhbHNlLFxuICAgIGlzUmVhZHk6IGZhbHNlLFxuICAgIGlzVmFsaWRhdGluZzogZmFsc2UsXG4gICAgaXNTdWJtaXR0ZWQ6IGZhbHNlLFxuICAgIGlzU3VibWl0dGluZzogZmFsc2UsXG4gICAgaXNTdWJtaXRTdWNjZXNzZnVsOiBmYWxzZSxcbiAgICBpc1ZhbGlkOiBmYWxzZSxcbiAgICB0b3VjaGVkRmllbGRzOiB7fSxcbiAgICBkaXJ0eUZpZWxkczoge30sXG4gICAgdmFsaWRhdGluZ0ZpZWxkczoge30sXG59O1xuZnVuY3Rpb24gY3JlYXRlRm9ybUNvbnRyb2wocHJvcHMgPSB7fSkge1xuICAgIGxldCBfb3B0aW9ucyA9IHtcbiAgICAgICAgLi4uZGVmYXVsdE9wdGlvbnMsXG4gICAgICAgIC4uLnByb3BzLFxuICAgIH07XG4gICAgbGV0IF9mb3JtU3RhdGUgPSB7XG4gICAgICAgIC4uLmNsb25lT2JqZWN0KERFRkFVTFRfRk9STV9TVEFURSksXG4gICAgICAgIGlzTG9hZGluZzogaXNGdW5jdGlvbihfb3B0aW9ucy5kZWZhdWx0VmFsdWVzKSxcbiAgICAgICAgZXJyb3JzOiBjbG9uZU9iamVjdChfb3B0aW9ucy5lcnJvcnMpIHx8IHt9LFxuICAgICAgICBkaXNhYmxlZDogX29wdGlvbnMuZGlzYWJsZWQgfHwgZmFsc2UsXG4gICAgfTtcbiAgICBsZXQgX2ZpZWxkcyA9IHt9O1xuICAgIGxldCBfZGVmYXVsdFZhbHVlcyA9IGlzT2JqZWN0KF9vcHRpb25zLmRlZmF1bHRWYWx1ZXMpIHx8IGlzT2JqZWN0KF9vcHRpb25zLnZhbHVlcylcbiAgICAgICAgPyBjbG9uZU9iamVjdChfb3B0aW9ucy5kZWZhdWx0VmFsdWVzIHx8IF9vcHRpb25zLnZhbHVlcykgfHwge31cbiAgICAgICAgOiB7fTtcbiAgICBsZXQgX2Zvcm1WYWx1ZXMgPSBfb3B0aW9ucy5zaG91bGRVbnJlZ2lzdGVyXG4gICAgICAgID8ge31cbiAgICAgICAgOiBjbG9uZU9iamVjdChfZGVmYXVsdFZhbHVlcyk7XG4gICAgbGV0IF9zdGF0ZSA9IHtcbiAgICAgICAgYWN0aW9uOiBmYWxzZSxcbiAgICAgICAgYWN0aW9uQXJyYXlMZW5ndGhzOiBuZXcgTWFwKCksXG4gICAgICAgIG1vdW50OiBmYWxzZSxcbiAgICAgICAgd2F0Y2g6IGZhbHNlLFxuICAgICAgICBrZWVwSXNWYWxpZDogZmFsc2UsXG4gICAgfTtcbiAgICBsZXQgX2RpcnR5RmllbGRzU3RhbGUgPSBmYWxzZTtcbiAgICBsZXQgX25hbWVzID0ge1xuICAgICAgICBtb3VudDogbmV3IFNldCgpLFxuICAgICAgICBkaXNhYmxlZDogbmV3IFNldCgpLFxuICAgICAgICB1bk1vdW50OiBuZXcgU2V0KCksXG4gICAgICAgIGFycmF5OiBuZXcgU2V0KCksXG4gICAgICAgIHdhdGNoOiBuZXcgU2V0KCksXG4gICAgICAgIHJlZ2lzdGVyTmFtZTogbmV3IFNldCgpLFxuICAgIH07XG4gICAgY29uc3QgZGVsYXlFcnJvckNhbGxiYWNrcyA9IHt9O1xuICAgIGNvbnN0IHRpbWVycyA9IHt9O1xuICAgIGNvbnN0IF92YWx1ZXNTdWJzY3JpYmVycyA9IG5ldyBTZXQoKTtcbiAgICBsZXQgX3ZhbGlkYXRpb25Nb2RlQmVmb3JlU3VibWl0ID0gZ2V0VmFsaWRhdGlvbk1vZGVzKF9vcHRpb25zLm1vZGUpO1xuICAgIGxldCBfdmFsaWRhdGlvbk1vZGVBZnRlclN1Ym1pdCA9IGdldFZhbGlkYXRpb25Nb2Rlcyhfb3B0aW9ucy5yZVZhbGlkYXRlTW9kZSk7XG4gICAgY29uc3QgZGVmYXVsdFByb3h5Rm9ybVN0YXRlID0ge1xuICAgICAgICBpc0RpcnR5OiBmYWxzZSxcbiAgICAgICAgZGlydHlGaWVsZHM6IGZhbHNlLFxuICAgICAgICB2YWxpZGF0aW5nRmllbGRzOiBmYWxzZSxcbiAgICAgICAgdG91Y2hlZEZpZWxkczogZmFsc2UsXG4gICAgICAgIGlzVmFsaWRhdGluZzogZmFsc2UsXG4gICAgICAgIGlzVmFsaWQ6IGZhbHNlLFxuICAgICAgICBlcnJvcnM6IGZhbHNlLFxuICAgIH07XG4gICAgY29uc3QgX3Byb3h5Rm9ybVN0YXRlID0ge1xuICAgICAgICAuLi5kZWZhdWx0UHJveHlGb3JtU3RhdGUsXG4gICAgfTtcbiAgICBjb25zdCBfcHJveHlTdWJzY3JpYmVGb3JtU3RhdGUgPSB7fTtcbiAgICBjb25zdCBfaXNUcmFja2VkID0gKC4uLmtleXMpID0+IGtleXMuc29tZSgoa2V5KSA9PiBfcHJveHlGb3JtU3RhdGVba2V5XSB8fCBfcHJveHlTdWJzY3JpYmVGb3JtU3RhdGVba2V5XSk7XG4gICAgY29uc3QgX2hhc1ZhbHVlc1N1YnNjcmliZXIgPSAobmFtZSkgPT4ge1xuICAgICAgICBmb3IgKGNvbnN0IHN1YnNjcmliZXIgb2YgX3ZhbHVlc1N1YnNjcmliZXJzKSB7XG4gICAgICAgICAgICBpZiAoc2hvdWxkU3Vic2NyaWJlQnlOYW1lKHN1YnNjcmliZXIubmFtZSwgbmFtZSwgc3Vic2NyaWJlci5leGFjdCkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfTtcbiAgICBjb25zdCBfc3ViamVjdHMgPSB7XG4gICAgICAgIGFycmF5OiBjcmVhdGVTdWJqZWN0KCksXG4gICAgICAgIHN0YXRlOiBjcmVhdGVTdWJqZWN0KCksXG4gICAgfTtcbiAgICBsZXQgX3NldFZhbGlkQ2FsbElkID0gMDtcbiAgICBsZXQgX3ZhbGlkYXRlRm9ybUNhbGxJZCA9IDA7XG4gICAgbGV0IF9yZXNldENhbGxJZCA9IDA7XG4gICAgbGV0IF9yZWdpc3RlckNhbGxJZCA9IDA7XG4gICAgY29uc3QgX3JlZ2lzdGVyQ2FsbElkcyA9IHt9O1xuICAgIGxldCBzaG91bGREaXNwbGF5QWxsQXNzb2NpYXRlZEVycm9ycyA9IF9vcHRpb25zLmNyaXRlcmlhTW9kZSA9PT0gVkFMSURBVElPTl9NT0RFLmFsbDtcbiAgICBjb25zdCBkZWJvdW5jZSA9IChuYW1lLCBjYWxsYmFjaykgPT4gKHdhaXQpID0+IHtcbiAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVyc1tuYW1lXSk7XG4gICAgICAgIHRpbWVyc1tuYW1lXSA9IHNldFRpbWVvdXQoY2FsbGJhY2ssIHdhaXQpO1xuICAgIH07XG4gICAgY29uc3QgY2FuY2VsRGVsYXllZEVycm9yID0gKG5hbWUpID0+IHtcbiAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVyc1tuYW1lXSk7XG4gICAgICAgIGRlbGV0ZSB0aW1lcnNbbmFtZV07XG4gICAgICAgIGRlbGV0ZSBkZWxheUVycm9yQ2FsbGJhY2tzW25hbWVdO1xuICAgIH07XG4gICAgY29uc3QgY2FuY2VsRGVsYXllZEVycm9yVHJlZSA9IChuYW1lKSA9PiB7XG4gICAgICAgIGNhbmNlbERlbGF5ZWRFcnJvcihuYW1lKTtcbiAgICAgICAgY29uc3QgcHJlZml4ID0gYCR7bmFtZX0uYDtcbiAgICAgICAgZm9yIChjb25zdCBrZXkgb2YgT2JqZWN0LmtleXMoZGVsYXlFcnJvckNhbGxiYWNrcykpIHtcbiAgICAgICAgICAgIGtleS5zdGFydHNXaXRoKHByZWZpeCkgJiYgY2FuY2VsRGVsYXllZEVycm9yKGtleSk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IF9zZXRWYWxpZCA9IGFzeW5jIChzaG91bGRVcGRhdGVWYWxpZCkgPT4ge1xuICAgICAgICBpZiAoX3N0YXRlLmtlZXBJc1ZhbGlkKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFfb3B0aW9ucy5kaXNhYmxlZCAmJiAoX2lzVHJhY2tlZCgnaXNWYWxpZCcpIHx8IHNob3VsZFVwZGF0ZVZhbGlkKSkge1xuICAgICAgICAgICAgY29uc3QgY2FsbElkID0gKytfc2V0VmFsaWRDYWxsSWQ7XG4gICAgICAgICAgICBjb25zdCByZXNldENhbGxJZCA9IF9yZXNldENhbGxJZDtcbiAgICAgICAgICAgIGxldCBpc1ZhbGlkO1xuICAgICAgICAgICAgaWYgKF9vcHRpb25zLnJlc29sdmVyKSB7XG4gICAgICAgICAgICAgICAgaXNWYWxpZCA9IGlzRW1wdHlPYmplY3QoKGF3YWl0IF9ydW5TY2hlbWEoKSkuZXJyb3JzKTtcbiAgICAgICAgICAgICAgICBjYWxsSWQgPT09IF9zZXRWYWxpZENhbGxJZCAmJiBfdXBkYXRlSXNWYWxpZGF0aW5nKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBpc1ZhbGlkID0gYXdhaXQgZXhlY3V0ZUJ1aWx0SW5WYWxpZGF0aW9uKHtcbiAgICAgICAgICAgICAgICAgICAgZmllbGRzOiBfZmllbGRzLFxuICAgICAgICAgICAgICAgICAgICBvbmx5Q2hlY2tWYWxpZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgZXZlbnRUeXBlOiBFVkVOVFMuVkFMSUQsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoY2FsbElkICE9PSBfc2V0VmFsaWRDYWxsSWQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAocmVzZXRDYWxsSWQgIT09IF9yZXNldENhbGxJZCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBfc2V0VmFsaWQoc2hvdWxkVXBkYXRlVmFsaWQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGlzVmFsaWQgIT09IF9mb3JtU3RhdGUuaXNWYWxpZCkge1xuICAgICAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICAgICAgaXNWYWxpZCxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgX3VwZGF0ZVZhbGlkYXRpbmdGaWVsZHMgPSAobmFtZXMsIGlzVmFsaWRhdGluZykgPT4ge1xuICAgICAgICBjb25zdCBmaWVsZE5hbWVzID0gWy4uLm5hbWVzXTtcbiAgICAgICAgaWYgKCFmaWVsZE5hbWVzLnNvbWUoKG5hbWUpID0+IG5hbWUgJiZcbiAgICAgICAgICAgIChpc1ZhbGlkYXRpbmdcbiAgICAgICAgICAgICAgICA/IGdldChfZm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMsIG5hbWUpICE9PSB0cnVlXG4gICAgICAgICAgICAgICAgOiBoYXMoX2Zvcm1TdGF0ZS52YWxpZGF0aW5nRmllbGRzLCBuYW1lKSkpKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdmFsaWRhdGluZ0ZpZWxkcyA9IGNsb25lT2JqZWN0KF9mb3JtU3RhdGUudmFsaWRhdGluZ0ZpZWxkcyk7XG4gICAgICAgIGZvciAoY29uc3QgbmFtZSBvZiBmaWVsZE5hbWVzKSB7XG4gICAgICAgICAgICBpZiAobmFtZSkge1xuICAgICAgICAgICAgICAgIGlzVmFsaWRhdGluZ1xuICAgICAgICAgICAgICAgICAgICA/IHNldCh2YWxpZGF0aW5nRmllbGRzLCBuYW1lLCB0cnVlKVxuICAgICAgICAgICAgICAgICAgICA6IHVuc2V0KHZhbGlkYXRpbmdGaWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmICghZGVlcEVxdWFsKF9mb3JtU3RhdGUudmFsaWRhdGluZ0ZpZWxkcywgdmFsaWRhdGluZ0ZpZWxkcykpIHtcbiAgICAgICAgICAgIF9mb3JtU3RhdGUudmFsaWRhdGluZ0ZpZWxkcyA9IHZhbGlkYXRpbmdGaWVsZHM7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IF91cGRhdGVJc1ZhbGlkYXRpbmcgPSAobmFtZXMsIGlzVmFsaWRhdGluZykgPT4ge1xuICAgICAgICBpZiAoIV9vcHRpb25zLmRpc2FibGVkICYmIF9pc1RyYWNrZWQoJ2lzVmFsaWRhdGluZycsICd2YWxpZGF0aW5nRmllbGRzJykpIHtcbiAgICAgICAgICAgIF91cGRhdGVWYWxpZGF0aW5nRmllbGRzKG5hbWVzIHx8IF9uYW1lcy5tb3VudCwgaXNWYWxpZGF0aW5nKTtcbiAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICB2YWxpZGF0aW5nRmllbGRzOiBfZm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMsXG4gICAgICAgICAgICAgICAgaXNWYWxpZGF0aW5nOiAhaXNFbXB0eU9iamVjdChfZm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMpLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IF91cGRhdGVEaXJ0eUZpZWxkcyA9ICgpID0+IHtcbiAgICAgICAgX2Zvcm1TdGF0ZS5kaXJ0eUZpZWxkcyA9IGdldERpcnR5RmllbGRzKF9kZWZhdWx0VmFsdWVzLCBfZm9ybVZhbHVlcywgdW5kZWZpbmVkLCBfZmllbGRzKTtcbiAgICB9O1xuICAgIGNvbnN0IF9zZXRGaWVsZEFycmF5ID0gKG5hbWUsIHZhbHVlcyA9IFtdLCBtZXRob2QsIGFyZ3MsIHNob3VsZFNldFZhbHVlcyA9IHRydWUsIHNob3VsZFVwZGF0ZUZpZWxkc0FuZFN0YXRlID0gdHJ1ZSkgPT4ge1xuICAgICAgICBpZiAoYXJncyAmJiBtZXRob2QgJiYgIV9vcHRpb25zLmRpc2FibGVkKSB7XG4gICAgICAgICAgICBfc3RhdGUuYWN0aW9uID0gdHJ1ZTtcbiAgICAgICAgICAgIF9zdGF0ZS5rZWVwSXNWYWxpZCA9IGZhbHNlO1xuICAgICAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICBjb25zdCByb290RmllbGQgPSBmaWVsZCAmJiBmaWVsZC5fZjtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkcyA9IHJvb3RGaWVsZCA/IE9iamVjdC5hc3NpZ24oW10sIGZpZWxkKSA6IGZpZWxkO1xuICAgICAgICAgICAgaWYgKCFfc3RhdGUuYWN0aW9uQXJyYXlMZW5ndGhzLmhhcyhuYW1lKSkge1xuICAgICAgICAgICAgICAgIF9zdGF0ZS5hY3Rpb25BcnJheUxlbmd0aHMuc2V0KG5hbWUsIEFycmF5LmlzQXJyYXkoZmllbGRzKSA/IGZpZWxkcy5sZW5ndGggOiAwKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChzaG91bGRVcGRhdGVGaWVsZHNBbmRTdGF0ZSAmJiBBcnJheS5pc0FycmF5KGZpZWxkcykpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBmaWVsZFZhbHVlcyA9IG1ldGhvZChmaWVsZHMsIGFyZ3MuYXJnQSwgYXJncy5hcmdCKSB8fCBmaWVsZHM7XG4gICAgICAgICAgICAgICAgcm9vdEZpZWxkXG4gICAgICAgICAgICAgICAgICAgID8gc2V0KF9maWVsZHMsIG5hbWUsIHsgLi4uZmllbGRWYWx1ZXMsIF9mOiByb290RmllbGQgfSlcbiAgICAgICAgICAgICAgICAgICAgOiBzaG91bGRTZXRWYWx1ZXMgJiYgc2V0KF9maWVsZHMsIG5hbWUsIGZpZWxkVmFsdWVzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IGZpZWxkQXJyYXlFcnJvcnMgPSBnZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpO1xuICAgICAgICAgICAgaWYgKHNob3VsZFVwZGF0ZUZpZWxkc0FuZFN0YXRlICYmIEFycmF5LmlzQXJyYXkoZmllbGRBcnJheUVycm9ycykpIHtcbiAgICAgICAgICAgICAgICBjb25zdCByb290RXJyb3IgPSBmaWVsZEFycmF5RXJyb3JzLnJvb3Q7XG4gICAgICAgICAgICAgICAgY29uc3QgZXJyb3JzID0gbWV0aG9kKGZpZWxkQXJyYXlFcnJvcnMsIGFyZ3MuYXJnQSwgYXJncy5hcmdCKSB8fCBmaWVsZEFycmF5RXJyb3JzO1xuICAgICAgICAgICAgICAgIGlmIChyb290RXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgZXJyb3JzLnJvb3QgPSByb290RXJyb3I7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHNob3VsZFNldFZhbHVlcyAmJiBzZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUsIGVycm9ycyk7XG4gICAgICAgICAgICAgICAgdW5zZXRFbXB0eUFycmF5KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICBfZm9ybVN0YXRlLmVycm9ycyA9IHsgLi4uX2Zvcm1TdGF0ZS5lcnJvcnMgfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IHRvdWNoZWRGaWVsZHNBcnJheSA9IGdldChfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgY29uc3Qgc2hvdWxkVXBkYXRlVG91Y2hlZEZpZWxkcyA9IHNob3VsZFVwZGF0ZUZpZWxkc0FuZFN0YXRlICYmIEFycmF5LmlzQXJyYXkodG91Y2hlZEZpZWxkc0FycmF5KTtcbiAgICAgICAgICAgIGlmIChzaG91bGRVcGRhdGVUb3VjaGVkRmllbGRzKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgdG91Y2hlZEZpZWxkcyA9IG1ldGhvZCh0b3VjaGVkRmllbGRzQXJyYXksIGFyZ3MuYXJnQSwgYXJncy5hcmdCKTtcbiAgICAgICAgICAgICAgICBzaG91bGRTZXRWYWx1ZXMgJiYgc2V0KF9mb3JtU3RhdGUudG91Y2hlZEZpZWxkcywgbmFtZSwgdG91Y2hlZEZpZWxkcyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBkaXJ0eUZpZWxkc0FycmF5ID0gZ2V0KF9mb3JtU3RhdGUuZGlydHlGaWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgaWYgKHNob3VsZFVwZGF0ZUZpZWxkc0FuZFN0YXRlICYmIEFycmF5LmlzQXJyYXkoZGlydHlGaWVsZHNBcnJheSkpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBkaXJ0eUZpZWxkcyA9IG1ldGhvZChkaXJ0eUZpZWxkc0FycmF5LCBhcmdzLmFyZ0EsIGFyZ3MuYXJnQikgfHwgZGlydHlGaWVsZHNBcnJheTtcbiAgICAgICAgICAgICAgICBzaG91bGRTZXRWYWx1ZXMgJiYgc2V0KF9mb3JtU3RhdGUuZGlydHlGaWVsZHMsIG5hbWUsIGRpcnR5RmllbGRzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChfaXNUcmFja2VkKCdkaXJ0eUZpZWxkcycpKSB7XG4gICAgICAgICAgICAgICAgX3VwZGF0ZURpcnR5RmllbGRzKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBfZGlydHlGaWVsZHNTdGFsZSA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgICAgICBpc0RpcnR5OiBfZ2V0RGlydHkobmFtZSwgdmFsdWVzKSxcbiAgICAgICAgICAgICAgICBkaXJ0eUZpZWxkczogX2Zvcm1TdGF0ZS5kaXJ0eUZpZWxkcyxcbiAgICAgICAgICAgICAgICAuLi4oc2hvdWxkVXBkYXRlVG91Y2hlZEZpZWxkcyAmJiB7XG4gICAgICAgICAgICAgICAgICAgIHRvdWNoZWRGaWVsZHM6IF9mb3JtU3RhdGUudG91Y2hlZEZpZWxkcyxcbiAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICBlcnJvcnM6IF9mb3JtU3RhdGUuZXJyb3JzLFxuICAgICAgICAgICAgICAgIGlzVmFsaWQ6IF9mb3JtU3RhdGUuaXNWYWxpZCxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgc2V0KF9mb3JtVmFsdWVzLCBuYW1lLCB2YWx1ZXMpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCB1cGRhdGVFcnJvcnMgPSAobmFtZSwgZXJyb3IpID0+IHtcbiAgICAgICAgc2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lLCBlcnJvcik7XG4gICAgICAgIF9mb3JtU3RhdGUuZXJyb3JzID0geyAuLi5fZm9ybVN0YXRlLmVycm9ycyB9O1xuICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICBlcnJvcnM6IF9mb3JtU3RhdGUuZXJyb3JzLFxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IF9zZXRFcnJvcnMgPSAoZXJyb3JzKSA9PiB7XG4gICAgICAgIE9iamVjdC5rZXlzKGRlbGF5RXJyb3JDYWxsYmFja3MpLmZvckVhY2goY2FuY2VsRGVsYXllZEVycm9yKTtcbiAgICAgICAgY29uc3QgaGFzRXJyb3JzID0gIWlzRW1wdHlPYmplY3QoZXJyb3JzKTtcbiAgICAgICAgX2Zvcm1TdGF0ZS5lcnJvcnMgPSBjbG9uZU9iamVjdChlcnJvcnMpO1xuICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICBlcnJvcnM6IF9mb3JtU3RhdGUuZXJyb3JzLFxuICAgICAgICAgICAgLi4uKGhhc0Vycm9ycyA/IHsgaXNWYWxpZDogZmFsc2UgfSA6IHt9KSxcbiAgICAgICAgfSk7XG4gICAgICAgICFoYXNFcnJvcnMgJiYgX3N0YXRlLm1vdW50ICYmIF9zZXRWYWxpZCgpO1xuICAgIH07XG4gICAgY29uc3QgdG9QYXRoID0gKG5hbWUpID0+IGlzS2V5KG5hbWUpID8gW25hbWVdIDogc3RyaW5nVG9QYXRoKG5hbWUpO1xuICAgIGNvbnN0IGhhc0V4cGxpY2l0TnVsbEludGVybWVkaWF0ZSA9IChuYW1lKSA9PiB7XG4gICAgICAgIGNvbnN0IHNlZ21lbnRzID0gdG9QYXRoKG5hbWUpO1xuICAgICAgICBsZXQgZm9ybVZhbHVlcyA9IF9mb3JtVmFsdWVzO1xuICAgICAgICBsZXQgZGVmYXVsdFZhbHVlcyA9IF9kZWZhdWx0VmFsdWVzO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNlZ21lbnRzLmxlbmd0aCAtIDE7IGkrKykge1xuICAgICAgICAgICAgY29uc3Qga2V5ID0gc2VnbWVudHNbaV07XG4gICAgICAgICAgICBmb3JtVmFsdWVzID0gaXNOdWxsT3JVbmRlZmluZWQoZm9ybVZhbHVlcykgPyBmb3JtVmFsdWVzIDogZm9ybVZhbHVlc1trZXldO1xuICAgICAgICAgICAgZGVmYXVsdFZhbHVlcyA9IGlzTnVsbE9yVW5kZWZpbmVkKGRlZmF1bHRWYWx1ZXMpXG4gICAgICAgICAgICAgICAgPyBkZWZhdWx0VmFsdWVzXG4gICAgICAgICAgICAgICAgOiBkZWZhdWx0VmFsdWVzW2tleV07XG4gICAgICAgICAgICBpZiAoZm9ybVZhbHVlcyA9PT0gbnVsbCAmJiBkZWZhdWx0VmFsdWVzICE9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH07XG4gICAgY29uc3QgaXNTdGFsZUFycmF5RmllbGQgPSAobmFtZSkgPT4ge1xuICAgICAgICBpZiAoIV9zdGF0ZS5hY3Rpb25BcnJheUxlbmd0aHMuc2l6ZSkge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHNlZ21lbnRzID0gdG9QYXRoKG5hbWUpO1xuICAgICAgICBsZXQgbm9kZSA9IF9mb3JtVmFsdWVzO1xuICAgICAgICBsZXQgcGF0aCA9ICcnO1xuICAgICAgICBsZXQgb3duZXJEZXB0aCA9IC0xO1xuICAgICAgICBsZXQgb3duZXJQcmVBY3Rpb25MZW5ndGggPSAwO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNlZ21lbnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAoaXNOdWxsT3JVbmRlZmluZWQobm9kZSkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBrZXkgPSBzZWdtZW50c1tpXTtcbiAgICAgICAgICAgIHBhdGggPSBwYXRoID8gYCR7cGF0aH0uJHtrZXl9YCA6IGtleTtcbiAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KG5vZGUpICYmICtrZXkgPj0gbm9kZS5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gb3duZXJEZXB0aCA9PT0gLTFcbiAgICAgICAgICAgICAgICAgICAgPyBmYWxzZVxuICAgICAgICAgICAgICAgICAgICA6IGkgPT09IG93bmVyRGVwdGhcbiAgICAgICAgICAgICAgICAgICAgICAgID8gK2tleSA8IG93bmVyUHJlQWN0aW9uTGVuZ3RoXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoX3N0YXRlLmFjdGlvbkFycmF5TGVuZ3Rocy5oYXMocGF0aCkpIHtcbiAgICAgICAgICAgICAgICBvd25lckRlcHRoID0gaSArIDE7XG4gICAgICAgICAgICAgICAgb3duZXJQcmVBY3Rpb25MZW5ndGggPSBfc3RhdGUuYWN0aW9uQXJyYXlMZW5ndGhzLmdldChwYXRoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG5vZGUgPSBub2RlW2tleV07XG4gICAgICAgICAgICBpZiAoaXNVbmRlZmluZWQobm9kZSkgJiZcbiAgICAgICAgICAgICAgICBvd25lckRlcHRoICE9PSAtMSAmJlxuICAgICAgICAgICAgICAgIGkgPiBvd25lckRlcHRoICYmXG4gICAgICAgICAgICAgICAgK3NlZ21lbnRzW293bmVyRGVwdGhdIDwgb3duZXJQcmVBY3Rpb25MZW5ndGgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfTtcbiAgICBjb25zdCBpc1Bhc3RBcnJheUVuZCA9IChuYW1lKSA9PiB7XG4gICAgICAgIGxldCBub2RlID0gX2Zvcm1WYWx1ZXM7XG4gICAgICAgIGZvciAoY29uc3Qga2V5IG9mIHRvUGF0aChuYW1lKSkge1xuICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkobm9kZSkgJiYgK2tleSA+PSBub2RlLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbm9kZSA9IG5vZGUgJiYgbm9kZVtrZXldO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9O1xuICAgIGNvbnN0IHVwZGF0ZVZhbGlkQW5kVmFsdWUgPSAobmFtZSwgc2hvdWxkU2tpcFNldFZhbHVlQXMsIHZhbHVlLCByZWYpID0+IHtcbiAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgIGlmIChmaWVsZCkge1xuICAgICAgICAgICAgaWYgKGhhc0V4cGxpY2l0TnVsbEludGVybWVkaWF0ZShuYW1lKSB8fCBpc1N0YWxlQXJyYXlGaWVsZChuYW1lKSkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IHdhc1Vuc2V0SW5Gb3JtVmFsdWVzID0gaXNVbmRlZmluZWQoZ2V0KF9mb3JtVmFsdWVzLCBuYW1lKSk7XG4gICAgICAgICAgICBjb25zdCBkZWZhdWx0VmFsdWUgPSBnZXQoX2Zvcm1WYWx1ZXMsIG5hbWUsIGlzVW5kZWZpbmVkKHZhbHVlKSA/IGdldChfZGVmYXVsdFZhbHVlcywgbmFtZSkgOiB2YWx1ZSk7XG4gICAgICAgICAgICBjb25zdCBpc0VkaXRlZEJlZm9yZVJlYWR5ID0gISFyZWYgJiYgIV9mb3JtU3RhdGUuaXNSZWFkeSAmJiBpc0VkaXRlZChyZWYpO1xuICAgICAgICAgICAgaWYgKGlzVW5kZWZpbmVkKGRlZmF1bHRWYWx1ZSkgfHxcbiAgICAgICAgICAgICAgICAocmVmICYmIHJlZi5kZWZhdWx0Q2hlY2tlZCkgfHxcbiAgICAgICAgICAgICAgICBpc0VkaXRlZEJlZm9yZVJlYWR5IHx8XG4gICAgICAgICAgICAgICAgc2hvdWxkU2tpcFNldFZhbHVlQXMpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBmaWVsZFZhbHVlID0gc2hvdWxkU2tpcFNldFZhbHVlQXNcbiAgICAgICAgICAgICAgICAgICAgPyBkZWZhdWx0VmFsdWVcbiAgICAgICAgICAgICAgICAgICAgOiBnZXRGaWVsZFZhbHVlKGZpZWxkLl9mKTtcbiAgICAgICAgICAgICAgICBpZiAoIWlzVW5kZWZpbmVkKGZpZWxkVmFsdWUpIHx8ICFpc1Bhc3RBcnJheUVuZChuYW1lKSkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoX2lzVHJhY2tlZCgnZGlydHlGaWVsZHMnKSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgIWRlZXBFcXVhbChnZXQoX2Zvcm1WYWx1ZXMsIG5hbWUpLCBmaWVsZFZhbHVlKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgX2RpcnR5RmllbGRzU3RhbGUgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHNldChfZm9ybVZhbHVlcywgbmFtZSwgZmllbGRWYWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChpc0VkaXRlZEJlZm9yZVJlYWR5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVUb3VjaEFuZERpcnR5KG5hbWUsIGZpZWxkVmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgc2V0RmllbGRWYWx1ZShuYW1lLCBkZWZhdWx0VmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKF9zdGF0ZS5tb3VudCAmJiAhX3N0YXRlLmFjdGlvbikge1xuICAgICAgICAgICAgICAgIGlmIChfb3B0aW9ucy5yZXNvbHZlciAmJlxuICAgICAgICAgICAgICAgICAgICBfaXNUcmFja2VkKCdpc1ZhbGlkYXRpbmcnLCAndmFsaWRhdGluZ0ZpZWxkcycpKSB7XG4gICAgICAgICAgICAgICAgICAgIFByb21pc2UucmVzb2x2ZSgpLnRoZW4oKCkgPT4gX3NldFZhbGlkKCkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgX3NldFZhbGlkKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmICh3YXNVbnNldEluRm9ybVZhbHVlcyAmJlxuICAgICAgICAgICAgICAgICAgICBfZm9ybVN0YXRlLmlzRGlydHkgJiZcbiAgICAgICAgICAgICAgICAgICAgX2lzVHJhY2tlZCgnaXNEaXJ0eScpKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzRGlydHkgPSBfZ2V0RGlydHkoKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFpc0RpcnR5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBfZm9ybVN0YXRlLmlzRGlydHkgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHsgLi4uX2Zvcm1TdGF0ZSB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoX29wdGlvbnMuc2hvdWxkVW5yZWdpc3RlciAmJlxuICAgICAgICAgICAgICAgICAgICB3YXNVbnNldEluRm9ybVZhbHVlcyAmJlxuICAgICAgICAgICAgICAgICAgICAhaXNVbmRlZmluZWQoZ2V0KF9mb3JtVmFsdWVzLCBuYW1lKSkgJiZcbiAgICAgICAgICAgICAgICAgICAgaXNXYXRjaGVkKG5hbWUsIF9uYW1lcykpIHtcbiAgICAgICAgICAgICAgICAgICAgX3N0YXRlLndhdGNoID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IHVwZGF0ZVRvdWNoQW5kRGlydHkgPSAobmFtZSwgZmllbGRWYWx1ZSwgaXNCbHVyRXZlbnQsIHNob3VsZERpcnR5LCBzaG91bGRSZW5kZXIpID0+IHtcbiAgICAgICAgbGV0IHNob3VsZFVwZGF0ZUZpZWxkID0gZmFsc2U7XG4gICAgICAgIGxldCBpc1ByZXZpb3VzRGlydHkgPSBmYWxzZTtcbiAgICAgICAgY29uc3Qgb3V0cHV0ID0ge1xuICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgfTtcbiAgICAgICAgaWYgKCFfb3B0aW9ucy5kaXNhYmxlZCB8fCBzaG91bGREaXJ0eSA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgaWYgKCFpc0JsdXJFdmVudCB8fCBzaG91bGREaXJ0eSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGlzQ3VycmVudEZpZWxkUHJpc3RpbmUgPSBkZWVwRXF1YWwoZ2V0KF9kZWZhdWx0VmFsdWVzLCBuYW1lKSwgZmllbGRWYWx1ZSk7XG4gICAgICAgICAgICAgICAgaWYgKF9pc1RyYWNrZWQoJ2lzRGlydHknKSkge1xuICAgICAgICAgICAgICAgICAgICBpc1ByZXZpb3VzRGlydHkgPSBfZm9ybVN0YXRlLmlzRGlydHk7XG4gICAgICAgICAgICAgICAgICAgIF9mb3JtU3RhdGUuaXNEaXJ0eSA9IG91dHB1dC5pc0RpcnR5ID1cbiAgICAgICAgICAgICAgICAgICAgICAgICFpc0N1cnJlbnRGaWVsZFByaXN0aW5lIHx8IF9nZXREaXJ0eSgpO1xuICAgICAgICAgICAgICAgICAgICBzaG91bGRVcGRhdGVGaWVsZCA9IGlzUHJldmlvdXNEaXJ0eSAhPT0gb3V0cHV0LmlzRGlydHk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlzUHJldmlvdXNEaXJ0eSA9ICEhZ2V0KF9mb3JtU3RhdGUuZGlydHlGaWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgICAgIGlmIChpc0N1cnJlbnRGaWVsZFByaXN0aW5lKSB7XG4gICAgICAgICAgICAgICAgICAgIHVuc2V0KF9mb3JtU3RhdGUuZGlydHlGaWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZGVmYXVsdEZpZWxkVmFsdWUgPSBnZXQoX2RlZmF1bHRWYWx1ZXMsIG5hbWUpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBmaWVsZCA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZGlydHlWYWx1ZSA9ICEoZmllbGQgJiYgZmllbGQuX2YpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAoaXNPYmplY3QoZGVmYXVsdEZpZWxkVmFsdWUpIHx8IEFycmF5LmlzQXJyYXkoZGVmYXVsdEZpZWxkVmFsdWUpKVxuICAgICAgICAgICAgICAgICAgICAgICAgPyBnZXREaXJ0eUZpZWxkcyhkZWZhdWx0RmllbGRWYWx1ZSwgZmllbGRWYWx1ZSwgdW5kZWZpbmVkLCBmaWVsZClcbiAgICAgICAgICAgICAgICAgICAgICAgIDogdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgc2V0KF9mb3JtU3RhdGUuZGlydHlGaWVsZHMsIG5hbWUsIGRpcnR5VmFsdWUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBsZXQgZGlkUmVzeW5jRGlydHlGaWVsZHMgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICBpZiAoX2RpcnR5RmllbGRzU3RhbGUgfHxcbiAgICAgICAgICAgICAgICAgICAgKGlzQ3VycmVudEZpZWxkUHJpc3RpbmUgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIChfaXNUcmFja2VkKCdpc0RpcnR5JykgPyBfZm9ybVN0YXRlLmlzRGlydHkgOiBfZ2V0RGlydHkoKSkpKSB7XG4gICAgICAgICAgICAgICAgICAgIF9kaXJ0eUZpZWxkc1N0YWxlID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG5leHREaXJ0eUZpZWxkcyA9IGdldERpcnR5RmllbGRzKF9kZWZhdWx0VmFsdWVzLCBfZm9ybVZhbHVlcywgdW5kZWZpbmVkLCBfZmllbGRzKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFkZWVwRXF1YWwoX2Zvcm1TdGF0ZS5kaXJ0eUZpZWxkcywgbmV4dERpcnR5RmllbGRzKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZGlkUmVzeW5jRGlydHlGaWVsZHMgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVwbGFjZURpcnR5RmllbGRzSW5QbGFjZShfZm9ybVN0YXRlLmRpcnR5RmllbGRzLCBuZXh0RGlydHlGaWVsZHMpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIG91dHB1dC5kaXJ0eUZpZWxkcyA9IF9mb3JtU3RhdGUuZGlydHlGaWVsZHM7XG4gICAgICAgICAgICAgICAgc2hvdWxkVXBkYXRlRmllbGQgPVxuICAgICAgICAgICAgICAgICAgICBzaG91bGRVcGRhdGVGaWVsZCB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgKF9pc1RyYWNrZWQoJ2RpcnR5RmllbGRzJykgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoZGlkUmVzeW5jRGlydHlGaWVsZHMgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNQcmV2aW91c0RpcnR5ICE9PSAhaXNDdXJyZW50RmllbGRQcmlzdGluZSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGlzQmx1ckV2ZW50KSB7XG4gICAgICAgICAgICAgICAgY29uc3QgaXNQcmV2aW91c0ZpZWxkVG91Y2hlZCA9IGhhcyhfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHMsIG5hbWUpXG4gICAgICAgICAgICAgICAgICAgID8gZ2V0KF9mb3JtU3RhdGUudG91Y2hlZEZpZWxkcywgbmFtZSlcbiAgICAgICAgICAgICAgICAgICAgOiB1bmRlZmluZWQ7XG4gICAgICAgICAgICAgICAgaWYgKCFpc1ByZXZpb3VzRmllbGRUb3VjaGVkKSB7XG4gICAgICAgICAgICAgICAgICAgIHNldChfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHMsIG5hbWUsIGlzQmx1ckV2ZW50KTtcbiAgICAgICAgICAgICAgICAgICAgb3V0cHV0LnRvdWNoZWRGaWVsZHMgPSBfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHM7XG4gICAgICAgICAgICAgICAgICAgIHNob3VsZFVwZGF0ZUZpZWxkID1cbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3VsZFVwZGF0ZUZpZWxkIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKF9pc1RyYWNrZWQoJ3RvdWNoZWRGaWVsZHMnKSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc1ByZXZpb3VzRmllbGRUb3VjaGVkICE9PSBpc0JsdXJFdmVudCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2hvdWxkVXBkYXRlRmllbGQgJiYgc2hvdWxkUmVuZGVyICYmIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KG91dHB1dCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHNob3VsZFVwZGF0ZUZpZWxkID8gb3V0cHV0IDoge307XG4gICAgfTtcbiAgICBjb25zdCBzaG91bGRSZW5kZXJCeUVycm9yID0gKG5hbWUsIGlzVmFsaWQsIGVycm9yLCBmaWVsZFN0YXRlKSA9PiB7XG4gICAgICAgIGNvbnN0IHByZXZpb3VzRmllbGRFcnJvciA9IGdldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSk7XG4gICAgICAgIGNvbnN0IHNob3VsZFVwZGF0ZVZhbGlkID0gX2lzVHJhY2tlZCgnaXNWYWxpZCcpICYmXG4gICAgICAgICAgICBpc0Jvb2xlYW4oaXNWYWxpZCkgJiZcbiAgICAgICAgICAgIF9mb3JtU3RhdGUuaXNWYWxpZCAhPT0gaXNWYWxpZDtcbiAgICAgICAgaWYgKF9vcHRpb25zLmRlbGF5RXJyb3IgJiYgZXJyb3IpIHtcbiAgICAgICAgICAgIGRlbGF5RXJyb3JDYWxsYmFja3NbbmFtZV0gPSBkZWJvdW5jZShuYW1lLCAoKSA9PiB1cGRhdGVFcnJvcnMobmFtZSwgZXJyb3IpKTtcbiAgICAgICAgICAgIGRlbGF5RXJyb3JDYWxsYmFja3NbbmFtZV0oX29wdGlvbnMuZGVsYXlFcnJvcik7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBjYW5jZWxEZWxheWVkRXJyb3IobmFtZSk7XG4gICAgICAgICAgICBlcnJvclxuICAgICAgICAgICAgICAgID8gc2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lLCBlcnJvcilcbiAgICAgICAgICAgICAgICA6IHVuc2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lKTtcbiAgICAgICAgICAgIF9mb3JtU3RhdGUuZXJyb3JzID0geyAuLi5fZm9ybVN0YXRlLmVycm9ycyB9O1xuICAgICAgICB9XG4gICAgICAgIGlmICgoZXJyb3JcbiAgICAgICAgICAgID8gIWRlZXBFcXVhbChwcmV2aW91c0ZpZWxkRXJyb3IsIGVycm9yLCB0cnVlKVxuICAgICAgICAgICAgOiBwcmV2aW91c0ZpZWxkRXJyb3IpIHx8XG4gICAgICAgICAgICAhaXNFbXB0eU9iamVjdChmaWVsZFN0YXRlKSB8fFxuICAgICAgICAgICAgc2hvdWxkVXBkYXRlVmFsaWQpIHtcbiAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWRGb3JtU3RhdGUgPSB7XG4gICAgICAgICAgICAgICAgLi4uZmllbGRTdGF0ZSxcbiAgICAgICAgICAgICAgICAuLi4oc2hvdWxkVXBkYXRlVmFsaWQgJiYgaXNCb29sZWFuKGlzVmFsaWQpID8geyBpc1ZhbGlkIH0gOiB7fSksXG4gICAgICAgICAgICAgICAgZXJyb3JzOiBfZm9ybVN0YXRlLmVycm9ycyxcbiAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHVwZGF0ZWRGb3JtU3RhdGUpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBfcnVuU2NoZW1hID0gYXN5bmMgKG5hbWUpID0+IHtcbiAgICAgICAgX3VwZGF0ZUlzVmFsaWRhdGluZyhuYW1lLCB0cnVlKTtcbiAgICAgICAgcmV0dXJuIGF3YWl0IF9vcHRpb25zLnJlc29sdmVyKF9mb3JtVmFsdWVzLCBfb3B0aW9ucy5jb250ZXh0LCBnZXRSZXNvbHZlck9wdGlvbnMobmFtZSB8fCBfbmFtZXMubW91bnQsIF9maWVsZHMsIF9vcHRpb25zLmNyaXRlcmlhTW9kZSwgX29wdGlvbnMuc2hvdWxkVXNlTmF0aXZlVmFsaWRhdGlvbikpO1xuICAgIH07XG4gICAgY29uc3QgZXhlY3V0ZVNjaGVtYUFuZFVwZGF0ZVN0YXRlID0gYXN5bmMgKG5hbWVzKSA9PiB7XG4gICAgICAgIGNvbnN0IHJlc2V0Q2FsbElkID0gX3Jlc2V0Q2FsbElkO1xuICAgICAgICBjb25zdCByZWdpc3RlckNhbGxJZCA9IF9yZWdpc3RlckNhbGxJZDtcbiAgICAgICAgY29uc3QgcmVnaXN0ZXJlZE5hbWVzID0gbmFtZXNcbiAgICAgICAgICAgID8gbmFtZXMuZmlsdGVyKChuYW1lKSA9PiBnZXQoX2ZpZWxkcywgbmFtZSkpXG4gICAgICAgICAgICA6IFtdO1xuICAgICAgICBjb25zdCB7IGVycm9ycyB9ID0gYXdhaXQgX3J1blNjaGVtYShuYW1lcyk7XG4gICAgICAgIGlmIChyZXNldENhbGxJZCAhPT0gX3Jlc2V0Q2FsbElkKSB7XG4gICAgICAgICAgICByZXR1cm4gZXJyb3JzO1xuICAgICAgICB9XG4gICAgICAgIF91cGRhdGVJc1ZhbGlkYXRpbmcobmFtZXMpO1xuICAgICAgICBpZiAobmFtZXMpIHtcbiAgICAgICAgICAgIGZvciAoY29uc3QgbmFtZSBvZiBuYW1lcykge1xuICAgICAgICAgICAgICAgIGlmIChyZWdpc3RlcmVkTmFtZXMuaW5jbHVkZXMobmFtZSkgJiZcbiAgICAgICAgICAgICAgICAgICAgKCFnZXQoX2ZpZWxkcywgbmFtZSkgfHwgX3JlZ2lzdGVyQ2FsbElkc1tuYW1lXSA+IHJlZ2lzdGVyQ2FsbElkKSkge1xuICAgICAgICAgICAgICAgICAgICB1bnNldChlcnJvcnMsIG5hbWUpO1xuICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3QgZXJyb3IgPSBnZXQoZXJyb3JzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICBjYW5jZWxEZWxheWVkRXJyb3JUcmVlKG5hbWUpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGlzRmllbGRBcnJheVJvb3RFcnJvciA9IF9uYW1lcy5hcnJheS5oYXMobmFtZSkgJiZcbiAgICAgICAgICAgICAgICAgICAgaXNPYmplY3QoZXJyb3IpICYmXG4gICAgICAgICAgICAgICAgICAgICFPYmplY3Qua2V5cyhlcnJvcikuc29tZSgoa2V5KSA9PiAhTnVtYmVyLmlzTmFOKE51bWJlcihrZXkpKSk7XG4gICAgICAgICAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICAgICAgY29uc3QgaGFzTmVzdGVkRmllbGRzID0gaXNPYmplY3QoZmllbGQpICYmIE9iamVjdC5rZXlzKGZpZWxkKS5zb21lKChrZXkpID0+IGtleSAhPT0gJ19mJyk7XG4gICAgICAgICAgICAgICAgaXNGaWVsZEFycmF5Um9vdEVycm9yXG4gICAgICAgICAgICAgICAgICAgID8gdXBkYXRlRmllbGRBcnJheVJvb3RFcnJvcihfZm9ybVN0YXRlLmVycm9ycywgeyBbbmFtZV06IGVycm9yIH0sIG5hbWUpXG4gICAgICAgICAgICAgICAgICAgIDogKGVycm9yICYmIChlcnJvci50eXBlIHx8IGVycm9yLm1lc3NhZ2UpKSB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgQXJyYXkuaXNBcnJheShlcnJvcikgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIChpc09iamVjdChlcnJvcikgJiYgaGFzTmVzdGVkRmllbGRzKVxuICAgICAgICAgICAgICAgICAgICAgICAgPyBzZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUsIGVycm9yKVxuICAgICAgICAgICAgICAgICAgICAgICAgOiB1bnNldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBfZm9ybVN0YXRlLmVycm9ycyA9IHsgLi4uX2Zvcm1TdGF0ZS5lcnJvcnMgfTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIE9iamVjdC5rZXlzKGRlbGF5RXJyb3JDYWxsYmFja3MpLmZvckVhY2goY2FuY2VsRGVsYXllZEVycm9yKTtcbiAgICAgICAgICAgIF9mb3JtU3RhdGUuZXJyb3JzID0gZXJyb3JzO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBlcnJvcnM7XG4gICAgfTtcbiAgICBjb25zdCB2YWxpZGF0ZUZvcm0gPSBhc3luYyAoeyBuYW1lLCBldmVudFR5cGUsIG9ubHlDaGVja1ZhbGlkLCB9KSA9PiB7XG4gICAgICAgIGlmIChfb3B0aW9ucy52YWxpZGF0ZSkge1xuICAgICAgICAgICAgY29uc3QgcmVzZXRDYWxsSWQgPSBfcmVzZXRDYWxsSWQ7XG4gICAgICAgICAgICBjb25zdCB2YWxpZGF0ZUZvcm1DYWxsSWQgPSArK192YWxpZGF0ZUZvcm1DYWxsSWQ7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBfb3B0aW9ucy52YWxpZGF0ZSh7XG4gICAgICAgICAgICAgICAgZm9ybVZhbHVlczogX2Zvcm1WYWx1ZXMsXG4gICAgICAgICAgICAgICAgZm9ybVN0YXRlOiBfZm9ybVN0YXRlLFxuICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICAgICAgZXZlbnRUeXBlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBpZiAocmVzZXRDYWxsSWQgIT09IF9yZXNldENhbGxJZCB8fFxuICAgICAgICAgICAgICAgIChldmVudFR5cGUgIT09IEVWRU5UUy5TVUJNSVQgJiZcbiAgICAgICAgICAgICAgICAgICAgdmFsaWRhdGVGb3JtQ2FsbElkICE9PSBfdmFsaWRhdGVGb3JtQ2FsbElkKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKG9ubHlDaGVja1ZhbGlkICYmXG4gICAgICAgICAgICAgICAgKGlzT2JqZWN0KHJlc3VsdClcbiAgICAgICAgICAgICAgICAgICAgPyBPYmplY3QudmFsdWVzKHJlc3VsdCkuc29tZShCb29sZWFuKVxuICAgICAgICAgICAgICAgICAgICA6IGlzU3RyaW5nKHJlc3VsdCkgfHwgIXJlc3VsdCkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaXNPYmplY3QocmVzdWx0KSkge1xuICAgICAgICAgICAgICAgIGxldCBpc1ZhbGlkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICBjbGVhckVycm9ycyhGT1JNX0VSUk9SX1RZUEUpO1xuICAgICAgICAgICAgICAgIGZvciAoY29uc3Qga2V5IGluIHJlc3VsdCkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBlcnJvciA9IHJlc3VsdFtrZXldO1xuICAgICAgICAgICAgICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzVmFsaWQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEVycm9yKGAke0ZPUk1fRVJST1JfVFlQRX0uJHtrZXl9YCwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IGlzU3RyaW5nKGVycm9yLm1lc3NhZ2UpID8gZXJyb3IubWVzc2FnZSA6ICcnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6IGVycm9yLnR5cGUgfHwgSU5QVVRfVkFMSURBVElPTl9SVUxFUy52YWxpZGF0ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBpc1ZhbGlkO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoaXNTdHJpbmcocmVzdWx0KSB8fCAhcmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgY2xlYXJFcnJvcnMoRk9STV9FUlJPUl9UWVBFKTtcbiAgICAgICAgICAgICAgICBzZXRFcnJvcihGT1JNX0VSUk9SX1RZUEUsIHtcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzdWx0IHx8ICcnLFxuICAgICAgICAgICAgICAgICAgICB0eXBlOiBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLnZhbGlkYXRlLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGNsZWFyRXJyb3JzKEZPUk1fRVJST1JfVFlQRSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfTtcbiAgICBjb25zdCBleGVjdXRlQnVpbHRJblZhbGlkYXRpb24gPSBhc3luYyAoeyBmaWVsZHMsIG9ubHlDaGVja1ZhbGlkLCBuYW1lLCBldmVudFR5cGUsIGNvbnRleHQgPSB7XG4gICAgICAgIHZhbGlkOiB0cnVlLFxuICAgICAgICBydW5Sb290VmFsaWRhdGlvbjogZmFsc2UsXG4gICAgfSwgfSkgPT4ge1xuICAgICAgICBjb25zdCByZXNldENhbGxJZCA9IF9yZXNldENhbGxJZDtcbiAgICAgICAgaWYgKF9vcHRpb25zLnZhbGlkYXRlICYmICFjb250ZXh0LnJ1blJvb3RWYWxpZGF0aW9uKSB7XG4gICAgICAgICAgICBjb250ZXh0LnJ1blJvb3RWYWxpZGF0aW9uID0gdHJ1ZTtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHZhbGlkYXRlRm9ybSh7XG4gICAgICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgICAgICBldmVudFR5cGUsXG4gICAgICAgICAgICAgICAgb25seUNoZWNrVmFsaWQsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmICghcmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgY29udGV4dC52YWxpZCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIGlmIChvbmx5Q2hlY2tWYWxpZCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gY29udGV4dC52YWxpZDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChjb25zdCBuYW1lIGluIGZpZWxkcykge1xuICAgICAgICAgICAgY29uc3QgZmllbGQgPSBmaWVsZHNbbmFtZV07XG4gICAgICAgICAgICBpZiAoZmllbGQpIHtcbiAgICAgICAgICAgICAgICBjb25zdCB7IF9mLCAuLi5maWVsZFZhbHVlIH0gPSBmaWVsZDtcbiAgICAgICAgICAgICAgICBpZiAoX2YpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNGaWVsZEFycmF5Um9vdCA9IF9uYW1lcy5hcnJheS5oYXMoX2YubmFtZSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzUHJvbWlzZUZ1bmN0aW9uID0gZmllbGQuX2YgJiYgaGFzUHJvbWlzZVZhbGlkYXRpb24oZmllbGQuX2YpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBzaG91bGRUcmFja0lzVmFsaWRhdGluZ1N0YXRlID0gX2lzVHJhY2tlZCgnaXNWYWxpZGF0aW5nJywgJ3ZhbGlkYXRpbmdGaWVsZHMnKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGlzUHJvbWlzZUZ1bmN0aW9uICYmIHNob3VsZFRyYWNrSXNWYWxpZGF0aW5nU3RhdGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIF91cGRhdGVJc1ZhbGlkYXRpbmcoW19mLm5hbWVdLCB0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjb25zdCByZWdpc3RlckNhbGxJZCA9IF9yZWdpc3RlckNhbGxJZDtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZmllbGRFcnJvciA9IGF3YWl0IHZhbGlkYXRlRmllbGQoZmllbGQsIF9uYW1lcy5kaXNhYmxlZCwgX2Zvcm1WYWx1ZXMsIHNob3VsZERpc3BsYXlBbGxBc3NvY2lhdGVkRXJyb3JzLCBfb3B0aW9ucy5zaG91bGRVc2VOYXRpdmVWYWxpZGF0aW9uICYmICFvbmx5Q2hlY2tWYWxpZCwgaXNGaWVsZEFycmF5Um9vdCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXNldENhbGxJZCAhPT0gX3Jlc2V0Q2FsbElkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gY29udGV4dC52YWxpZDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAoaXNQcm9taXNlRnVuY3Rpb24gJiYgc2hvdWxkVHJhY2tJc1ZhbGlkYXRpbmdTdGF0ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgX3VwZGF0ZUlzVmFsaWRhdGluZyhbX2YubmFtZV0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmICghZ2V0KF9maWVsZHMsIF9mLm5hbWUpIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICBfcmVnaXN0ZXJDYWxsSWRzW19mLm5hbWVdID4gcmVnaXN0ZXJDYWxsSWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChmaWVsZEVycm9yW19mLm5hbWVdKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb250ZXh0LnZhbGlkID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAob25seUNoZWNrVmFsaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAoIW9ubHlDaGVja1ZhbGlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYW5jZWxEZWxheWVkRXJyb3IoX2YubmFtZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBnZXQoZmllbGRFcnJvciwgX2YubmFtZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGlzRmllbGRBcnJheVJvb3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB1cGRhdGVGaWVsZEFycmF5Um9vdEVycm9yKF9mb3JtU3RhdGUuZXJyb3JzLCBmaWVsZEVycm9yLCBfZi5uYW1lKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHNldChfZm9ybVN0YXRlLmVycm9ycywgX2YubmFtZSwgZmllbGRFcnJvcltfZi5uYW1lXSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHVuc2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBfZi5uYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAoX29wdGlvbnMuc2hvdWxkVXNlTmF0aXZlVmFsaWRhdGlvbiAmJiBmaWVsZEVycm9yW19mLm5hbWVdKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAhaXNFbXB0eU9iamVjdChmaWVsZFZhbHVlKSAmJlxuICAgICAgICAgICAgICAgICAgICAoYXdhaXQgZXhlY3V0ZUJ1aWx0SW5WYWxpZGF0aW9uKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRleHQsXG4gICAgICAgICAgICAgICAgICAgICAgICBvbmx5Q2hlY2tWYWxpZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpZWxkczogZmllbGRWYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6IG5hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBldmVudFR5cGUsXG4gICAgICAgICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gY29udGV4dC52YWxpZDtcbiAgICB9O1xuICAgIGNvbnN0IF9yZW1vdmVVbm1vdW50ZWQgPSAoKSA9PiB7XG4gICAgICAgIGZvciAoY29uc3QgbmFtZSBvZiBfbmFtZXMudW5Nb3VudCkge1xuICAgICAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICBmaWVsZCAmJlxuICAgICAgICAgICAgICAgIChmaWVsZC5fZi5yZWZzXG4gICAgICAgICAgICAgICAgICAgID8gZmllbGQuX2YucmVmcy5ldmVyeSgocmVmKSA9PiAhbGl2ZShyZWYpKVxuICAgICAgICAgICAgICAgICAgICA6ICFsaXZlKGZpZWxkLl9mLnJlZikpICYmXG4gICAgICAgICAgICAgICAgdW5yZWdpc3RlcihuYW1lKTtcbiAgICAgICAgfVxuICAgICAgICBfbmFtZXMudW5Nb3VudCA9IG5ldyBTZXQoKTtcbiAgICB9O1xuICAgIGNvbnN0IF9nZXREaXJ0eSA9IChuYW1lLCBkYXRhKSA9PiAobmFtZSAmJiAhaXNVbmRlZmluZWQoZGF0YSkgJiYgc2V0KF9mb3JtVmFsdWVzLCBuYW1lLCBkYXRhKSxcbiAgICAgICAgIWRlZXBFcXVhbChfc3RhdGUubW91bnQgPyBfZm9ybVZhbHVlcyA6IF9kZWZhdWx0VmFsdWVzLCBfZGVmYXVsdFZhbHVlcykpO1xuICAgIGNvbnN0IF9nZXRXYXRjaCA9IChuYW1lcywgZGVmYXVsdFZhbHVlLCBpc0dsb2JhbCkgPT4ge1xuICAgICAgICBjb25zdCB2YWx1ZXMgPSBfc3RhdGUubW91bnRcbiAgICAgICAgICAgID8gX2Zvcm1WYWx1ZXNcbiAgICAgICAgICAgIDogaXNVbmRlZmluZWQoZGVmYXVsdFZhbHVlKSB8fCAhaXNVbmRlZmluZWQobmFtZXMpXG4gICAgICAgICAgICAgICAgPyBfZGVmYXVsdFZhbHVlc1xuICAgICAgICAgICAgICAgIDogZGVmYXVsdFZhbHVlO1xuICAgICAgICByZXR1cm4gZ2VuZXJhdGVXYXRjaE91dHB1dChuYW1lcywgX25hbWVzLCBpc1VuZGVmaW5lZChuYW1lcykgPyB7IC4uLnZhbHVlcyB9IDogdmFsdWVzLCBpc0dsb2JhbCwgZGVmYXVsdFZhbHVlKTtcbiAgICB9O1xuICAgIGNvbnN0IF9nZXRGaWVsZEFycmF5ID0gKG5hbWUpID0+IGNvbXBhY3QoZ2V0KF9zdGF0ZS5tb3VudCA/IF9mb3JtVmFsdWVzIDogX2RlZmF1bHRWYWx1ZXMsIG5hbWUsIF9vcHRpb25zLnNob3VsZFVucmVnaXN0ZXIgPyBnZXQoX2RlZmF1bHRWYWx1ZXMsIG5hbWUsIFtdKSA6IFtdKSk7XG4gICAgY29uc3Qgc2V0RmllbGRWYWx1ZSA9IChuYW1lLCB2YWx1ZSwgb3B0aW9ucyA9IHt9LCBza2lwQ2xvbmUgPSBmYWxzZSwgc2tpcFJlbmRlciA9IGZhbHNlLCBza2lwVmFsdWVSZW5kZXIgPSBmYWxzZSkgPT4ge1xuICAgICAgICBjb25zdCBmaWVsZCA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgbGV0IGZpZWxkVmFsdWUgPSB2YWx1ZTtcbiAgICAgICAgaWYgKGZpZWxkKSB7XG4gICAgICAgICAgICBjb25zdCBmaWVsZFJlZmVyZW5jZSA9IGZpZWxkLl9mO1xuICAgICAgICAgICAgaWYgKGZpZWxkUmVmZXJlbmNlKSB7XG4gICAgICAgICAgICAgICAgIWZpZWxkUmVmZXJlbmNlLmRpc2FibGVkICYmXG4gICAgICAgICAgICAgICAgICAgIHNldChfZm9ybVZhbHVlcywgbmFtZSwgZ2V0RmllbGRWYWx1ZUFzKHZhbHVlLCBmaWVsZFJlZmVyZW5jZSkpO1xuICAgICAgICAgICAgICAgIGZpZWxkVmFsdWUgPVxuICAgICAgICAgICAgICAgICAgICBpc0hUTUxFbGVtZW50KGZpZWxkUmVmZXJlbmNlLnJlZikgJiYgaXNOdWxsT3JVbmRlZmluZWQodmFsdWUpXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICcnXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHZhbHVlO1xuICAgICAgICAgICAgICAgIGlmIChpc011bHRpcGxlU2VsZWN0KGZpZWxkUmVmZXJlbmNlLnJlZikpIHtcbiAgICAgICAgICAgICAgICAgICAgWy4uLmZpZWxkUmVmZXJlbmNlLnJlZi5vcHRpb25zXS5mb3JFYWNoKChvcHRpb25SZWYpID0+IChvcHRpb25SZWYuc2VsZWN0ZWQgPSBmaWVsZFZhbHVlLmluY2x1ZGVzKG9wdGlvblJlZi52YWx1ZSkpKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoZmllbGRSZWZlcmVuY2UucmVmcykge1xuICAgICAgICAgICAgICAgICAgICBpZiAoaXNDaGVja0JveElucHV0KGZpZWxkUmVmZXJlbmNlLnJlZikpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpZWxkUmVmZXJlbmNlLnJlZnMuZm9yRWFjaCgoY2hlY2tib3hSZWYpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWNoZWNrYm94UmVmLmRlZmF1bHRDaGVja2VkIHx8ICFjaGVja2JveFJlZi5kaXNhYmxlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShmaWVsZFZhbHVlKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tib3hSZWYuY2hlY2tlZCA9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIWlzVW5kZWZpbmVkKGNoZWNrYm94UmVmLnZhbHVlKSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWVsZFZhbHVlLmluY2x1ZGVzKGNoZWNrYm94UmVmLnZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrYm94UmVmLmNoZWNrZWQgPVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpZWxkVmFsdWUgPT09IGNoZWNrYm94UmVmLnZhbHVlIHx8ICEhZmllbGRWYWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgZmllbGRSZWZlcmVuY2UucmVmcy5mb3JFYWNoKChyYWRpb1JlZikgPT4gKHJhZGlvUmVmLmNoZWNrZWQgPSByYWRpb1JlZi52YWx1ZSA9PT0gZmllbGRWYWx1ZSkpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGlzRmlsZUlucHV0KGZpZWxkUmVmZXJlbmNlLnJlZikpIHtcbiAgICAgICAgICAgICAgICAgICAgZmllbGRSZWZlcmVuY2UucmVmLnZhbHVlID0gJyc7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBmaWVsZFJlZmVyZW5jZS5yZWYudmFsdWUgPSBmaWVsZFZhbHVlO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWZpZWxkUmVmZXJlbmNlLnJlZi50eXBlICYmICFza2lwUmVuZGVyICYmICFza2lwVmFsdWVSZW5kZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlczogc2tpcENsb25lXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gX2Zvcm1WYWx1ZXNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBfaGFzVmFsdWVzU3Vic2NyaWJlcihuYW1lKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBjbG9uZU9iamVjdChfZm9ybVZhbHVlcylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgKG9wdGlvbnMuc2hvdWxkRGlydHkgfHwgb3B0aW9ucy5zaG91bGRUb3VjaCkgJiZcbiAgICAgICAgICAgIHVwZGF0ZVRvdWNoQW5kRGlydHkobmFtZSwgZmllbGQgJiZcbiAgICAgICAgICAgICAgICBmaWVsZC5fZiAmJlxuICAgICAgICAgICAgICAgICFmaWVsZC5fZi5kaXNhYmxlZCAmJlxuICAgICAgICAgICAgICAgIChmaWVsZC5fZi52YWx1ZUFzTnVtYmVyIHx8XG4gICAgICAgICAgICAgICAgICAgIGZpZWxkLl9mLnZhbHVlQXNEYXRlIHx8XG4gICAgICAgICAgICAgICAgICAgIGZpZWxkLl9mLnNldFZhbHVlQXMpXG4gICAgICAgICAgICAgICAgPyBnZXRGaWVsZFZhbHVlQXModmFsdWUsIGZpZWxkLl9mKVxuICAgICAgICAgICAgICAgIDogZmllbGRWYWx1ZSwgb3B0aW9ucy5zaG91bGRUb3VjaCwgb3B0aW9ucy5zaG91bGREaXJ0eSwgIXNraXBSZW5kZXIpO1xuICAgICAgICBvcHRpb25zLnNob3VsZFZhbGlkYXRlICYmXG4gICAgICAgICAgICB0cmlnZ2VyKG5hbWUsIHtcbiAgICAgICAgICAgICAgICBkZWxheUVycm9yOiBvcHRpb25zLmRlbGF5RXJyb3IsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgaWYgKG9wdGlvbnMuc2hvdWxkVmFsaWRhdGUgJiZcbiAgICAgICAgICAgIGZpZWxkICYmXG4gICAgICAgICAgICBmaWVsZC5fZiAmJlxuICAgICAgICAgICAgZmllbGQuX2YuZGVwcyAmJlxuICAgICAgICAgICAgKCFBcnJheS5pc0FycmF5KGZpZWxkLl9mLmRlcHMpIHx8IGZpZWxkLl9mLmRlcHMubGVuZ3RoID4gMCkpIHtcbiAgICAgICAgICAgIHRyaWdnZXIoZmllbGQuX2YuZGVwcyk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IHNldEZpZWxkVmFsdWVzID0gKG5hbWUsIHZhbHVlLCBvcHRpb25zLCBza2lwQ2xvbmUgPSBmYWxzZSwgc2tpcFJlbmRlciA9IGZhbHNlLCBza2lwVmFsdWVSZW5kZXIgPSBmYWxzZSkgPT4ge1xuICAgICAgICBmb3IgKGNvbnN0IGZpZWxkS2V5IGluIHZhbHVlKSB7XG4gICAgICAgICAgICBpZiAoIU9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbCh2YWx1ZSwgZmllbGRLZXkpKSB7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBmaWVsZFZhbHVlID0gdmFsdWVbZmllbGRLZXldO1xuICAgICAgICAgICAgY29uc3QgZmllbGROYW1lID0gbmFtZSArICcuJyArIGZpZWxkS2V5O1xuICAgICAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgZmllbGROYW1lKTtcbiAgICAgICAgICAgIGlmIChfbmFtZXMuYXJyYXkuaGFzKGZpZWxkTmFtZSkpIHtcbiAgICAgICAgICAgICAgICBfc3ViamVjdHMuYXJyYXkubmV4dCh7XG4gICAgICAgICAgICAgICAgICAgIG5hbWU6IGZpZWxkTmFtZSxcbiAgICAgICAgICAgICAgICAgICAgdmFsdWVzOiBza2lwQ2xvbmUgPyBfZm9ybVZhbHVlcyA6IGNsb25lT2JqZWN0KF9mb3JtVmFsdWVzKSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIChfbmFtZXMuYXJyYXkuaGFzKG5hbWUpIHx8XG4gICAgICAgICAgICAgICAgaXNPYmplY3QoZmllbGRWYWx1ZSkgfHxcbiAgICAgICAgICAgICAgICAoZmllbGQgJiYgIWZpZWxkLl9mKSkgJiZcbiAgICAgICAgICAgICAgICAhaXNEYXRlT2JqZWN0KGZpZWxkVmFsdWUpXG4gICAgICAgICAgICAgICAgPyBzZXRGaWVsZFZhbHVlcyhmaWVsZE5hbWUsIGZpZWxkVmFsdWUsIG9wdGlvbnMsIHNraXBDbG9uZSwgc2tpcFJlbmRlciwgc2tpcFZhbHVlUmVuZGVyKVxuICAgICAgICAgICAgICAgIDogc2V0RmllbGRWYWx1ZShmaWVsZE5hbWUsIGZpZWxkVmFsdWUsIG9wdGlvbnMsIHNraXBDbG9uZSwgc2tpcFJlbmRlciwgc2tpcFZhbHVlUmVuZGVyKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgX3NldFZhbHVlID0gKG5hbWUsIHZhbHVlLCBvcHRpb25zLCBza2lwQ2xvbmUsIHNraXBTdGF0ZUVtaXQgPSBmYWxzZSkgPT4ge1xuICAgICAgICBjb25zdCBmaWVsZCA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgY29uc3QgaXNGaWVsZEFycmF5ID0gX25hbWVzLmFycmF5LmhhcyhuYW1lKTtcbiAgICAgICAgY29uc3QgY2xvbmVWYWx1ZSA9IHNraXBDbG9uZSA/IHZhbHVlIDogY2xvbmVPYmplY3QodmFsdWUpO1xuICAgICAgICBjb25zdCBwcmV2aW91c1ZhbHVlID0gZ2V0KF9mb3JtVmFsdWVzLCBuYW1lKTtcbiAgICAgICAgY29uc3QgaXNWYWx1ZVVuY2hhbmdlZCA9IGRlZXBFcXVhbChwcmV2aW91c1ZhbHVlLCBjbG9uZVZhbHVlKTtcbiAgICAgICAgaWYgKCFpc1ZhbHVlVW5jaGFuZ2VkKSB7XG4gICAgICAgICAgICBzZXQoX2Zvcm1WYWx1ZXMsIG5hbWUsIGNsb25lVmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0ZpZWxkQXJyYXkpIHtcbiAgICAgICAgICAgIF9zdWJqZWN0cy5hcnJheS5uZXh0KHtcbiAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgIHZhbHVlczogc2tpcENsb25lID8gX2Zvcm1WYWx1ZXMgOiBjbG9uZU9iamVjdChfZm9ybVZhbHVlcyksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmIChfaXNUcmFja2VkKCdpc0RpcnR5JywgJ2RpcnR5RmllbGRzJykgJiYgb3B0aW9ucy5zaG91bGREaXJ0eSkge1xuICAgICAgICAgICAgICAgIF91cGRhdGVEaXJ0eUZpZWxkcygpO1xuICAgICAgICAgICAgICAgIF9mb3JtU3RhdGUuaXNEaXJ0eSA9IF9nZXREaXJ0eShuYW1lLCBjbG9uZVZhbHVlKTtcbiAgICAgICAgICAgICAgICBpZiAoIXNraXBTdGF0ZUVtaXQpIHtcbiAgICAgICAgICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpcnR5RmllbGRzOiBfZm9ybVN0YXRlLmRpcnR5RmllbGRzLFxuICAgICAgICAgICAgICAgICAgICAgICAgaXNEaXJ0eTogX2Zvcm1TdGF0ZS5pc0RpcnR5LFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBvcHRpb25zLnNob3VsZFZhbGlkYXRlICYmXG4gICAgICAgICAgICAgICAgdHJpZ2dlcihuYW1lLCB7XG4gICAgICAgICAgICAgICAgICAgIGRlbGF5RXJyb3I6IG9wdGlvbnMuZGVsYXlFcnJvcixcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IGlzRW1wdHkgPSAoQXJyYXkuaXNBcnJheShjbG9uZVZhbHVlKSAmJiAhY2xvbmVWYWx1ZS5sZW5ndGgpIHx8XG4gICAgICAgICAgICAgICAgaXNFbXB0eU9iamVjdChjbG9uZVZhbHVlKTtcbiAgICAgICAgICAgIGNvbnN0IHNraXBWYWx1ZVJlbmRlciA9ICFpc1ZhbHVlVW5jaGFuZ2VkICYmICFza2lwU3RhdGVFbWl0O1xuICAgICAgICAgICAgaWYgKCFmaWVsZCB8fCBmaWVsZC5fZiB8fCBpc051bGxPclVuZGVmaW5lZChjbG9uZVZhbHVlKSB8fCBpc0VtcHR5KSB7XG4gICAgICAgICAgICAgICAgc2V0RmllbGRWYWx1ZShuYW1lLCBjbG9uZVZhbHVlLCBvcHRpb25zLCBza2lwQ2xvbmUsIHNraXBTdGF0ZUVtaXQsIHNraXBWYWx1ZVJlbmRlcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBzZXRGaWVsZFZhbHVlcyhuYW1lLCBjbG9uZVZhbHVlLCBvcHRpb25zLCBza2lwQ2xvbmUsIHNraXBTdGF0ZUVtaXQsIHNraXBWYWx1ZVJlbmRlcik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFpc1ZhbHVlVW5jaGFuZ2VkICYmICFza2lwU3RhdGVFbWl0KSB7XG4gICAgICAgICAgICBjb25zdCB3YXRjaGVkID0gaXNXYXRjaGVkKG5hbWUsIF9uYW1lcyk7XG4gICAgICAgICAgICBjb25zdCBlbWl0dGVkTmFtZSA9IF9zdGF0ZS5tb3VudCB8fCB3YXRjaGVkID8gbmFtZSA6IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkQXJyYXlJdGVtTmFtZXMgPSBpc0ZpZWxkQXJyYXlcbiAgICAgICAgICAgICAgICA/IFtdXG4gICAgICAgICAgICAgICAgOiBnZXRGaWVsZEFycmF5SXRlbU5hbWVzKF9uYW1lcy5hcnJheSwgbmFtZSk7XG4gICAgICAgICAgICBjb25zdCB2YWx1ZXMgPSBza2lwQ2xvbmVcbiAgICAgICAgICAgICAgICA/IF9mb3JtVmFsdWVzXG4gICAgICAgICAgICAgICAgOiBfaGFzVmFsdWVzU3Vic2NyaWJlcihlbWl0dGVkTmFtZSkgfHxcbiAgICAgICAgICAgICAgICAgICAgZmllbGRBcnJheUl0ZW1OYW1lcy5zb21lKF9oYXNWYWx1ZXNTdWJzY3JpYmVyKVxuICAgICAgICAgICAgICAgICAgICA/IGNsb25lT2JqZWN0KF9mb3JtVmFsdWVzKVxuICAgICAgICAgICAgICAgICAgICA6IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICAuLi4od2F0Y2hlZCAmJiBfZm9ybVN0YXRlKSxcbiAgICAgICAgICAgICAgICBuYW1lOiBlbWl0dGVkTmFtZSxcbiAgICAgICAgICAgICAgICB2YWx1ZXMsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGZvciAoY29uc3QgaXRlbU5hbWUgb2YgZmllbGRBcnJheUl0ZW1OYW1lcykge1xuICAgICAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogaXRlbU5hbWUsXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlczogdmFsdWVzICYmIGNsb25lT2JqZWN0KF9mb3JtVmFsdWVzKSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3Qgc2V0VmFsdWUgPSAobmFtZSwgdmFsdWUsIG9wdGlvbnMgPSB7fSkgPT4gX3NldFZhbHVlKG5hbWUsIHZhbHVlLCBvcHRpb25zLCBmYWxzZSk7XG4gICAgY29uc3Qgc2V0VmFsdWVzID0gKGZvcm1WYWx1ZXMsIG9wdGlvbnMgPSB7fSkgPT4ge1xuICAgICAgICBjb25zdCB1cGRhdGVkRm9ybVZhbHVlcyA9IGlzRnVuY3Rpb24oZm9ybVZhbHVlcylcbiAgICAgICAgICAgID8gZm9ybVZhbHVlcyhfZm9ybVZhbHVlcylcbiAgICAgICAgICAgIDogZm9ybVZhbHVlcztcbiAgICAgICAgaWYgKCFkZWVwRXF1YWwoX2Zvcm1WYWx1ZXMsIHVwZGF0ZWRGb3JtVmFsdWVzKSB8fFxuICAgICAgICAgICAgb3B0aW9ucy5zaG91bGRWYWxpZGF0ZSB8fFxuICAgICAgICAgICAgb3B0aW9ucy5zaG91bGREaXJ0eSB8fFxuICAgICAgICAgICAgb3B0aW9ucy5zaG91bGRUb3VjaCkge1xuICAgICAgICAgICAgX2Zvcm1WYWx1ZXMgPSB7XG4gICAgICAgICAgICAgICAgLi4uX2Zvcm1WYWx1ZXMsXG4gICAgICAgICAgICAgICAgLi4udXBkYXRlZEZvcm1WYWx1ZXMsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgZm9yIChjb25zdCBmaWVsZE5hbWUgb2YgbmV3IFNldChbLi4uX25hbWVzLm1vdW50LCAuLi5fbmFtZXMuYXJyYXldKSkge1xuICAgICAgICAgICAgICAgIGlmIChoYXModXBkYXRlZEZvcm1WYWx1ZXMsIGZpZWxkTmFtZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgX3NldFZhbHVlKGZpZWxkTmFtZSwgZ2V0KHVwZGF0ZWRGb3JtVmFsdWVzLCBmaWVsZE5hbWUpLCBvcHRpb25zLCB0cnVlLCB0cnVlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAob3B0aW9ucy5zaG91bGREaXJ0eSAmJiBfaXNUcmFja2VkKCdpc0RpcnR5JywgJ2RpcnR5RmllbGRzJykpIHtcbiAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IG5hbWUgb2YgT2JqZWN0LmtleXModXBkYXRlZEZvcm1WYWx1ZXMpKSB7XG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZVRvdWNoQW5kRGlydHkobmFtZSwgX2Zvcm1WYWx1ZXNbbmFtZV0sIGZhbHNlLCB0cnVlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgLi4uX2Zvcm1TdGF0ZSxcbiAgICAgICAgICAgICAgICBuYW1lOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgdHlwZTogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgIC4uLihfdmFsdWVzU3Vic2NyaWJlcnMuc2l6ZSA/IHsgdmFsdWVzOiBfZm9ybVZhbHVlcyB9IDoge30pLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBpZiAob3B0aW9ucy5zaG91bGRWYWxpZGF0ZSkge1xuICAgICAgICAgICAgICAgIF9zZXRWYWxpZCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBvbkNoYW5nZSA9IGFzeW5jIChldmVudCkgPT4ge1xuICAgICAgICBfc3RhdGUubW91bnQgPSB0cnVlO1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBldmVudC50YXJnZXQ7XG4gICAgICAgIGxldCBuYW1lID0gdGFyZ2V0Lm5hbWU7XG4gICAgICAgIGxldCBpc0ZpZWxkVmFsdWVVcGRhdGVkID0gdHJ1ZTtcbiAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgIGNvbnN0IHJlZ2lzdGVyQ2FsbElkID0gX3JlZ2lzdGVyQ2FsbElkO1xuICAgICAgICBjb25zdCBfdXBkYXRlSXNGaWVsZFZhbHVlVXBkYXRlZCA9IChmaWVsZFZhbHVlKSA9PiB7XG4gICAgICAgICAgICBpc0ZpZWxkVmFsdWVVcGRhdGVkID1cbiAgICAgICAgICAgICAgICAhIWdldChfZmllbGRzLCBuYW1lKSAmJlxuICAgICAgICAgICAgICAgICAgICAhKF9yZWdpc3RlckNhbGxJZHNbbmFtZV0gPiByZWdpc3RlckNhbGxJZCkgJiZcbiAgICAgICAgICAgICAgICAgICAgZGVlcEVxdWFsKGZpZWxkVmFsdWUsIGdldChfZm9ybVZhbHVlcywgbmFtZSwgZmllbGRWYWx1ZSkpO1xuICAgICAgICB9O1xuICAgICAgICBpZiAoZmllbGQpIHtcbiAgICAgICAgICAgIF9zdGF0ZS5rZWVwSXNWYWxpZCA9IGZhbHNlO1xuICAgICAgICAgICAgbGV0IGVycm9yO1xuICAgICAgICAgICAgbGV0IGlzVmFsaWQ7XG4gICAgICAgICAgICBsZXQgc2hvdWxkRmx1c2hFcnJvciA9IGZhbHNlO1xuICAgICAgICAgICAgY29uc3QgZmllbGRWYWx1ZSA9IHRhcmdldC50eXBlXG4gICAgICAgICAgICAgICAgPyBnZXRGaWVsZFZhbHVlKGZpZWxkLl9mKVxuICAgICAgICAgICAgICAgIDogZ2V0RXZlbnRWYWx1ZShldmVudCk7XG4gICAgICAgICAgICBjb25zdCBpc0JsdXJFdmVudCA9IGV2ZW50LnR5cGUgPT09IEVWRU5UUy5CTFVSIHx8IGV2ZW50LnR5cGUgPT09IEVWRU5UUy5GT0NVU19PVVQ7XG4gICAgICAgICAgICBjb25zdCBoYXNOb1ZhbGlkYXRpb25FZmZlY3QgPSAhaGFzVmFsaWRhdGlvbihmaWVsZC5fZikgJiZcbiAgICAgICAgICAgICAgICAhX29wdGlvbnMudmFsaWRhdGUgJiZcbiAgICAgICAgICAgICAgICAhX29wdGlvbnMucmVzb2x2ZXIgJiZcbiAgICAgICAgICAgICAgICAhZ2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lKSAmJlxuICAgICAgICAgICAgICAgICFmaWVsZC5fZi5kZXBzO1xuICAgICAgICAgICAgY29uc3Qgc2hvdWxkU2tpcFZhbGlkYXRpb24gPSBoYXNOb1ZhbGlkYXRpb25FZmZlY3QgfHxcbiAgICAgICAgICAgICAgICBza2lwVmFsaWRhdGlvbihpc0JsdXJFdmVudCwgZ2V0KF9mb3JtU3RhdGUudG91Y2hlZEZpZWxkcywgbmFtZSksIF9mb3JtU3RhdGUuaXNTdWJtaXR0ZWQsIF92YWxpZGF0aW9uTW9kZUFmdGVyU3VibWl0LCBfdmFsaWRhdGlvbk1vZGVCZWZvcmVTdWJtaXQpO1xuICAgICAgICAgICAgY29uc3Qgd2F0Y2hlZCA9IGlzV2F0Y2hlZChuYW1lLCBfbmFtZXMsIGlzQmx1ckV2ZW50KTtcbiAgICAgICAgICAgIHNldChfZm9ybVZhbHVlcywgbmFtZSwgY2xvbmVPYmplY3QoZmllbGRWYWx1ZSkpO1xuICAgICAgICAgICAgaWYgKGlzQmx1ckV2ZW50KSB7XG4gICAgICAgICAgICAgICAgaWYgKCF0YXJnZXQgfHwgIXRhcmdldC5yZWFkT25seSkge1xuICAgICAgICAgICAgICAgICAgICBmaWVsZC5fZi5vbkJsdXIgJiYgZmllbGQuX2Yub25CbHVyKGV2ZW50KTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChkZWxheUVycm9yQ2FsbGJhY2tzLCBuYW1lKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2hvdWxkRmx1c2hFcnJvciA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBkZWxheUVycm9yQ2FsbGJhY2tzW25hbWVdKDApO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoZmllbGQuX2Yub25DaGFuZ2UpIHtcbiAgICAgICAgICAgICAgICBmaWVsZC5fZi5vbkNoYW5nZShldmVudCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBmaWVsZFN0YXRlID0gdXBkYXRlVG91Y2hBbmREaXJ0eShuYW1lLCBmaWVsZFZhbHVlLCBpc0JsdXJFdmVudCk7XG4gICAgICAgICAgICBjb25zdCBzaG91bGRSZW5kZXIgPSAhaXNFbXB0eU9iamVjdChmaWVsZFN0YXRlKSB8fCB3YXRjaGVkO1xuICAgICAgICAgICAgIWlzQmx1ckV2ZW50ICYmXG4gICAgICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgICAgICB0eXBlOiBldmVudC50eXBlLFxuICAgICAgICAgICAgICAgICAgICAuLi4oX2hhc1ZhbHVlc1N1YnNjcmliZXIobmFtZSlcbiAgICAgICAgICAgICAgICAgICAgICAgID8geyB2YWx1ZXM6IGNsb25lT2JqZWN0KF9mb3JtVmFsdWVzKSB9XG4gICAgICAgICAgICAgICAgICAgICAgICA6IHt9KSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmIChzaG91bGRTa2lwVmFsaWRhdGlvbikge1xuICAgICAgICAgICAgICAgIGlmICgoIWhhc05vVmFsaWRhdGlvbkVmZmVjdCB8fCAhX2Zvcm1TdGF0ZS5pc1ZhbGlkKSAmJlxuICAgICAgICAgICAgICAgICAgICBfaXNUcmFja2VkKCdpc1ZhbGlkJykpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKF9vcHRpb25zLm1vZGUgPT09ICdvbkJsdXInKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXNCbHVyRXZlbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfc2V0VmFsaWQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmICghaXNCbHVyRXZlbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIF9zZXRWYWxpZCgpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiAoc2hvdWxkUmVuZGVyICYmXG4gICAgICAgICAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHsgbmFtZSwgLi4uKHdhdGNoZWQgPyB7fSA6IGZpZWxkU3RhdGUpIH0pKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghX29wdGlvbnMucmVzb2x2ZXIgJiYgX29wdGlvbnMudmFsaWRhdGUpIHtcbiAgICAgICAgICAgICAgICBhd2FpdCB2YWxpZGF0ZUZvcm0oe1xuICAgICAgICAgICAgICAgICAgICBuYW1lOiBuYW1lLFxuICAgICAgICAgICAgICAgICAgICBldmVudFR5cGU6IGV2ZW50LnR5cGUsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAhaXNCbHVyRXZlbnQgJiYgd2F0Y2hlZCAmJiBfc3ViamVjdHMuc3RhdGUubmV4dCh7IC4uLl9mb3JtU3RhdGUgfSk7XG4gICAgICAgICAgICBpZiAoX29wdGlvbnMucmVzb2x2ZXIpIHtcbiAgICAgICAgICAgICAgICBjb25zdCByZXNldENhbGxJZCA9IF9yZXNldENhbGxJZDtcbiAgICAgICAgICAgICAgICBjb25zdCB7IGVycm9ycyB9ID0gYXdhaXQgX3J1blNjaGVtYShbbmFtZV0pO1xuICAgICAgICAgICAgICAgIGlmIChyZXNldENhbGxJZCAhPT0gX3Jlc2V0Q2FsbElkKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgX3VwZGF0ZUlzVmFsaWRhdGluZyhbbmFtZV0pO1xuICAgICAgICAgICAgICAgIF91cGRhdGVJc0ZpZWxkVmFsdWVVcGRhdGVkKGZpZWxkVmFsdWUpO1xuICAgICAgICAgICAgICAgIGlmICghaXNGaWVsZFZhbHVlVXBkYXRlZCkge1xuICAgICAgICAgICAgICAgICAgICAhaXNFbXB0eU9iamVjdChmaWVsZFN0YXRlKSAmJiBfc3ViamVjdHMuc3RhdGUubmV4dChmaWVsZFN0YXRlKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25zdCBwcmV2aW91c0Vycm9yTG9va3VwUmVzdWx0ID0gc2NoZW1hRXJyb3JMb29rdXAoX2Zvcm1TdGF0ZS5lcnJvcnMsIF9maWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGVycm9yTG9va3VwUmVzdWx0ID0gc2NoZW1hRXJyb3JMb29rdXAoZXJyb3JzLCBfZmllbGRzLCBwcmV2aW91c0Vycm9yTG9va3VwUmVzdWx0Lm5hbWUgfHwgbmFtZSk7XG4gICAgICAgICAgICAgICAgZXJyb3IgPSBlcnJvckxvb2t1cFJlc3VsdC5lcnJvcjtcbiAgICAgICAgICAgICAgICBuYW1lID0gZXJyb3JMb29rdXBSZXN1bHQubmFtZTtcbiAgICAgICAgICAgICAgICBpc1ZhbGlkID0gaXNFbXB0eU9iamVjdChlcnJvcnMpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVzZXRDYWxsSWQgPSBfcmVzZXRDYWxsSWQ7XG4gICAgICAgICAgICAgICAgY29uc3Qgc2V0VmFsaWRDYWxsSWQgPSArK19zZXRWYWxpZENhbGxJZDtcbiAgICAgICAgICAgICAgICBfdXBkYXRlSXNWYWxpZGF0aW5nKFtuYW1lXSwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgZXJyb3IgPSAoYXdhaXQgdmFsaWRhdGVGaWVsZChmaWVsZCwgX25hbWVzLmRpc2FibGVkLCBfZm9ybVZhbHVlcywgc2hvdWxkRGlzcGxheUFsbEFzc29jaWF0ZWRFcnJvcnMsIF9vcHRpb25zLnNob3VsZFVzZU5hdGl2ZVZhbGlkYXRpb24pKVtuYW1lXTtcbiAgICAgICAgICAgICAgICBpZiAocmVzZXRDYWxsSWQgIT09IF9yZXNldENhbGxJZCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIF91cGRhdGVJc1ZhbGlkYXRpbmcoW25hbWVdKTtcbiAgICAgICAgICAgICAgICBfdXBkYXRlSXNGaWVsZFZhbHVlVXBkYXRlZChmaWVsZFZhbHVlKTtcbiAgICAgICAgICAgICAgICBpZiAoaXNGaWVsZFZhbHVlVXBkYXRlZCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzVmFsaWQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChfaXNUcmFja2VkKCdpc1ZhbGlkJykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzVmFsaWQgPSBhd2FpdCBleGVjdXRlQnVpbHRJblZhbGlkYXRpb24oe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpZWxkczogX2ZpZWxkcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbmx5Q2hlY2tWYWxpZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBuYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV2ZW50VHlwZTogZXZlbnQudHlwZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc2V0Q2FsbElkICE9PSBfcmVzZXRDYWxsSWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBfdXBkYXRlSXNGaWVsZFZhbHVlVXBkYXRlZChmaWVsZFZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzZXRWYWxpZENhbGxJZCAhPT0gX3NldFZhbGlkQ2FsbElkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNWYWxpZCA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChpc0ZpZWxkVmFsdWVVcGRhdGVkKSB7XG4gICAgICAgICAgICAgICAgZmllbGQuX2YuZGVwcyAmJlxuICAgICAgICAgICAgICAgICAgICAoIUFycmF5LmlzQXJyYXkoZmllbGQuX2YuZGVwcykgfHwgZmllbGQuX2YuZGVwcy5sZW5ndGggPiAwKSAmJlxuICAgICAgICAgICAgICAgICAgICB0cmlnZ2VyKGZpZWxkLl9mLmRlcHMpO1xuICAgICAgICAgICAgICAgIHNob3VsZFJlbmRlckJ5RXJyb3IobmFtZSwgaXNWYWxpZCwgZXJyb3IsIGZpZWxkU3RhdGUpO1xuICAgICAgICAgICAgICAgIHNob3VsZEZsdXNoRXJyb3IgJiZcbiAgICAgICAgICAgICAgICAgICAgT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKGRlbGF5RXJyb3JDYWxsYmFja3MsIG5hbWUpICYmXG4gICAgICAgICAgICAgICAgICAgIGRlbGF5RXJyb3JDYWxsYmFja3NbbmFtZV0oMCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IF9mb2N1c0lucHV0ID0gKHJlZiwga2V5KSA9PiB7XG4gICAgICAgIGlmIChnZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIGtleSkgJiYgcmVmLmZvY3VzKSB7XG4gICAgICAgICAgICByZWYuZm9jdXMoKTtcbiAgICAgICAgICAgIHJldHVybiAxO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybjtcbiAgICB9O1xuICAgIGNvbnN0IHRyaWdnZXIgPSBhc3luYyAobmFtZSwgb3B0aW9ucyA9IHt9KSA9PiB7XG4gICAgICAgIF9zdGF0ZS5rZWVwSXNWYWxpZCA9IGZhbHNlO1xuICAgICAgICBsZXQgaXNWYWxpZDtcbiAgICAgICAgbGV0IHZhbGlkYXRpb25SZXN1bHQ7XG4gICAgICAgIGNvbnN0IGZpZWxkTmFtZXMgPSBjb252ZXJ0VG9BcnJheVBheWxvYWQobmFtZSk7XG4gICAgICAgIGNvbnN0IHJlc2V0Q2FsbElkID0gX3Jlc2V0Q2FsbElkO1xuICAgICAgICBpZiAoX29wdGlvbnMucmVzb2x2ZXIpIHtcbiAgICAgICAgICAgIGNvbnN0IGVycm9ycyA9IGF3YWl0IGV4ZWN1dGVTY2hlbWFBbmRVcGRhdGVTdGF0ZShpc1VuZGVmaW5lZChuYW1lKSA/IG5hbWUgOiBmaWVsZE5hbWVzKTtcbiAgICAgICAgICAgIGlzVmFsaWQgPSBpc0VtcHR5T2JqZWN0KGVycm9ycyk7XG4gICAgICAgICAgICB2YWxpZGF0aW9uUmVzdWx0ID0gbmFtZVxuICAgICAgICAgICAgICAgID8gIWZpZWxkTmFtZXMuc29tZSgobmFtZSkgPT4gZ2V0KGVycm9ycywgbmFtZSkpXG4gICAgICAgICAgICAgICAgOiBpc1ZhbGlkO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG5hbWUpIHtcbiAgICAgICAgICAgIHZhbGlkYXRpb25SZXN1bHQgPSAoYXdhaXQgUHJvbWlzZS5hbGwoZmllbGROYW1lcy5tYXAoYXN5bmMgKGZpZWxkTmFtZSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KF9maWVsZHMsIGZpZWxkTmFtZSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGF3YWl0IGV4ZWN1dGVCdWlsdEluVmFsaWRhdGlvbih7XG4gICAgICAgICAgICAgICAgICAgIGZpZWxkczogZmllbGQgJiYgZmllbGQuX2YgPyB7IFtmaWVsZE5hbWVdOiBmaWVsZCB9IDogZmllbGQsXG4gICAgICAgICAgICAgICAgICAgIGV2ZW50VHlwZTogRVZFTlRTLlRSSUdHRVIsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KSkpLmV2ZXJ5KEJvb2xlYW4pO1xuICAgICAgICAgICAgISghdmFsaWRhdGlvblJlc3VsdCAmJiAhX2Zvcm1TdGF0ZS5pc1ZhbGlkKSAmJiBfc2V0VmFsaWQoKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHZhbGlkYXRpb25SZXN1bHQgPSBpc1ZhbGlkID0gYXdhaXQgZXhlY3V0ZUJ1aWx0SW5WYWxpZGF0aW9uKHtcbiAgICAgICAgICAgICAgICBmaWVsZHM6IF9maWVsZHMsXG4gICAgICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgICAgICBldmVudFR5cGU6IEVWRU5UUy5UUklHR0VSLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHJlc2V0Q2FsbElkICE9PSBfcmVzZXRDYWxsSWQpIHtcbiAgICAgICAgICAgIHJldHVybiB2YWxpZGF0aW9uUmVzdWx0O1xuICAgICAgICB9XG4gICAgICAgIGlmIChvcHRpb25zLmRlbGF5RXJyb3IgJiYgX29wdGlvbnMuZGVsYXlFcnJvciAmJiBpc1N0cmluZyhuYW1lKSkge1xuICAgICAgICAgICAgY29uc3QgZXJyb3IgPSBnZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpO1xuICAgICAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgdW5zZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpO1xuICAgICAgICAgICAgICAgIGRlbGF5RXJyb3JDYWxsYmFja3NbbmFtZV0gPSBkZWJvdW5jZShuYW1lLCAoKSA9PiB1cGRhdGVFcnJvcnMobmFtZSwgZXJyb3IpKTtcbiAgICAgICAgICAgICAgICBkZWxheUVycm9yQ2FsbGJhY2tzW25hbWVdKF9vcHRpb25zLmRlbGF5RXJyb3IpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgY2FuY2VsRGVsYXllZEVycm9yKG5hbWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChvcHRpb25zLnNob3VsZFRvdWNoKSB7XG4gICAgICAgICAgICBjb25zdCB0b3VjaEZpZWxkID0gKGZpZWxkTmFtZSkgPT4ge1xuICAgICAgICAgICAgICAgICFfbmFtZXMuYXJyYXkuaGFzKGZpZWxkTmFtZSkgJiZcbiAgICAgICAgICAgICAgICAgICAgc2V0KF9mb3JtU3RhdGUudG91Y2hlZEZpZWxkcywgZmllbGROYW1lLCB0cnVlKTtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGZpZWxkTmFtZSBvZiBuYW1lID8gZmllbGROYW1lcyA6IF9uYW1lcy5tb3VudCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KF9maWVsZHMsIGZpZWxkTmFtZSk7XG4gICAgICAgICAgICAgICAgaXNPYmplY3QoZmllbGQpIHx8IEFycmF5LmlzQXJyYXkoZmllbGQpXG4gICAgICAgICAgICAgICAgICAgID8gaXRlcmF0ZUZpZWxkc0J5QWN0aW9uKF9maWVsZHMsIChfLCBrZXkpID0+IHRvdWNoRmllbGQoa2V5KSwgW1xuICAgICAgICAgICAgICAgICAgICAgICAgZmllbGROYW1lLFxuICAgICAgICAgICAgICAgICAgICBdKVxuICAgICAgICAgICAgICAgICAgICA6IHRvdWNoRmllbGQoZmllbGROYW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBfZm9ybVN0YXRlLmVycm9ycyA9IHsgLi4uX2Zvcm1TdGF0ZS5lcnJvcnMgfTtcbiAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgLi4uKCFpc1N0cmluZyhuYW1lKSB8fFxuICAgICAgICAgICAgICAgIChfaXNUcmFja2VkKCdpc1ZhbGlkJykgJiYgaXNWYWxpZCAhPT0gX2Zvcm1TdGF0ZS5pc1ZhbGlkKVxuICAgICAgICAgICAgICAgID8ge31cbiAgICAgICAgICAgICAgICA6IHsgbmFtZSB9KSxcbiAgICAgICAgICAgIC4uLihfb3B0aW9ucy5yZXNvbHZlciB8fCAhbmFtZSA/IHsgaXNWYWxpZCB9IDoge30pLFxuICAgICAgICAgICAgLi4uKG9wdGlvbnMuc2hvdWxkVG91Y2ggJiYgX2lzVHJhY2tlZCgndG91Y2hlZEZpZWxkcycpXG4gICAgICAgICAgICAgICAgPyB7IHRvdWNoZWRGaWVsZHM6IF9mb3JtU3RhdGUudG91Y2hlZEZpZWxkcyB9XG4gICAgICAgICAgICAgICAgOiB7fSksXG4gICAgICAgICAgICBlcnJvcnM6IF9mb3JtU3RhdGUuZXJyb3JzLFxuICAgICAgICB9KTtcbiAgICAgICAgb3B0aW9ucy5zaG91bGRGb2N1cyAmJlxuICAgICAgICAgICAgIXZhbGlkYXRpb25SZXN1bHQgJiZcbiAgICAgICAgICAgIGl0ZXJhdGVGaWVsZHNCeUFjdGlvbihfZmllbGRzLCBfZm9jdXNJbnB1dCwgbmFtZSA/IGZpZWxkTmFtZXMgOiBfbmFtZXMubW91bnQpO1xuICAgICAgICByZXR1cm4gdmFsaWRhdGlvblJlc3VsdDtcbiAgICB9O1xuICAgIGNvbnN0IGdldFZhbHVlcyA9ICgoZmllbGROYW1lcywgY29uZmlnKSA9PiB7XG4gICAgICAgIGxldCB2YWx1ZXMgPSBpc1VuZGVmaW5lZChmaWVsZE5hbWVzKSAmJiAhY29uZmlnXG4gICAgICAgICAgICA/IHsgLi4uKF9zdGF0ZS5tb3VudCA/IF9mb3JtVmFsdWVzIDogX2RlZmF1bHRWYWx1ZXMpIH1cbiAgICAgICAgICAgIDogX3N0YXRlLm1vdW50XG4gICAgICAgICAgICAgICAgPyBfZm9ybVZhbHVlc1xuICAgICAgICAgICAgICAgIDogX2RlZmF1bHRWYWx1ZXM7XG4gICAgICAgIGlmIChjb25maWcpIHtcbiAgICAgICAgICAgIHZhbHVlcyA9IGV4dHJhY3RGb3JtVmFsdWVzKGNvbmZpZy5kaXJ0eUZpZWxkcyA/IF9mb3JtU3RhdGUuZGlydHlGaWVsZHMgOiBfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHMsIHZhbHVlcyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGlzVW5kZWZpbmVkKGZpZWxkTmFtZXMpXG4gICAgICAgICAgICA/IHZhbHVlc1xuICAgICAgICAgICAgOiBpc1N0cmluZyhmaWVsZE5hbWVzKVxuICAgICAgICAgICAgICAgID8gZ2V0KHZhbHVlcywgZmllbGROYW1lcylcbiAgICAgICAgICAgICAgICA6IGZpZWxkTmFtZXMubWFwKChuYW1lKSA9PiBnZXQodmFsdWVzLCBuYW1lKSk7XG4gICAgfSk7XG4gICAgY29uc3QgZ2V0RXJyb3JzID0gKChmaWVsZE5hbWVzKSA9PiBpc1VuZGVmaW5lZChmaWVsZE5hbWVzKVxuICAgICAgICA/IHsgLi4uX2Zvcm1TdGF0ZS5lcnJvcnMgfVxuICAgICAgICA6IGlzU3RyaW5nKGZpZWxkTmFtZXMpXG4gICAgICAgICAgICA/IGdldChfZm9ybVN0YXRlLmVycm9ycywgZmllbGROYW1lcylcbiAgICAgICAgICAgIDogZmllbGROYW1lcy5tYXAoKG5hbWUpID0+IGdldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSkpKTtcbiAgICBjb25zdCBnZXRGaWVsZFN0YXRlID0gKG5hbWUsIGZvcm1TdGF0ZSkgPT4ge1xuICAgICAgICBjb25zdCB0YXJnZXRGb3JtU3RhdGUgPSBmb3JtU3RhdGUgfHwgX2Zvcm1TdGF0ZTtcbiAgICAgICAgY29uc3QgZXJyb3IgPSBnZXQodGFyZ2V0Rm9ybVN0YXRlLmVycm9ycywgbmFtZSk7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBpbnZhbGlkOiAhIWVycm9yLFxuICAgICAgICAgICAgaXNEaXJ0eTogISFnZXQodGFyZ2V0Rm9ybVN0YXRlLmRpcnR5RmllbGRzLCBuYW1lKSxcbiAgICAgICAgICAgIGVycm9yLFxuICAgICAgICAgICAgaXNWYWxpZGF0aW5nOiAhIWdldCh0YXJnZXRGb3JtU3RhdGUudmFsaWRhdGluZ0ZpZWxkcywgbmFtZSksXG4gICAgICAgICAgICBpc1RvdWNoZWQ6ICEhZ2V0KHRhcmdldEZvcm1TdGF0ZS50b3VjaGVkRmllbGRzLCBuYW1lKSxcbiAgICAgICAgfTtcbiAgICB9O1xuICAgIGNvbnN0IGNsZWFyRXJyb3JzID0gKG5hbWUpID0+IHtcbiAgICAgICAgY29uc3QgbmFtZXMgPSBuYW1lID8gY29udmVydFRvQXJyYXlQYXlsb2FkKG5hbWUpIDogdW5kZWZpbmVkO1xuICAgICAgICBpZiAobmFtZXMpIHtcbiAgICAgICAgICAgIG5hbWVzLmZvckVhY2goKGlucHV0TmFtZSkgPT4ge1xuICAgICAgICAgICAgICAgIGNhbmNlbERlbGF5ZWRFcnJvclRyZWUoaW5wdXROYW1lKTtcbiAgICAgICAgICAgICAgICB1bnNldChfZm9ybVN0YXRlLmVycm9ycywgaW5wdXROYW1lKTtcbiAgICAgICAgICAgICAgICBfZm9ybVN0YXRlLmVycm9ycyA9IHsgLi4uX2Zvcm1TdGF0ZS5lcnJvcnMgfTtcbiAgICAgICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgICAgIG5hbWU6IGlucHV0TmFtZSxcbiAgICAgICAgICAgICAgICAgICAgZXJyb3JzOiBfZm9ybVN0YXRlLmVycm9ycyxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgT2JqZWN0LmtleXMoZGVsYXlFcnJvckNhbGxiYWNrcykuZm9yRWFjaChjYW5jZWxEZWxheWVkRXJyb3IpO1xuICAgICAgICAgICAgX2Zvcm1TdGF0ZS5lcnJvcnMgPSB7fTtcbiAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICBlcnJvcnM6IF9mb3JtU3RhdGUuZXJyb3JzLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IHNldEVycm9yID0gKG5hbWUsIGVycm9yLCBvcHRpb25zKSA9PiB7XG4gICAgICAgIHZhciBfYTtcbiAgICAgICAgY2FuY2VsRGVsYXllZEVycm9yVHJlZShuYW1lKTtcbiAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgbmFtZSwgeyBfZjoge30gfSk7XG4gICAgICAgIGNvbnN0IHJlZiA9IGZpZWxkLl9mICYmIGZpZWxkLl9mLnJlZjtcbiAgICAgICAgY29uc3QgY3VycmVudEVycm9yID0gZ2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lKSB8fCB7fTtcbiAgICAgICAgY29uc3QgeyByZWY6IGN1cnJlbnRSZWYsIG1lc3NhZ2UsIHR5cGUsIHR5cGVzLCAuLi5yZXN0T2ZFcnJvclRyZWUgfSA9IGN1cnJlbnRFcnJvcjtcbiAgICAgICAgc2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lLCB7XG4gICAgICAgICAgICAuLi5yZXN0T2ZFcnJvclRyZWUsXG4gICAgICAgICAgICAuLi5lcnJvcixcbiAgICAgICAgICAgIHJlZixcbiAgICAgICAgfSk7XG4gICAgICAgIF9mb3JtU3RhdGUuZXJyb3JzID0geyAuLi5fZm9ybVN0YXRlLmVycm9ycyB9O1xuICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgZXJyb3JzOiBfZm9ybVN0YXRlLmVycm9ycyxcbiAgICAgICAgICAgIGlzVmFsaWQ6IGZhbHNlLFxuICAgICAgICB9KTtcbiAgICAgICAgaWYgKG9wdGlvbnMgJiYgb3B0aW9ucy5zaG91bGRGb2N1cykge1xuICAgICAgICAgICAgY29uc3QgZmllbGRSZWYgPSAoKF9hID0gZmllbGQuX2YpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5yZWZzKVxuICAgICAgICAgICAgICAgID8gZmllbGQuX2YucmVmcy5maW5kKChyZWYpID0+ICFyZWYuZGlzYWJsZWQpIHx8IGZpZWxkLl9mLnJlZnNbMF1cbiAgICAgICAgICAgICAgICA6IHJlZjtcbiAgICAgICAgICAgIGZpZWxkUmVmICYmIGZpZWxkUmVmLmZvY3VzICYmIGZpZWxkUmVmLmZvY3VzKCk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IHdhdGNoID0gKG5hbWUsIGRlZmF1bHRWYWx1ZSkgPT4ge1xuICAgICAgICBpZiAoaXNGdW5jdGlvbihuYW1lKSkge1xuICAgICAgICAgICAgY29uc3QgdmFsdWVzU3Vic2NyaWJlciA9IHt9O1xuICAgICAgICAgICAgX3ZhbHVlc1N1YnNjcmliZXJzLmFkZCh2YWx1ZXNTdWJzY3JpYmVyKTtcbiAgICAgICAgICAgIGNvbnN0IHsgdW5zdWJzY3JpYmUgfSA9IF9zdWJqZWN0cy5zdGF0ZS5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgICAgIG5leHQ6IChwYXlsb2FkKSA9PiAndmFsdWVzJyBpbiBwYXlsb2FkICYmXG4gICAgICAgICAgICAgICAgICAgIG5hbWUocGF5bG9hZC52YWx1ZXMgfHwgX2dldFdhdGNoKHVuZGVmaW5lZCwgZGVmYXVsdFZhbHVlKSwgcGF5bG9hZCksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgdW5zdWJzY3JpYmU6ICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgX3ZhbHVlc1N1YnNjcmliZXJzLmRlbGV0ZSh2YWx1ZXNTdWJzY3JpYmVyKTtcbiAgICAgICAgICAgICAgICAgICAgdW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gX2dldFdhdGNoKG5hbWUsIGRlZmF1bHRWYWx1ZSwgdHJ1ZSk7XG4gICAgfTtcbiAgICBjb25zdCBfc3Vic2NyaWJlID0gKHByb3BzKSA9PiB7XG4gICAgICAgIGNvbnN0IHZhbHVlc1N1YnNjcmliZXIgPSB7IG5hbWU6IHByb3BzLm5hbWUsIGV4YWN0OiBwcm9wcy5leGFjdCB9O1xuICAgICAgICBwcm9wcy5mb3JtU3RhdGUgJiZcbiAgICAgICAgICAgIHByb3BzLmZvcm1TdGF0ZS52YWx1ZXMgJiZcbiAgICAgICAgICAgIF92YWx1ZXNTdWJzY3JpYmVycy5hZGQodmFsdWVzU3Vic2NyaWJlcik7XG4gICAgICAgIGNvbnN0IHsgdW5zdWJzY3JpYmUgfSA9IF9zdWJqZWN0cy5zdGF0ZS5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgbmV4dDogKGZvcm1TdGF0ZSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChzaG91bGRTdWJzY3JpYmVCeU5hbWUocHJvcHMubmFtZSwgZm9ybVN0YXRlLm5hbWUsIHByb3BzLmV4YWN0KSAmJlxuICAgICAgICAgICAgICAgICAgICBzaG91bGRSZW5kZXJGb3JtU3RhdGUoZm9ybVN0YXRlLCBwcm9wcy5mb3JtU3RhdGUgfHwgX3Byb3h5Rm9ybVN0YXRlLCBwcm9wcy5yZVJlbmRlclJvb3QpKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbHVlcyA9IGZvcm1TdGF0ZS52YWx1ZXMgfHwgeyAuLi5fZm9ybVZhbHVlcyB9O1xuICAgICAgICAgICAgICAgICAgICBwcm9wcy5jYWxsYmFjayh7XG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5fZm9ybVN0YXRlLFxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybVN0YXRlLFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdGluZ0ZpZWxkczogX2Zvcm1TdGF0ZS52YWxpZGF0aW5nRmllbGRzLFxuICAgICAgICAgICAgICAgICAgICAgICAgaXNWYWxpZGF0aW5nOiBfZm9ybVN0YXRlLmlzVmFsaWRhdGluZyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlcyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZXM6IF9kZWZhdWx0VmFsdWVzLFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgICAgIF92YWx1ZXNTdWJzY3JpYmVycy5kZWxldGUodmFsdWVzU3Vic2NyaWJlcik7XG4gICAgICAgICAgICB1bnN1YnNjcmliZSgpO1xuICAgICAgICB9O1xuICAgIH07XG4gICAgY29uc3Qgc3Vic2NyaWJlID0gKHByb3BzKSA9PiB7XG4gICAgICAgIF9zdGF0ZS5tb3VudCA9IHRydWU7XG4gICAgICAgIGNvbnN0IHRyYWNrZWRLZXlzID0gT2JqZWN0LmtleXMocHJvcHMuZm9ybVN0YXRlIHx8IHt9KS5maWx0ZXIoKGtleSkgPT4gcHJvcHMuZm9ybVN0YXRlICYmIHByb3BzLmZvcm1TdGF0ZVtrZXldKTtcbiAgICAgICAgZm9yIChjb25zdCBrZXkgb2YgdHJhY2tlZEtleXMpIHtcbiAgICAgICAgICAgIF9wcm94eVN1YnNjcmliZUZvcm1TdGF0ZVtrZXldID0gKF9wcm94eVN1YnNjcmliZUZvcm1TdGF0ZVtrZXldIHx8IDApICsgMTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB1bnN1YnNjcmliZSA9IF9zdWJzY3JpYmUoe1xuICAgICAgICAgICAgLi4ucHJvcHMsXG4gICAgICAgICAgICBmb3JtU3RhdGU6IHtcbiAgICAgICAgICAgICAgICAuLi5kZWZhdWx0UHJveHlGb3JtU3RhdGUsXG4gICAgICAgICAgICAgICAgLi4ucHJvcHMuZm9ybVN0YXRlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICAvLyBzcGxpY2UoMCkgZW1wdGllcyB0aGUgbGlzdCwgc28gYSByZXBlYXRlZCB1bnN1YnNjcmliZSByZWxlYXNlcyBub3RoaW5nXG4gICAgICAgICAgICBmb3IgKGNvbnN0IGtleSBvZiB0cmFja2VkS2V5cy5zcGxpY2UoMCkpIHtcbiAgICAgICAgICAgICAgICBfcHJveHlTdWJzY3JpYmVGb3JtU3RhdGVba2V5XS0tO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdW5zdWJzY3JpYmUoKTtcbiAgICAgICAgfTtcbiAgICB9O1xuICAgIGNvbnN0IHVucmVnaXN0ZXIgPSAobmFtZSwgb3B0aW9ucyA9IHt9KSA9PiB7XG4gICAgICAgIGNvbnN0IHJlcXVlc3RlZE5hbWVzID0gbmFtZVxuICAgICAgICAgICAgPyBjb252ZXJ0VG9BcnJheVBheWxvYWQobmFtZSlcbiAgICAgICAgICAgIDogWy4uLl9uYW1lcy5tb3VudF07XG4gICAgICAgIGNvbnN0IGZpZWxkTmFtZXMgPSBuZXcgU2V0KHJlcXVlc3RlZE5hbWVzKTtcbiAgICAgICAgaWYgKG5hbWUpIHtcbiAgICAgICAgICAgIGZvciAoY29uc3QgZmllbGROYW1lIG9mIF9uYW1lcy5tb3VudCkge1xuICAgICAgICAgICAgICAgIGlmIChyZXF1ZXN0ZWROYW1lcy5zb21lKChwYXJlbnQpID0+IGZpZWxkTmFtZS5zdGFydHNXaXRoKGAke3BhcmVudH0uYCkpKSB7XG4gICAgICAgICAgICAgICAgICAgIGZpZWxkTmFtZXMuYWRkKGZpZWxkTmFtZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmICghb3B0aW9ucy5rZWVwSXNWYWxpZGF0aW5nKSB7XG4gICAgICAgICAgICBfdXBkYXRlVmFsaWRhdGluZ0ZpZWxkcyhmaWVsZE5hbWVzKTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKGNvbnN0IGZpZWxkTmFtZSBvZiBmaWVsZE5hbWVzKSB7XG4gICAgICAgICAgICBfbmFtZXMubW91bnQuZGVsZXRlKGZpZWxkTmFtZSk7XG4gICAgICAgICAgICBfbmFtZXMuYXJyYXkuZGVsZXRlKGZpZWxkTmFtZSk7XG4gICAgICAgICAgICBfbmFtZXMuZGlzYWJsZWQuZGVsZXRlKGZpZWxkTmFtZSk7XG4gICAgICAgICAgICB1bnNldChfZmllbGRzLCBmaWVsZE5hbWUpO1xuICAgICAgICAgICAgIW9wdGlvbnMua2VlcFZhbHVlICYmIHVuc2V0KF9mb3JtVmFsdWVzLCBmaWVsZE5hbWUpO1xuICAgICAgICAgICAgaWYgKCFvcHRpb25zLmtlZXBFcnJvcikge1xuICAgICAgICAgICAgICAgIGNhbmNlbERlbGF5ZWRFcnJvclRyZWUoZmllbGROYW1lKTtcbiAgICAgICAgICAgICAgICB1bnNldChfZm9ybVN0YXRlLmVycm9ycywgZmllbGROYW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgICFvcHRpb25zLmtlZXBEaXJ0eSAmJiB1bnNldChfZm9ybVN0YXRlLmRpcnR5RmllbGRzLCBmaWVsZE5hbWUpO1xuICAgICAgICAgICAgIW9wdGlvbnMua2VlcFRvdWNoZWQgJiYgdW5zZXQoX2Zvcm1TdGF0ZS50b3VjaGVkRmllbGRzLCBmaWVsZE5hbWUpO1xuICAgICAgICAgICAgIV9vcHRpb25zLnNob3VsZFVucmVnaXN0ZXIgJiZcbiAgICAgICAgICAgICAgICAhb3B0aW9ucy5rZWVwRGVmYXVsdFZhbHVlICYmXG4gICAgICAgICAgICAgICAgdW5zZXQoX2RlZmF1bHRWYWx1ZXMsIGZpZWxkTmFtZSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFvcHRpb25zLmtlZXBFcnJvcikge1xuICAgICAgICAgICAgX2Zvcm1TdGF0ZS5lcnJvcnMgPSB7IC4uLl9mb3JtU3RhdGUuZXJyb3JzIH07XG4gICAgICAgIH1cbiAgICAgICAgX3ZhbHVlc1N1YnNjcmliZXJzLnNpemUgJiZcbiAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICB2YWx1ZXM6IGNsb25lT2JqZWN0KF9mb3JtVmFsdWVzKSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAuLi5fZm9ybVN0YXRlLFxuICAgICAgICAgICAgLi4uKG9wdGlvbnMua2VlcERpcnR5ID8ge30gOiB7IGlzRGlydHk6IF9nZXREaXJ0eSgpIH0pLFxuICAgICAgICAgICAgLi4uKG9wdGlvbnMua2VlcElzVmFsaWRhdGluZ1xuICAgICAgICAgICAgICAgID8ge31cbiAgICAgICAgICAgICAgICA6IHsgaXNWYWxpZGF0aW5nOiAhaXNFbXB0eU9iamVjdChfZm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMpIH0pLFxuICAgICAgICB9KTtcbiAgICAgICAgIW9wdGlvbnMua2VlcElzVmFsaWQgJiYgX3NldFZhbGlkKCk7XG4gICAgfTtcbiAgICBjb25zdCBfc2V0RGlzYWJsZWRGaWVsZCA9ICh7IGRpc2FibGVkLCBuYW1lLCB9KSA9PiB7XG4gICAgICAgIGlmICgoaXNCb29sZWFuKGRpc2FibGVkKSAmJiBfc3RhdGUubW91bnQpIHx8XG4gICAgICAgICAgICAhIWRpc2FibGVkIHx8XG4gICAgICAgICAgICBfbmFtZXMuZGlzYWJsZWQuaGFzKG5hbWUpKSB7XG4gICAgICAgICAgICBjb25zdCB3YXNEaXNhYmxlZCA9IF9uYW1lcy5kaXNhYmxlZC5oYXMobmFtZSk7XG4gICAgICAgICAgICBjb25zdCBpc0Rpc2FibGVkID0gISFkaXNhYmxlZDtcbiAgICAgICAgICAgIGNvbnN0IGRpc2FibGVkU3RhdGVDaGFuZ2VkID0gd2FzRGlzYWJsZWQgIT09IGlzRGlzYWJsZWQ7XG4gICAgICAgICAgICBkaXNhYmxlZCA/IF9uYW1lcy5kaXNhYmxlZC5hZGQobmFtZSkgOiBfbmFtZXMuZGlzYWJsZWQuZGVsZXRlKG5hbWUpO1xuICAgICAgICAgICAgZGlzYWJsZWRTdGF0ZUNoYW5nZWQgJiYgX3N0YXRlLm1vdW50ICYmICFfc3RhdGUuYWN0aW9uICYmIF9zZXRWYWxpZCgpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCByZWdpc3RlciA9IChuYW1lLCBvcHRpb25zID0ge30pID0+IHtcbiAgICAgICAgbGV0IGZpZWxkID0gZ2V0KF9maWVsZHMsIG5hbWUpO1xuICAgICAgICBjb25zdCBkaXNhYmxlZElzRGVmaW5lZCA9IGlzQm9vbGVhbihvcHRpb25zLmRpc2FibGVkKSB8fCBpc0Jvb2xlYW4oX29wdGlvbnMuZGlzYWJsZWQpO1xuICAgICAgICBjb25zdCBzaG91bGRSZXZhbGlkYXRlUmVtb3VudCA9ICFfbmFtZXMucmVnaXN0ZXJOYW1lLmhhcyhuYW1lKSAmJiBmaWVsZCAmJiBmaWVsZC5fZiAmJiAhZmllbGQuX2YubW91bnQ7XG4gICAgICAgIGlmICghZmllbGQgfHwgIWZpZWxkLl9mKSB7XG4gICAgICAgICAgICBfcmVnaXN0ZXJDYWxsSWRzW25hbWVdID0gKytfcmVnaXN0ZXJDYWxsSWQ7XG4gICAgICAgIH1cbiAgICAgICAgc2V0KF9maWVsZHMsIG5hbWUsIHtcbiAgICAgICAgICAgIC4uLihmaWVsZCB8fCB7fSksXG4gICAgICAgICAgICBfZjoge1xuICAgICAgICAgICAgICAgIC4uLihmaWVsZCAmJiBmaWVsZC5fZiA/IGZpZWxkLl9mIDogeyByZWY6IHsgbmFtZSB9IH0pLFxuICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICAgICAgbW91bnQ6IHRydWUsXG4gICAgICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICBfbmFtZXMubW91bnQuYWRkKG5hbWUpO1xuICAgICAgICBpZiAoZmllbGQgJiYgZmllbGQuX2YpIHtcbiAgICAgICAgICAgIGNvbnN0IG5leHRGaWVsZCA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgIGZvciAoY29uc3QgcnVsZSBvZiBSRUdJU1RFUl9WQUxJREFUSU9OX1JVTEVTKSB7XG4gICAgICAgICAgICAgICAgaWYgKCEocnVsZSBpbiBvcHRpb25zKSkge1xuICAgICAgICAgICAgICAgICAgICBkZWxldGUgbmV4dEZpZWxkLl9mW3J1bGVdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoZmllbGQgJiYgIXNob3VsZFJldmFsaWRhdGVSZW1vdW50KSB7XG4gICAgICAgICAgICBfc2V0RGlzYWJsZWRGaWVsZCh7XG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ6IGlzQm9vbGVhbihvcHRpb25zLmRpc2FibGVkKVxuICAgICAgICAgICAgICAgICAgICA/IG9wdGlvbnMuZGlzYWJsZWRcbiAgICAgICAgICAgICAgICAgICAgOiBfb3B0aW9ucy5kaXNhYmxlZCxcbiAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB1cGRhdGVWYWxpZEFuZFZhbHVlKG5hbWUsIHRydWUsIG9wdGlvbnMudmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAuLi4oZGlzYWJsZWRJc0RlZmluZWRcbiAgICAgICAgICAgICAgICA/IHsgZGlzYWJsZWQ6IG9wdGlvbnMuZGlzYWJsZWQgfHwgX29wdGlvbnMuZGlzYWJsZWQgfVxuICAgICAgICAgICAgICAgIDoge30pLFxuICAgICAgICAgICAgLi4uKF9vcHRpb25zLnByb2dyZXNzaXZlXG4gICAgICAgICAgICAgICAgPyB7XG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOiAhIWdldFJ1bGVWYWx1ZShvcHRpb25zLnJlcXVpcmVkKSxcbiAgICAgICAgICAgICAgICAgICAgbWluOiBnZXRSdWxlVmFsdWUob3B0aW9ucy5taW4pLFxuICAgICAgICAgICAgICAgICAgICBtYXg6IGdldFJ1bGVWYWx1ZShvcHRpb25zLm1heCksXG4gICAgICAgICAgICAgICAgICAgIG1pbkxlbmd0aDogZ2V0UnVsZVZhbHVlKG9wdGlvbnMubWluTGVuZ3RoKSxcbiAgICAgICAgICAgICAgICAgICAgbWF4TGVuZ3RoOiBnZXRSdWxlVmFsdWUob3B0aW9ucy5tYXhMZW5ndGgpLFxuICAgICAgICAgICAgICAgICAgICBwYXR0ZXJuOiBnZXRSdWxlVmFsdWUob3B0aW9ucy5wYXR0ZXJuKSxcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgOiB7fSksXG4gICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgb25DaGFuZ2UsXG4gICAgICAgICAgICBvbkJsdXI6IG9uQ2hhbmdlLFxuICAgICAgICAgICAgcmVmOiAocmVmKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHJlZikge1xuICAgICAgICAgICAgICAgICAgICBfbmFtZXMucmVnaXN0ZXJOYW1lLmFkZChuYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgcmVnaXN0ZXIobmFtZSwgb3B0aW9ucyk7XG4gICAgICAgICAgICAgICAgICAgIF9uYW1lcy5yZWdpc3Rlck5hbWUuZGVsZXRlKG5hbWUpO1xuICAgICAgICAgICAgICAgICAgICBmaWVsZCA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZmllbGRSZWYgPSBpc1VuZGVmaW5lZChyZWYudmFsdWUpXG4gICAgICAgICAgICAgICAgICAgICAgICA/IHJlZi5xdWVyeVNlbGVjdG9yQWxsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyByZWYucXVlcnlTZWxlY3RvckFsbCgnaW5wdXQsc2VsZWN0LHRleHRhcmVhJylbMF0gfHwgcmVmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiByZWZcbiAgICAgICAgICAgICAgICAgICAgICAgIDogcmVmO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCByYWRpb09yQ2hlY2tib3ggPSBpc1JhZGlvT3JDaGVja2JveChmaWVsZFJlZik7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlZnMgPSBmaWVsZC5fZi5yZWZzIHx8IFtdO1xuICAgICAgICAgICAgICAgICAgICBpZiAocmFkaW9PckNoZWNrYm94XG4gICAgICAgICAgICAgICAgICAgICAgICA/IHJlZnMuZmluZCgob3B0aW9uKSA9PiBvcHRpb24gPT09IGZpZWxkUmVmKVxuICAgICAgICAgICAgICAgICAgICAgICAgOiBmaWVsZFJlZiA9PT0gZmllbGQuX2YucmVmKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbmV3RmllbGQgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5maWVsZC5fZixcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJhZGlvT3JDaGVja2JveCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgbmV3RmllbGQucmVmcyA9IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5yZWZzLmZpbHRlcihsaXZlKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWVsZFJlZixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi4oQXJyYXkuaXNBcnJheShnZXQoX2RlZmF1bHRWYWx1ZXMsIG5hbWUpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFt7fV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBbXSksXG4gICAgICAgICAgICAgICAgICAgICAgICBdO1xuICAgICAgICAgICAgICAgICAgICAgICAgbmV3RmllbGQucmVmID0geyB0eXBlOiBmaWVsZFJlZi50eXBlLCBuYW1lIH07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuZXdGaWVsZC5yZWYgPSBmaWVsZFJlZjtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZSBuZXdGaWVsZC5yZWZzO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHNldChfZmllbGRzLCBuYW1lLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBfZjogbmV3RmllbGQsXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB1cGRhdGVWYWxpZEFuZFZhbHVlKG5hbWUsIGZhbHNlLCB1bmRlZmluZWQsIGZpZWxkUmVmKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGZpZWxkID0gZ2V0KF9maWVsZHMsIG5hbWUsIHt9KTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGZpZWxkLl9mKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmaWVsZC5fZi5tb3VudCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIChfb3B0aW9ucy5zaG91bGRVbnJlZ2lzdGVyIHx8IG9wdGlvbnMuc2hvdWxkVW5yZWdpc3RlcikgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICEoaXNOYW1lSW5GaWVsZEFycmF5KF9uYW1lcy5hcnJheSwgbmFtZSkgJiYgX3N0YXRlLmFjdGlvbikgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIF9uYW1lcy51bk1vdW50LmFkZChuYW1lKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICB9O1xuICAgIH07XG4gICAgY29uc3QgX2ZvY3VzRXJyb3IgPSAoKSA9PiBfb3B0aW9ucy5zaG91bGRGb2N1c0Vycm9yICYmXG4gICAgICAgICFfb3B0aW9ucy5zaG91bGRVc2VOYXRpdmVWYWxpZGF0aW9uICYmXG4gICAgICAgIGl0ZXJhdGVGaWVsZHNCeUFjdGlvbihfZmllbGRzLCBfZm9jdXNJbnB1dCwgX25hbWVzLm1vdW50KTtcbiAgICBjb25zdCBfZGlzYWJsZUZvcm0gPSAoZGlzYWJsZWQpID0+IHtcbiAgICAgICAgaWYgKGlzQm9vbGVhbihkaXNhYmxlZCkpIHtcbiAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHsgZGlzYWJsZWQgfSk7XG4gICAgICAgICAgICBpdGVyYXRlRmllbGRzQnlBY3Rpb24oX2ZpZWxkcywgKHJlZiwgbmFtZSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRGaWVsZCA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICBpZiAoY3VycmVudEZpZWxkKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlZi5kaXNhYmxlZCA9IGN1cnJlbnRGaWVsZC5fZi5kaXNhYmxlZCB8fCBkaXNhYmxlZDtcbiAgICAgICAgICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoY3VycmVudEZpZWxkLl9mLnJlZnMpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50RmllbGQuX2YucmVmcy5mb3JFYWNoKChpbnB1dFJlZikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlucHV0UmVmLmRpc2FibGVkID0gY3VycmVudEZpZWxkLl9mLmRpc2FibGVkIHx8IGRpc2FibGVkO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LCAwKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgaGFuZGxlU3VibWl0ID0gKG9uVmFsaWQsIG9uSW52YWxpZCkgPT4gYXN5bmMgKGUpID0+IHtcbiAgICAgICAgbGV0IHJlc3VsdCA9IHVuZGVmaW5lZDtcbiAgICAgICAgbGV0IG9uVmFsaWRFcnJvciA9IHVuZGVmaW5lZDtcbiAgICAgICAgbGV0IG9uVmFsaWRGYWlsZWQgPSBmYWxzZTtcbiAgICAgICAgaWYgKGUpIHtcbiAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQgJiYgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgZS5wZXJzaXN0ICYmIGUucGVyc2lzdCgpO1xuICAgICAgICB9XG4gICAgICAgIGxldCBmaWVsZFZhbHVlcyA9IGNsb25lT2JqZWN0KF9mb3JtVmFsdWVzKTtcbiAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgaXNTdWJtaXR0aW5nOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgcmVzZXRDYWxsSWQgPSBfcmVzZXRDYWxsSWQ7XG4gICAgICAgIGNvbnN0IG9uU3VibWl0RXJyb3IgPSAoZXJyb3IpID0+IHtcbiAgICAgICAgICAgIGlmIChyZXNldENhbGxJZCA9PT0gX3Jlc2V0Q2FsbElkKSB7XG4gICAgICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoeyBpc1N1Ym1pdHRpbmc6IGZhbHNlIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgIH07XG4gICAgICAgIGlmIChfb3B0aW9ucy5yZXNvbHZlcikge1xuICAgICAgICAgICAgbGV0IHZhbGlkYXRpb25SZXN1bHQ7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIHZhbGlkYXRpb25SZXN1bHQgPSBhd2FpdCBfcnVuU2NoZW1hKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICBvblN1Ym1pdEVycm9yKGVycm9yKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IHsgZXJyb3JzLCB2YWx1ZXMgfSA9IHZhbGlkYXRpb25SZXN1bHQ7XG4gICAgICAgICAgICBpZiAocmVzZXRDYWxsSWQgIT09IF9yZXNldENhbGxJZCkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIF91cGRhdGVJc1ZhbGlkYXRpbmcoKTtcbiAgICAgICAgICAgIE9iamVjdC5rZXlzKGRlbGF5RXJyb3JDYWxsYmFja3MpLmZvckVhY2goY2FuY2VsRGVsYXllZEVycm9yKTtcbiAgICAgICAgICAgIF9mb3JtU3RhdGUuZXJyb3JzID0gZXJyb3JzO1xuICAgICAgICAgICAgZmllbGRWYWx1ZXMgPSBjbG9uZU9iamVjdCh2YWx1ZXMpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBhd2FpdCBleGVjdXRlQnVpbHRJblZhbGlkYXRpb24oe1xuICAgICAgICAgICAgICAgICAgICBmaWVsZHM6IF9maWVsZHMsXG4gICAgICAgICAgICAgICAgICAgIGV2ZW50VHlwZTogRVZFTlRTLlNVQk1JVCxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgIG9uU3VibWl0RXJyb3IoZXJyb3IpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHJlc2V0Q2FsbElkICE9PSBfcmVzZXRDYWxsSWQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB1bnNldChfZm9ybVN0YXRlLmVycm9ycywgUk9PVF9FUlJPUl9UWVBFKTtcbiAgICAgICAgICAgIF9mb3JtU3RhdGUuZXJyb3JzID0geyAuLi5fZm9ybVN0YXRlLmVycm9ycyB9O1xuICAgICAgICB9XG4gICAgICAgIGlmIChfbmFtZXMuZGlzYWJsZWQuc2l6ZSAmJlxuICAgICAgICAgICAgKGlzT2JqZWN0KGZpZWxkVmFsdWVzKSB8fCBBcnJheS5pc0FycmF5KGZpZWxkVmFsdWVzKSkpIHtcbiAgICAgICAgICAgIGZvciAoY29uc3QgbmFtZSBvZiBfbmFtZXMuZGlzYWJsZWQpIHtcbiAgICAgICAgICAgICAgICB1bnNldChmaWVsZFZhbHVlcywgbmFtZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzRW1wdHlPYmplY3QoX2Zvcm1TdGF0ZS5lcnJvcnMpKSB7XG4gICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgZXJyb3JzOiB7fSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICByZXN1bHQgPSBhd2FpdCBvblZhbGlkKGZpZWxkVmFsdWVzLCBlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgIG9uVmFsaWRGYWlsZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIG9uVmFsaWRFcnJvciA9IGVycm9yO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgaWYgKG9uSW52YWxpZCkge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IG9uSW52YWxpZCh7IC4uLl9mb3JtU3RhdGUuZXJyb3JzIH0sIGUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgb25TdWJtaXRFcnJvcihlcnJvcik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHJlc2V0Q2FsbElkID09PSBfcmVzZXRDYWxsSWQpIHtcbiAgICAgICAgICAgICAgICBfZm9jdXNFcnJvcigpO1xuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoX2ZvY3VzRXJyb3IpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChyZXNldENhbGxJZCA9PT0gX3Jlc2V0Q2FsbElkKSB7XG4gICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgaXNTdWJtaXR0ZWQ6IHRydWUsXG4gICAgICAgICAgICAgICAgaXNTdWJtaXR0aW5nOiBmYWxzZSxcbiAgICAgICAgICAgICAgICBpc1N1Ym1pdFN1Y2Nlc3NmdWw6IGlzRW1wdHlPYmplY3QoX2Zvcm1TdGF0ZS5lcnJvcnMpICYmICFvblZhbGlkRmFpbGVkLFxuICAgICAgICAgICAgICAgIHN1Ym1pdENvdW50OiBfZm9ybVN0YXRlLnN1Ym1pdENvdW50ICsgMSxcbiAgICAgICAgICAgICAgICBlcnJvcnM6IF9mb3JtU3RhdGUuZXJyb3JzLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG9uVmFsaWRGYWlsZWQpIHtcbiAgICAgICAgICAgIHRocm93IG9uVmFsaWRFcnJvcjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH07XG4gICAgY29uc3QgcmVzZXRGaWVsZCA9IChuYW1lLCBvcHRpb25zID0ge30pID0+IHtcbiAgICAgICAgaWYgKGdldChfZmllbGRzLCBuYW1lKSkge1xuICAgICAgICAgICAgX3VwZGF0ZVZhbGlkYXRpbmdGaWVsZHMoW25hbWVdKTtcbiAgICAgICAgICAgIGlmIChpc1VuZGVmaW5lZChvcHRpb25zLmRlZmF1bHRWYWx1ZSkpIHtcbiAgICAgICAgICAgICAgICBzZXRWYWx1ZShuYW1lLCBjbG9uZU9iamVjdChnZXQoX2RlZmF1bHRWYWx1ZXMsIG5hbWUpKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBzZXRWYWx1ZShuYW1lLCBvcHRpb25zLmRlZmF1bHRWYWx1ZSk7XG4gICAgICAgICAgICAgICAgX2RlZmF1bHRWYWx1ZXMgPSBjbG9uZU9iamVjdChfZGVmYXVsdFZhbHVlcyk7XG4gICAgICAgICAgICAgICAgc2V0KF9kZWZhdWx0VmFsdWVzLCBuYW1lLCBjbG9uZU9iamVjdChvcHRpb25zLmRlZmF1bHRWYWx1ZSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKCFvcHRpb25zLmtlZXBUb3VjaGVkKSB7XG4gICAgICAgICAgICAgICAgdW5zZXQoX2Zvcm1TdGF0ZS50b3VjaGVkRmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghb3B0aW9ucy5rZWVwRGlydHkpIHtcbiAgICAgICAgICAgICAgICB1bnNldChfZm9ybVN0YXRlLmRpcnR5RmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICBfZm9ybVN0YXRlLmlzRGlydHkgPSAhaXNVbmRlZmluZWQob3B0aW9ucy5kZWZhdWx0VmFsdWUpXG4gICAgICAgICAgICAgICAgICAgID8gX2dldERpcnR5KG5hbWUsIGNsb25lT2JqZWN0KGdldChfZGVmYXVsdFZhbHVlcywgbmFtZSkpKVxuICAgICAgICAgICAgICAgICAgICA6IF9nZXREaXJ0eSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKCFvcHRpb25zLmtlZXBFcnJvcikge1xuICAgICAgICAgICAgICAgIGNhbmNlbERlbGF5ZWRFcnJvclRyZWUobmFtZSk7XG4gICAgICAgICAgICAgICAgdW5zZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpO1xuICAgICAgICAgICAgICAgIF9mb3JtU3RhdGUuZXJyb3JzID0geyAuLi5fZm9ybVN0YXRlLmVycm9ycyB9O1xuICAgICAgICAgICAgICAgIF9zZXRWYWxpZCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgIC4uLl9mb3JtU3RhdGUsXG4gICAgICAgICAgICAgICAgaXNWYWxpZGF0aW5nOiAhaXNFbXB0eU9iamVjdChfZm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMpLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IF9yZXNldCA9IChmb3JtVmFsdWVzLCBrZWVwU3RhdGVPcHRpb25zID0ge30pID0+IHtcbiAgICAgICAgX3Jlc2V0Q2FsbElkKys7XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRWYWx1ZXMgPSBmb3JtVmFsdWVzID8gY2xvbmVPYmplY3QoZm9ybVZhbHVlcykgOiBfZGVmYXVsdFZhbHVlcztcbiAgICAgICAgY29uc3QgY2xvbmVVcGRhdGVkVmFsdWVzID0gY2xvbmVPYmplY3QodXBkYXRlZFZhbHVlcyk7XG4gICAgICAgIGNvbnN0IGlzRW1wdHlSZXNldFZhbHVlcyA9IGlzRW1wdHlPYmplY3QoZm9ybVZhbHVlcyk7XG4gICAgICAgIGNvbnN0IHZhbHVlcyA9IGNsb25lVXBkYXRlZFZhbHVlcztcbiAgICAgICAgY29uc3QgZmllbGRSZWZzID0gX2ZpZWxkcztcbiAgICAgICAgT2JqZWN0LmtleXMoZGVsYXlFcnJvckNhbGxiYWNrcykuZm9yRWFjaChjYW5jZWxEZWxheWVkRXJyb3IpO1xuICAgICAgICBpZiAoIWtlZXBTdGF0ZU9wdGlvbnMua2VlcERlZmF1bHRWYWx1ZXMpIHtcbiAgICAgICAgICAgIF9kZWZhdWx0VmFsdWVzID0gdXBkYXRlZFZhbHVlcztcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWtlZXBTdGF0ZU9wdGlvbnMua2VlcFZhbHVlcykge1xuICAgICAgICAgICAgaWYgKGtlZXBTdGF0ZU9wdGlvbnMua2VlcERpcnR5VmFsdWVzKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZmllbGRzVG9DaGVjayA9IG5ldyBTZXQoW1xuICAgICAgICAgICAgICAgICAgICAuLi5fbmFtZXMubW91bnQsXG4gICAgICAgICAgICAgICAgICAgIC4uLmNvbGxlY3REaXJ0eUZpZWxkTmFtZXMoZ2V0RGlydHlGaWVsZHMoX2RlZmF1bHRWYWx1ZXMsIF9mb3JtVmFsdWVzLCB1bmRlZmluZWQsIGZpZWxkUmVmcyksIF9mb3JtU3RhdGUuZGlydHlGaWVsZHMpLFxuICAgICAgICAgICAgICAgIF0pO1xuICAgICAgICAgICAgICAgIGZvciAoY29uc3QgZmllbGROYW1lIG9mIGZpZWxkc1RvQ2hlY2spIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNEaXJ0eSA9IGdldChfZm9ybVN0YXRlLmRpcnR5RmllbGRzLCBmaWVsZE5hbWUpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBleGlzdGluZ1ZhbHVlID0gZ2V0KF9mb3JtVmFsdWVzLCBmaWVsZE5hbWUpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXdWYWx1ZSA9IGdldCh2YWx1ZXMsIGZpZWxkTmFtZSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChpc0RpcnR5ICYmICFpc1VuZGVmaW5lZChleGlzdGluZ1ZhbHVlKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0KHZhbHVlcywgZmllbGROYW1lLCBleGlzdGluZ1ZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmICghaXNEaXJ0eSAmJiAhaXNVbmRlZmluZWQobmV3VmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRWYWx1ZShmaWVsZE5hbWUsIG5ld1ZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGlmIChpc1dlYiAmJiBpc1VuZGVmaW5lZChmb3JtVmFsdWVzKSkge1xuICAgICAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IG5hbWUgb2YgX25hbWVzLm1vdW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBmaWVsZCA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaWVsZCAmJiBmaWVsZC5fZikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGZpZWxkUmVmZXJlbmNlID0gQXJyYXkuaXNBcnJheShmaWVsZC5fZi5yZWZzKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGZpZWxkLl9mLnJlZnNbMF1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBmaWVsZC5fZi5yZWY7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGlzSFRNTEVsZW1lbnQoZmllbGRSZWZlcmVuY2UpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGZvcm0gPSBmaWVsZFJlZmVyZW5jZS5jbG9zZXN0KCdmb3JtJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmb3JtKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtLnJlc2V0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoa2VlcFN0YXRlT3B0aW9ucy5rZWVwRmllbGRzUmVmKSB7XG4gICAgICAgICAgICAgICAgICAgIGZvciAoY29uc3QgZmllbGROYW1lIG9mIF9uYW1lcy5tb3VudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0VmFsdWUoZmllbGROYW1lLCBnZXQodmFsdWVzLCBmaWVsZE5hbWUpKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgX2ZpZWxkcyA9IHt9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChfb3B0aW9ucy5zaG91bGRVbnJlZ2lzdGVyKSB7XG4gICAgICAgICAgICAgICAgX2Zvcm1WYWx1ZXMgPSBrZWVwU3RhdGVPcHRpb25zLmtlZXBEZWZhdWx0VmFsdWVzXG4gICAgICAgICAgICAgICAgICAgID8gY2xvbmVPYmplY3QoX2RlZmF1bHRWYWx1ZXMpXG4gICAgICAgICAgICAgICAgICAgIDoge307XG4gICAgICAgICAgICAgICAgaWYgKGtlZXBTdGF0ZU9wdGlvbnMua2VlcEZpZWxkc1JlZikge1xuICAgICAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IGZpZWxkTmFtZSBvZiBfbmFtZXMubW91bnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldChfZm9ybVZhbHVlcywgZmllbGROYW1lLCBnZXQodmFsdWVzLCBmaWVsZE5hbWUpKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIF9mb3JtVmFsdWVzID0gY2xvbmVPYmplY3QodmFsdWVzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIF9zdWJqZWN0cy5hcnJheS5uZXh0KHtcbiAgICAgICAgICAgICAgICB2YWx1ZXM6IHsgLi4udmFsdWVzIH0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICBuYW1lOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgdHlwZTogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgIHZhbHVlczogeyAuLi52YWx1ZXMgfSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIF9uYW1lcyA9IHtcbiAgICAgICAgICAgIG1vdW50OiBrZWVwU3RhdGVPcHRpb25zLmtlZXBEaXJ0eVZhbHVlcyB8fCBrZWVwU3RhdGVPcHRpb25zLmtlZXBGaWVsZHNSZWZcbiAgICAgICAgICAgICAgICA/IF9uYW1lcy5tb3VudFxuICAgICAgICAgICAgICAgIDogbmV3IFNldCgpLFxuICAgICAgICAgICAgdW5Nb3VudDogbmV3IFNldCgpLFxuICAgICAgICAgICAgYXJyYXk6IG5ldyBTZXQoKSxcbiAgICAgICAgICAgIHJlZ2lzdGVyTmFtZTogbmV3IFNldCgpLFxuICAgICAgICAgICAgZGlzYWJsZWQ6IGtlZXBTdGF0ZU9wdGlvbnMua2VlcFZhbHVlcyB8fFxuICAgICAgICAgICAgICAgIGtlZXBTdGF0ZU9wdGlvbnMua2VlcERpcnR5VmFsdWVzIHx8XG4gICAgICAgICAgICAgICAga2VlcFN0YXRlT3B0aW9ucy5rZWVwRmllbGRzUmVmXG4gICAgICAgICAgICAgICAgPyBuZXcgU2V0KFsuLi5fbmFtZXMuZGlzYWJsZWRdLmZpbHRlcigobmFtZSkgPT4gZ2V0KF9maWVsZHMsIG5hbWUpKSlcbiAgICAgICAgICAgICAgICA6IG5ldyBTZXQoKSxcbiAgICAgICAgICAgIHdhdGNoOiBuZXcgU2V0KCksXG4gICAgICAgICAgICB3YXRjaEFsbDogZmFsc2UsXG4gICAgICAgICAgICBmb2N1czogJycsXG4gICAgICAgIH07XG4gICAgICAgIF9zdGF0ZS5tb3VudCA9XG4gICAgICAgICAgICAhX3Byb3h5Rm9ybVN0YXRlLmlzVmFsaWQgfHxcbiAgICAgICAgICAgICAgICAhIWtlZXBTdGF0ZU9wdGlvbnMua2VlcElzVmFsaWQgfHxcbiAgICAgICAgICAgICAgICAhIWtlZXBTdGF0ZU9wdGlvbnMua2VlcERpcnR5VmFsdWVzIHx8XG4gICAgICAgICAgICAgICAgKCFfb3B0aW9ucy5zaG91bGRVbnJlZ2lzdGVyICYmICFpc0VtcHR5T2JqZWN0KHZhbHVlcykpO1xuICAgICAgICBfc3RhdGUud2F0Y2ggPSAhIV9vcHRpb25zLnNob3VsZFVucmVnaXN0ZXI7XG4gICAgICAgIF9zdGF0ZS5rZWVwSXNWYWxpZCA9ICEha2VlcFN0YXRlT3B0aW9ucy5rZWVwSXNWYWxpZDtcbiAgICAgICAgX3N0YXRlLmFjdGlvbiA9IGZhbHNlO1xuICAgICAgICBfc3RhdGUuYWN0aW9uQXJyYXlMZW5ndGhzLmNsZWFyKCk7XG4gICAgICAgIF9kaXJ0eUZpZWxkc1N0YWxlID0gZmFsc2U7XG4gICAgICAgIGlmICgha2VlcFN0YXRlT3B0aW9ucy5rZWVwRXJyb3JzKSB7XG4gICAgICAgICAgICBfZm9ybVN0YXRlLmVycm9ycyA9IHt9O1xuICAgICAgICB9XG4gICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgIHN1Ym1pdENvdW50OiBrZWVwU3RhdGVPcHRpb25zLmtlZXBTdWJtaXRDb3VudFxuICAgICAgICAgICAgICAgID8gX2Zvcm1TdGF0ZS5zdWJtaXRDb3VudFxuICAgICAgICAgICAgICAgIDogMCxcbiAgICAgICAgICAgIGlzRGlydHk6IGlzRW1wdHlSZXNldFZhbHVlc1xuICAgICAgICAgICAgICAgID8gZmFsc2VcbiAgICAgICAgICAgICAgICA6IGtlZXBTdGF0ZU9wdGlvbnMua2VlcERpcnR5XG4gICAgICAgICAgICAgICAgICAgID8gX2Zvcm1TdGF0ZS5pc0RpcnR5XG4gICAgICAgICAgICAgICAgICAgIDoga2VlcFN0YXRlT3B0aW9ucy5rZWVwVmFsdWVzXG4gICAgICAgICAgICAgICAgICAgICAgICA/IF9nZXREaXJ0eSgpXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICEhKGtlZXBTdGF0ZU9wdGlvbnMua2VlcERlZmF1bHRWYWx1ZXMgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtVmFsdWVzICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIWRlZXBFcXVhbChmb3JtVmFsdWVzLCBfZGVmYXVsdFZhbHVlcykpLFxuICAgICAgICAgICAgaXNTdWJtaXR0ZWQ6IGtlZXBTdGF0ZU9wdGlvbnMua2VlcElzU3VibWl0dGVkXG4gICAgICAgICAgICAgICAgPyBfZm9ybVN0YXRlLmlzU3VibWl0dGVkXG4gICAgICAgICAgICAgICAgOiBmYWxzZSxcbiAgICAgICAgICAgIGRpcnR5RmllbGRzOiAoaXNFbXB0eVJlc2V0VmFsdWVzXG4gICAgICAgICAgICAgICAgPyB7fVxuICAgICAgICAgICAgICAgIDoga2VlcFN0YXRlT3B0aW9ucy5rZWVwRGlydHlWYWx1ZXNcbiAgICAgICAgICAgICAgICAgICAgPyBrZWVwU3RhdGVPcHRpb25zLmtlZXBEZWZhdWx0VmFsdWVzICYmIF9mb3JtVmFsdWVzXG4gICAgICAgICAgICAgICAgICAgICAgICA/IGdldERpcnR5RmllbGRzKF9kZWZhdWx0VmFsdWVzLCBfZm9ybVZhbHVlcywgdW5kZWZpbmVkLCBmaWVsZFJlZnMpXG4gICAgICAgICAgICAgICAgICAgICAgICA6IF9mb3JtU3RhdGUuZGlydHlGaWVsZHNcbiAgICAgICAgICAgICAgICAgICAgOiBrZWVwU3RhdGVPcHRpb25zLmtlZXBEZWZhdWx0VmFsdWVzICYmIGZvcm1WYWx1ZXNcbiAgICAgICAgICAgICAgICAgICAgICAgID8gZ2V0RGlydHlGaWVsZHMoX2RlZmF1bHRWYWx1ZXMsIGZvcm1WYWx1ZXMsIHVuZGVmaW5lZCwgZmllbGRSZWZzKVxuICAgICAgICAgICAgICAgICAgICAgICAgOiBrZWVwU3RhdGVPcHRpb25zLmtlZXBEaXJ0eVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gX2Zvcm1TdGF0ZS5kaXJ0eUZpZWxkc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDoga2VlcFN0YXRlT3B0aW9ucy5rZWVwVmFsdWVzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gZ2V0RGlydHlGaWVsZHMoX2RlZmF1bHRWYWx1ZXMsIF9mb3JtVmFsdWVzLCB1bmRlZmluZWQsIGZpZWxkUmVmcylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiB7fSksXG4gICAgICAgICAgICB0b3VjaGVkRmllbGRzOiBrZWVwU3RhdGVPcHRpb25zLmtlZXBUb3VjaGVkXG4gICAgICAgICAgICAgICAgPyBfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHNcbiAgICAgICAgICAgICAgICA6IHt9LFxuICAgICAgICAgICAgLi4uKCFrZWVwU3RhdGVPcHRpb25zLmtlZXBJc1ZhbGlkYXRpbmcgJiZcbiAgICAgICAgICAgICAgICAoX2Zvcm1TdGF0ZS5pc1ZhbGlkYXRpbmcgfHwgIWlzRW1wdHlPYmplY3QoX2Zvcm1TdGF0ZS52YWxpZGF0aW5nRmllbGRzKSlcbiAgICAgICAgICAgICAgICA/IHsgdmFsaWRhdGluZ0ZpZWxkczoge30sIGlzVmFsaWRhdGluZzogZmFsc2UgfVxuICAgICAgICAgICAgICAgIDogbnVsbCksXG4gICAgICAgICAgICBlcnJvcnM6IGtlZXBTdGF0ZU9wdGlvbnMua2VlcEVycm9ycyA/IF9mb3JtU3RhdGUuZXJyb3JzIDoge30sXG4gICAgICAgICAgICBpc1N1Ym1pdFN1Y2Nlc3NmdWw6IGtlZXBTdGF0ZU9wdGlvbnMua2VlcElzU3VibWl0U3VjY2Vzc2Z1bFxuICAgICAgICAgICAgICAgID8gX2Zvcm1TdGF0ZS5pc1N1Ym1pdFN1Y2Nlc3NmdWxcbiAgICAgICAgICAgICAgICA6IGZhbHNlLFxuICAgICAgICAgICAgaXNTdWJtaXR0aW5nOiBmYWxzZSxcbiAgICAgICAgICAgIGRlZmF1bHRWYWx1ZXM6IF9kZWZhdWx0VmFsdWVzLFxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IHJlc2V0ID0gKGZvcm1WYWx1ZXMsIGtlZXBTdGF0ZU9wdGlvbnMpID0+IF9yZXNldChpc0Z1bmN0aW9uKGZvcm1WYWx1ZXMpID8gZm9ybVZhbHVlcyhfZm9ybVZhbHVlcykgOiBmb3JtVmFsdWVzLCB7XG4gICAgICAgIC4uLl9vcHRpb25zLnJlc2V0T3B0aW9ucyxcbiAgICAgICAgLi4ua2VlcFN0YXRlT3B0aW9ucyxcbiAgICB9KTtcbiAgICBjb25zdCBzZXRGb2N1cyA9IChuYW1lLCBvcHRpb25zID0ge30pID0+IHtcbiAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgIGNvbnN0IGZpZWxkUmVmZXJlbmNlID0gZmllbGQgJiYgZmllbGQuX2Y7XG4gICAgICAgIGlmIChmaWVsZFJlZmVyZW5jZSkge1xuICAgICAgICAgICAgY29uc3QgZmllbGRSZWYgPSAoZmllbGRSZWZlcmVuY2UucmVmc1xuICAgICAgICAgICAgICAgID8gZmllbGRSZWZlcmVuY2UucmVmcy5maW5kKChyZWYpID0+ICFyZWYuZGlzYWJsZWQpIHx8XG4gICAgICAgICAgICAgICAgICAgIGZpZWxkUmVmZXJlbmNlLnJlZnNbMF1cbiAgICAgICAgICAgICAgICA6IGZpZWxkUmVmZXJlbmNlLnJlZik7XG4gICAgICAgICAgICBpZiAoZmllbGRSZWYuZm9jdXMpIHtcbiAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgZmllbGRSZWYuZm9jdXMoKTtcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9ucy5zaG91bGRTZWxlY3QgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzRnVuY3Rpb24oZmllbGRSZWYuc2VsZWN0KSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgZmllbGRSZWYuc2VsZWN0KCk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IF9zZXRGb3JtU3RhdGUgPSAodXBkYXRlZEZvcm1TdGF0ZSkgPT4ge1xuICAgICAgICAvLyBgbmFtZWAsIGB0eXBlYCwgYW5kIGB2YWx1ZXNgIGRlc2NyaWJlIHRoZSBldmVudCB0aGF0IHByb2R1Y2VkIHRoaXNcbiAgICAgICAgLy8gdXBkYXRlLCBub3QgdGhlIGZvcm0ncyBwZXJzaXN0ZWQgc3RhdGUgKHRoZXkgYXJlbid0IHBhcnQgb2ZcbiAgICAgICAgLy8gYEZvcm1TdGF0ZWApLiBNZXJnaW5nIHRoZW0gaW4gd291bGQgbGVhayBhIHN0YWxlIGBuYW1lYC9gdHlwZWAgZnJvbVxuICAgICAgICAvLyBvbmUgZXZlbnQgaW50byBhIGxhdGVyLCB1bnJlbGF0ZWQgbm90aWZpY2F0aW9uIHRoYXQgZG9lc24ndCBzcGVjaWZ5XG4gICAgICAgIC8vIGl0cyBvd24uXG4gICAgICAgIGNvbnN0IHsgbmFtZSwgdHlwZSwgdmFsdWVzLCAuLi5mb3JtU3RhdGUgfSA9IHVwZGF0ZWRGb3JtU3RhdGU7XG4gICAgICAgIGlmIChPYmplY3Qua2V5cyhmb3JtU3RhdGUpLmxlbmd0aCkge1xuICAgICAgICAgICAgX2Zvcm1TdGF0ZSA9IHtcbiAgICAgICAgICAgICAgICAuLi5fZm9ybVN0YXRlLFxuICAgICAgICAgICAgICAgIC4uLmZvcm1TdGF0ZSxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICB9O1xuICAgIF9zdWJqZWN0cy5zdGF0ZS5zdWJzY3JpYmUoeyBuZXh0OiBfc2V0Rm9ybVN0YXRlIH0pO1xuICAgIGNvbnN0IF9yZXNldERlZmF1bHRWYWx1ZXMgPSAoKSA9PiBpc0Z1bmN0aW9uKF9vcHRpb25zLmRlZmF1bHRWYWx1ZXMpICYmXG4gICAgICAgIF9vcHRpb25zLmRlZmF1bHRWYWx1ZXMoKS50aGVuKCh2YWx1ZXMpID0+IHtcbiAgICAgICAgICAgIHJlc2V0KHZhbHVlcywgX29wdGlvbnMucmVzZXRPcHRpb25zKTtcbiAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICBpc0xvYWRpbmc6IGZhbHNlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIGNvbnN0IHJlc2V0RGVmYXVsdFZhbHVlcyA9ICh2YWx1ZXMsIG9wdGlvbnMgPSB7fSkgPT4ge1xuICAgICAgICBfZGVmYXVsdFZhbHVlcyA9IGNsb25lT2JqZWN0KHZhbHVlcyk7XG4gICAgICAgIGlmICghb3B0aW9ucy5rZWVwRGlydHkpIHtcbiAgICAgICAgICAgIGNvbnN0IG5ld0RpcnR5RmllbGRzID0gZ2V0RGlydHlGaWVsZHMoX2RlZmF1bHRWYWx1ZXMsIF9mb3JtVmFsdWVzLCB1bmRlZmluZWQsIF9maWVsZHMpO1xuICAgICAgICAgICAgX2Zvcm1TdGF0ZS5kaXJ0eUZpZWxkcyA9IG5ld0RpcnR5RmllbGRzO1xuICAgICAgICAgICAgX2Zvcm1TdGF0ZS5pc0RpcnR5ID0gIWlzRW1wdHlPYmplY3QobmV3RGlydHlGaWVsZHMpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghb3B0aW9ucy5rZWVwSXNWYWxpZCkge1xuICAgICAgICAgICAgX3NldFZhbGlkKCk7XG4gICAgICAgIH1cbiAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgLi4uX2Zvcm1TdGF0ZSxcbiAgICAgICAgICAgIGRlZmF1bHRWYWx1ZXM6IF9kZWZhdWx0VmFsdWVzLFxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IG1ldGhvZHMgPSB7XG4gICAgICAgIGNvbnRyb2w6IHtcbiAgICAgICAgICAgIHJlZ2lzdGVyLFxuICAgICAgICAgICAgdW5yZWdpc3RlcixcbiAgICAgICAgICAgIGdldEZpZWxkU3RhdGUsXG4gICAgICAgICAgICBoYW5kbGVTdWJtaXQsXG4gICAgICAgICAgICBzZXRFcnJvcixcbiAgICAgICAgICAgIF9zdWJzY3JpYmUsXG4gICAgICAgICAgICBfcnVuU2NoZW1hLFxuICAgICAgICAgICAgX3VwZGF0ZUlzVmFsaWRhdGluZyxcbiAgICAgICAgICAgIF9mb2N1c0Vycm9yLFxuICAgICAgICAgICAgX2dldFdhdGNoLFxuICAgICAgICAgICAgX2dldERpcnR5LFxuICAgICAgICAgICAgX3NldFZhbGlkLFxuICAgICAgICAgICAgX3NldEZpZWxkQXJyYXksXG4gICAgICAgICAgICBfc2V0RGlzYWJsZWRGaWVsZCxcbiAgICAgICAgICAgIF9zZXRFcnJvcnMsXG4gICAgICAgICAgICBfZ2V0RmllbGRBcnJheSxcbiAgICAgICAgICAgIF9yZXNldCxcbiAgICAgICAgICAgIF9yZXNldERlZmF1bHRWYWx1ZXMsXG4gICAgICAgICAgICBfcmVtb3ZlVW5tb3VudGVkLFxuICAgICAgICAgICAgX2Rpc2FibGVGb3JtLFxuICAgICAgICAgICAgX3N1YmplY3RzLFxuICAgICAgICAgICAgX3Byb3h5Rm9ybVN0YXRlLFxuICAgICAgICAgICAgZ2V0IF9maWVsZHMoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIF9maWVsZHM7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZ2V0IF9mb3JtVmFsdWVzKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBfZm9ybVZhbHVlcztcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBnZXQgX3N0YXRlKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBfc3RhdGU7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2V0IF9zdGF0ZSh2YWx1ZSkge1xuICAgICAgICAgICAgICAgIF9zdGF0ZSA9IHZhbHVlO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGdldCBfZGVmYXVsdFZhbHVlcygpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gX2RlZmF1bHRWYWx1ZXM7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZ2V0IF9uYW1lcygpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gX25hbWVzO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNldCBfbmFtZXModmFsdWUpIHtcbiAgICAgICAgICAgICAgICBfbmFtZXMgPSB2YWx1ZTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBnZXQgX2Zvcm1TdGF0ZSgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gX2Zvcm1TdGF0ZTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBnZXQgX29wdGlvbnMoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIF9vcHRpb25zO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNldCBfb3B0aW9ucyh2YWx1ZSkge1xuICAgICAgICAgICAgICAgIF9vcHRpb25zID0ge1xuICAgICAgICAgICAgICAgICAgICAuLi5fb3B0aW9ucyxcbiAgICAgICAgICAgICAgICAgICAgLi4udmFsdWUsXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICBfdmFsaWRhdGlvbk1vZGVCZWZvcmVTdWJtaXQgPSBnZXRWYWxpZGF0aW9uTW9kZXMoX29wdGlvbnMubW9kZSk7XG4gICAgICAgICAgICAgICAgX3ZhbGlkYXRpb25Nb2RlQWZ0ZXJTdWJtaXQgPSBnZXRWYWxpZGF0aW9uTW9kZXMoX29wdGlvbnMucmVWYWxpZGF0ZU1vZGUpO1xuICAgICAgICAgICAgICAgIHNob3VsZERpc3BsYXlBbGxBc3NvY2lhdGVkRXJyb3JzID1cbiAgICAgICAgICAgICAgICAgICAgX29wdGlvbnMuY3JpdGVyaWFNb2RlID09PSBWQUxJREFUSU9OX01PREUuYWxsO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgc3Vic2NyaWJlLFxuICAgICAgICB0cmlnZ2VyLFxuICAgICAgICByZWdpc3RlcixcbiAgICAgICAgaGFuZGxlU3VibWl0LFxuICAgICAgICB3YXRjaCxcbiAgICAgICAgc2V0VmFsdWUsXG4gICAgICAgIHNldFZhbHVlcyxcbiAgICAgICAgZ2V0VmFsdWVzLFxuICAgICAgICBnZXRFcnJvcnMsXG4gICAgICAgIHJlc2V0LFxuICAgICAgICByZXNldEZpZWxkLFxuICAgICAgICByZXNldERlZmF1bHRWYWx1ZXMsXG4gICAgICAgIGNsZWFyRXJyb3JzLFxuICAgICAgICB1bnJlZ2lzdGVyLFxuICAgICAgICBzZXRFcnJvcixcbiAgICAgICAgc2V0Rm9jdXMsXG4gICAgICAgIGdldEZpZWxkU3RhdGUsXG4gICAgfTtcbiAgICByZXR1cm4ge1xuICAgICAgICAuLi5tZXRob2RzLFxuICAgICAgICBmb3JtQ29udHJvbDogbWV0aG9kcyxcbiAgICB9O1xufVxuXG5jb25zdCBSRVNFVF9PUFRJT05TID0ge1xuICAgIG1vZGU6IGRlZmF1bHRPcHRpb25zLm1vZGUsXG4gICAgcmVWYWxpZGF0ZU1vZGU6IGRlZmF1bHRPcHRpb25zLnJlVmFsaWRhdGVNb2RlLFxuICAgIHNob3VsZEZvY3VzRXJyb3I6IGRlZmF1bHRPcHRpb25zLnNob3VsZEZvY3VzRXJyb3IsXG4gICAgcmVzb2x2ZXI6IHVuZGVmaW5lZCxcbiAgICBjcml0ZXJpYU1vZGU6IHVuZGVmaW5lZCxcbiAgICBkZWxheUVycm9yOiB1bmRlZmluZWQsXG4gICAgc2hvdWxkVW5yZWdpc3RlcjogdW5kZWZpbmVkLFxuICAgIHNob3VsZFVzZU5hdGl2ZVZhbGlkYXRpb246IHVuZGVmaW5lZCxcbiAgICBjb250ZXh0OiB1bmRlZmluZWQsXG4gICAgcHJvZ3Jlc3NpdmU6IHVuZGVmaW5lZCxcbiAgICByZXNldE9wdGlvbnM6IHVuZGVmaW5lZCxcbn07XG4vKipcbiAqIENvcmUgaG9vayBmb3IgbWFuYWdpbmcgYSBmb3JtLiBSZXR1cm5zIGFsbCBtZXRob2RzIGFuZCBzdGF0ZSBmb3JcbiAqIHJlZ2lzdHJhdGlvbiwgdmFsaWRhdGlvbiwgYW5kIHN1Ym1pc3Npb24uXG4gKlxuICogQHNlZSBbQVBJXShodHRwczovL3JlYWN0LWhvb2stZm9ybS5jb20vZG9jcy91c2Vmb3JtKVxuICpcbiAqIEBleGFtcGxlXG4gKiBgYGB0c3hcbiAqIGNvbnN0IHsgcmVnaXN0ZXIsIGhhbmRsZVN1Ym1pdCwgZm9ybVN0YXRlOiB7IGVycm9ycyB9IH0gPSB1c2VGb3JtPEZvcm1WYWx1ZXM+KCk7XG4gKiA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0KG9uU3VibWl0KX0+XG4gKiAgIDxpbnB1dCB7Li4ucmVnaXN0ZXIoXCJlbWFpbFwiLCB7IHJlcXVpcmVkOiB0cnVlIH0pfSAvPlxuICogPC9mb3JtPlxuICogYGBgXG4gKi9cbmZ1bmN0aW9uIHVzZUZvcm0ocHJvcHMgPSB7fSkge1xuICAgIGNvbnN0IF9mb3JtQ29udHJvbCA9IFJlYWN0LnVzZVJlZih1bmRlZmluZWQpO1xuICAgIGNvbnN0IF92YWx1ZXMgPSBSZWFjdC51c2VSZWYodW5kZWZpbmVkKTtcbiAgICBjb25zdCBfZm9ybUNvbnRyb2xQcm9wID0gUmVhY3QudXNlUmVmKHByb3BzLmZvcm1Db250cm9sKTtcbiAgICBjb25zdCBfaGFkRGlzYWJsZWQgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICAgIGNvbnN0IF9oYWRWYWxpZGF0ZSA9IFJlYWN0LnVzZVJlZighIXByb3BzLnZhbGlkYXRlKTtcbiAgICBjb25zdCBfaGFkRXJyb3JzID0gUmVhY3QudXNlUmVmKCEhcHJvcHMuZXJyb3JzKTtcbiAgICBjb25zdCBfaXNNb3VudGVkID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgICBjb25zdCBbZm9ybVN0YXRlLCB1cGRhdGVGb3JtU3RhdGVdID0gUmVhY3QudXNlU3RhdGUoKCkgPT4gKHtcbiAgICAgICAgLi4uY2xvbmVPYmplY3QoREVGQVVMVF9GT1JNX1NUQVRFKSxcbiAgICAgICAgaXNMb2FkaW5nOiBpc0Z1bmN0aW9uKHByb3BzLmRlZmF1bHRWYWx1ZXMpLFxuICAgICAgICBlcnJvcnM6IHByb3BzLmVycm9ycyB8fCB7fSxcbiAgICAgICAgZGlzYWJsZWQ6IHByb3BzLmRpc2FibGVkIHx8IGZhbHNlLFxuICAgICAgICBkZWZhdWx0VmFsdWVzOiBpc0Z1bmN0aW9uKHByb3BzLmRlZmF1bHRWYWx1ZXMpXG4gICAgICAgICAgICA/IHVuZGVmaW5lZFxuICAgICAgICAgICAgOiBwcm9wcy5kZWZhdWx0VmFsdWVzLFxuICAgIH0pKTtcbiAgICBpZiAoIV9mb3JtQ29udHJvbC5jdXJyZW50IHx8XG4gICAgICAgIChwcm9wcy5mb3JtQ29udHJvbCAmJiBfZm9ybUNvbnRyb2xQcm9wLmN1cnJlbnQgIT09IHByb3BzLmZvcm1Db250cm9sKSkge1xuICAgICAgICBfZm9ybUNvbnRyb2xQcm9wLmN1cnJlbnQgPSBwcm9wcy5mb3JtQ29udHJvbDtcbiAgICAgICAgX2hhZERpc2FibGVkLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgaWYgKHByb3BzLmZvcm1Db250cm9sKSB7XG4gICAgICAgICAgICBfZm9ybUNvbnRyb2wuY3VycmVudCA9IHtcbiAgICAgICAgICAgICAgICAuLi5wcm9wcy5mb3JtQ29udHJvbCxcbiAgICAgICAgICAgICAgICBmb3JtU3RhdGUsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgaWYgKHByb3BzLmRlZmF1bHRWYWx1ZXMgJiYgIWlzRnVuY3Rpb24ocHJvcHMuZGVmYXVsdFZhbHVlcykpIHtcbiAgICAgICAgICAgICAgICBwcm9wcy5mb3JtQ29udHJvbC5yZXNldChwcm9wcy5kZWZhdWx0VmFsdWVzLCBwcm9wcy5yZXNldE9wdGlvbnMpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgeyBmb3JtQ29udHJvbCwgLi4ucmVzdCB9ID0gY3JlYXRlRm9ybUNvbnRyb2wocHJvcHMpO1xuICAgICAgICAgICAgX2Zvcm1Db250cm9sLmN1cnJlbnQgPSB7XG4gICAgICAgICAgICAgICAgLi4ucmVzdCxcbiAgICAgICAgICAgICAgICBmb3JtU3RhdGUsXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgfVxuICAgIGNvbnN0IGNvbnRyb2wgPSBfZm9ybUNvbnRyb2wuY3VycmVudC5jb250cm9sO1xuICAgIGNvbnN0IHByZXZpb3VzT3B0aW9ucyA9IGNvbnRyb2wuX29wdGlvbnM7XG4gICAgY29uc3QgcmVtb3ZlZE9wdGlvbnMgPSB7fTtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBSRVNFVF9PUFRJT05TKSB7XG4gICAgICAgIGlmIChrZXkgaW4gcHJldmlvdXNPcHRpb25zICYmICEoa2V5IGluIHByb3BzKSkge1xuICAgICAgICAgICAgcmVtb3ZlZE9wdGlvbnNba2V5XSA9IFJFU0VUX09QVElPTlNba2V5XTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAoX2hhZERpc2FibGVkLmN1cnJlbnQgJiYgIXByb3BzLmRpc2FibGVkKSB7XG4gICAgICAgIHJlbW92ZWRPcHRpb25zLmRpc2FibGVkID0gZmFsc2U7XG4gICAgfVxuICAgIGNvbnRyb2wuX29wdGlvbnMgPSB7XG4gICAgICAgIC4uLnJlbW92ZWRPcHRpb25zLFxuICAgICAgICAuLi5wcm9wcyxcbiAgICAgICAgdmFsaWRhdGU6IHByb3BzLnZhbGlkYXRlLFxuICAgIH07XG4gICAgY29uc3QgZ2V0Q3VycmVudEZvcm1TdGF0ZSA9ICgpID0+ICh7XG4gICAgICAgIC4uLmNvbnRyb2wuX2Zvcm1TdGF0ZSxcbiAgICAgICAgZGVmYXVsdFZhbHVlczogY29udHJvbC5fZGVmYXVsdFZhbHVlcyxcbiAgICB9KTtcbiAgICBjb25zdCB7IHJlc3luY0lmTmVlZGVkLCBzbmFwc2hvdCB9ID0gdXNlUmVzeW5jT25SZWNvbm5lY3QoZ2V0Q3VycmVudEZvcm1TdGF0ZSwgY2xvbmVGb3JtU3RhdGUpO1xuICAgIHVzZUlzb21vcnBoaWNMYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgICAgICByZXN5bmNJZk5lZWRlZCh0cnVlLCBnZXRDdXJyZW50Rm9ybVN0YXRlLCB1cGRhdGVGb3JtU3RhdGUpO1xuICAgICAgICBjb25zdCB1bnN1YnNjcmliZSA9IGNvbnRyb2wuX3N1YnNjcmliZSh7XG4gICAgICAgICAgICBmb3JtU3RhdGU6IGNvbnRyb2wuX3Byb3h5Rm9ybVN0YXRlLFxuICAgICAgICAgICAgY2FsbGJhY2s6ICgpID0+IHVwZGF0ZUZvcm1TdGF0ZSh7XG4gICAgICAgICAgICAgICAgLi4uY29udHJvbC5fZm9ybVN0YXRlLFxuICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZXM6IGNvbnRyb2wuX2RlZmF1bHRWYWx1ZXMsXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHJlUmVuZGVyUm9vdDogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICAgIHVwZGF0ZUZvcm1TdGF0ZSgoZGF0YSkgPT4gKHtcbiAgICAgICAgICAgIC4uLmRhdGEsXG4gICAgICAgICAgICBpc1JlYWR5OiB0cnVlLFxuICAgICAgICB9KSk7XG4gICAgICAgIGNvbnRyb2wuX2Zvcm1TdGF0ZS5pc1JlYWR5ID0gdHJ1ZTtcbiAgICAgICAgY29udHJvbC5fc3ViamVjdHMuc3RhdGUubmV4dCh7IGlzUmVhZHk6IHRydWUgfSk7XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICB1bnN1YnNjcmliZSgpO1xuICAgICAgICAgICAgc25hcHNob3QodHJ1ZSwgZ2V0Q3VycmVudEZvcm1TdGF0ZSk7XG4gICAgICAgIH07XG4gICAgfSwgW2NvbnRyb2wsIHJlc3luY0lmTmVlZGVkLCBzbmFwc2hvdF0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGNvbnRyb2wuX2Rpc2FibGVGb3JtKF9oYWREaXNhYmxlZC5jdXJyZW50ICYmICFwcm9wcy5kaXNhYmxlZCA/IGZhbHNlIDogcHJvcHMuZGlzYWJsZWQpO1xuICAgICAgICBfaGFkRGlzYWJsZWQuY3VycmVudCA9ICEhcHJvcHMuZGlzYWJsZWQ7XG4gICAgfSwgW2NvbnRyb2wsIHByb3BzLmRpc2FibGVkXSk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKHByb3BzLm1vZGUpIHtcbiAgICAgICAgICAgIGNvbnRyb2wuX29wdGlvbnMubW9kZSA9IHByb3BzLm1vZGU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHByb3BzLnJlVmFsaWRhdGVNb2RlKSB7XG4gICAgICAgICAgICBjb250cm9sLl9vcHRpb25zLnJlVmFsaWRhdGVNb2RlID0gcHJvcHMucmVWYWxpZGF0ZU1vZGU7XG4gICAgICAgIH1cbiAgICB9LCBbY29udHJvbCwgcHJvcHMubW9kZSwgcHJvcHMucmVWYWxpZGF0ZU1vZGVdKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAocHJvcHMuZXJyb3JzKSB7XG4gICAgICAgICAgICBjb250cm9sLl9zZXRFcnJvcnMocHJvcHMuZXJyb3JzKTtcbiAgICAgICAgICAgIGNvbnRyb2wuX2ZvY3VzRXJyb3IoKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChfaGFkRXJyb3JzLmN1cnJlbnQpIHtcbiAgICAgICAgICAgIGNvbnRyb2wuX3NldEVycm9ycyh7fSk7XG4gICAgICAgIH1cbiAgICAgICAgX2hhZEVycm9ycy5jdXJyZW50ID0gISFwcm9wcy5lcnJvcnM7XG4gICAgfSwgW2NvbnRyb2wsIHByb3BzLmVycm9yc10pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChfaGFkVmFsaWRhdGUuY3VycmVudCAmJiAhcHJvcHMudmFsaWRhdGUpIHtcbiAgICAgICAgICAgIF9mb3JtQ29udHJvbC5jdXJyZW50ICYmIF9mb3JtQ29udHJvbC5jdXJyZW50LmNsZWFyRXJyb3JzKEZPUk1fRVJST1JfVFlQRSk7XG4gICAgICAgIH1cbiAgICAgICAgX2hhZFZhbGlkYXRlLmN1cnJlbnQgPSAhIXByb3BzLnZhbGlkYXRlO1xuICAgIH0sIFtwcm9wcy52YWxpZGF0ZV0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIHByb3BzLnNob3VsZFVucmVnaXN0ZXIgJiZcbiAgICAgICAgICAgIGNvbnRyb2wuX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgIHZhbHVlczogY29udHJvbC5fZ2V0V2F0Y2goKSxcbiAgICAgICAgICAgIH0pO1xuICAgIH0sIFtjb250cm9sLCBwcm9wcy5zaG91bGRVbnJlZ2lzdGVyXSk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKGNvbnRyb2wuX3Byb3h5Rm9ybVN0YXRlLmlzRGlydHkpIHtcbiAgICAgICAgICAgIGNvbnN0IGlzRGlydHkgPSBjb250cm9sLl9nZXREaXJ0eSgpO1xuICAgICAgICAgICAgaWYgKGlzRGlydHkgIT09IGZvcm1TdGF0ZS5pc0RpcnR5KSB7XG4gICAgICAgICAgICAgICAgY29udHJvbC5fc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgICAgIGlzRGlydHksXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LCBbY29udHJvbCwgZm9ybVN0YXRlLmlzRGlydHldKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAocHJvcHMudmFsdWVzICYmICFkZWVwRXF1YWwocHJvcHMudmFsdWVzLCBfdmFsdWVzLmN1cnJlbnQpKSB7XG4gICAgICAgICAgICBjb250cm9sLl9yZXNldChwcm9wcy52YWx1ZXMsIHtcbiAgICAgICAgICAgICAgICBrZWVwRmllbGRzUmVmOiB0cnVlLFxuICAgICAgICAgICAgICAgIC4uLmNvbnRyb2wuX29wdGlvbnMucmVzZXRPcHRpb25zLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBpZiAoIShjb250cm9sLl9vcHRpb25zLnJlc2V0T3B0aW9ucyAmJlxuICAgICAgICAgICAgICAgIGNvbnRyb2wuX29wdGlvbnMucmVzZXRPcHRpb25zLmtlZXBJc1ZhbGlkKSkge1xuICAgICAgICAgICAgICAgIGNvbnRyb2wuX3NldFZhbGlkKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBfdmFsdWVzLmN1cnJlbnQgPSBwcm9wcy52YWx1ZXM7XG4gICAgICAgICAgICB1cGRhdGVGb3JtU3RhdGUoKHN0YXRlKSA9PiAoeyAuLi5zdGF0ZSB9KSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBjb250cm9sLl9yZXNldERlZmF1bHRWYWx1ZXMoKTtcbiAgICAgICAgfVxuICAgIH0sIFtjb250cm9sLCBwcm9wcy52YWx1ZXNdKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoIWNvbnRyb2wuX3N0YXRlLm1vdW50IHx8ICghX2lzTW91bnRlZC5jdXJyZW50ICYmICFwcm9wcy52YWx1ZXMpKSB7XG4gICAgICAgICAgICBjb250cm9sLl9zZXRWYWxpZCgpO1xuICAgICAgICAgICAgY29udHJvbC5fc3RhdGUubW91bnQgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIF9pc01vdW50ZWQuY3VycmVudCA9IHRydWU7XG4gICAgICAgIGlmIChjb250cm9sLl9zdGF0ZS53YXRjaCkge1xuICAgICAgICAgICAgY29udHJvbC5fc3RhdGUud2F0Y2ggPSBmYWxzZTtcbiAgICAgICAgICAgIGNvbnRyb2wuX3N1YmplY3RzLnN0YXRlLm5leHQoeyAuLi5jb250cm9sLl9mb3JtU3RhdGUgfSk7XG4gICAgICAgIH1cbiAgICAgICAgY29udHJvbC5fcmVtb3ZlVW5tb3VudGVkKCk7XG4gICAgfSk7XG4gICAgX2Zvcm1Db250cm9sLmN1cnJlbnQuZm9ybVN0YXRlID0gUmVhY3QudXNlTWVtbygoKSA9PiBnZXRQcm94eUZvcm1TdGF0ZShmb3JtU3RhdGUsIGNvbnRyb2wpLCBbY29udHJvbCwgZm9ybVN0YXRlXSk7XG4gICAgcmV0dXJuIF9mb3JtQ29udHJvbC5jdXJyZW50O1xufVxuXG5jb25zdCBIb29rRm9ybUNvbnRleHQgPSBSZWFjdC5jcmVhdGVDb250ZXh0KG51bGwpO1xuSG9va0Zvcm1Db250ZXh0LmRpc3BsYXlOYW1lID0gJ0hvb2tGb3JtQ29udGV4dCc7XG4vKipcbiAqIFJldHJpZXZlcyBhbGwgYHVzZUZvcm1gIG1ldGhvZHMgZnJvbSB0aGUgbmVhcmVzdCBgRm9ybVByb3ZpZGVyYC5cbiAqIFVzZSBpbiBkZWVwbHkgbmVzdGVkIGNvbXBvbmVudHMgdG8gYXZvaWQgcHJvcC1kcmlsbGluZy5cbiAqXG4gKiBAc2VlIFtBUEldKGh0dHBzOi8vcmVhY3QtaG9vay1mb3JtLmNvbS9kb2NzL3VzZWZvcm1jb250ZXh0KVxuICpcbiAqIEBleGFtcGxlXG4gKiBgYGB0c3hcbiAqIGNvbnN0IHsgcmVnaXN0ZXIgfSA9IHVzZUZvcm1Db250ZXh0PEZvcm1WYWx1ZXM+KCk7XG4gKiBgYGBcbiAqL1xuY29uc3QgdXNlRm9ybUNvbnRleHQgPSAoKSA9PiBSZWFjdC51c2VDb250ZXh0KEhvb2tGb3JtQ29udGV4dCk7XG4vKipcbiAqIFByb3ZpZGVzIGFsbCBgdXNlRm9ybWAgbWV0aG9kcyB0byB0aGUgY29tcG9uZW50IHRyZWUgdmlhIFJlYWN0IENvbnRleHQuXG4gKiBQYWlyIHdpdGggYHVzZUZvcm1Db250ZXh0YCB0byBjb25zdW1lIHRoZW0gaW4gYW55IGRlc2NlbmRhbnQuXG4gKlxuICogQHNlZSBbQVBJXShodHRwczovL3JlYWN0LWhvb2stZm9ybS5jb20vZG9jcy91c2Vmb3JtY29udGV4dClcbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiA8Rm9ybVByb3ZpZGVyIHsuLi5tZXRob2RzfT5cbiAqICAgPGZvcm0gb25TdWJtaXQ9e21ldGhvZHMuaGFuZGxlU3VibWl0KG9uU3VibWl0KX0+e2NoaWxkcmVufTwvZm9ybT5cbiAqIDwvRm9ybVByb3ZpZGVyPlxuICogYGBgXG4gKi9cbmNvbnN0IEZvcm1Qcm92aWRlciA9ICh7IGNoaWxkcmVuLCB3YXRjaCwgZ2V0VmFsdWVzLCBnZXRFcnJvcnMsIGdldEZpZWxkU3RhdGUsIHNldEVycm9yLCBjbGVhckVycm9ycywgc2V0VmFsdWUsIHNldFZhbHVlcywgdHJpZ2dlciwgZm9ybVN0YXRlLCByZXNldEZpZWxkLCByZXNldCwgcmVzZXREZWZhdWx0VmFsdWVzLCBoYW5kbGVTdWJtaXQsIHVucmVnaXN0ZXIsIGNvbnRyb2wsIHJlZ2lzdGVyLCBzZXRGb2N1cywgc3Vic2NyaWJlLCB9KSA9PiB7XG4gICAgY29uc3QgbWVtb2l6ZWRWYWx1ZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICAgICAgd2F0Y2gsXG4gICAgICAgIGdldFZhbHVlcyxcbiAgICAgICAgZ2V0RXJyb3JzLFxuICAgICAgICBnZXRGaWVsZFN0YXRlLFxuICAgICAgICBzZXRFcnJvcixcbiAgICAgICAgY2xlYXJFcnJvcnMsXG4gICAgICAgIHNldFZhbHVlLFxuICAgICAgICBzZXRWYWx1ZXMsXG4gICAgICAgIHRyaWdnZXIsXG4gICAgICAgIGZvcm1TdGF0ZSxcbiAgICAgICAgcmVzZXRGaWVsZCxcbiAgICAgICAgcmVzZXQsXG4gICAgICAgIHJlc2V0RGVmYXVsdFZhbHVlcyxcbiAgICAgICAgaGFuZGxlU3VibWl0LFxuICAgICAgICB1bnJlZ2lzdGVyLFxuICAgICAgICBjb250cm9sLFxuICAgICAgICByZWdpc3RlcixcbiAgICAgICAgc2V0Rm9jdXMsXG4gICAgICAgIHN1YnNjcmliZSxcbiAgICB9KSwgW1xuICAgICAgICBjbGVhckVycm9ycyxcbiAgICAgICAgY29udHJvbCxcbiAgICAgICAgZm9ybVN0YXRlLFxuICAgICAgICBnZXRFcnJvcnMsXG4gICAgICAgIGdldEZpZWxkU3RhdGUsXG4gICAgICAgIGdldFZhbHVlcyxcbiAgICAgICAgaGFuZGxlU3VibWl0LFxuICAgICAgICByZWdpc3RlcixcbiAgICAgICAgcmVzZXQsXG4gICAgICAgIHJlc2V0RGVmYXVsdFZhbHVlcyxcbiAgICAgICAgcmVzZXRGaWVsZCxcbiAgICAgICAgc2V0RXJyb3IsXG4gICAgICAgIHNldEZvY3VzLFxuICAgICAgICBzZXRWYWx1ZSxcbiAgICAgICAgc2V0VmFsdWVzLFxuICAgICAgICBzdWJzY3JpYmUsXG4gICAgICAgIHRyaWdnZXIsXG4gICAgICAgIHVucmVnaXN0ZXIsXG4gICAgICAgIHdhdGNoLFxuICAgIF0pO1xuICAgIHJldHVybiAoUmVhY3QuY3JlYXRlRWxlbWVudChIb29rRm9ybUNvbnRleHQuUHJvdmlkZXIsIHsgdmFsdWU6IG1lbW9pemVkVmFsdWUgfSxcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChIb29rRm9ybUNvbnRyb2xDb250ZXh0LlByb3ZpZGVyLCB7IHZhbHVlOiBtZW1vaXplZFZhbHVlLmNvbnRyb2wgfSwgY2hpbGRyZW4pKSk7XG59O1xuXG4vKipcbiAqIENvbXBvbmVudCB3cmFwcGVyIGFyb3VuZCBgdXNlV2F0Y2hgLiBSZS1yZW5kZXJzIG9ubHkgd2hlbiB3YXRjaGVkIGZpZWxkcyBjaGFuZ2UuXG4gKlxuICogQHNlZSBbQVBJXShodHRwczovL3JlYWN0LWhvb2stZm9ybS5jb20vZG9jcy91c2V3YXRjaClcbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiA8V2F0Y2hcbiAqICAgY29udHJvbD17Y29udHJvbH1cbiAqICAgbmFtZXM9e1tcImZvb1wiLCBcImJhclwiXX1cbiAqICAgcmVuZGVyPXsoW2ZvbywgYmFyXSkgPT4gPHNwYW4+e2Zvb30ge2Jhcn08L3NwYW4+fVxuICogLz5cbiAqIGBgYFxuICovXG5jb25zdCBXYXRjaCA9IChwcm9wcykgPT4gcHJvcHMucmVuZGVyKHVzZVdhdGNoKHsgbmFtZTogcHJvcHMubmFtZXMsIC4uLnByb3BzIH0pKTtcblxuZXhwb3J0IHsgQ29udHJvbGxlciwgRXJyb3JNZXNzYWdlLCBGaWVsZEFycmF5LCBGb3JtLCBGb3JtUHJvdmlkZXIsIEZvcm1TdGF0ZSwgRm9ybVN0YXRlU3Vic2NyaWJlLCBXYXRjaCwgYXBwZW5kRXJyb3JzLCBjcmVhdGVGb3JtQ29udHJvbCwgZ2V0LCBzZXQsIHVzZUNvbnRyb2xsZXIsIHVzZUZpZWxkQXJyYXksIHVzZUZvcm0sIHVzZUZvcm1Db250ZXh0LCB1c2VGb3JtU3RhdGUsIHVzZVdhdGNoIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5lc20ubWpzLm1hcFxuIl0sIm1hcHBpbmdzIjoiOzs7O0FBRUEsSUFBSSxtQkFBbUIsWUFBWSxRQUFRLFNBQVM7QUFFcEQsSUFBSSxlQUFlLFlBQVksUUFBUSxTQUFTO0FBRWhELElBQUksZ0JBQWdCLFVBQVUsaUJBQWlCO0FBRS9DLElBQUkscUJBQXFCLFVBQVUsU0FBUztBQUU1QyxJQUFNLGdCQUFnQixVQUFVLE9BQU8sVUFBVTtBQUNqRCxJQUFJLFlBQVksVUFBVSxDQUFDLGtCQUFrQixLQUFLLEtBQzlDLENBQUMsTUFBTSxRQUFRLEtBQUssS0FDcEIsYUFBYSxLQUFLLEtBQ2xCLENBQUMsYUFBYSxLQUFLO0FBRXZCLElBQUksaUJBQWlCLFVBQVUsU0FBUyxLQUFLLEtBQUssTUFBTSxTQUNsRCxnQkFBZ0IsTUFBTSxNQUFNLElBQ3hCLE1BQU0sT0FBTyxVQUNiLFlBQVksTUFBTSxNQUFNLElBQ3BCLE1BQU0sT0FBTyxRQUNiLE1BQU0sT0FBTyxRQUNyQjtBQUVOLElBQU0sZ0JBQWdCO0FBQ3RCLElBQUksZ0JBQWdCLFVBQVUsTUFBTSxNQUFNLGFBQWEsQ0FBQyxDQUFDLE9BQU8sT0FBTztBQUV2RSxTQUFTLHFCQUFxQixTQUFTLE1BQU07Q0FDekMsTUFBTSxXQUFXLGFBQWEsSUFBSTtDQUNsQyxJQUFJLGFBQWEsUUFBUTtDQUN6QixJQUFJLGdCQUFnQixRQUFRO0NBQzVCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFNBQVMsR0FBRyxLQUFLO0VBQzFDLE1BQU0sTUFBTSxTQUFTO0VBQ3JCLGFBQ0ksY0FBYyxPQUNSLGFBQ0EsV0FBVztFQUNyQixnQkFDSSxpQkFBaUIsT0FDWCxnQkFDQSxjQUFjO0VBQ3hCLElBQUksZUFBZSxRQUFRLGtCQUFrQixNQUN6QyxPQUFPO0NBRWY7QUFFSjtBQUVBLElBQUksc0JBQXNCLE9BQU8sU0FBUyxLQUNyQyxNQUFNLEdBQUcsQ0FBQyxDQUNWLE1BQU0sTUFBTSxPQUFPLFFBQVEsQ0FBQyxNQUFNLE9BQU8sSUFBSSxDQUFDLEtBQUssTUFBTSxJQUFJLElBQUksTUFBTSxHQUFHLEtBQUssQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7QUFFaEcsSUFBSSxRQUFRLE9BQU8sV0FBVyxlQUMxQixPQUFPLE9BQU8sZ0JBQWdCLGVBQzlCLE9BQU8sYUFBYTtBQUV4QixTQUFTLFlBQVksTUFBTTtDQUN2QixJQUFJLFNBQVMsUUFBUSxPQUFPLFNBQVMsVUFDakMsT0FBTztDQUVYLElBQUksZ0JBQWdCLE1BQ2hCLE9BQU8sSUFBSSxLQUFLLElBQUk7Q0FFeEIsTUFBTSxpQkFBaUIsT0FBTyxTQUFTLGVBQWUsZ0JBQWdCO0NBQ3RFLE1BQU0scUJBQXFCLE9BQU8sYUFBYSxlQUFlLGdCQUFnQjtDQUM5RSxJQUFJLFVBQVUsa0JBQWtCLHFCQUM1QixPQUFPO0NBRVgsTUFBTSxVQUFVLE1BQU0sUUFBUSxJQUFJO0NBQ2xDLE1BQU0sWUFBWSxPQUFPLGVBQWUsSUFBSTtDQUM1QyxJQUFJLENBQUMsV0FBVyxhQUFhLFVBQVUsZ0JBQWdCLFFBQ25ELE9BQU87Q0FFWCxNQUFNLE9BQU8sVUFBVSxJQUFJLE1BQU0sS0FBSyxNQUFNLElBQUksT0FBTyxPQUFPLFNBQVM7Q0FDdkUsS0FBSyxNQUFNLE9BQU8sTUFDZCxJQUFJLE9BQU8sVUFBVSxlQUFlLEtBQUssTUFBTSxHQUFHLEdBQzlDLEtBQUssT0FBTyxZQUFZLEtBQUssSUFBSTtDQUd6QyxPQUFPO0FBQ1g7QUFFQSxJQUFNLFNBQVM7Q0FDWCxNQUFNO0NBQ04sV0FBVztDQUNYLFFBQVE7Q0FDUixRQUFRO0NBQ1IsU0FBUztDQUNULE9BQU87QUFDWDtBQUNBLElBQU0sa0JBQWtCO0NBQ3BCLFFBQVE7Q0FDUixVQUFVO0NBQ1YsVUFBVTtDQUNWLFdBQVc7Q0FDWCxLQUFLO0FBQ1Q7QUFDQSxJQUFNLHlCQUF5QjtDQUMzQixLQUFLO0NBQ0wsS0FBSztDQUNMLFdBQVc7Q0FDWCxXQUFXO0NBQ1gsU0FBUztDQUNULFVBQVU7Q0FDVixVQUFVO0FBQ2Q7QUFDQSxJQUFNLDRCQUE0QjtDQUM5Qix1QkFBdUI7Q0FDdkIsdUJBQXVCO0NBQ3ZCLHVCQUF1QjtDQUN2Qix1QkFBdUI7Q0FDdkIsdUJBQXVCO0NBQ3ZCLHVCQUF1QjtDQUN2Qix1QkFBdUI7QUFDM0I7QUFDQSxJQUFNLGtCQUFrQjtBQUN4QixJQUFNLGtCQUFrQjtBQUN4QixJQUFNLHFCQUFxQjtDQUFDO0NBQWE7Q0FBZTtBQUFXO0FBRW5FLElBQU0sWUFBWTtBQUNsQixJQUFJLFNBQVMsVUFBVSxVQUFVLEtBQUssS0FBSztBQUUzQyxJQUFJLGVBQWUsUUFBUSxRQUFRLEtBQUE7QUFFbkMsSUFBSSxPQUFPLFFBQVEsTUFBTSxpQkFBaUI7Q0FDdEMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLE1BQU0sR0FDekIsT0FBTztDQUVYLE1BQU0sUUFBUSxNQUFNLElBQUksSUFBSSxDQUFDLElBQUksSUFBSSxhQUFhLElBQUk7Q0FDdEQsSUFBSSxNQUFNLE1BQU0sUUFBUSxtQkFBbUIsU0FBUyxHQUFHLENBQUMsR0FDcEQsT0FBTztDQUVYLE1BQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxRQUFRO0VBQ3pDLE9BQU8sa0JBQWtCLE1BQU0sSUFDekIsS0FBQSxJQUNBLE9BQU87Q0FDakIsR0FBRyxNQUFNO0NBQ1QsT0FBUSxZQUFZLE1BQU0sS0FBSyxXQUFXLFNBQ3BDLFlBQVksT0FBTyxLQUFLLElBQ3BCLGVBQ0EsT0FBTyxRQUNYO0FBQ1Y7QUFFQSxJQUFJLGFBQWEsVUFBVSxPQUFPLFVBQVU7QUFFNUMsSUFBSSxjQUFjLFVBQVUsT0FBTyxVQUFVO0FBRTdDLElBQUksT0FBTyxRQUFRLE1BQU0sVUFBVTtDQUMvQixJQUFJLFFBQVE7Q0FDWixNQUFNLFdBQVcsTUFBTSxJQUFJLElBQUksQ0FBQyxJQUFJLElBQUksYUFBYSxJQUFJO0NBQ3pELE1BQU0sU0FBUyxTQUFTO0NBQ3hCLE1BQU0sWUFBWSxTQUFTO0NBQzNCLE9BQU8sRUFBRSxRQUFRLFFBQVE7RUFDckIsTUFBTSxNQUFNLFNBQVM7RUFDckIsSUFBSSxXQUFXO0VBQ2YsSUFBSSxVQUFVLFdBQVc7R0FDckIsTUFBTSxXQUFXLE9BQU87R0FDeEIsV0FDSSxTQUFTLFFBQVEsS0FBSyxNQUFNLFFBQVEsUUFBUSxJQUN0QyxXQUNBLENBQUMsTUFBTSxDQUFDLFNBQVMsUUFBUSxFQUFFLElBQ3ZCLENBQUMsSUFDRCxDQUFDO0VBQ25CO0VBQ0EsSUFBSSxtQkFBbUIsU0FBUyxHQUFHLEdBQy9CO0VBRUosT0FBTyxPQUFPO0VBQ2QsU0FBUyxPQUFPO0NBQ3BCO0FBQ0o7Ozs7O0FBTUEsSUFBTSx5QkFBQSxhQUErQixjQUFjLElBQUk7QUFDdkQsdUJBQXVCLGNBQWM7Ozs7QUFJckMsSUFBTSw4QkFBQSxhQUFvQyxXQUFXLHNCQUFzQjtBQUUzRSxJQUFJLHFCQUFxQixXQUFXLFNBQVMscUJBQXFCLFNBQVMsU0FBUztDQUNoRixNQUFNLFNBQVMsQ0FBQztDQUNoQixLQUFLLE1BQU0sT0FBTyxXQUNkLE9BQU8sZUFBZSxRQUFRLEtBQUssRUFDL0IsV0FBVztFQUNQLE1BQU0sT0FBTztFQUNiLElBQUksUUFBUSxnQkFBZ0IsVUFBVSxnQkFBZ0IsS0FDbEQsUUFBUSxnQkFBZ0IsUUFBUSxDQUFDLFVBQVUsZ0JBQWdCO0VBRS9ELHdCQUF3QixvQkFBb0IsUUFBUTtFQUNwRCxPQUFPLFVBQVU7Q0FDckIsRUFDSixDQUFDO0NBRUwsT0FBTztBQUNYO0FBRUEsSUFBTSw0QkFBNEIsT0FBTyxXQUFXLGNBQUEsYUFBb0Isa0JBQUEsYUFBd0I7QUFFaEcsSUFBSSxpQkFBaUIsZUFBZTtDQUNoQyxNQUFNLGdCQUFnQixXQUFXLGVBQWUsV0FBVyxZQUFZO0NBQ3ZFLE9BQVEsU0FBUyxhQUFhLEtBQUssY0FBYyxlQUFlLGVBQWU7QUFDbkY7QUFFQSxJQUFJLGVBQWUsVUFBVSxrQkFBa0IsS0FBSyxLQUFLLENBQUMsYUFBYSxLQUFLO0FBRTVFLElBQU0sb0NBQW9DLFFBQVEsU0FBUyxLQUFLLFdBQVcsS0FDdkUsQ0FBQyxNQUFNLFFBQVEsTUFBTSxLQUNyQixPQUFPLGVBQWUsTUFBTSxNQUFNLFFBQ2xDLENBQUMsY0FBYyxNQUFNO0FBQ3pCLFNBQVMsVUFBVSxTQUFTLFNBQVMsZ0JBQWdCLE9BQU8sMEJBQVUsSUFBSSxRQUFRLEdBQUc7Q0FDakYsSUFBSSxZQUFZLFNBQ1osT0FBTztDQUVYLElBQUksWUFBWSxPQUFPLEtBQUssWUFBWSxPQUFPLEdBQzNDLE9BQU8sT0FBTyxHQUFHLFNBQVMsT0FBTztDQUVyQyxJQUFJLGFBQWEsT0FBTyxLQUFLLGFBQWEsT0FBTyxHQUM3QyxPQUFPLE9BQU8sR0FBRyxRQUFRLFFBQVEsR0FBRyxRQUFRLFFBQVEsQ0FBQztDQUV6RCxJQUFJLE1BQU0sUUFBUSxPQUFPLEtBQ3JCLE1BQU0sUUFBUSxPQUFPLEtBQ3JCLFFBQVEsV0FBVyxRQUFRLFFBQzNCLE9BQU87Q0FFWCxNQUFNLFFBQVEsT0FBTyxLQUFLLE9BQU87Q0FDakMsTUFBTSxRQUFRLE9BQU8sS0FBSyxPQUFPO0NBQ2pDLElBQUksTUFBTSxXQUFXLE1BQU0sUUFDdkIsT0FBTztDQUVYLElBQUksaUNBQWlDLFNBQVMsS0FBSyxLQUMvQyxpQ0FBaUMsU0FBUyxLQUFLLEdBQy9DLE9BQU8sT0FBTyxHQUFHLFNBQVMsT0FBTztDQUVyQyxJQUFJLENBQUMsTUFBTSxVQUFVLE1BQU0sUUFBUSxPQUFPLE1BQU0sTUFBTSxRQUFRLE9BQU8sR0FDakUsT0FBTztDQUVYLE1BQU0sZUFBZSxRQUFRLElBQUksT0FBTztDQUN4QyxJQUFJLGdCQUFnQixhQUFhLElBQUksT0FBTyxHQUN4QyxPQUFPO0NBRVgsSUFBSSxjQUNBLGFBQWEsSUFBSSxPQUFPO01BRXZCO0VBQ0QsTUFBTSxxQkFBSyxJQUFJLFFBQVE7RUFDdkIsR0FBRyxJQUFJLE9BQU87RUFDZCxRQUFRLElBQUksU0FBUyxFQUFFO0NBQzNCO0NBQ0EsS0FBSyxNQUFNLE9BQU8sT0FBTztFQUNyQixNQUFNLE9BQU8sUUFBUTtFQUNyQixJQUFJLENBQUMsT0FBTyxVQUFVLGVBQWUsS0FBSyxTQUFTLEdBQUcsR0FDbEQsT0FBTztFQUVYLElBQUksQ0FBQyxpQkFBaUIsUUFBUSxPQUFPO0dBQ2pDLE1BQU0sT0FBTyxRQUFRO0dBQ3JCLElBQUssYUFBYSxJQUFJLEtBQUssYUFBYSxJQUFJLE1BQ3RDLFNBQVMsSUFBSSxLQUFLLE1BQU0sUUFBUSxJQUFJLE9BQ2pDLFNBQVMsSUFBSSxLQUFLLE1BQU0sUUFBUSxJQUFJLEtBQ3ZDLENBQUMsVUFBVSxNQUFNLE1BQU0sZUFBZSxPQUFPLElBQzdDLENBQUMsT0FBTyxHQUFHLE1BQU0sSUFBSSxHQUN2QixPQUFPO0VBRWY7Q0FDSjtDQUNBLE9BQU87QUFDWDtBQUVBLElBQU0sa0JBQWtCLEVBQUUsZUFBZSxHQUFHLGlCQUFpQjtDQUFFLEdBQUcsWUFBWSxTQUFTO0NBQUc7QUFBYztBQUN4RyxTQUFTLHFCQUFxQixpQkFBaUIsUUFBUSxhQUFhO0NBQ2hFLE1BQU0sYUFBQSxhQUFtQixPQUFPLEtBQUs7Q0FDckMsTUFBTSxlQUFBLGFBQXFCLE9BQU8sS0FBSztDQUN2QyxNQUFNLGFBQUEsYUFBbUIsT0FBTyxLQUFBLENBQVM7Q0FDekMsTUFBTSxlQUFBLGFBQXFCLE9BQU8sQ0FBQztDQUNuQyxhQUFhO0NBQ2IsSUFBSSxDQUFDLGFBQWEsV0FBVyxpQkFBaUI7RUFDMUMsYUFBYSxVQUFVO0VBQ3ZCLFdBQVcsVUFBVSxNQUFNLGdCQUFnQixDQUFDO0NBQ2hEO0NBaUJBLE9BQU87RUFBRSxnQkFBQSxhQWhCb0IsYUFBYSxTQUFTLGlCQUFpQixhQUFhO0dBQzdFLElBQUksWUFDQyxXQUFXLFdBQ1AsYUFBYSxXQUFXLGFBQWEsVUFBVSxJQUFLO0lBQ3pELE1BQU0sZUFBZSxnQkFBZ0I7SUFDckMsSUFBSSxDQUFDLFVBQVUsV0FBVyxTQUFTLFlBQVksR0FDM0MsU0FBUyxZQUFZO0dBRTdCO0dBQ0EsV0FBVyxVQUFVO0VBQ3pCLEdBQUcsQ0FBQyxDQU1rQjtFQUFHLFVBQUEsYUFMRixhQUFhLFNBQVMsb0JBQW9CO0dBQzdELElBQUksU0FDQSxXQUFXLFVBQVUsTUFBTSxnQkFBZ0IsQ0FBQztFQUVwRCxHQUFHLENBQUMsS0FBSyxDQUN1QjtDQUFFO0FBQ3RDOzs7Ozs7Ozs7Ozs7QUFhQSxTQUFTLGFBQWEsT0FBTztDQUN6QixNQUFNLGNBQWMsc0JBQXNCO0NBQzFDLE1BQU0sRUFBRSxVQUFVLGFBQWEsVUFBVSxNQUFNLFVBQVUsU0FBUyxDQUFDO0NBQ25FLE1BQU0sNkJBQTZCO0VBQy9CLEdBQUcsUUFBUTtFQUNYLGVBQWUsUUFBUTtDQUMzQjtDQUNBLE1BQU0sQ0FBQyxXQUFXLG1CQUFBLGFBQXlCLFNBQVMsbUJBQW1CO0NBQ3ZFLE1BQU0sdUJBQUEsYUFBNkIsT0FBTztFQUN0QyxTQUFTO0VBQ1QsV0FBVztFQUNYLGFBQWE7RUFDYixlQUFlO0VBQ2Ysa0JBQWtCO0VBQ2xCLGNBQWM7RUFDZCxTQUFTO0VBQ1QsUUFBUTtDQUNaLENBQUM7Q0FDRCxNQUFNLEVBQUUsZ0JBQWdCLGFBQWEscUJBQXFCLHFCQUFxQixjQUFjO0NBQzdGLGdDQUFnQztFQUM1QixlQUFlLENBQUMsVUFBVSxxQkFBcUIsZUFBZTtFQUM5RCxNQUFNLGNBQWMsUUFBUSxXQUFXO0dBQ25DO0dBQ0EsV0FBVyxxQkFBcUI7R0FDaEM7R0FDQSxXQUFXLGNBQWM7SUFDckIsQ0FBQyxZQUNHLGdCQUFnQjtLQUNaLEdBQUcsUUFBUTtLQUNYLEdBQUc7S0FDSCxlQUFlLFFBQVE7SUFDM0IsQ0FBQztHQUNUO0VBQ0osQ0FBQztFQUNELGFBQWE7R0FDVCxZQUFZO0dBQ1osU0FBUyxDQUFDLFVBQVUsbUJBQW1CO0VBQzNDO0NBQ0osR0FBRztFQUFDO0VBQVM7RUFBTTtFQUFVO0VBQU87RUFBZ0I7Q0FBUSxDQUFDO0NBQzdELGFBQU0sZ0JBQWdCO0VBQ2xCLHFCQUFxQixRQUFRLFdBQVcsUUFBUSxVQUFVLElBQUk7Q0FDbEUsR0FBRyxDQUFDLE9BQU8sQ0FBQztDQUNaLE9BQUEsYUFBYSxjQUFjLGtCQUFrQixXQUFXLFNBQVMscUJBQXFCLFNBQVMsS0FBSyxHQUFHLENBQUMsV0FBVyxPQUFPLENBQUM7QUFDL0g7QUFFQSxJQUFJLFlBQVksVUFBVSxPQUFPLFVBQVU7QUFFM0MsSUFBSSx1QkFBdUIsT0FBTyxRQUFRLFlBQVksVUFBVSxpQkFBaUI7Q0FDN0UsSUFBSSxTQUFTLEtBQUssR0FBRztFQUNqQixZQUFZLE9BQU8sTUFBTSxJQUFJLEtBQUs7RUFDbEMsT0FBTyxJQUFJLFlBQVksT0FBTyxZQUFZO0NBQzlDO0NBQ0EsSUFBSSxNQUFNLFFBQVEsS0FBSyxHQUNuQixPQUFPLE1BQU0sS0FBSyxlQUFlLFlBQVksT0FBTyxNQUFNLElBQUksU0FBUyxHQUNuRSxJQUFJLFlBQVksV0FBVyxJQUFJLGNBQWMsU0FBUyxDQUFDLEVBQUU7Q0FFakUsYUFBYSxPQUFPLFdBQVc7Q0FDL0IsT0FBTztBQUNYOzs7Ozs7Ozs7Ozs7O0FBY0EsU0FBUyxTQUFTLE9BQU87Q0FDckIsTUFBTSxjQUFjLHNCQUFzQjtDQUMxQyxNQUFNLEVBQUUsVUFBVSxhQUFhLE1BQU0sY0FBYyxVQUFVLE9BQU8sWUFBYSxTQUFTLENBQUM7Q0FDM0YsTUFBTSxnQkFBQSxhQUFzQixPQUFPLFlBQVk7Q0FDL0MsTUFBTSxXQUFBLGFBQWlCLE9BQU8sT0FBTztDQUNyQyxNQUFNLGVBQUEsYUFBcUIsT0FBTyxPQUFPO0NBQ3pDLE1BQU0sWUFBQSxhQUFrQixPQUFPLElBQUk7Q0FDbkMsU0FBUyxVQUFVO0NBQ25CLE1BQU0seUJBQXlCO0VBQzNCLE1BQU0sZUFBZSxRQUFRLFVBQVUsTUFBTSxjQUFjLE9BQU87RUFDbEUsT0FBTyxTQUFTLFVBQVUsU0FBUyxRQUFRLFlBQVksSUFBSTtDQUMvRDtDQUNBLE1BQU0sQ0FBQyxPQUFPLGVBQUEsYUFBcUIsU0FBUyxnQkFBZ0I7Q0FDNUQsTUFBTSxxQkFBQSxhQUEyQixPQUFPLEtBQUs7Q0FDN0MsTUFBTSxtQkFBQSxhQUF5QixhQUFhLFdBQVc7RUFDbkQsTUFBTSxhQUFhLG9CQUFvQixNQUFNLFFBQVEsUUFBUSxVQUFVLFFBQVEsYUFBYSxPQUFPLGNBQWMsT0FBTztFQUN4SCxPQUFPLFNBQVMsVUFDVixTQUFTLFFBQVEsVUFBVSxJQUMzQjtDQUNWLEdBQUc7RUFBQyxRQUFRO0VBQWEsUUFBUTtFQUFRO0NBQUksQ0FBQztDQUM5QyxNQUFNLGVBQUEsYUFBcUIsYUFBYSxXQUFXO0VBQy9DLElBQUksQ0FBQyxVQUFVO0dBQ1gsTUFBTSxhQUFhLG9CQUFvQixNQUFNLFFBQVEsUUFBUSxVQUFVLFFBQVEsYUFBYSxPQUFPLGNBQWMsT0FBTztHQUN4SCxJQUFJLFNBQVMsU0FBUztJQUNsQixNQUFNLHFCQUFxQixTQUFTLFFBQVEsVUFBVTtJQUN0RCxJQUFJLENBQUMsVUFBVSxvQkFBb0IsbUJBQW1CLE9BQU8sR0FBRztLQUM1RCxZQUFZLGtCQUFrQjtLQUM5QixtQkFBbUIsVUFBVTtJQUNqQztHQUNKLE9BQ0s7SUFDRCxZQUFZLFVBQVU7SUFDdEIsbUJBQW1CLFVBQVU7R0FDakM7RUFDSjtDQUNKLEdBQUc7RUFBQyxRQUFRO0VBQWEsUUFBUTtFQUFRO0VBQVU7Q0FBSSxDQUFDO0NBQ3hELE1BQU0sRUFBRSxnQkFBZ0IsYUFBYSxxQkFBcUIsZ0JBQWdCO0NBQzFFLE1BQU0sZ0JBQUEsYUFBc0IsT0FBTyxZQUFZO0NBQy9DLGNBQWMsVUFBVTtDQUN4QixNQUFNLG9CQUFBLGFBQTBCLE9BQU8sZ0JBQWdCO0NBQ3ZELGtCQUFrQixVQUFVO0NBQzVCLGdDQUFnQztFQUM1QixJQUFJLGFBQWEsWUFBWSxXQUN6QixDQUFDLFVBQVUsVUFBVSxTQUFTLElBQUksR0FBRztHQUNyQyxhQUFhLFVBQVU7R0FDdkIsVUFBVSxVQUFVO0dBQ3BCLGNBQWMsUUFBUTtFQUMxQixPQUVJLGVBQWUsQ0FBQyxnQkFBZ0Isa0JBQWtCLFFBQVEsSUFBSSxpQkFBaUI7R0FDM0UsTUFBTSxZQUFZLFlBQVksWUFBWTtHQUMxQyxZQUFZLFNBQVM7R0FDckIsbUJBQW1CLFVBQVU7RUFDakMsQ0FBQztFQUVMLE1BQU0sY0FBYyxRQUFRLFdBQVc7R0FDbkM7R0FDQSxXQUFXLEVBQ1AsUUFBUSxLQUNaO0dBQ0E7R0FDQSxXQUFXLGNBQWM7SUFDckIsY0FBYyxRQUFRLFVBQVUsTUFBTTtHQUMxQztFQUNKLENBQUM7RUFDRCxhQUFhO0dBQ1QsWUFBWTtHQUNaLFNBQVMsQ0FBQyxnQkFBZ0Isa0JBQWtCLFFBQVEsQ0FBQztFQUN6RDtDQUNKLEdBQUc7RUFBQztFQUFTO0VBQU87RUFBTTtFQUFVO0VBQWdCO0NBQVEsQ0FBQztDQUM3RCxhQUFNLGdCQUFnQixRQUFRLGlCQUFpQixDQUFDO0NBS2hELE1BQU0saUJBQWlCLGFBQWEsWUFBWTtDQUNoRCxNQUFNLFdBQVcsVUFBVTtDQUMzQixNQUFNLGNBQUEsYUFBb0IsY0FBYyxDQUFDLGtCQUFrQixDQUFDLFVBQVUsVUFBVSxJQUFJLEdBQUc7RUFBQztFQUFnQjtFQUFNO0NBQVEsQ0FBQztDQUN2SCxJQUFJLGtCQUFrQixhQUNsQixjQUFjLFVBQVU7Q0FHNUIsT0FEOEIsQ0FBQyxhQUFhLGtCQUFrQixlQUMvQixpQkFBaUIsSUFBSTtBQUN4RDs7Ozs7Ozs7Ozs7OztBQWNBLFNBQVMsY0FBYyxPQUFPO0NBQzFCLE1BQU0sY0FBYyxzQkFBc0I7Q0FDMUMsTUFBTSxFQUFFLE1BQU0sVUFBVSxVQUFVLGFBQWEsa0JBQWtCLGNBQWMsUUFBUSxTQUFVO0NBQ2pHLE1BQU0sZUFBZSxtQkFBbUIsUUFBUSxPQUFPLE9BQU8sSUFBSTtDQUtsRSxNQUFNLFFBQVEsU0FBUztFQUNuQjtFQUNBO0VBQ0EsY0FBQSxhQVAyQixjQUFjO0dBQ3pDLE1BQU0sV0FBVyxJQUFJLFFBQVEsYUFBYSxNQUFNLElBQUksUUFBUSxnQkFBZ0IsTUFBTSxZQUFZLENBQUM7R0FDL0YsT0FBUSxZQUFZLFFBQVEsSUFBSSxxQkFBcUIsU0FBUyxJQUFJLElBQUk7RUFDMUUsR0FBRztHQUFDO0dBQVM7R0FBTTtFQUFZLENBSUU7RUFDN0I7Q0FDSixDQUFDO0NBQ0QsTUFBTSxZQUFZLGFBQWE7RUFDM0I7RUFDQTtFQUNBO0NBQ0osQ0FBQztDQUNELE1BQU0sU0FBQSxhQUFlLE9BQU8sS0FBSztDQUNqQyxNQUFNLG9CQUFBLGFBQTBCLE9BQU8sZ0JBQWdCO0NBQ3ZELE1BQU0sWUFBQSxhQUFrQixPQUFPLElBQUk7Q0FDbkMsTUFBTSxrQkFBQSxhQUF3QixPQUFPLEtBQUEsQ0FBUztDQUM5QyxNQUFNLGlCQUFBLGFBQXVCLE9BQU8sUUFBUSxTQUFTLE1BQU07RUFDdkQsR0FBRyxNQUFNO0VBQ1QsT0FBTyxnQkFBZ0IsWUFBWSxRQUFRLENBQUMsSUFBSSxRQUFRLFNBQVMsSUFBSSxJQUMvRCxLQUFBLElBQ0E7RUFDTixHQUFJLFVBQVUsTUFBTSxRQUFRLElBQUksRUFBRSxVQUFVLE1BQU0sU0FBUyxJQUFJLENBQUM7Q0FDcEUsQ0FBQyxDQUFDO0NBQ0YsZ0JBQWdCLFVBQVU7Q0FDMUIsT0FBTyxVQUFVO0NBQ2pCLE1BQU0sYUFBQSxhQUFtQixjQUFjLE9BQU8saUJBQWlCLENBQUMsR0FBRztFQUMvRCxTQUFTO0dBQ0wsWUFBWTtHQUNaLFdBQVcsQ0FBQyxDQUFDLElBQUksVUFBVSxRQUFRLElBQUk7RUFDM0M7RUFDQSxTQUFTO0dBQ0wsWUFBWTtHQUNaLFdBQVcsQ0FBQyxDQUFDLElBQUksVUFBVSxhQUFhLElBQUk7RUFDaEQ7RUFDQSxXQUFXO0dBQ1AsWUFBWTtHQUNaLFdBQVcsQ0FBQyxDQUFDLElBQUksVUFBVSxlQUFlLElBQUk7RUFDbEQ7RUFDQSxjQUFjO0dBQ1YsWUFBWTtHQUNaLFdBQVcsQ0FBQyxDQUFDLElBQUksVUFBVSxrQkFBa0IsSUFBSTtFQUNyRDtFQUNBLE9BQU87R0FDSCxZQUFZO0dBQ1osV0FBVyxJQUFJLFVBQVUsUUFBUSxJQUFJO0VBQ3pDO0NBQ0osQ0FBQyxHQUFHLENBQUMsV0FBVyxJQUFJLENBQUM7Q0FDckIsTUFBTSxXQUFBLGFBQWlCLGFBQWEsVUFBVTtFQUMxQyxNQUFNLFFBQVEsY0FBYyxLQUFLO0VBQ2pDLElBQUksQ0FBQyxJQUFJLFFBQVEsU0FBUyxJQUFJLEdBQzFCLGVBQWUsVUFBVSxRQUFRLFNBQVMsTUFBTTtHQUM1QyxHQUFHLE9BQU8sUUFBUTtHQUNsQjtFQUNKLENBQUM7RUFFTCxPQUFPLGVBQWUsUUFBUSxTQUFTO0dBQ25DLFFBQVE7SUFDSixPQUFPLGNBQWMsS0FBSztJQUMxQjtHQUNKO0dBQ0EsTUFBTSxPQUFPO0VBQ2pCLENBQUM7Q0FDTCxHQUFHLENBQUMsTUFBTSxPQUFPLENBQUM7Q0FDbEIsTUFBTSxTQUFBLGFBQWUsa0JBQWtCO0VBQ25DLE1BQU0sUUFBUSxJQUFJLFFBQVEsYUFBYSxJQUFJO0VBQzNDLElBQUksQ0FBQyxJQUFJLFFBQVEsU0FBUyxJQUFJLEdBQzFCLGVBQWUsVUFBVSxRQUFRLFNBQVMsTUFBTTtHQUM1QyxHQUFHLE9BQU8sUUFBUTtHQUNsQjtFQUNKLENBQUM7RUFFTCxPQUFPLGVBQWUsUUFBUSxPQUFPO0dBQ2pDLFFBQVE7SUFDSjtJQUNBO0dBQ0o7R0FDQSxNQUFNLE9BQU87RUFDakIsQ0FBQztDQUNMLEdBQUcsQ0FBQyxNQUFNLE9BQU8sQ0FBQztDQUNsQixNQUFNLE1BQUEsYUFBWSxhQUFhLFFBQVE7RUFDbkMsSUFBSSxLQUNBLFVBQVUsVUFBVTtHQUNoQixhQUFhLFdBQVcsSUFBSSxLQUFLLEtBQUssSUFBSSxNQUFNO0dBQ2hELGNBQWMsV0FBVyxJQUFJLE1BQU0sS0FBSyxJQUFJLE9BQU87R0FDbkQsb0JBQW9CLFlBQVksV0FBVyxJQUFJLGlCQUFpQixLQUFLLElBQUksa0JBQWtCLE9BQU87R0FDbEcsc0JBQXNCLFdBQVcsSUFBSSxjQUFjLEtBQUssSUFBSSxlQUFlO0VBQy9FO0VBRUosTUFBTSxRQUFRLElBQUksUUFBUSxTQUFTLElBQUk7RUFDdkMsSUFBSSxTQUFTLE1BQU0sTUFBTSxLQUFLO0dBQzFCLE1BQU0sR0FBRyxNQUFNLFVBQVU7R0FDekIsTUFBTSxHQUFHLEtBQUs7RUFDbEI7Q0FDSixHQUFHLENBQUMsUUFBUSxTQUFTLElBQUksQ0FBQztDQUMxQixNQUFNLFFBQUEsYUFBYyxlQUFlO0VBQy9CO0VBQ0E7RUFDQSxHQUFJLFVBQVUsUUFBUSxLQUFLLFVBQVUsV0FDL0IsRUFBRSxVQUFVLFVBQVUsWUFBWSxTQUFTLElBQzNDLENBQUM7RUFDUDtFQUNBO0VBQ0E7Q0FDSixJQUFJO0VBQUM7RUFBTTtFQUFVLFVBQVU7RUFBVTtFQUFVO0VBQVE7RUFBSztDQUFLLENBQUM7Q0FDdEUsYUFBTSxnQkFBZ0I7RUFDbEIsa0JBQWtCLFVBQVU7RUFDNUIsSUFBSSxRQUFRLFNBQVMsb0JBQW9CLGtCQUFrQjtHQUN2RCxNQUFNLFFBQVEsWUFBWSxJQUFJLG1CQUN4QixRQUFRLGlCQUNSLFFBQVEsU0FBUyxVQUFVLFFBQVEsZ0JBQWdCLE1BQU0sSUFBSSxRQUFRLFNBQVMsZUFBZSxNQUFNLE9BQU8sUUFBUSxZQUFZLENBQUMsQ0FBQztHQUN0SSxJQUFJLFFBQVEsZ0JBQWdCLE1BQU0sS0FBSztHQUN2QyxJQUFJLFlBQVksSUFBSSxRQUFRLGFBQWEsSUFBSSxDQUFDLEdBQzFDLElBQUksUUFBUSxhQUFhLE1BQU0sS0FBSztFQUU1QyxPQUNLLElBQUksQ0FBQyxnQkFDTixDQUFDLFlBQVksT0FBTyxRQUFRLFlBQVksS0FDeEMsWUFBWSxJQUFJLFFBQVEsZ0JBQWdCLElBQUksQ0FBQyxHQUFHO0dBQ2hELElBQUksUUFBUSxnQkFBZ0IsTUFBTSxZQUFZLE9BQU8sUUFBUSxZQUFZLENBQUM7R0FDMUUsUUFBUSxVQUFVLE1BQU0sS0FBSyxFQUN6QixlQUFlLFFBQVEsZUFDM0IsQ0FBQztFQUNMO0NBQ0osR0FBRztFQUFDO0VBQVM7RUFBTTtFQUFjO0NBQWdCLENBQUM7Q0FDbEQsYUFBTSxnQkFBZ0I7RUFDbEIsZUFBZSxVQUFVLFFBQVEsU0FBUyxNQUFNO0dBQzVDLEdBQUcsT0FBTyxRQUFRO0dBQ2xCLEdBQUksVUFBVSxPQUFPLFFBQVEsUUFBUSxJQUMvQixFQUFFLFVBQVUsT0FBTyxRQUFRLFNBQVMsSUFDcEMsQ0FBQztFQUNYLENBQUM7RUFDRCxNQUFNLGlCQUFpQixNQUFNLFVBQVU7R0FDbkMsTUFBTSxRQUFRLElBQUksUUFBUSxTQUFTLElBQUk7R0FDdkMsSUFBSSxTQUFTLE1BQU0sSUFBSTtJQUNuQixNQUFNLEdBQUcsUUFBUTtJQUNqQixNQUFNLEdBQUcsS0FBSztHQUNsQjtFQUNKO0VBQ0EsY0FBYyxNQUFNLElBQUk7RUFDeEIsQ0FBQyxnQkFDRyxRQUFRLFNBQVMsTUFBTTtHQUNuQixHQUFHLE9BQU8sUUFBUTtHQUNsQixHQUFJLFVBQVUsT0FBTyxRQUFRLFFBQVEsSUFDL0IsRUFBRSxVQUFVLE9BQU8sUUFBUSxTQUFTLElBQ3BDLENBQUM7RUFDWCxDQUFDO0VBQ0wsSUFBSSxVQUFVLFNBQVM7R0FDbkIsTUFBTSxRQUFRLElBQUksUUFBUSxTQUFTLElBQUk7R0FDdkMsSUFBSSxTQUFTLE1BQU0sSUFDZixNQUFNLEdBQUcsTUFBTSxVQUFVO0VBRWpDO0VBQ0EsYUFBYTtHQUNULE1BQU0sd0JBQXdCLFFBQVEsU0FBUyxvQkFBb0Isa0JBQWtCO0dBQ3JGLENBQUMsZUFDSyx5QkFBeUIsQ0FBQyxRQUFRLE9BQU8sU0FDekMseUJBQ0EsUUFBUSxXQUFXLElBQUksSUFDdkIsY0FBYyxNQUFNLEtBQUs7RUFDbkM7Q0FDSixHQUFHO0VBQUM7RUFBTTtFQUFTO0NBQVksQ0FBQztDQUNoQyxhQUFNLGdCQUFnQjtFQUNsQixRQUFRLGtCQUFrQjtHQUN0QjtHQUNBO0VBQ0osQ0FBQztDQUNMLEdBQUc7RUFBQztFQUFVO0VBQU07Q0FBTyxDQUFDO0NBQzVCLE9BQUEsYUFBYSxlQUFlO0VBQ3hCO0VBQ0E7RUFDQTtDQUNKLElBQUk7RUFBQztFQUFPO0VBQVc7Q0FBVSxDQUFDO0FBQ3RDOzs7Ozs7Ozs7Ozs7Ozs7QUFnQkEsSUFBTSxjQUFjLFVBQVUsTUFBTSxPQUFPLGNBQWMsS0FBSyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7QUFnQi9ELElBQU0sZ0JBQWdCLEVBQUUsSUFBSSxTQUFTLE1BQU0sYUFBYztDQUNyRCxNQUFNLEVBQUUsV0FBVyxhQUFhO0VBQzVCO0VBQ007Q0FDVixDQUFDO0NBQ0QsTUFBTSxRQUFRLElBQUksUUFBUSxJQUFJO0NBQzlCLElBQUksQ0FBQyxPQUNELE9BQU87Q0FFWCxNQUFNLFVBQVUsTUFBTSxXQUFXO0NBQ2pDLElBQUksUUFDQSxPQUFPLE9BQU87RUFBRTtFQUFTLFVBQVUsTUFBTTtDQUFNLENBQUM7Q0FFcEQsT0FBQSxhQUFhLGNBQWMsTUFBQSxhQUFZLFVBQVUsTUFBTSxPQUFPO0FBQ2xFO0FBRUEsSUFBSSxtQkFBbUIsT0FBTyxXQUFXLGVBQWUsT0FBTyxhQUN6RCxPQUFPLFdBQVcsSUFDbEIsdUNBQXVDLFFBQVEsVUFBVSxNQUFNO0NBQzdELE1BQU0sSUFBSyxLQUFLLE9BQU8sSUFBSSxLQUFNO0NBQ2pDLFFBQVEsTUFBTSxNQUFNLElBQUssSUFBSSxJQUFPLEVBQUEsQ0FBSyxTQUFTLEVBQUU7QUFDeEQsQ0FBQztBQUVMLElBQUkscUJBQXFCLE1BQU0sT0FBTyxVQUFVLENBQUMsTUFBTSxRQUFRLGVBQWUsWUFBWSxRQUFRLFdBQVcsSUFDdkcsUUFBUSxhQUNOLEdBQUcsS0FBSyxHQUFHLFlBQVksUUFBUSxVQUFVLElBQUksUUFBUSxRQUFRLFdBQVcsS0FDMUU7QUFFTixJQUFJLHNCQUFzQixVQUFVO0NBQ2hDLFlBQVksQ0FBQyxRQUFRLFNBQVMsZ0JBQWdCO0NBQzlDLFVBQVUsU0FBUyxnQkFBZ0I7Q0FDbkMsWUFBWSxTQUFTLGdCQUFnQjtDQUNyQyxTQUFTLFNBQVMsZ0JBQWdCO0NBQ2xDLFdBQVcsU0FBUyxnQkFBZ0I7QUFDeEM7QUFFQSxJQUFJLGFBQWEsTUFBTSxRQUFRLGdCQUFnQjtDQUMzQyxJQUFJLGFBQ0EsT0FBTztDQUNYLElBQUksT0FBTyxZQUFZLE9BQU8sTUFBTSxJQUFJLElBQUksR0FDeEMsT0FBTztDQUNYLEtBQUssTUFBTSxhQUFhLE9BQU8sT0FDM0IsSUFBSSxLQUFLLFdBQVcsU0FBUyxLQUFLLEtBQUssT0FBTyxVQUFVLE1BQU0sTUFBTSxLQUNoRSxPQUFPO0NBRWYsT0FBTztBQUNYO0FBRUEsSUFBTSx5QkFBeUIsUUFBUSxRQUFRLGdCQUFnQjtDQUMzRCxJQUFJO0NBQ0osS0FBSyxNQUFNLE9BQU8sZUFBZSxPQUFPLEtBQUssTUFBTSxHQUFHO0VBQ2xELElBQUksUUFBUSxNQUNSO0VBRUosTUFBTSxRQUFTLGNBQWMsSUFBSSxRQUFRLEdBQUcsSUFBSSxPQUFPO0VBQ3ZELElBQUksT0FBTztHQUNQLE1BQU0sRUFBRSxPQUFPO0dBQ2YsSUFBSSxJQUFJO0lBQ0osTUFBTSxZQUFZLEtBQUssR0FBRyxVQUFVLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSyxJQUFJLEdBQUcsTUFBTSxRQUFRLENBQUMsSUFBSSxRQUFRO0lBQ25HLElBQUksWUFBWSxPQUFPLFVBQVUsR0FBRyxJQUFJLEdBQ3BDLE9BQU87U0FFTixJQUFJLEdBQUcsT0FBTyxPQUFPLEdBQUcsS0FBSyxHQUFHLElBQUksR0FDckMsT0FBTztTQUdQLElBQUksc0JBQXNCLE9BQU8sTUFBTSxHQUNuQyxPQUFPO0dBR25CLE9BQ0ssSUFBSSxTQUFTLEtBQUssS0FBSyxNQUFNLFFBQVEsS0FBSyxHQUN2QztRQUFBLHNCQUFzQixPQUFPLE1BQU0sR0FDbkMsT0FBTztHQUFBO0VBR25CO0NBQ0o7QUFFSjtBQUVBLElBQUksNkJBQTZCLFFBQVEsT0FBTyxTQUFTO0NBQ3JELE1BQU0saUJBQWlCLElBQUksUUFBUSxJQUFJO0NBQ3ZDLE1BQU0sbUJBQW1CLE1BQU0sUUFBUSxjQUFjLElBQUksaUJBQWlCLENBQUM7Q0FDM0UsSUFBSSxrQkFBa0IsaUJBQWlCLElBQUksTUFBTSxPQUFPLGlCQUFpQixNQUFNLEtBQUssQ0FBQztDQUNyRixJQUFJLFFBQVEsTUFBTSxnQkFBZ0I7Q0FDbEMsT0FBTztBQUNYO0FBRUEsSUFBSSxpQkFBaUIsVUFBVSxTQUFTLEtBQUssS0FBSyxDQUFDLE9BQU8sS0FBSyxLQUFLLENBQUMsQ0FBQztBQUV0RSxJQUFJLGlCQUFpQixVQUFVO0NBQzNCLElBQUksQ0FBQyxPQUNELE9BQU87Q0FFWCxNQUFNLFFBQVEsUUFBUSxNQUFNLGdCQUFnQjtDQUM1QyxPQUFRLGtCQUNILFNBQVMsTUFBTSxjQUFjLE1BQU0sWUFBWSxjQUFjO0FBQ3RFO0FBRUEsSUFBSSxnQkFBZ0IsWUFBWSxRQUFRLFNBQVM7QUFFakQsSUFBSSxXQUFXLFVBQVUsaUJBQWlCO0FBRTFDLElBQUksZ0JBQWdCLE1BQU0sMEJBQTBCLFFBQVEsTUFBTSxZQUFZLDJCQUN4RTtDQUNFLEdBQUcsT0FBTztDQUNWLE9BQU87RUFDSCxHQUFJLE9BQU8sU0FBUyxPQUFPLEtBQUssQ0FBQyxRQUFRLE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FBQztHQUM5RCxPQUFPLFdBQVc7Q0FDdkI7QUFDSixJQUNFLENBQUM7QUFFUCxJQUFNLGdCQUFnQjtDQUNsQixPQUFPO0NBQ1AsU0FBUztBQUNiO0FBQ0EsSUFBTSxjQUFjO0NBQUUsT0FBTztDQUFNLFNBQVM7QUFBSztBQUNqRCxJQUFJLG9CQUFvQixZQUFZO0NBQ2hDLElBQUksQ0FBQyxNQUFNLFFBQVEsT0FBTyxHQUN0QixPQUFPO0NBRVgsSUFBSSxRQUFRLFNBQVMsR0FBRztFQUNwQixNQUFNLFNBQVMsUUFDVixRQUFRLFdBQVcsVUFBVSxPQUFPLFdBQVcsQ0FBQyxPQUFPLFFBQVEsQ0FBQyxDQUNoRSxLQUFLLFdBQVcsT0FBTyxLQUFLO0VBQ2pDLE9BQU87R0FBRSxPQUFPO0dBQVEsU0FBUyxDQUFDLENBQUMsT0FBTztFQUFPO0NBQ3JEO0NBQ0EsTUFBTSxTQUFTLFFBQVE7Q0FDdkIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLFdBQVcsT0FBTyxVQUNyQyxPQUFPO0NBRVgsSUFBSSxDQUFDLE9BQU8sY0FBYyxFQUFFLFdBQVcsT0FBTyxhQUMxQyxPQUFPO0NBRVgsT0FBTyxZQUFZLE9BQU8sS0FBSyxLQUFLLE9BQU8sVUFBVSxLQUMvQyxjQUNBO0VBQUUsT0FBTyxPQUFPO0VBQU8sU0FBUztDQUFLO0FBQy9DO0FBRUEsSUFBTSxnQkFBZ0I7Q0FDbEIsU0FBUztDQUNULE9BQU87QUFDWDtBQUNBLElBQUksaUJBQWlCLFlBQVksTUFBTSxRQUFRLE9BQU8sSUFDaEQsUUFBUSxRQUFRLFVBQVUsV0FBVyxVQUFVLE9BQU8sV0FBVyxDQUFDLE9BQU8sV0FDckU7Q0FDRSxTQUFTO0NBQ1QsT0FBTyxPQUFPO0FBQ2xCLElBQ0UsVUFBVSxhQUFhLElBQzNCO0FBRU4sU0FBUyxpQkFBaUIsUUFBUSxLQUFLLE9BQU8sWUFBWTtDQUN0RCxJQUFJLFNBQVMsTUFBTSxLQUNkLE1BQU0sUUFBUSxNQUFNLEtBQUssQ0FBQyxDQUFDLE9BQU8sVUFBVSxPQUFPLE1BQU0sUUFBUSxLQUNqRSxVQUFVLE1BQU0sS0FBSyxDQUFDLFFBQ3ZCLE9BQU87RUFDSDtFQUNBLFNBQVMsU0FBUyxNQUFNLElBQUksU0FBUztFQUNyQztDQUNKO0FBRVI7QUFFQSxJQUFJLHNCQUFzQixtQkFBbUIsU0FBUyxjQUFjLEtBQUssQ0FBQyxRQUFRLGNBQWMsSUFDMUYsaUJBQ0E7Q0FDRSxPQUFPO0NBQ1AsU0FBUztBQUNiO0FBRUosSUFBSSxnQkFBZ0IsT0FBTyxPQUFPLG9CQUFvQixZQUFZLDBCQUEwQiwyQkFBMkIsaUJBQWlCO0NBQ3BJLE1BQU0sRUFBRSxLQUFLLE1BQU0sVUFBVSxXQUFXLFdBQVcsS0FBSyxLQUFLLFNBQVMsVUFBVSxNQUFNLGVBQWUsT0FBTyxPQUFRLE1BQU07Q0FDMUgsTUFBTSxhQUFhLElBQUksWUFBWSxJQUFJO0NBQ3ZDLElBQUksQ0FBQyxTQUFTLG1CQUFtQixJQUFJLElBQUksR0FDckMsT0FBTyxDQUFDO0NBRVosTUFBTSxXQUFXLE9BQU8sS0FBSyxLQUFLO0NBQ2xDLE1BQU0scUJBQXFCLFlBQVk7RUFDbkMsSUFBSSw2QkFBNkIsU0FBUyxnQkFBZ0I7R0FDdEQsTUFBTSxrQkFBa0IsVUFBVSxPQUFPLElBQUksS0FBSyxXQUFXO0dBQzdELElBQUksTUFDQSxLQUFLLFNBQVMsUUFBUSxXQUFXLElBQUksaUJBQWlCLEtBQ2xELElBQUksa0JBQWtCLGVBQWUsQ0FBQztRQUcxQyxTQUFTLGtCQUFrQixlQUFlO0dBRTlDLFNBQVMsZUFBZTtFQUM1QjtDQUNKO0NBQ0EsTUFBTSxRQUFRLENBQUM7Q0FDZixNQUFNLFVBQVUsQ0FBQyxNQUFNLGFBQWEsR0FBRztDQUN2QyxNQUFNLGFBQWEsQ0FBQyxNQUFNLGdCQUFnQixHQUFHO0NBQzdDLE1BQU0sb0JBQW9CLFdBQVc7Q0FDckMsTUFBTSxXQUFZLGlCQUFpQixZQUFZLEdBQUcsTUFDOUMsWUFBWSxJQUFJLEtBQUssS0FDckIsWUFBWSxVQUFVLEtBQ3JCLGNBQWMsR0FBRyxLQUFLLElBQUksVUFBVSxNQUFNLENBQUMsTUFDNUMsZUFBZSxNQUNkLE1BQU0sUUFBUSxVQUFVLEtBQUssQ0FBQyxXQUFXO0NBQzlDLE1BQU0sb0JBQW9CLGFBQWEsS0FBSyxNQUFNLE1BQU0sMEJBQTBCLEtBQUs7Q0FDdkYsTUFBTSxvQkFBb0IsV0FBVyxrQkFBa0Isa0JBQWtCLFVBQVUsdUJBQXVCLFdBQVcsVUFBVSx1QkFBdUIsY0FBYztFQUNoSyxNQUFNLFVBQVUsWUFBWSxtQkFBbUI7RUFDL0MsTUFBTSxRQUFRO0dBQ1YsTUFBTSxZQUFZLFVBQVU7R0FDNUI7R0FDQTtHQUNBLEdBQUcsa0JBQWtCLFlBQVksVUFBVSxTQUFTLE9BQU87RUFDL0Q7Q0FDSjtDQUNBLElBQUksZUFDRSxDQUFDLE1BQU0sUUFBUSxVQUFVLEtBQUssQ0FBQyxXQUFXLFNBQzFDLGFBQ0ksQ0FBQyxzQkFBc0IsV0FBVyxrQkFBa0IsVUFBVSxNQUMzRCxVQUFVLFVBQVUsS0FBSyxDQUFDLGNBQzFCLGNBQWMsQ0FBQyxpQkFBaUIsSUFBSSxDQUFDLENBQUMsV0FDdEMsV0FBVyxDQUFDLGNBQWMsSUFBSSxDQUFDLENBQUMsVUFBVztFQUNwRCxNQUFNLEVBQUUsT0FBTyxZQUFZLFNBQVMsUUFBUSxJQUN0QztHQUFFLE9BQU8sQ0FBQyxDQUFDO0dBQVUsU0FBUztFQUFTLElBQ3ZDLG1CQUFtQixRQUFRO0VBQ2pDLElBQUksT0FBTztHQUNQLE1BQU0sUUFBUTtJQUNWLE1BQU0sdUJBQXVCO0lBQzdCO0lBQ0EsS0FBSztJQUNMLEdBQUcsa0JBQWtCLHVCQUF1QixVQUFVLE9BQU87R0FDakU7R0FDQSxJQUFJLENBQUMsMEJBQTBCO0lBQzNCLGtCQUFrQixPQUFPO0lBQ3pCLE9BQU87R0FDWDtFQUNKO0NBQ0o7Q0FDQSxJQUFJLENBQUMsWUFBWSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQyxrQkFBa0IsR0FBRyxJQUFJO0VBQ2xFLElBQUk7RUFDSixJQUFJO0VBQ0osTUFBTSxZQUFZLG1CQUFtQixHQUFHO0VBQ3hDLE1BQU0sWUFBWSxtQkFBbUIsR0FBRztFQUN4QyxJQUFJLENBQUMsa0JBQWtCLFVBQVUsS0FDN0IsQ0FBQyxhQUFhLFVBQVUsS0FDeEIsQ0FBQyxNQUFNLFVBQVUsR0FBRztHQUNwQixNQUFNLGNBQWUsQ0FBQyxNQUFNLElBQUksa0JBQzNCLGFBQWEsQ0FBQyxhQUFhO0dBQ2hDLElBQUksQ0FBQyxrQkFBa0IsVUFBVSxLQUFLLEdBQ2xDLFlBQVksY0FBYyxVQUFVO0dBRXhDLElBQUksQ0FBQyxrQkFBa0IsVUFBVSxLQUFLLEdBQ2xDLFlBQVksY0FBYyxVQUFVO0VBRTVDLE9BQ0s7R0FDRCxNQUFNLFlBQWEsQ0FBQyxNQUFNLElBQUksZUFDMUIsSUFBSSxLQUFLLFVBQVU7R0FDdkIsTUFBTSxxQkFBcUIseUJBQVMsSUFBSSxzQkFBSyxJQUFJLEtBQUssRUFBQSxDQUFFLGFBQWEsSUFBSSxNQUFNLElBQUk7R0FDbkYsTUFBTSxTQUFTLElBQUksUUFBUTtHQUMzQixNQUFNLFNBQVMsSUFBSSxRQUFRO0dBQzNCLElBQUksU0FBUyxVQUFVLEtBQUssS0FBSyxZQUM3QixZQUFZLFNBQ04sa0JBQWtCLFVBQVUsSUFBSSxrQkFBa0IsVUFBVSxLQUFLLElBQ2pFLFNBQ0ksYUFBYSxVQUFVLFFBQ3ZCLFlBQVksSUFBSSxLQUFLLFVBQVUsS0FBSztHQUVsRCxJQUFJLFNBQVMsVUFBVSxLQUFLLEtBQUssWUFDN0IsWUFBWSxTQUNOLGtCQUFrQixVQUFVLElBQUksa0JBQWtCLFVBQVUsS0FBSyxJQUNqRSxTQUNJLGFBQWEsVUFBVSxRQUN2QixZQUFZLElBQUksS0FBSyxVQUFVLEtBQUs7RUFFdEQ7RUFDQSxJQUFJLGFBQWEsV0FBVztHQUN4QixpQkFBaUIsQ0FBQyxDQUFDLFdBQVcsVUFBVSxTQUFTLFVBQVUsU0FBUyx1QkFBdUIsS0FBSyx1QkFBdUIsR0FBRztHQUMxSCxJQUFJLENBQUMsMEJBQTBCO0lBQzNCLGtCQUFrQixNQUFNLEtBQUssQ0FBQyxPQUFPO0lBQ3JDLE9BQU87R0FDWDtFQUNKO0NBQ0o7Q0FDQSxLQUFLLENBQUMsa0JBQWtCLFNBQVMsS0FBSyxDQUFDLGtCQUFrQixTQUFTLE1BQzlELENBQUMsWUFDQSxTQUFTLFVBQVUsS0FBTSxnQkFBZ0IsTUFBTSxRQUFRLFVBQVUsSUFBSztFQUN2RSxNQUFNLGtCQUFrQixtQkFBbUIsU0FBUztFQUNwRCxNQUFNLGtCQUFrQixtQkFBbUIsU0FBUztFQUNwRCxNQUFNLFlBQVksQ0FBQyxrQkFBa0IsZ0JBQWdCLEtBQUssS0FDdEQsV0FBVyxTQUFTLENBQUMsZ0JBQWdCO0VBQ3pDLE1BQU0sWUFBWSxDQUFDLGtCQUFrQixnQkFBZ0IsS0FBSyxLQUN0RCxXQUFXLFNBQVMsQ0FBQyxnQkFBZ0I7RUFDekMsSUFBSSxhQUFhLFdBQVc7R0FDeEIsaUJBQWlCLFdBQVcsZ0JBQWdCLFNBQVMsZ0JBQWdCLE9BQU87R0FDNUUsSUFBSSxDQUFDLDBCQUEwQjtJQUMzQixrQkFBa0IsTUFBTSxLQUFLLENBQUMsT0FBTztJQUNyQyxPQUFPO0dBQ1g7RUFDSjtDQUNKO0NBQ0EsSUFBSSxXQUFXLENBQUMsV0FBVyxTQUFTLFVBQVUsR0FBRztFQUM3QyxNQUFNLEVBQUUsT0FBTyxjQUFjLFlBQVksbUJBQW1CLE9BQU87RUFDbkUsSUFBSSxRQUFRLFlBQVksS0FBSyxDQUFDLFdBQVcsTUFBTSxZQUFZLEdBQUc7R0FDMUQsTUFBTSxRQUFRO0lBQ1YsTUFBTSx1QkFBdUI7SUFDN0I7SUFDQTtJQUNBLEdBQUcsa0JBQWtCLHVCQUF1QixTQUFTLE9BQU87R0FDaEU7R0FDQSxJQUFJLENBQUMsMEJBQTBCO0lBQzNCLGtCQUFrQixPQUFPO0lBQ3pCLE9BQU87R0FDWDtFQUNKO0NBQ0o7Q0FDQSxJQUFJLFVBQVU7RUFDVixJQUFJLFdBQVcsUUFBUSxHQUFHO0dBRXRCLE1BQU0sZ0JBQWdCLGlCQUFpQixNQURsQixTQUFTLFlBQVksVUFBVSxHQUNMLFFBQVE7R0FDdkQsSUFBSSxlQUFlO0lBQ2YsTUFBTSxRQUFRO0tBQ1YsR0FBRztLQUNILEdBQUcsa0JBQWtCLHVCQUF1QixVQUFVLGNBQWMsT0FBTztJQUMvRTtJQUNBLElBQUksQ0FBQywwQkFBMEI7S0FDM0Isa0JBQWtCLGNBQWMsT0FBTztLQUN2QyxPQUFPO0lBQ1g7R0FDSjtFQUNKLE9BQ0ssSUFBSSxTQUFTLFFBQVEsR0FBRztHQUN6QixJQUFJLG1CQUFtQixDQUFDO0dBQ3hCLEtBQUssTUFBTSxPQUFPLFVBQVU7SUFDeEIsSUFBSSxDQUFDLGNBQWMsZ0JBQWdCLEtBQUssQ0FBQywwQkFDckM7SUFFSixNQUFNLGdCQUFnQixpQkFBaUIsTUFBTSxTQUFTLElBQUksQ0FBQyxZQUFZLFVBQVUsR0FBRyxVQUFVLEdBQUc7SUFDakcsSUFBSSxlQUFlO0tBQ2YsbUJBQW1CO01BQ2YsR0FBRztNQUNILEdBQUcsa0JBQWtCLEtBQUssY0FBYyxPQUFPO0tBQ25EO0tBQ0EsSUFBSSxDQUFDLDBCQUNELGtCQUFrQixjQUFjLE9BQU87S0FFM0MsSUFBSSwwQkFDQSxNQUFNLFFBQVE7SUFFdEI7R0FDSjtHQUNBLElBQUksQ0FBQyxjQUFjLGdCQUFnQixHQUFHO0lBQ2xDLE1BQU0sUUFBUTtLQUNWLEtBQUs7S0FDTCxHQUFHO0lBQ1A7SUFDQSxJQUFJLENBQUMsMEJBQ0QsT0FBTztHQUVmO0VBQ0o7Q0FDSjtDQUNBLE1BQU0sYUFBYSxNQUFNO0NBQ3pCLGtCQUFrQixhQUFhLFdBQVcsVUFBVSxJQUFJO0NBQ3hELE9BQU87QUFDWDtBQUVBLElBQUkseUJBQXlCLFVBQVcsTUFBTSxRQUFRLEtBQUssSUFBSSxRQUFRLENBQUMsS0FBSztBQUU3RSxJQUFJLFlBQVksTUFBTSxVQUFVLENBQzVCLEdBQUcsTUFDSCxHQUFHLHNCQUFzQixLQUFLLENBQ2xDO0FBRUEsSUFBSSxrQkFBa0IsVUFBVSxNQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0sVUFBVSxLQUFBLENBQVMsSUFBSSxLQUFBO0FBRXBGLFNBQVMsT0FBTyxNQUFNLE9BQU8sT0FBTztDQUNoQyxPQUFPO0VBQ0gsR0FBRyxLQUFLLE1BQU0sR0FBRyxLQUFLO0VBQ3RCLEdBQUcsc0JBQXNCLEtBQUs7RUFDOUIsR0FBRyxLQUFLLE1BQU0sS0FBSztDQUN2QjtBQUNKO0FBRUEsSUFBSSxlQUFlLE1BQU0sTUFBTSxPQUFPO0NBQ2xDLElBQUksQ0FBQyxNQUFNLFFBQVEsSUFBSSxHQUNuQixPQUFPLENBQUM7Q0FFWixJQUFJLFlBQVksS0FBSyxHQUFHLEdBQ3BCLEtBQUssTUFBTSxLQUFBO0NBRWYsS0FBSyxPQUFPLElBQUksR0FBRyxLQUFLLE9BQU8sTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFO0NBQzFDLE9BQU87QUFDWDtBQUVBLElBQUksYUFBYSxNQUFNLFVBQVUsQ0FDN0IsR0FBRyxzQkFBc0IsS0FBSyxHQUM5QixHQUFHLHNCQUFzQixJQUFJLENBQ2pDO0FBRUEsSUFBSSxXQUFXLFVBQVUsTUFBTSxRQUFRLEtBQUssSUFBSSxNQUFNLE9BQU8sT0FBTyxJQUFJLENBQUM7QUFFekUsU0FBUyxnQkFBZ0IsTUFBTSxTQUFTO0NBQ3BDLElBQUksSUFBSTtDQUNSLE1BQU0sT0FBTyxDQUFDLEdBQUcsSUFBSTtDQUNyQixLQUFLLE1BQU0sU0FBUyxTQUFTO0VBQ3pCLEtBQUssT0FBTyxRQUFRLEdBQUcsQ0FBQztFQUN4QjtDQUNKO0NBQ0EsT0FBTyxRQUFRLElBQUksQ0FBQyxDQUFDLFNBQVMsT0FBTyxDQUFDO0FBQzFDO0FBQ0EsSUFBSSxpQkFBaUIsTUFBTSxVQUFVLFlBQVksS0FBSyxJQUNoRCxDQUFDLElBQ0QsZ0JBQWdCLE1BQU0sQ0FBQyxHQUFHLElBQUksSUFBSSxzQkFBc0IsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQyxDQUFDO0FBRTVGLElBQUksZUFBZSxNQUFNLFFBQVEsV0FBVztDQUN4QyxDQUFDLEtBQUssU0FBUyxLQUFLLFdBQVcsQ0FBQyxLQUFLLFNBQVMsS0FBSyxPQUFPO0FBQzlEO0FBRUEsU0FBUyxRQUFRLFFBQVEsWUFBWTtDQUNqQyxNQUFNLFNBQVMsV0FBVyxTQUFTO0NBQ25DLElBQUksUUFBUTtDQUNaLE9BQU8sUUFBUSxRQUFRO0VBQ25CLElBQUksa0JBQWtCLE1BQU0sR0FBRztHQUMzQixTQUFTLEtBQUE7R0FDVDtFQUNKO0VBQ0EsU0FBUyxPQUFPLFdBQVc7RUFDM0I7Q0FDSjtDQUNBLE9BQU87QUFDWDtBQUNBLFNBQVMsYUFBYSxLQUFLO0NBQ3ZCLEtBQUssTUFBTSxPQUFPLEtBQ2QsSUFBSSxJQUFJLGVBQWUsR0FBRyxLQUFLLENBQUMsWUFBWSxJQUFJLElBQUksR0FDaEQsT0FBTztDQUdmLE9BQU87QUFDWDtBQUNBLFNBQVMsTUFBTSxRQUFRLE1BQU07Q0FDekIsSUFBSSxDQUFDLFNBQVMsTUFBTSxLQUFLLENBQUMsTUFBTSxRQUFRLE1BQU0sR0FDMUMsT0FBTztDQUVYLElBQUksU0FBUyxJQUFJLEtBQUssT0FBTyxVQUFVLGVBQWUsS0FBSyxRQUFRLElBQUksR0FBRztFQUN0RSxPQUFPLE9BQU87RUFDZCxPQUFPO0NBQ1g7Q0FDQSxNQUFNLFFBQVEsTUFBTSxRQUFRLElBQUksSUFDMUIsT0FDQSxNQUFNLElBQUksSUFDTixDQUFDLElBQUksSUFDTCxhQUFhLElBQUk7Q0FDM0IsSUFBSSxNQUFNLE1BQU0sWUFBWSxtQkFBbUIsU0FBUyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEdBQ3BFLE9BQU87Q0FFWCxNQUFNLGNBQWMsTUFBTSxXQUFXLElBQUksU0FBUyxRQUFRLFFBQVEsS0FBSztDQUN2RSxNQUFNLFFBQVEsTUFBTSxTQUFTO0NBQzdCLE1BQU0sTUFBTSxNQUFNO0NBQ2xCLElBQUksZ0JBQWdCLFNBQVMsV0FBVyxLQUFLLE1BQU0sUUFBUSxXQUFXLElBQ2xFLE9BQU8sWUFBWTtDQUV2QixJQUFJLFVBQVUsTUFDUixTQUFTLFdBQVcsS0FBSyxjQUFjLFdBQVcsS0FDL0MsTUFBTSxRQUFRLFdBQVcsS0FBSyxhQUFhLFdBQVcsSUFDM0QsTUFBTSxRQUFRLE1BQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQztDQUVwQyxPQUFPO0FBQ1g7QUFFQSxJQUFJLFlBQVksYUFBYSxPQUFPLFVBQVU7Q0FDMUMsWUFBWSxTQUFTO0NBQ3JCLE9BQU87QUFDWDs7Ozs7Ozs7Ozs7OztBQWNBLFNBQVMsY0FBYyxPQUFPO0NBQzFCLE1BQU0sY0FBYyxzQkFBc0I7Q0FDMUMsTUFBTSxFQUFFLFVBQVUsYUFBYSxNQUFNLFVBQVUsTUFBTSxVQUFVLGtCQUFrQixVQUFXO0NBQzVGLE1BQU0sNkJBQTZCLFFBQVEsZUFBZSxJQUFJO0NBQzlELE1BQU0sQ0FBQyxRQUFRLGFBQUEsYUFBbUIsU0FBUyxvQkFBb0I7Q0FDL0QsTUFBTSxNQUFBLGFBQVksT0FBTyxRQUFRLGVBQWUsSUFBSSxDQUFDLENBQUMsSUFBSSxVQUFVLENBQUM7Q0FDckUsTUFBTSxZQUFBLGFBQWtCLE9BQU8sS0FBSztDQUNwQyxNQUFNLEVBQUUsZ0JBQWdCLGFBQWEscUJBQXFCLG9CQUFvQjtDQUM5RSxNQUFNLGVBQUEsYUFBcUIsT0FBTyxPQUFPO0NBQ3pDLE1BQU0sWUFBQSxhQUFrQixPQUFPLElBQUk7Q0FDbkMsTUFBTSxTQUFBLGFBQWUsT0FBTztFQUFFO0VBQVM7RUFBTTtDQUFNLENBQUM7Q0FDcEQsSUFBSSxDQUFDLFVBQ0QsUUFBUSxPQUFPLE1BQU0sSUFBSSxJQUFJO0NBRWpDLGFBQU0sY0FBYztFQUNoQixJQUFJLENBQUMsWUFBWSxRQUFRO0dBQ3JCLElBQUksU0FDQyxPQUFPLFFBQVEsU0FDWixPQUFPLFFBQVEsWUFBWSxXQUMzQixPQUFPLFFBQVEsU0FBUyxNQUM1QixRQUFRLFNBQVMsTUFBTSxLQUFLO0dBRWhDLE9BQU8sVUFBVTtJQUFFO0lBQVM7SUFBTTtHQUFNO0VBQzVDO0NBQ0osR0FBRztFQUFDO0VBQVM7RUFBTTtFQUFRO0VBQU87Q0FBUSxDQUFDO0NBQzNDLGdDQUFnQztFQUM1QixJQUFJLFVBQ0E7RUFFSixJQUFJLGFBQWEsWUFBWSxXQUFXLFVBQVUsWUFBWSxNQUMxRCxlQUFlLE1BQU0sdUJBQXVCLGdCQUFnQjtHQUN4RCxVQUFVLFdBQVc7R0FDckIsSUFBSSxVQUFVLFlBQVksSUFBSSxVQUFVO0VBQzVDLENBQUM7T0FFQTtHQUNELGFBQWEsVUFBVTtHQUN2QixVQUFVLFVBQVU7R0FDcEIsTUFBTSxjQUFjLHFCQUFxQjtHQUN6QyxJQUFJLENBQUMsVUFBVSxRQUFRLFdBQVcsR0FBRztJQUNqQyxVQUFVLFdBQVc7SUFDckIsSUFBSSxVQUFVLFlBQVksSUFBSSxVQUFVO0dBQzVDO0dBQ0EsU0FBUyxNQUFNLG9CQUFvQjtFQUN2QztFQUNBLE1BQU0sY0FBYyxRQUFRLFVBQVUsTUFBTSxVQUFVLEVBQ2xELE9BQU8sRUFBRSxRQUFRLE1BQU0scUJBQXNCO0dBQ3pDLElBQUksbUJBQW1CLFFBQVEsQ0FBQyxnQkFBZ0I7SUFDNUMsTUFBTSxjQUFjLElBQUksUUFBUSxJQUFJO0lBQ3BDLElBQUksTUFBTSxRQUFRLFdBQVcsR0FBRztLQUM1QixVQUFVLFdBQVc7S0FDckIsSUFBSSxVQUFVLFlBQVksSUFBSSxVQUFVO0lBQzVDLE9BQ0ssSUFBSSxDQUFDLGdCQUFnQjtLQUN0QixVQUFVLENBQUMsQ0FBQztLQUNaLElBQUksVUFBVSxDQUFDO0lBQ25CO0dBQ0o7RUFDSixFQUNKLENBQUMsQ0FBQyxDQUFDO0VBQ0gsYUFBYTtHQUNULFlBQVk7R0FDWixTQUFTLE1BQU0sb0JBQW9CO0VBQ3ZDO0NBQ0osR0FBRztFQUFDO0VBQVM7RUFBTTtFQUFVO0VBQWdCO0NBQVEsQ0FBQztDQUN0RCxNQUFNLGVBQUEsYUFBcUIsYUFBYSw0QkFBNEI7RUFDaEUsVUFBVSxVQUFVO0VBQ3BCLFFBQVEsZUFBZSxNQUFNLHVCQUF1QjtDQUN4RCxHQUFHLENBQUMsU0FBUyxJQUFJLENBQUM7Q0FDbEIsTUFBTSxVQUFVLE9BQU8sWUFBWTtFQUMvQixJQUFJLFVBQ0E7RUFFSixNQUFNLGNBQWMsc0JBQXNCLFlBQVksS0FBSyxDQUFDO0VBQzVELE1BQU0sMEJBQTBCLFNBQVMsUUFBUSxlQUFlLElBQUksR0FBRyxXQUFXO0VBQ2xGLFFBQVEsT0FBTyxRQUFRLGtCQUFrQixNQUFNLHdCQUF3QixTQUFTLEdBQUcsT0FBTztFQUMxRixJQUFJLFVBQVUsU0FBUyxJQUFJLFNBQVMsWUFBWSxJQUFJLFVBQVUsQ0FBQztFQUMvRCxhQUFhLHVCQUF1QjtFQUNwQyxVQUFVLHVCQUF1QjtFQUNqQyxRQUFRLGVBQWUsTUFBTSx5QkFBeUIsVUFBVSxFQUM1RCxNQUFNLGVBQWUsS0FBSyxFQUM5QixDQUFDO0NBQ0w7Q0FDQSxNQUFNLFdBQVcsT0FBTyxZQUFZO0VBQ2hDLElBQUksVUFDQTtFQUVKLE1BQU0sZUFBZSxzQkFBc0IsWUFBWSxLQUFLLENBQUM7RUFDN0QsTUFBTSwwQkFBMEIsVUFBVSxRQUFRLGVBQWUsSUFBSSxHQUFHLFlBQVk7RUFDcEYsUUFBUSxPQUFPLFFBQVEsa0JBQWtCLE1BQU0sR0FBRyxPQUFPO0VBQ3pELElBQUksVUFBVSxVQUFVLElBQUksU0FBUyxhQUFhLElBQUksVUFBVSxDQUFDO0VBQ2pFLGFBQWEsdUJBQXVCO0VBQ3BDLFVBQVUsdUJBQXVCO0VBQ2pDLFFBQVEsZUFBZSxNQUFNLHlCQUF5QixXQUFXLEVBQzdELE1BQU0sZUFBZSxLQUFLLEVBQzlCLENBQUM7Q0FDTDtDQUNBLE1BQU0sVUFBVSxVQUFVO0VBQ3RCLElBQUksVUFDQTtFQUVKLE1BQU0sMEJBQTBCLGNBQWMsUUFBUSxlQUFlLElBQUksR0FBRyxLQUFLO0VBQ2pGLElBQUksVUFBVSxjQUFjLElBQUksU0FBUyxLQUFLO0VBQzlDLGFBQWEsdUJBQXVCO0VBQ3BDLFVBQVUsdUJBQXVCO0VBQ2pDLENBQUMsTUFBTSxRQUFRLElBQUksUUFBUSxTQUFTLElBQUksQ0FBQyxLQUNyQyxJQUFJLFFBQVEsU0FBUyxNQUFNLEtBQUEsQ0FBUztFQUN4QyxRQUFRLGVBQWUsTUFBTSx5QkFBeUIsZUFBZSxFQUNqRSxNQUFNLE1BQ1YsQ0FBQztDQUNMO0NBQ0EsTUFBTSxZQUFZLE9BQU8sT0FBTyxZQUFZO0VBQ3hDLElBQUksVUFDQTtFQUVKLE1BQU0sY0FBYyxzQkFBc0IsWUFBWSxLQUFLLENBQUM7RUFDNUQsTUFBTSwwQkFBMEIsT0FBTyxRQUFRLGVBQWUsSUFBSSxHQUFHLE9BQU8sV0FBVztFQUN2RixRQUFRLE9BQU8sUUFBUSxrQkFBa0IsTUFBTSxPQUFPLE9BQU87RUFDN0QsSUFBSSxVQUFVLE9BQU8sSUFBSSxTQUFTLE9BQU8sWUFBWSxJQUFJLFVBQVUsQ0FBQztFQUNwRSxhQUFhLHVCQUF1QjtFQUNwQyxVQUFVLHVCQUF1QjtFQUNqQyxRQUFRLGVBQWUsTUFBTSx5QkFBeUIsUUFBUTtHQUMxRCxNQUFNO0dBQ04sTUFBTSxlQUFlLEtBQUs7RUFDOUIsQ0FBQztDQUNMO0NBQ0EsTUFBTSxRQUFRLFFBQVEsV0FBVztFQUM3QixJQUFJLFVBQ0E7RUFFSixNQUFNLDBCQUEwQixRQUFRLGVBQWUsSUFBSTtFQUMzRCxZQUFZLHlCQUF5QixRQUFRLE1BQU07RUFDbkQsWUFBWSxJQUFJLFNBQVMsUUFBUSxNQUFNO0VBQ3ZDLGFBQWEsdUJBQXVCO0VBQ3BDLFVBQVUsdUJBQXVCO0VBQ2pDLFFBQVEsZUFBZSxNQUFNLHlCQUF5QixhQUFhO0dBQy9ELE1BQU07R0FDTixNQUFNO0VBQ1YsR0FBRyxLQUFLO0NBQ1o7Q0FDQSxNQUFNLFFBQVEsTUFBTSxPQUFPO0VBQ3ZCLElBQUksVUFDQTtFQUVKLE1BQU0sMEJBQTBCLFFBQVEsZUFBZSxJQUFJO0VBQzNELFlBQVkseUJBQXlCLE1BQU0sRUFBRTtFQUM3QyxZQUFZLElBQUksU0FBUyxNQUFNLEVBQUU7RUFDakMsYUFBYSx1QkFBdUI7RUFDcEMsVUFBVSx1QkFBdUI7RUFDakMsUUFBUSxlQUFlLE1BQU0seUJBQXlCLGFBQWE7R0FDL0QsTUFBTTtHQUNOLE1BQU07RUFDVixHQUFHLEtBQUs7Q0FDWjtDQUNBLE1BQU0sVUFBVSxPQUFPLFVBQVU7RUFDN0IsSUFBSSxVQUNBO0VBRUosTUFBTSxjQUFjLFlBQVksS0FBSztFQUNyQyxNQUFNLDBCQUEwQixTQUFTLFFBQVEsZUFBZSxJQUFJLEdBQUcsT0FBTyxXQUFXO0VBQ3pGLElBQUksVUFBVSxDQUFDLEdBQUcsdUJBQXVCLENBQUMsQ0FBQyxLQUFLLE1BQU0sTUFBTSxDQUFDLFFBQVEsTUFBTSxRQUFRLFdBQVcsSUFBSSxJQUFJLFFBQVEsRUFBRTtFQUNoSCxhQUFhLHVCQUF1QjtFQUNwQyxVQUFVLENBQUMsR0FBRyx1QkFBdUIsQ0FBQztFQUN0QyxRQUFRLGVBQWUsTUFBTSx5QkFBeUIsVUFBVTtHQUM1RCxNQUFNO0dBQ04sTUFBTSxlQUFlLEtBQUs7RUFDOUIsQ0FBQztDQUNMO0NBQ0EsTUFBTSxXQUFXLFVBQVU7RUFDdkIsSUFBSSxVQUNBO0VBRUosTUFBTSwwQkFBMEIsc0JBQXNCLFlBQVksS0FBSyxDQUFDO0VBQ3hFLElBQUksVUFBVSx3QkFBd0IsSUFBSSxVQUFVO0VBQ3BELGFBQWEsQ0FBQyxHQUFHLHVCQUF1QixDQUFDO0VBQ3pDLFVBQVUsQ0FBQyxHQUFHLHVCQUF1QixDQUFDO0VBQ3RDLFFBQVEsZUFBZSxNQUFNLENBQUMsR0FBRyx1QkFBdUIsSUFBSSxTQUFTLE1BQU0sUUFBUSxJQUFJLElBQ2pGLEtBQUssTUFBTSxHQUFHLHdCQUF3QixNQUFNLElBQzVDLE1BQU0sQ0FBQyxDQUFDO0NBQ2xCO0NBQ0EsYUFBTSxnQkFBZ0I7RUFDbEIsSUFBSSxVQUFVO0dBQ1YsUUFBUSxPQUFPLG1CQUFtQixPQUFPLElBQUk7R0FDN0M7RUFDSjtFQUNBLFFBQVEsT0FBTyxTQUFTO0VBQ3hCLFFBQVEsT0FBTyxtQkFBbUIsT0FBTyxJQUFJO0VBQzdDLFVBQVUsTUFBTSxRQUFRLE1BQU0sS0FDMUIsUUFBUSxVQUFVLE1BQU0sS0FBSyxFQUN6QixHQUFHLFFBQVEsV0FDZixDQUFDO0VBQ0wsTUFBTSxrQkFBa0IsbUJBQW1CLFFBQVEsU0FBUyxJQUFJO0VBQ2hFLE1BQU0sa0JBQWtCLG1CQUFtQixRQUFRLFNBQVMsY0FBYztFQUMxRSxJQUFJLFVBQVUsWUFDVCxDQUFDLGdCQUFnQixjQUFjLFFBQVEsV0FBVyxnQkFDbkQsRUFBRSxRQUFRLFdBQVcsZUFBZSxnQkFBZ0IsZ0JBQ25ELENBQUMsZ0JBQWdCLFlBQ2IsUUFBUSxXQUFXLGVBQWUsZ0JBQWdCLGFBQWM7R0FDckUsTUFBTSxtQkFBbUIsSUFBSSxRQUFRLGFBQWEsSUFBSTtHQUN0RCxJQUFJLFFBQVEsU0FBUyxVQUNqQixRQUFRLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sV0FBVztJQUN4QyxRQUFRLG9CQUFvQixDQUFDLElBQUksQ0FBQztJQUNsQyxJQUFJLHFCQUFxQixJQUFJLFFBQVEsYUFBYSxJQUFJLEdBQ2xEO0lBRUosTUFBTSxRQUFRLElBQUksT0FBTyxRQUFRLElBQUk7SUFDckMsSUFBSSxDQUFDLFVBQVUsSUFBSSxRQUFRLFdBQVcsUUFBUSxJQUFJLEdBQUcsT0FBTyxJQUFJLEdBQUc7S0FDL0QsSUFBSSxPQUNBLFNBQVMsS0FBSyxLQUNWLENBQUMsT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDLE1BQU0sUUFBUSxDQUFDLE9BQU8sTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUNuRCwwQkFBMEIsUUFBUSxXQUFXLFFBQVEsR0FBRyxPQUFPLE1BQU0sR0FBRyxJQUFJLElBQzVFLElBQUksUUFBUSxXQUFXLFFBQVEsTUFBTSxLQUFLO1VBR2hELE1BQU0sUUFBUSxXQUFXLFFBQVEsSUFBSTtLQUV6QyxRQUFRLFdBQVcsU0FBUyxFQUFFLEdBQUcsUUFBUSxXQUFXLE9BQU87S0FDM0QsUUFBUSxVQUFVLE1BQU0sS0FBSyxFQUN6QixRQUFRLFFBQVEsV0FBVyxPQUMvQixDQUFDO0lBQ0w7R0FDSixDQUFDO1FBRUE7SUFDRCxNQUFNLFFBQVEsSUFBSSxRQUFRLFNBQVMsSUFBSTtJQUN2QyxJQUFJLFNBQVMsTUFBTSxJQUNmLGNBQWMsT0FBTyxRQUFRLE9BQU8sVUFBVSxRQUFRLGFBQWEsUUFBUSxTQUFTLGlCQUFpQixnQkFBZ0IsS0FBSyxRQUFRLFNBQVMsMkJBQTJCLElBQUksQ0FBQyxDQUFDLE1BQU0sVUFBVTtLQUN4TCxJQUFJLHFCQUFxQixJQUFJLFFBQVEsYUFBYSxJQUFJLEdBQ2xEO0tBRUosSUFBSSxDQUFDLGNBQWMsS0FBSyxHQUFHO01BQ3ZCLDBCQUEwQixRQUFRLFdBQVcsUUFBUSxPQUFPLElBQUk7TUFDaEUsUUFBUSxXQUFXLFNBQVMsRUFBRSxHQUFHLFFBQVEsV0FBVyxPQUFPO01BQzNELFFBQVEsVUFBVSxNQUFNLEtBQUssRUFDekIsUUFBUSxRQUFRLFdBQVcsT0FDL0IsQ0FBQztLQUNMLE9BQ0s7TUFDRCxNQUFNLGdCQUFnQixJQUFJLFFBQVEsV0FBVyxRQUFRLElBQUk7TUFDekQsSUFBSSxpQkFBaUIsY0FBYyxrQkFBa0I7T0FDakQsTUFBTSxRQUFRLFdBQVcsUUFBUSxHQUFHLEtBQUssR0FBRyxpQkFBaUI7T0FDN0QsUUFBUSxXQUFXLFNBQVMsRUFBRSxHQUFHLFFBQVEsV0FBVyxPQUFPO09BQzNELFFBQVEsVUFBVSxNQUFNLEtBQUssRUFDekIsUUFBUSxRQUFRLFdBQVcsT0FDL0IsQ0FBQztNQUNMO0tBQ0o7SUFDSixDQUFDO0dBRVQ7RUFDSjtFQUlBLFVBQVUsV0FDTixRQUFRLFVBQVUsTUFBTSxLQUFLO0dBQ3pCO0dBQ0EsUUFBUSxZQUFZLFFBQVEsV0FBVztFQUMzQyxDQUFDO0VBQ0wsUUFBUSxPQUFPLFNBQ1gsc0JBQXNCLFFBQVEsVUFBVSxLQUFLLFFBQVE7R0FDakQsSUFBSSxRQUFRLE9BQU8sU0FDZixJQUFJLFdBQVcsUUFBUSxPQUFPLEtBQUssS0FDbkMsSUFBSSxPQUFPO0lBQ1gsSUFBSSxNQUFNO0lBQ1YsT0FBTztHQUNYO0VBRUosQ0FBQztFQUNMLFFBQVEsT0FBTyxRQUFRO0VBQ3ZCLFFBQVEsVUFBVTtFQUNsQixVQUFVLFVBQVU7Q0FDeEIsR0FBRztFQUFDO0VBQVE7RUFBTTtFQUFTO0NBQVEsQ0FBQztDQUNwQyxhQUFNLGdCQUFnQjtFQUNsQixJQUFJLENBQUMsVUFDRCxZQUFZLElBQUksUUFBUSxhQUFhLElBQUksQ0FBQyxLQUN0QyxRQUFRLGVBQWUsSUFBSTtFQUVuQyxhQUFhO0dBQ1QsUUFBUSxPQUFPLG1CQUFtQixPQUFPLElBQUk7R0FDN0MsUUFBUSxPQUFPLG1CQUFtQixTQUFTLFFBQVEsT0FBTyxTQUFTO0dBQ25FLElBQUksVUFDQTtHQUVKLE1BQU0sNkJBQTZCLEVBQUUsUUFBUSxTQUFTLG9CQUFvQjtHQUMxRSxNQUFNLGlCQUFpQixNQUFNLFVBQVU7SUFDbkMsTUFBTSxRQUFRLElBQUksUUFBUSxTQUFTLElBQUk7SUFDdkMsSUFBSSxTQUFTLE1BQU0sSUFDZixNQUFNLEdBQUcsUUFBUTtHQUV6QjtHQUNBLElBQUksVUFBVSxXQUFXLDRCQUNyQixRQUFRLFVBQVUsTUFBTSxLQUFLO0lBQ3pCO0lBQ0EsUUFBUSxZQUFZLFFBQVEsV0FBVztHQUMzQyxDQUFDO0dBRUwsSUFBSSxDQUFDLDhCQUNELFFBQVEsT0FBTyxVQUNmLENBQUMsR0FBRyxRQUFRLE9BQU8sbUJBQW1CLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxjQUFjLEtBQUssV0FBVyxZQUFZLEdBQUcsQ0FBQyxHQUNsRztHQUVKLDZCQUNNLGNBQWMsTUFBTSxLQUFLLElBQ3pCLFFBQVEsV0FBVyxJQUFJO0VBQ2pDO0NBQ0osR0FBRztFQUFDO0VBQU07RUFBUztFQUFTO0VBQWtCO0NBQVEsQ0FBQztDQUN2RCxPQUFPO0VBQ0gsTUFBQSxhQUFZLFlBQVksTUFBTTtHQUFDO0dBQWM7R0FBTTtHQUFTO0VBQVEsQ0FBQztFQUNyRSxNQUFBLGFBQVksWUFBWSxNQUFNO0dBQUM7R0FBYztHQUFNO0dBQVM7RUFBUSxDQUFDO0VBQ3JFLFNBQUEsYUFBZSxZQUFZLFNBQVM7R0FDaEM7R0FDQTtHQUNBO0dBQ0E7RUFDSixDQUFDO0VBQ0QsUUFBQSxhQUFjLFlBQVksUUFBUTtHQUFDO0dBQWM7R0FBTTtHQUFTO0VBQVEsQ0FBQztFQUN6RSxRQUFBLGFBQWMsWUFBWSxRQUFRO0dBQUM7R0FBYztHQUFNO0dBQVM7RUFBUSxDQUFDO0VBQ3pFLFFBQUEsYUFBYyxZQUFZLFVBQVU7R0FBQztHQUFjO0dBQU07R0FBUztFQUFRLENBQUM7RUFDM0UsUUFBQSxhQUFjLFlBQVksUUFBUTtHQUFDO0dBQWM7R0FBTTtHQUFTO0VBQVEsQ0FBQztFQUN6RSxTQUFBLGFBQWUsWUFBWSxTQUFTO0dBQ2hDO0dBQ0E7R0FDQTtHQUNBO0VBQ0osQ0FBQztFQUNELFFBQUEsYUFBYyxjQUFjLE9BQU8sS0FBSyxPQUFPLFdBQVc7R0FDdEQsR0FBRztHQUNILEdBQUksVUFBVSxRQUFRLElBQUksRUFBRSxTQUFTLElBQUksQ0FBQztJQUN6QyxVQUFVLElBQUksUUFBUSxVQUFVLFdBQVc7RUFDaEQsRUFBRSxHQUFHO0dBQUM7R0FBUTtHQUFTO0VBQVEsQ0FBQztDQUNwQztBQUNKOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFrQ0EsSUFBTSxjQUFjLFVBQVUsTUFBTSxPQUFPLGNBQWMsS0FBSyxDQUFDO0FBRS9ELElBQU0sY0FBYyxVQUFXLE9BQU8sU0FBUyxlQUFlLGlCQUFpQixRQUMxRSxPQUFPLFNBQVMsZUFBZSxpQkFBaUI7QUFDckQsSUFBTSxrQkFBa0IsVUFBVSxPQUFPLGFBQWEsZUFBZSxpQkFBaUI7QUFDdEYsSUFBTSxXQUFXLFFBQVE7Q0FDckIsTUFBTSxTQUFTLENBQUM7Q0FDaEIsS0FBSyxNQUFNLE9BQU8sT0FBTyxLQUFLLEdBQUcsR0FDN0IsSUFBSSxhQUFhLElBQUksSUFBSSxLQUNyQixJQUFJLFNBQVMsUUFDYixDQUFDLGFBQWEsSUFBSSxJQUFJLEtBQ3RCLENBQUMsV0FBVyxJQUFJLElBQUksS0FDcEIsQ0FBQyxlQUFlLElBQUksSUFBSSxHQUFHO0VBQzNCLE1BQU0sU0FBUyxRQUFRLElBQUksSUFBSTtFQUMvQixLQUFLLE1BQU0sYUFBYSxPQUFPLEtBQUssTUFBTSxHQUN0QyxPQUFPLEdBQUcsSUFBSSxHQUFHLGVBQWUsT0FBTztDQUUvQyxPQUVJLE9BQU8sT0FBTyxJQUFJO0NBRzFCLE9BQU87QUFDWDtBQUVBLFNBQVMsZUFBZSxNQUFNO0NBQzFCLE1BQU0sU0FBUyxJQUFJLFNBQVM7Q0FDNUIsTUFBTSxvQkFBb0IsUUFBUSxJQUFJO0NBQ3RDLEtBQUssTUFBTSxPQUFPLG1CQUFtQjtFQUNqQyxNQUFNLFFBQVEsa0JBQWtCO0VBQ2hDLElBQUksWUFBWSxLQUFLLEdBQ2pCO0VBRUosSUFBSSxPQUFPLGFBQWEsZUFBZSxpQkFBaUIsVUFBVTtHQUM5RCxLQUFLLElBQUksUUFBUSxHQUFHLFFBQVEsTUFBTSxRQUFRLFNBQVM7SUFDL0MsTUFBTSxPQUFPLE1BQU07SUFDbkIsUUFBUSxPQUFPLE9BQU8sS0FBSyxJQUFJO0dBQ25DO0dBQ0E7RUFDSjtFQUNBLE9BQU8sT0FBTyxLQUFLLEtBQUs7Q0FDNUI7Q0FDQSxPQUFPO0FBQ1g7QUFFQSxTQUFTLGtCQUFrQixPQUFPO0NBQzlCLElBQUk7RUFDQSxPQUFPLEtBQUssVUFBVSxLQUFLO0NBQy9CLFNBQ08sSUFBSTtFQUNQLE9BQU87Q0FDWDtBQUNKO0FBRUEsU0FBUyxPQUFPLENBQUU7QUFFbEIsSUFBTSxlQUFlO0FBQ3JCLFNBQVMsc0JBQXNCLFFBQVE7Q0FDbkMsT0FBTyxVQUFVLE9BQU8sU0FBUztBQUNyQzs7Ozs7Ozs7Ozs7Ozs7O0FBZUEsU0FBUyxLQUFLLE9BQU87Q0FDakIsTUFBTSxjQUFjLHNCQUFzQjtDQUMxQyxNQUFNLENBQUMsU0FBUyxjQUFBLGFBQW9CLFNBQVMsS0FBSztDQUNsRCxNQUFNLEVBQUUsVUFBVSxhQUFhLFdBQVcsTUFBTSxVQUFVLFFBQVEsU0FBUyxjQUFjLFNBQVMsU0FBUyxVQUFVLE1BQU0sUUFBUSxZQUFZLE1BQU0saUJBQWlCLHVCQUF1QixHQUFHLFNBQVM7Q0FDek0sTUFBTSxlQUFBLGFBQXFCLGNBQWM7RUFDckMsT0FBTyxRQUFRLGFBQWEsT0FBTyxNQUFNLFVBQVU7R0FDL0MsTUFBTSxXQUFXLGVBQWUsSUFBSTtHQUNwQyxNQUFNLGVBQWUsa0JBQWtCLElBQUk7R0FDM0MsSUFBSSxVQUNBLE1BQU0sU0FBUztJQUNYO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7R0FDSixDQUFDO0dBRUwsSUFBSSxTQUFTLE1BQU0sR0FDZixJQUFJO0lBQ0EsTUFBTSxlQUFlLFVBQVUsb0NBQW9DLEtBQUssS0FBSztJQUM3RSxNQUFNLGNBQWMsV0FBVyxDQUFDLFlBQVksT0FBTyxJQUFJLFVBQVUsS0FBQTtJQUNqRSxNQUFNLGtCQUFrQixTQUFTLGNBQzNCLEtBQUssS0FBSyxXQUFXLElBQ3BCLFdBQ0MsT0FBTyxRQUFRLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLFdBQVcsS0FBSyxZQUFZLE1BQU0sa0JBQWtCLEtBQUssS0FBSyxLQUFLLENBQUMsS0FDeEcsV0FBVyxLQUFLLEtBQUssT0FBTztJQUNyQyxJQUFJLE9BQU87SUFDWCxJQUFJLGVBQWUsT0FBTyxHQUN0QixPQUFPO1NBRU4sSUFBSSxlQUFlLGlEQUFpRCxHQUNyRSxPQUFPLElBQUksZ0JBQWdCLE1BQU0sS0FBSyxXQUFXLENBQUMsTUFBTSxXQUFXLENBQy9ELE1BQ0EsU0FBUyxLQUFLLElBQUksUUFBUSxNQUFNLElBQ3BDLENBQUMsQ0FBQztTQUVELElBQUksZUFBZSwwQkFBMEIsR0FDOUMsT0FBTyxNQUFNLEtBQUssV0FBVyxDQUFDLE1BQU0sV0FBVyxHQUFHLEtBQUssR0FBRyxTQUFTLEtBQUssSUFBSSxRQUFRLE1BQU0sS0FBSyxLQUFLLENBQUMsQ0FBQyxLQUFLLEVBQUU7SUFFakgsTUFBTSxXQUFXLE1BQU0sTUFBTSxRQUFRO0tBQ2pDO0tBQ0EsU0FBUztNQUNMLEdBQUcsT0FBTyxZQUFZLE9BQU8sUUFBUSxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sV0FBVyxLQUFLLFlBQVksTUFBTSxrQkFDaEcsQ0FBQyxlQUFlLENBQUMsWUFBWSxLQUFLLENBQUUsQ0FBQztNQUMxQyxHQUFJLGVBQWUsRUFBRSxnQkFBZ0IsWUFBWTtLQUNyRDtLQUNBO0lBQ0osQ0FBQztJQUNELElBQUksWUFBWSxDQUFDLGVBQWUsU0FBUyxNQUFNLEdBQUc7S0FDOUMsUUFBUSxFQUFFLFNBQVMsQ0FBQztLQUNwQixPQUFPLEVBQUUsTUFBTSxPQUFPLFNBQVMsTUFBTSxFQUFFO0lBQzNDLE9BRUksVUFBVSxFQUFFLFNBQVMsQ0FBQztHQUU5QixTQUNPLE9BQU87SUFDVixRQUFRLEVBQUUsTUFBTSxDQUFDO0lBQ2pCLE9BQU8sRUFBRSxNQUFNLEdBQUc7R0FDdEI7R0FFSixJQUFJLFdBQVcsTUFBTSxHQUNqQixJQUFJO0lBQ0EsTUFBTSxPQUFPLFFBQVE7R0FDekIsU0FDTyxPQUFPO0lBQ1YsUUFBUSxFQUFFLE1BQU0sQ0FBQztJQUNqQixPQUFPLEVBQUUsTUFBTSxHQUFHO0dBQ3RCO0VBSVIsQ0FBQztDQUNMLEdBQUc7RUFDQztFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDSixDQUFDO0NBQ0QsTUFBTSxTQUFBLGFBQWUsWUFBWSxPQUFPLFVBQVU7RUFDOUMsTUFBTSxNQUFNLE1BQU0sYUFBYSxLQUFLO0VBQ3BDLElBQUksT0FBTyxTQUFTO0dBQ2hCLFFBQVEsVUFBVSxNQUFNLEtBQUssRUFBRSxvQkFBb0IsTUFBTSxDQUFDO0dBQzFELFFBQVEsU0FBUyxlQUFlLEdBQUc7RUFDdkM7Q0FDSixHQUFHLENBQUMsY0FBYyxPQUFPLENBQUM7Q0FDMUIsYUFBTSxnQkFBZ0I7RUFDbEIsV0FBVyxJQUFJO0NBQ25CLEdBQUcsQ0FBQyxDQUFDO0NBQ0wsSUFBSSxRQUNBLE9BQU8sT0FBTyxFQUFFLE9BQU8sQ0FBQztDQUs1QixPQUFBLGFBQWMsY0FBYyxRQUFRO0VBQUUsWUFBWTtFQUFpQjtFQUFRLEdBQUksQ0FBQyxXQUFXLE1BQU0sS0FBSztHQUFFO0dBQVE7RUFBUTtFQUFJLFVBQVU7RUFBUSxHQUFHO0NBQUssR0FBRyxRQUFRO0FBQ3JLO0FBRUEsSUFBTSxhQUFhLEVBQUUsU0FBUyxVQUFVLE9BQU8sTUFBTSxhQUFjLE9BQU8sYUFBYTtDQUFFO0NBQVM7Q0FBTTtDQUFVO0FBQU0sQ0FBQyxDQUFDOztBQUUxSCxJQUFNLHFCQUFxQjtBQUUzQixJQUFJLHNCQUFzQjtDQUN0QixJQUFJLDZCQUFhLElBQUksSUFBSTtDQUN6QixJQUFJLGtCQUFrQjtDQUN0QixNQUFNLFFBQVEsVUFBVTtFQUNwQixNQUFNLFlBQVk7RUFDbEI7RUFDQSxLQUFLLE1BQU0sWUFBWSxXQUNuQixTQUFTLFFBQVEsU0FBUyxLQUFLLEtBQUs7RUFFeEMsY0FBYyxjQUFjO0NBQ2hDO0NBQ0EsTUFBTSxhQUFhLGFBQWE7RUFDNUIsV0FBVyxJQUFJLFFBQVE7RUFDdkIsT0FBTyxFQUNILG1CQUFtQjtHQUNmLElBQUksaUJBQWlCO0lBQ2pCLGFBQWEsSUFBSSxJQUFJLFVBQVU7SUFDL0Isa0JBQWtCO0dBQ3RCO0dBQ0EsV0FBVyxPQUFPLFFBQVE7RUFDOUIsRUFDSjtDQUNKO0NBQ0EsTUFBTSxvQkFBb0I7RUFDdEIsNkJBQWEsSUFBSSxJQUFJO0VBQ3JCLGtCQUFrQjtDQUN0QjtDQUNBLE9BQU87RUFDSCxJQUFJLFlBQVk7R0FDWixPQUFPLE1BQU0sS0FBSyxVQUFVO0VBQ2hDO0VBQ0E7RUFDQTtFQUNBO0NBQ0o7QUFDSjtBQUVBLFNBQVMsa0JBQWtCLGFBQWEsWUFBWTtDQUNoRCxNQUFNLFNBQVUsTUFBTSxRQUFRLFdBQVcsSUFBSSxDQUFDLElBQUksQ0FBQztDQUNuRCxLQUFLLE1BQU0sT0FBTyxhQUNkLElBQUksT0FBTyxVQUFVLGVBQWUsS0FBSyxhQUFhLEdBQUcsR0FBRztFQUN4RCxNQUFNLGFBQWEsWUFBWTtFQUMvQixNQUFNLGFBQWEsV0FBVztFQUM5QixJQUFJLGVBQ0MsU0FBUyxVQUFVLEtBQUssTUFBTSxRQUFRLFVBQVUsTUFDakQsWUFDQSxPQUFPLE9BQU8sa0JBQWtCLFlBQVksVUFBVTtPQUVyRCxJQUFJLFlBQVksTUFDakIsT0FBTyxPQUFPO0NBRXRCO0NBRUosT0FBTztBQUNYO0FBRUEsSUFBTSxVQUFVLE9BQU8sUUFBUSxVQUFVLFFBQ3JDLGFBQWEsS0FBSyxLQUNsQixPQUFPLFVBQVUsZUFBZSxLQUFLLE9BQU8sR0FBRztBQUNuRCxJQUFJLE9BQU8sUUFBUSxTQUFTO0NBQ3hCLElBQUksQ0FBQyxNQUNELE9BQU87Q0FFWCxJQUFJLFNBQVM7Q0FDYixLQUFLLE1BQU0sT0FBTyxNQUFNLElBQUksSUFBSSxDQUFDLElBQUksSUFBSSxhQUFhLElBQUksR0FBRztFQUN6RCxJQUFJLENBQUMsT0FBTyxRQUFRLEdBQUcsR0FFbkIsT0FBTyxPQUFPLFFBQVEsSUFBSTtFQUU5QixTQUFTLE9BQU87Q0FDcEI7Q0FDQSxPQUFPO0FBQ1g7QUFFQSxJQUFJLG9CQUFvQixZQUFZLFFBQVEsU0FBUztBQUVyRCxJQUFNLGtCQUFrQixXQUFXO0NBQy9CLE1BQU0sVUFBVSxDQUFDLEdBQUcsT0FBTyxPQUFPO0NBQ2xDLE9BQU8sQ0FBQyxPQUFPLFlBQ1gsT0FBTyxPQUFPLEtBQ2QsQ0FBQyxRQUFRLE1BQU0sV0FBVyxPQUFPLGVBQWUsSUFDOUMsT0FBTyxrQkFDTCxRQUFRLFdBQVcsV0FBVztFQUMxQixJQUFJO0VBQ0osT0FBTyxDQUFDLE9BQU8sWUFDWCxHQUFHLEtBQUssT0FBTyxtQkFBbUIsUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRyxRQUFRLG9CQUFvQjtDQUMxRyxDQUFDLElBQ0gsUUFBUSxNQUFNLFdBQVcsT0FBTyxhQUFhLE9BQU8sZUFBZTtBQUM3RTtBQUNBLElBQUksWUFBWSxRQUFRLGdCQUFnQixHQUFHLElBQ3JDLElBQUksWUFBWSxJQUFJLGlCQUNwQixJQUFJLFNBQVMsZ0JBQWdCLGlCQUFpQixHQUFHLElBQzdDLGVBQWUsR0FBRyxJQUNsQixDQUFDLGFBQWEsR0FBRyxLQUNmLElBQUksU0FBUyxXQUNiLElBQUksU0FBUyxXQUNiLGtCQUFrQixPQUNsQixJQUFJLFVBQVUsSUFBSTtBQUU5QixJQUFJLHFCQUFxQixRQUFRLGFBQWEsR0FBRyxLQUFLLGdCQUFnQixHQUFHO0FBRXpFLElBQUksUUFBUSxRQUFRLGNBQWMsR0FBRyxLQUFLLElBQUk7QUFFOUMsU0FBUyxpQkFBaUIsT0FBTztDQUM3QixPQUFPLE1BQU0sUUFBUSxLQUFLLEtBQUssU0FBUyxLQUFLO0FBQ2pEO0FBQ0EsU0FBUyx1QkFBdUIsV0FBVyxtQkFBbUIsU0FBUyxJQUFJLFFBQVEsQ0FBQyxHQUFHO0NBQ25GLEtBQUssTUFBTSxPQUFPLFdBQVc7RUFDekIsTUFBTSxPQUFPLFNBQVMsR0FBRyxPQUFPLEdBQUcsUUFBUTtFQUMzQyxNQUFNLFFBQVEsVUFBVTtFQUN4QixJQUFJLGlCQUFpQixLQUFLLEtBQ3RCLGlCQUFpQixJQUFJLG1CQUFtQixJQUFJLENBQUMsR0FDN0MsdUJBQXVCLE9BQU8sbUJBQW1CLE1BQU0sS0FBSztPQUUzRCxJQUFJLE9BQ0wsTUFBTSxLQUFLLElBQUk7Q0FFdkI7Q0FDQSxPQUFPO0FBQ1g7QUFFQSxJQUFJLHFCQUFxQixTQUFTO0NBQzlCLEtBQUssTUFBTSxPQUFPLE1BQ2QsSUFBSSxXQUFXLEtBQUssSUFBSSxHQUNwQixPQUFPO0NBR2YsT0FBTztBQUNYO0FBRUEsU0FBUyxjQUFjLE9BQU87Q0FDMUIsT0FBTyxNQUFNLFFBQVEsS0FBSyxLQUFNLFNBQVMsS0FBSyxLQUFLLENBQUMsa0JBQWtCLEtBQUs7QUFDL0U7QUFDQSxTQUFTLGlCQUFpQixVQUFVO0NBQ2hDLE9BQU8sQ0FBQyxFQUFFLFlBQVksUUFBUTtBQUNsQztBQUNBLFNBQVMsc0JBQXNCLE9BQU87Q0FDbEMsT0FBTyxNQUFNLFFBQVEsS0FBSyxJQUNwQixDQUFDLE1BQU0sTUFBTSxTQUFTLENBQUMsWUFBWSxJQUFJLENBQUMsSUFDeEMsQ0FBQyxPQUFPLEtBQUssS0FBSyxDQUFDLENBQUM7QUFDOUI7QUFDQSxTQUFTLGdCQUFnQixXQUFXLEtBQUs7Q0FDckMsSUFBSSxNQUFNLFFBQVEsU0FBUyxHQUN2QixVQUFVLE9BQU8sS0FBQTtNQUdqQixPQUFPLFVBQVU7QUFFekI7QUFDQSxTQUFTLGdCQUFnQixNQUFNLFNBQVMsQ0FBQyxHQUFHLFdBQVc7Q0FDbkQsS0FBSyxNQUFNLE9BQU8sTUFBTTtFQUNwQixNQUFNLFFBQVEsS0FBSztFQUNuQixNQUFNLFdBQVcsYUFBYSxVQUFVO0VBQ3hDLElBQUksY0FBYyxLQUFLLE1BQ2xCLENBQUMsTUFBTSxRQUFRLEtBQUssS0FBSyxDQUFDLGlCQUFpQixRQUFRLElBQUk7R0FDeEQsT0FBTyxPQUFPLE1BQU0sUUFBUSxLQUFLLElBQUksQ0FBQyxJQUFJLENBQUM7R0FDM0MsZ0JBQWdCLE9BQU8sT0FBTyxNQUFNLFFBQVE7R0FDNUMsSUFBSSxzQkFBc0IsT0FBTyxJQUFJLEdBQ2pDLGdCQUFnQixRQUFRLEdBQUc7RUFFbkMsT0FDSyxJQUFJLENBQUMsWUFBWSxLQUFLLEdBQ3ZCLE9BQU8sT0FBTztDQUV0QjtDQUNBLE9BQU87QUFDWDtBQUNBLFNBQVMsZUFBZSxNQUFNLFlBQVksdUJBQXVCLFdBQVc7Q0FDeEUsSUFBSSxDQUFDLHVCQUNELHdCQUF3QixnQkFBZ0IsWUFBYSxNQUFNLFFBQVEsa0JBQWtCLFVBQVUsSUFBSSxPQUFPLFVBQVUsSUFDOUcsQ0FBQyxJQUNELENBQUMsR0FBSSxTQUFTO0NBRXhCLEtBQUssTUFBTSxPQUFPLE1BQU07RUFDcEIsTUFBTSxRQUFRLEtBQUs7RUFDbkIsTUFBTSxXQUFXLGFBQWEsVUFBVTtFQUN4QyxJQUFJLGNBQWMsS0FBSyxNQUNsQixDQUFDLE1BQU0sUUFBUSxLQUFLLEtBQUssQ0FBQyxpQkFBaUIsUUFBUSxJQUFJO0dBQ3hELElBQUksWUFBWSxVQUFVLEtBQUssWUFBWSxzQkFBc0IsSUFBSSxHQUNqRSxzQkFBc0IsT0FBTyxnQkFBZ0IsT0FBUSxNQUFNLFFBQVEsS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUksUUFBUTtRQUc5RixlQUFlLE9BQU8sa0JBQWtCLFVBQVUsSUFBSSxDQUFDLElBQUksV0FBVyxNQUFNLHNCQUFzQixNQUFNLFFBQVE7R0FFcEgsSUFBSSxzQkFBc0Isc0JBQXNCLElBQUksR0FDaEQsZ0JBQWdCLHVCQUF1QixHQUFHO0VBRWxELE9BQ0ssSUFBSSxVQUFVLE9BQU8sa0JBQWtCLFVBQVUsSUFBSSxLQUFBLElBQVksV0FBVyxJQUFJLEdBQ2pGLGdCQUFnQix1QkFBdUIsR0FBRztPQUcxQyxzQkFBc0IsT0FBTztDQUVyQztDQUNBLE9BQU87QUFDWDtBQUVBLElBQUksMEJBQTBCLE9BQU8sU0FBUztDQUMxQyxNQUFNLFdBQVcsS0FBSyxNQUFNLEdBQUc7Q0FDL0IsTUFBTSxVQUFVLENBQUM7Q0FDakIsSUFBSSxTQUFTLFNBQVM7Q0FDdEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxVQUFVLE1BQU0sU0FBUyxNQUMxRCxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxLQUFLLE1BQU0sSUFBSSxNQUFNLEdBQ3hDLFFBQVEsS0FBSyxHQUFHLE9BQU8sR0FBRyxTQUFTLElBQUk7Q0FHL0MsT0FBTztBQUNYO0FBRUEsSUFBSSxtQkFBbUIsT0FBTyxFQUFFLGVBQWUsYUFBYSxpQkFBaUIsWUFBWSxLQUFLLElBQ3hGLFFBQ0EsZ0JBQ0ksVUFBVSxLQUNOLE1BQ0EsUUFDSSxDQUFDLFFBQ0QsUUFDUixlQUFlLFNBQVMsS0FBSyxJQUN6QixJQUFJLEtBQUssS0FBSyxJQUNkLGFBQ0ksV0FBVyxLQUFLLElBQ2hCO0FBRWxCLFNBQVMsY0FBYyxJQUFJO0NBQ3ZCLE1BQU0sTUFBTSxHQUFHO0NBQ2YsSUFBSSxZQUFZLEdBQUcsR0FDZixPQUFPLElBQUk7Q0FFZixJQUFJLGFBQWEsR0FBRyxHQUNoQixPQUFPLGNBQWMsR0FBRyxJQUFJLENBQUMsQ0FBQztDQUVsQyxJQUFJLGlCQUFpQixHQUFHLEdBQ3BCLE9BQU8sQ0FBQyxHQUFHLElBQUksZUFBZSxDQUFDLENBQzFCLFFBQVEsV0FBVztFQUFFLElBQUk7RUFBSSxPQUFPLENBQUMsT0FBTyxZQUFZLEdBQUcsS0FBSyxPQUFPLGFBQWEsUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRyxLQUFLLFFBQVEsb0JBQW9CO0NBQUksQ0FBQyxDQUFDLENBQy9KLEtBQUssRUFBRSxZQUFZLEtBQUs7Q0FFakMsSUFBSSxnQkFBZ0IsR0FBRyxHQUNuQixPQUFPLGlCQUFpQixHQUFHLElBQUksQ0FBQyxDQUFDO0NBRXJDLE9BQU8sZ0JBQWdCLElBQUksT0FBTyxFQUFFO0FBQ3hDO0FBRUEsSUFBSSxzQkFBc0IsYUFBYSxTQUFTLGNBQWMsOEJBQThCO0NBQ3hGLE1BQU0sU0FBUyxDQUFDO0NBQ2hCLEtBQUssTUFBTSxRQUFRLGFBQWE7RUFDNUIsTUFBTSxRQUFRLElBQUksU0FBUyxJQUFJO0VBQy9CLFNBQVMsSUFBSSxRQUFRLE1BQU0sWUFBWSxNQUFNLEVBQUUsQ0FBQztDQUNwRDtDQUNBLE9BQU87RUFDSDtFQUNBLE9BQU8sQ0FBQyxHQUFHLFdBQVc7RUFDdEI7RUFDQTtDQUNKO0FBQ0o7QUFFQSxJQUFJLGdCQUFnQixTQUFTLFlBQVksSUFBSSxJQUN2QyxPQUNBLFFBQVEsSUFBSSxJQUNSLEtBQUssU0FDTCxTQUFTLElBQUksSUFDVCxRQUFRLEtBQUssS0FBSyxJQUNkLEtBQUssTUFBTSxTQUNYLEtBQUssUUFDVDtBQUVkLElBQU0saUJBQWlCO0FBQ3ZCLElBQUksd0JBQXdCLG1CQUFtQjtDQUMzQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsZUFBZSxVQUNuQyxPQUFPO0NBQ1gsSUFBSSxXQUFXLGVBQWUsUUFBUSxHQUNsQyxPQUFPLGVBQWUsU0FBUyxZQUFZLFNBQVM7Q0FFeEQsSUFBSSxTQUFTLGVBQWUsUUFBUSxHQUMzQjtPQUFBLE1BQU0sT0FBTyxlQUFlLFVBQzdCLElBQUksZUFBZSxTQUFTLElBQUksQ0FBQyxZQUFZLFNBQVMsZ0JBQ2xELE9BQU87Q0FBQTtDQUluQixPQUFPO0FBQ1g7QUFFQSxJQUFJLGlCQUFpQixZQUFZLFFBQVEsVUFDcEMsUUFBUSxZQUNKLENBQUMsWUFBWSxRQUFRLFFBQVEsS0FBSyxRQUFRLGFBQWEsU0FDeEQsQ0FBQyxZQUFZLFFBQVEsR0FBRyxLQUN4QixDQUFDLFlBQVksUUFBUSxHQUFHLEtBQ3hCLENBQUMsWUFBWSxRQUFRLFNBQVMsS0FDOUIsQ0FBQyxZQUFZLFFBQVEsU0FBUyxLQUM5QixRQUFRLFdBQ1IsUUFBUTtBQUVoQixTQUFTLGtCQUFrQixRQUFRLFNBQVMsTUFBTTtDQUM5QyxNQUFNLFFBQVEsSUFBSSxRQUFRLElBQUk7Q0FDOUIsSUFBSyxVQUFVLE1BQU0sUUFBUSxNQUFNLFlBQWEsTUFBTSxRQUFRLEtBQUssR0FDL0QsT0FBTztFQUNIO0VBQ0E7Q0FDSjtDQUVKLE1BQU0sUUFBUSxLQUFLLE1BQU0sR0FBRztDQUM1QixPQUFPLE1BQU0sUUFBUTtFQUNqQixNQUFNLFlBQVksTUFBTSxLQUFLLEdBQUc7RUFDaEMsTUFBTSxRQUFRLElBQUksU0FBUyxTQUFTO0VBQ3BDLE1BQU0sYUFBYSxJQUFJLFFBQVEsU0FBUztFQUN4QyxJQUFJLFNBQVMsQ0FBQyxNQUFNLFFBQVEsS0FBSyxLQUFLLFNBQVMsV0FDM0MsT0FBTyxFQUFFLEtBQUs7RUFFbEIsSUFBSSxjQUFjLFdBQVcsTUFDekIsT0FBTztHQUNILE1BQU07R0FDTixPQUFPO0VBQ1g7RUFFSixJQUFJLGNBQWMsV0FBVyxRQUFRLFdBQVcsS0FBSyxNQUNqRCxPQUFPO0dBQ0gsTUFBTSxHQUFHLFVBQVU7R0FDbkIsT0FBTyxXQUFXO0VBQ3RCO0VBRUosTUFBTSxJQUFJO0NBQ2Q7Q0FDQSxPQUFPLEVBQ0gsS0FDSjtBQUNKO0FBRUEsSUFBSSx5QkFBeUIsZUFBZSxpQkFBaUIsV0FBVztDQUNwRSxNQUFNLE9BQU8sT0FBTyxLQUFLLGFBQWEsQ0FBQyxDQUFDLFFBQVEsUUFBUSxRQUFRLE1BQU07Q0FDdEUsT0FBUSxDQUFDLEtBQUssVUFDVCxVQUFVLEtBQUssVUFBVSxPQUFPLEtBQUssZUFBZSxDQUFDLENBQUMsVUFDdkQsS0FBSyxNQUFNLFFBQVEsZ0JBQWdCLFVBQzlCLENBQUMsVUFBVSxnQkFBZ0IsSUFBSTtBQUM1QztBQUVBLElBQU0sZUFBZSxhQUFhLFlBQVksVUFBVSxRQUNsRCxnQkFBZ0IsY0FBYyxZQUFZLFdBQVcsYUFBYSxHQUFHLElBQ3JFLFlBQVksV0FBVyxVQUFVLEtBQUssV0FBVyxXQUFXLFdBQVc7QUFDN0UsSUFBSSx5QkFBeUIsTUFBTSxZQUFZLFVBQVU7Q0FDckQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxjQUFjLFNBQVMsWUFDakMsT0FBTztDQUVYLElBQUksQ0FBQyxNQUFNLFFBQVEsSUFBSSxHQUNuQixPQUFPLFlBQVksTUFBTSxZQUFZLEtBQUs7Q0FFOUMsS0FBSyxNQUFNLGVBQWUsTUFDdEIsSUFBSSxlQUFlLFlBQVksYUFBYSxZQUFZLEtBQUssR0FDekQsT0FBTztDQUdmLE9BQU87QUFDWDtBQUVBLElBQUksa0JBQWtCLGFBQWEsV0FBVyxhQUFhLGdCQUFnQixTQUFTO0NBQ2hGLElBQUksS0FBSyxTQUNMLE9BQU87TUFFTixJQUFJLENBQUMsZUFBZSxLQUFLLFdBQzFCLE9BQU8sRUFBRSxhQUFhO01BRXJCLElBQUksY0FBYyxlQUFlLFdBQVcsS0FBSyxVQUNsRCxPQUFPLENBQUM7TUFFUCxJQUFJLGNBQWMsZUFBZSxhQUFhLEtBQUssWUFDcEQsT0FBTztDQUVYLE9BQU87QUFDWDtBQUVBLElBQUksbUJBQW1CLEtBQUssU0FBUztDQUNqQyxNQUFNLFFBQVEsSUFBSSxLQUFLLElBQUk7Q0FDM0IsQ0FBQyxRQUFRLEtBQUssQ0FBQyxDQUFDLFVBQ1osRUFBRSxTQUFTLE1BQU0sU0FDakIsTUFBTSxLQUFLLElBQUk7QUFDdkI7QUFFQSxJQUFNLGlCQUFpQjtDQUNuQixNQUFNLGdCQUFnQjtDQUN0QixnQkFBZ0IsZ0JBQWdCO0NBQ2hDLGtCQUFrQjtBQUN0QjtBQUNBLElBQU0sNkJBQTZCLGFBQWEsb0JBQW9CO0NBQ2hFLEtBQUssTUFBTSxPQUFPLGFBQ2QsT0FBTyxZQUFZO0NBRXZCLE9BQU8sT0FBTyxhQUFhLGVBQWU7QUFDOUM7QUFDQSxJQUFNLHFCQUFxQjtDQUN2QixhQUFhO0NBQ2IsU0FBUztDQUNULFNBQVM7Q0FDVCxjQUFjO0NBQ2QsYUFBYTtDQUNiLGNBQWM7Q0FDZCxvQkFBb0I7Q0FDcEIsU0FBUztDQUNULGVBQWUsQ0FBQztDQUNoQixhQUFhLENBQUM7Q0FDZCxrQkFBa0IsQ0FBQztBQUN2QjtBQUNBLFNBQVMsa0JBQWtCLFFBQVEsQ0FBQyxHQUFHO0NBQ25DLElBQUksV0FBVztFQUNYLEdBQUc7RUFDSCxHQUFHO0NBQ1A7Q0FDQSxJQUFJLGFBQWE7RUFDYixHQUFHLFlBQVksa0JBQWtCO0VBQ2pDLFdBQVcsV0FBVyxTQUFTLGFBQWE7RUFDNUMsUUFBUSxZQUFZLFNBQVMsTUFBTSxLQUFLLENBQUM7RUFDekMsVUFBVSxTQUFTLFlBQVk7Q0FDbkM7Q0FDQSxJQUFJLFVBQVUsQ0FBQztDQUNmLElBQUksaUJBQWlCLFNBQVMsU0FBUyxhQUFhLEtBQUssU0FBUyxTQUFTLE1BQU0sSUFDM0UsWUFBWSxTQUFTLGlCQUFpQixTQUFTLE1BQU0sS0FBSyxDQUFDLElBQzNELENBQUM7Q0FDUCxJQUFJLGNBQWMsU0FBUyxtQkFDckIsQ0FBQyxJQUNELFlBQVksY0FBYztDQUNoQyxJQUFJLFNBQVM7RUFDVCxRQUFRO0VBQ1Isb0NBQW9CLElBQUksSUFBSTtFQUM1QixPQUFPO0VBQ1AsT0FBTztFQUNQLGFBQWE7Q0FDakI7Q0FDQSxJQUFJLG9CQUFvQjtDQUN4QixJQUFJLFNBQVM7RUFDVCx1QkFBTyxJQUFJLElBQUk7RUFDZiwwQkFBVSxJQUFJLElBQUk7RUFDbEIseUJBQVMsSUFBSSxJQUFJO0VBQ2pCLHVCQUFPLElBQUksSUFBSTtFQUNmLHVCQUFPLElBQUksSUFBSTtFQUNmLDhCQUFjLElBQUksSUFBSTtDQUMxQjtDQUNBLE1BQU0sc0JBQXNCLENBQUM7Q0FDN0IsTUFBTSxTQUFTLENBQUM7Q0FDaEIsTUFBTSxxQ0FBcUIsSUFBSSxJQUFJO0NBQ25DLElBQUksOEJBQThCLG1CQUFtQixTQUFTLElBQUk7Q0FDbEUsSUFBSSw2QkFBNkIsbUJBQW1CLFNBQVMsY0FBYztDQUMzRSxNQUFNLHdCQUF3QjtFQUMxQixTQUFTO0VBQ1QsYUFBYTtFQUNiLGtCQUFrQjtFQUNsQixlQUFlO0VBQ2YsY0FBYztFQUNkLFNBQVM7RUFDVCxRQUFRO0NBQ1o7Q0FDQSxNQUFNLGtCQUFrQixFQUNwQixHQUFHLHNCQUNQO0NBQ0EsTUFBTSwyQkFBMkIsQ0FBQztDQUNsQyxNQUFNLGNBQWMsR0FBRyxTQUFTLEtBQUssTUFBTSxRQUFRLGdCQUFnQixRQUFRLHlCQUF5QixJQUFJO0NBQ3hHLE1BQU0sd0JBQXdCLFNBQVM7RUFDbkMsS0FBSyxNQUFNLGNBQWMsb0JBQ3JCLElBQUksc0JBQXNCLFdBQVcsTUFBTSxNQUFNLFdBQVcsS0FBSyxHQUM3RCxPQUFPO0VBR2YsT0FBTztDQUNYO0NBQ0EsTUFBTSxZQUFZO0VBQ2QsT0FBTyxjQUFjO0VBQ3JCLE9BQU8sY0FBYztDQUN6QjtDQUNBLElBQUksa0JBQWtCO0NBQ3RCLElBQUksc0JBQXNCO0NBQzFCLElBQUksZUFBZTtDQUNuQixJQUFJLGtCQUFrQjtDQUN0QixNQUFNLG1CQUFtQixDQUFDO0NBQzFCLElBQUksbUNBQW1DLFNBQVMsaUJBQWlCLGdCQUFnQjtDQUNqRixNQUFNLFlBQVksTUFBTSxjQUFjLFNBQVM7RUFDM0MsYUFBYSxPQUFPLEtBQUs7RUFDekIsT0FBTyxRQUFRLFdBQVcsVUFBVSxJQUFJO0NBQzVDO0NBQ0EsTUFBTSxzQkFBc0IsU0FBUztFQUNqQyxhQUFhLE9BQU8sS0FBSztFQUN6QixPQUFPLE9BQU87RUFDZCxPQUFPLG9CQUFvQjtDQUMvQjtDQUNBLE1BQU0sMEJBQTBCLFNBQVM7RUFDckMsbUJBQW1CLElBQUk7RUFDdkIsTUFBTSxTQUFTLEdBQUcsS0FBSztFQUN2QixLQUFLLE1BQU0sT0FBTyxPQUFPLEtBQUssbUJBQW1CLEdBQzdDLElBQUksV0FBVyxNQUFNLEtBQUssbUJBQW1CLEdBQUc7Q0FFeEQ7Q0FDQSxNQUFNLFlBQVksT0FBTyxzQkFBc0I7RUFDM0MsSUFBSSxPQUFPLGFBQ1A7RUFFSixJQUFJLENBQUMsU0FBUyxhQUFhLFdBQVcsU0FBUyxLQUFLLG9CQUFvQjtHQUNwRSxNQUFNLFNBQVMsRUFBRTtHQUNqQixNQUFNLGNBQWM7R0FDcEIsSUFBSTtHQUNKLElBQUksU0FBUyxVQUFVO0lBQ25CLFVBQVUsZUFBZSxNQUFNLFdBQVcsRUFBQSxDQUFHLE1BQU07SUFDbkQsV0FBVyxtQkFBbUIsb0JBQW9CO0dBQ3RELE9BRUksVUFBVSxNQUFNLHlCQUF5QjtJQUNyQyxRQUFRO0lBQ1IsZ0JBQWdCO0lBQ2hCLFdBQVcsT0FBTztHQUN0QixDQUFDO0dBRUwsSUFBSSxXQUFXLGlCQUNYO0dBRUosSUFBSSxnQkFBZ0IsY0FDaEIsT0FBTyxVQUFVLGlCQUFpQjtHQUV0QyxJQUFJLFlBQVksV0FBVyxTQUN2QixVQUFVLE1BQU0sS0FBSyxFQUNqQixRQUNKLENBQUM7RUFFVDtDQUNKO0NBQ0EsTUFBTSwyQkFBMkIsT0FBTyxpQkFBaUI7RUFDckQsTUFBTSxhQUFhLENBQUMsR0FBRyxLQUFLO0VBQzVCLElBQUksQ0FBQyxXQUFXLE1BQU0sU0FBUyxTQUMxQixlQUNLLElBQUksV0FBVyxrQkFBa0IsSUFBSSxNQUFNLE9BQzNDLElBQUksV0FBVyxrQkFBa0IsSUFBSSxFQUFFLEdBQzdDO0VBRUosTUFBTSxtQkFBbUIsWUFBWSxXQUFXLGdCQUFnQjtFQUNoRSxLQUFLLE1BQU0sUUFBUSxZQUNmLElBQUksTUFDQSxlQUNNLElBQUksa0JBQWtCLE1BQU0sSUFBSSxJQUNoQyxNQUFNLGtCQUFrQixJQUFJO0VBRzFDLElBQUksQ0FBQyxVQUFVLFdBQVcsa0JBQWtCLGdCQUFnQixHQUN4RCxXQUFXLG1CQUFtQjtDQUV0QztDQUNBLE1BQU0sdUJBQXVCLE9BQU8saUJBQWlCO0VBQ2pELElBQUksQ0FBQyxTQUFTLFlBQVksV0FBVyxnQkFBZ0Isa0JBQWtCLEdBQUc7R0FDdEUsd0JBQXdCLFNBQVMsT0FBTyxPQUFPLFlBQVk7R0FDM0QsVUFBVSxNQUFNLEtBQUs7SUFDakIsa0JBQWtCLFdBQVc7SUFDN0IsY0FBYyxDQUFDLGNBQWMsV0FBVyxnQkFBZ0I7R0FDNUQsQ0FBQztFQUNMO0NBQ0o7Q0FDQSxNQUFNLDJCQUEyQjtFQUM3QixXQUFXLGNBQWMsZUFBZSxnQkFBZ0IsYUFBYSxLQUFBLEdBQVcsT0FBTztDQUMzRjtDQUNBLE1BQU0sa0JBQWtCLE1BQU0sU0FBUyxDQUFDLEdBQUcsUUFBUSxNQUFNLGtCQUFrQixNQUFNLDZCQUE2QixTQUFTO0VBQ25ILElBQUksUUFBUSxVQUFVLENBQUMsU0FBUyxVQUFVO0dBQ3RDLE9BQU8sU0FBUztHQUNoQixPQUFPLGNBQWM7R0FDckIsTUFBTSxRQUFRLElBQUksU0FBUyxJQUFJO0dBQy9CLE1BQU0sWUFBWSxTQUFTLE1BQU07R0FDakMsTUFBTSxTQUFTLFlBQVksT0FBTyxPQUFPLENBQUMsR0FBRyxLQUFLLElBQUk7R0FDdEQsSUFBSSxDQUFDLE9BQU8sbUJBQW1CLElBQUksSUFBSSxHQUNuQyxPQUFPLG1CQUFtQixJQUFJLE1BQU0sTUFBTSxRQUFRLE1BQU0sSUFBSSxPQUFPLFNBQVMsQ0FBQztHQUVqRixJQUFJLDhCQUE4QixNQUFNLFFBQVEsTUFBTSxHQUFHO0lBQ3JELE1BQU0sY0FBYyxPQUFPLFFBQVEsS0FBSyxNQUFNLEtBQUssSUFBSSxLQUFLO0lBQzVELFlBQ00sSUFBSSxTQUFTLE1BQU07S0FBRSxHQUFHO0tBQWEsSUFBSTtJQUFVLENBQUMsSUFDcEQsbUJBQW1CLElBQUksU0FBUyxNQUFNLFdBQVc7R0FDM0Q7R0FDQSxNQUFNLG1CQUFtQixJQUFJLFdBQVcsUUFBUSxJQUFJO0dBQ3BELElBQUksOEJBQThCLE1BQU0sUUFBUSxnQkFBZ0IsR0FBRztJQUMvRCxNQUFNLFlBQVksaUJBQWlCO0lBQ25DLE1BQU0sU0FBUyxPQUFPLGtCQUFrQixLQUFLLE1BQU0sS0FBSyxJQUFJLEtBQUs7SUFDakUsSUFBSSxXQUNBLE9BQU8sT0FBTztJQUVsQixtQkFBbUIsSUFBSSxXQUFXLFFBQVEsTUFBTSxNQUFNO0lBQ3RELGdCQUFnQixXQUFXLFFBQVEsSUFBSTtJQUN2QyxXQUFXLFNBQVMsRUFBRSxHQUFHLFdBQVcsT0FBTztHQUMvQztHQUNBLE1BQU0scUJBQXFCLElBQUksV0FBVyxlQUFlLElBQUk7R0FDN0QsTUFBTSw0QkFBNEIsOEJBQThCLE1BQU0sUUFBUSxrQkFBa0I7R0FDaEcsSUFBSSwyQkFBMkI7SUFDM0IsTUFBTSxnQkFBZ0IsT0FBTyxvQkFBb0IsS0FBSyxNQUFNLEtBQUssSUFBSTtJQUNyRSxtQkFBbUIsSUFBSSxXQUFXLGVBQWUsTUFBTSxhQUFhO0dBQ3hFO0dBQ0EsTUFBTSxtQkFBbUIsSUFBSSxXQUFXLGFBQWEsSUFBSTtHQUN6RCxJQUFJLDhCQUE4QixNQUFNLFFBQVEsZ0JBQWdCLEdBQUc7SUFDL0QsTUFBTSxjQUFjLE9BQU8sa0JBQWtCLEtBQUssTUFBTSxLQUFLLElBQUksS0FBSztJQUN0RSxtQkFBbUIsSUFBSSxXQUFXLGFBQWEsTUFBTSxXQUFXO0dBQ3BFO0dBQ0EsSUFBSSxXQUFXLGFBQWEsR0FDeEIsbUJBQW1CO1FBR25CLG9CQUFvQjtHQUV4QixVQUFVLE1BQU0sS0FBSztJQUNqQjtJQUNBLFNBQVMsVUFBVSxNQUFNLE1BQU07SUFDL0IsYUFBYSxXQUFXO0lBQ3hCLEdBQUksNkJBQTZCLEVBQzdCLGVBQWUsV0FBVyxjQUM5QjtJQUNBLFFBQVEsV0FBVztJQUNuQixTQUFTLFdBQVc7R0FDeEIsQ0FBQztFQUNMLE9BRUksSUFBSSxhQUFhLE1BQU0sTUFBTTtDQUVyQztDQUNBLE1BQU0sZ0JBQWdCLE1BQU0sVUFBVTtFQUNsQyxJQUFJLFdBQVcsUUFBUSxNQUFNLEtBQUs7RUFDbEMsV0FBVyxTQUFTLEVBQUUsR0FBRyxXQUFXLE9BQU87RUFDM0MsVUFBVSxNQUFNLEtBQUssRUFDakIsUUFBUSxXQUFXLE9BQ3ZCLENBQUM7Q0FDTDtDQUNBLE1BQU0sY0FBYyxXQUFXO0VBQzNCLE9BQU8sS0FBSyxtQkFBbUIsQ0FBQyxDQUFDLFFBQVEsa0JBQWtCO0VBQzNELE1BQU0sWUFBWSxDQUFDLGNBQWMsTUFBTTtFQUN2QyxXQUFXLFNBQVMsWUFBWSxNQUFNO0VBQ3RDLFVBQVUsTUFBTSxLQUFLO0dBQ2pCLFFBQVEsV0FBVztHQUNuQixHQUFJLFlBQVksRUFBRSxTQUFTLE1BQU0sSUFBSSxDQUFDO0VBQzFDLENBQUM7RUFDRCxDQUFDLGFBQWEsT0FBTyxTQUFTLFVBQVU7Q0FDNUM7Q0FDQSxNQUFNLFVBQVUsU0FBUyxNQUFNLElBQUksSUFBSSxDQUFDLElBQUksSUFBSSxhQUFhLElBQUk7Q0FDakUsTUFBTSwrQkFBK0IsU0FBUztFQUMxQyxNQUFNLFdBQVcsT0FBTyxJQUFJO0VBQzVCLElBQUksYUFBYTtFQUNqQixJQUFJLGdCQUFnQjtFQUNwQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxTQUFTLEdBQUcsS0FBSztHQUMxQyxNQUFNLE1BQU0sU0FBUztHQUNyQixhQUFhLGtCQUFrQixVQUFVLElBQUksYUFBYSxXQUFXO0dBQ3JFLGdCQUFnQixrQkFBa0IsYUFBYSxJQUN6QyxnQkFDQSxjQUFjO0dBQ3BCLElBQUksZUFBZSxRQUFRLGtCQUFrQixNQUN6QyxPQUFPO0VBRWY7RUFDQSxPQUFPO0NBQ1g7Q0FDQSxNQUFNLHFCQUFxQixTQUFTO0VBQ2hDLElBQUksQ0FBQyxPQUFPLG1CQUFtQixNQUMzQixPQUFPO0VBRVgsTUFBTSxXQUFXLE9BQU8sSUFBSTtFQUM1QixJQUFJLE9BQU87RUFDWCxJQUFJLE9BQU87RUFDWCxJQUFJLGFBQWE7RUFDakIsSUFBSSx1QkFBdUI7RUFDM0IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUFLO0dBQ3RDLElBQUksa0JBQWtCLElBQUksR0FDdEIsT0FBTztHQUVYLE1BQU0sTUFBTSxTQUFTO0dBQ3JCLE9BQU8sT0FBTyxHQUFHLEtBQUssR0FBRyxRQUFRO0dBQ2pDLElBQUksTUFBTSxRQUFRLElBQUksS0FBSyxDQUFDLE9BQU8sS0FBSyxRQUNwQyxPQUFPLGVBQWUsS0FDaEIsUUFDQSxNQUFNLGFBQ0YsQ0FBQyxNQUFNLHVCQUNQO0dBRWQsSUFBSSxPQUFPLG1CQUFtQixJQUFJLElBQUksR0FBRztJQUNyQyxhQUFhLElBQUk7SUFDakIsdUJBQXVCLE9BQU8sbUJBQW1CLElBQUksSUFBSTtHQUM3RDtHQUNBLE9BQU8sS0FBSztHQUNaLElBQUksWUFBWSxJQUFJLEtBQ2hCLGVBQWUsTUFDZixJQUFJLGNBQ0osQ0FBQyxTQUFTLGNBQWMsc0JBQ3hCLE9BQU87RUFFZjtFQUNBLE9BQU87Q0FDWDtDQUNBLE1BQU0sa0JBQWtCLFNBQVM7RUFDN0IsSUFBSSxPQUFPO0VBQ1gsS0FBSyxNQUFNLE9BQU8sT0FBTyxJQUFJLEdBQUc7R0FDNUIsSUFBSSxNQUFNLFFBQVEsSUFBSSxLQUFLLENBQUMsT0FBTyxLQUFLLFFBQ3BDLE9BQU87R0FFWCxPQUFPLFFBQVEsS0FBSztFQUN4QjtFQUNBLE9BQU87Q0FDWDtDQUNBLE1BQU0sdUJBQXVCLE1BQU0sc0JBQXNCLE9BQU8sUUFBUTtFQUNwRSxNQUFNLFFBQVEsSUFBSSxTQUFTLElBQUk7RUFDL0IsSUFBSSxPQUFPO0dBQ1AsSUFBSSw0QkFBNEIsSUFBSSxLQUFLLGtCQUFrQixJQUFJLEdBQzNEO0dBRUosTUFBTSx1QkFBdUIsWUFBWSxJQUFJLGFBQWEsSUFBSSxDQUFDO0dBQy9ELE1BQU0sZUFBZSxJQUFJLGFBQWEsTUFBTSxZQUFZLEtBQUssSUFBSSxJQUFJLGdCQUFnQixJQUFJLElBQUksS0FBSztHQUNsRyxNQUFNLHNCQUFzQixDQUFDLENBQUMsT0FBTyxDQUFDLFdBQVcsV0FBVyxTQUFTLEdBQUc7R0FDeEUsSUFBSSxZQUFZLFlBQVksS0FDdkIsT0FBTyxJQUFJLGtCQUNaLHVCQUNBLHNCQUFzQjtJQUN0QixNQUFNLGFBQWEsdUJBQ2IsZUFDQSxjQUFjLE1BQU0sRUFBRTtJQUM1QixJQUFJLENBQUMsWUFBWSxVQUFVLEtBQUssQ0FBQyxlQUFlLElBQUksR0FBRztLQUNuRCxJQUFJLFdBQVcsYUFBYSxLQUN4QixDQUFDLFVBQVUsSUFBSSxhQUFhLElBQUksR0FBRyxVQUFVLEdBQzdDLG9CQUFvQjtLQUV4QixJQUFJLGFBQWEsTUFBTSxVQUFVO0tBQ2pDLElBQUkscUJBQ0Esb0JBQW9CLE1BQU0sVUFBVTtJQUU1QztHQUNKLE9BRUksY0FBYyxNQUFNLFlBQVk7R0FFcEMsSUFBSSxPQUFPLFNBQVMsQ0FBQyxPQUFPLFFBQVE7SUFDaEMsSUFBSSxTQUFTLFlBQ1QsV0FBVyxnQkFBZ0Isa0JBQWtCLEdBQzdDLFFBQVEsUUFBUSxDQUFDLENBQUMsV0FBVyxVQUFVLENBQUM7U0FHeEMsVUFBVTtJQUVkLElBQUksd0JBQ0EsV0FBVyxXQUNYLFdBQVcsU0FBUyxHQUVoQjtTQUFBLENBRFksVUFDTCxHQUFHO01BQ1YsV0FBVyxVQUFVO01BQ3JCLFVBQVUsTUFBTSxLQUFLLEVBQUUsR0FBRyxXQUFXLENBQUM7S0FDMUM7O0lBRUosSUFBSSxTQUFTLG9CQUNULHdCQUNBLENBQUMsWUFBWSxJQUFJLGFBQWEsSUFBSSxDQUFDLEtBQ25DLFVBQVUsTUFBTSxNQUFNLEdBQ3RCLE9BQU8sUUFBUTtHQUV2QjtFQUNKO0NBQ0o7Q0FDQSxNQUFNLHVCQUF1QixNQUFNLFlBQVksYUFBYSxhQUFhLGlCQUFpQjtFQUN0RixJQUFJLG9CQUFvQjtFQUN4QixJQUFJLGtCQUFrQjtFQUN0QixNQUFNLFNBQVMsRUFDWCxLQUNKO0VBQ0EsSUFBSSxDQUFDLFNBQVMsWUFBWSxnQkFBZ0IsTUFBTTtHQUM1QyxJQUFJLENBQUMsZUFBZSxhQUFhO0lBQzdCLE1BQU0seUJBQXlCLFVBQVUsSUFBSSxnQkFBZ0IsSUFBSSxHQUFHLFVBQVU7SUFDOUUsSUFBSSxXQUFXLFNBQVMsR0FBRztLQUN2QixrQkFBa0IsV0FBVztLQUM3QixXQUFXLFVBQVUsT0FBTyxVQUN4QixDQUFDLDBCQUEwQixVQUFVO0tBQ3pDLG9CQUFvQixvQkFBb0IsT0FBTztJQUNuRDtJQUNBLGtCQUFrQixDQUFDLENBQUMsSUFBSSxXQUFXLGFBQWEsSUFBSTtJQUNwRCxJQUFJLHdCQUNBLE1BQU0sV0FBVyxhQUFhLElBQUk7U0FFakM7S0FDRCxNQUFNLG9CQUFvQixJQUFJLGdCQUFnQixJQUFJO0tBQ2xELE1BQU0sUUFBUSxJQUFJLFNBQVMsSUFBSTtLQUMvQixNQUFNLGFBQWEsRUFBRSxTQUFTLE1BQU0sUUFDL0IsU0FBUyxpQkFBaUIsS0FBSyxNQUFNLFFBQVEsaUJBQWlCLEtBQzdELGVBQWUsbUJBQW1CLFlBQVksS0FBQSxHQUFXLEtBQUssSUFDOUQ7S0FDTixJQUFJLFdBQVcsYUFBYSxNQUFNLFVBQVU7SUFDaEQ7SUFDQSxJQUFJLHVCQUF1QjtJQUMzQixJQUFJLHFCQUNDLDJCQUNJLFdBQVcsU0FBUyxJQUFJLFdBQVcsVUFBVSxVQUFVLElBQUs7S0FDakUsb0JBQW9CO0tBQ3BCLE1BQU0sa0JBQWtCLGVBQWUsZ0JBQWdCLGFBQWEsS0FBQSxHQUFXLE9BQU87S0FDdEYsSUFBSSxDQUFDLFVBQVUsV0FBVyxhQUFhLGVBQWUsR0FBRztNQUNyRCx1QkFBdUI7TUFDdkIsMEJBQTBCLFdBQVcsYUFBYSxlQUFlO0tBQ3JFO0lBQ0o7SUFDQSxPQUFPLGNBQWMsV0FBVztJQUNoQyxvQkFDSSxxQkFDSyxXQUFXLGFBQWEsTUFDcEIsd0JBQ0csb0JBQW9CLENBQUM7R0FDekM7R0FDQSxJQUFJLGFBQWE7SUFDYixNQUFNLHlCQUF5QixJQUFJLFdBQVcsZUFBZSxJQUFJLElBQzNELElBQUksV0FBVyxlQUFlLElBQUksSUFDbEMsS0FBQTtJQUNOLElBQUksQ0FBQyx3QkFBd0I7S0FDekIsSUFBSSxXQUFXLGVBQWUsTUFBTSxXQUFXO0tBQy9DLE9BQU8sZ0JBQWdCLFdBQVc7S0FDbEMsb0JBQ0kscUJBQ0ssV0FBVyxlQUFlLEtBQ3ZCLDJCQUEyQjtJQUMzQztHQUNKO0dBQ0EscUJBQXFCLGdCQUFnQixVQUFVLE1BQU0sS0FBSyxNQUFNO0VBQ3BFO0VBQ0EsT0FBTyxvQkFBb0IsU0FBUyxDQUFDO0NBQ3pDO0NBQ0EsTUFBTSx1QkFBdUIsTUFBTSxTQUFTLE9BQU8sZUFBZTtFQUM5RCxNQUFNLHFCQUFxQixJQUFJLFdBQVcsUUFBUSxJQUFJO0VBQ3RELE1BQU0sb0JBQW9CLFdBQVcsU0FBUyxLQUMxQyxVQUFVLE9BQU8sS0FDakIsV0FBVyxZQUFZO0VBQzNCLElBQUksU0FBUyxjQUFjLE9BQU87R0FDOUIsb0JBQW9CLFFBQVEsU0FBUyxZQUFZLGFBQWEsTUFBTSxLQUFLLENBQUM7R0FDMUUsb0JBQW9CLEtBQUssQ0FBQyxTQUFTLFVBQVU7RUFDakQsT0FDSztHQUNELG1CQUFtQixJQUFJO0dBQ3ZCLFFBQ00sSUFBSSxXQUFXLFFBQVEsTUFBTSxLQUFLLElBQ2xDLE1BQU0sV0FBVyxRQUFRLElBQUk7R0FDbkMsV0FBVyxTQUFTLEVBQUUsR0FBRyxXQUFXLE9BQU87RUFDL0M7RUFDQSxLQUFLLFFBQ0MsQ0FBQyxVQUFVLG9CQUFvQixPQUFPLElBQUksSUFDMUMsdUJBQ0YsQ0FBQyxjQUFjLFVBQVUsS0FDekIsbUJBQW1CO0dBQ25CLE1BQU0sbUJBQW1CO0lBQ3JCLEdBQUc7SUFDSCxHQUFJLHFCQUFxQixVQUFVLE9BQU8sSUFBSSxFQUFFLFFBQVEsSUFBSSxDQUFDO0lBQzdELFFBQVEsV0FBVztJQUNuQjtHQUNKO0dBQ0EsVUFBVSxNQUFNLEtBQUssZ0JBQWdCO0VBQ3pDO0NBQ0o7Q0FDQSxNQUFNLGFBQWEsT0FBTyxTQUFTO0VBQy9CLG9CQUFvQixNQUFNLElBQUk7RUFDOUIsT0FBTyxNQUFNLFNBQVMsU0FBUyxhQUFhLFNBQVMsU0FBUyxtQkFBbUIsUUFBUSxPQUFPLE9BQU8sU0FBUyxTQUFTLGNBQWMsU0FBUyx5QkFBeUIsQ0FBQztDQUM5SztDQUNBLE1BQU0sOEJBQThCLE9BQU8sVUFBVTtFQUNqRCxNQUFNLGNBQWM7RUFDcEIsTUFBTSxpQkFBaUI7RUFDdkIsTUFBTSxrQkFBa0IsUUFDbEIsTUFBTSxRQUFRLFNBQVMsSUFBSSxTQUFTLElBQUksQ0FBQyxJQUN6QyxDQUFDO0VBQ1AsTUFBTSxFQUFFLFdBQVcsTUFBTSxXQUFXLEtBQUs7RUFDekMsSUFBSSxnQkFBZ0IsY0FDaEIsT0FBTztFQUVYLG9CQUFvQixLQUFLO0VBQ3pCLElBQUksT0FBTztHQUNQLEtBQUssTUFBTSxRQUFRLE9BQU87SUFDdEIsSUFBSSxnQkFBZ0IsU0FBUyxJQUFJLE1BQzVCLENBQUMsSUFBSSxTQUFTLElBQUksS0FBSyxpQkFBaUIsUUFBUSxpQkFBaUI7S0FDbEUsTUFBTSxRQUFRLElBQUk7S0FDbEI7SUFDSjtJQUNBLE1BQU0sUUFBUSxJQUFJLFFBQVEsSUFBSTtJQUM5Qix1QkFBdUIsSUFBSTtJQUMzQixNQUFNLHdCQUF3QixPQUFPLE1BQU0sSUFBSSxJQUFJLEtBQy9DLFNBQVMsS0FBSyxLQUNkLENBQUMsT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDLE1BQU0sUUFBUSxDQUFDLE9BQU8sTUFBTSxPQUFPLEdBQUcsQ0FBQyxDQUFDO0lBQ2hFLE1BQU0sUUFBUSxJQUFJLFNBQVMsSUFBSTtJQUMvQixNQUFNLGtCQUFrQixTQUFTLEtBQUssS0FBSyxPQUFPLEtBQUssS0FBSyxDQUFDLENBQUMsTUFBTSxRQUFRLFFBQVEsSUFBSTtJQUN4Rix3QkFDTSwwQkFBMEIsV0FBVyxRQUFRLEdBQUcsT0FBTyxNQUFNLEdBQUcsSUFBSSxJQUNuRSxVQUFVLE1BQU0sUUFBUSxNQUFNLFlBQzdCLE1BQU0sUUFBUSxLQUFLLEtBQ2xCLFNBQVMsS0FBSyxLQUFLLGtCQUNsQixJQUFJLFdBQVcsUUFBUSxNQUFNLEtBQUssSUFDbEMsTUFBTSxXQUFXLFFBQVEsSUFBSTtHQUMzQztHQUNBLFdBQVcsU0FBUyxFQUFFLEdBQUcsV0FBVyxPQUFPO0VBQy9DLE9BQ0s7R0FDRCxPQUFPLEtBQUssbUJBQW1CLENBQUMsQ0FBQyxRQUFRLGtCQUFrQjtHQUMzRCxXQUFXLFNBQVM7RUFDeEI7RUFDQSxPQUFPO0NBQ1g7Q0FDQSxNQUFNLGVBQWUsT0FBTyxFQUFFLE1BQU0sV0FBVyxxQkFBc0I7RUFDakUsSUFBSSxTQUFTLFVBQVU7R0FDbkIsTUFBTSxjQUFjO0dBQ3BCLE1BQU0scUJBQXFCLEVBQUU7R0FDN0IsTUFBTSxTQUFTLE1BQU0sU0FBUyxTQUFTO0lBQ25DLFlBQVk7SUFDWixXQUFXO0lBQ1g7SUFDQTtHQUNKLENBQUM7R0FDRCxJQUFJLGdCQUFnQixnQkFDZixjQUFjLE9BQU8sVUFDbEIsdUJBQXVCLHFCQUMzQixPQUFPO0dBRVgsSUFBSSxtQkFDQyxTQUFTLE1BQU0sSUFDVixPQUFPLE9BQU8sTUFBTSxDQUFDLENBQUMsS0FBSyxPQUFPLElBQ2xDLFNBQVMsTUFBTSxLQUFLLENBQUMsU0FDM0IsT0FBTztHQUVYLElBQUksU0FBUyxNQUFNLEdBQUc7SUFDbEIsSUFBSSxVQUFVO0lBQ2QsWUFBWSxlQUFlO0lBQzNCLEtBQUssTUFBTSxPQUFPLFFBQVE7S0FDdEIsTUFBTSxRQUFRLE9BQU87S0FDckIsSUFBSSxPQUFPO01BQ1AsVUFBVTtNQUNWLFNBQVMsR0FBRyxnQkFBZ0IsR0FBRyxPQUFPO09BQ2xDLFNBQVMsU0FBUyxNQUFNLE9BQU8sSUFBSSxNQUFNLFVBQVU7T0FDbkQsTUFBTSxNQUFNLFFBQVEsdUJBQXVCO01BQy9DLENBQUM7S0FDTDtJQUNKO0lBQ0EsT0FBTztHQUNYLE9BQ0ssSUFBSSxTQUFTLE1BQU0sS0FBSyxDQUFDLFFBQVE7SUFDbEMsWUFBWSxlQUFlO0lBQzNCLFNBQVMsaUJBQWlCO0tBQ3RCLFNBQVMsVUFBVTtLQUNuQixNQUFNLHVCQUF1QjtJQUNqQyxDQUFDO0lBQ0QsT0FBTztHQUNYLE9BQ0s7SUFDRCxZQUFZLGVBQWU7SUFDM0IsT0FBTztHQUNYO0VBQ0o7RUFDQSxPQUFPO0NBQ1g7Q0FDQSxNQUFNLDJCQUEyQixPQUFPLEVBQUUsUUFBUSxnQkFBZ0IsTUFBTSxXQUFXLFVBQVU7RUFDekYsT0FBTztFQUNQLG1CQUFtQjtDQUN2QixRQUFTO0VBQ0wsTUFBTSxjQUFjO0VBQ3BCLElBQUksU0FBUyxZQUFZLENBQUMsUUFBUSxtQkFBbUI7R0FDakQsUUFBUSxvQkFBb0I7R0FNNUIsSUFBSSxDQUFDLE1BTGdCLGFBQWE7SUFDOUI7SUFDQTtJQUNBO0dBQ0osQ0FBQyxHQUNZO0lBQ1QsUUFBUSxRQUFRO0lBQ2hCLElBQUksZ0JBQ0EsT0FBTyxRQUFRO0dBRXZCO0VBQ0o7RUFDQSxLQUFLLE1BQU0sUUFBUSxRQUFRO0dBQ3ZCLE1BQU0sUUFBUSxPQUFPO0dBQ3JCLElBQUksT0FBTztJQUNQLE1BQU0sRUFBRSxJQUFJLEdBQUcsZUFBZTtJQUM5QixJQUFJLElBQUk7S0FDSixNQUFNLG1CQUFtQixPQUFPLE1BQU0sSUFBSSxHQUFHLElBQUk7S0FDakQsTUFBTSxvQkFBb0IsTUFBTSxNQUFNLHFCQUFxQixNQUFNLEVBQUU7S0FDbkUsTUFBTSwrQkFBK0IsV0FBVyxnQkFBZ0Isa0JBQWtCO0tBQ2xGLElBQUkscUJBQXFCLDhCQUNyQixvQkFBb0IsQ0FBQyxHQUFHLElBQUksR0FBRyxJQUFJO0tBRXZDLE1BQU0saUJBQWlCO0tBQ3ZCLE1BQU0sYUFBYSxNQUFNLGNBQWMsT0FBTyxPQUFPLFVBQVUsYUFBYSxrQ0FBa0MsU0FBUyw2QkFBNkIsQ0FBQyxnQkFBZ0IsZ0JBQWdCO0tBQ3JMLElBQUksZ0JBQWdCLGNBQ2hCLE9BQU8sUUFBUTtLQUVuQixJQUFJLHFCQUFxQiw4QkFDckIsb0JBQW9CLENBQUMsR0FBRyxJQUFJLENBQUM7S0FFakMsSUFBSSxDQUFDLElBQUksU0FBUyxHQUFHLElBQUksS0FDckIsaUJBQWlCLEdBQUcsUUFBUSxnQkFDNUI7S0FFSixJQUFJLFdBQVcsR0FBRyxPQUFPO01BQ3JCLFFBQVEsUUFBUTtNQUNoQixJQUFJLGdCQUNBO0tBRVI7S0FDQSxJQUFJLENBQUMsZ0JBQWdCO01BQ2pCLG1CQUFtQixHQUFHLElBQUk7TUFDMUIsSUFBSSxZQUFZLEdBQUcsSUFBSSxJQUNqQixtQkFDSSwwQkFBMEIsV0FBVyxRQUFRLFlBQVksR0FBRyxJQUFJLElBQ2hFLElBQUksV0FBVyxRQUFRLEdBQUcsTUFBTSxXQUFXLEdBQUcsS0FBSyxJQUN2RCxNQUFNLFdBQVcsUUFBUSxHQUFHLElBQUk7S0FDMUM7S0FDQSxJQUFJLFNBQVMsNkJBQTZCLFdBQVcsR0FBRyxPQUNwRDtJQUVSO0lBQ0EsQ0FBQyxjQUFjLFVBQVUsS0FDcEIsTUFBTSx5QkFBeUI7S0FDNUI7S0FDQTtLQUNBLFFBQVE7S0FDRjtLQUNOO0lBQ0osQ0FBQztHQUNUO0VBQ0o7RUFDQSxPQUFPLFFBQVE7Q0FDbkI7Q0FDQSxNQUFNLHlCQUF5QjtFQUMzQixLQUFLLE1BQU0sUUFBUSxPQUFPLFNBQVM7R0FDL0IsTUFBTSxRQUFRLElBQUksU0FBUyxJQUFJO0dBQy9CLFVBQ0ssTUFBTSxHQUFHLE9BQ0osTUFBTSxHQUFHLEtBQUssT0FBTyxRQUFRLENBQUMsS0FBSyxHQUFHLENBQUMsSUFDdkMsQ0FBQyxLQUFLLE1BQU0sR0FBRyxHQUFHLE1BQ3hCLFdBQVcsSUFBSTtFQUN2QjtFQUNBLE9BQU8sMEJBQVUsSUFBSSxJQUFJO0NBQzdCO0NBQ0EsTUFBTSxhQUFhLE1BQU0sVUFBVSxRQUFRLENBQUMsWUFBWSxJQUFJLEtBQUssSUFBSSxhQUFhLE1BQU0sSUFBSSxHQUN4RixDQUFDLFVBQVUsT0FBTyxRQUFRLGNBQWMsZ0JBQWdCLGNBQWM7Q0FDMUUsTUFBTSxhQUFhLE9BQU8sY0FBYyxhQUFhO0VBQ2pELE1BQU0sU0FBUyxPQUFPLFFBQ2hCLGNBQ0EsWUFBWSxZQUFZLEtBQUssQ0FBQyxZQUFZLEtBQUssSUFDM0MsaUJBQ0E7RUFDVixPQUFPLG9CQUFvQixPQUFPLFFBQVEsWUFBWSxLQUFLLElBQUksRUFBRSxHQUFHLE9BQU8sSUFBSSxRQUFRLFVBQVUsWUFBWTtDQUNqSDtDQUNBLE1BQU0sa0JBQWtCLFNBQVMsUUFBUSxJQUFJLE9BQU8sUUFBUSxjQUFjLGdCQUFnQixNQUFNLFNBQVMsbUJBQW1CLElBQUksZ0JBQWdCLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Q0FDL0osTUFBTSxpQkFBaUIsTUFBTSxPQUFPLFVBQVUsQ0FBQyxHQUFHLFlBQVksT0FBTyxhQUFhLE9BQU8sa0JBQWtCLFVBQVU7RUFDakgsTUFBTSxRQUFRLElBQUksU0FBUyxJQUFJO0VBQy9CLElBQUksYUFBYTtFQUNqQixJQUFJLE9BQU87R0FDUCxNQUFNLGlCQUFpQixNQUFNO0dBQzdCLElBQUksZ0JBQWdCO0lBQ2hCLENBQUMsZUFBZSxZQUNaLElBQUksYUFBYSxNQUFNLGdCQUFnQixPQUFPLGNBQWMsQ0FBQztJQUNqRSxhQUNJLGNBQWMsZUFBZSxHQUFHLEtBQUssa0JBQWtCLEtBQUssSUFDdEQsS0FDQTtJQUNWLElBQUksaUJBQWlCLGVBQWUsR0FBRyxHQUNuQyxDQUFDLEdBQUcsZUFBZSxJQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsY0FBZSxVQUFVLFdBQVcsV0FBVyxTQUFTLFVBQVUsS0FBSyxDQUFFO1NBRWpILElBQUksZUFBZSxNQUFNO0tBQzFCLElBQUksZ0JBQWdCLGVBQWUsR0FBRyxHQUNsQyxlQUFlLEtBQUssU0FBUyxnQkFBZ0I7TUFDekMsSUFBSSxDQUFDLFlBQVksa0JBQWtCLENBQUMsWUFBWSxVQUFVO09BQ3RELElBQUksTUFBTSxRQUFRLFVBQVUsR0FDeEIsWUFBWSxVQUNSLENBQUMsWUFBWSxZQUFZLEtBQUssS0FDMUIsV0FBVyxTQUFTLFlBQVksS0FBSztZQUc3QyxZQUFZLFVBQ1IsZUFBZSxZQUFZLFNBQVMsQ0FBQyxDQUFDO01BRWxEO0tBQ0osQ0FBQztVQUdELGVBQWUsS0FBSyxTQUFTLGFBQWMsU0FBUyxVQUFVLFNBQVMsVUFBVSxVQUFXO0lBRXBHLE9BQ0ssSUFBSSxZQUFZLGVBQWUsR0FBRyxHQUNuQyxlQUFlLElBQUksUUFBUTtTQUUxQjtLQUNELGVBQWUsSUFBSSxRQUFRO0tBQzNCLElBQUksQ0FBQyxlQUFlLElBQUksUUFBUSxDQUFDLGNBQWMsQ0FBQyxpQkFDNUMsVUFBVSxNQUFNLEtBQUs7TUFDakI7TUFDQSxRQUFRLFlBQ0YsY0FDQSxxQkFBcUIsSUFBSSxJQUNyQixZQUFZLFdBQVcsSUFDdkIsS0FBQTtLQUNkLENBQUM7SUFFVDtHQUNKO0VBQ0o7RUFDQSxDQUFDLFFBQVEsZUFBZSxRQUFRLGdCQUM1QixvQkFBb0IsTUFBTSxTQUN0QixNQUFNLE1BQ04sQ0FBQyxNQUFNLEdBQUcsYUFDVCxNQUFNLEdBQUcsaUJBQ04sTUFBTSxHQUFHLGVBQ1QsTUFBTSxHQUFHLGNBQ1gsZ0JBQWdCLE9BQU8sTUFBTSxFQUFFLElBQy9CLFlBQVksUUFBUSxhQUFhLFFBQVEsYUFBYSxDQUFDLFVBQVU7RUFDM0UsUUFBUSxrQkFDSixRQUFRLE1BQU0sRUFDVixZQUFZLFFBQVEsV0FDeEIsQ0FBQztFQUNMLElBQUksUUFBUSxrQkFDUixTQUNBLE1BQU0sTUFDTixNQUFNLEdBQUcsU0FDUixDQUFDLE1BQU0sUUFBUSxNQUFNLEdBQUcsSUFBSSxLQUFLLE1BQU0sR0FBRyxLQUFLLFNBQVMsSUFDekQsUUFBUSxNQUFNLEdBQUcsSUFBSTtDQUU3QjtDQUNBLE1BQU0sa0JBQWtCLE1BQU0sT0FBTyxTQUFTLFlBQVksT0FBTyxhQUFhLE9BQU8sa0JBQWtCLFVBQVU7RUFDN0csS0FBSyxNQUFNLFlBQVksT0FBTztHQUMxQixJQUFJLENBQUMsT0FBTyxVQUFVLGVBQWUsS0FBSyxPQUFPLFFBQVEsR0FDckQ7R0FFSixNQUFNLGFBQWEsTUFBTTtHQUN6QixNQUFNLFlBQVksT0FBTyxNQUFNO0dBQy9CLE1BQU0sUUFBUSxJQUFJLFNBQVMsU0FBUztHQUNwQyxJQUFJLE9BQU8sTUFBTSxJQUFJLFNBQVMsR0FDMUIsVUFBVSxNQUFNLEtBQUs7SUFDakIsTUFBTTtJQUNOLFFBQVEsWUFBWSxjQUFjLFlBQVksV0FBVztHQUM3RCxDQUFDO0dBRUwsQ0FBQyxPQUFPLE1BQU0sSUFBSSxJQUFJLEtBQ2xCLFNBQVMsVUFBVSxLQUNsQixTQUFTLENBQUMsTUFBTSxPQUNqQixDQUFDLGFBQWEsVUFBVSxJQUN0QixlQUFlLFdBQVcsWUFBWSxTQUFTLFdBQVcsWUFBWSxlQUFlLElBQ3JGLGNBQWMsV0FBVyxZQUFZLFNBQVMsV0FBVyxZQUFZLGVBQWU7RUFDOUY7Q0FDSjtDQUNBLE1BQU0sYUFBYSxNQUFNLE9BQU8sU0FBUyxXQUFXLGdCQUFnQixVQUFVO0VBQzFFLE1BQU0sUUFBUSxJQUFJLFNBQVMsSUFBSTtFQUMvQixNQUFNLGVBQWUsT0FBTyxNQUFNLElBQUksSUFBSTtFQUMxQyxNQUFNLGFBQWEsWUFBWSxRQUFRLFlBQVksS0FBSztFQUV4RCxNQUFNLG1CQUFtQixVQURILElBQUksYUFBYSxJQUNRLEdBQUcsVUFBVTtFQUM1RCxJQUFJLENBQUMsa0JBQ0QsSUFBSSxhQUFhLE1BQU0sVUFBVTtFQUVyQyxJQUFJLGNBQWM7R0FDZCxVQUFVLE1BQU0sS0FBSztJQUNqQjtJQUNBLFFBQVEsWUFBWSxjQUFjLFlBQVksV0FBVztHQUM3RCxDQUFDO0dBQ0QsSUFBSSxXQUFXLFdBQVcsYUFBYSxLQUFLLFFBQVEsYUFBYTtJQUM3RCxtQkFBbUI7SUFDbkIsV0FBVyxVQUFVLFVBQVUsTUFBTSxVQUFVO0lBQy9DLElBQUksQ0FBQyxlQUNELFVBQVUsTUFBTSxLQUFLO0tBQ2pCO0tBQ0EsYUFBYSxXQUFXO0tBQ3hCLFNBQVMsV0FBVztJQUN4QixDQUFDO0dBRVQ7R0FDQSxRQUFRLGtCQUNKLFFBQVEsTUFBTSxFQUNWLFlBQVksUUFBUSxXQUN4QixDQUFDO0VBQ1QsT0FDSztHQUNELE1BQU0sVUFBVyxNQUFNLFFBQVEsVUFBVSxLQUFLLENBQUMsV0FBVyxVQUN0RCxjQUFjLFVBQVU7R0FDNUIsTUFBTSxrQkFBa0IsQ0FBQyxvQkFBb0IsQ0FBQztHQUM5QyxJQUFJLENBQUMsU0FBUyxNQUFNLE1BQU0sa0JBQWtCLFVBQVUsS0FBSyxTQUN2RCxjQUFjLE1BQU0sWUFBWSxTQUFTLFdBQVcsZUFBZSxlQUFlO1FBR2xGLGVBQWUsTUFBTSxZQUFZLFNBQVMsV0FBVyxlQUFlLGVBQWU7RUFFM0Y7RUFDQSxJQUFJLENBQUMsb0JBQW9CLENBQUMsZUFBZTtHQUNyQyxNQUFNLFVBQVUsVUFBVSxNQUFNLE1BQU07R0FDdEMsTUFBTSxjQUFjLE9BQU8sU0FBUyxVQUFVLE9BQU8sS0FBQTtHQUNyRCxNQUFNLHNCQUFzQixlQUN0QixDQUFDLElBQ0QsdUJBQXVCLE9BQU8sT0FBTyxJQUFJO0dBQy9DLE1BQU0sU0FBUyxZQUNULGNBQ0EscUJBQXFCLFdBQVcsS0FDOUIsb0JBQW9CLEtBQUssb0JBQW9CLElBQzNDLFlBQVksV0FBVyxJQUN2QixLQUFBO0dBQ1YsVUFBVSxNQUFNLEtBQUs7SUFDakIsR0FBSSxXQUFXO0lBQ2YsTUFBTTtJQUNOO0dBQ0osQ0FBQztHQUNELEtBQUssTUFBTSxZQUFZLHFCQUNuQixVQUFVLE1BQU0sS0FBSztJQUNqQixNQUFNO0lBQ04sUUFBUSxVQUFVLFlBQVksV0FBVztHQUM3QyxDQUFDO0VBRVQ7Q0FDSjtDQUNBLE1BQU0sWUFBWSxNQUFNLE9BQU8sVUFBVSxDQUFDLE1BQU0sVUFBVSxNQUFNLE9BQU8sU0FBUyxLQUFLO0NBQ3JGLE1BQU0sYUFBYSxZQUFZLFVBQVUsQ0FBQyxNQUFNO0VBQzVDLE1BQU0sb0JBQW9CLFdBQVcsVUFBVSxJQUN6QyxXQUFXLFdBQVcsSUFDdEI7RUFDTixJQUFJLENBQUMsVUFBVSxhQUFhLGlCQUFpQixLQUN6QyxRQUFRLGtCQUNSLFFBQVEsZUFDUixRQUFRLGFBQWE7R0FDckIsY0FBYztJQUNWLEdBQUc7SUFDSCxHQUFHO0dBQ1A7R0FDQSxLQUFLLE1BQU0sNkJBQWEsSUFBSSxJQUFJLENBQUMsR0FBRyxPQUFPLE9BQU8sR0FBRyxPQUFPLEtBQUssQ0FBQyxHQUM5RCxJQUFJLElBQUksbUJBQW1CLFNBQVMsR0FDaEMsVUFBVSxXQUFXLElBQUksbUJBQW1CLFNBQVMsR0FBRyxTQUFTLE1BQU0sSUFBSTtHQUduRixJQUFJLFFBQVEsZUFBZSxXQUFXLFdBQVcsYUFBYSxHQUMxRCxLQUFLLE1BQU0sUUFBUSxPQUFPLEtBQUssaUJBQWlCLEdBQzVDLG9CQUFvQixNQUFNLFlBQVksT0FBTyxPQUFPLElBQUk7R0FHaEUsVUFBVSxNQUFNLEtBQUs7SUFDakIsR0FBRztJQUNILE1BQU0sS0FBQTtJQUNOLE1BQU0sS0FBQTtJQUNOLEdBQUksbUJBQW1CLE9BQU8sRUFBRSxRQUFRLFlBQVksSUFBSSxDQUFDO0dBQzdELENBQUM7R0FDRCxJQUFJLFFBQVEsZ0JBQ1IsVUFBVTtFQUVsQjtDQUNKO0NBQ0EsTUFBTSxXQUFXLE9BQU8sVUFBVTtFQUM5QixPQUFPLFFBQVE7RUFDZixNQUFNLFNBQVMsTUFBTTtFQUNyQixJQUFJLE9BQU8sT0FBTztFQUNsQixJQUFJLHNCQUFzQjtFQUMxQixNQUFNLFFBQVEsSUFBSSxTQUFTLElBQUk7RUFDL0IsTUFBTSxpQkFBaUI7RUFDdkIsTUFBTSw4QkFBOEIsZUFBZTtHQUMvQyxzQkFDSSxDQUFDLENBQUMsSUFBSSxTQUFTLElBQUksS0FDZixFQUFFLGlCQUFpQixRQUFRLG1CQUMzQixVQUFVLFlBQVksSUFBSSxhQUFhLE1BQU0sVUFBVSxDQUFDO0VBQ3BFO0VBQ0EsSUFBSSxPQUFPO0dBQ1AsT0FBTyxjQUFjO0dBQ3JCLElBQUk7R0FDSixJQUFJO0dBQ0osSUFBSSxtQkFBbUI7R0FDdkIsTUFBTSxhQUFhLE9BQU8sT0FDcEIsY0FBYyxNQUFNLEVBQUUsSUFDdEIsY0FBYyxLQUFLO0dBQ3pCLE1BQU0sY0FBYyxNQUFNLFNBQVMsT0FBTyxRQUFRLE1BQU0sU0FBUyxPQUFPO0dBQ3hFLE1BQU0sd0JBQXdCLENBQUMsY0FBYyxNQUFNLEVBQUUsS0FDakQsQ0FBQyxTQUFTLFlBQ1YsQ0FBQyxTQUFTLFlBQ1YsQ0FBQyxJQUFJLFdBQVcsUUFBUSxJQUFJLEtBQzVCLENBQUMsTUFBTSxHQUFHO0dBQ2QsTUFBTSx1QkFBdUIseUJBQ3pCLGVBQWUsYUFBYSxJQUFJLFdBQVcsZUFBZSxJQUFJLEdBQUcsV0FBVyxhQUFhLDRCQUE0QiwyQkFBMkI7R0FDcEosTUFBTSxVQUFVLFVBQVUsTUFBTSxRQUFRLFdBQVc7R0FDbkQsSUFBSSxhQUFhLE1BQU0sWUFBWSxVQUFVLENBQUM7R0FDOUMsSUFBSSxhQUNJO1FBQUEsQ0FBQyxVQUFVLENBQUMsT0FBTyxVQUFVO0tBQzdCLE1BQU0sR0FBRyxVQUFVLE1BQU0sR0FBRyxPQUFPLEtBQUs7S0FDeEMsSUFBSSxPQUFPLFVBQVUsZUFBZSxLQUFLLHFCQUFxQixJQUFJLEdBQUc7TUFDakUsbUJBQW1CO01BQ25CLG9CQUFvQixLQUFLLENBQUMsQ0FBQztLQUMvQjtJQUNKO1VBRUMsSUFBSSxNQUFNLEdBQUcsVUFDZCxNQUFNLEdBQUcsU0FBUyxLQUFLO0dBRTNCLE1BQU0sYUFBYSxvQkFBb0IsTUFBTSxZQUFZLFdBQVc7R0FDcEUsTUFBTSxlQUFlLENBQUMsY0FBYyxVQUFVLEtBQUs7R0FDbkQsQ0FBQyxlQUNHLFVBQVUsTUFBTSxLQUFLO0lBQ2pCO0lBQ0EsTUFBTSxNQUFNO0lBQ1osR0FBSSxxQkFBcUIsSUFBSSxJQUN2QixFQUFFLFFBQVEsWUFBWSxXQUFXLEVBQUUsSUFDbkMsQ0FBQztHQUNYLENBQUM7R0FDTCxJQUFJLHNCQUFzQjtJQUN0QixLQUFLLENBQUMseUJBQXlCLENBQUMsV0FBVyxZQUN2QyxXQUFXLFNBQVMsR0FBRztLQUN2QixJQUFJLFNBQVMsU0FBUyxVQUNkO1VBQUEsYUFDQSxVQUFVO0tBQUEsT0FHYixJQUFJLENBQUMsYUFDTixVQUFVO0lBRWxCO0lBQ0EsT0FBUSxnQkFDSixVQUFVLE1BQU0sS0FBSztLQUFFO0tBQU0sR0FBSSxVQUFVLENBQUMsSUFBSTtJQUFZLENBQUM7R0FDckU7R0FDQSxJQUFJLENBQUMsU0FBUyxZQUFZLFNBQVMsVUFDL0IsTUFBTSxhQUFhO0lBQ1Q7SUFDTixXQUFXLE1BQU07R0FDckIsQ0FBQztHQUVMLENBQUMsZUFBZSxXQUFXLFVBQVUsTUFBTSxLQUFLLEVBQUUsR0FBRyxXQUFXLENBQUM7R0FDakUsSUFBSSxTQUFTLFVBQVU7SUFDbkIsTUFBTSxjQUFjO0lBQ3BCLE1BQU0sRUFBRSxXQUFXLE1BQU0sV0FBVyxDQUFDLElBQUksQ0FBQztJQUMxQyxJQUFJLGdCQUFnQixjQUNoQjtJQUVKLG9CQUFvQixDQUFDLElBQUksQ0FBQztJQUMxQiwyQkFBMkIsVUFBVTtJQUNyQyxJQUFJLENBQUMscUJBQXFCO0tBQ3RCLENBQUMsY0FBYyxVQUFVLEtBQUssVUFBVSxNQUFNLEtBQUssVUFBVTtLQUM3RDtJQUNKO0lBQ0EsTUFBTSw0QkFBNEIsa0JBQWtCLFdBQVcsUUFBUSxTQUFTLElBQUk7SUFDcEYsTUFBTSxvQkFBb0Isa0JBQWtCLFFBQVEsU0FBUywwQkFBMEIsUUFBUSxJQUFJO0lBQ25HLFFBQVEsa0JBQWtCO0lBQzFCLE9BQU8sa0JBQWtCO0lBQ3pCLFVBQVUsY0FBYyxNQUFNO0dBQ2xDLE9BQ0s7SUFDRCxNQUFNLGNBQWM7SUFDcEIsTUFBTSxpQkFBaUIsRUFBRTtJQUN6QixvQkFBb0IsQ0FBQyxJQUFJLEdBQUcsSUFBSTtJQUNoQyxTQUFTLE1BQU0sY0FBYyxPQUFPLE9BQU8sVUFBVSxhQUFhLGtDQUFrQyxTQUFTLHlCQUF5QixFQUFBLENBQUc7SUFDekksSUFBSSxnQkFBZ0IsY0FDaEI7SUFFSixvQkFBb0IsQ0FBQyxJQUFJLENBQUM7SUFDMUIsMkJBQTJCLFVBQVU7SUFDckMsSUFBSSxxQkFBcUI7S0FDckIsSUFBSSxPQUNBLFVBQVU7VUFFVCxJQUFJLFdBQVcsU0FBUyxHQUFHO01BQzVCLFVBQVUsTUFBTSx5QkFBeUI7T0FDckMsUUFBUTtPQUNSLGdCQUFnQjtPQUNWO09BQ04sV0FBVyxNQUFNO01BQ3JCLENBQUM7TUFDRCxJQUFJLGdCQUFnQixjQUNoQjtNQUVKLDJCQUEyQixVQUFVO01BQ3JDLElBQUksbUJBQW1CLGlCQUNuQixVQUFVLEtBQUE7S0FFbEI7SUFDSjtHQUNKO0dBQ0EsSUFBSSxxQkFBcUI7SUFDckIsTUFBTSxHQUFHLFNBQ0osQ0FBQyxNQUFNLFFBQVEsTUFBTSxHQUFHLElBQUksS0FBSyxNQUFNLEdBQUcsS0FBSyxTQUFTLE1BQ3pELFFBQVEsTUFBTSxHQUFHLElBQUk7SUFDekIsb0JBQW9CLE1BQU0sU0FBUyxPQUFPLFVBQVU7SUFDcEQsb0JBQ0ksT0FBTyxVQUFVLGVBQWUsS0FBSyxxQkFBcUIsSUFBSSxLQUM5RCxvQkFBb0IsS0FBSyxDQUFDLENBQUM7R0FDbkM7RUFDSjtDQUNKO0NBQ0EsTUFBTSxlQUFlLEtBQUssUUFBUTtFQUM5QixJQUFJLElBQUksV0FBVyxRQUFRLEdBQUcsS0FBSyxJQUFJLE9BQU87R0FDMUMsSUFBSSxNQUFNO0dBQ1YsT0FBTztFQUNYO0NBRUo7Q0FDQSxNQUFNLFVBQVUsT0FBTyxNQUFNLFVBQVUsQ0FBQyxNQUFNO0VBQzFDLE9BQU8sY0FBYztFQUNyQixJQUFJO0VBQ0osSUFBSTtFQUNKLE1BQU0sYUFBYSxzQkFBc0IsSUFBSTtFQUM3QyxNQUFNLGNBQWM7RUFDcEIsSUFBSSxTQUFTLFVBQVU7R0FDbkIsTUFBTSxTQUFTLE1BQU0sNEJBQTRCLFlBQVksSUFBSSxJQUFJLE9BQU8sVUFBVTtHQUN0RixVQUFVLGNBQWMsTUFBTTtHQUM5QixtQkFBbUIsT0FDYixDQUFDLFdBQVcsTUFBTSxTQUFTLElBQUksUUFBUSxJQUFJLENBQUMsSUFDNUM7RUFDVixPQUNLLElBQUksTUFBTTtHQUNYLG9CQUFvQixNQUFNLFFBQVEsSUFBSSxXQUFXLElBQUksT0FBTyxjQUFjO0lBQ3RFLE1BQU0sUUFBUSxJQUFJLFNBQVMsU0FBUztJQUNwQyxPQUFPLE1BQU0seUJBQXlCO0tBQ2xDLFFBQVEsU0FBUyxNQUFNLEtBQUssR0FBRyxZQUFZLE1BQU0sSUFBSTtLQUNyRCxXQUFXLE9BQU87SUFDdEIsQ0FBQztHQUNMLENBQUMsQ0FBQyxFQUFBLENBQUcsTUFBTSxPQUFPO0dBQ2xCLENBQUcsb0JBQXFCLFdBQVcsWUFBWSxVQUFVO0VBQzdELE9BRUksbUJBQW1CLFVBQVUsTUFBTSx5QkFBeUI7R0FDeEQsUUFBUTtHQUNSO0dBQ0EsV0FBVyxPQUFPO0VBQ3RCLENBQUM7RUFFTCxJQUFJLGdCQUFnQixjQUNoQixPQUFPO0VBRVgsSUFBSSxRQUFRLGNBQWMsU0FBUyxjQUFjLFNBQVMsSUFBSSxHQUFHO0dBQzdELE1BQU0sUUFBUSxJQUFJLFdBQVcsUUFBUSxJQUFJO0dBQ3pDLElBQUksT0FBTztJQUNQLE1BQU0sV0FBVyxRQUFRLElBQUk7SUFDN0Isb0JBQW9CLFFBQVEsU0FBUyxZQUFZLGFBQWEsTUFBTSxLQUFLLENBQUM7SUFDMUUsb0JBQW9CLEtBQUssQ0FBQyxTQUFTLFVBQVU7R0FDakQsT0FFSSxtQkFBbUIsSUFBSTtFQUUvQjtFQUNBLElBQUksUUFBUSxhQUFhO0dBQ3JCLE1BQU0sY0FBYyxjQUFjO0lBQzlCLENBQUMsT0FBTyxNQUFNLElBQUksU0FBUyxLQUN2QixJQUFJLFdBQVcsZUFBZSxXQUFXLElBQUk7R0FDckQ7R0FDQSxLQUFLLE1BQU0sYUFBYSxPQUFPLGFBQWEsT0FBTyxPQUFPO0lBQ3RELE1BQU0sUUFBUSxJQUFJLFNBQVMsU0FBUztJQUNwQyxTQUFTLEtBQUssS0FBSyxNQUFNLFFBQVEsS0FBSyxJQUNoQyxzQkFBc0IsVUFBVSxHQUFHLFFBQVEsV0FBVyxHQUFHLEdBQUcsQ0FDMUQsU0FDSixDQUFDLElBQ0MsV0FBVyxTQUFTO0dBQzlCO0VBQ0o7RUFDQSxXQUFXLFNBQVMsRUFBRSxHQUFHLFdBQVcsT0FBTztFQUMzQyxVQUFVLE1BQU0sS0FBSztHQUNqQixHQUFJLENBQUMsU0FBUyxJQUFJLEtBQ2IsV0FBVyxTQUFTLEtBQUssWUFBWSxXQUFXLFVBQy9DLENBQUMsSUFDRCxFQUFFLEtBQUs7R0FDYixHQUFJLFNBQVMsWUFBWSxDQUFDLE9BQU8sRUFBRSxRQUFRLElBQUksQ0FBQztHQUNoRCxHQUFJLFFBQVEsZUFBZSxXQUFXLGVBQWUsSUFDL0MsRUFBRSxlQUFlLFdBQVcsY0FBYyxJQUMxQyxDQUFDO0dBQ1AsUUFBUSxXQUFXO0VBQ3ZCLENBQUM7RUFDRCxRQUFRLGVBQ0osQ0FBQyxvQkFDRCxzQkFBc0IsU0FBUyxhQUFhLE9BQU8sYUFBYSxPQUFPLEtBQUs7RUFDaEYsT0FBTztDQUNYO0NBQ0EsTUFBTSxjQUFjLFlBQVksV0FBVztFQUN2QyxJQUFJLFNBQVMsWUFBWSxVQUFVLEtBQUssQ0FBQyxTQUNuQyxFQUFFLEdBQUksT0FBTyxRQUFRLGNBQWMsZUFBZ0IsSUFDbkQsT0FBTyxRQUNILGNBQ0E7RUFDVixJQUFJLFFBQ0EsU0FBUyxrQkFBa0IsT0FBTyxjQUFjLFdBQVcsY0FBYyxXQUFXLGVBQWUsTUFBTTtFQUU3RyxPQUFPLFlBQVksVUFBVSxJQUN2QixTQUNBLFNBQVMsVUFBVSxJQUNmLElBQUksUUFBUSxVQUFVLElBQ3RCLFdBQVcsS0FBSyxTQUFTLElBQUksUUFBUSxJQUFJLENBQUM7Q0FDeEQ7Q0FDQSxNQUFNLGNBQWMsZUFBZSxZQUFZLFVBQVUsSUFDbkQsRUFBRSxHQUFHLFdBQVcsT0FBTyxJQUN2QixTQUFTLFVBQVUsSUFDZixJQUFJLFdBQVcsUUFBUSxVQUFVLElBQ2pDLFdBQVcsS0FBSyxTQUFTLElBQUksV0FBVyxRQUFRLElBQUksQ0FBQztDQUMvRCxNQUFNLGlCQUFpQixNQUFNLGNBQWM7RUFDdkMsTUFBTSxrQkFBa0IsYUFBYTtFQUNyQyxNQUFNLFFBQVEsSUFBSSxnQkFBZ0IsUUFBUSxJQUFJO0VBQzlDLE9BQU87R0FDSCxTQUFTLENBQUMsQ0FBQztHQUNYLFNBQVMsQ0FBQyxDQUFDLElBQUksZ0JBQWdCLGFBQWEsSUFBSTtHQUNoRDtHQUNBLGNBQWMsQ0FBQyxDQUFDLElBQUksZ0JBQWdCLGtCQUFrQixJQUFJO0dBQzFELFdBQVcsQ0FBQyxDQUFDLElBQUksZ0JBQWdCLGVBQWUsSUFBSTtFQUN4RDtDQUNKO0NBQ0EsTUFBTSxlQUFlLFNBQVM7RUFDMUIsTUFBTSxRQUFRLE9BQU8sc0JBQXNCLElBQUksSUFBSSxLQUFBO0VBQ25ELElBQUksT0FDQSxNQUFNLFNBQVMsY0FBYztHQUN6Qix1QkFBdUIsU0FBUztHQUNoQyxNQUFNLFdBQVcsUUFBUSxTQUFTO0dBQ2xDLFdBQVcsU0FBUyxFQUFFLEdBQUcsV0FBVyxPQUFPO0dBQzNDLFVBQVUsTUFBTSxLQUFLO0lBQ2pCLE1BQU07SUFDTixRQUFRLFdBQVc7R0FDdkIsQ0FBQztFQUNMLENBQUM7T0FFQTtHQUNELE9BQU8sS0FBSyxtQkFBbUIsQ0FBQyxDQUFDLFFBQVEsa0JBQWtCO0dBQzNELFdBQVcsU0FBUyxDQUFDO0dBQ3JCLFVBQVUsTUFBTSxLQUFLLEVBQ2pCLFFBQVEsV0FBVyxPQUN2QixDQUFDO0VBQ0w7Q0FDSjtDQUNBLE1BQU0sWUFBWSxNQUFNLE9BQU8sWUFBWTtFQUN2QyxJQUFJO0VBQ0osdUJBQXVCLElBQUk7RUFDM0IsTUFBTSxRQUFRLElBQUksU0FBUyxNQUFNLEVBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBQztFQUMzQyxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sR0FBRztFQUVqQyxNQUFNLEVBQUUsS0FBSyxZQUFZLFNBQVMsTUFBTSxPQUFPLEdBQUcsb0JBRDdCLElBQUksV0FBVyxRQUFRLElBQUksS0FBSyxDQUFDO0VBRXRELElBQUksV0FBVyxRQUFRLE1BQU07R0FDekIsR0FBRztHQUNILEdBQUc7R0FDSDtFQUNKLENBQUM7RUFDRCxXQUFXLFNBQVMsRUFBRSxHQUFHLFdBQVcsT0FBTztFQUMzQyxVQUFVLE1BQU0sS0FBSztHQUNqQjtHQUNBLFFBQVEsV0FBVztHQUNuQixTQUFTO0VBQ2IsQ0FBQztFQUNELElBQUksV0FBVyxRQUFRLGFBQWE7R0FDaEMsTUFBTSxhQUFhLEtBQUssTUFBTSxRQUFRLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSyxJQUFJLEdBQUcsUUFDcEUsTUFBTSxHQUFHLEtBQUssTUFBTSxRQUFRLENBQUMsSUFBSSxRQUFRLEtBQUssTUFBTSxHQUFHLEtBQUssS0FDNUQ7R0FDTixZQUFZLFNBQVMsU0FBUyxTQUFTLE1BQU07RUFDakQ7Q0FDSjtDQUNBLE1BQU0sU0FBUyxNQUFNLGlCQUFpQjtFQUNsQyxJQUFJLFdBQVcsSUFBSSxHQUFHO0dBQ2xCLE1BQU0sbUJBQW1CLENBQUM7R0FDMUIsbUJBQW1CLElBQUksZ0JBQWdCO0dBQ3ZDLE1BQU0sRUFBRSxnQkFBZ0IsVUFBVSxNQUFNLFVBQVUsRUFDOUMsT0FBTyxZQUFZLFlBQVksV0FDM0IsS0FBSyxRQUFRLFVBQVUsVUFBVSxLQUFBLEdBQVcsWUFBWSxHQUFHLE9BQU8sRUFDMUUsQ0FBQztHQUNELE9BQU8sRUFDSCxtQkFBbUI7SUFDZixtQkFBbUIsT0FBTyxnQkFBZ0I7SUFDMUMsWUFBWTtHQUNoQixFQUNKO0VBQ0o7RUFDQSxPQUFPLFVBQVUsTUFBTSxjQUFjLElBQUk7Q0FDN0M7Q0FDQSxNQUFNLGNBQWMsVUFBVTtFQUMxQixNQUFNLG1CQUFtQjtHQUFFLE1BQU0sTUFBTTtHQUFNLE9BQU8sTUFBTTtFQUFNO0VBQ2hFLE1BQU0sYUFDRixNQUFNLFVBQVUsVUFDaEIsbUJBQW1CLElBQUksZ0JBQWdCO0VBQzNDLE1BQU0sRUFBRSxnQkFBZ0IsVUFBVSxNQUFNLFVBQVUsRUFDOUMsT0FBTyxjQUFjO0dBQ2pCLElBQUksc0JBQXNCLE1BQU0sTUFBTSxVQUFVLE1BQU0sTUFBTSxLQUFLLEtBQzdELHNCQUFzQixXQUFXLE1BQU0sYUFBYSxpQkFBaUIsTUFBTSxZQUFZLEdBQUc7SUFDMUYsTUFBTSxTQUFTLFVBQVUsVUFBVSxFQUFFLEdBQUcsWUFBWTtJQUNwRCxNQUFNLFNBQVM7S0FDWCxHQUFHO0tBQ0gsR0FBRztLQUNILGtCQUFrQixXQUFXO0tBQzdCLGNBQWMsV0FBVztLQUN6QjtLQUNBLGVBQWU7SUFDbkIsQ0FBQztHQUNMO0VBQ0osRUFDSixDQUFDO0VBQ0QsYUFBYTtHQUNULG1CQUFtQixPQUFPLGdCQUFnQjtHQUMxQyxZQUFZO0VBQ2hCO0NBQ0o7Q0FDQSxNQUFNLGFBQWEsVUFBVTtFQUN6QixPQUFPLFFBQVE7RUFDZixNQUFNLGNBQWMsT0FBTyxLQUFLLE1BQU0sYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsUUFBUSxNQUFNLGFBQWEsTUFBTSxVQUFVLElBQUk7RUFDOUcsS0FBSyxNQUFNLE9BQU8sYUFDZCx5QkFBeUIsUUFBUSx5QkFBeUIsUUFBUSxLQUFLO0VBRTNFLE1BQU0sY0FBYyxXQUFXO0dBQzNCLEdBQUc7R0FDSCxXQUFXO0lBQ1AsR0FBRztJQUNILEdBQUcsTUFBTTtHQUNiO0VBQ0osQ0FBQztFQUNELGFBQWE7R0FFVCxLQUFLLE1BQU0sT0FBTyxZQUFZLE9BQU8sQ0FBQyxHQUNsQyx5QkFBeUIsSUFBSTtHQUVqQyxZQUFZO0VBQ2hCO0NBQ0o7Q0FDQSxNQUFNLGNBQWMsTUFBTSxVQUFVLENBQUMsTUFBTTtFQUN2QyxNQUFNLGlCQUFpQixPQUNqQixzQkFBc0IsSUFBSSxJQUMxQixDQUFDLEdBQUcsT0FBTyxLQUFLO0VBQ3RCLE1BQU0sYUFBYSxJQUFJLElBQUksY0FBYztFQUN6QyxJQUFJLE1BQ0s7UUFBQSxNQUFNLGFBQWEsT0FBTyxPQUMzQixJQUFJLGVBQWUsTUFBTSxXQUFXLFVBQVUsV0FBVyxHQUFHLE9BQU8sRUFBRSxDQUFDLEdBQ2xFLFdBQVcsSUFBSSxTQUFTO0VBQUE7RUFJcEMsSUFBSSxDQUFDLFFBQVEsa0JBQ1Qsd0JBQXdCLFVBQVU7RUFFdEMsS0FBSyxNQUFNLGFBQWEsWUFBWTtHQUNoQyxPQUFPLE1BQU0sT0FBTyxTQUFTO0dBQzdCLE9BQU8sTUFBTSxPQUFPLFNBQVM7R0FDN0IsT0FBTyxTQUFTLE9BQU8sU0FBUztHQUNoQyxNQUFNLFNBQVMsU0FBUztHQUN4QixDQUFDLFFBQVEsYUFBYSxNQUFNLGFBQWEsU0FBUztHQUNsRCxJQUFJLENBQUMsUUFBUSxXQUFXO0lBQ3BCLHVCQUF1QixTQUFTO0lBQ2hDLE1BQU0sV0FBVyxRQUFRLFNBQVM7R0FDdEM7R0FDQSxDQUFDLFFBQVEsYUFBYSxNQUFNLFdBQVcsYUFBYSxTQUFTO0dBQzdELENBQUMsUUFBUSxlQUFlLE1BQU0sV0FBVyxlQUFlLFNBQVM7R0FDakUsQ0FBQyxTQUFTLG9CQUNOLENBQUMsUUFBUSxvQkFDVCxNQUFNLGdCQUFnQixTQUFTO0VBQ3ZDO0VBQ0EsSUFBSSxDQUFDLFFBQVEsV0FDVCxXQUFXLFNBQVMsRUFBRSxHQUFHLFdBQVcsT0FBTztFQUUvQyxtQkFBbUIsUUFDZixVQUFVLE1BQU0sS0FBSyxFQUNqQixRQUFRLFlBQVksV0FBVyxFQUNuQyxDQUFDO0VBQ0wsVUFBVSxNQUFNLEtBQUs7R0FDakIsR0FBRztHQUNILEdBQUksUUFBUSxZQUFZLENBQUMsSUFBSSxFQUFFLFNBQVMsVUFBVSxFQUFFO0dBQ3BELEdBQUksUUFBUSxtQkFDTixDQUFDLElBQ0QsRUFBRSxjQUFjLENBQUMsY0FBYyxXQUFXLGdCQUFnQixFQUFFO0VBQ3RFLENBQUM7RUFDRCxDQUFDLFFBQVEsZUFBZSxVQUFVO0NBQ3RDO0NBQ0EsTUFBTSxxQkFBcUIsRUFBRSxVQUFVLFdBQVk7RUFDL0MsSUFBSyxVQUFVLFFBQVEsS0FBSyxPQUFPLFNBQy9CLENBQUMsQ0FBQyxZQUNGLE9BQU8sU0FBUyxJQUFJLElBQUksR0FBRztHQUczQixNQUFNLHVCQUZjLE9BQU8sU0FBUyxJQUFJLElBRUQsTUFBTSxDQUR6QixDQUFDO0dBRXJCLFdBQVcsT0FBTyxTQUFTLElBQUksSUFBSSxJQUFJLE9BQU8sU0FBUyxPQUFPLElBQUk7R0FDbEUsd0JBQXdCLE9BQU8sU0FBUyxDQUFDLE9BQU8sVUFBVSxVQUFVO0VBQ3hFO0NBQ0o7Q0FDQSxNQUFNLFlBQVksTUFBTSxVQUFVLENBQUMsTUFBTTtFQUNyQyxJQUFJLFFBQVEsSUFBSSxTQUFTLElBQUk7RUFDN0IsTUFBTSxvQkFBb0IsVUFBVSxRQUFRLFFBQVEsS0FBSyxVQUFVLFNBQVMsUUFBUTtFQUNwRixNQUFNLDBCQUEwQixDQUFDLE9BQU8sYUFBYSxJQUFJLElBQUksS0FBSyxTQUFTLE1BQU0sTUFBTSxDQUFDLE1BQU0sR0FBRztFQUNqRyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sSUFDakIsaUJBQWlCLFFBQVEsRUFBRTtFQUUvQixJQUFJLFNBQVMsTUFBTTtHQUNmLEdBQUksU0FBUyxDQUFDO0dBQ2QsSUFBSTtJQUNBLEdBQUksU0FBUyxNQUFNLEtBQUssTUFBTSxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRTtJQUNuRDtJQUNBLE9BQU87SUFDUCxHQUFHO0dBQ1A7RUFDSixDQUFDO0VBQ0QsT0FBTyxNQUFNLElBQUksSUFBSTtFQUNyQixJQUFJLFNBQVMsTUFBTSxJQUFJO0dBQ25CLE1BQU0sWUFBWSxJQUFJLFNBQVMsSUFBSTtHQUNuQyxLQUFLLE1BQU0sUUFBUSwyQkFDZixJQUFJLEVBQUUsUUFBUSxVQUNWLE9BQU8sVUFBVSxHQUFHO0VBR2hDO0VBQ0EsSUFBSSxTQUFTLENBQUMseUJBQ1Ysa0JBQWtCO0dBQ2QsVUFBVSxVQUFVLFFBQVEsUUFBUSxJQUM5QixRQUFRLFdBQ1IsU0FBUztHQUNmO0VBQ0osQ0FBQztPQUdELG9CQUFvQixNQUFNLE1BQU0sUUFBUSxLQUFLO0VBRWpELE9BQU87R0FDSCxHQUFJLG9CQUNFLEVBQUUsVUFBVSxRQUFRLFlBQVksU0FBUyxTQUFTLElBQ2xELENBQUM7R0FDUCxHQUFJLFNBQVMsY0FDUDtJQUNFLFVBQVUsQ0FBQyxDQUFDLGFBQWEsUUFBUSxRQUFRO0lBQ3pDLEtBQUssYUFBYSxRQUFRLEdBQUc7SUFDN0IsS0FBSyxhQUFhLFFBQVEsR0FBRztJQUM3QixXQUFXLGFBQWEsUUFBUSxTQUFTO0lBQ3pDLFdBQVcsYUFBYSxRQUFRLFNBQVM7SUFDekMsU0FBUyxhQUFhLFFBQVEsT0FBTztHQUN6QyxJQUNFLENBQUM7R0FDUDtHQUNBO0dBQ0EsUUFBUTtHQUNSLE1BQU0sUUFBUTtJQUNWLElBQUksS0FBSztLQUNMLE9BQU8sYUFBYSxJQUFJLElBQUk7S0FDNUIsU0FBUyxNQUFNLE9BQU87S0FDdEIsT0FBTyxhQUFhLE9BQU8sSUFBSTtLQUMvQixRQUFRLElBQUksU0FBUyxJQUFJO0tBQ3pCLE1BQU0sV0FBVyxZQUFZLElBQUksS0FBSyxJQUNoQyxJQUFJLG1CQUNBLElBQUksaUJBQWlCLHVCQUF1QixDQUFDLENBQUMsTUFBTSxNQUNwRCxNQUNKO0tBQ04sTUFBTSxrQkFBa0Isa0JBQWtCLFFBQVE7S0FDbEQsTUFBTSxPQUFPLE1BQU0sR0FBRyxRQUFRLENBQUM7S0FDL0IsSUFBSSxrQkFDRSxLQUFLLE1BQU0sV0FBVyxXQUFXLFFBQVEsSUFDekMsYUFBYSxNQUFNLEdBQUcsS0FDeEI7S0FFSixNQUFNLFdBQVcsRUFDYixHQUFHLE1BQU0sR0FDYjtLQUNBLElBQUksaUJBQWlCO01BQ2pCLFNBQVMsT0FBTztPQUNaLEdBQUcsS0FBSyxPQUFPLElBQUk7T0FDbkI7T0FDQSxHQUFJLE1BQU0sUUFBUSxJQUFJLGdCQUFnQixJQUFJLENBQUMsSUFDckMsQ0FBQyxDQUFDLENBQUMsSUFDSCxDQUFDO01BQ1g7TUFDQSxTQUFTLE1BQU07T0FBRSxNQUFNLFNBQVM7T0FBTTtNQUFLO0tBQy9DLE9BQ0s7TUFDRCxTQUFTLE1BQU07TUFDZixPQUFPLFNBQVM7S0FDcEI7S0FDQSxJQUFJLFNBQVMsTUFBTSxFQUNmLElBQUksU0FDUixDQUFDO0tBQ0Qsb0JBQW9CLE1BQU0sT0FBTyxLQUFBLEdBQVcsUUFBUTtJQUN4RCxPQUNLO0tBQ0QsUUFBUSxJQUFJLFNBQVMsTUFBTSxDQUFDLENBQUM7S0FDN0IsSUFBSSxNQUFNLElBQ04sTUFBTSxHQUFHLFFBQVE7S0FFckIsQ0FBQyxTQUFTLG9CQUFvQixRQUFRLHFCQUNsQyxFQUFFLG1CQUFtQixPQUFPLE9BQU8sSUFBSSxLQUFLLE9BQU8sV0FDbkQsT0FBTyxRQUFRLElBQUksSUFBSTtJQUMvQjtHQUNKO0VBQ0o7Q0FDSjtDQUNBLE1BQU0sb0JBQW9CLFNBQVMsb0JBQy9CLENBQUMsU0FBUyw2QkFDVixzQkFBc0IsU0FBUyxhQUFhLE9BQU8sS0FBSztDQUM1RCxNQUFNLGdCQUFnQixhQUFhO0VBQy9CLElBQUksVUFBVSxRQUFRLEdBQUc7R0FDckIsVUFBVSxNQUFNLEtBQUssRUFBRSxTQUFTLENBQUM7R0FDakMsc0JBQXNCLFVBQVUsS0FBSyxTQUFTO0lBQzFDLE1BQU0sZUFBZSxJQUFJLFNBQVMsSUFBSTtJQUN0QyxJQUFJLGNBQWM7S0FDZCxJQUFJLFdBQVcsYUFBYSxHQUFHLFlBQVk7S0FDM0MsSUFBSSxNQUFNLFFBQVEsYUFBYSxHQUFHLElBQUksR0FDbEMsYUFBYSxHQUFHLEtBQUssU0FBUyxhQUFhO01BQ3ZDLFNBQVMsV0FBVyxhQUFhLEdBQUcsWUFBWTtLQUNwRCxDQUFDO0lBRVQ7R0FDSixHQUFHLENBQUM7RUFDUjtDQUNKO0NBQ0EsTUFBTSxnQkFBZ0IsU0FBUyxjQUFjLE9BQU8sTUFBTTtFQUN0RCxJQUFJLFNBQVMsS0FBQTtFQUNiLElBQUksZUFBZSxLQUFBO0VBQ25CLElBQUksZ0JBQWdCO0VBQ3BCLElBQUksR0FBRztHQUNILEVBQUUsa0JBQWtCLEVBQUUsZUFBZTtHQUNyQyxFQUFFLFdBQVcsRUFBRSxRQUFRO0VBQzNCO0VBQ0EsSUFBSSxjQUFjLFlBQVksV0FBVztFQUN6QyxVQUFVLE1BQU0sS0FBSyxFQUNqQixjQUFjLEtBQ2xCLENBQUM7RUFDRCxNQUFNLGNBQWM7RUFDcEIsTUFBTSxpQkFBaUIsVUFBVTtHQUM3QixJQUFJLGdCQUFnQixjQUNoQixVQUFVLE1BQU0sS0FBSyxFQUFFLGNBQWMsTUFBTSxDQUFDO0dBRWhELE1BQU07RUFDVjtFQUNBLElBQUksU0FBUyxVQUFVO0dBQ25CLElBQUk7R0FDSixJQUFJO0lBQ0EsbUJBQW1CLE1BQU0sV0FBVztHQUN4QyxTQUNPLE9BQU87SUFDVixjQUFjLEtBQUs7R0FDdkI7R0FDQSxNQUFNLEVBQUUsUUFBUSxXQUFXO0dBQzNCLElBQUksZ0JBQWdCLGNBQ2hCO0dBRUosb0JBQW9CO0dBQ3BCLE9BQU8sS0FBSyxtQkFBbUIsQ0FBQyxDQUFDLFFBQVEsa0JBQWtCO0dBQzNELFdBQVcsU0FBUztHQUNwQixjQUFjLFlBQVksTUFBTTtFQUNwQyxPQUNLO0dBQ0QsSUFBSTtJQUNBLE1BQU0seUJBQXlCO0tBQzNCLFFBQVE7S0FDUixXQUFXLE9BQU87SUFDdEIsQ0FBQztHQUNMLFNBQ08sT0FBTztJQUNWLGNBQWMsS0FBSztHQUN2QjtHQUNBLElBQUksZ0JBQWdCLGNBQ2hCO0dBRUosTUFBTSxXQUFXLFFBQVEsZUFBZTtHQUN4QyxXQUFXLFNBQVMsRUFBRSxHQUFHLFdBQVcsT0FBTztFQUMvQztFQUNBLElBQUksT0FBTyxTQUFTLFNBQ2YsU0FBUyxXQUFXLEtBQUssTUFBTSxRQUFRLFdBQVcsSUFDbkQsS0FBSyxNQUFNLFFBQVEsT0FBTyxVQUN0QixNQUFNLGFBQWEsSUFBSTtFQUcvQixJQUFJLGNBQWMsV0FBVyxNQUFNLEdBQUc7R0FDbEMsVUFBVSxNQUFNLEtBQUssRUFDakIsUUFBUSxDQUFDLEVBQ2IsQ0FBQztHQUNELElBQUk7SUFDQSxTQUFTLE1BQU0sUUFBUSxhQUFhLENBQUM7R0FDekMsU0FDTyxPQUFPO0lBQ1YsZ0JBQWdCO0lBQ2hCLGVBQWU7R0FDbkI7RUFDSixPQUNLO0dBQ0QsSUFBSSxXQUNBLElBQUk7SUFDQSxNQUFNLFVBQVUsRUFBRSxHQUFHLFdBQVcsT0FBTyxHQUFHLENBQUM7R0FDL0MsU0FDTyxPQUFPO0lBQ1YsY0FBYyxLQUFLO0dBQ3ZCO0dBRUosSUFBSSxnQkFBZ0IsY0FBYztJQUM5QixZQUFZO0lBQ1osV0FBVyxXQUFXO0dBQzFCO0VBQ0o7RUFDQSxJQUFJLGdCQUFnQixjQUNoQixVQUFVLE1BQU0sS0FBSztHQUNqQixhQUFhO0dBQ2IsY0FBYztHQUNkLG9CQUFvQixjQUFjLFdBQVcsTUFBTSxLQUFLLENBQUM7R0FDekQsYUFBYSxXQUFXLGNBQWM7R0FDdEMsUUFBUSxXQUFXO0VBQ3ZCLENBQUM7RUFFTCxJQUFJLGVBQ0EsTUFBTTtFQUVWLE9BQU87Q0FDWDtDQUNBLE1BQU0sY0FBYyxNQUFNLFVBQVUsQ0FBQyxNQUFNO0VBQ3ZDLElBQUksSUFBSSxTQUFTLElBQUksR0FBRztHQUNwQix3QkFBd0IsQ0FBQyxJQUFJLENBQUM7R0FDOUIsSUFBSSxZQUFZLFFBQVEsWUFBWSxHQUNoQyxTQUFTLE1BQU0sWUFBWSxJQUFJLGdCQUFnQixJQUFJLENBQUMsQ0FBQztRQUVwRDtJQUNELFNBQVMsTUFBTSxRQUFRLFlBQVk7SUFDbkMsaUJBQWlCLFlBQVksY0FBYztJQUMzQyxJQUFJLGdCQUFnQixNQUFNLFlBQVksUUFBUSxZQUFZLENBQUM7R0FDL0Q7R0FDQSxJQUFJLENBQUMsUUFBUSxhQUNULE1BQU0sV0FBVyxlQUFlLElBQUk7R0FFeEMsSUFBSSxDQUFDLFFBQVEsV0FBVztJQUNwQixNQUFNLFdBQVcsYUFBYSxJQUFJO0lBQ2xDLFdBQVcsVUFBVSxDQUFDLFlBQVksUUFBUSxZQUFZLElBQ2hELFVBQVUsTUFBTSxZQUFZLElBQUksZ0JBQWdCLElBQUksQ0FBQyxDQUFDLElBQ3RELFVBQVU7R0FDcEI7R0FDQSxJQUFJLENBQUMsUUFBUSxXQUFXO0lBQ3BCLHVCQUF1QixJQUFJO0lBQzNCLE1BQU0sV0FBVyxRQUFRLElBQUk7SUFDN0IsV0FBVyxTQUFTLEVBQUUsR0FBRyxXQUFXLE9BQU87SUFDM0MsVUFBVTtHQUNkO0dBQ0EsVUFBVSxNQUFNLEtBQUs7SUFDakIsR0FBRztJQUNILGNBQWMsQ0FBQyxjQUFjLFdBQVcsZ0JBQWdCO0dBQzVELENBQUM7RUFDTDtDQUNKO0NBQ0EsTUFBTSxVQUFVLFlBQVksbUJBQW1CLENBQUMsTUFBTTtFQUNsRDtFQUNBLE1BQU0sZ0JBQWdCLGFBQWEsWUFBWSxVQUFVLElBQUk7RUFDN0QsTUFBTSxxQkFBcUIsWUFBWSxhQUFhO0VBQ3BELE1BQU0scUJBQXFCLGNBQWMsVUFBVTtFQUNuRCxNQUFNLFNBQVM7RUFDZixNQUFNLFlBQVk7RUFDbEIsT0FBTyxLQUFLLG1CQUFtQixDQUFDLENBQUMsUUFBUSxrQkFBa0I7RUFDM0QsSUFBSSxDQUFDLGlCQUFpQixtQkFDbEIsaUJBQWlCO0VBRXJCLElBQUksQ0FBQyxpQkFBaUIsWUFBWTtHQUM5QixJQUFJLGlCQUFpQixpQkFBaUI7SUFDbEMsTUFBTSxnQ0FBZ0IsSUFBSSxJQUFJLENBQzFCLEdBQUcsT0FBTyxPQUNWLEdBQUcsdUJBQXVCLGVBQWUsZ0JBQWdCLGFBQWEsS0FBQSxHQUFXLFNBQVMsR0FBRyxXQUFXLFdBQVcsQ0FDdkgsQ0FBQztJQUNELEtBQUssTUFBTSxhQUFhLGVBQWU7S0FDbkMsTUFBTSxVQUFVLElBQUksV0FBVyxhQUFhLFNBQVM7S0FDckQsTUFBTSxnQkFBZ0IsSUFBSSxhQUFhLFNBQVM7S0FDaEQsTUFBTSxXQUFXLElBQUksUUFBUSxTQUFTO0tBQ3RDLElBQUksV0FBVyxDQUFDLFlBQVksYUFBYSxHQUNyQyxJQUFJLFFBQVEsV0FBVyxhQUFhO1VBRW5DLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxRQUFRLEdBQ3RDLFNBQVMsV0FBVyxRQUFRO0lBRXBDO0dBQ0osT0FDSztJQUNELElBQUksU0FBUyxZQUFZLFVBQVUsR0FDL0IsS0FBSyxNQUFNLFFBQVEsT0FBTyxPQUFPO0tBQzdCLE1BQU0sUUFBUSxJQUFJLFNBQVMsSUFBSTtLQUMvQixJQUFJLFNBQVMsTUFBTSxJQUFJO01BQ25CLE1BQU0saUJBQWlCLE1BQU0sUUFBUSxNQUFNLEdBQUcsSUFBSSxJQUM1QyxNQUFNLEdBQUcsS0FBSyxLQUNkLE1BQU0sR0FBRztNQUNmLElBQUksY0FBYyxjQUFjLEdBQUc7T0FDL0IsTUFBTSxPQUFPLGVBQWUsUUFBUSxNQUFNO09BQzFDLElBQUksTUFBTTtRQUNOLEtBQUssTUFBTTtRQUNYO09BQ0o7TUFDSjtLQUNKO0lBQ0o7SUFFSixJQUFJLGlCQUFpQixlQUNqQixLQUFLLE1BQU0sYUFBYSxPQUFPLE9BQzNCLFNBQVMsV0FBVyxJQUFJLFFBQVEsU0FBUyxDQUFDO1NBSTlDLFVBQVUsQ0FBQztHQUVuQjtHQUNBLElBQUksU0FBUyxrQkFBa0I7SUFDM0IsY0FBYyxpQkFBaUIsb0JBQ3pCLFlBQVksY0FBYyxJQUMxQixDQUFDO0lBQ1AsSUFBSSxpQkFBaUIsZUFDakIsS0FBSyxNQUFNLGFBQWEsT0FBTyxPQUMzQixJQUFJLGFBQWEsV0FBVyxJQUFJLFFBQVEsU0FBUyxDQUFDO0dBRzlELE9BRUksY0FBYyxZQUFZLE1BQU07R0FFcEMsVUFBVSxNQUFNLEtBQUssRUFDakIsUUFBUSxFQUFFLEdBQUcsT0FBTyxFQUN4QixDQUFDO0dBQ0QsVUFBVSxNQUFNLEtBQUs7SUFDakIsTUFBTSxLQUFBO0lBQ04sTUFBTSxLQUFBO0lBQ04sUUFBUSxFQUFFLEdBQUcsT0FBTztHQUN4QixDQUFDO0VBQ0w7RUFDQSxTQUFTO0dBQ0wsT0FBTyxpQkFBaUIsbUJBQW1CLGlCQUFpQixnQkFDdEQsT0FBTyx3QkFDUCxJQUFJLElBQUk7R0FDZCx5QkFBUyxJQUFJLElBQUk7R0FDakIsdUJBQU8sSUFBSSxJQUFJO0dBQ2YsOEJBQWMsSUFBSSxJQUFJO0dBQ3RCLFVBQVUsaUJBQWlCLGNBQ3ZCLGlCQUFpQixtQkFDakIsaUJBQWlCLGdCQUNmLElBQUksSUFBSSxDQUFDLEdBQUcsT0FBTyxRQUFRLENBQUMsQ0FBQyxRQUFRLFNBQVMsSUFBSSxTQUFTLElBQUksQ0FBQyxDQUFDLG9CQUNqRSxJQUFJLElBQUk7R0FDZCx1QkFBTyxJQUFJLElBQUk7R0FDZixVQUFVO0dBQ1YsT0FBTztFQUNYO0VBQ0EsT0FBTyxRQUNILENBQUMsZ0JBQWdCLFdBQ2IsQ0FBQyxDQUFDLGlCQUFpQixlQUNuQixDQUFDLENBQUMsaUJBQWlCLG1CQUNsQixDQUFDLFNBQVMsb0JBQW9CLENBQUMsY0FBYyxNQUFNO0VBQzVELE9BQU8sUUFBUSxDQUFDLENBQUMsU0FBUztFQUMxQixPQUFPLGNBQWMsQ0FBQyxDQUFDLGlCQUFpQjtFQUN4QyxPQUFPLFNBQVM7RUFDaEIsT0FBTyxtQkFBbUIsTUFBTTtFQUNoQyxvQkFBb0I7RUFDcEIsSUFBSSxDQUFDLGlCQUFpQixZQUNsQixXQUFXLFNBQVMsQ0FBQztFQUV6QixVQUFVLE1BQU0sS0FBSztHQUNqQixhQUFhLGlCQUFpQixrQkFDeEIsV0FBVyxjQUNYO0dBQ04sU0FBUyxxQkFDSCxRQUNBLGlCQUFpQixZQUNiLFdBQVcsVUFDWCxpQkFBaUIsYUFDYixVQUFVLElBQ1YsQ0FBQyxFQUFFLGlCQUFpQixxQkFDbEIsY0FDQSxDQUFDLFVBQVUsWUFBWSxjQUFjO0dBQ3JELGFBQWEsaUJBQWlCLGtCQUN4QixXQUFXLGNBQ1g7R0FDTixhQUFjLHFCQUNSLENBQUMsSUFDRCxpQkFBaUIsa0JBQ2IsaUJBQWlCLHFCQUFxQixjQUNsQyxlQUFlLGdCQUFnQixhQUFhLEtBQUEsR0FBVyxTQUFTLElBQ2hFLFdBQVcsY0FDZixpQkFBaUIscUJBQXFCLGFBQ2xDLGVBQWUsZ0JBQWdCLFlBQVksS0FBQSxHQUFXLFNBQVMsSUFDL0QsaUJBQWlCLFlBQ2IsV0FBVyxjQUNYLGlCQUFpQixhQUNiLGVBQWUsZ0JBQWdCLGFBQWEsS0FBQSxHQUFXLFNBQVMsSUFDaEUsQ0FBQztHQUN2QixlQUFlLGlCQUFpQixjQUMxQixXQUFXLGdCQUNYLENBQUM7R0FDUCxHQUFJLENBQUMsaUJBQWlCLHFCQUNqQixXQUFXLGdCQUFnQixDQUFDLGNBQWMsV0FBVyxnQkFBZ0IsS0FDcEU7SUFBRSxrQkFBa0IsQ0FBQztJQUFHLGNBQWM7R0FBTSxJQUM1QztHQUNOLFFBQVEsaUJBQWlCLGFBQWEsV0FBVyxTQUFTLENBQUM7R0FDM0Qsb0JBQW9CLGlCQUFpQix5QkFDL0IsV0FBVyxxQkFDWDtHQUNOLGNBQWM7R0FDZCxlQUFlO0VBQ25CLENBQUM7Q0FDTDtDQUNBLE1BQU0sU0FBUyxZQUFZLHFCQUFxQixPQUFPLFdBQVcsVUFBVSxJQUFJLFdBQVcsV0FBVyxJQUFJLFlBQVk7RUFDbEgsR0FBRyxTQUFTO0VBQ1osR0FBRztDQUNQLENBQUM7Q0FDRCxNQUFNLFlBQVksTUFBTSxVQUFVLENBQUMsTUFBTTtFQUNyQyxNQUFNLFFBQVEsSUFBSSxTQUFTLElBQUk7RUFDL0IsTUFBTSxpQkFBaUIsU0FBUyxNQUFNO0VBQ3RDLElBQUksZ0JBQWdCO0dBQ2hCLE1BQU0sV0FBWSxlQUFlLE9BQzNCLGVBQWUsS0FBSyxNQUFNLFFBQVEsQ0FBQyxJQUFJLFFBQVEsS0FDN0MsZUFBZSxLQUFLLEtBQ3RCLGVBQWU7R0FDckIsSUFBSSxTQUFTLE9BQ1QsaUJBQWlCO0lBQ2IsU0FBUyxNQUFNO0lBQ2YsUUFBUSxnQkFDSixXQUFXLFNBQVMsTUFBTSxLQUMxQixTQUFTLE9BQU87R0FDeEIsQ0FBQztFQUVUO0NBQ0o7Q0FDQSxNQUFNLGlCQUFpQixxQkFBcUI7RUFNeEMsTUFBTSxFQUFFLE1BQU0sTUFBTSxRQUFRLEdBQUcsY0FBYztFQUM3QyxJQUFJLE9BQU8sS0FBSyxTQUFTLENBQUMsQ0FBQyxRQUN2QixhQUFhO0dBQ1QsR0FBRztHQUNILEdBQUc7RUFDUDtDQUVSO0NBQ0EsVUFBVSxNQUFNLFVBQVUsRUFBRSxNQUFNLGNBQWMsQ0FBQztDQUNqRCxNQUFNLDRCQUE0QixXQUFXLFNBQVMsYUFBYSxLQUMvRCxTQUFTLGNBQWMsQ0FBQyxDQUFDLE1BQU0sV0FBVztFQUN0QyxNQUFNLFFBQVEsU0FBUyxZQUFZO0VBQ25DLFVBQVUsTUFBTSxLQUFLLEVBQ2pCLFdBQVcsTUFDZixDQUFDO0NBQ0wsQ0FBQztDQUNMLE1BQU0sc0JBQXNCLFFBQVEsVUFBVSxDQUFDLE1BQU07RUFDakQsaUJBQWlCLFlBQVksTUFBTTtFQUNuQyxJQUFJLENBQUMsUUFBUSxXQUFXO0dBQ3BCLE1BQU0saUJBQWlCLGVBQWUsZ0JBQWdCLGFBQWEsS0FBQSxHQUFXLE9BQU87R0FDckYsV0FBVyxjQUFjO0dBQ3pCLFdBQVcsVUFBVSxDQUFDLGNBQWMsY0FBYztFQUN0RDtFQUNBLElBQUksQ0FBQyxRQUFRLGFBQ1QsVUFBVTtFQUVkLFVBQVUsTUFBTSxLQUFLO0dBQ2pCLEdBQUc7R0FDSCxlQUFlO0VBQ25CLENBQUM7Q0FDTDtDQUNBLE1BQU0sVUFBVTtFQUNaLFNBQVM7R0FDTDtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBLElBQUksVUFBVTtJQUNWLE9BQU87R0FDWDtHQUNBLElBQUksY0FBYztJQUNkLE9BQU87R0FDWDtHQUNBLElBQUksU0FBUztJQUNULE9BQU87R0FDWDtHQUNBLElBQUksT0FBTyxPQUFPO0lBQ2QsU0FBUztHQUNiO0dBQ0EsSUFBSSxpQkFBaUI7SUFDakIsT0FBTztHQUNYO0dBQ0EsSUFBSSxTQUFTO0lBQ1QsT0FBTztHQUNYO0dBQ0EsSUFBSSxPQUFPLE9BQU87SUFDZCxTQUFTO0dBQ2I7R0FDQSxJQUFJLGFBQWE7SUFDYixPQUFPO0dBQ1g7R0FDQSxJQUFJLFdBQVc7SUFDWCxPQUFPO0dBQ1g7R0FDQSxJQUFJLFNBQVMsT0FBTztJQUNoQixXQUFXO0tBQ1AsR0FBRztLQUNILEdBQUc7SUFDUDtJQUNBLDhCQUE4QixtQkFBbUIsU0FBUyxJQUFJO0lBQzlELDZCQUE2QixtQkFBbUIsU0FBUyxjQUFjO0lBQ3ZFLG1DQUNJLFNBQVMsaUJBQWlCLGdCQUFnQjtHQUNsRDtFQUNKO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNKO0NBQ0EsT0FBTztFQUNILEdBQUc7RUFDSCxhQUFhO0NBQ2pCO0FBQ0o7QUFFQSxJQUFNLGdCQUFnQjtDQUNsQixNQUFNLGVBQWU7Q0FDckIsZ0JBQWdCLGVBQWU7Q0FDL0Isa0JBQWtCLGVBQWU7Q0FDakMsVUFBVSxLQUFBO0NBQ1YsY0FBYyxLQUFBO0NBQ2QsWUFBWSxLQUFBO0NBQ1osa0JBQWtCLEtBQUE7Q0FDbEIsMkJBQTJCLEtBQUE7Q0FDM0IsU0FBUyxLQUFBO0NBQ1QsYUFBYSxLQUFBO0NBQ2IsY0FBYyxLQUFBO0FBQ2xCOzs7Ozs7Ozs7Ozs7Ozs7QUFlQSxTQUFTLFFBQVEsUUFBUSxDQUFDLEdBQUc7Q0FDekIsTUFBTSxlQUFBLGFBQXFCLE9BQU8sS0FBQSxDQUFTO0NBQzNDLE1BQU0sVUFBQSxhQUFnQixPQUFPLEtBQUEsQ0FBUztDQUN0QyxNQUFNLG1CQUFBLGFBQXlCLE9BQU8sTUFBTSxXQUFXO0NBQ3ZELE1BQU0sZUFBQSxhQUFxQixPQUFPLEtBQUs7Q0FDdkMsTUFBTSxlQUFBLGFBQXFCLE9BQU8sQ0FBQyxDQUFDLE1BQU0sUUFBUTtDQUNsRCxNQUFNLGFBQUEsYUFBbUIsT0FBTyxDQUFDLENBQUMsTUFBTSxNQUFNO0NBQzlDLE1BQU0sYUFBQSxhQUFtQixPQUFPLEtBQUs7Q0FDckMsTUFBTSxDQUFDLFdBQVcsbUJBQUEsYUFBeUIsZ0JBQWdCO0VBQ3ZELEdBQUcsWUFBWSxrQkFBa0I7RUFDakMsV0FBVyxXQUFXLE1BQU0sYUFBYTtFQUN6QyxRQUFRLE1BQU0sVUFBVSxDQUFDO0VBQ3pCLFVBQVUsTUFBTSxZQUFZO0VBQzVCLGVBQWUsV0FBVyxNQUFNLGFBQWEsSUFDdkMsS0FBQSxJQUNBLE1BQU07Q0FDaEIsRUFBRTtDQUNGLElBQUksQ0FBQyxhQUFhLFdBQ2IsTUFBTSxlQUFlLGlCQUFpQixZQUFZLE1BQU0sYUFBYztFQUN2RSxpQkFBaUIsVUFBVSxNQUFNO0VBQ2pDLGFBQWEsVUFBVTtFQUN2QixJQUFJLE1BQU0sYUFBYTtHQUNuQixhQUFhLFVBQVU7SUFDbkIsR0FBRyxNQUFNO0lBQ1Q7R0FDSjtHQUNBLElBQUksTUFBTSxpQkFBaUIsQ0FBQyxXQUFXLE1BQU0sYUFBYSxHQUN0RCxNQUFNLFlBQVksTUFBTSxNQUFNLGVBQWUsTUFBTSxZQUFZO0VBRXZFLE9BQ0s7R0FDRCxNQUFNLEVBQUUsYUFBYSxHQUFHLFNBQVMsa0JBQWtCLEtBQUs7R0FDeEQsYUFBYSxVQUFVO0lBQ25CLEdBQUc7SUFDSDtHQUNKO0VBQ0o7Q0FDSjtDQUNBLE1BQU0sVUFBVSxhQUFhLFFBQVE7Q0FDckMsTUFBTSxrQkFBa0IsUUFBUTtDQUNoQyxNQUFNLGlCQUFpQixDQUFDO0NBQ3hCLEtBQUssTUFBTSxPQUFPLGVBQ2QsSUFBSSxPQUFPLG1CQUFtQixFQUFFLE9BQU8sUUFDbkMsZUFBZSxPQUFPLGNBQWM7Q0FHNUMsSUFBSSxhQUFhLFdBQVcsQ0FBQyxNQUFNLFVBQy9CLGVBQWUsV0FBVztDQUU5QixRQUFRLFdBQVc7RUFDZixHQUFHO0VBQ0gsR0FBRztFQUNILFVBQVUsTUFBTTtDQUNwQjtDQUNBLE1BQU0sNkJBQTZCO0VBQy9CLEdBQUcsUUFBUTtFQUNYLGVBQWUsUUFBUTtDQUMzQjtDQUNBLE1BQU0sRUFBRSxnQkFBZ0IsYUFBYSxxQkFBcUIscUJBQXFCLGNBQWM7Q0FDN0YsZ0NBQWdDO0VBQzVCLGVBQWUsTUFBTSxxQkFBcUIsZUFBZTtFQUN6RCxNQUFNLGNBQWMsUUFBUSxXQUFXO0dBQ25DLFdBQVcsUUFBUTtHQUNuQixnQkFBZ0IsZ0JBQWdCO0lBQzVCLEdBQUcsUUFBUTtJQUNYLGVBQWUsUUFBUTtHQUMzQixDQUFDO0dBQ0QsY0FBYztFQUNsQixDQUFDO0VBQ0QsaUJBQWlCLFVBQVU7R0FDdkIsR0FBRztHQUNILFNBQVM7RUFDYixFQUFFO0VBQ0YsUUFBUSxXQUFXLFVBQVU7RUFDN0IsUUFBUSxVQUFVLE1BQU0sS0FBSyxFQUFFLFNBQVMsS0FBSyxDQUFDO0VBQzlDLGFBQWE7R0FDVCxZQUFZO0dBQ1osU0FBUyxNQUFNLG1CQUFtQjtFQUN0QztDQUNKLEdBQUc7RUFBQztFQUFTO0VBQWdCO0NBQVEsQ0FBQztDQUN0QyxhQUFNLGdCQUFnQjtFQUNsQixRQUFRLGFBQWEsYUFBYSxXQUFXLENBQUMsTUFBTSxXQUFXLFFBQVEsTUFBTSxRQUFRO0VBQ3JGLGFBQWEsVUFBVSxDQUFDLENBQUMsTUFBTTtDQUNuQyxHQUFHLENBQUMsU0FBUyxNQUFNLFFBQVEsQ0FBQztDQUM1QixhQUFNLGdCQUFnQjtFQUNsQixJQUFJLE1BQU0sTUFDTixRQUFRLFNBQVMsT0FBTyxNQUFNO0VBRWxDLElBQUksTUFBTSxnQkFDTixRQUFRLFNBQVMsaUJBQWlCLE1BQU07Q0FFaEQsR0FBRztFQUFDO0VBQVMsTUFBTTtFQUFNLE1BQU07Q0FBYyxDQUFDO0NBQzlDLGFBQU0sZ0JBQWdCO0VBQ2xCLElBQUksTUFBTSxRQUFRO0dBQ2QsUUFBUSxXQUFXLE1BQU0sTUFBTTtHQUMvQixRQUFRLFlBQVk7RUFDeEIsT0FDSyxJQUFJLFdBQVcsU0FDaEIsUUFBUSxXQUFXLENBQUMsQ0FBQztFQUV6QixXQUFXLFVBQVUsQ0FBQyxDQUFDLE1BQU07Q0FDakMsR0FBRyxDQUFDLFNBQVMsTUFBTSxNQUFNLENBQUM7Q0FDMUIsYUFBTSxnQkFBZ0I7RUFDbEIsSUFBSSxhQUFhLFdBQVcsQ0FBQyxNQUFNLFVBQy9CLGFBQWEsV0FBVyxhQUFhLFFBQVEsWUFBWSxlQUFlO0VBRTVFLGFBQWEsVUFBVSxDQUFDLENBQUMsTUFBTTtDQUNuQyxHQUFHLENBQUMsTUFBTSxRQUFRLENBQUM7Q0FDbkIsYUFBTSxnQkFBZ0I7RUFDbEIsTUFBTSxvQkFDRixRQUFRLFVBQVUsTUFBTSxLQUFLLEVBQ3pCLFFBQVEsUUFBUSxVQUFVLEVBQzlCLENBQUM7Q0FDVCxHQUFHLENBQUMsU0FBUyxNQUFNLGdCQUFnQixDQUFDO0NBQ3BDLGFBQU0sZ0JBQWdCO0VBQ2xCLElBQUksUUFBUSxnQkFBZ0IsU0FBUztHQUNqQyxNQUFNLFVBQVUsUUFBUSxVQUFVO0dBQ2xDLElBQUksWUFBWSxVQUFVLFNBQ3RCLFFBQVEsVUFBVSxNQUFNLEtBQUssRUFDekIsUUFDSixDQUFDO0VBRVQ7Q0FDSixHQUFHLENBQUMsU0FBUyxVQUFVLE9BQU8sQ0FBQztDQUMvQixhQUFNLGdCQUFnQjtFQUNsQixJQUFJLE1BQU0sVUFBVSxDQUFDLFVBQVUsTUFBTSxRQUFRLFFBQVEsT0FBTyxHQUFHO0dBQzNELFFBQVEsT0FBTyxNQUFNLFFBQVE7SUFDekIsZUFBZTtJQUNmLEdBQUcsUUFBUSxTQUFTO0dBQ3hCLENBQUM7R0FDRCxJQUFJLEVBQUUsUUFBUSxTQUFTLGdCQUNuQixRQUFRLFNBQVMsYUFBYSxjQUM5QixRQUFRLFVBQVU7R0FFdEIsUUFBUSxVQUFVLE1BQU07R0FDeEIsaUJBQWlCLFdBQVcsRUFBRSxHQUFHLE1BQU0sRUFBRTtFQUM3QyxPQUVJLFFBQVEsb0JBQW9CO0NBRXBDLEdBQUcsQ0FBQyxTQUFTLE1BQU0sTUFBTSxDQUFDO0NBQzFCLGFBQU0sZ0JBQWdCO0VBQ2xCLElBQUksQ0FBQyxRQUFRLE9BQU8sU0FBVSxDQUFDLFdBQVcsV0FBVyxDQUFDLE1BQU0sUUFBUztHQUNqRSxRQUFRLFVBQVU7R0FDbEIsUUFBUSxPQUFPLFFBQVE7RUFDM0I7RUFDQSxXQUFXLFVBQVU7RUFDckIsSUFBSSxRQUFRLE9BQU8sT0FBTztHQUN0QixRQUFRLE9BQU8sUUFBUTtHQUN2QixRQUFRLFVBQVUsTUFBTSxLQUFLLEVBQUUsR0FBRyxRQUFRLFdBQVcsQ0FBQztFQUMxRDtFQUNBLFFBQVEsaUJBQWlCO0NBQzdCLENBQUM7Q0FDRCxhQUFhLFFBQVEsWUFBQSxhQUFrQixjQUFjLGtCQUFrQixXQUFXLE9BQU8sR0FBRyxDQUFDLFNBQVMsU0FBUyxDQUFDO0NBQ2hILE9BQU8sYUFBYTtBQUN4QjtBQUVBLElBQU0sa0JBQUEsYUFBd0IsY0FBYyxJQUFJO0FBQ2hELGdCQUFnQixjQUFjOzs7Ozs7Ozs7Ozs7QUFZOUIsSUFBTSx1QkFBQSxhQUE2QixXQUFXLGVBQWU7Ozs7Ozs7Ozs7Ozs7O0FBYzdELElBQU0sZ0JBQWdCLEVBQUUsVUFBVSxPQUFPLFdBQVcsV0FBVyxlQUFlLFVBQVUsYUFBYSxVQUFVLFdBQVcsU0FBUyxXQUFXLFlBQVksT0FBTyxvQkFBb0IsY0FBYyxZQUFZLFNBQVMsVUFBVSxVQUFVLGdCQUFpQjtDQUN6UCxNQUFNLGdCQUFBLGFBQXNCLGVBQWU7RUFDdkM7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDSixJQUFJO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDSixDQUFDO0NBQ0QsT0FBQSxhQUFjLGNBQWMsZ0JBQWdCLFVBQVUsRUFBRSxPQUFPLGNBQWMsR0FBQSxhQUNuRSxjQUFjLHVCQUF1QixVQUFVLEVBQUUsT0FBTyxjQUFjLFFBQVEsR0FBRyxRQUFRLENBQUM7QUFDeEc7Ozs7Ozs7Ozs7Ozs7OztBQWdCQSxJQUFNLFNBQVMsVUFBVSxNQUFNLE9BQU8sU0FBUztDQUFFLE1BQU0sTUFBTTtDQUFPLEdBQUc7QUFBTSxDQUFDLENBQUMiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF19
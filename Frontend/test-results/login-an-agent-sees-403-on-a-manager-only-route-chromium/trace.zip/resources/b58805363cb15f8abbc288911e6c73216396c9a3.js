import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/admin.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { useTranslation } from "/src/i18n/index.ts";
import { PagePlaceholder } from "/src/pages/PagePlaceholder.tsx";
var _jsxFileName = "C:/CarHire/Frontend/src/pages/admin.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=bb1d9b35";
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$(), _s6 = $RefreshSig$(), _s7 = $RefreshSig$(), _s8 = $RefreshSig$(), _s9 = $RefreshSig$(), _s10 = $RefreshSig$(), _s11 = $RefreshSig$(), _s12 = $RefreshSig$();
export function DashboardPage() {
	_s();
	const { t } = useTranslation();
	return /* @__PURE__ */ _jsxDEV(PagePlaceholder, { title: t("page.dashboard") }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 4,
		columnNumber: 74
	}, this);
}
_s(DashboardPage, "zlIdU9EjM2llFt74AbE2KsUJXyM=", false, function() {
	return [useTranslation];
});
_c = DashboardPage;
export function FleetPage() {
	_s2();
	const { t } = useTranslation();
	return /* @__PURE__ */ _jsxDEV(PagePlaceholder, { title: t("page.fleet") }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 5,
		columnNumber: 70
	}, this);
}
_s2(FleetPage, "zlIdU9EjM2llFt74AbE2KsUJXyM=", false, function() {
	return [useTranslation];
});
_c2 = FleetPage;
export function BookingsPage() {
	_s3();
	const { t } = useTranslation();
	return /* @__PURE__ */ _jsxDEV(PagePlaceholder, { title: t("page.bookings") }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 6,
		columnNumber: 73
	}, this);
}
_s3(BookingsPage, "zlIdU9EjM2llFt74AbE2KsUJXyM=", false, function() {
	return [useTranslation];
});
_c3 = BookingsPage;
export function ApprovalsPage() {
	_s4();
	const { t } = useTranslation();
	return /* @__PURE__ */ _jsxDEV(PagePlaceholder, { title: t("page.approvals") }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 7,
		columnNumber: 74
	}, this);
}
_s4(ApprovalsPage, "zlIdU9EjM2llFt74AbE2KsUJXyM=", false, function() {
	return [useTranslation];
});
_c4 = ApprovalsPage;
export function HandoverPage() {
	_s5();
	const { t } = useTranslation();
	return /* @__PURE__ */ _jsxDEV(PagePlaceholder, { title: t("page.handover") }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 8,
		columnNumber: 73
	}, this);
}
_s5(HandoverPage, "zlIdU9EjM2llFt74AbE2KsUJXyM=", false, function() {
	return [useTranslation];
});
_c5 = HandoverPage;
export function TimelinePage() {
	_s6();
	const { t } = useTranslation();
	return /* @__PURE__ */ _jsxDEV(PagePlaceholder, { title: t("page.timeline") }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 9,
		columnNumber: 73
	}, this);
}
_s6(TimelinePage, "zlIdU9EjM2llFt74AbE2KsUJXyM=", false, function() {
	return [useTranslation];
});
_c6 = TimelinePage;
export function DriversPage() {
	_s7();
	const { t } = useTranslation();
	return /* @__PURE__ */ _jsxDEV(PagePlaceholder, { title: t("page.drivers") }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 10,
		columnNumber: 72
	}, this);
}
_s7(DriversPage, "zlIdU9EjM2llFt74AbE2KsUJXyM=", false, function() {
	return [useTranslation];
});
_c7 = DriversPage;
export function MechanicsPage() {
	_s8();
	const { t } = useTranslation();
	return /* @__PURE__ */ _jsxDEV(PagePlaceholder, { title: t("page.mechanics") }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 11,
		columnNumber: 74
	}, this);
}
_s8(MechanicsPage, "zlIdU9EjM2llFt74AbE2KsUJXyM=", false, function() {
	return [useTranslation];
});
_c8 = MechanicsPage;
export function MyTripsPage() {
	_s9();
	const { t } = useTranslation();
	return /* @__PURE__ */ _jsxDEV(PagePlaceholder, { title: t("page.myTrips") }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 72
	}, this);
}
_s9(MyTripsPage, "zlIdU9EjM2llFt74AbE2KsUJXyM=", false, function() {
	return [useTranslation];
});
_c9 = MyTripsPage;
export function IncidentsPage() {
	_s10();
	const { t } = useTranslation();
	return /* @__PURE__ */ _jsxDEV(PagePlaceholder, { title: t("page.incidents") }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 74
	}, this);
}
_s10(IncidentsPage, "zlIdU9EjM2llFt74AbE2KsUJXyM=", false, function() {
	return [useTranslation];
});
_c10 = IncidentsPage;
export function StaffPage() {
	_s11();
	const { t } = useTranslation();
	return /* @__PURE__ */ _jsxDEV(PagePlaceholder, { title: t("page.staff") }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 70
	}, this);
}
_s11(StaffPage, "zlIdU9EjM2llFt74AbE2KsUJXyM=", false, function() {
	return [useTranslation];
});
_c11 = StaffPage;
export function AuditPage() {
	_s12();
	const { t } = useTranslation();
	return /* @__PURE__ */ _jsxDEV(PagePlaceholder, { title: t("page.audit") }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 70
	}, this);
}
_s12(AuditPage, "zlIdU9EjM2llFt74AbE2KsUJXyM=", false, function() {
	return [useTranslation];
});
_c12 = AuditPage;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12;
$RefreshReg$(_c, "DashboardPage");
$RefreshReg$(_c2, "FleetPage");
$RefreshReg$(_c3, "BookingsPage");
$RefreshReg$(_c4, "ApprovalsPage");
$RefreshReg$(_c5, "HandoverPage");
$RefreshReg$(_c6, "TimelinePage");
$RefreshReg$(_c7, "DriversPage");
$RefreshReg$(_c8, "MechanicsPage");
$RefreshReg$(_c9, "MyTripsPage");
$RefreshReg$(_c10, "IncidentsPage");
$RefreshReg$(_c11, "StaffPage");
$RefreshReg$(_c12, "AuditPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/admin.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/CarHire/Frontend/src/pages/admin.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/CarHire/Frontend/src/pages/admin.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/CarHire/Frontend/src/pages/admin.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyx1QkFBdUI7Ozs7QUFFaEMsT0FBTyxTQUFTLGdCQUFnQjs7Q0FBRSxNQUFNLEVBQUUsTUFBTSxlQUFlO0NBQUcsT0FBTyx3QkFBQyxpQkFBRCxFQUFpQixPQUFPLEVBQUUsZ0JBQWdCLEVBQUk7Ozs7O0FBQUU7Ozs7O0FBQ3pILE9BQU8sU0FBUyxZQUFZOztDQUFFLE1BQU0sRUFBRSxNQUFNLGVBQWU7Q0FBRyxPQUFPLHdCQUFDLGlCQUFELEVBQWlCLE9BQU8sRUFBRSxZQUFZLEVBQUk7Ozs7O0FBQUU7Ozs7O0FBQ2pILE9BQU8sU0FBUyxlQUFlOztDQUFFLE1BQU0sRUFBRSxNQUFNLGVBQWU7Q0FBRyxPQUFPLHdCQUFDLGlCQUFELEVBQWlCLE9BQU8sRUFBRSxlQUFlLEVBQUk7Ozs7O0FBQUU7Ozs7O0FBQ3ZILE9BQU8sU0FBUyxnQkFBZ0I7O0NBQUUsTUFBTSxFQUFFLE1BQU0sZUFBZTtDQUFHLE9BQU8sd0JBQUMsaUJBQUQsRUFBaUIsT0FBTyxFQUFFLGdCQUFnQixFQUFJOzs7OztBQUFFOzs7OztBQUN6SCxPQUFPLFNBQVMsZUFBZTs7Q0FBRSxNQUFNLEVBQUUsTUFBTSxlQUFlO0NBQUcsT0FBTyx3QkFBQyxpQkFBRCxFQUFpQixPQUFPLEVBQUUsZUFBZSxFQUFJOzs7OztBQUFFOzs7OztBQUN2SCxPQUFPLFNBQVMsZUFBZTs7Q0FBRSxNQUFNLEVBQUUsTUFBTSxlQUFlO0NBQUcsT0FBTyx3QkFBQyxpQkFBRCxFQUFpQixPQUFPLEVBQUUsZUFBZSxFQUFJOzs7OztBQUFFOzs7OztBQUN2SCxPQUFPLFNBQVMsY0FBYzs7Q0FBRSxNQUFNLEVBQUUsTUFBTSxlQUFlO0NBQUcsT0FBTyx3QkFBQyxpQkFBRCxFQUFpQixPQUFPLEVBQUUsY0FBYyxFQUFJOzs7OztBQUFFOzs7OztBQUNySCxPQUFPLFNBQVMsZ0JBQWdCOztDQUFFLE1BQU0sRUFBRSxNQUFNLGVBQWU7Q0FBRyxPQUFPLHdCQUFDLGlCQUFELEVBQWlCLE9BQU8sRUFBRSxnQkFBZ0IsRUFBSTs7Ozs7QUFBRTs7Ozs7QUFDekgsT0FBTyxTQUFTLGNBQWM7O0NBQUUsTUFBTSxFQUFFLE1BQU0sZUFBZTtDQUFHLE9BQU8sd0JBQUMsaUJBQUQsRUFBaUIsT0FBTyxFQUFFLGNBQWMsRUFBSTs7Ozs7QUFBRTs7Ozs7QUFDckgsT0FBTyxTQUFTLGdCQUFnQjs7Q0FBRSxNQUFNLEVBQUUsTUFBTSxlQUFlO0NBQUcsT0FBTyx3QkFBQyxpQkFBRCxFQUFpQixPQUFPLEVBQUUsZ0JBQWdCLEVBQUk7Ozs7O0FBQUU7Ozs7O0FBQ3pILE9BQU8sU0FBUyxZQUFZOztDQUFFLE1BQU0sRUFBRSxNQUFNLGVBQWU7Q0FBRyxPQUFPLHdCQUFDLGlCQUFELEVBQWlCLE9BQU8sRUFBRSxZQUFZLEVBQUk7Ozs7O0FBQUU7Ozs7O0FBQ2pILE9BQU8sU0FBUyxZQUFZOztDQUFFLE1BQU0sRUFBRSxNQUFNLGVBQWU7Q0FBRyxPQUFPLHdCQUFDLGlCQUFELEVBQWlCLE9BQU8sRUFBRSxZQUFZLEVBQUk7Ozs7O0FBQUUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiYWRtaW4udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVRyYW5zbGF0aW9uIH0gZnJvbSAnLi4vaTE4bidcclxuaW1wb3J0IHsgUGFnZVBsYWNlaG9sZGVyIH0gZnJvbSAnLi9QYWdlUGxhY2Vob2xkZXInXHJcblxyXG5leHBvcnQgZnVuY3Rpb24gRGFzaGJvYXJkUGFnZSgpIHsgY29uc3QgeyB0IH0gPSB1c2VUcmFuc2xhdGlvbigpOyByZXR1cm4gPFBhZ2VQbGFjZWhvbGRlciB0aXRsZT17dCgncGFnZS5kYXNoYm9hcmQnKX0gLz4gfVxyXG5leHBvcnQgZnVuY3Rpb24gRmxlZXRQYWdlKCkgeyBjb25zdCB7IHQgfSA9IHVzZVRyYW5zbGF0aW9uKCk7IHJldHVybiA8UGFnZVBsYWNlaG9sZGVyIHRpdGxlPXt0KCdwYWdlLmZsZWV0Jyl9IC8+IH1cclxuZXhwb3J0IGZ1bmN0aW9uIEJvb2tpbmdzUGFnZSgpIHsgY29uc3QgeyB0IH0gPSB1c2VUcmFuc2xhdGlvbigpOyByZXR1cm4gPFBhZ2VQbGFjZWhvbGRlciB0aXRsZT17dCgncGFnZS5ib29raW5ncycpfSAvPiB9XHJcbmV4cG9ydCBmdW5jdGlvbiBBcHByb3ZhbHNQYWdlKCkgeyBjb25zdCB7IHQgfSA9IHVzZVRyYW5zbGF0aW9uKCk7IHJldHVybiA8UGFnZVBsYWNlaG9sZGVyIHRpdGxlPXt0KCdwYWdlLmFwcHJvdmFscycpfSAvPiB9XHJcbmV4cG9ydCBmdW5jdGlvbiBIYW5kb3ZlclBhZ2UoKSB7IGNvbnN0IHsgdCB9ID0gdXNlVHJhbnNsYXRpb24oKTsgcmV0dXJuIDxQYWdlUGxhY2Vob2xkZXIgdGl0bGU9e3QoJ3BhZ2UuaGFuZG92ZXInKX0gLz4gfVxyXG5leHBvcnQgZnVuY3Rpb24gVGltZWxpbmVQYWdlKCkgeyBjb25zdCB7IHQgfSA9IHVzZVRyYW5zbGF0aW9uKCk7IHJldHVybiA8UGFnZVBsYWNlaG9sZGVyIHRpdGxlPXt0KCdwYWdlLnRpbWVsaW5lJyl9IC8+IH1cclxuZXhwb3J0IGZ1bmN0aW9uIERyaXZlcnNQYWdlKCkgeyBjb25zdCB7IHQgfSA9IHVzZVRyYW5zbGF0aW9uKCk7IHJldHVybiA8UGFnZVBsYWNlaG9sZGVyIHRpdGxlPXt0KCdwYWdlLmRyaXZlcnMnKX0gLz4gfVxyXG5leHBvcnQgZnVuY3Rpb24gTWVjaGFuaWNzUGFnZSgpIHsgY29uc3QgeyB0IH0gPSB1c2VUcmFuc2xhdGlvbigpOyByZXR1cm4gPFBhZ2VQbGFjZWhvbGRlciB0aXRsZT17dCgncGFnZS5tZWNoYW5pY3MnKX0gLz4gfVxyXG5leHBvcnQgZnVuY3Rpb24gTXlUcmlwc1BhZ2UoKSB7IGNvbnN0IHsgdCB9ID0gdXNlVHJhbnNsYXRpb24oKTsgcmV0dXJuIDxQYWdlUGxhY2Vob2xkZXIgdGl0bGU9e3QoJ3BhZ2UubXlUcmlwcycpfSAvPiB9XHJcbmV4cG9ydCBmdW5jdGlvbiBJbmNpZGVudHNQYWdlKCkgeyBjb25zdCB7IHQgfSA9IHVzZVRyYW5zbGF0aW9uKCk7IHJldHVybiA8UGFnZVBsYWNlaG9sZGVyIHRpdGxlPXt0KCdwYWdlLmluY2lkZW50cycpfSAvPiB9XHJcbmV4cG9ydCBmdW5jdGlvbiBTdGFmZlBhZ2UoKSB7IGNvbnN0IHsgdCB9ID0gdXNlVHJhbnNsYXRpb24oKTsgcmV0dXJuIDxQYWdlUGxhY2Vob2xkZXIgdGl0bGU9e3QoJ3BhZ2Uuc3RhZmYnKX0gLz4gfVxyXG5leHBvcnQgZnVuY3Rpb24gQXVkaXRQYWdlKCkgeyBjb25zdCB7IHQgfSA9IHVzZVRyYW5zbGF0aW9uKCk7IHJldHVybiA8UGFnZVBsYWNlaG9sZGVyIHRpdGxlPXt0KCdwYWdlLmF1ZGl0Jyl9IC8+IH0iXX0=
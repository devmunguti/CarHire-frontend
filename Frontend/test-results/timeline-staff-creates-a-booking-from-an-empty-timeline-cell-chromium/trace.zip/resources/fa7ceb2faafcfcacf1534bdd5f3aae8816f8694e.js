import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/bookings/PaymentStatus.tsx");const useCallback = __vite__cjsImport0_react["useCallback"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=8b23c0c4";
import { useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=8b23c0c4";
import { AlertTriangle, CheckCircle2, Clock3, RotateCw, Smartphone, XCircle } from "/node_modules/.vite/deps/lucide-react.js?v=8b23c0c4";
import { ApiError, apiClient } from "/src/api/client.ts";
import { Button, PhoneInput } from "/src/components/ui/index.ts";
import { isKenyanPhone, maskKenyanPhone, normalisePhone } from "/src/lib/index.ts";
var _jsxFileName = "C:/CarHire/Frontend/src/features/bookings/PaymentStatus.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b23c0c4";
var _s = $RefreshSig$();
export function PaymentStatus({ bookingId, amountDueKes, initialPhone = "", onConfirmed }) {
	_s();
	const queryClient = useQueryClient();
	const [phone, setPhone] = useState(initialPhone);
	const [paymentId, setPaymentId] = useState(null);
	const [maskedPhone, setMaskedPhone] = useState("");
	const [paymentState, setPaymentState] = useState("idle");
	const [secondsRemaining, setSecondsRemaining] = useState(120);
	const [paidAmountKes, setPaidAmountKes] = useState();
	const [error, setError] = useState(null);
	const [manualMessage, setManualMessage] = useState(null);
	const deadline = useRef(0);
	const pollInFlight = useRef(false);
	const applyStatus = useCallback(async (id) => {
		if (pollInFlight.current) return;
		pollInFlight.current = true;
		try {
			const result = await apiClient.get(`/payments/${encodeURIComponent(id)}/status`);
			setPaidAmountKes(result.paidAmountKes);
			if (result.outcome === "confirmed") {
				setPaymentState("confirmed");
				setManualMessage(null);
				await queryClient.invalidateQueries({ queryKey: ["booking", bookingId] });
				await queryClient.invalidateQueries({ queryKey: ["bookings"] });
				onConfirmed?.();
			} else if (result.outcome === "failed") {
				setPaymentState("failed");
				setError(result.message ?? "The payment was not completed.");
			} else if (result.outcome === "manual_refund") {
				setPaymentState("manual_refund");
				setError(result.message ?? "This late payment was flagged for manual refund.");
			} else if (paymentState === "timeout") {
				setManualMessage("The payment is still processing. Check again shortly.");
			}
		} catch (requestError) {
			setError(requestError instanceof ApiError ? requestError.message : "Payment status is temporarily unavailable.");
		} finally {
			pollInFlight.current = false;
		}
	}, [
		bookingId,
		onConfirmed,
		paymentState,
		queryClient
	]);
	useEffect(() => {
		if (paymentState !== "waiting" || !paymentId) return;
		const timer = window.setInterval(() => {
			const remaining = Math.max(0, Math.ceil((deadline.current - Date.now()) / 1e3));
			setSecondsRemaining(remaining);
			if (remaining === 0) {
				setPaymentState("timeout");
				return;
			}
			if (remaining % 3 === 0) void applyStatus(paymentId);
		}, 1e3);
		return () => window.clearInterval(timer);
	}, [
		applyStatus,
		paymentId,
		paymentState
	]);
	async function initiatePayment() {
		setError(null);
		setManualMessage(null);
		if (!isKenyanPhone(phone)) {
			setError("Enter a valid Kenyan mobile number, such as 0712 345 678 or 0112 345 678.");
			return;
		}
		try {
			const result = await apiClient.post(`/bookings/${encodeURIComponent(bookingId)}/payments/stk`, {
				phone: normalisePhone(phone),
				amountKes: amountDueKes
			});
			setPaymentId(result.paymentId);
			setMaskedPhone(result.maskedPhone || maskKenyanPhone(phone));
			deadline.current = Date.now() + 12e4;
			setSecondsRemaining(120);
			setPaidAmountKes(undefined);
			setPaymentState("waiting");
		} catch (requestError) {
			setError(requestError instanceof ApiError ? requestError.message : "Could not start the payment request.");
		}
	}
	async function checkManually() {
		if (!paymentId) return;
		setManualMessage(null);
		await applyStatus(paymentId);
	}
	function retryPayment() {
		setPaymentId(null);
		setPaymentState("idle");
		setSecondsRemaining(120);
		setPaidAmountKes(undefined);
		setError(null);
		setManualMessage(null);
	}
	const amountMismatch = paymentState === "confirmed" && paidAmountKes !== undefined && paidAmountKes !== amountDueKes;
	return /* @__PURE__ */ _jsxDEV("section", {
		"aria-live": "polite",
		className: "payment-status",
		"data-state": paymentState,
		children: [
			paymentState === "idle" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "payment-status__heading",
					children: [/* @__PURE__ */ _jsxDEV(Smartphone, {
						"aria-hidden": "true",
						size: 20
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 119,
						columnNumber: 50
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", { children: "Pay by M-Pesa" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 119,
						columnNumber: 98
					}, this), /* @__PURE__ */ _jsxDEV("p", { children: ["Amount due: KES ", new Intl.NumberFormat("en-KE").format(amountDueKes)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 119,
						columnNumber: 120
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 119,
						columnNumber: 93
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 119,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(PhoneInput, {
					error: error ?? undefined,
					label: "M-Pesa phone number",
					onChange: setPhone,
					value: phone
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 120,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Button, {
					disabled: !isKenyanPhone(phone),
					onClick: () => void initiatePayment(),
					children: [/* @__PURE__ */ _jsxDEV(Smartphone, {
						"aria-hidden": "true",
						size: 17
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 121,
						columnNumber: 89
					}, this), " Send payment request"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 121,
					columnNumber: 9
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 118,
				columnNumber: 35
			}, this),
			paymentState === "waiting" && /* @__PURE__ */ _jsxDEV("div", {
				className: "payment-status__state",
				children: [
					/* @__PURE__ */ _jsxDEV(Clock3, {
						"aria-hidden": "true",
						size: 24
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 124,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("h3", { children: "Check your phone" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 125,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: [
						"Approve the M-Pesa request sent to ",
						/* @__PURE__ */ _jsxDEV("strong", { children: maskedPhone }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 126,
							columnNumber: 47
						}, this),
						"."
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "payment-status__countdown",
						children: [
							"Checking for payment: ",
							Math.floor(secondsRemaining / 60),
							":",
							String(secondsRemaining % 60).padStart(2, "0")
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 123,
				columnNumber: 38
			}, this),
			paymentState === "confirmed" && /* @__PURE__ */ _jsxDEV("div", {
				className: "payment-status__state",
				children: [
					/* @__PURE__ */ _jsxDEV(CheckCircle2, {
						"aria-hidden": "true",
						size: 24
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 130,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("h3", { children: "Payment confirmed" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 131,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: [
						"API-confirmed payment for ",
						maskedPhone,
						"."
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 132,
						columnNumber: 9
					}, this),
					amountMismatch && /* @__PURE__ */ _jsxDEV("p", {
						className: "payment-status__warning",
						role: "alert",
						children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, {
							"aria-hidden": "true",
							size: 17
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 133,
							columnNumber: 80
						}, this), " Paid amount differs from the amount due. Review before handover."]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 133,
						columnNumber: 28
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 129,
				columnNumber: 40
			}, this),
			paymentState === "failed" && /* @__PURE__ */ _jsxDEV("div", {
				className: "payment-status__state",
				children: [
					/* @__PURE__ */ _jsxDEV(XCircle, {
						"aria-hidden": "true",
						size: 24
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("h3", { children: "Payment failed" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 49
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: error }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 72
					}, this),
					/* @__PURE__ */ _jsxDEV(Button, {
						onClick: retryPayment,
						variant: "secondary",
						children: [/* @__PURE__ */ _jsxDEV(RotateCw, {
							"aria-hidden": "true",
							size: 17
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 137,
							columnNumber: 60
						}, this), " Retry payment"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 137,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 135,
				columnNumber: 37
			}, this),
			paymentState === "timeout" && /* @__PURE__ */ _jsxDEV("div", {
				className: "payment-status__state",
				children: [
					/* @__PURE__ */ _jsxDEV(Clock3, {
						"aria-hidden": "true",
						size: 24
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 140,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("h3", { children: "Payment status timed out" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 140,
						columnNumber: 48
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: "We did not receive a final status. You can check again without starting another payment." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 140,
						columnNumber: 81
					}, this),
					manualMessage && /* @__PURE__ */ _jsxDEV("p", {
						role: "status",
						children: manualMessage
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 141,
						columnNumber: 27
					}, this),
					error && /* @__PURE__ */ _jsxDEV("p", {
						className: "field__error",
						role: "alert",
						children: error
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 142,
						columnNumber: 19
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "payment-status__actions",
						children: [/* @__PURE__ */ _jsxDEV(Button, {
							onClick: () => void checkManually(),
							variant: "secondary",
							children: "Check status"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 143,
							columnNumber: 50
						}, this), /* @__PURE__ */ _jsxDEV(Button, {
							onClick: retryPayment,
							variant: "ghost",
							children: [/* @__PURE__ */ _jsxDEV(RotateCw, {
								"aria-hidden": "true",
								size: 17
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 143,
								columnNumber: 183
							}, this), " Retry payment"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 143,
							columnNumber: 136
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 143,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 139,
				columnNumber: 38
			}, this),
			paymentState === "manual_refund" && /* @__PURE__ */ _jsxDEV("div", {
				className: "payment-status__state",
				children: [
					/* @__PURE__ */ _jsxDEV(AlertTriangle, {
						"aria-hidden": "true",
						size: 24
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 146,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("h3", { children: "Payment flagged for manual refund" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 146,
						columnNumber: 55
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: [error, " Contact an owner before handing over the vehicle."] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 146,
						columnNumber: 97
					}, this),
					/* @__PURE__ */ _jsxDEV(Button, {
						onClick: retryPayment,
						variant: "secondary",
						children: [/* @__PURE__ */ _jsxDEV(RotateCw, {
							"aria-hidden": "true",
							size: 17
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 147,
							columnNumber: 60
						}, this), " Try another payment"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 147,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 145,
				columnNumber: 44
			}, this),
			paymentState === "idle" && error && /* @__PURE__ */ _jsxDEV("p", {
				className: "field__error",
				role: "alert",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 149,
				columnNumber: 44
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 117,
		columnNumber: 5
	}, this);
}
_s(PaymentStatus, "lpqjQyf23OzChRcIBEvBgHA0sxc=", false, function() {
	return [useQueryClient];
});
_c = PaymentStatus;
var _c;
$RefreshReg$(_c, "PaymentStatus");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/bookings/PaymentStatus.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/CarHire/Frontend/src/features/bookings/PaymentStatus.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/CarHire/Frontend/src/features/bookings/PaymentStatus.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/CarHire/Frontend/src/features/bookings/PaymentStatus.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhLFdBQVcsUUFBUSxnQkFBZ0I7QUFDekQsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxlQUFlLGNBQWMsUUFBUSxVQUFVLFlBQVksZUFBZTtBQUNuRixTQUFTLFVBQVUsaUJBQWlCO0FBRXBDLFNBQVMsUUFBUSxrQkFBa0I7QUFDbkMsU0FBUyxlQUFlLGlCQUFpQixzQkFBc0I7Ozs7QUFJL0QsT0FBTyxTQUFTLGNBQWMsRUFDNUIsV0FDQSxjQUNBLGVBQWUsSUFDZixlQU1DOztDQUNELE1BQU0sY0FBYyxlQUFlO0NBQ25DLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxZQUFZO0NBQy9DLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUF3QixJQUFJO0NBQzlELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEVBQUU7Q0FDakQsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQXVCLE1BQU07Q0FDckUsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBUyxHQUFHO0NBQzVELE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUE2QjtDQUN2RSxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQXdCLElBQUk7Q0FDdEQsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQXdCLElBQUk7Q0FDdEUsTUFBTSxXQUFXLE9BQU8sQ0FBQztDQUN6QixNQUFNLGVBQWUsT0FBTyxLQUFLO0NBRWpDLE1BQU0sY0FBYyxZQUFZLE9BQU8sT0FBZTtFQUNwRCxJQUFJLGFBQWEsU0FBUztFQUMxQixhQUFhLFVBQVU7RUFDdkIsSUFBSTtHQUNGLE1BQU0sU0FBUyxNQUFNLFVBQVUsSUFBZSxhQUFhLG1CQUFtQixFQUFFLEVBQUUsUUFBUTtHQUMxRixpQkFBaUIsT0FBTyxhQUFhO0dBQ3JDLElBQUksT0FBTyxZQUFZLGFBQWE7SUFDbEMsZ0JBQWdCLFdBQVc7SUFDM0IsaUJBQWlCLElBQUk7SUFDckIsTUFBTSxZQUFZLGtCQUFrQixFQUFFLFVBQVUsQ0FBQyxXQUFXLFNBQVMsRUFBRSxDQUFDO0lBQ3hFLE1BQU0sWUFBWSxrQkFBa0IsRUFBRSxVQUFVLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDOUQsY0FBYztHQUNoQixPQUFPLElBQUksT0FBTyxZQUFZLFVBQVU7SUFDdEMsZ0JBQWdCLFFBQVE7SUFDeEIsU0FBUyxPQUFPLFdBQVcsZ0NBQWdDO0dBQzdELE9BQU8sSUFBSSxPQUFPLFlBQVksaUJBQWlCO0lBQzdDLGdCQUFnQixlQUFlO0lBQy9CLFNBQVMsT0FBTyxXQUFXLGtEQUFrRDtHQUMvRSxPQUFPLElBQUksaUJBQWlCLFdBQVc7SUFDckMsaUJBQWlCLHVEQUF1RDtHQUMxRTtFQUNGLFNBQVMsY0FBYztHQUNyQixTQUFTLHdCQUF3QixXQUFXLGFBQWEsVUFBVSw0Q0FBNEM7RUFDakgsVUFBVTtHQUNSLGFBQWEsVUFBVTtFQUN6QjtDQUNGLEdBQUc7RUFBQztFQUFXO0VBQWE7RUFBYztDQUFXLENBQUM7Q0FFdEQsZ0JBQWdCO0VBQ2QsSUFBSSxpQkFBaUIsYUFBYSxDQUFDLFdBQVc7RUFDOUMsTUFBTSxRQUFRLE9BQU8sa0JBQWtCO0dBQ3JDLE1BQU0sWUFBWSxLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sU0FBUyxVQUFVLEtBQUssSUFBSSxLQUFLLEdBQUksQ0FBQztHQUMvRSxvQkFBb0IsU0FBUztHQUM3QixJQUFJLGNBQWMsR0FBRztJQUNuQixnQkFBZ0IsU0FBUztJQUN6QjtHQUNGO0dBQ0EsSUFBSSxZQUFZLE1BQU0sR0FBRyxLQUFLLFlBQVksU0FBUztFQUNyRCxHQUFHLEdBQUk7RUFDUCxhQUFhLE9BQU8sY0FBYyxLQUFLO0NBQ3pDLEdBQUc7RUFBQztFQUFhO0VBQVc7Q0FBWSxDQUFDO0NBRXpDLGVBQWUsa0JBQWtCO0VBQy9CLFNBQVMsSUFBSTtFQUNiLGlCQUFpQixJQUFJO0VBQ3JCLElBQUksQ0FBQyxjQUFjLEtBQUssR0FBRztHQUN6QixTQUFTLDJFQUEyRTtHQUNwRjtFQUNGO0VBQ0EsSUFBSTtHQUNGLE1BQU0sU0FBUyxNQUFNLFVBQVUsS0FBb0IsYUFBYSxtQkFBbUIsU0FBUyxFQUFFLGdCQUFnQjtJQUM1RyxPQUFPLGVBQWUsS0FBSztJQUMzQixXQUFXO0dBQ2IsQ0FBQztHQUNELGFBQWEsT0FBTyxTQUFTO0dBQzdCLGVBQWUsT0FBTyxlQUFlLGdCQUFnQixLQUFLLENBQUM7R0FDM0QsU0FBUyxVQUFVLEtBQUssSUFBSSxJQUFJO0dBQ2hDLG9CQUFvQixHQUFHO0dBQ3ZCLGlCQUFpQixTQUFTO0dBQzFCLGdCQUFnQixTQUFTO0VBQzNCLFNBQVMsY0FBYztHQUNyQixTQUFTLHdCQUF3QixXQUFXLGFBQWEsVUFBVSxzQ0FBc0M7RUFDM0c7Q0FDRjtDQUVBLGVBQWUsZ0JBQWdCO0VBQzdCLElBQUksQ0FBQyxXQUFXO0VBQ2hCLGlCQUFpQixJQUFJO0VBQ3JCLE1BQU0sWUFBWSxTQUFTO0NBQzdCO0NBRUEsU0FBUyxlQUFlO0VBQ3RCLGFBQWEsSUFBSTtFQUNqQixnQkFBZ0IsTUFBTTtFQUN0QixvQkFBb0IsR0FBRztFQUN2QixpQkFBaUIsU0FBUztFQUMxQixTQUFTLElBQUk7RUFDYixpQkFBaUIsSUFBSTtDQUN2QjtDQUVBLE1BQU0saUJBQWlCLGlCQUFpQixlQUFlLGtCQUFrQixhQUFhLGtCQUFrQjtDQUV4RyxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxhQUFVO0VBQVMsV0FBVTtFQUFpQixjQUFZO1lBQW5FO0dBQ0csaUJBQWlCLFVBQVU7SUFDMUIsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUF5Qyx3QkFBQyxZQUFEO01BQVksZUFBWTtNQUFPLE1BQU07S0FBSzs7OztlQUFDLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxNQUFELFlBQUksZ0JBQWlCOzs7O2VBQUMsd0JBQUMsS0FBRCxhQUFHLG9CQUFpQixJQUFJLEtBQUssYUFBYSxPQUFPLENBQUMsQ0FBQyxPQUFPLFlBQVksQ0FBSzs7OzthQUFNOzs7O2FBQU07Ozs7OztJQUN0TSx3QkFBQyxZQUFEO0tBQVksT0FBTyxTQUFTO0tBQVcsT0FBTTtLQUFzQixVQUFVO0tBQVUsT0FBTztJQUFROzs7OztJQUN0Ryx3QkFBQyxRQUFEO0tBQVEsVUFBVSxDQUFDLGNBQWMsS0FBSztLQUFHLGVBQWUsS0FBSyxnQkFBZ0I7ZUFBN0UsQ0FBZ0Ysd0JBQUMsWUFBRDtNQUFZLGVBQVk7TUFBTyxNQUFNO0tBQUs7Ozs7ZUFBQyx1QkFBNkI7Ozs7OztHQUN4Sjs7Ozs7R0FDRCxpQkFBaUIsYUFBYSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQzdCLHdCQUFDLFFBQUQ7TUFBUSxlQUFZO01BQU8sTUFBTTtLQUFLOzs7OztLQUN0Qyx3QkFBQyxNQUFELFlBQUksbUJBQW9COzs7OztLQUN4Qix3QkFBQyxLQUFEO01BQUc7TUFBbUMsd0JBQUMsVUFBRCxZQUFTLFlBQW9COzs7OztNQUFDO0tBQUk7Ozs7O0tBQ3hFLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFiO09BQXlDO09BQXVCLEtBQUssTUFBTSxtQkFBbUIsRUFBRTtPQUFFO09BQUUsT0FBTyxtQkFBbUIsRUFBRSxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUc7TUFBSzs7Ozs7O0lBQ25KOzs7Ozs7R0FDSixpQkFBaUIsZUFBZSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQy9CLHdCQUFDLGNBQUQ7TUFBYyxlQUFZO01BQU8sTUFBTTtLQUFLOzs7OztLQUM1Qyx3QkFBQyxNQUFELFlBQUksb0JBQXFCOzs7OztLQUN6Qix3QkFBQyxLQUFEO01BQUc7TUFBMkI7TUFBWTtLQUFJOzs7OztLQUM3QyxrQkFBa0Isd0JBQUMsS0FBRDtNQUFHLFdBQVU7TUFBMEIsTUFBSztnQkFBNUMsQ0FBb0Qsd0JBQUMsZUFBRDtPQUFlLGVBQVk7T0FBTyxNQUFNO01BQUs7Ozs7Z0JBQUMsbUVBQW9FOzs7Ozs7SUFDdEw7Ozs7OztHQUNKLGlCQUFpQixZQUFZLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDNUIsd0JBQUMsU0FBRDtNQUFTLGVBQVk7TUFBTyxNQUFNO0tBQUs7Ozs7O0tBQUMsd0JBQUMsTUFBRCxZQUFJLGlCQUFrQjs7Ozs7S0FBQyx3QkFBQyxLQUFELFlBQUksTUFBUzs7Ozs7S0FDNUUsd0JBQUMsUUFBRDtNQUFRLFNBQVM7TUFBYyxTQUFRO2dCQUF2QyxDQUFtRCx3QkFBQyxVQUFEO09BQVUsZUFBWTtPQUFPLE1BQU07TUFBSzs7OztnQkFBQyxnQkFBc0I7Ozs7OztJQUMvRzs7Ozs7O0dBQ0osaUJBQWlCLGFBQWEsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUM3Qix3QkFBQyxRQUFEO01BQVEsZUFBWTtNQUFPLE1BQU07S0FBSzs7Ozs7S0FBQyx3QkFBQyxNQUFELFlBQUksMkJBQTRCOzs7OztLQUFDLHdCQUFDLEtBQUQsWUFBRywyRkFBMkY7Ozs7O0tBQ3JLLGlCQUFpQix3QkFBQyxLQUFEO01BQUcsTUFBSztnQkFBVTtLQUFpQjs7Ozs7S0FDcEQsU0FBUyx3QkFBQyxLQUFEO01BQUcsV0FBVTtNQUFlLE1BQUs7Z0JBQVM7S0FBUzs7Ozs7S0FDN0Qsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FBeUMsd0JBQUMsUUFBRDtPQUFRLGVBQWUsS0FBSyxjQUFjO09BQUcsU0FBUTtpQkFBWTtNQUFvQjs7OztnQkFBQyx3QkFBQyxRQUFEO09BQVEsU0FBUztPQUFjLFNBQVE7aUJBQXZDLENBQStDLHdCQUFDLFVBQUQ7UUFBVSxlQUFZO1FBQU8sTUFBTTtPQUFLOzs7O2lCQUFDLGdCQUFzQjs7Ozs7Y0FBTTs7Ozs7O0lBQ2hQOzs7Ozs7R0FDSixpQkFBaUIsbUJBQW1CLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDbkMsd0JBQUMsZUFBRDtNQUFlLGVBQVk7TUFBTyxNQUFNO0tBQUs7Ozs7O0tBQUMsd0JBQUMsTUFBRCxZQUFJLG9DQUFxQzs7Ozs7S0FBQyx3QkFBQyxLQUFELGFBQUksT0FBTSxvREFBcUQ7Ozs7O0tBQ3ZKLHdCQUFDLFFBQUQ7TUFBUSxTQUFTO01BQWMsU0FBUTtnQkFBdkMsQ0FBbUQsd0JBQUMsVUFBRDtPQUFVLGVBQVk7T0FBTyxNQUFNO01BQUs7Ozs7Z0JBQUMsc0JBQTRCOzs7Ozs7SUFDckg7Ozs7OztHQUNKLGlCQUFpQixVQUFVLFNBQVMsd0JBQUMsS0FBRDtJQUFHLFdBQVU7SUFBZSxNQUFLO2NBQVM7R0FBUzs7Ozs7RUFDakY7Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlBheW1lbnRTdGF0dXMudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXHJcbmltcG9ydCB7IEFsZXJ0VHJpYW5nbGUsIENoZWNrQ2lyY2xlMiwgQ2xvY2szLCBSb3RhdGVDdywgU21hcnRwaG9uZSwgWENpcmNsZSB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcclxuaW1wb3J0IHsgQXBpRXJyb3IsIGFwaUNsaWVudCB9IGZyb20gJy4uLy4uL2FwaS9jbGllbnQnXHJcbmltcG9ydCB0eXBlIHsgU3RrSW5pdGlhdGlvbiwgU3RrU3RhdHVzIH0gZnJvbSAnLi4vLi4vYXBpL3R5cGVzJ1xyXG5pbXBvcnQgeyBCdXR0b24sIFBob25lSW5wdXQgfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL3VpJ1xyXG5pbXBvcnQgeyBpc0tlbnlhblBob25lLCBtYXNrS2VueWFuUGhvbmUsIG5vcm1hbGlzZVBob25lIH0gZnJvbSAnLi4vLi4vbGliJ1xyXG5cclxudHlwZSBQYXltZW50U3RhdGUgPSAnaWRsZScgfCAnd2FpdGluZycgfCAnY29uZmlybWVkJyB8ICdmYWlsZWQnIHwgJ3RpbWVvdXQnIHwgJ21hbnVhbF9yZWZ1bmQnXHJcblxyXG5leHBvcnQgZnVuY3Rpb24gUGF5bWVudFN0YXR1cyh7XHJcbiAgYm9va2luZ0lkLFxyXG4gIGFtb3VudER1ZUtlcyxcclxuICBpbml0aWFsUGhvbmUgPSAnJyxcclxuICBvbkNvbmZpcm1lZCxcclxufToge1xyXG4gIGJvb2tpbmdJZDogc3RyaW5nXHJcbiAgYW1vdW50RHVlS2VzOiBudW1iZXJcclxuICBpbml0aWFsUGhvbmU/OiBzdHJpbmdcclxuICBvbkNvbmZpcm1lZD86ICgpID0+IHZvaWRcclxufSkge1xyXG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKVxyXG4gIGNvbnN0IFtwaG9uZSwgc2V0UGhvbmVdID0gdXNlU3RhdGUoaW5pdGlhbFBob25lKVxyXG4gIGNvbnN0IFtwYXltZW50SWQsIHNldFBheW1lbnRJZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKVxyXG4gIGNvbnN0IFttYXNrZWRQaG9uZSwgc2V0TWFza2VkUGhvbmVdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW3BheW1lbnRTdGF0ZSwgc2V0UGF5bWVudFN0YXRlXSA9IHVzZVN0YXRlPFBheW1lbnRTdGF0ZT4oJ2lkbGUnKVxyXG4gIGNvbnN0IFtzZWNvbmRzUmVtYWluaW5nLCBzZXRTZWNvbmRzUmVtYWluaW5nXSA9IHVzZVN0YXRlKDEyMClcclxuICBjb25zdCBbcGFpZEFtb3VudEtlcywgc2V0UGFpZEFtb3VudEtlc10gPSB1c2VTdGF0ZTxudW1iZXIgfCB1bmRlZmluZWQ+KClcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpXHJcbiAgY29uc3QgW21hbnVhbE1lc3NhZ2UsIHNldE1hbnVhbE1lc3NhZ2VdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbClcclxuICBjb25zdCBkZWFkbGluZSA9IHVzZVJlZigwKVxyXG4gIGNvbnN0IHBvbGxJbkZsaWdodCA9IHVzZVJlZihmYWxzZSlcclxuXHJcbiAgY29uc3QgYXBwbHlTdGF0dXMgPSB1c2VDYWxsYmFjayhhc3luYyAoaWQ6IHN0cmluZykgPT4ge1xyXG4gICAgaWYgKHBvbGxJbkZsaWdodC5jdXJyZW50KSByZXR1cm5cclxuICAgIHBvbGxJbkZsaWdodC5jdXJyZW50ID0gdHJ1ZVxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgYXBpQ2xpZW50LmdldDxTdGtTdGF0dXM+KGAvcGF5bWVudHMvJHtlbmNvZGVVUklDb21wb25lbnQoaWQpfS9zdGF0dXNgKVxyXG4gICAgICBzZXRQYWlkQW1vdW50S2VzKHJlc3VsdC5wYWlkQW1vdW50S2VzKVxyXG4gICAgICBpZiAocmVzdWx0Lm91dGNvbWUgPT09ICdjb25maXJtZWQnKSB7XHJcbiAgICAgICAgc2V0UGF5bWVudFN0YXRlKCdjb25maXJtZWQnKVxyXG4gICAgICAgIHNldE1hbnVhbE1lc3NhZ2UobnVsbClcclxuICAgICAgICBhd2FpdCBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbJ2Jvb2tpbmcnLCBib29raW5nSWRdIH0pXHJcbiAgICAgICAgYXdhaXQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogWydib29raW5ncyddIH0pXHJcbiAgICAgICAgb25Db25maXJtZWQ/LigpXHJcbiAgICAgIH0gZWxzZSBpZiAocmVzdWx0Lm91dGNvbWUgPT09ICdmYWlsZWQnKSB7XHJcbiAgICAgICAgc2V0UGF5bWVudFN0YXRlKCdmYWlsZWQnKVxyXG4gICAgICAgIHNldEVycm9yKHJlc3VsdC5tZXNzYWdlID8/ICdUaGUgcGF5bWVudCB3YXMgbm90IGNvbXBsZXRlZC4nKVxyXG4gICAgICB9IGVsc2UgaWYgKHJlc3VsdC5vdXRjb21lID09PSAnbWFudWFsX3JlZnVuZCcpIHtcclxuICAgICAgICBzZXRQYXltZW50U3RhdGUoJ21hbnVhbF9yZWZ1bmQnKVxyXG4gICAgICAgIHNldEVycm9yKHJlc3VsdC5tZXNzYWdlID8/ICdUaGlzIGxhdGUgcGF5bWVudCB3YXMgZmxhZ2dlZCBmb3IgbWFudWFsIHJlZnVuZC4nKVxyXG4gICAgICB9IGVsc2UgaWYgKHBheW1lbnRTdGF0ZSA9PT0gJ3RpbWVvdXQnKSB7XHJcbiAgICAgICAgc2V0TWFudWFsTWVzc2FnZSgnVGhlIHBheW1lbnQgaXMgc3RpbGwgcHJvY2Vzc2luZy4gQ2hlY2sgYWdhaW4gc2hvcnRseS4nKVxyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChyZXF1ZXN0RXJyb3IpIHtcclxuICAgICAgc2V0RXJyb3IocmVxdWVzdEVycm9yIGluc3RhbmNlb2YgQXBpRXJyb3IgPyByZXF1ZXN0RXJyb3IubWVzc2FnZSA6ICdQYXltZW50IHN0YXR1cyBpcyB0ZW1wb3JhcmlseSB1bmF2YWlsYWJsZS4nKVxyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgcG9sbEluRmxpZ2h0LmN1cnJlbnQgPSBmYWxzZVxyXG4gICAgfVxyXG4gIH0sIFtib29raW5nSWQsIG9uQ29uZmlybWVkLCBwYXltZW50U3RhdGUsIHF1ZXJ5Q2xpZW50XSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChwYXltZW50U3RhdGUgIT09ICd3YWl0aW5nJyB8fCAhcGF5bWVudElkKSByZXR1cm5cclxuICAgIGNvbnN0IHRpbWVyID0gd2luZG93LnNldEludGVydmFsKCgpID0+IHtcclxuICAgICAgY29uc3QgcmVtYWluaW5nID0gTWF0aC5tYXgoMCwgTWF0aC5jZWlsKChkZWFkbGluZS5jdXJyZW50IC0gRGF0ZS5ub3coKSkgLyAxMDAwKSlcclxuICAgICAgc2V0U2Vjb25kc1JlbWFpbmluZyhyZW1haW5pbmcpXHJcbiAgICAgIGlmIChyZW1haW5pbmcgPT09IDApIHtcclxuICAgICAgICBzZXRQYXltZW50U3RhdGUoJ3RpbWVvdXQnKVxyXG4gICAgICAgIHJldHVyblxyXG4gICAgICB9XHJcbiAgICAgIGlmIChyZW1haW5pbmcgJSAzID09PSAwKSB2b2lkIGFwcGx5U3RhdHVzKHBheW1lbnRJZClcclxuICAgIH0sIDEwMDApXHJcbiAgICByZXR1cm4gKCkgPT4gd2luZG93LmNsZWFySW50ZXJ2YWwodGltZXIpXHJcbiAgfSwgW2FwcGx5U3RhdHVzLCBwYXltZW50SWQsIHBheW1lbnRTdGF0ZV0pXHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGluaXRpYXRlUGF5bWVudCgpIHtcclxuICAgIHNldEVycm9yKG51bGwpXHJcbiAgICBzZXRNYW51YWxNZXNzYWdlKG51bGwpXHJcbiAgICBpZiAoIWlzS2VueWFuUGhvbmUocGhvbmUpKSB7XHJcbiAgICAgIHNldEVycm9yKCdFbnRlciBhIHZhbGlkIEtlbnlhbiBtb2JpbGUgbnVtYmVyLCBzdWNoIGFzIDA3MTIgMzQ1IDY3OCBvciAwMTEyIDM0NSA2NzguJylcclxuICAgICAgcmV0dXJuXHJcbiAgICB9XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBhcGlDbGllbnQucG9zdDxTdGtJbml0aWF0aW9uPihgL2Jvb2tpbmdzLyR7ZW5jb2RlVVJJQ29tcG9uZW50KGJvb2tpbmdJZCl9L3BheW1lbnRzL3N0a2AsIHtcclxuICAgICAgICBwaG9uZTogbm9ybWFsaXNlUGhvbmUocGhvbmUpLFxyXG4gICAgICAgIGFtb3VudEtlczogYW1vdW50RHVlS2VzLFxyXG4gICAgICB9KVxyXG4gICAgICBzZXRQYXltZW50SWQocmVzdWx0LnBheW1lbnRJZClcclxuICAgICAgc2V0TWFza2VkUGhvbmUocmVzdWx0Lm1hc2tlZFBob25lIHx8IG1hc2tLZW55YW5QaG9uZShwaG9uZSkpXHJcbiAgICAgIGRlYWRsaW5lLmN1cnJlbnQgPSBEYXRlLm5vdygpICsgMTIwXzAwMFxyXG4gICAgICBzZXRTZWNvbmRzUmVtYWluaW5nKDEyMClcclxuICAgICAgc2V0UGFpZEFtb3VudEtlcyh1bmRlZmluZWQpXHJcbiAgICAgIHNldFBheW1lbnRTdGF0ZSgnd2FpdGluZycpXHJcbiAgICB9IGNhdGNoIChyZXF1ZXN0RXJyb3IpIHtcclxuICAgICAgc2V0RXJyb3IocmVxdWVzdEVycm9yIGluc3RhbmNlb2YgQXBpRXJyb3IgPyByZXF1ZXN0RXJyb3IubWVzc2FnZSA6ICdDb3VsZCBub3Qgc3RhcnQgdGhlIHBheW1lbnQgcmVxdWVzdC4nKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gY2hlY2tNYW51YWxseSgpIHtcclxuICAgIGlmICghcGF5bWVudElkKSByZXR1cm5cclxuICAgIHNldE1hbnVhbE1lc3NhZ2UobnVsbClcclxuICAgIGF3YWl0IGFwcGx5U3RhdHVzKHBheW1lbnRJZClcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIHJldHJ5UGF5bWVudCgpIHtcclxuICAgIHNldFBheW1lbnRJZChudWxsKVxyXG4gICAgc2V0UGF5bWVudFN0YXRlKCdpZGxlJylcclxuICAgIHNldFNlY29uZHNSZW1haW5pbmcoMTIwKVxyXG4gICAgc2V0UGFpZEFtb3VudEtlcyh1bmRlZmluZWQpXHJcbiAgICBzZXRFcnJvcihudWxsKVxyXG4gICAgc2V0TWFudWFsTWVzc2FnZShudWxsKVxyXG4gIH1cclxuXHJcbiAgY29uc3QgYW1vdW50TWlzbWF0Y2ggPSBwYXltZW50U3RhdGUgPT09ICdjb25maXJtZWQnICYmIHBhaWRBbW91bnRLZXMgIT09IHVuZGVmaW5lZCAmJiBwYWlkQW1vdW50S2VzICE9PSBhbW91bnREdWVLZXNcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uIGFyaWEtbGl2ZT1cInBvbGl0ZVwiIGNsYXNzTmFtZT1cInBheW1lbnQtc3RhdHVzXCIgZGF0YS1zdGF0ZT17cGF5bWVudFN0YXRlfT5cclxuICAgICAge3BheW1lbnRTdGF0ZSA9PT0gJ2lkbGUnICYmIDw+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYXltZW50LXN0YXR1c19faGVhZGluZ1wiPjxTbWFydHBob25lIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHNpemU9ezIwfSAvPjxkaXY+PGgzPlBheSBieSBNLVBlc2E8L2gzPjxwPkFtb3VudCBkdWU6IEtFUyB7bmV3IEludGwuTnVtYmVyRm9ybWF0KCdlbi1LRScpLmZvcm1hdChhbW91bnREdWVLZXMpfTwvcD48L2Rpdj48L2Rpdj5cclxuICAgICAgICA8UGhvbmVJbnB1dCBlcnJvcj17ZXJyb3IgPz8gdW5kZWZpbmVkfSBsYWJlbD1cIk0tUGVzYSBwaG9uZSBudW1iZXJcIiBvbkNoYW5nZT17c2V0UGhvbmV9IHZhbHVlPXtwaG9uZX0gLz5cclxuICAgICAgICA8QnV0dG9uIGRpc2FibGVkPXshaXNLZW55YW5QaG9uZShwaG9uZSl9IG9uQ2xpY2s9eygpID0+IHZvaWQgaW5pdGlhdGVQYXltZW50KCl9PjxTbWFydHBob25lIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHNpemU9ezE3fSAvPiBTZW5kIHBheW1lbnQgcmVxdWVzdDwvQnV0dG9uPlxyXG4gICAgICA8Lz59XHJcbiAgICAgIHtwYXltZW50U3RhdGUgPT09ICd3YWl0aW5nJyAmJiA8ZGl2IGNsYXNzTmFtZT1cInBheW1lbnQtc3RhdHVzX19zdGF0ZVwiPlxyXG4gICAgICAgIDxDbG9jazMgYXJpYS1oaWRkZW49XCJ0cnVlXCIgc2l6ZT17MjR9IC8+XHJcbiAgICAgICAgPGgzPkNoZWNrIHlvdXIgcGhvbmU8L2gzPlxyXG4gICAgICAgIDxwPkFwcHJvdmUgdGhlIE0tUGVzYSByZXF1ZXN0IHNlbnQgdG8gPHN0cm9uZz57bWFza2VkUGhvbmV9PC9zdHJvbmc+LjwvcD5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJwYXltZW50LXN0YXR1c19fY291bnRkb3duXCI+Q2hlY2tpbmcgZm9yIHBheW1lbnQ6IHtNYXRoLmZsb29yKHNlY29uZHNSZW1haW5pbmcgLyA2MCl9OntTdHJpbmcoc2Vjb25kc1JlbWFpbmluZyAlIDYwKS5wYWRTdGFydCgyLCAnMCcpfTwvcD5cclxuICAgICAgPC9kaXY+fVxyXG4gICAgICB7cGF5bWVudFN0YXRlID09PSAnY29uZmlybWVkJyAmJiA8ZGl2IGNsYXNzTmFtZT1cInBheW1lbnQtc3RhdHVzX19zdGF0ZVwiPlxyXG4gICAgICAgIDxDaGVja0NpcmNsZTIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgc2l6ZT17MjR9IC8+XHJcbiAgICAgICAgPGgzPlBheW1lbnQgY29uZmlybWVkPC9oMz5cclxuICAgICAgICA8cD5BUEktY29uZmlybWVkIHBheW1lbnQgZm9yIHttYXNrZWRQaG9uZX0uPC9wPlxyXG4gICAgICAgIHthbW91bnRNaXNtYXRjaCAmJiA8cCBjbGFzc05hbWU9XCJwYXltZW50LXN0YXR1c19fd2FybmluZ1wiIHJvbGU9XCJhbGVydFwiPjxBbGVydFRyaWFuZ2xlIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHNpemU9ezE3fSAvPiBQYWlkIGFtb3VudCBkaWZmZXJzIGZyb20gdGhlIGFtb3VudCBkdWUuIFJldmlldyBiZWZvcmUgaGFuZG92ZXIuPC9wPn1cclxuICAgICAgPC9kaXY+fVxyXG4gICAgICB7cGF5bWVudFN0YXRlID09PSAnZmFpbGVkJyAmJiA8ZGl2IGNsYXNzTmFtZT1cInBheW1lbnQtc3RhdHVzX19zdGF0ZVwiPlxyXG4gICAgICAgIDxYQ2lyY2xlIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHNpemU9ezI0fSAvPjxoMz5QYXltZW50IGZhaWxlZDwvaDM+PHA+e2Vycm9yfTwvcD5cclxuICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9e3JldHJ5UGF5bWVudH0gdmFyaWFudD1cInNlY29uZGFyeVwiPjxSb3RhdGVDdyBhcmlhLWhpZGRlbj1cInRydWVcIiBzaXplPXsxN30gLz4gUmV0cnkgcGF5bWVudDwvQnV0dG9uPlxyXG4gICAgICA8L2Rpdj59XHJcbiAgICAgIHtwYXltZW50U3RhdGUgPT09ICd0aW1lb3V0JyAmJiA8ZGl2IGNsYXNzTmFtZT1cInBheW1lbnQtc3RhdHVzX19zdGF0ZVwiPlxyXG4gICAgICAgIDxDbG9jazMgYXJpYS1oaWRkZW49XCJ0cnVlXCIgc2l6ZT17MjR9IC8+PGgzPlBheW1lbnQgc3RhdHVzIHRpbWVkIG91dDwvaDM+PHA+V2UgZGlkIG5vdCByZWNlaXZlIGEgZmluYWwgc3RhdHVzLiBZb3UgY2FuIGNoZWNrIGFnYWluIHdpdGhvdXQgc3RhcnRpbmcgYW5vdGhlciBwYXltZW50LjwvcD5cclxuICAgICAgICB7bWFudWFsTWVzc2FnZSAmJiA8cCByb2xlPVwic3RhdHVzXCI+e21hbnVhbE1lc3NhZ2V9PC9wPn1cclxuICAgICAgICB7ZXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwiZmllbGRfX2Vycm9yXCIgcm9sZT1cImFsZXJ0XCI+e2Vycm9yfTwvcD59XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYXltZW50LXN0YXR1c19fYWN0aW9uc1wiPjxCdXR0b24gb25DbGljaz17KCkgPT4gdm9pZCBjaGVja01hbnVhbGx5KCl9IHZhcmlhbnQ9XCJzZWNvbmRhcnlcIj5DaGVjayBzdGF0dXM8L0J1dHRvbj48QnV0dG9uIG9uQ2xpY2s9e3JldHJ5UGF5bWVudH0gdmFyaWFudD1cImdob3N0XCI+PFJvdGF0ZUN3IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHNpemU9ezE3fSAvPiBSZXRyeSBwYXltZW50PC9CdXR0b24+PC9kaXY+XHJcbiAgICAgIDwvZGl2Pn1cclxuICAgICAge3BheW1lbnRTdGF0ZSA9PT0gJ21hbnVhbF9yZWZ1bmQnICYmIDxkaXYgY2xhc3NOYW1lPVwicGF5bWVudC1zdGF0dXNfX3N0YXRlXCI+XHJcbiAgICAgICAgPEFsZXJ0VHJpYW5nbGUgYXJpYS1oaWRkZW49XCJ0cnVlXCIgc2l6ZT17MjR9IC8+PGgzPlBheW1lbnQgZmxhZ2dlZCBmb3IgbWFudWFsIHJlZnVuZDwvaDM+PHA+e2Vycm9yfSBDb250YWN0IGFuIG93bmVyIGJlZm9yZSBoYW5kaW5nIG92ZXIgdGhlIHZlaGljbGUuPC9wPlxyXG4gICAgICAgIDxCdXR0b24gb25DbGljaz17cmV0cnlQYXltZW50fSB2YXJpYW50PVwic2Vjb25kYXJ5XCI+PFJvdGF0ZUN3IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHNpemU9ezE3fSAvPiBUcnkgYW5vdGhlciBwYXltZW50PC9CdXR0b24+XHJcbiAgICAgIDwvZGl2Pn1cclxuICAgICAge3BheW1lbnRTdGF0ZSA9PT0gJ2lkbGUnICYmIGVycm9yICYmIDxwIGNsYXNzTmFtZT1cImZpZWxkX19lcnJvclwiIHJvbGU9XCJhbGVydFwiPntlcnJvcn08L3A+fVxyXG4gICAgPC9zZWN0aW9uPlxyXG4gIClcclxufSJdfQ==
import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/bookings/QuoteBuilder.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useMemo = __vite__cjsImport0_react["useMemo"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport5_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=8b23c0c4";
import { useCalculateQuote } from "/src/api/queries.ts";
import { Button, Checkbox, DateTimeRangePicker, Input, Select, Tabs } from "/src/components/ui/index.ts";
import { formatKes } from "/src/lib/index.ts";
import { t } from "/src/i18n/index.ts";
var _jsxFileName = "C:/CarHire/Frontend/src/features/bookings/QuoteBuilder.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b23c0c4";
var _s = $RefreshSig$();
const extraOptions = [
	{
		code: "baby_seat",
		label: "booking.babySeat"
	},
	{
		code: "rooftop_tent",
		label: "booking.rooftopTent"
	},
	{
		code: "cooler_box",
		label: "booking.coolerBox"
	},
	{
		code: "airport_pickup",
		label: "booking.airportPickup"
	}
];
const extrasLabels = Object.fromEntries(extraOptions.map(({ code, label }) => [code, label]));
export function QuoteBuilder({ request, onChange, showDates = true, showPickupLocation = true, showModeAndExtras = true, onReserve, onQuoteChange, reserveDisabled = false, conflictMessage }) {
	_s();
	const { isPending, mutateAsync } = useCalculateQuote();
	const [quoted, setQuoted] = useState(null);
	const [errorRequestKey, setErrorRequestKey] = useState(null);
	const latestRequestKey = useRef("");
	const requestKey = JSON.stringify(request);
	const requestPayload = useMemo(() => JSON.parse(requestKey), [requestKey]);
	const canQuote = Boolean(request.vehicleId && request.pickupAt && request.returnAt && request.pickupLocation.trim());
	const currentQuote = quoted?.requestKey === requestKey ? quoted.quote : undefined;
	const error = errorRequestKey === requestKey;
	useEffect(() => {
		onQuoteChange?.(currentQuote ?? null);
	}, [currentQuote, onQuoteChange]);
	useEffect(() => {
		if (!canQuote) return;
		const timerId = window.setTimeout(() => {
			latestRequestKey.current = requestKey;
			mutateAsync(requestPayload).then((quote) => {
				if (latestRequestKey.current === requestKey) {
					setQuoted({
						requestKey,
						quote
					});
					setErrorRequestKey(null);
				}
			}).catch(() => {
				if (latestRequestKey.current === requestKey) setErrorRequestKey(requestKey);
			});
		}, 300);
		return () => window.clearTimeout(timerId);
	}, [
		canQuote,
		requestKey,
		requestPayload,
		mutateAsync
	]);
	function update(patch) {
		onChange({
			...request,
			...patch
		});
	}
	function toggleExtra(code, checked) {
		update({ extras: checked ? [...request.extras, code] : request.extras.filter((item) => item !== code) });
	}
	return /* @__PURE__ */ _jsxDEV("section", {
		"aria-labelledby": "quote-builder-title",
		className: "quote-builder",
		children: [
			/* @__PURE__ */ _jsxDEV("h2", {
				id: "quote-builder-title",
				children: t("booking.quoteBreakdown")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 7
			}, this),
			showDates && /* @__PURE__ */ _jsxDEV(DateTimeRangePicker, {
				endUtc: request.returnAt,
				label: t("booking.dateRange"),
				onChange: (range) => update({
					pickupAt: range.startUtc,
					returnAt: range.endUtc
				}),
				startUtc: request.pickupAt
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 81,
				columnNumber: 21
			}, this),
			showPickupLocation && /* @__PURE__ */ _jsxDEV(Input, {
				label: t("booking.pickupLocation"),
				onChange: (event) => update({ pickupLocation: event.target.value }),
				placeholder: t("booking.pickupPlaceholder"),
				value: request.pickupLocation
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 82,
				columnNumber: 30
			}, this),
			showModeAndExtras && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				/* @__PURE__ */ _jsxDEV(Tabs, {
					label: t("booking.driveMode"),
					onChange: (value) => update({ mode: value }),
					options: [{
						value: "self_drive",
						label: t("booking.selfDrive")
					}, {
						value: "chauffeur",
						label: t("booking.chauffeur")
					}],
					value: request.mode
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 84,
					columnNumber: 9
				}, this),
				request.mode === "chauffeur" && /* @__PURE__ */ _jsxDEV(Select, {
					label: "Driver fee area",
					onChange: (event) => update({ driverLocation: event.target.value }),
					options: [{
						value: "in_town",
						label: "In-town"
					}, {
						value: "upcountry",
						label: "Upcountry"
					}],
					value: request.driverLocation ?? "in_town"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 90,
					columnNumber: 42
				}, this),
				/* @__PURE__ */ _jsxDEV("fieldset", {
					className: "quote-extras",
					children: [/* @__PURE__ */ _jsxDEV("legend", { children: t("booking.extras") }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 97,
						columnNumber: 11
					}, this), extraOptions.map(({ code, label }) => /* @__PURE__ */ _jsxDEV(Checkbox, {
						checked: request.extras.includes(code),
						label: t(label),
						onChange: (checked) => toggleExtra(code, checked)
					}, code, false, {
						fileName: _jsxFileName,
						lineNumber: 98,
						columnNumber: 50
					}, this))]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 96,
					columnNumber: 9
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 83,
				columnNumber: 29
			}, this),
			isPending && canQuote && /* @__PURE__ */ _jsxDEV("p", {
				"aria-live": "polite",
				className: "quote-calculating",
				children: t("booking.calculating")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 102,
				columnNumber: 33
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				className: "field__error",
				role: "alert",
				children: t("booking.quoteError")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 103,
				columnNumber: 17
			}, this),
			conflictMessage && /* @__PURE__ */ _jsxDEV("p", {
				className: "quote-conflict",
				role: "alert",
				children: conflictMessage
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 104,
				columnNumber: 27
			}, this),
			currentQuote && /* @__PURE__ */ _jsxDEV(QuoteBreakdown, { quote: currentQuote }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 105,
				columnNumber: 24
			}, this),
			onReserve && /* @__PURE__ */ _jsxDEV(Button, {
				disabled: reserveDisabled || !currentQuote,
				onClick: () => currentQuote && onReserve(request, currentQuote),
				children: t("booking.reserve")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 106,
				columnNumber: 21
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 79,
		columnNumber: 5
	}, this);
}
_s(QuoteBuilder, "mL9LwBMe6FQ0bcHsHVoL5RCpMcI=", false, function() {
	return [useCalculateQuote];
});
_c = QuoteBuilder;
export function QuoteBreakdown({ quote }) {
	const snapshot = quote.pricingSnapshot;
	const chauffeurFeeLabel = snapshot.driverLocation === "upcountry" ? "Upcountry driver fee" : "In-town driver fee";
	return /* @__PURE__ */ _jsxDEV("dl", {
		className: "quote-breakdown",
		children: [
			/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: t("booking.baseDays").replace("{days}", String(snapshot.baseDays)) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 116,
				columnNumber: 12
			}, this), /* @__PURE__ */ _jsxDEV("dd", { children: formatKes(snapshot.baseAmountKes) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 116,
				columnNumber: 89
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 116,
				columnNumber: 7
			}, this),
			snapshot.chauffeurFeeKes > 0 && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: chauffeurFeeLabel }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 117,
				columnNumber: 45
			}, this), /* @__PURE__ */ _jsxDEV("dd", { children: formatKes(snapshot.chauffeurFeeKes) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 117,
				columnNumber: 73
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 117,
				columnNumber: 40
			}, this),
			snapshot.extras.map((extra) => /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: t(extrasLabels[extra.code] ?? extra.label) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 118,
				columnNumber: 61
			}, this), /* @__PURE__ */ _jsxDEV("dd", { children: formatKes(extra.amountKes) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 118,
				columnNumber: 114
			}, this)] }, extra.code, true, {
				fileName: _jsxFileName,
				lineNumber: 118,
				columnNumber: 39
			}, this)),
			/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: t("booking.vat").replace("{rate}", String(snapshot.vatRate)) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 119,
				columnNumber: 12
			}, this), /* @__PURE__ */ _jsxDEV("dd", { children: formatKes(snapshot.vatAmountKes) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 119,
				columnNumber: 83
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 119,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "quote-breakdown__total",
				children: [/* @__PURE__ */ _jsxDEV("dt", { children: t("booking.totalDue") }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 120,
					columnNumber: 47
				}, this), /* @__PURE__ */ _jsxDEV("dd", { children: formatKes(snapshot.totalDueKes) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 120,
					columnNumber: 79
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 120,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "quote-breakdown__deposit",
				children: [/* @__PURE__ */ _jsxDEV("dt", { children: [
					t("booking.refundableDeposit"),
					" ",
					/* @__PURE__ */ _jsxDEV("span", { children: t("booking.depositUntaxed") }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 121,
						columnNumber: 86
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 121,
					columnNumber: 49
				}, this), /* @__PURE__ */ _jsxDEV("dd", { children: formatKes(snapshot.refundableDepositKes) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 121,
					columnNumber: 133
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 121,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 115,
		columnNumber: 5
	}, this);
}
_c2 = QuoteBreakdown;
var _c, _c2;
$RefreshReg$(_c, "QuoteBuilder");
$RefreshReg$(_c2, "QuoteBreakdown");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/bookings/QuoteBuilder.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/CarHire/Frontend/src/features/bookings/QuoteBuilder.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/CarHire/Frontend/src/features/bookings/QuoteBuilder.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/CarHire/Frontend/src/features/bookings/QuoteBuilder.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFNBQVMsUUFBUSxnQkFBZ0I7QUFFckQsU0FBUyx5QkFBeUI7QUFDbEMsU0FBUyxRQUFRLFVBQVUscUJBQXFCLE9BQU8sUUFBUSxZQUFZO0FBQzNFLFNBQVMsaUJBQWlCO0FBQzFCLFNBQVMsU0FBUzs7OztBQUVsQixNQUFNLGVBQWU7Q0FDbkI7RUFBRSxNQUFNO0VBQWEsT0FBTztDQUFtQjtDQUMvQztFQUFFLE1BQU07RUFBZ0IsT0FBTztDQUFzQjtDQUNyRDtFQUFFLE1BQU07RUFBYyxPQUFPO0NBQW9CO0NBQ2pEO0VBQUUsTUFBTTtFQUFrQixPQUFPO0NBQXdCO0FBQzNEO0FBRUEsTUFBTSxlQUF1QyxPQUFPLFlBQVksYUFBYSxLQUFLLEVBQUUsTUFBTSxZQUFZLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FBQztBQWNwSCxPQUFPLFNBQVMsYUFBYSxFQUMzQixTQUNBLFVBQ0EsWUFBWSxNQUNaLHFCQUFxQixNQUNyQixvQkFBb0IsTUFDcEIsV0FDQSxlQUNBLGtCQUFrQixPQUNsQixtQkFDb0I7O0NBQ3BCLE1BQU0sRUFBRSxXQUFXLGdCQUFnQixrQkFBa0I7Q0FDckQsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUE4RCxJQUFJO0NBQzlGLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQXdCLElBQUk7Q0FDMUUsTUFBTSxtQkFBbUIsT0FBTyxFQUFFO0NBQ2xDLE1BQU0sYUFBYSxLQUFLLFVBQVUsT0FBTztDQUN6QyxNQUFNLGlCQUFpQixjQUFjLEtBQUssTUFBTSxVQUFVLEdBQW1CLENBQUMsVUFBVSxDQUFDO0NBQ3pGLE1BQU0sV0FBVyxRQUFRLFFBQVEsYUFBYSxRQUFRLFlBQVksUUFBUSxZQUFZLFFBQVEsZUFBZSxLQUFLLENBQUM7Q0FDbkgsTUFBTSxlQUFlLFFBQVEsZUFBZSxhQUFhLE9BQU8sUUFBUTtDQUN4RSxNQUFNLFFBQVEsb0JBQW9CO0NBRWxDLGdCQUFnQjtFQUNkLGdCQUFnQixnQkFBZ0IsSUFBSTtDQUN0QyxHQUFHLENBQUMsY0FBYyxhQUFhLENBQUM7Q0FFaEMsZ0JBQWdCO0VBQ2QsSUFBSSxDQUFDLFVBQVU7RUFDZixNQUFNLFVBQVUsT0FBTyxpQkFBaUI7R0FDdEMsaUJBQWlCLFVBQVU7R0FDM0IsWUFBWSxjQUFjLENBQUMsQ0FBQyxNQUFNLFVBQVU7SUFDMUMsSUFBSSxpQkFBaUIsWUFBWSxZQUFZO0tBQzNDLFVBQVU7TUFBRTtNQUFZO0tBQU0sQ0FBQztLQUMvQixtQkFBbUIsSUFBSTtJQUN6QjtHQUNGLENBQUMsQ0FBQyxDQUFDLFlBQVk7SUFDYixJQUFJLGlCQUFpQixZQUFZLFlBQVksbUJBQW1CLFVBQVU7R0FDNUUsQ0FBQztFQUNILEdBQUcsR0FBRztFQUNOLGFBQWEsT0FBTyxhQUFhLE9BQU87Q0FDMUMsR0FBRztFQUFDO0VBQVU7RUFBWTtFQUFnQjtDQUFXLENBQUM7Q0FFdEQsU0FBUyxPQUFPLE9BQThCO0VBQzVDLFNBQVM7R0FBRSxHQUFHO0dBQVMsR0FBRztFQUFNLENBQUM7Q0FDbkM7Q0FFQSxTQUFTLFlBQVksTUFBYyxTQUFrQjtFQUNuRCxPQUFPLEVBQUUsUUFBUSxVQUFVLENBQUMsR0FBRyxRQUFRLFFBQVEsSUFBSSxJQUFJLFFBQVEsT0FBTyxRQUFRLFNBQVMsU0FBUyxJQUFJLEVBQUUsQ0FBQztDQUN6RztDQUVBLE9BQ0Usd0JBQUMsV0FBRDtFQUFTLG1CQUFnQjtFQUFzQixXQUFVO1lBQXpEO0dBQ0Usd0JBQUMsTUFBRDtJQUFJLElBQUc7Y0FBdUIsRUFBRSx3QkFBd0I7R0FBTTs7Ozs7R0FDN0QsYUFBYSx3QkFBQyxxQkFBRDtJQUFxQixRQUFRLFFBQVE7SUFBVSxPQUFPLEVBQUUsbUJBQW1CO0lBQUcsV0FBVyxVQUFVLE9BQU87S0FBRSxVQUFVLE1BQU07S0FBVSxVQUFVLE1BQU07SUFBTyxDQUFDO0lBQUcsVUFBVSxRQUFRO0dBQVc7Ozs7O0dBQzNNLHNCQUFzQix3QkFBQyxPQUFEO0lBQU8sT0FBTyxFQUFFLHdCQUF3QjtJQUFHLFdBQVcsVUFBVSxPQUFPLEVBQUUsZ0JBQWdCLE1BQU0sT0FBTyxNQUFNLENBQUM7SUFBRyxhQUFhLEVBQUUsMkJBQTJCO0lBQUcsT0FBTyxRQUFRO0dBQWlCOzs7OztHQUNuTixxQkFBcUI7SUFDcEIsd0JBQUMsTUFBRDtLQUNFLE9BQU8sRUFBRSxtQkFBbUI7S0FDNUIsV0FBVyxVQUFVLE9BQU8sRUFBRSxNQUFNLE1BQW1CLENBQUM7S0FDeEQsU0FBUyxDQUFDO01BQUUsT0FBTztNQUFjLE9BQU8sRUFBRSxtQkFBbUI7S0FBRSxHQUFHO01BQUUsT0FBTztNQUFhLE9BQU8sRUFBRSxtQkFBbUI7S0FBRSxDQUFDO0tBQ3ZILE9BQU8sUUFBUTtJQUNoQjs7Ozs7SUFDQSxRQUFRLFNBQVMsZUFBZSx3QkFBQyxRQUFEO0tBQy9CLE9BQU07S0FDTixXQUFXLFVBQVUsT0FBTyxFQUFFLGdCQUFnQixNQUFNLE9BQU8sTUFBd0IsQ0FBQztLQUNwRixTQUFTLENBQUM7TUFBRSxPQUFPO01BQVcsT0FBTztLQUFVLEdBQUc7TUFBRSxPQUFPO01BQWEsT0FBTztLQUFZLENBQUM7S0FDNUYsT0FBTyxRQUFRLGtCQUFrQjtJQUNsQzs7Ozs7SUFDRCx3QkFBQyxZQUFEO0tBQVUsV0FBVTtlQUFwQixDQUNFLHdCQUFDLFVBQUQsWUFBUyxFQUFFLGdCQUFnQixFQUFVOzs7O2VBQ3BDLGFBQWEsS0FBSyxFQUFFLE1BQU0sWUFBWSx3QkFBQyxVQUFEO01BQVUsU0FBUyxRQUFRLE9BQU8sU0FBUyxJQUFJO01BQWMsT0FBTyxFQUFFLEtBQUs7TUFBRyxXQUFXLFlBQVksWUFBWSxNQUFNLE9BQU87S0FBSSxHQUEzRTs7OztZQUEyRSxDQUFDLENBQ2xLOzs7Ozs7R0FDVjs7Ozs7R0FFRCxhQUFhLFlBQVksd0JBQUMsS0FBRDtJQUFHLGFBQVU7SUFBUyxXQUFVO2NBQXFCLEVBQUUscUJBQXFCO0dBQUs7Ozs7O0dBQzFHLFNBQVMsd0JBQUMsS0FBRDtJQUFHLFdBQVU7SUFBZSxNQUFLO2NBQVMsRUFBRSxvQkFBb0I7R0FBSzs7Ozs7R0FDOUUsbUJBQW1CLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO0lBQWlCLE1BQUs7Y0FBUztHQUFtQjs7Ozs7R0FDbEYsZ0JBQWdCLHdCQUFDLGdCQUFELEVBQWdCLE9BQU8sYUFBZTs7Ozs7R0FDdEQsYUFBYSx3QkFBQyxRQUFEO0lBQVEsVUFBVSxtQkFBbUIsQ0FBQztJQUFjLGVBQWUsZ0JBQWdCLFVBQVUsU0FBUyxZQUFZO2NBQUksRUFBRSxpQkFBaUI7R0FBVTs7Ozs7RUFDMUo7Ozs7OztBQUViOzs7OztBQUVBLE9BQU8sU0FBUyxlQUFlLEVBQUUsU0FBbUM7Q0FDbEUsTUFBTSxXQUFXLE1BQU07Q0FDdkIsTUFBTSxvQkFBb0IsU0FBUyxtQkFBbUIsY0FBYyx5QkFBeUI7Q0FDN0YsT0FDRSx3QkFBQyxNQUFEO0VBQUksV0FBVTtZQUFkO0dBQ0Usd0JBQUMsT0FBRCxhQUFLLHdCQUFDLE1BQUQsWUFBSyxFQUFFLGtCQUFrQixDQUFDLENBQUMsUUFBUSxVQUFVLE9BQU8sU0FBUyxRQUFRLENBQUMsRUFBTTs7OzthQUFDLHdCQUFDLE1BQUQsWUFBSyxVQUFVLFNBQVMsYUFBYSxFQUFNOzs7O1dBQU07Ozs7O0dBQ2xJLFNBQVMsa0JBQWtCLEtBQUssd0JBQUMsT0FBRCxhQUFLLHdCQUFDLE1BQUQsWUFBSyxrQkFBc0I7Ozs7YUFBQyx3QkFBQyxNQUFELFlBQUssVUFBVSxTQUFTLGVBQWUsRUFBTTs7OztXQUFNOzs7OztHQUNwSCxTQUFTLE9BQU8sS0FBSyxVQUFVLHdCQUFDLE9BQUQsYUFBc0Isd0JBQUMsTUFBRCxZQUFLLEVBQUUsYUFBYSxNQUFNLFNBQVMsTUFBTSxLQUFLLEVBQU07Ozs7YUFBQyx3QkFBQyxNQUFELFlBQUssVUFBVSxNQUFNLFNBQVMsRUFBTTs7OztXQUFNLEtBQTNHLE1BQU07Ozs7VUFBcUcsQ0FBQztHQUN0Six3QkFBQyxPQUFELGFBQUssd0JBQUMsTUFBRCxZQUFLLEVBQUUsYUFBYSxDQUFDLENBQUMsUUFBUSxVQUFVLE9BQU8sU0FBUyxPQUFPLENBQUMsRUFBTTs7OzthQUFDLHdCQUFDLE1BQUQsWUFBSyxVQUFVLFNBQVMsWUFBWSxFQUFNOzs7O1dBQU07Ozs7O0dBQzVILHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FBd0Msd0JBQUMsTUFBRCxZQUFLLEVBQUUsa0JBQWtCLEVBQU07Ozs7Y0FBQyx3QkFBQyxNQUFELFlBQUssVUFBVSxTQUFTLFdBQVcsRUFBTTs7OztZQUFNOzs7Ozs7R0FDdkgsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUEwQyx3QkFBQyxNQUFEO0tBQUssRUFBRSwyQkFBMkI7S0FBRTtLQUFDLHdCQUFDLFFBQUQsWUFBTyxFQUFFLHdCQUF3QixFQUFROzs7OztJQUFLOzs7O2NBQUMsd0JBQUMsTUFBRCxZQUFLLFVBQVUsU0FBUyxvQkFBb0IsRUFBTTs7OztZQUFNOzs7Ozs7RUFDcEw7Ozs7OztBQUVSIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlF1b3RlQnVpbGRlci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB0eXBlIHsgRHJpdmVNb2RlLCBEcml2ZXJMb2NhdGlvbiwgUXVvdGVSZXF1ZXN0LCBRdW90ZVJlc3BvbnNlIH0gZnJvbSAnLi4vLi4vYXBpL3R5cGVzJ1xyXG5pbXBvcnQgeyB1c2VDYWxjdWxhdGVRdW90ZSB9IGZyb20gJy4uLy4uL2FwaS9xdWVyaWVzJ1xyXG5pbXBvcnQgeyBCdXR0b24sIENoZWNrYm94LCBEYXRlVGltZVJhbmdlUGlja2VyLCBJbnB1dCwgU2VsZWN0LCBUYWJzIH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy91aSdcclxuaW1wb3J0IHsgZm9ybWF0S2VzIH0gZnJvbSAnLi4vLi4vbGliJ1xyXG5pbXBvcnQgeyB0IH0gZnJvbSAnLi4vLi4vaTE4bidcclxuXHJcbmNvbnN0IGV4dHJhT3B0aW9ucyA9IFtcclxuICB7IGNvZGU6ICdiYWJ5X3NlYXQnLCBsYWJlbDogJ2Jvb2tpbmcuYmFieVNlYXQnIH0sXHJcbiAgeyBjb2RlOiAncm9vZnRvcF90ZW50JywgbGFiZWw6ICdib29raW5nLnJvb2Z0b3BUZW50JyB9LFxyXG4gIHsgY29kZTogJ2Nvb2xlcl9ib3gnLCBsYWJlbDogJ2Jvb2tpbmcuY29vbGVyQm94JyB9LFxyXG4gIHsgY29kZTogJ2FpcnBvcnRfcGlja3VwJywgbGFiZWw6ICdib29raW5nLmFpcnBvcnRQaWNrdXAnIH0sXHJcbl1cclxuXHJcbmNvbnN0IGV4dHJhc0xhYmVsczogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IE9iamVjdC5mcm9tRW50cmllcyhleHRyYU9wdGlvbnMubWFwKCh7IGNvZGUsIGxhYmVsIH0pID0+IFtjb2RlLCBsYWJlbF0pKVxyXG5cclxudHlwZSBRdW90ZUJ1aWxkZXJQcm9wcyA9IHtcclxuICByZXF1ZXN0OiBRdW90ZVJlcXVlc3RcclxuICBvbkNoYW5nZTogKHJlcXVlc3Q6IFF1b3RlUmVxdWVzdCkgPT4gdm9pZFxyXG4gIHNob3dEYXRlcz86IGJvb2xlYW5cclxuICBzaG93UGlja3VwTG9jYXRpb24/OiBib29sZWFuXHJcbiAgc2hvd01vZGVBbmRFeHRyYXM/OiBib29sZWFuXHJcbiAgb25SZXNlcnZlPzogKHJlcXVlc3Q6IFF1b3RlUmVxdWVzdCwgcXVvdGU6IFF1b3RlUmVzcG9uc2UpID0+IHZvaWRcclxuICBvblF1b3RlQ2hhbmdlPzogKHF1b3RlOiBRdW90ZVJlc3BvbnNlIHwgbnVsbCkgPT4gdm9pZFxyXG4gIHJlc2VydmVEaXNhYmxlZD86IGJvb2xlYW5cclxuICBjb25mbGljdE1lc3NhZ2U/OiBzdHJpbmdcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFF1b3RlQnVpbGRlcih7XHJcbiAgcmVxdWVzdCxcclxuICBvbkNoYW5nZSxcclxuICBzaG93RGF0ZXMgPSB0cnVlLFxyXG4gIHNob3dQaWNrdXBMb2NhdGlvbiA9IHRydWUsXHJcbiAgc2hvd01vZGVBbmRFeHRyYXMgPSB0cnVlLFxyXG4gIG9uUmVzZXJ2ZSxcclxuICBvblF1b3RlQ2hhbmdlLFxyXG4gIHJlc2VydmVEaXNhYmxlZCA9IGZhbHNlLFxyXG4gIGNvbmZsaWN0TWVzc2FnZSxcclxufTogUXVvdGVCdWlsZGVyUHJvcHMpIHtcclxuICBjb25zdCB7IGlzUGVuZGluZywgbXV0YXRlQXN5bmMgfSA9IHVzZUNhbGN1bGF0ZVF1b3RlKClcclxuICBjb25zdCBbcXVvdGVkLCBzZXRRdW90ZWRdID0gdXNlU3RhdGU8eyByZXF1ZXN0S2V5OiBzdHJpbmc7IHF1b3RlOiBRdW90ZVJlc3BvbnNlIH0gfCBudWxsPihudWxsKVxyXG4gIGNvbnN0IFtlcnJvclJlcXVlc3RLZXksIHNldEVycm9yUmVxdWVzdEtleV0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKVxyXG4gIGNvbnN0IGxhdGVzdFJlcXVlc3RLZXkgPSB1c2VSZWYoJycpXHJcbiAgY29uc3QgcmVxdWVzdEtleSA9IEpTT04uc3RyaW5naWZ5KHJlcXVlc3QpXHJcbiAgY29uc3QgcmVxdWVzdFBheWxvYWQgPSB1c2VNZW1vKCgpID0+IEpTT04ucGFyc2UocmVxdWVzdEtleSkgYXMgUXVvdGVSZXF1ZXN0LCBbcmVxdWVzdEtleV0pXHJcbiAgY29uc3QgY2FuUXVvdGUgPSBCb29sZWFuKHJlcXVlc3QudmVoaWNsZUlkICYmIHJlcXVlc3QucGlja3VwQXQgJiYgcmVxdWVzdC5yZXR1cm5BdCAmJiByZXF1ZXN0LnBpY2t1cExvY2F0aW9uLnRyaW0oKSlcclxuICBjb25zdCBjdXJyZW50UXVvdGUgPSBxdW90ZWQ/LnJlcXVlc3RLZXkgPT09IHJlcXVlc3RLZXkgPyBxdW90ZWQucXVvdGUgOiB1bmRlZmluZWRcclxuICBjb25zdCBlcnJvciA9IGVycm9yUmVxdWVzdEtleSA9PT0gcmVxdWVzdEtleVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgb25RdW90ZUNoYW5nZT8uKGN1cnJlbnRRdW90ZSA/PyBudWxsKVxyXG4gIH0sIFtjdXJyZW50UXVvdGUsIG9uUXVvdGVDaGFuZ2VdKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKCFjYW5RdW90ZSkgcmV0dXJuXHJcbiAgICBjb25zdCB0aW1lcklkID0gd2luZG93LnNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICBsYXRlc3RSZXF1ZXN0S2V5LmN1cnJlbnQgPSByZXF1ZXN0S2V5XHJcbiAgICAgIG11dGF0ZUFzeW5jKHJlcXVlc3RQYXlsb2FkKS50aGVuKChxdW90ZSkgPT4ge1xyXG4gICAgICAgIGlmIChsYXRlc3RSZXF1ZXN0S2V5LmN1cnJlbnQgPT09IHJlcXVlc3RLZXkpIHtcclxuICAgICAgICAgIHNldFF1b3RlZCh7IHJlcXVlc3RLZXksIHF1b3RlIH0pXHJcbiAgICAgICAgICBzZXRFcnJvclJlcXVlc3RLZXkobnVsbClcclxuICAgICAgICB9XHJcbiAgICAgIH0pLmNhdGNoKCgpID0+IHtcclxuICAgICAgICBpZiAobGF0ZXN0UmVxdWVzdEtleS5jdXJyZW50ID09PSByZXF1ZXN0S2V5KSBzZXRFcnJvclJlcXVlc3RLZXkocmVxdWVzdEtleSlcclxuICAgICAgfSlcclxuICAgIH0sIDMwMClcclxuICAgIHJldHVybiAoKSA9PiB3aW5kb3cuY2xlYXJUaW1lb3V0KHRpbWVySWQpXHJcbiAgfSwgW2NhblF1b3RlLCByZXF1ZXN0S2V5LCByZXF1ZXN0UGF5bG9hZCwgbXV0YXRlQXN5bmNdKVxyXG5cclxuICBmdW5jdGlvbiB1cGRhdGUocGF0Y2g6IFBhcnRpYWw8UXVvdGVSZXF1ZXN0Pikge1xyXG4gICAgb25DaGFuZ2UoeyAuLi5yZXF1ZXN0LCAuLi5wYXRjaCB9KVxyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gdG9nZ2xlRXh0cmEoY29kZTogc3RyaW5nLCBjaGVja2VkOiBib29sZWFuKSB7XHJcbiAgICB1cGRhdGUoeyBleHRyYXM6IGNoZWNrZWQgPyBbLi4ucmVxdWVzdC5leHRyYXMsIGNvZGVdIDogcmVxdWVzdC5leHRyYXMuZmlsdGVyKChpdGVtKSA9PiBpdGVtICE9PSBjb2RlKSB9KVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uIGFyaWEtbGFiZWxsZWRieT1cInF1b3RlLWJ1aWxkZXItdGl0bGVcIiBjbGFzc05hbWU9XCJxdW90ZS1idWlsZGVyXCI+XHJcbiAgICAgIDxoMiBpZD1cInF1b3RlLWJ1aWxkZXItdGl0bGVcIj57dCgnYm9va2luZy5xdW90ZUJyZWFrZG93bicpfTwvaDI+XHJcbiAgICAgIHtzaG93RGF0ZXMgJiYgPERhdGVUaW1lUmFuZ2VQaWNrZXIgZW5kVXRjPXtyZXF1ZXN0LnJldHVybkF0fSBsYWJlbD17dCgnYm9va2luZy5kYXRlUmFuZ2UnKX0gb25DaGFuZ2U9eyhyYW5nZSkgPT4gdXBkYXRlKHsgcGlja3VwQXQ6IHJhbmdlLnN0YXJ0VXRjLCByZXR1cm5BdDogcmFuZ2UuZW5kVXRjIH0pfSBzdGFydFV0Yz17cmVxdWVzdC5waWNrdXBBdH0gLz59XHJcbiAgICAgIHtzaG93UGlja3VwTG9jYXRpb24gJiYgPElucHV0IGxhYmVsPXt0KCdib29raW5nLnBpY2t1cExvY2F0aW9uJyl9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHVwZGF0ZSh7IHBpY2t1cExvY2F0aW9uOiBldmVudC50YXJnZXQudmFsdWUgfSl9IHBsYWNlaG9sZGVyPXt0KCdib29raW5nLnBpY2t1cFBsYWNlaG9sZGVyJyl9IHZhbHVlPXtyZXF1ZXN0LnBpY2t1cExvY2F0aW9ufSAvPn1cclxuICAgICAge3Nob3dNb2RlQW5kRXh0cmFzICYmIDw+XHJcbiAgICAgICAgPFRhYnNcclxuICAgICAgICAgIGxhYmVsPXt0KCdib29raW5nLmRyaXZlTW9kZScpfVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gdXBkYXRlKHsgbW9kZTogdmFsdWUgYXMgRHJpdmVNb2RlIH0pfVxyXG4gICAgICAgICAgb3B0aW9ucz17W3sgdmFsdWU6ICdzZWxmX2RyaXZlJywgbGFiZWw6IHQoJ2Jvb2tpbmcuc2VsZkRyaXZlJykgfSwgeyB2YWx1ZTogJ2NoYXVmZmV1cicsIGxhYmVsOiB0KCdib29raW5nLmNoYXVmZmV1cicpIH1dfVxyXG4gICAgICAgICAgdmFsdWU9e3JlcXVlc3QubW9kZX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIHtyZXF1ZXN0Lm1vZGUgPT09ICdjaGF1ZmZldXInICYmIDxTZWxlY3RcclxuICAgICAgICAgIGxhYmVsPVwiRHJpdmVyIGZlZSBhcmVhXCJcclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHVwZGF0ZSh7IGRyaXZlckxvY2F0aW9uOiBldmVudC50YXJnZXQudmFsdWUgYXMgRHJpdmVyTG9jYXRpb24gfSl9XHJcbiAgICAgICAgICBvcHRpb25zPXtbeyB2YWx1ZTogJ2luX3Rvd24nLCBsYWJlbDogJ0luLXRvd24nIH0sIHsgdmFsdWU6ICd1cGNvdW50cnknLCBsYWJlbDogJ1VwY291bnRyeScgfV19XHJcbiAgICAgICAgICB2YWx1ZT17cmVxdWVzdC5kcml2ZXJMb2NhdGlvbiA/PyAnaW5fdG93bid9XHJcbiAgICAgICAgLz59XHJcbiAgICAgICAgPGZpZWxkc2V0IGNsYXNzTmFtZT1cInF1b3RlLWV4dHJhc1wiPlxyXG4gICAgICAgICAgPGxlZ2VuZD57dCgnYm9va2luZy5leHRyYXMnKX08L2xlZ2VuZD5cclxuICAgICAgICAgIHtleHRyYU9wdGlvbnMubWFwKCh7IGNvZGUsIGxhYmVsIH0pID0+IDxDaGVja2JveCBjaGVja2VkPXtyZXF1ZXN0LmV4dHJhcy5pbmNsdWRlcyhjb2RlKX0ga2V5PXtjb2RlfSBsYWJlbD17dChsYWJlbCl9IG9uQ2hhbmdlPXsoY2hlY2tlZCkgPT4gdG9nZ2xlRXh0cmEoY29kZSwgY2hlY2tlZCl9IC8+KX1cclxuICAgICAgICA8L2ZpZWxkc2V0PlxyXG4gICAgICA8Lz59XHJcblxyXG4gICAgICB7aXNQZW5kaW5nICYmIGNhblF1b3RlICYmIDxwIGFyaWEtbGl2ZT1cInBvbGl0ZVwiIGNsYXNzTmFtZT1cInF1b3RlLWNhbGN1bGF0aW5nXCI+e3QoJ2Jvb2tpbmcuY2FsY3VsYXRpbmcnKX08L3A+fVxyXG4gICAgICB7ZXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwiZmllbGRfX2Vycm9yXCIgcm9sZT1cImFsZXJ0XCI+e3QoJ2Jvb2tpbmcucXVvdGVFcnJvcicpfTwvcD59XHJcbiAgICAgIHtjb25mbGljdE1lc3NhZ2UgJiYgPHAgY2xhc3NOYW1lPVwicXVvdGUtY29uZmxpY3RcIiByb2xlPVwiYWxlcnRcIj57Y29uZmxpY3RNZXNzYWdlfTwvcD59XHJcbiAgICAgIHtjdXJyZW50UXVvdGUgJiYgPFF1b3RlQnJlYWtkb3duIHF1b3RlPXtjdXJyZW50UXVvdGV9IC8+fVxyXG4gICAgICB7b25SZXNlcnZlICYmIDxCdXR0b24gZGlzYWJsZWQ9e3Jlc2VydmVEaXNhYmxlZCB8fCAhY3VycmVudFF1b3RlfSBvbkNsaWNrPXsoKSA9PiBjdXJyZW50UXVvdGUgJiYgb25SZXNlcnZlKHJlcXVlc3QsIGN1cnJlbnRRdW90ZSl9Pnt0KCdib29raW5nLnJlc2VydmUnKX08L0J1dHRvbj59XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gUXVvdGVCcmVha2Rvd24oeyBxdW90ZSB9OiB7IHF1b3RlOiBRdW90ZVJlc3BvbnNlIH0pIHtcclxuICBjb25zdCBzbmFwc2hvdCA9IHF1b3RlLnByaWNpbmdTbmFwc2hvdFxyXG4gIGNvbnN0IGNoYXVmZmV1ckZlZUxhYmVsID0gc25hcHNob3QuZHJpdmVyTG9jYXRpb24gPT09ICd1cGNvdW50cnknID8gJ1VwY291bnRyeSBkcml2ZXIgZmVlJyA6ICdJbi10b3duIGRyaXZlciBmZWUnXHJcbiAgcmV0dXJuIChcclxuICAgIDxkbCBjbGFzc05hbWU9XCJxdW90ZS1icmVha2Rvd25cIj5cclxuICAgICAgPGRpdj48ZHQ+e3QoJ2Jvb2tpbmcuYmFzZURheXMnKS5yZXBsYWNlKCd7ZGF5c30nLCBTdHJpbmcoc25hcHNob3QuYmFzZURheXMpKX08L2R0PjxkZD57Zm9ybWF0S2VzKHNuYXBzaG90LmJhc2VBbW91bnRLZXMpfTwvZGQ+PC9kaXY+XHJcbiAgICAgIHtzbmFwc2hvdC5jaGF1ZmZldXJGZWVLZXMgPiAwICYmIDxkaXY+PGR0PntjaGF1ZmZldXJGZWVMYWJlbH08L2R0PjxkZD57Zm9ybWF0S2VzKHNuYXBzaG90LmNoYXVmZmV1ckZlZUtlcyl9PC9kZD48L2Rpdj59XHJcbiAgICAgIHtzbmFwc2hvdC5leHRyYXMubWFwKChleHRyYSkgPT4gPGRpdiBrZXk9e2V4dHJhLmNvZGV9PjxkdD57dChleHRyYXNMYWJlbHNbZXh0cmEuY29kZV0gPz8gZXh0cmEubGFiZWwpfTwvZHQ+PGRkPntmb3JtYXRLZXMoZXh0cmEuYW1vdW50S2VzKX08L2RkPjwvZGl2Pil9XHJcbiAgICAgIDxkaXY+PGR0Pnt0KCdib29raW5nLnZhdCcpLnJlcGxhY2UoJ3tyYXRlfScsIFN0cmluZyhzbmFwc2hvdC52YXRSYXRlKSl9PC9kdD48ZGQ+e2Zvcm1hdEtlcyhzbmFwc2hvdC52YXRBbW91bnRLZXMpfTwvZGQ+PC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicXVvdGUtYnJlYWtkb3duX190b3RhbFwiPjxkdD57dCgnYm9va2luZy50b3RhbER1ZScpfTwvZHQ+PGRkPntmb3JtYXRLZXMoc25hcHNob3QudG90YWxEdWVLZXMpfTwvZGQ+PC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicXVvdGUtYnJlYWtkb3duX19kZXBvc2l0XCI+PGR0Pnt0KCdib29raW5nLnJlZnVuZGFibGVEZXBvc2l0Jyl9IDxzcGFuPnt0KCdib29raW5nLmRlcG9zaXRVbnRheGVkJyl9PC9zcGFuPjwvZHQ+PGRkPntmb3JtYXRLZXMoc25hcHNob3QucmVmdW5kYWJsZURlcG9zaXRLZXMpfTwvZGQ+PC9kaXY+XHJcbiAgICA8L2RsPlxyXG4gIClcclxufSJdfQ==
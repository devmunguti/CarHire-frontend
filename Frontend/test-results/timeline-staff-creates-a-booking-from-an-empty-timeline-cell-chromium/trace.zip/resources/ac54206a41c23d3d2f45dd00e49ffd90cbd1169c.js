import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/bookings/BookingDetailPage.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport13_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport13_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=8b23c0c4";
import { Link, useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=8b23c0c4";
import { useAssignDriver, useAvailableDrivers, useBookingDetail, useUpdateBooking } from "/src/api/queries.ts";
import { ApiError } from "/src/api/client.ts";
import { Button, Checkbox, DataTable, EmptyState, ErrorState, Modal, Select, Skeleton, StatusChip } from "/src/components/ui/index.ts";
import { useCan } from "/src/hooks/useCan.ts";
import { t } from "/src/i18n/index.ts";
import { formatEat, formatKenyanPhone, formatKes } from "/src/lib/index.ts";
import { vehicles } from "/src/mocks/fixtures.ts";
import { HoldCountdown } from "/src/features/bookings/HoldCountdown.tsx";
import { QuoteBreakdown } from "/src/features/bookings/QuoteBuilder.tsx";
import { PaymentStatus } from "/src/features/bookings/PaymentStatus.tsx";
import { getDriverEligibilityReason } from "/src/features/drivers/driverRules.ts";
var _jsxFileName = "C:/CarHire/Frontend/src/features/bookings/BookingDetailPage.tsx";
import __vite__cjsImport13_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b23c0c4";
var _s = $RefreshSig$();
export function BookingDetailPage() {
	_s();
	const { id = "" } = useParams();
	const navigate = useNavigate();
	const bookingQuery = useBookingDetail(id);
	const updateBooking = useUpdateBooking(id);
	const assignDriver = useAssignDriver(id);
	const canApprove = useCan("approvals:offline");
	const canHandover = useCan("handover:manage");
	const canAssignDriver = useCan("drivers:assign");
	const [cancelOpen, setCancelOpen] = useState(false);
	const [assignDriverOpen, setAssignDriverOpen] = useState(false);
	const [selectedDriverId, setSelectedDriverId] = useState("");
	const [autoAssign, setAutoAssign] = useState(false);
	const [assignDriverError, setAssignDriverError] = useState(null);
	const [expired, setExpired] = useState(false);
	const [actionError, setActionError] = useState(false);
	const booking = bookingQuery.data;
	const vehicle = booking ? vehicles.find((item) => item.id === booking.vehicleId) : undefined;
	const availableDriversQuery = useAvailableDrivers(booking?.pickupAt ?? "", booking?.returnAt ?? "", booking?.vehicleId ?? "", assignDriverOpen);
	const assignableDrivers = (availableDriversQuery.data?.drivers ?? []).filter((driver) => booking && !getDriverEligibilityReason(driver, booking.returnAt) && (!vehicle || vehicle.seats <= 8 || driver.licenceClass === "C1"));
	const suggestedDriverId = assignableDrivers.some((driver) => driver.id === availableDriversQuery.data?.autoAssignDriverId) ? availableDriversQuery.data?.autoAssignDriverId ?? null : null;
	async function updateStatus(status) {
		setActionError(false);
		try {
			await updateBooking.mutateAsync({
				status,
				pendingApproval: status === "confirmed" ? false : booking?.pendingApproval
			});
		} catch {
			setActionError(true);
			return;
		}
	}
	if (bookingQuery.isLoading) return /* @__PURE__ */ _jsxDEV(Skeleton, { rows: 5 }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 52,
		columnNumber: 38
	}, this);
	if (bookingQuery.isError || !booking) return /* @__PURE__ */ _jsxDEV(ErrorState, {
		onRetry: () => void bookingQuery.refetch(),
		retryLabel: t("styleguide.retry"),
		title: t("booking.actionError")
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 53,
		columnNumber: 48
	}, this);
	const visibleStatus = expired && booking.status === "reserved" ? "expired" : booking.status;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "booking-detail-page",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "booking-detail-header",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV(Link, {
					className: "booking-back-link",
					to: "/admin/bookings",
					children: t("booking.listTitle")
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 60,
					columnNumber: 14
				}, this), /* @__PURE__ */ _jsxDEV("h2", { children: booking.reference }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 60,
					columnNumber: 102
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 60,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "booking-detail-header__status",
					children: [/* @__PURE__ */ _jsxDEV(StatusChip, {
						status: visibleStatus,
						variant: "booking"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 56
					}, this), booking.status === "reserved" && /* @__PURE__ */ _jsxDEV(HoldCountdown, {
						holdExpiresAt: booking.holdExpiresAt,
						onExpire: () => {
							setExpired(true);
							void bookingQuery.refetch();
						}
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 145
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 59,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "booking-detail-actions",
				children: [
					booking.status === "reserved" && canApprove && booking.pendingApproval && /* @__PURE__ */ _jsxDEV(Button, {
						disabled: updateBooking.isPending,
						onClick: () => void updateStatus("confirmed"),
						variant: "primary",
						children: t("booking.approveOffline")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 65,
						columnNumber: 84
					}, this),
					booking.status === "confirmed" && canHandover && /* @__PURE__ */ _jsxDEV(Link, {
						className: "button button--primary",
						to: `/admin/bookings/${booking.id}/check-out`,
						children: t("booking.checkOut")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 59
					}, this),
					booking.status === "confirmed" && canAssignDriver && booking.mode === "chauffeur" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: /* @__PURE__ */ _jsxDEV(Button, {
						onClick: () => {
							setAssignDriverOpen(true);
							setAssignDriverError(null);
							setSelectedDriverId("");
							setAutoAssign(false);
						},
						variant: "secondary",
						children: t("booking.assignDriver")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 11
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 67,
						columnNumber: 95
					}, this),
					booking.status === "checked_out" && canHandover && /* @__PURE__ */ _jsxDEV(Link, {
						className: "button button--primary",
						to: `/admin/bookings/${booking.id}/check-in`,
						children: t("booking.checkIn")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 61
					}, this),
					booking.status === "overdue" && canHandover && /* @__PURE__ */ _jsxDEV(Link, {
						className: "button button--danger",
						to: `/admin/bookings/${booking.id}/check-in`,
						children: t("booking.checkIn")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 57
					}, this),
					["reserved", "confirmed"].includes(booking.status) && /* @__PURE__ */ _jsxDEV(Button, {
						onClick: () => setCancelOpen(true),
						variant: "danger",
						children: t("booking.cancel")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 64
					}, this),
					booking.status === "overdue" && /* @__PURE__ */ _jsxDEV("span", {
						className: "booking-late-fee",
						children: [
							t("booking.accruedLateFee"),
							": ",
							formatKes(booking.accruedLateFeeKes ?? 0)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 73,
						columnNumber: 42
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 64,
				columnNumber: 7
			}, this),
			assignDriverOpen && /* @__PURE__ */ _jsxDEV(Modal, {
				open: true,
				title: "Assign driver",
				onClose: () => setAssignDriverOpen(false),
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "driver-assignment-modal stack stack--md",
					children: [
						/* @__PURE__ */ _jsxDEV(Checkbox, {
							checked: autoAssign,
							label: "Auto-assign next available driver by rotation",
							onChange: (checked) => {
								setAutoAssign(checked);
								setSelectedDriverId("");
							}
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 78,
							columnNumber: 11
						}, this),
						availableDriversQuery.isLoading && /* @__PURE__ */ _jsxDEV(Skeleton, { rows: 2 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 47
						}, this),
						availableDriversQuery.isError && /* @__PURE__ */ _jsxDEV(ErrorState, {
							onRetry: () => void availableDriversQuery.refetch(),
							retryLabel: "Retry",
							title: "Available drivers could not be loaded"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 80,
							columnNumber: 45
						}, this),
						availableDriversQuery.data && assignableDrivers.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
							className: "empty-state",
							children: "No available, licence-valid drivers match this vehicle and trip window."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 76
						}, this),
						availableDriversQuery.data && assignableDrivers.length > 0 && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
							/* @__PURE__ */ _jsxDEV(Select, {
								disabled: autoAssign,
								label: "Available drivers",
								onChange: (event) => setSelectedDriverId(event.target.value),
								options: [{
									value: "",
									label: "Choose a driver"
								}, ...assignableDrivers.map((driver) => ({
									value: driver.id,
									label: `${driver.name} · ${driver.licenceClass} · ${driver.rating.toFixed(1)} / 5`
								}))],
								value: autoAssign ? suggestedDriverId ?? "" : selectedDriverId
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 83,
								columnNumber: 13
							}, this),
							assignDriverError && /* @__PURE__ */ _jsxDEV("p", {
								className: "field__error",
								role: "alert",
								children: assignDriverError
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 90,
								columnNumber: 35
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "confirm-dialog__actions",
								children: [/* @__PURE__ */ _jsxDEV(Button, {
									onClick: () => setAssignDriverOpen(false),
									variant: "secondary",
									children: "Cancel"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 92,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV(Button, {
									disabled: assignDriver.isPending || !(autoAssign ? suggestedDriverId : selectedDriverId),
									onClick: () => {
										const driverId = autoAssign ? suggestedDriverId : selectedDriverId;
										if (!driverId) return;
										setAssignDriverError(null);
										void assignDriver.mutateAsync(driverId).then(() => setAssignDriverOpen(false)).catch((error) => {
											setAssignDriverError(error instanceof ApiError && error.status === 409 ? "This driver was just assigned to another booking. Refresh the available drivers and choose again." : "The driver could not be assigned. Try again.");
											void availableDriversQuery.refetch();
										});
									},
									variant: "primary",
									children: assignDriver.isPending ? "Assigning…" : "Assign driver"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 93,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 91,
								columnNumber: 13
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 74
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 77,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 76,
				columnNumber: 28
			}, this),
			booking.status === "reserved" && booking.paymentMethod === "mpesa_online" && /* @__PURE__ */ _jsxDEV("section", {
				className: "booking-detail-payment",
				children: /* @__PURE__ */ _jsxDEV(PaymentStatus, {
					amountDueKes: booking.totalKes,
					bookingId: booking.id,
					initialPhone: booking.customerPhone,
					onConfirmed: () => void bookingQuery.refetch()
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 110,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 109,
				columnNumber: 85
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "booking-detail-grid",
				children: [
					/* @__PURE__ */ _jsxDEV("section", {
						className: "booking-detail-panel",
						children: [/* @__PURE__ */ _jsxDEV("h3", { children: t("booking.customer") }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 114,
							columnNumber: 51
						}, this), /* @__PURE__ */ _jsxDEV("dl", {
							className: "booking-details-list",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: t("booking.customerName") }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 115,
									columnNumber: 16
								}, this), /* @__PURE__ */ _jsxDEV("dd", { children: booking.customerName ?? "—" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 115,
									columnNumber: 52
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 115,
									columnNumber: 11
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: t("booking.customerPhone") }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 116,
									columnNumber: 16
								}, this), /* @__PURE__ */ _jsxDEV("dd", { children: booking.customerPhone ? formatKenyanPhone(booking.customerPhone) : "—" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 116,
									columnNumber: 53
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 116,
									columnNumber: 11
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: t("booking.pickupAt") }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 117,
									columnNumber: 16
								}, this), /* @__PURE__ */ _jsxDEV("dd", { children: formatEat(booking.pickupAt) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 117,
									columnNumber: 48
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 117,
									columnNumber: 11
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: t("booking.returnAt") }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 118,
									columnNumber: 16
								}, this), /* @__PURE__ */ _jsxDEV("dd", { children: formatEat(booking.returnAt) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 118,
									columnNumber: 48
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 118,
									columnNumber: 11
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 114,
							columnNumber: 83
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 114,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("section", {
						className: "booking-detail-panel",
						children: [/* @__PURE__ */ _jsxDEV("h3", { children: t("booking.vehicle") }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 121,
							columnNumber: 51
						}, this), /* @__PURE__ */ _jsxDEV("dl", {
							className: "booking-details-list",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: t("booking.vehicle") }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 122,
									columnNumber: 16
								}, this), /* @__PURE__ */ _jsxDEV("dd", { children: vehicle ? `${vehicle.make} ${vehicle.model}` : booking.vehicleId }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 122,
									columnNumber: 47
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 122,
									columnNumber: 11
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: t("booking.reference") }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 123,
									columnNumber: 16
								}, this), /* @__PURE__ */ _jsxDEV("dd", { children: vehicle?.registration ?? "—" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 123,
									columnNumber: 49
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 123,
									columnNumber: 11
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: t("booking.mode") }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 124,
									columnNumber: 16
								}, this), /* @__PURE__ */ _jsxDEV("dd", { children: t(booking.mode === "chauffeur" ? "booking.chauffeur" : "booking.selfDrive") }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 124,
									columnNumber: 44
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 124,
									columnNumber: 11
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: t("booking.payment") }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 125,
									columnNumber: 16
								}, this), /* @__PURE__ */ _jsxDEV("dd", { children: t(`booking.${booking.paymentMethod === "mpesa_online" ? "mpesaOnline" : booking.paymentMethod === "mpesa_manual" ? "mpesaManual" : booking.paymentMethod ?? "cash"}`) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 125,
									columnNumber: 47
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 125,
									columnNumber: 11
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 121,
							columnNumber: 82
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 121,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("section", {
						className: "booking-detail-panel booking-detail-panel--wide",
						children: [/* @__PURE__ */ _jsxDEV("h3", { children: t("booking.quoteSnapshot") }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 128,
							columnNumber: 78
						}, this), booking.pricingSnapshot ? /* @__PURE__ */ _jsxDEV(QuoteBreakdown, { quote: {
							currency: "KES",
							pricingSnapshot: booking.pricingSnapshot
						} }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 129,
							columnNumber: 38
						}, this) : /* @__PURE__ */ _jsxDEV("p", { children: t("booking.noQuoteSnapshot") }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 129,
							columnNumber: 129
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 128,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("section", {
						className: "booking-detail-panel",
						children: [/* @__PURE__ */ _jsxDEV("h3", { children: t("booking.payments") }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 132,
							columnNumber: 51
						}, this), booking.payments?.length ? /* @__PURE__ */ _jsxDEV(DataTable, {
							columns: [
								{
									key: "method",
									header: t("booking.payment"),
									render: (payment) => t(`booking.${payment.method === "mpesa_online" ? "mpesaOnline" : payment.method === "mpesa_manual" ? "mpesaManual" : payment.method}`)
								},
								{
									key: "amount",
									header: t("booking.total"),
									render: (payment) => formatKes(payment.amountKes)
								},
								{
									key: "status",
									header: t("booking.status"),
									render: (payment) => payment.status
								}
							],
							empty: /* @__PURE__ */ _jsxDEV(_Fragment, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 137,
								columnNumber: 21
							}, this),
							rowKey: (payment) => payment.id,
							rows: booking.payments
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 133,
							columnNumber: 39
						}, this) : /* @__PURE__ */ _jsxDEV(EmptyState, {
							description: t("booking.noPayments"),
							title: t("booking.payments")
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 137,
							columnNumber: 90
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 132,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("section", {
						className: "booking-detail-panel",
						children: [/* @__PURE__ */ _jsxDEV("h3", { children: t("booking.driver") }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 140,
							columnNumber: 51
						}, this), /* @__PURE__ */ _jsxDEV("p", { children: booking.driver?.name ?? "—" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 140,
							columnNumber: 81
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 140,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("section", {
						className: "booking-detail-panel",
						children: [/* @__PURE__ */ _jsxDEV("h3", { children: t("booking.inspections") }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 141,
							columnNumber: 51
						}, this), booking.inspections?.length ? /* @__PURE__ */ _jsxDEV("ul", {
							className: "booking-event-list",
							children: booking.inspections.map((inspection) => /* @__PURE__ */ _jsxDEV("li", { children: [
								/* @__PURE__ */ _jsxDEV("b", { children: t(inspection.type === "check_out" ? "booking.checkOut" : "booking.checkIn") }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 142,
									columnNumber: 142
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: [inspection.odometer, " km"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 142,
									columnNumber: 226
								}, this),
								/* @__PURE__ */ _jsxDEV("time", { children: formatEat(inspection.createdAt) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 142,
									columnNumber: 263
								}, this)
							] }, inspection.id, true, {
								fileName: _jsxFileName,
								lineNumber: 142,
								columnNumber: 118
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 142,
							columnNumber: 42
						}, this) : /* @__PURE__ */ _jsxDEV(EmptyState, {
							description: t("booking.noInspections"),
							title: t("booking.inspections")
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 142,
							columnNumber: 324
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 141,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("section", {
						className: "booking-detail-panel",
						children: [/* @__PURE__ */ _jsxDEV("h3", { children: t("booking.eventTimeline") }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 51
						}, this), booking.events?.length ? /* @__PURE__ */ _jsxDEV("ul", {
							className: "booking-event-list",
							children: booking.events.map((event) => /* @__PURE__ */ _jsxDEV("li", { children: [
								/* @__PURE__ */ _jsxDEV("b", { children: event.type }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 145,
									columnNumber: 122
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: event.note }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 145,
									columnNumber: 141
								}, this),
								/* @__PURE__ */ _jsxDEV("small", { children: event.actor }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 145,
									columnNumber: 166
								}, this),
								/* @__PURE__ */ _jsxDEV("time", { children: formatEat(event.createdAt) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 145,
									columnNumber: 194
								}, this)
							] }, event.id, true, {
								fileName: _jsxFileName,
								lineNumber: 145,
								columnNumber: 103
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 37
						}, this) : /* @__PURE__ */ _jsxDEV(EmptyState, {
							description: t("booking.noEvents"),
							title: t("booking.eventTimeline")
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 250
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 144,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("section", {
						className: "booking-detail-panel",
						children: [/* @__PURE__ */ _jsxDEV("h3", { children: t("booking.audit") }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 147,
							columnNumber: 51
						}, this), booking.auditEntries?.length ? /* @__PURE__ */ _jsxDEV("ul", {
							className: "booking-event-list",
							children: booking.auditEntries.map((event) => /* @__PURE__ */ _jsxDEV("li", { children: [
								/* @__PURE__ */ _jsxDEV("b", { children: event.type }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 148,
									columnNumber: 134
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: event.note }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 148,
									columnNumber: 153
								}, this),
								/* @__PURE__ */ _jsxDEV("small", { children: event.actor }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 148,
									columnNumber: 178
								}, this),
								/* @__PURE__ */ _jsxDEV("time", { children: formatEat(event.createdAt) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 148,
									columnNumber: 206
								}, this)
							] }, event.id, true, {
								fileName: _jsxFileName,
								lineNumber: 148,
								columnNumber: 115
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 148,
							columnNumber: 43
						}, this) : /* @__PURE__ */ _jsxDEV(EmptyState, {
							description: t("booking.noAudit"),
							title: t("booking.audit")
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 148,
							columnNumber: 262
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 147,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 113,
				columnNumber: 7
			}, this),
			actionError && /* @__PURE__ */ _jsxDEV("p", {
				className: "quote-conflict",
				role: "alert",
				children: t("booking.actionError")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 151,
				columnNumber: 23
			}, this),
			cancelOpen && /* @__PURE__ */ _jsxDEV("div", {
				className: "booking-cancel-confirm",
				role: "group",
				children: [
					/* @__PURE__ */ _jsxDEV("span", { children: t("booking.cancelConfirm") }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 152,
						columnNumber: 75
					}, this),
					/* @__PURE__ */ _jsxDEV(Button, {
						onClick: () => void updateStatus("cancelled").then(() => {
							setCancelOpen(false);
							navigate("/admin/bookings");
						}),
						variant: "danger",
						children: t("booking.confirmAction")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 152,
						columnNumber: 116
					}, this),
					/* @__PURE__ */ _jsxDEV(Button, {
						onClick: () => setCancelOpen(false),
						variant: "secondary",
						children: t("booking.back")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 152,
						columnNumber: 291
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 152,
				columnNumber: 22
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 58,
		columnNumber: 5
	}, this);
}
_s(BookingDetailPage, "cCjNSNAhay9cIftC8B0SoOb0VLM=", false, function() {
	return [
		useParams,
		useNavigate,
		useBookingDetail,
		useUpdateBooking,
		useAssignDriver,
		useCan,
		useCan,
		useCan,
		useAvailableDrivers
	];
});
_c = BookingDetailPage;
var _c;
$RefreshReg$(_c, "BookingDetailPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/bookings/BookingDetailPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/CarHire/Frontend/src/features/bookings/BookingDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/CarHire/Frontend/src/features/bookings/BookingDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/CarHire/Frontend/src/features/bookings/BookingDetailPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxNQUFNLGFBQWEsaUJBQWlCO0FBQzdDLFNBQVMsaUJBQWlCLHFCQUFxQixrQkFBa0Isd0JBQXdCO0FBQ3pGLFNBQVMsZ0JBQWdCO0FBRXpCLFNBQVMsUUFBUSxVQUFVLFdBQVcsWUFBWSxZQUFZLE9BQU8sUUFBUSxVQUFVLGtCQUFrQjtBQUN6RyxTQUFTLGNBQWM7QUFDdkIsU0FBUyxTQUFTO0FBQ2xCLFNBQVMsV0FBVyxtQkFBbUIsaUJBQWlCO0FBQ3hELFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsa0NBQWtDOzs7O0FBRTNDLE9BQU8sU0FBUyxvQkFBb0I7O0NBQ2xDLE1BQU0sRUFBRSxLQUFLLE9BQU8sVUFBVTtDQUM5QixNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLGVBQWUsaUJBQWlCLEVBQUU7Q0FDeEMsTUFBTSxnQkFBZ0IsaUJBQWlCLEVBQUU7Q0FDekMsTUFBTSxlQUFlLGdCQUFnQixFQUFFO0NBQ3ZDLE1BQU0sYUFBYSxPQUFPLG1CQUFtQjtDQUM3QyxNQUFNLGNBQWMsT0FBTyxpQkFBaUI7Q0FDNUMsTUFBTSxrQkFBa0IsT0FBTyxnQkFBZ0I7Q0FDL0MsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsS0FBSztDQUNsRCxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUFTLEtBQUs7Q0FDOUQsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBUyxFQUFFO0NBQzNELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLEtBQUs7Q0FDbEQsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBd0IsSUFBSTtDQUM5RSxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsS0FBSztDQUM1QyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxLQUFLO0NBQ3BELE1BQU0sVUFBVSxhQUFhO0NBQzdCLE1BQU0sVUFBVSxVQUFVLFNBQVMsTUFBTSxTQUFTLEtBQUssT0FBTyxRQUFRLFNBQVMsSUFBSTtDQUNuRixNQUFNLHdCQUF3QixvQkFBb0IsU0FBUyxZQUFZLElBQUksU0FBUyxZQUFZLElBQUksU0FBUyxhQUFhLElBQUksZ0JBQWdCO0NBQzlJLE1BQU0scUJBQXFCLHNCQUFzQixNQUFNLFdBQVcsQ0FBQyxFQUFDLENBQUUsUUFBUSxXQUFXLFdBQ3BGLENBQUMsMkJBQTJCLFFBQVEsUUFBUSxRQUFRLE1BQ25ELENBQUMsV0FBVyxRQUFRLFNBQVMsS0FBSyxPQUFPLGlCQUFpQixLQUFLO0NBQ3JFLE1BQU0sb0JBQW9CLGtCQUFrQixNQUFNLFdBQVcsT0FBTyxPQUFPLHNCQUFzQixNQUFNLGtCQUFrQixJQUNySCxzQkFBc0IsTUFBTSxzQkFBc0IsT0FDbEQ7Q0FFSixlQUFlLGFBQWEsUUFBdUI7RUFDakQsZUFBZSxLQUFLO0VBQ3BCLElBQUk7R0FDRixNQUFNLGNBQWMsWUFBWTtJQUFFO0lBQVEsaUJBQWlCLFdBQVcsY0FBYyxRQUFRLFNBQVM7R0FBZ0IsQ0FBQztFQUN4SCxRQUFRO0dBQ04sZUFBZSxJQUFJO0dBQ25CO0VBQ0Y7Q0FDRjtDQUVBLElBQUksYUFBYSxXQUFXLE9BQU8sd0JBQUMsVUFBRCxFQUFVLE1BQU0sRUFBSTs7Ozs7Q0FDdkQsSUFBSSxhQUFhLFdBQVcsQ0FBQyxTQUFTLE9BQU8sd0JBQUMsWUFBRDtFQUFZLGVBQWUsS0FBSyxhQUFhLFFBQVE7RUFBRyxZQUFZLEVBQUUsa0JBQWtCO0VBQUcsT0FBTyxFQUFFLHFCQUFxQjtDQUFJOzs7OztDQUUxSyxNQUFNLGdCQUErQixXQUFXLFFBQVEsV0FBVyxhQUFhLFlBQVksUUFBUTtDQUVwRyxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxVQUFEO0lBQVEsV0FBVTtjQUFsQixDQUNFLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxNQUFEO0tBQU0sV0FBVTtLQUFvQixJQUFHO2VBQW1CLEVBQUUsbUJBQW1CO0lBQVE7Ozs7Y0FBQyx3QkFBQyxNQUFELFlBQUssUUFBUSxVQUFjOzs7O1lBQU07Ozs7Y0FDOUgsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUErQyx3QkFBQyxZQUFEO01BQVksUUFBUTtNQUFlLFNBQVE7S0FBVzs7OztlQUFFLFFBQVEsV0FBVyxjQUFjLHdCQUFDLGVBQUQ7TUFBZSxlQUFlLFFBQVE7TUFBZSxnQkFBZ0I7T0FBRSxXQUFXLElBQUk7T0FBRyxLQUFLLGFBQWEsUUFBUTtNQUFFO0tBQUk7Ozs7YUFBTzs7Ozs7WUFDbFE7Ozs7OztHQUVSLHdCQUFDLFdBQUQ7SUFBUyxXQUFVO2NBQW5CO0tBQ0csUUFBUSxXQUFXLGNBQWMsY0FBYyxRQUFRLG1CQUFtQix3QkFBQyxRQUFEO01BQVEsVUFBVSxjQUFjO01BQVcsZUFBZSxLQUFLLGFBQWEsV0FBVztNQUFHLFNBQVE7Z0JBQVcsRUFBRSx3QkFBd0I7S0FBVTs7Ozs7S0FDM04sUUFBUSxXQUFXLGVBQWUsZUFBZSx3QkFBQyxNQUFEO01BQU0sV0FBVTtNQUF5QixJQUFJLG1CQUFtQixRQUFRLEdBQUc7Z0JBQWMsRUFBRSxrQkFBa0I7S0FBUTs7Ozs7S0FDdEssUUFBUSxXQUFXLGVBQWUsbUJBQW1CLFFBQVEsU0FBUyxlQUFlLCtDQUNwRix3QkFBQyxRQUFEO01BQVEsZUFBZTtPQUFFLG9CQUFvQixJQUFJO09BQUcscUJBQXFCLElBQUk7T0FBRyxvQkFBb0IsRUFBRTtPQUFHLGNBQWMsS0FBSztNQUFFO01BQUcsU0FBUTtnQkFBYSxFQUFFLHNCQUFzQjtLQUFVOzs7O2NBQ3hMOzs7OztLQUNELFFBQVEsV0FBVyxpQkFBaUIsZUFBZSx3QkFBQyxNQUFEO01BQU0sV0FBVTtNQUF5QixJQUFJLG1CQUFtQixRQUFRLEdBQUc7Z0JBQWEsRUFBRSxpQkFBaUI7S0FBUTs7Ozs7S0FDdEssUUFBUSxXQUFXLGFBQWEsZUFBZSx3QkFBQyxNQUFEO01BQU0sV0FBVTtNQUF3QixJQUFJLG1CQUFtQixRQUFRLEdBQUc7Z0JBQWEsRUFBRSxpQkFBaUI7S0FBUTs7Ozs7S0FDakssQ0FBQyxZQUFZLFdBQVcsQ0FBQyxDQUFDLFNBQVMsUUFBUSxNQUFNLEtBQUssd0JBQUMsUUFBRDtNQUFRLGVBQWUsY0FBYyxJQUFJO01BQUcsU0FBUTtnQkFBVSxFQUFFLGdCQUFnQjtLQUFVOzs7OztLQUNoSixRQUFRLFdBQVcsYUFBYSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaEI7T0FBb0MsRUFBRSx3QkFBd0I7T0FBRTtPQUFHLFVBQVUsUUFBUSxxQkFBcUIsQ0FBQztNQUFROzs7Ozs7SUFDN0k7Ozs7OztHQUVSLG9CQUFvQix3QkFBQyxPQUFEO0lBQU87SUFBSyxPQUFNO0lBQWdCLGVBQWUsb0JBQW9CLEtBQUs7Y0FDN0Ysd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLFVBQUQ7T0FBVSxTQUFTO09BQVksT0FBTTtPQUFnRCxXQUFXLFlBQVk7UUFBRSxjQUFjLE9BQU87UUFBRyxvQkFBb0IsRUFBRTtPQUFFO01BQUk7Ozs7O01BQ2pLLHNCQUFzQixhQUFhLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEVBQUk7Ozs7O01BQ3ZELHNCQUFzQixXQUFXLHdCQUFDLFlBQUQ7T0FBWSxlQUFlLEtBQUssc0JBQXNCLFFBQVE7T0FBRyxZQUFXO09BQVEsT0FBTTtNQUF5Qzs7Ozs7TUFDcEssc0JBQXNCLFFBQVEsa0JBQWtCLFdBQVcsS0FBSyx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBYztNQUEwRTs7Ozs7TUFDckssc0JBQXNCLFFBQVEsa0JBQWtCLFNBQVMsS0FBSztPQUM3RCx3QkFBQyxRQUFEO1FBQ0UsVUFBVTtRQUNWLE9BQU07UUFDTixXQUFXLFVBQVUsb0JBQW9CLE1BQU0sT0FBTyxLQUFLO1FBQzNELFNBQVMsQ0FBQztTQUFFLE9BQU87U0FBSSxPQUFPO1FBQWtCLEdBQUcsR0FBRyxrQkFBa0IsS0FBSyxZQUFZO1NBQUUsT0FBTyxPQUFPO1NBQUksT0FBTyxHQUFHLE9BQU8sS0FBSyxLQUFLLE9BQU8sYUFBYSxLQUFLLE9BQU8sT0FBTyxRQUFRLENBQUMsRUFBRTtRQUFNLEVBQUUsQ0FBQztRQUNuTSxPQUFPLGFBQWEscUJBQXFCLEtBQUs7T0FDL0M7Ozs7O09BQ0EscUJBQXFCLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO1FBQWUsTUFBSztrQkFBUztPQUFxQjs7Ozs7T0FDckYsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQVEsZUFBZSxvQkFBb0IsS0FBSztTQUFHLFNBQVE7bUJBQVk7UUFBYzs7OztrQkFDckYsd0JBQUMsUUFBRDtTQUFRLFVBQVUsYUFBYSxhQUFhLEVBQUUsYUFBYSxvQkFBb0I7U0FBbUIsZUFBZTtVQUMvRyxNQUFNLFdBQVcsYUFBYSxvQkFBb0I7VUFDbEQsSUFBSSxDQUFDLFVBQVU7VUFDZixxQkFBcUIsSUFBSTtVQUN6QixLQUFLLGFBQWEsWUFBWSxRQUFRLENBQUMsQ0FBQyxXQUFXLG9CQUFvQixLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sVUFBbUI7V0FDdkcscUJBQXFCLGlCQUFpQixZQUFZLE1BQU0sV0FBVyxNQUMvRCxzR0FDQSw4Q0FBOEM7V0FDbEQsS0FBSyxzQkFBc0IsUUFBUTtVQUNyQyxDQUFDO1NBQ0g7U0FBRyxTQUFRO21CQUFXLGFBQWEsWUFBWSxlQUFlO1FBQXdCOzs7O2dCQUNuRjs7Ozs7O01BQ0w7Ozs7O0tBQ0M7Ozs7OztHQUNBOzs7OztHQUVOLFFBQVEsV0FBVyxjQUFjLFFBQVEsa0JBQWtCLGtCQUFrQix3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUMvRix3QkFBQyxlQUFEO0tBQWUsY0FBYyxRQUFRO0tBQVUsV0FBVyxRQUFRO0tBQUksY0FBYyxRQUFRO0tBQWUsbUJBQW1CLEtBQUssYUFBYSxRQUFRO0lBQUk7Ozs7O0dBQ3JKOzs7OztHQUVULHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxXQUFEO01BQVMsV0FBVTtnQkFBbkIsQ0FBMEMsd0JBQUMsTUFBRCxZQUFLLEVBQUUsa0JBQWtCLEVBQU07Ozs7Z0JBQUMsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQ7UUFDeEUsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLE1BQUQsWUFBSyxFQUFFLHNCQUFzQixFQUFNOzs7O2tCQUFDLHdCQUFDLE1BQUQsWUFBSyxRQUFRLGdCQUFnQixJQUFROzs7O2dCQUFNOzs7OztRQUNwRix3QkFBQyxPQUFELGFBQUssd0JBQUMsTUFBRCxZQUFLLEVBQUUsdUJBQXVCLEVBQU07Ozs7a0JBQUMsd0JBQUMsTUFBRCxZQUFLLFFBQVEsZ0JBQWdCLGtCQUFrQixRQUFRLGFBQWEsSUFBSSxJQUFROzs7O2dCQUFNOzs7OztRQUNoSSx3QkFBQyxPQUFELGFBQUssd0JBQUMsTUFBRCxZQUFLLEVBQUUsa0JBQWtCLEVBQU07Ozs7a0JBQUMsd0JBQUMsTUFBRCxZQUFLLFVBQVUsUUFBUSxRQUFRLEVBQU07Ozs7Z0JBQU07Ozs7O1FBQ2hGLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxNQUFELFlBQUssRUFBRSxrQkFBa0IsRUFBTTs7OztrQkFBQyx3QkFBQyxNQUFELFlBQUssVUFBVSxRQUFRLFFBQVEsRUFBTTs7OztnQkFBTTs7Ozs7T0FDOUU7Ozs7O2NBQVU7Ozs7OztLQUVkLHdCQUFDLFdBQUQ7TUFBUyxXQUFVO2dCQUFuQixDQUEwQyx3QkFBQyxNQUFELFlBQUssRUFBRSxpQkFBaUIsRUFBTTs7OztnQkFBQyx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZDtRQUN2RSx3QkFBQyxPQUFELGFBQUssd0JBQUMsTUFBRCxZQUFLLEVBQUUsaUJBQWlCLEVBQU07Ozs7a0JBQUMsd0JBQUMsTUFBRCxZQUFLLFVBQVUsR0FBRyxRQUFRLEtBQUssR0FBRyxRQUFRLFVBQVUsUUFBUSxVQUFjOzs7O2dCQUFNOzs7OztRQUNwSCx3QkFBQyxPQUFELGFBQUssd0JBQUMsTUFBRCxZQUFLLEVBQUUsbUJBQW1CLEVBQU07Ozs7a0JBQUMsd0JBQUMsTUFBRCxZQUFLLFNBQVMsZ0JBQWdCLElBQVE7Ozs7Z0JBQU07Ozs7O1FBQ2xGLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxNQUFELFlBQUssRUFBRSxjQUFjLEVBQU07Ozs7a0JBQUMsd0JBQUMsTUFBRCxZQUFLLEVBQUUsUUFBUSxTQUFTLGNBQWMsc0JBQXNCLG1CQUFtQixFQUFNOzs7O2dCQUFNOzs7OztRQUM1SCx3QkFBQyxPQUFELGFBQUssd0JBQUMsTUFBRCxZQUFLLEVBQUUsaUJBQWlCLEVBQU07Ozs7a0JBQUMsd0JBQUMsTUFBRCxZQUFLLEVBQUUsV0FBVyxRQUFRLGtCQUFrQixpQkFBaUIsZ0JBQWdCLFFBQVEsa0JBQWtCLGlCQUFpQixnQkFBZ0IsUUFBUSxpQkFBaUIsUUFBUSxFQUFNOzs7O2dCQUFNOzs7OztPQUN2Tjs7Ozs7Y0FBVTs7Ozs7O0tBRWQsd0JBQUMsV0FBRDtNQUFTLFdBQVU7Z0JBQW5CLENBQXFFLHdCQUFDLE1BQUQsWUFBSyxFQUFFLHVCQUF1QixFQUFNOzs7O2dCQUN0RyxRQUFRLGtCQUFrQix3QkFBQyxnQkFBRCxFQUFnQixPQUFPO09BQUUsVUFBVTtPQUFPLGlCQUFpQixRQUFRO01BQWdCLEVBQUk7Ozs7aUJBQUksd0JBQUMsS0FBRCxZQUFJLEVBQUUseUJBQXlCLEVBQUs7Ozs7Y0FDbko7Ozs7OztLQUVULHdCQUFDLFdBQUQ7TUFBUyxXQUFVO2dCQUFuQixDQUEwQyx3QkFBQyxNQUFELFlBQUssRUFBRSxrQkFBa0IsRUFBTTs7OztnQkFDdEUsUUFBUSxVQUFVLFNBQVMsd0JBQUMsV0FBRDtPQUFXLFNBQVM7UUFDOUM7U0FBRSxLQUFLO1NBQVUsUUFBUSxFQUFFLGlCQUFpQjtTQUFHLFNBQVMsWUFBWSxFQUFFLFdBQVcsUUFBUSxXQUFXLGlCQUFpQixnQkFBZ0IsUUFBUSxXQUFXLGlCQUFpQixnQkFBZ0IsUUFBUSxRQUFRO1FBQUU7UUFDM007U0FBRSxLQUFLO1NBQVUsUUFBUSxFQUFFLGVBQWU7U0FBRyxTQUFTLFlBQVksVUFBVSxRQUFRLFNBQVM7UUFBRTtRQUMvRjtTQUFFLEtBQUs7U0FBVSxRQUFRLEVBQUUsZ0JBQWdCO1NBQUcsU0FBUyxZQUFZLFFBQVE7UUFBTztPQUNwRjtPQUFHLE9BQU8sb0NBQUk7Ozs7O09BQUcsU0FBUyxZQUFZLFFBQVE7T0FBSSxNQUFNLFFBQVE7TUFBVzs7OztpQkFBSSx3QkFBQyxZQUFEO09BQVksYUFBYSxFQUFFLG9CQUFvQjtPQUFHLE9BQU8sRUFBRSxrQkFBa0I7TUFBSTs7OztjQUN6Sjs7Ozs7O0tBRVQsd0JBQUMsV0FBRDtNQUFTLFdBQVU7Z0JBQW5CLENBQTBDLHdCQUFDLE1BQUQsWUFBSyxFQUFFLGdCQUFnQixFQUFNOzs7O2dCQUFDLHdCQUFDLEtBQUQsWUFBSSxRQUFRLFFBQVEsUUFBUSxJQUFPOzs7O2NBQVU7Ozs7OztLQUNySCx3QkFBQyxXQUFEO01BQVMsV0FBVTtnQkFBbkIsQ0FBMEMsd0JBQUMsTUFBRCxZQUFLLEVBQUUscUJBQXFCLEVBQU07Ozs7Z0JBQ3pFLFFBQVEsYUFBYSxTQUFTLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFzQixRQUFRLFlBQVksS0FBSyxlQUFlLHdCQUFDLE1BQUQ7UUFBd0Isd0JBQUMsS0FBRCxZQUFJLEVBQUUsV0FBVyxTQUFTLGNBQWMscUJBQXFCLGlCQUFpQixFQUFLOzs7OztRQUFDLHdCQUFDLFFBQUQsYUFBTyxXQUFXLFVBQVMsS0FBUzs7Ozs7UUFBQyx3QkFBQyxRQUFELFlBQU8sVUFBVSxXQUFXLFNBQVMsRUFBUTs7Ozs7T0FBSyxLQUExTCxXQUFXOzs7O2NBQStLLENBQUM7TUFBTTs7OztpQkFBSSx3QkFBQyxZQUFEO09BQVksYUFBYSxFQUFFLHVCQUF1QjtPQUFHLE9BQU8sRUFBRSxxQkFBcUI7TUFBSTs7OztjQUN6WTs7Ozs7O0tBQ1Qsd0JBQUMsV0FBRDtNQUFTLFdBQVU7Z0JBQW5CLENBQTBDLHdCQUFDLE1BQUQsWUFBSyxFQUFFLHVCQUF1QixFQUFNOzs7O2dCQUMzRSxRQUFRLFFBQVEsU0FBUyx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBc0IsUUFBUSxPQUFPLEtBQUssVUFBVSx3QkFBQyxNQUFEO1FBQW1CLHdCQUFDLEtBQUQsWUFBSSxNQUFNLEtBQVE7Ozs7O1FBQUMsd0JBQUMsUUFBRCxZQUFPLE1BQU0sS0FBVzs7Ozs7UUFBQyx3QkFBQyxTQUFELFlBQVEsTUFBTSxNQUFhOzs7OztRQUFDLHdCQUFDLFFBQUQsWUFBTyxVQUFVLE1BQU0sU0FBUyxFQUFROzs7OztPQUFLLEtBQS9ILE1BQU07Ozs7Y0FBeUgsQ0FBQztNQUFNOzs7O2lCQUFJLHdCQUFDLFlBQUQ7T0FBWSxhQUFhLEVBQUUsa0JBQWtCO09BQUcsT0FBTyxFQUFFLHVCQUF1QjtNQUFJOzs7O2NBQzVUOzs7Ozs7S0FDVCx3QkFBQyxXQUFEO01BQVMsV0FBVTtnQkFBbkIsQ0FBMEMsd0JBQUMsTUFBRCxZQUFLLEVBQUUsZUFBZSxFQUFNOzs7O2dCQUNuRSxRQUFRLGNBQWMsU0FBUyx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBc0IsUUFBUSxhQUFhLEtBQUssVUFBVSx3QkFBQyxNQUFEO1FBQW1CLHdCQUFDLEtBQUQsWUFBSSxNQUFNLEtBQVE7Ozs7O1FBQUMsd0JBQUMsUUFBRCxZQUFPLE1BQU0sS0FBVzs7Ozs7UUFBQyx3QkFBQyxTQUFELFlBQVEsTUFBTSxNQUFhOzs7OztRQUFDLHdCQUFDLFFBQUQsWUFBTyxVQUFVLE1BQU0sU0FBUyxFQUFROzs7OztPQUFLLEtBQS9ILE1BQU07Ozs7Y0FBeUgsQ0FBQztNQUFNOzs7O2lCQUFJLHdCQUFDLFlBQUQ7T0FBWSxhQUFhLEVBQUUsaUJBQWlCO09BQUcsT0FBTyxFQUFFLGVBQWU7TUFBSTs7OztjQUMvVDs7Ozs7O0lBQ047Ozs7OztHQUNKLGVBQWUsd0JBQUMsS0FBRDtJQUFHLFdBQVU7SUFBaUIsTUFBSztjQUFTLEVBQUUscUJBQXFCO0dBQUs7Ozs7O0dBQ3ZGLGNBQWMsd0JBQUMsT0FBRDtJQUFLLFdBQVU7SUFBeUIsTUFBSztjQUE3QztLQUFxRCx3QkFBQyxRQUFELFlBQU8sRUFBRSx1QkFBdUIsRUFBUTs7Ozs7S0FBQyx3QkFBQyxRQUFEO01BQVEsZUFBZSxLQUFLLGFBQWEsV0FBVyxDQUFDLENBQUMsV0FBVztPQUFFLGNBQWMsS0FBSztPQUFHLFNBQVMsaUJBQWlCO01BQUUsQ0FBQztNQUFHLFNBQVE7Z0JBQVUsRUFBRSx1QkFBdUI7S0FBVTs7Ozs7S0FBQyx3QkFBQyxRQUFEO01BQVEsZUFBZSxjQUFjLEtBQUs7TUFBRyxTQUFRO2dCQUFhLEVBQUUsY0FBYztLQUFVOzs7OztJQUFNOzs7Ozs7RUFDM1g7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkJvb2tpbmdEZXRhaWxQYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBMaW5rLCB1c2VOYXZpZ2F0ZSwgdXNlUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcclxuaW1wb3J0IHsgdXNlQXNzaWduRHJpdmVyLCB1c2VBdmFpbGFibGVEcml2ZXJzLCB1c2VCb29raW5nRGV0YWlsLCB1c2VVcGRhdGVCb29raW5nIH0gZnJvbSAnLi4vLi4vYXBpL3F1ZXJpZXMnXHJcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSAnLi4vLi4vYXBpL2NsaWVudCdcclxuaW1wb3J0IHR5cGUgeyBCb29raW5nU3RhdHVzIH0gZnJvbSAnLi4vLi4vYXBpL3R5cGVzJ1xyXG5pbXBvcnQgeyBCdXR0b24sIENoZWNrYm94LCBEYXRhVGFibGUsIEVtcHR5U3RhdGUsIEVycm9yU3RhdGUsIE1vZGFsLCBTZWxlY3QsIFNrZWxldG9uLCBTdGF0dXNDaGlwIH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy91aSdcclxuaW1wb3J0IHsgdXNlQ2FuIH0gZnJvbSAnLi4vLi4vaG9va3MvdXNlQ2FuJ1xyXG5pbXBvcnQgeyB0IH0gZnJvbSAnLi4vLi4vaTE4bidcclxuaW1wb3J0IHsgZm9ybWF0RWF0LCBmb3JtYXRLZW55YW5QaG9uZSwgZm9ybWF0S2VzIH0gZnJvbSAnLi4vLi4vbGliJ1xyXG5pbXBvcnQgeyB2ZWhpY2xlcyB9IGZyb20gJy4uLy4uL21vY2tzL2ZpeHR1cmVzJ1xyXG5pbXBvcnQgeyBIb2xkQ291bnRkb3duIH0gZnJvbSAnLi9Ib2xkQ291bnRkb3duJ1xyXG5pbXBvcnQgeyBRdW90ZUJyZWFrZG93biB9IGZyb20gJy4vUXVvdGVCdWlsZGVyJ1xyXG5pbXBvcnQgeyBQYXltZW50U3RhdHVzIH0gZnJvbSAnLi9QYXltZW50U3RhdHVzJ1xyXG5pbXBvcnQgeyBnZXREcml2ZXJFbGlnaWJpbGl0eVJlYXNvbiB9IGZyb20gJy4uL2RyaXZlcnMvZHJpdmVyUnVsZXMnXHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQm9va2luZ0RldGFpbFBhZ2UoKSB7XHJcbiAgY29uc3QgeyBpZCA9ICcnIH0gPSB1c2VQYXJhbXMoKVxyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxyXG4gIGNvbnN0IGJvb2tpbmdRdWVyeSA9IHVzZUJvb2tpbmdEZXRhaWwoaWQpXHJcbiAgY29uc3QgdXBkYXRlQm9va2luZyA9IHVzZVVwZGF0ZUJvb2tpbmcoaWQpXHJcbiAgY29uc3QgYXNzaWduRHJpdmVyID0gdXNlQXNzaWduRHJpdmVyKGlkKVxyXG4gIGNvbnN0IGNhbkFwcHJvdmUgPSB1c2VDYW4oJ2FwcHJvdmFsczpvZmZsaW5lJylcclxuICBjb25zdCBjYW5IYW5kb3ZlciA9IHVzZUNhbignaGFuZG92ZXI6bWFuYWdlJylcclxuICBjb25zdCBjYW5Bc3NpZ25Ecml2ZXIgPSB1c2VDYW4oJ2RyaXZlcnM6YXNzaWduJylcclxuICBjb25zdCBbY2FuY2VsT3Blbiwgc2V0Q2FuY2VsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICBjb25zdCBbYXNzaWduRHJpdmVyT3Blbiwgc2V0QXNzaWduRHJpdmVyT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICBjb25zdCBbc2VsZWN0ZWREcml2ZXJJZCwgc2V0U2VsZWN0ZWREcml2ZXJJZF0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbYXV0b0Fzc2lnbiwgc2V0QXV0b0Fzc2lnbl0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICBjb25zdCBbYXNzaWduRHJpdmVyRXJyb3IsIHNldEFzc2lnbkRyaXZlckVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpXHJcbiAgY29uc3QgW2V4cGlyZWQsIHNldEV4cGlyZWRdID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgY29uc3QgW2FjdGlvbkVycm9yLCBzZXRBY3Rpb25FcnJvcl0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICBjb25zdCBib29raW5nID0gYm9va2luZ1F1ZXJ5LmRhdGFcclxuICBjb25zdCB2ZWhpY2xlID0gYm9va2luZyA/IHZlaGljbGVzLmZpbmQoKGl0ZW0pID0+IGl0ZW0uaWQgPT09IGJvb2tpbmcudmVoaWNsZUlkKSA6IHVuZGVmaW5lZFxyXG4gIGNvbnN0IGF2YWlsYWJsZURyaXZlcnNRdWVyeSA9IHVzZUF2YWlsYWJsZURyaXZlcnMoYm9va2luZz8ucGlja3VwQXQgPz8gJycsIGJvb2tpbmc/LnJldHVybkF0ID8/ICcnLCBib29raW5nPy52ZWhpY2xlSWQgPz8gJycsIGFzc2lnbkRyaXZlck9wZW4pXHJcbiAgY29uc3QgYXNzaWduYWJsZURyaXZlcnMgPSAoYXZhaWxhYmxlRHJpdmVyc1F1ZXJ5LmRhdGE/LmRyaXZlcnMgPz8gW10pLmZpbHRlcigoZHJpdmVyKSA9PiBib29raW5nXHJcbiAgICAmJiAhZ2V0RHJpdmVyRWxpZ2liaWxpdHlSZWFzb24oZHJpdmVyLCBib29raW5nLnJldHVybkF0KVxyXG4gICAgJiYgKCF2ZWhpY2xlIHx8IHZlaGljbGUuc2VhdHMgPD0gOCB8fCBkcml2ZXIubGljZW5jZUNsYXNzID09PSAnQzEnKSlcclxuICBjb25zdCBzdWdnZXN0ZWREcml2ZXJJZCA9IGFzc2lnbmFibGVEcml2ZXJzLnNvbWUoKGRyaXZlcikgPT4gZHJpdmVyLmlkID09PSBhdmFpbGFibGVEcml2ZXJzUXVlcnkuZGF0YT8uYXV0b0Fzc2lnbkRyaXZlcklkKVxyXG4gICAgPyBhdmFpbGFibGVEcml2ZXJzUXVlcnkuZGF0YT8uYXV0b0Fzc2lnbkRyaXZlcklkID8/IG51bGxcclxuICAgIDogbnVsbFxyXG5cclxuICBhc3luYyBmdW5jdGlvbiB1cGRhdGVTdGF0dXMoc3RhdHVzOiBCb29raW5nU3RhdHVzKSB7XHJcbiAgICBzZXRBY3Rpb25FcnJvcihmYWxzZSlcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IHVwZGF0ZUJvb2tpbmcubXV0YXRlQXN5bmMoeyBzdGF0dXMsIHBlbmRpbmdBcHByb3ZhbDogc3RhdHVzID09PSAnY29uZmlybWVkJyA/IGZhbHNlIDogYm9va2luZz8ucGVuZGluZ0FwcHJvdmFsIH0pXHJcbiAgICB9IGNhdGNoIHtcclxuICAgICAgc2V0QWN0aW9uRXJyb3IodHJ1ZSlcclxuICAgICAgcmV0dXJuXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBpZiAoYm9va2luZ1F1ZXJ5LmlzTG9hZGluZykgcmV0dXJuIDxTa2VsZXRvbiByb3dzPXs1fSAvPlxyXG4gIGlmIChib29raW5nUXVlcnkuaXNFcnJvciB8fCAhYm9va2luZykgcmV0dXJuIDxFcnJvclN0YXRlIG9uUmV0cnk9eygpID0+IHZvaWQgYm9va2luZ1F1ZXJ5LnJlZmV0Y2goKX0gcmV0cnlMYWJlbD17dCgnc3R5bGVndWlkZS5yZXRyeScpfSB0aXRsZT17dCgnYm9va2luZy5hY3Rpb25FcnJvcicpfSAvPlxyXG5cclxuICBjb25zdCB2aXNpYmxlU3RhdHVzOiBCb29raW5nU3RhdHVzID0gZXhwaXJlZCAmJiBib29raW5nLnN0YXR1cyA9PT0gJ3Jlc2VydmVkJyA/ICdleHBpcmVkJyA6IGJvb2tpbmcuc3RhdHVzXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImJvb2tpbmctZGV0YWlsLXBhZ2VcIj5cclxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJib29raW5nLWRldGFpbC1oZWFkZXJcIj5cclxuICAgICAgICA8ZGl2PjxMaW5rIGNsYXNzTmFtZT1cImJvb2tpbmctYmFjay1saW5rXCIgdG89XCIvYWRtaW4vYm9va2luZ3NcIj57dCgnYm9va2luZy5saXN0VGl0bGUnKX08L0xpbms+PGgyPntib29raW5nLnJlZmVyZW5jZX08L2gyPjwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9va2luZy1kZXRhaWwtaGVhZGVyX19zdGF0dXNcIj48U3RhdHVzQ2hpcCBzdGF0dXM9e3Zpc2libGVTdGF0dXN9IHZhcmlhbnQ9XCJib29raW5nXCIgLz57Ym9va2luZy5zdGF0dXMgPT09ICdyZXNlcnZlZCcgJiYgPEhvbGRDb3VudGRvd24gaG9sZEV4cGlyZXNBdD17Ym9va2luZy5ob2xkRXhwaXJlc0F0fSBvbkV4cGlyZT17KCkgPT4geyBzZXRFeHBpcmVkKHRydWUpOyB2b2lkIGJvb2tpbmdRdWVyeS5yZWZldGNoKCkgfX0gLz59PC9kaXY+XHJcbiAgICAgIDwvaGVhZGVyPlxyXG5cclxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiYm9va2luZy1kZXRhaWwtYWN0aW9uc1wiPlxyXG4gICAgICAgIHtib29raW5nLnN0YXR1cyA9PT0gJ3Jlc2VydmVkJyAmJiBjYW5BcHByb3ZlICYmIGJvb2tpbmcucGVuZGluZ0FwcHJvdmFsICYmIDxCdXR0b24gZGlzYWJsZWQ9e3VwZGF0ZUJvb2tpbmcuaXNQZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiB2b2lkIHVwZGF0ZVN0YXR1cygnY29uZmlybWVkJyl9IHZhcmlhbnQ9XCJwcmltYXJ5XCI+e3QoJ2Jvb2tpbmcuYXBwcm92ZU9mZmxpbmUnKX08L0J1dHRvbj59XHJcbiAgICAgICAge2Jvb2tpbmcuc3RhdHVzID09PSAnY29uZmlybWVkJyAmJiBjYW5IYW5kb3ZlciAmJiA8TGluayBjbGFzc05hbWU9XCJidXR0b24gYnV0dG9uLS1wcmltYXJ5XCIgdG89e2AvYWRtaW4vYm9va2luZ3MvJHtib29raW5nLmlkfS9jaGVjay1vdXRgfT57dCgnYm9va2luZy5jaGVja091dCcpfTwvTGluaz59XHJcbiAgICAgICAge2Jvb2tpbmcuc3RhdHVzID09PSAnY29uZmlybWVkJyAmJiBjYW5Bc3NpZ25Ecml2ZXIgJiYgYm9va2luZy5tb2RlID09PSAnY2hhdWZmZXVyJyAmJiA8PlxyXG4gICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB7IHNldEFzc2lnbkRyaXZlck9wZW4odHJ1ZSk7IHNldEFzc2lnbkRyaXZlckVycm9yKG51bGwpOyBzZXRTZWxlY3RlZERyaXZlcklkKCcnKTsgc2V0QXV0b0Fzc2lnbihmYWxzZSkgfX0gdmFyaWFudD1cInNlY29uZGFyeVwiPnt0KCdib29raW5nLmFzc2lnbkRyaXZlcicpfTwvQnV0dG9uPlxyXG4gICAgICAgIDwvPn1cclxuICAgICAgICB7Ym9va2luZy5zdGF0dXMgPT09ICdjaGVja2VkX291dCcgJiYgY2FuSGFuZG92ZXIgJiYgPExpbmsgY2xhc3NOYW1lPVwiYnV0dG9uIGJ1dHRvbi0tcHJpbWFyeVwiIHRvPXtgL2FkbWluL2Jvb2tpbmdzLyR7Ym9va2luZy5pZH0vY2hlY2staW5gfT57dCgnYm9va2luZy5jaGVja0luJyl9PC9MaW5rPn1cclxuICAgICAgICB7Ym9va2luZy5zdGF0dXMgPT09ICdvdmVyZHVlJyAmJiBjYW5IYW5kb3ZlciAmJiA8TGluayBjbGFzc05hbWU9XCJidXR0b24gYnV0dG9uLS1kYW5nZXJcIiB0bz17YC9hZG1pbi9ib29raW5ncy8ke2Jvb2tpbmcuaWR9L2NoZWNrLWluYH0+e3QoJ2Jvb2tpbmcuY2hlY2tJbicpfTwvTGluaz59XHJcbiAgICAgICAge1sncmVzZXJ2ZWQnLCAnY29uZmlybWVkJ10uaW5jbHVkZXMoYm9va2luZy5zdGF0dXMpICYmIDxCdXR0b24gb25DbGljaz17KCkgPT4gc2V0Q2FuY2VsT3Blbih0cnVlKX0gdmFyaWFudD1cImRhbmdlclwiPnt0KCdib29raW5nLmNhbmNlbCcpfTwvQnV0dG9uPn1cclxuICAgICAgICB7Ym9va2luZy5zdGF0dXMgPT09ICdvdmVyZHVlJyAmJiA8c3BhbiBjbGFzc05hbWU9XCJib29raW5nLWxhdGUtZmVlXCI+e3QoJ2Jvb2tpbmcuYWNjcnVlZExhdGVGZWUnKX06IHtmb3JtYXRLZXMoYm9va2luZy5hY2NydWVkTGF0ZUZlZUtlcyA/PyAwKX08L3NwYW4+fVxyXG4gICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICB7YXNzaWduRHJpdmVyT3BlbiAmJiA8TW9kYWwgb3BlbiB0aXRsZT1cIkFzc2lnbiBkcml2ZXJcIiBvbkNsb3NlPXsoKSA9PiBzZXRBc3NpZ25Ecml2ZXJPcGVuKGZhbHNlKX0+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkcml2ZXItYXNzaWdubWVudC1tb2RhbCBzdGFjayBzdGFjay0tbWRcIj5cclxuICAgICAgICAgIDxDaGVja2JveCBjaGVja2VkPXthdXRvQXNzaWdufSBsYWJlbD1cIkF1dG8tYXNzaWduIG5leHQgYXZhaWxhYmxlIGRyaXZlciBieSByb3RhdGlvblwiIG9uQ2hhbmdlPXsoY2hlY2tlZCkgPT4geyBzZXRBdXRvQXNzaWduKGNoZWNrZWQpOyBzZXRTZWxlY3RlZERyaXZlcklkKCcnKSB9fSAvPlxyXG4gICAgICAgICAge2F2YWlsYWJsZURyaXZlcnNRdWVyeS5pc0xvYWRpbmcgJiYgPFNrZWxldG9uIHJvd3M9ezJ9IC8+fVxyXG4gICAgICAgICAge2F2YWlsYWJsZURyaXZlcnNRdWVyeS5pc0Vycm9yICYmIDxFcnJvclN0YXRlIG9uUmV0cnk9eygpID0+IHZvaWQgYXZhaWxhYmxlRHJpdmVyc1F1ZXJ5LnJlZmV0Y2goKX0gcmV0cnlMYWJlbD1cIlJldHJ5XCIgdGl0bGU9XCJBdmFpbGFibGUgZHJpdmVycyBjb3VsZCBub3QgYmUgbG9hZGVkXCIgLz59XHJcbiAgICAgICAgICB7YXZhaWxhYmxlRHJpdmVyc1F1ZXJ5LmRhdGEgJiYgYXNzaWduYWJsZURyaXZlcnMubGVuZ3RoID09PSAwICYmIDxwIGNsYXNzTmFtZT1cImVtcHR5LXN0YXRlXCI+Tm8gYXZhaWxhYmxlLCBsaWNlbmNlLXZhbGlkIGRyaXZlcnMgbWF0Y2ggdGhpcyB2ZWhpY2xlIGFuZCB0cmlwIHdpbmRvdy48L3A+fVxyXG4gICAgICAgICAge2F2YWlsYWJsZURyaXZlcnNRdWVyeS5kYXRhICYmIGFzc2lnbmFibGVEcml2ZXJzLmxlbmd0aCA+IDAgJiYgPD5cclxuICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXthdXRvQXNzaWdufVxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiQXZhaWxhYmxlIGRyaXZlcnNcIlxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFNlbGVjdGVkRHJpdmVySWQoZXZlbnQudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICBvcHRpb25zPXtbeyB2YWx1ZTogJycsIGxhYmVsOiAnQ2hvb3NlIGEgZHJpdmVyJyB9LCAuLi5hc3NpZ25hYmxlRHJpdmVycy5tYXAoKGRyaXZlcikgPT4gKHsgdmFsdWU6IGRyaXZlci5pZCwgbGFiZWw6IGAke2RyaXZlci5uYW1lfSDCtyAke2RyaXZlci5saWNlbmNlQ2xhc3N9IMK3ICR7ZHJpdmVyLnJhdGluZy50b0ZpeGVkKDEpfSAvIDVgIH0pKV19XHJcbiAgICAgICAgICAgICAgdmFsdWU9e2F1dG9Bc3NpZ24gPyBzdWdnZXN0ZWREcml2ZXJJZCA/PyAnJyA6IHNlbGVjdGVkRHJpdmVySWR9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIHthc3NpZ25Ecml2ZXJFcnJvciAmJiA8cCBjbGFzc05hbWU9XCJmaWVsZF9fZXJyb3JcIiByb2xlPVwiYWxlcnRcIj57YXNzaWduRHJpdmVyRXJyb3J9PC9wPn1cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb25maXJtLWRpYWxvZ19fYWN0aW9uc1wiPlxyXG4gICAgICAgICAgICAgIDxCdXR0b24gb25DbGljaz17KCkgPT4gc2V0QXNzaWduRHJpdmVyT3BlbihmYWxzZSl9IHZhcmlhbnQ9XCJzZWNvbmRhcnlcIj5DYW5jZWw8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8QnV0dG9uIGRpc2FibGVkPXthc3NpZ25Ecml2ZXIuaXNQZW5kaW5nIHx8ICEoYXV0b0Fzc2lnbiA/IHN1Z2dlc3RlZERyaXZlcklkIDogc2VsZWN0ZWREcml2ZXJJZCl9IG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGRyaXZlcklkID0gYXV0b0Fzc2lnbiA/IHN1Z2dlc3RlZERyaXZlcklkIDogc2VsZWN0ZWREcml2ZXJJZFxyXG4gICAgICAgICAgICAgICAgaWYgKCFkcml2ZXJJZCkgcmV0dXJuXHJcbiAgICAgICAgICAgICAgICBzZXRBc3NpZ25Ecml2ZXJFcnJvcihudWxsKVxyXG4gICAgICAgICAgICAgICAgdm9pZCBhc3NpZ25Ecml2ZXIubXV0YXRlQXN5bmMoZHJpdmVySWQpLnRoZW4oKCkgPT4gc2V0QXNzaWduRHJpdmVyT3BlbihmYWxzZSkpLmNhdGNoKChlcnJvcjogdW5rbm93bikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBzZXRBc3NpZ25Ecml2ZXJFcnJvcihlcnJvciBpbnN0YW5jZW9mIEFwaUVycm9yICYmIGVycm9yLnN0YXR1cyA9PT0gNDA5XHJcbiAgICAgICAgICAgICAgICAgICAgPyAnVGhpcyBkcml2ZXIgd2FzIGp1c3QgYXNzaWduZWQgdG8gYW5vdGhlciBib29raW5nLiBSZWZyZXNoIHRoZSBhdmFpbGFibGUgZHJpdmVycyBhbmQgY2hvb3NlIGFnYWluLidcclxuICAgICAgICAgICAgICAgICAgICA6ICdUaGUgZHJpdmVyIGNvdWxkIG5vdCBiZSBhc3NpZ25lZC4gVHJ5IGFnYWluLicpXHJcbiAgICAgICAgICAgICAgICAgIHZvaWQgYXZhaWxhYmxlRHJpdmVyc1F1ZXJ5LnJlZmV0Y2goKVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICB9fSB2YXJpYW50PVwicHJpbWFyeVwiPnthc3NpZ25Ecml2ZXIuaXNQZW5kaW5nID8gJ0Fzc2lnbmluZ+KApicgOiAnQXNzaWduIGRyaXZlcid9PC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC8+fVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L01vZGFsPn1cclxuXHJcbiAgICAgIHtib29raW5nLnN0YXR1cyA9PT0gJ3Jlc2VydmVkJyAmJiBib29raW5nLnBheW1lbnRNZXRob2QgPT09ICdtcGVzYV9vbmxpbmUnICYmIDxzZWN0aW9uIGNsYXNzTmFtZT1cImJvb2tpbmctZGV0YWlsLXBheW1lbnRcIj5cclxuICAgICAgICA8UGF5bWVudFN0YXR1cyBhbW91bnREdWVLZXM9e2Jvb2tpbmcudG90YWxLZXN9IGJvb2tpbmdJZD17Ym9va2luZy5pZH0gaW5pdGlhbFBob25lPXtib29raW5nLmN1c3RvbWVyUGhvbmV9IG9uQ29uZmlybWVkPXsoKSA9PiB2b2lkIGJvb2tpbmdRdWVyeS5yZWZldGNoKCl9IC8+XHJcbiAgICAgIDwvc2VjdGlvbj59XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvb2tpbmctZGV0YWlsLWdyaWRcIj5cclxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJib29raW5nLWRldGFpbC1wYW5lbFwiPjxoMz57dCgnYm9va2luZy5jdXN0b21lcicpfTwvaDM+PGRsIGNsYXNzTmFtZT1cImJvb2tpbmctZGV0YWlscy1saXN0XCI+XHJcbiAgICAgICAgICA8ZGl2PjxkdD57dCgnYm9va2luZy5jdXN0b21lck5hbWUnKX08L2R0PjxkZD57Ym9va2luZy5jdXN0b21lck5hbWUgPz8gJ+KAlCd9PC9kZD48L2Rpdj5cclxuICAgICAgICAgIDxkaXY+PGR0Pnt0KCdib29raW5nLmN1c3RvbWVyUGhvbmUnKX08L2R0PjxkZD57Ym9va2luZy5jdXN0b21lclBob25lID8gZm9ybWF0S2VueWFuUGhvbmUoYm9va2luZy5jdXN0b21lclBob25lKSA6ICfigJQnfTwvZGQ+PC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PjxkdD57dCgnYm9va2luZy5waWNrdXBBdCcpfTwvZHQ+PGRkPntmb3JtYXRFYXQoYm9va2luZy5waWNrdXBBdCl9PC9kZD48L2Rpdj5cclxuICAgICAgICAgIDxkaXY+PGR0Pnt0KCdib29raW5nLnJldHVybkF0Jyl9PC9kdD48ZGQ+e2Zvcm1hdEVhdChib29raW5nLnJldHVybkF0KX08L2RkPjwvZGl2PlxyXG4gICAgICAgIDwvZGw+PC9zZWN0aW9uPlxyXG5cclxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJib29raW5nLWRldGFpbC1wYW5lbFwiPjxoMz57dCgnYm9va2luZy52ZWhpY2xlJyl9PC9oMz48ZGwgY2xhc3NOYW1lPVwiYm9va2luZy1kZXRhaWxzLWxpc3RcIj5cclxuICAgICAgICAgIDxkaXY+PGR0Pnt0KCdib29raW5nLnZlaGljbGUnKX08L2R0PjxkZD57dmVoaWNsZSA/IGAke3ZlaGljbGUubWFrZX0gJHt2ZWhpY2xlLm1vZGVsfWAgOiBib29raW5nLnZlaGljbGVJZH08L2RkPjwvZGl2PlxyXG4gICAgICAgICAgPGRpdj48ZHQ+e3QoJ2Jvb2tpbmcucmVmZXJlbmNlJyl9PC9kdD48ZGQ+e3ZlaGljbGU/LnJlZ2lzdHJhdGlvbiA/PyAn4oCUJ308L2RkPjwvZGl2PlxyXG4gICAgICAgICAgPGRpdj48ZHQ+e3QoJ2Jvb2tpbmcubW9kZScpfTwvZHQ+PGRkPnt0KGJvb2tpbmcubW9kZSA9PT0gJ2NoYXVmZmV1cicgPyAnYm9va2luZy5jaGF1ZmZldXInIDogJ2Jvb2tpbmcuc2VsZkRyaXZlJyl9PC9kZD48L2Rpdj5cclxuICAgICAgICAgIDxkaXY+PGR0Pnt0KCdib29raW5nLnBheW1lbnQnKX08L2R0PjxkZD57dChgYm9va2luZy4ke2Jvb2tpbmcucGF5bWVudE1ldGhvZCA9PT0gJ21wZXNhX29ubGluZScgPyAnbXBlc2FPbmxpbmUnIDogYm9va2luZy5wYXltZW50TWV0aG9kID09PSAnbXBlc2FfbWFudWFsJyA/ICdtcGVzYU1hbnVhbCcgOiBib29raW5nLnBheW1lbnRNZXRob2QgPz8gJ2Nhc2gnfWApfTwvZGQ+PC9kaXY+XHJcbiAgICAgICAgPC9kbD48L3NlY3Rpb24+XHJcblxyXG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImJvb2tpbmctZGV0YWlsLXBhbmVsIGJvb2tpbmctZGV0YWlsLXBhbmVsLS13aWRlXCI+PGgzPnt0KCdib29raW5nLnF1b3RlU25hcHNob3QnKX08L2gzPlxyXG4gICAgICAgICAge2Jvb2tpbmcucHJpY2luZ1NuYXBzaG90ID8gPFF1b3RlQnJlYWtkb3duIHF1b3RlPXt7IGN1cnJlbmN5OiAnS0VTJywgcHJpY2luZ1NuYXBzaG90OiBib29raW5nLnByaWNpbmdTbmFwc2hvdCB9fSAvPiA6IDxwPnt0KCdib29raW5nLm5vUXVvdGVTbmFwc2hvdCcpfTwvcD59XHJcbiAgICAgICAgPC9zZWN0aW9uPlxyXG5cclxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJib29raW5nLWRldGFpbC1wYW5lbFwiPjxoMz57dCgnYm9va2luZy5wYXltZW50cycpfTwvaDM+XHJcbiAgICAgICAgICB7Ym9va2luZy5wYXltZW50cz8ubGVuZ3RoID8gPERhdGFUYWJsZSBjb2x1bW5zPXtbXHJcbiAgICAgICAgICAgIHsga2V5OiAnbWV0aG9kJywgaGVhZGVyOiB0KCdib29raW5nLnBheW1lbnQnKSwgcmVuZGVyOiAocGF5bWVudCkgPT4gdChgYm9va2luZy4ke3BheW1lbnQubWV0aG9kID09PSAnbXBlc2Ffb25saW5lJyA/ICdtcGVzYU9ubGluZScgOiBwYXltZW50Lm1ldGhvZCA9PT0gJ21wZXNhX21hbnVhbCcgPyAnbXBlc2FNYW51YWwnIDogcGF5bWVudC5tZXRob2R9YCkgfSxcclxuICAgICAgICAgICAgeyBrZXk6ICdhbW91bnQnLCBoZWFkZXI6IHQoJ2Jvb2tpbmcudG90YWwnKSwgcmVuZGVyOiAocGF5bWVudCkgPT4gZm9ybWF0S2VzKHBheW1lbnQuYW1vdW50S2VzKSB9LFxyXG4gICAgICAgICAgICB7IGtleTogJ3N0YXR1cycsIGhlYWRlcjogdCgnYm9va2luZy5zdGF0dXMnKSwgcmVuZGVyOiAocGF5bWVudCkgPT4gcGF5bWVudC5zdGF0dXMgfSxcclxuICAgICAgICAgIF19IGVtcHR5PXs8PjwvPn0gcm93S2V5PXsocGF5bWVudCkgPT4gcGF5bWVudC5pZH0gcm93cz17Ym9va2luZy5wYXltZW50c30gLz4gOiA8RW1wdHlTdGF0ZSBkZXNjcmlwdGlvbj17dCgnYm9va2luZy5ub1BheW1lbnRzJyl9IHRpdGxlPXt0KCdib29raW5nLnBheW1lbnRzJyl9IC8+fVxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuXHJcbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiYm9va2luZy1kZXRhaWwtcGFuZWxcIj48aDM+e3QoJ2Jvb2tpbmcuZHJpdmVyJyl9PC9oMz48cD57Ym9va2luZy5kcml2ZXI/Lm5hbWUgPz8gJ+KAlCd9PC9wPjwvc2VjdGlvbj5cclxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJib29raW5nLWRldGFpbC1wYW5lbFwiPjxoMz57dCgnYm9va2luZy5pbnNwZWN0aW9ucycpfTwvaDM+XHJcbiAgICAgICAgICB7Ym9va2luZy5pbnNwZWN0aW9ucz8ubGVuZ3RoID8gPHVsIGNsYXNzTmFtZT1cImJvb2tpbmctZXZlbnQtbGlzdFwiPntib29raW5nLmluc3BlY3Rpb25zLm1hcCgoaW5zcGVjdGlvbikgPT4gPGxpIGtleT17aW5zcGVjdGlvbi5pZH0+PGI+e3QoaW5zcGVjdGlvbi50eXBlID09PSAnY2hlY2tfb3V0JyA/ICdib29raW5nLmNoZWNrT3V0JyA6ICdib29raW5nLmNoZWNrSW4nKX08L2I+PHNwYW4+e2luc3BlY3Rpb24ub2RvbWV0ZXJ9IGttPC9zcGFuPjx0aW1lPntmb3JtYXRFYXQoaW5zcGVjdGlvbi5jcmVhdGVkQXQpfTwvdGltZT48L2xpPil9PC91bD4gOiA8RW1wdHlTdGF0ZSBkZXNjcmlwdGlvbj17dCgnYm9va2luZy5ub0luc3BlY3Rpb25zJyl9IHRpdGxlPXt0KCdib29raW5nLmluc3BlY3Rpb25zJyl9IC8+fVxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJib29raW5nLWRldGFpbC1wYW5lbFwiPjxoMz57dCgnYm9va2luZy5ldmVudFRpbWVsaW5lJyl9PC9oMz5cclxuICAgICAgICAgIHtib29raW5nLmV2ZW50cz8ubGVuZ3RoID8gPHVsIGNsYXNzTmFtZT1cImJvb2tpbmctZXZlbnQtbGlzdFwiPntib29raW5nLmV2ZW50cy5tYXAoKGV2ZW50KSA9PiA8bGkga2V5PXtldmVudC5pZH0+PGI+e2V2ZW50LnR5cGV9PC9iPjxzcGFuPntldmVudC5ub3RlfTwvc3Bhbj48c21hbGw+e2V2ZW50LmFjdG9yfTwvc21hbGw+PHRpbWU+e2Zvcm1hdEVhdChldmVudC5jcmVhdGVkQXQpfTwvdGltZT48L2xpPil9PC91bD4gOiA8RW1wdHlTdGF0ZSBkZXNjcmlwdGlvbj17dCgnYm9va2luZy5ub0V2ZW50cycpfSB0aXRsZT17dCgnYm9va2luZy5ldmVudFRpbWVsaW5lJyl9IC8+fVxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJib29raW5nLWRldGFpbC1wYW5lbFwiPjxoMz57dCgnYm9va2luZy5hdWRpdCcpfTwvaDM+XHJcbiAgICAgICAgICB7Ym9va2luZy5hdWRpdEVudHJpZXM/Lmxlbmd0aCA/IDx1bCBjbGFzc05hbWU9XCJib29raW5nLWV2ZW50LWxpc3RcIj57Ym9va2luZy5hdWRpdEVudHJpZXMubWFwKChldmVudCkgPT4gPGxpIGtleT17ZXZlbnQuaWR9PjxiPntldmVudC50eXBlfTwvYj48c3Bhbj57ZXZlbnQubm90ZX08L3NwYW4+PHNtYWxsPntldmVudC5hY3Rvcn08L3NtYWxsPjx0aW1lPntmb3JtYXRFYXQoZXZlbnQuY3JlYXRlZEF0KX08L3RpbWU+PC9saT4pfTwvdWw+IDogPEVtcHR5U3RhdGUgZGVzY3JpcHRpb249e3QoJ2Jvb2tpbmcubm9BdWRpdCcpfSB0aXRsZT17dCgnYm9va2luZy5hdWRpdCcpfSAvPn1cclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7YWN0aW9uRXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwicXVvdGUtY29uZmxpY3RcIiByb2xlPVwiYWxlcnRcIj57dCgnYm9va2luZy5hY3Rpb25FcnJvcicpfTwvcD59XHJcbiAgICAgIHtjYW5jZWxPcGVuICYmIDxkaXYgY2xhc3NOYW1lPVwiYm9va2luZy1jYW5jZWwtY29uZmlybVwiIHJvbGU9XCJncm91cFwiPjxzcGFuPnt0KCdib29raW5nLmNhbmNlbENvbmZpcm0nKX08L3NwYW4+PEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB2b2lkIHVwZGF0ZVN0YXR1cygnY2FuY2VsbGVkJykudGhlbigoKSA9PiB7IHNldENhbmNlbE9wZW4oZmFsc2UpOyBuYXZpZ2F0ZSgnL2FkbWluL2Jvb2tpbmdzJykgfSl9IHZhcmlhbnQ9XCJkYW5nZXJcIj57dCgnYm9va2luZy5jb25maXJtQWN0aW9uJyl9PC9CdXR0b24+PEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRDYW5jZWxPcGVuKGZhbHNlKX0gdmFyaWFudD1cInNlY29uZGFyeVwiPnt0KCdib29raW5nLmJhY2snKX08L0J1dHRvbj48L2Rpdj59XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn0iXX0=
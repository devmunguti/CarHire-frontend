import { r as __toESM, t as __commonJSMin } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=8b23c0c4";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/jsx-runtime-cNwuCTLA.js?v=8b23c0c4";
import { t as require_react } from "/node_modules/.vite/deps/react-4hkZzRew.js?v=8b23c0c4";
// node_modules/dayjs/dayjs.min.js
var require_dayjs_min = /* @__PURE__ */ __commonJSMin(((exports, module, this$1) => {
	(function(t, e) {
		"object" == typeof exports && "undefined" != typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define(e) : (t = "undefined" != typeof globalThis ? globalThis : t || self).dayjs = e();
	})(this$1, (function() {
		"use strict";
		var t = 1e3, e = 6e4, n = 36e5, r = "millisecond", i = "second", s = "minute", u = "hour", a = "day", o = "week", c = "month", f = "quarter", h = "year", d = "date", l = "Invalid Date", $ = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/, y = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g, M = {
			name: "en",
			weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),
			months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"),
			ordinal: function(t) {
				var e = [
					"th",
					"st",
					"nd",
					"rd"
				], n = t % 100;
				return "[" + t + (e[(n - 20) % 10] || e[n] || e[0]) + "]";
			}
		}, m = function(t, e, n) {
			var r = String(t);
			return !r || r.length >= e ? t : "" + Array(e + 1 - r.length).join(n) + t;
		}, v = {
			s: m,
			z: function(t) {
				var e = -t.utcOffset(), n = Math.abs(e), r = Math.floor(n / 60), i = n % 60;
				return (e <= 0 ? "+" : "-") + m(r, 2, "0") + ":" + m(i, 2, "0");
			},
			m: function t(e, n) {
				if (e.date() < n.date()) return -t(n, e);
				var r = 12 * (n.year() - e.year()) + (n.month() - e.month()), i = e.clone().add(r, c), s = n - i < 0, u = e.clone().add(r + (s ? -1 : 1), c);
				return +(-(r + (n - i) / (s ? i - u : u - i)) || 0);
			},
			a: function(t) {
				return t < 0 ? Math.ceil(t) || 0 : Math.floor(t);
			},
			p: function(t) {
				return {
					M: c,
					y: h,
					w: o,
					d: a,
					D: d,
					h: u,
					m: s,
					s: i,
					ms: r,
					Q: f
				}[t] || String(t || "").toLowerCase().replace(/s$/, "");
			},
			u: function(t) {
				return void 0 === t;
			}
		}, g = "en", D = {};
		D[g] = M;
		var p = "$isDayjsObject", S = function(t) {
			return t instanceof _ || !(!t || !t[p]);
		}, w = function t(e, n, r) {
			var i;
			if (!e) return g;
			if ("string" == typeof e) {
				var s = e.toLowerCase();
				D[s] && (i = s), n && (D[s] = n, i = s);
				var u = e.split("-");
				if (!i && u.length > 1) return t(u[0]);
			} else {
				var a = e.name;
				D[a] = e, i = a;
			}
			return !r && i && (g = i), i || !r && g;
		}, O = function(t, e) {
			if (S(t)) return t.clone();
			var n = "object" == typeof e ? e : {};
			return n.date = t, n.args = arguments, new _(n);
		}, b = v;
		b.l = w, b.i = S, b.w = function(t, e) {
			return O(t, {
				locale: e.$L,
				utc: e.$u,
				x: e.$x,
				$offset: e.$offset
			});
		};
		var _ = function() {
			function M(t) {
				this.$L = w(t.locale, null, !0), this.parse(t), this.$x = this.$x || t.x || {}, this[p] = !0;
			}
			var m = M.prototype;
			return m.parse = function(t) {
				this.$d = function(t) {
					var e = t.date, n = t.utc;
					if (null === e) return /* @__PURE__ */ new Date(NaN);
					if (b.u(e)) return /* @__PURE__ */ new Date();
					if (e instanceof Date) return new Date(e);
					if ("string" == typeof e && !/Z$/i.test(e)) {
						var r = e.match($);
						if (r) {
							var i = r[2] - 1 || 0, s = (r[7] || "0").substring(0, 3);
							return n ? new Date(Date.UTC(r[1], i, r[3] || 1, r[4] || 0, r[5] || 0, r[6] || 0, s)) : new Date(r[1], i, r[3] || 1, r[4] || 0, r[5] || 0, r[6] || 0, s);
						}
					}
					return new Date(e);
				}(t), this.init();
			}, m.init = function() {
				var t = this.$d;
				this.$y = t.getFullYear(), this.$M = t.getMonth(), this.$D = t.getDate(), this.$W = t.getDay(), this.$H = t.getHours(), this.$m = t.getMinutes(), this.$s = t.getSeconds(), this.$ms = t.getMilliseconds();
			}, m.$utils = function() {
				return b;
			}, m.isValid = function() {
				return !(this.$d.toString() === l);
			}, m.isSame = function(t, e) {
				var n = O(t);
				return this.startOf(e) <= n && n <= this.endOf(e);
			}, m.isAfter = function(t, e) {
				return O(t) < this.startOf(e);
			}, m.isBefore = function(t, e) {
				return this.endOf(e) < O(t);
			}, m.$g = function(t, e, n) {
				return b.u(t) ? this[e] : this.set(n, t);
			}, m.unix = function() {
				return Math.floor(this.valueOf() / 1e3);
			}, m.valueOf = function() {
				return this.$d.getTime();
			}, m.startOf = function(t, e) {
				var n = this, r = !!b.u(e) || e, f = b.p(t), l = function(t, e) {
					var i = b.w(n.$u ? Date.UTC(n.$y, e, t) : new Date(n.$y, e, t), n);
					return r ? i : i.endOf(a);
				}, $ = function(t, e) {
					return b.w(n.toDate()[t].apply(n.toDate("s"), (r ? [
						0,
						0,
						0,
						0
					] : [
						23,
						59,
						59,
						999
					]).slice(e)), n);
				}, y = this.$W, M = this.$M, m = this.$D, v = "set" + (this.$u ? "UTC" : "");
				switch (f) {
					case h: return r ? l(1, 0) : l(31, 11);
					case c: return r ? l(1, M) : l(0, M + 1);
					case o:
						var g = this.$locale().weekStart || 0, D = (y < g ? y + 7 : y) - g;
						return l(r ? m - D : m + (6 - D), M);
					case a:
					case d: return $(v + "Hours", 0);
					case u: return $(v + "Minutes", 1);
					case s: return $(v + "Seconds", 2);
					case i: return $(v + "Milliseconds", 3);
					default: return this.clone();
				}
			}, m.endOf = function(t) {
				return this.startOf(t, !1);
			}, m.$set = function(t, e) {
				var n, o = b.p(t), f = "set" + (this.$u ? "UTC" : ""), l = (n = {}, n[a] = f + "Date", n[d] = f + "Date", n[c] = f + "Month", n[h] = f + "FullYear", n[u] = f + "Hours", n[s] = f + "Minutes", n[i] = f + "Seconds", n[r] = f + "Milliseconds", n)[o], $ = o === a ? this.$D + (e - this.$W) : e;
				if (o === c || o === h) {
					var y = this.clone().set(d, 1);
					y.$d[l]($), y.init(), this.$d = y.set(d, Math.min(this.$D, y.daysInMonth())).$d;
				} else l && this.$d[l]($);
				return this.init(), this;
			}, m.set = function(t, e) {
				return this.clone().$set(t, e);
			}, m.get = function(t) {
				return this[b.p(t)]();
			}, m.add = function(r, f) {
				var d, l = this;
				r = Number(r);
				var $ = b.p(f), y = function(t) {
					var e = O(l);
					return b.w(e.date(e.date() + Math.round(t * r)), l);
				};
				if ($ === c) return this.set(c, this.$M + r);
				if ($ === h) return this.set(h, this.$y + r);
				if ($ === a) return y(1);
				if ($ === o) return y(7);
				var M = (d = {}, d[s] = e, d[u] = n, d[i] = t, d)[$] || 1, m = this.$d.getTime() + r * M;
				return b.w(m, this);
			}, m.subtract = function(t, e) {
				return this.add(-1 * t, e);
			}, m.format = function(t) {
				var e = this, n = this.$locale();
				if (!this.isValid()) return n.invalidDate || l;
				var r = t || "YYYY-MM-DDTHH:mm:ssZ", i = b.z(this), s = this.$H, u = this.$m, a = this.$M, o = n.weekdays, c = n.months, f = n.meridiem, h = function(t, n, i, s) {
					return t && (t[n] || t(e, r)) || i[n].slice(0, s);
				}, d = function(t) {
					return b.s(s % 12 || 12, t, "0");
				}, $ = f || function(t, e, n) {
					var r = t < 12 ? "AM" : "PM";
					return n ? r.toLowerCase() : r;
				};
				return r.replace(y, (function(t, r) {
					return r || function(t) {
						switch (t) {
							case "YY": return String(e.$y).slice(-2);
							case "YYYY": return b.s(e.$y, 4, "0");
							case "M": return a + 1;
							case "MM": return b.s(a + 1, 2, "0");
							case "MMM": return h(n.monthsShort, a, c, 3);
							case "MMMM": return h(c, a);
							case "D": return e.$D;
							case "DD": return b.s(e.$D, 2, "0");
							case "d": return String(e.$W);
							case "dd": return h(n.weekdaysMin, e.$W, o, 2);
							case "ddd": return h(n.weekdaysShort, e.$W, o, 3);
							case "dddd": return o[e.$W];
							case "H": return String(s);
							case "HH": return b.s(s, 2, "0");
							case "h": return d(1);
							case "hh": return d(2);
							case "a": return $(s, u, !0);
							case "A": return $(s, u, !1);
							case "m": return String(u);
							case "mm": return b.s(u, 2, "0");
							case "s": return String(e.$s);
							case "ss": return b.s(e.$s, 2, "0");
							case "SSS": return b.s(e.$ms, 3, "0");
							case "Z": return i;
						}
						return null;
					}(t) || i.replace(":", "");
				}));
			}, m.utcOffset = function() {
				return 15 * -Math.round(this.$d.getTimezoneOffset() / 15);
			}, m.diff = function(r, d, l) {
				var $, y = this, M = b.p(d), m = O(r), v = (m.utcOffset() - this.utcOffset()) * e, g = this - m, D = function() {
					return b.m(y, m);
				};
				switch (M) {
					case h:
						$ = D() / 12;
						break;
					case c:
						$ = D();
						break;
					case f:
						$ = D() / 3;
						break;
					case o:
						$ = (g - v) / 6048e5;
						break;
					case a:
						$ = (g - v) / 864e5;
						break;
					case u:
						$ = g / n;
						break;
					case s:
						$ = g / e;
						break;
					case i:
						$ = g / t;
						break;
					default: $ = g;
				}
				return l ? $ : b.a($);
			}, m.daysInMonth = function() {
				return this.endOf(c).$D;
			}, m.$locale = function() {
				return D[this.$L];
			}, m.locale = function(t, e) {
				if (!t) return this.$L;
				var n = this.clone(), r = w(t, e, !0);
				return r && (n.$L = r), n;
			}, m.clone = function() {
				return b.w(this.$d, this);
			}, m.toDate = function() {
				return new Date(this.valueOf());
			}, m.toJSON = function() {
				return this.isValid() ? this.toISOString() : null;
			}, m.toISOString = function() {
				return this.$d.toISOString();
			}, m.toString = function() {
				return this.$d.toUTCString();
			}, M;
		}(), k = _.prototype;
		return O.prototype = k, [
			["$ms", r],
			["$s", i],
			["$m", s],
			["$H", u],
			["$W", a],
			["$M", c],
			["$y", h],
			["$D", d]
		].forEach((function(t) {
			k[t[1]] = function(e) {
				return this.$g(e, t[0], t[1]);
			};
		})), O.extend = function(t, e) {
			return t.$i || (t(e, _, O), t.$i = !0), O;
		}, O.locale = w, O.isDayjs = S, O.unix = function(t) {
			return O(1e3 * t);
		}, O.en = D[g], O.Ls = D, O.p = {}, O;
	}));
}));
// node_modules/react-calendar-timeline/dist/react-calendar-timeline.es.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_dayjs_min = /* @__PURE__ */ __toESM(require_dayjs_min());
function Hn(a) {
	let i = 0, s = 0, u = !0;
	for (; a;) !a.offsetParent && a.tagName === "BODY" && a.scrollLeft === 0 && a.scrollTop === 0 && (a = document.scrollingElement || a), i += a.offsetLeft - (u ? 0 : a.scrollLeft) + a.clientLeft, s += a.offsetTop - (u ? 0 : a.scrollTop) + a.clientTop, a = a.offsetParent, u = !1;
	return {
		x: i,
		y: s
	};
}
function Ot(a) {
	if (a === document.body) return {
		scrollLeft: 0,
		scrollTop: 0
	};
	{
		const i = Ot(a.parentNode);
		return {
			scrollLeft: a.scrollLeft + i.scrollLeft,
			scrollTop: a.scrollTop + i.scrollTop
		};
	}
}
function Ct(a) {
	if (a === document.body || !a.offsetParent) return {
		offsetLeft: 0,
		offsetTop: 0
	};
	{
		const i = Ct(a.offsetParent);
		return {
			offsetLeft: a.offsetLeft + i.offsetLeft,
			offsetTop: a.offsetTop + i.offsetTop
		};
	}
}
var Ie = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function rt(a) {
	return a && a.__esModule && Object.prototype.hasOwnProperty.call(a, "default") ? a.default : a;
}
var Et = { exports: {} };
Et.exports;
(function(a, i) {
	(function(s, u) {
		a.exports = u();
	})(Ie, function() {
		function s(t, e) {
			var r = Object.keys(t);
			if (Object.getOwnPropertySymbols) {
				var n = Object.getOwnPropertySymbols(t);
				e && (n = n.filter(function(o) {
					return Object.getOwnPropertyDescriptor(t, o).enumerable;
				})), r.push.apply(r, n);
			}
			return r;
		}
		function u(t) {
			for (var e = 1; e < arguments.length; e++) {
				var r = arguments[e] != null ? arguments[e] : {};
				e % 2 ? s(Object(r), !0).forEach(function(n) {
					S(t, n, r[n]);
				}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r)) : s(Object(r)).forEach(function(n) {
					Object.defineProperty(t, n, Object.getOwnPropertyDescriptor(r, n));
				});
			}
			return t;
		}
		function v(t) {
			return v = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
				return typeof e;
			} : function(e) {
				return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
			}, v(t);
		}
		function f(t, e) {
			if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
		}
		function m(t, e) {
			for (var r = 0; r < e.length; r++) {
				var n = e[r];
				n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(t, O(n.key), n);
			}
		}
		function y(t, e, r) {
			return e && m(t.prototype, e), Object.defineProperty(t, "prototype", { writable: !1 }), t;
		}
		function S(t, e, r) {
			return (e = O(e)) in t ? Object.defineProperty(t, e, {
				value: r,
				enumerable: !0,
				configurable: !0,
				writable: !0
			}) : t[e] = r, t;
		}
		function C(t, e) {
			if (typeof e != "function" && e !== null) throw new TypeError("Super expression must either be null or a function");
			t.prototype = Object.create(e && e.prototype, { constructor: {
				value: t,
				writable: !0,
				configurable: !0
			} }), Object.defineProperty(t, "prototype", { writable: !1 }), e && R(t, e);
		}
		function D(t) {
			return D = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
				return e.__proto__ || Object.getPrototypeOf(e);
			}, D(t);
		}
		function R(t, e) {
			return R = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(r, n) {
				return r.__proto__ = n, r;
			}, R(t, e);
		}
		function T(t) {
			if (t === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
			return t;
		}
		function P(t) {
			var e = function() {
				if (typeof Reflect > "u" || !Reflect.construct || Reflect.construct.sham) return !1;
				if (typeof Proxy == "function") return !0;
				try {
					return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0;
				} catch {
					return !1;
				}
			}();
			return function() {
				var r, n = D(t);
				if (e) {
					var o = D(this).constructor;
					r = Reflect.construct(n, arguments, o);
				} else r = n.apply(this, arguments);
				return function(l, c) {
					if (c && (typeof c == "object" || typeof c == "function")) return c;
					if (c !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
					return T(l);
				}(this, r);
			};
		}
		function _() {
			return _ = typeof Reflect < "u" && Reflect.get ? Reflect.get.bind() : function(t, e, r) {
				var n = function(l, c) {
					for (; !Object.prototype.hasOwnProperty.call(l, c) && (l = D(l)) !== null;);
					return l;
				}(t, e);
				if (n) {
					var o = Object.getOwnPropertyDescriptor(n, e);
					return o.get ? o.get.call(arguments.length < 3 ? t : r) : o.value;
				}
			}, _.apply(this, arguments);
		}
		function O(t) {
			var e = function(r, n) {
				if (typeof r != "object" || r === null) return r;
				var o = r[Symbol.toPrimitive];
				if (o !== void 0) {
					var l = o.call(r, n);
					if (typeof l != "object") return l;
					throw new TypeError("@@toPrimitive must return a primitive value.");
				}
				return String(r);
			}(t, "string");
			return typeof e == "symbol" ? e : e + "";
		}
		var k = function(t) {
			return !(!t || !t.Window) && t instanceof t.Window;
		}, L = void 0, H = void 0;
		function X(t) {
			L = t;
			var e = t.document.createTextNode("");
			e.ownerDocument !== t.document && typeof t.wrap == "function" && t.wrap(e) === e && (t = t.wrap(t)), H = t;
		}
		function B(t) {
			return k(t) ? t : (t.ownerDocument || t).defaultView || H.window;
		}
		typeof window < "u" && window && X(window);
		var V = function(t) {
			return !!t && v(t) === "object";
		}, le = function(t) {
			return typeof t == "function";
		}, w = {
			window: function(t) {
				return t === H || k(t);
			},
			docFrag: function(t) {
				return V(t) && t.nodeType === 11;
			},
			object: V,
			func: le,
			number: function(t) {
				return typeof t == "number";
			},
			bool: function(t) {
				return typeof t == "boolean";
			},
			string: function(t) {
				return typeof t == "string";
			},
			element: function(t) {
				if (!t || v(t) !== "object") return !1;
				var e = B(t) || H;
				return /object|function/.test(typeof Element > "u" ? "undefined" : v(Element)) ? t instanceof Element || t instanceof e.Element : t.nodeType === 1 && typeof t.nodeName == "string";
			},
			plainObject: function(t) {
				return V(t) && !!t.constructor && /function Object\b/.test(t.constructor.toString());
			},
			array: function(t) {
				return V(t) && t.length !== void 0 && le(t.splice);
			}
		};
		function ce(t) {
			var e = t.interaction;
			if (e.prepared.name === "drag") {
				var r = e.prepared.axis;
				r === "x" ? (e.coords.cur.page.y = e.coords.start.page.y, e.coords.cur.client.y = e.coords.start.client.y, e.coords.velocity.client.y = 0, e.coords.velocity.page.y = 0) : r === "y" && (e.coords.cur.page.x = e.coords.start.page.x, e.coords.cur.client.x = e.coords.start.client.x, e.coords.velocity.client.x = 0, e.coords.velocity.page.x = 0);
			}
		}
		function Me(t) {
			var e = t.iEvent, r = t.interaction;
			if (r.prepared.name === "drag") {
				var n = r.prepared.axis;
				if (n === "x" || n === "y") {
					var o = n === "x" ? "y" : "x";
					e.page[o] = r.coords.start.page[o], e.client[o] = r.coords.start.client[o], e.delta[o] = 0;
				}
			}
		}
		var nt = {
			id: "actions/drag",
			install: function(t) {
				var e = t.actions, r = t.Interactable, n = t.defaults;
				r.prototype.draggable = nt.draggable, e.map.drag = nt, e.methodDict.drag = "draggable", n.actions.drag = nt.defaults;
			},
			listeners: {
				"interactions:before-action-move": ce,
				"interactions:action-resume": ce,
				"interactions:action-move": Me,
				"auto-start:check": function(t) {
					var e = t.interaction, r = t.interactable, n = t.buttons, o = r.options.drag;
					if (o && o.enabled && (!e.pointerIsDown || !/mouse|pointer/.test(e.pointerType) || n & r.options.drag.mouseButtons)) return t.action = {
						name: "drag",
						axis: o.lockAxis === "start" ? o.startAxis : o.lockAxis
					}, !1;
				}
			},
			draggable: function(t) {
				return w.object(t) ? (this.options.drag.enabled = t.enabled !== !1, this.setPerAction("drag", t), this.setOnEvents("drag", t), /^(xy|x|y|start)$/.test(t.lockAxis) && (this.options.drag.lockAxis = t.lockAxis), /^(xy|x|y)$/.test(t.startAxis) && (this.options.drag.startAxis = t.startAxis), this) : w.bool(t) ? (this.options.drag.enabled = t, this) : this.options.drag;
			},
			beforeMove: ce,
			move: Me,
			defaults: {
				startAxis: "xy",
				lockAxis: "xy"
			},
			getCursor: function() {
				return "move";
			},
			filterEventType: function(t) {
				return t.search("drag") === 0;
			}
		}, Fr = nt, ne = {
			init: function(t) {
				var e = t;
				ne.document = e.document, ne.DocumentFragment = e.DocumentFragment || Re, ne.SVGElement = e.SVGElement || Re, ne.SVGSVGElement = e.SVGSVGElement || Re, ne.SVGElementInstance = e.SVGElementInstance || Re, ne.Element = e.Element || Re, ne.HTMLElement = e.HTMLElement || ne.Element, ne.Event = e.Event, ne.Touch = e.Touch || Re, ne.PointerEvent = e.PointerEvent || e.MSPointerEvent;
			},
			document: null,
			DocumentFragment: null,
			SVGElement: null,
			SVGSVGElement: null,
			SVGElementInstance: null,
			Element: null,
			HTMLElement: null,
			Event: null,
			Touch: null,
			PointerEvent: null
		};
		function Re() {}
		var Q = ne, ie = {
			init: function(t) {
				var e = Q.Element, r = t.navigator || {};
				ie.supportsTouch = "ontouchstart" in t || w.func(t.DocumentTouch) && Q.document instanceof t.DocumentTouch, ie.supportsPointerEvent = r.pointerEnabled !== !1 && !!Q.PointerEvent, ie.isIOS = /iP(hone|od|ad)/.test(r.platform), ie.isIOS7 = /iP(hone|od|ad)/.test(r.platform) && /OS 7[^\d]/.test(r.appVersion), ie.isIe9 = /MSIE 9/.test(r.userAgent), ie.isOperaMobile = r.appName === "Opera" && ie.supportsTouch && /Presto/.test(r.userAgent), ie.prefixedMatchesSelector = "matches" in e.prototype ? "matches" : "webkitMatchesSelector" in e.prototype ? "webkitMatchesSelector" : "mozMatchesSelector" in e.prototype ? "mozMatchesSelector" : "oMatchesSelector" in e.prototype ? "oMatchesSelector" : "msMatchesSelector", ie.pEventTypes = ie.supportsPointerEvent ? Q.PointerEvent === t.MSPointerEvent ? {
					up: "MSPointerUp",
					down: "MSPointerDown",
					over: "mouseover",
					out: "mouseout",
					move: "MSPointerMove",
					cancel: "MSPointerCancel"
				} : {
					up: "pointerup",
					down: "pointerdown",
					over: "pointerover",
					out: "pointerout",
					move: "pointermove",
					cancel: "pointercancel"
				} : null, ie.wheelEvent = Q.document && "onmousewheel" in Q.document ? "mousewheel" : "wheel";
			},
			supportsTouch: null,
			supportsPointerEvent: null,
			isIOS7: null,
			isIOS: null,
			isIe9: null,
			isOperaMobile: null,
			prefixedMatchesSelector: null,
			pEventTypes: null,
			wheelEvent: null
		}, oe = ie;
		function Se(t, e) {
			if (t.contains) return t.contains(e);
			for (; e;) {
				if (e === t) return !0;
				e = e.parentNode;
			}
			return !1;
		}
		function Ur(t, e) {
			for (; w.element(t);) {
				if (me(t, e)) return t;
				t = pe(t);
			}
			return null;
		}
		function pe(t) {
			var e = t.parentNode;
			if (w.docFrag(e)) {
				for (; (e = e.host) && w.docFrag(e););
				return e;
			}
			return e;
		}
		function me(t, e) {
			return H !== L && (e = e.replace(/\/deep\//g, " ")), t[oe.prefixedMatchesSelector](e);
		}
		var Wt = function(t) {
			return t.parentNode || t.host;
		};
		function Nr(t, e) {
			for (var r, n = [], o = t; (r = Wt(o)) && o !== e && r !== o.ownerDocument;) n.unshift(o), o = r;
			return n;
		}
		function Ft(t, e, r) {
			for (; w.element(t);) {
				if (me(t, e)) return !0;
				if ((t = pe(t)) === r) return me(t, e);
			}
			return !1;
		}
		function Gr(t) {
			return t.correspondingUseElement || t;
		}
		function Ut(t) {
			var e = t instanceof Q.SVGElement ? t.getBoundingClientRect() : t.getClientRects()[0];
			return e && {
				left: e.left,
				right: e.right,
				top: e.top,
				bottom: e.bottom,
				width: e.width || e.right - e.left,
				height: e.height || e.bottom - e.top
			};
		}
		function Nt(t) {
			var e, r = Ut(t);
			if (!oe.isIOS7 && r) {
				var n = {
					x: (e = (e = B(t)) || H).scrollX || e.document.documentElement.scrollLeft,
					y: e.scrollY || e.document.documentElement.scrollTop
				};
				r.left += n.x, r.right += n.x, r.top += n.y, r.bottom += n.y;
			}
			return r;
		}
		function Yr(t) {
			for (var e = []; t;) e.push(t), t = pe(t);
			return e;
		}
		function Kr(t) {
			return !!w.string(t) && (Q.document.querySelector(t), !0);
		}
		function W(t, e) {
			for (var r in e) t[r] = e[r];
			return t;
		}
		function Xr(t, e, r) {
			return t === "parent" ? pe(r) : t === "self" ? e.getRect(r) : Ur(r, t);
		}
		function Ue(t, e, r, n) {
			var o = t;
			return w.string(o) ? o = Xr(o, e, r) : w.func(o) && (o = o.apply(void 0, n)), w.element(o) && (o = Nt(o)), o;
		}
		function it(t) {
			return t && {
				x: "x" in t ? t.x : t.left,
				y: "y" in t ? t.y : t.top
			};
		}
		function Gt(t) {
			return !t || "x" in t && "y" in t || ((t = W({}, t)).x = t.left || 0, t.y = t.top || 0, t.width = t.width || (t.right || 0) - t.x, t.height = t.height || (t.bottom || 0) - t.y), t;
		}
		function ot(t, e, r) {
			t.left && (e.left += r.x), t.right && (e.right += r.x), t.top && (e.top += r.y), t.bottom && (e.bottom += r.y), e.width = e.right - e.left, e.height = e.bottom - e.top;
		}
		function Ne(t, e, r) {
			var n = r && t.options[r];
			return it(Ue(n && n.origin || t.options.origin, t, e, [t && e])) || {
				x: 0,
				y: 0
			};
		}
		function Oe(t, e) {
			var r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : function(h) {
				return !0;
			}, n = arguments.length > 3 ? arguments[3] : void 0;
			if (n = n || {}, w.string(t) && t.search(" ") !== -1 && (t = Br(t)), w.array(t)) return t.forEach(function(h) {
				return Oe(h, e, r, n);
			}), n;
			if (w.object(t) && (e = t, t = ""), w.func(e) && r(t)) n[t] = n[t] || [], n[t].push(e);
			else if (w.array(e)) for (var o = 0, l = e; o < l.length; o++) {
				var c = l[o];
				Oe(t, c, r, n);
			}
			else if (w.object(e)) for (var p in e) Oe(Br(p).map(function(h) {
				return "".concat(t).concat(h);
			}), e[p], r, n);
			return n;
		}
		function Br(t) {
			return t.trim().split(/ +/);
		}
		var Ge = function(t, e) {
			return Math.sqrt(t * t + e * e);
		}, so = ["webkit", "moz"];
		function st(t, e) {
			t.__set || (t.__set = {});
			var r = function(o) {
				if (so.some(function(l) {
					return o.indexOf(l) === 0;
				})) return 1;
				typeof t[o] != "function" && o !== "__set" && Object.defineProperty(t, o, {
					get: function() {
						return o in t.__set ? t.__set[o] : t.__set[o] = e[o];
					},
					set: function(l) {
						t.__set[o] = l;
					},
					configurable: !0
				});
			};
			for (var n in e) r(n);
			return t;
		}
		function at(t, e) {
			t.page = t.page || {}, t.page.x = e.page.x, t.page.y = e.page.y, t.client = t.client || {}, t.client.x = e.client.x, t.client.y = e.client.y, t.timeStamp = e.timeStamp;
		}
		function Vr(t) {
			t.page.x = 0, t.page.y = 0, t.client.x = 0, t.client.y = 0;
		}
		function qr(t) {
			return t instanceof Q.Event || t instanceof Q.Touch;
		}
		function lt(t, e, r) {
			return t = t || "page", (r = r || {}).x = e[t + "X"], r.y = e[t + "Y"], r;
		}
		function Zr(t, e) {
			return e = e || {
				x: 0,
				y: 0
			}, oe.isOperaMobile && qr(t) ? (lt("screen", t, e), e.x += window.scrollX, e.y += window.scrollY) : lt("page", t, e), e;
		}
		function Ye(t) {
			return w.number(t.pointerId) ? t.pointerId : t.identifier;
		}
		function ao(t, e, r) {
			var n = e.length > 1 ? Jr(e) : e[0];
			Zr(n, t.page), function(o, l) {
				l = l || {}, oe.isOperaMobile && qr(o) ? lt("screen", o, l) : lt("client", o, l);
			}(n, t.client), t.timeStamp = r;
		}
		function Yt(t) {
			var e = [];
			return w.array(t) ? (e[0] = t[0], e[1] = t[1]) : t.type === "touchend" ? t.touches.length === 1 ? (e[0] = t.touches[0], e[1] = t.changedTouches[0]) : t.touches.length === 0 && (e[0] = t.changedTouches[0], e[1] = t.changedTouches[1]) : (e[0] = t.touches[0], e[1] = t.touches[1]), e;
		}
		function Jr(t) {
			for (var e = {
				pageX: 0,
				pageY: 0,
				clientX: 0,
				clientY: 0,
				screenX: 0,
				screenY: 0
			}, r = 0; r < t.length; r++) {
				var n = t[r];
				for (var o in e) e[o] += n[o];
			}
			for (var l in e) e[l] /= t.length;
			return e;
		}
		function Kt(t) {
			if (!t.length) return null;
			var e = Yt(t), r = Math.min(e[0].pageX, e[1].pageX), n = Math.min(e[0].pageY, e[1].pageY), o = Math.max(e[0].pageX, e[1].pageX), l = Math.max(e[0].pageY, e[1].pageY);
			return {
				x: r,
				y: n,
				left: r,
				top: n,
				right: o,
				bottom: l,
				width: o - r,
				height: l - n
			};
		}
		function Xt(t, e) {
			var r = e + "X", n = e + "Y", o = Yt(t);
			return Ge(o[0][r] - o[1][r], o[0][n] - o[1][n]);
		}
		function Bt(t, e) {
			var r = e + "X", n = e + "Y", o = Yt(t), l = o[1][r] - o[0][r], c = o[1][n] - o[0][n];
			return 180 * Math.atan2(c, l) / Math.PI;
		}
		function Qr(t) {
			return w.string(t.pointerType) ? t.pointerType : w.number(t.pointerType) ? [
				void 0,
				void 0,
				"touch",
				"pen",
				"mouse"
			][t.pointerType] : /touch/.test(t.type || "") || t instanceof Q.Touch ? "touch" : "mouse";
		}
		function en(t) {
			var e = w.func(t.composedPath) ? t.composedPath() : t.path;
			return [Gr(e ? e[0] : t.target), Gr(t.currentTarget)];
		}
		var ct = function() {
			function t(e) {
				f(this, t), this.immediatePropagationStopped = !1, this.propagationStopped = !1, this._interaction = e;
			}
			return y(t, [
				{
					key: "preventDefault",
					value: function() {}
				},
				{
					key: "stopPropagation",
					value: function() {
						this.propagationStopped = !0;
					}
				},
				{
					key: "stopImmediatePropagation",
					value: function() {
						this.immediatePropagationStopped = this.propagationStopped = !0;
					}
				}
			]), t;
		}();
		Object.defineProperty(ct.prototype, "interaction", {
			get: function() {
				return this._interaction._proxy;
			},
			set: function() {}
		});
		var tn = function(t, e) {
			for (var r = 0; r < e.length; r++) {
				var n = e[r];
				t.push(n);
			}
			return t;
		}, rn = function(t) {
			return tn([], t);
		}, Ke = function(t, e) {
			for (var r = 0; r < t.length; r++) if (e(t[r], r, t)) return r;
			return -1;
		}, Xe = function(t, e) {
			return t[Ke(t, e)];
		}, De = function(t) {
			C(r, t);
			var e = P(r);
			function r(n, o, l) {
				var c;
				f(this, r), (c = e.call(this, o._interaction)).dropzone = void 0, c.dragEvent = void 0, c.relatedTarget = void 0, c.draggable = void 0, c.propagationStopped = !1, c.immediatePropagationStopped = !1;
				var p = l === "dragleave" ? n.prev : n.cur, h = p.element, g = p.dropzone;
				return c.type = l, c.target = h, c.currentTarget = h, c.dropzone = g, c.dragEvent = o, c.relatedTarget = o.target, c.draggable = o.interactable, c.timeStamp = o.timeStamp, c;
			}
			return y(r, [
				{
					key: "reject",
					value: function() {
						var n = this, o = this._interaction.dropState;
						if (this.type === "dropactivate" || this.dropzone && o.cur.dropzone === this.dropzone && o.cur.element === this.target) if (o.prev.dropzone = this.dropzone, o.prev.element = this.target, o.rejected = !0, o.events.enter = null, this.stopImmediatePropagation(), this.type === "dropactivate") {
							var l = o.activeDrops, c = Ke(l, function(h) {
								var g = h.dropzone, d = h.element;
								return g === n.dropzone && d === n.target;
							});
							o.activeDrops.splice(c, 1);
							var p = new r(o, this.dragEvent, "dropdeactivate");
							p.dropzone = this.dropzone, p.target = this.target, this.dropzone.fire(p);
						} else this.dropzone.fire(new r(o, this.dragEvent, "dragleave"));
					}
				},
				{
					key: "preventDefault",
					value: function() {}
				},
				{
					key: "stopPropagation",
					value: function() {
						this.propagationStopped = !0;
					}
				},
				{
					key: "stopImmediatePropagation",
					value: function() {
						this.immediatePropagationStopped = this.propagationStopped = !0;
					}
				}
			]), r;
		}(ct);
		function nn(t, e) {
			for (var r = 0, n = t.slice(); r < n.length; r++) {
				var o = n[r], l = o.dropzone, c = o.element;
				e.dropzone = l, e.target = c, l.fire(e), e.propagationStopped = e.immediatePropagationStopped = !1;
			}
		}
		function Vt(t, e) {
			for (var r = function(l, c) {
				for (var p = [], h = 0, g = l.interactables.list; h < g.length; h++) {
					var d = g[h];
					if (d.options.drop.enabled) {
						var b = d.options.drop.accept;
						if (!(w.element(b) && b !== c || w.string(b) && !me(c, b) || w.func(b) && !b({
							dropzone: d,
							draggableElement: c
						}))) for (var x = 0, I = d.getAllElements(); x < I.length; x++) {
							var E = I[x];
							E !== c && p.push({
								dropzone: d,
								element: E,
								rect: d.getRect(E)
							});
						}
					}
				}
				return p;
			}(t, e), n = 0; n < r.length; n++) {
				var o = r[n];
				o.rect = o.dropzone.getRect(o.element);
			}
			return r;
		}
		function on(t, e, r) {
			for (var n = t.dropState, o = t.interactable, l = t.element, c = [], p = 0, h = n.activeDrops; p < h.length; p++) {
				var g = h[p], d = g.dropzone, b = g.element, x = g.rect, I = d.dropCheck(e, r, o, l, b, x);
				c.push(I ? b : null);
			}
			var E = function(M) {
				for (var $, z, A, N = [], K = 0; K < M.length; K++) {
					var F = M[K], G = M[$];
					if (F && K !== $) if (G) {
						var te = Wt(F), J = Wt(G);
						if (te !== F.ownerDocument) if (J !== F.ownerDocument) if (te !== J) {
							N = N.length ? N : Nr(G);
							var re = void 0;
							if (G instanceof Q.HTMLElement && F instanceof Q.SVGElement && !(F instanceof Q.SVGSVGElement)) {
								if (F === J) continue;
								re = F.ownerSVGElement;
							} else re = F;
							for (var se = Nr(re, G.ownerDocument), fe = 0; se[fe] && se[fe] === N[fe];) fe++;
							var bt = [
								se[fe - 1],
								se[fe],
								N[fe]
							];
							if (bt[0]) for (var Qe = bt[0].lastChild; Qe;) {
								if (Qe === bt[1]) {
									$ = K, N = se;
									break;
								}
								if (Qe === bt[2]) break;
								Qe = Qe.previousSibling;
							}
						} else A = G, (parseInt(B(z = F).getComputedStyle(z).zIndex, 10) || 0) >= (parseInt(B(A).getComputedStyle(A).zIndex, 10) || 0) && ($ = K);
						else $ = K;
					} else $ = K;
				}
				return $;
			}(c);
			return n.activeDrops[E] || null;
		}
		function qt(t, e, r) {
			var n = t.dropState, o = {
				enter: null,
				leave: null,
				activate: null,
				deactivate: null,
				move: null,
				drop: null
			};
			return r.type === "dragstart" && (o.activate = new De(n, r, "dropactivate"), o.activate.target = null, o.activate.dropzone = null), r.type === "dragend" && (o.deactivate = new De(n, r, "dropdeactivate"), o.deactivate.target = null, o.deactivate.dropzone = null), n.rejected || (n.cur.element !== n.prev.element && (n.prev.dropzone && (o.leave = new De(n, r, "dragleave"), r.dragLeave = o.leave.target = n.prev.element, r.prevDropzone = o.leave.dropzone = n.prev.dropzone), n.cur.dropzone && (o.enter = new De(n, r, "dragenter"), r.dragEnter = n.cur.element, r.dropzone = n.cur.dropzone)), r.type === "dragend" && n.cur.dropzone && (o.drop = new De(n, r, "drop"), r.dropzone = n.cur.dropzone, r.relatedTarget = n.cur.element), r.type === "dragmove" && n.cur.dropzone && (o.move = new De(n, r, "dropmove"), r.dropzone = n.cur.dropzone)), o;
		}
		function Zt(t, e) {
			var r = t.dropState, n = r.activeDrops, o = r.cur, l = r.prev;
			e.leave && l.dropzone.fire(e.leave), e.enter && o.dropzone.fire(e.enter), e.move && o.dropzone.fire(e.move), e.drop && o.dropzone.fire(e.drop), e.deactivate && nn(n, e.deactivate), r.prev.dropzone = o.dropzone, r.prev.element = o.element;
		}
		function sn(t, e) {
			var r = t.interaction, n = t.iEvent, o = t.event;
			if (n.type === "dragmove" || n.type === "dragend") {
				var l = r.dropState;
				e.dynamicDrop && (l.activeDrops = Vt(e, r.element));
				var c = n, p = on(r, c, o);
				l.rejected = l.rejected && !!p && p.dropzone === l.cur.dropzone && p.element === l.cur.element, l.cur.dropzone = p && p.dropzone, l.cur.element = p && p.element, l.events = qt(r, 0, c);
			}
		}
		var an = {
			id: "actions/drop",
			install: function(t) {
				var e = t.actions, r = t.interactStatic, n = t.Interactable, o = t.defaults;
				t.usePlugin(Fr), n.prototype.dropzone = function(l) {
					return function(c, p) {
						if (w.object(p)) {
							if (c.options.drop.enabled = p.enabled !== !1, p.listeners) {
								var h = Oe(p.listeners), g = Object.keys(h).reduce(function(b, x) {
									return b[/^(enter|leave)/.test(x) ? "drag".concat(x) : /^(activate|deactivate|move)/.test(x) ? "drop".concat(x) : x] = h[x], b;
								}, {}), d = c.options.drop.listeners;
								d && c.off(d), c.on(g), c.options.drop.listeners = g;
							}
							return w.func(p.ondrop) && c.on("drop", p.ondrop), w.func(p.ondropactivate) && c.on("dropactivate", p.ondropactivate), w.func(p.ondropdeactivate) && c.on("dropdeactivate", p.ondropdeactivate), w.func(p.ondragenter) && c.on("dragenter", p.ondragenter), w.func(p.ondragleave) && c.on("dragleave", p.ondragleave), w.func(p.ondropmove) && c.on("dropmove", p.ondropmove), /^(pointer|center)$/.test(p.overlap) ? c.options.drop.overlap = p.overlap : w.number(p.overlap) && (c.options.drop.overlap = Math.max(Math.min(1, p.overlap), 0)), "accept" in p && (c.options.drop.accept = p.accept), "checker" in p && (c.options.drop.checker = p.checker), c;
						}
						return w.bool(p) ? (c.options.drop.enabled = p, c) : c.options.drop;
					}(this, l);
				}, n.prototype.dropCheck = function(l, c, p, h, g, d) {
					return function(b, x, I, E, M, $, z) {
						var A = !1;
						if (!(z = z || b.getRect($))) return !!b.options.drop.checker && b.options.drop.checker(x, I, A, b, $, E, M);
						var N = b.options.drop.overlap;
						if (N === "pointer") {
							var K = Ne(E, M, "drag"), F = Zr(x);
							F.x += K.x, F.y += K.y;
							var G = F.x > z.left && F.x < z.right, te = F.y > z.top && F.y < z.bottom;
							A = G && te;
						}
						var J = E.getRect(M);
						if (J && N === "center") {
							var re = J.left + J.width / 2, se = J.top + J.height / 2;
							A = re >= z.left && re <= z.right && se >= z.top && se <= z.bottom;
						}
						return J && w.number(N) && (A = Math.max(0, Math.min(z.right, J.right) - Math.max(z.left, J.left)) * Math.max(0, Math.min(z.bottom, J.bottom) - Math.max(z.top, J.top)) / (J.width * J.height) >= N), b.options.drop.checker && (A = b.options.drop.checker(x, I, A, b, $, E, M)), A;
					}(this, l, c, p, h, g, d);
				}, r.dynamicDrop = function(l) {
					return w.bool(l) ? (t.dynamicDrop = l, r) : t.dynamicDrop;
				}, W(e.phaselessTypes, {
					dragenter: !0,
					dragleave: !0,
					dropactivate: !0,
					dropdeactivate: !0,
					dropmove: !0,
					drop: !0
				}), e.methodDict.drop = "dropzone", t.dynamicDrop = !1, o.actions.drop = an.defaults;
			},
			listeners: {
				"interactions:before-action-start": function(t) {
					var e = t.interaction;
					e.prepared.name === "drag" && (e.dropState = {
						cur: {
							dropzone: null,
							element: null
						},
						prev: {
							dropzone: null,
							element: null
						},
						rejected: null,
						events: null,
						activeDrops: []
					});
				},
				"interactions:after-action-start": function(t, e) {
					var r = t.interaction, n = (t.event, t.iEvent);
					if (r.prepared.name === "drag") {
						var o = r.dropState;
						o.activeDrops = [], o.events = {}, o.activeDrops = Vt(e, r.element), o.events = qt(r, 0, n), o.events.activate && (nn(o.activeDrops, o.events.activate), e.fire("actions/drop:start", {
							interaction: r,
							dragEvent: n
						}));
					}
				},
				"interactions:action-move": sn,
				"interactions:after-action-move": function(t, e) {
					var r = t.interaction, n = t.iEvent;
					if (r.prepared.name === "drag") {
						var o = r.dropState;
						Zt(r, o.events), e.fire("actions/drop:move", {
							interaction: r,
							dragEvent: n
						}), o.events = {};
					}
				},
				"interactions:action-end": function(t, e) {
					if (t.interaction.prepared.name === "drag") {
						var r = t.interaction, n = t.iEvent;
						sn(t, e), Zt(r, r.dropState.events), e.fire("actions/drop:end", {
							interaction: r,
							dragEvent: n
						});
					}
				},
				"interactions:stop": function(t) {
					var e = t.interaction;
					if (e.prepared.name === "drag") {
						var r = e.dropState;
						r && (r.activeDrops = null, r.events = null, r.cur.dropzone = null, r.cur.element = null, r.prev.dropzone = null, r.prev.element = null, r.rejected = !1);
					}
				}
			},
			getActiveDrops: Vt,
			getDrop: on,
			getDropEvents: qt,
			fireDropEvents: Zt,
			filterEventType: function(t) {
				return t.search("drag") === 0 || t.search("drop") === 0;
			},
			defaults: {
				enabled: !1,
				accept: null,
				overlap: "pointer"
			}
		}, lo = an;
		function Jt(t) {
			var e = t.interaction, r = t.iEvent, n = t.phase;
			if (e.prepared.name === "gesture") {
				var o = e.pointers.map(function(g) {
					return g.pointer;
				}), l = n === "start", c = n === "end", p = e.interactable.options.deltaSource;
				if (r.touches = [o[0], o[1]], l) r.distance = Xt(o, p), r.box = Kt(o), r.scale = 1, r.ds = 0, r.angle = Bt(o, p), r.da = 0, e.gesture.startDistance = r.distance, e.gesture.startAngle = r.angle;
				else if (c || e.pointers.length < 2) {
					var h = e.prevEvent;
					r.distance = h.distance, r.box = h.box, r.scale = h.scale, r.ds = 0, r.angle = h.angle, r.da = 0;
				} else r.distance = Xt(o, p), r.box = Kt(o), r.scale = r.distance / e.gesture.startDistance, r.angle = Bt(o, p), r.ds = r.scale - e.gesture.scale, r.da = r.angle - e.gesture.angle;
				e.gesture.distance = r.distance, e.gesture.angle = r.angle, w.number(r.scale) && r.scale !== 1 / 0 && !isNaN(r.scale) && (e.gesture.scale = r.scale);
			}
		}
		var Qt = {
			id: "actions/gesture",
			before: ["actions/drag", "actions/resize"],
			install: function(t) {
				var e = t.actions, r = t.Interactable, n = t.defaults;
				r.prototype.gesturable = function(o) {
					return w.object(o) ? (this.options.gesture.enabled = o.enabled !== !1, this.setPerAction("gesture", o), this.setOnEvents("gesture", o), this) : w.bool(o) ? (this.options.gesture.enabled = o, this) : this.options.gesture;
				}, e.map.gesture = Qt, e.methodDict.gesture = "gesturable", n.actions.gesture = Qt.defaults;
			},
			listeners: {
				"interactions:action-start": Jt,
				"interactions:action-move": Jt,
				"interactions:action-end": Jt,
				"interactions:new": function(t) {
					t.interaction.gesture = {
						angle: 0,
						distance: 0,
						scale: 1,
						startAngle: 0,
						startDistance: 0
					};
				},
				"auto-start:check": function(t) {
					if (!(t.interaction.pointers.length < 2)) {
						var e = t.interactable.options.gesture;
						if (e && e.enabled) return t.action = { name: "gesture" }, !1;
					}
				}
			},
			defaults: {},
			getCursor: function() {
				return "";
			},
			filterEventType: function(t) {
				return t.search("gesture") === 0;
			}
		}, co = Qt;
		function uo(t, e, r, n, o, l, c) {
			if (!e) return !1;
			if (e === !0) {
				var p = w.number(l.width) ? l.width : l.right - l.left, h = w.number(l.height) ? l.height : l.bottom - l.top;
				if (c = Math.min(c, Math.abs((t === "left" || t === "right" ? p : h) / 2)), p < 0 && (t === "left" ? t = "right" : t === "right" && (t = "left")), h < 0 && (t === "top" ? t = "bottom" : t === "bottom" && (t = "top")), t === "left") {
					var g = p >= 0 ? l.left : l.right;
					return r.x < g + c;
				}
				if (t === "top") {
					var d = h >= 0 ? l.top : l.bottom;
					return r.y < d + c;
				}
				if (t === "right") return r.x > (p >= 0 ? l.right : l.left) - c;
				if (t === "bottom") return r.y > (h >= 0 ? l.bottom : l.top) - c;
			}
			return !!w.element(n) && (w.element(e) ? e === n : Ft(n, e, o));
		}
		function ln(t) {
			var e = t.iEvent, r = t.interaction;
			if (r.prepared.name === "resize" && r.resizeAxes) {
				var n = e;
				r.interactable.options.resize.square ? (r.resizeAxes === "y" ? n.delta.x = n.delta.y : n.delta.y = n.delta.x, n.axes = "xy") : (n.axes = r.resizeAxes, r.resizeAxes === "x" ? n.delta.y = 0 : r.resizeAxes === "y" && (n.delta.x = 0));
			}
		}
		var he, Ce, de = {
			id: "actions/resize",
			before: ["actions/drag"],
			install: function(t) {
				var e = t.actions, r = t.browser, n = t.Interactable, o = t.defaults;
				de.cursors = function(l) {
					return l.isIe9 ? {
						x: "e-resize",
						y: "s-resize",
						xy: "se-resize",
						top: "n-resize",
						left: "w-resize",
						bottom: "s-resize",
						right: "e-resize",
						topleft: "se-resize",
						bottomright: "se-resize",
						topright: "ne-resize",
						bottomleft: "ne-resize"
					} : {
						x: "ew-resize",
						y: "ns-resize",
						xy: "nwse-resize",
						top: "ns-resize",
						left: "ew-resize",
						bottom: "ns-resize",
						right: "ew-resize",
						topleft: "nwse-resize",
						bottomright: "nwse-resize",
						topright: "nesw-resize",
						bottomleft: "nesw-resize"
					};
				}(r), de.defaultMargin = r.supportsTouch || r.supportsPointerEvent ? 20 : 10, n.prototype.resizable = function(l) {
					return function(c, p, h) {
						return w.object(p) ? (c.options.resize.enabled = p.enabled !== !1, c.setPerAction("resize", p), c.setOnEvents("resize", p), w.string(p.axis) && /^x$|^y$|^xy$/.test(p.axis) ? c.options.resize.axis = p.axis : p.axis === null && (c.options.resize.axis = h.defaults.actions.resize.axis), w.bool(p.preserveAspectRatio) ? c.options.resize.preserveAspectRatio = p.preserveAspectRatio : w.bool(p.square) && (c.options.resize.square = p.square), c) : w.bool(p) ? (c.options.resize.enabled = p, c) : c.options.resize;
					}(this, l, t);
				}, e.map.resize = de, e.methodDict.resize = "resizable", o.actions.resize = de.defaults;
			},
			listeners: {
				"interactions:new": function(t) {
					t.interaction.resizeAxes = "xy";
				},
				"interactions:action-start": function(t) {
					(function(e) {
						var r = e.iEvent, n = e.interaction;
						if (n.prepared.name === "resize" && n.prepared.edges) {
							var o = r, l = n.rect;
							n._rects = {
								start: W({}, l),
								corrected: W({}, l),
								previous: W({}, l),
								delta: {
									left: 0,
									right: 0,
									width: 0,
									top: 0,
									bottom: 0,
									height: 0
								}
							}, o.edges = n.prepared.edges, o.rect = n._rects.corrected, o.deltaRect = n._rects.delta;
						}
					})(t), ln(t);
				},
				"interactions:action-move": function(t) {
					(function(e) {
						var r = e.iEvent, n = e.interaction;
						if (n.prepared.name === "resize" && n.prepared.edges) {
							var o = r, l = n.interactable.options.resize.invert, c = l === "reposition" || l === "negate", p = n.rect, h = n._rects, g = h.start, d = h.corrected, b = h.delta, x = h.previous;
							if (W(x, d), c) {
								if (W(d, p), l === "reposition") {
									if (d.top > d.bottom) {
										var I = d.top;
										d.top = d.bottom, d.bottom = I;
									}
									if (d.left > d.right) {
										var E = d.left;
										d.left = d.right, d.right = E;
									}
								}
							} else d.top = Math.min(p.top, g.bottom), d.bottom = Math.max(p.bottom, g.top), d.left = Math.min(p.left, g.right), d.right = Math.max(p.right, g.left);
							for (var M in d.width = d.right - d.left, d.height = d.bottom - d.top, d) b[M] = d[M] - x[M];
							o.edges = n.prepared.edges, o.rect = d, o.deltaRect = b;
						}
					})(t), ln(t);
				},
				"interactions:action-end": function(t) {
					var e = t.iEvent, r = t.interaction;
					if (r.prepared.name === "resize" && r.prepared.edges) {
						var n = e;
						n.edges = r.prepared.edges, n.rect = r._rects.corrected, n.deltaRect = r._rects.delta;
					}
				},
				"auto-start:check": function(t) {
					var e = t.interaction, r = t.interactable, n = t.element, o = t.rect, l = t.buttons;
					if (o) {
						var c = W({}, e.coords.cur.page), p = r.options.resize;
						if (p && p.enabled && (!e.pointerIsDown || !/mouse|pointer/.test(e.pointerType) || l & p.mouseButtons)) {
							if (w.object(p.edges)) {
								var h = {
									left: !1,
									right: !1,
									top: !1,
									bottom: !1
								};
								for (var g in h) h[g] = uo(g, p.edges[g], c, e._latestPointer.eventTarget, n, o, p.margin || de.defaultMargin);
								h.left = h.left && !h.right, h.top = h.top && !h.bottom, (h.left || h.right || h.top || h.bottom) && (t.action = {
									name: "resize",
									edges: h
								});
							} else {
								var d = p.axis !== "y" && c.x > o.right - de.defaultMargin, b = p.axis !== "x" && c.y > o.bottom - de.defaultMargin;
								(d || b) && (t.action = {
									name: "resize",
									axes: (d ? "x" : "") + (b ? "y" : "")
								});
							}
							return !t.action && void 0;
						}
					}
				}
			},
			defaults: {
				square: !1,
				preserveAspectRatio: !1,
				axis: "xy",
				margin: NaN,
				edges: null,
				invert: "none"
			},
			cursors: null,
			getCursor: function(t) {
				var e = t.edges, r = t.axis, n = t.name, o = de.cursors, l = null;
				if (r) l = o[n + r];
				else if (e) {
					for (var c = "", p = 0, h = [
						"top",
						"bottom",
						"left",
						"right"
					]; p < h.length; p++) {
						var g = h[p];
						e[g] && (c += g);
					}
					l = o[c];
				}
				return l;
			},
			filterEventType: function(t) {
				return t.search("resize") === 0;
			},
			defaultMargin: null
		}, po = de, ho = {
			id: "actions",
			install: function(t) {
				t.usePlugin(co), t.usePlugin(po), t.usePlugin(Fr), t.usePlugin(lo);
			}
		}, cn = 0, be = {
			request: function(t) {
				return he(t);
			},
			cancel: function(t) {
				return Ce(t);
			},
			init: function(t) {
				if (he = t.requestAnimationFrame, Ce = t.cancelAnimationFrame, !he) for (var e = [
					"ms",
					"moz",
					"webkit",
					"o"
				], r = 0; r < e.length; r++) {
					var n = e[r];
					he = t["".concat(n, "RequestAnimationFrame")], Ce = t["".concat(n, "CancelAnimationFrame")] || t["".concat(n, "CancelRequestAnimationFrame")];
				}
				he = he && he.bind(t), Ce = Ce && Ce.bind(t), he || (he = function(o) {
					var l = Date.now(), c = Math.max(0, 16 - (l - cn)), p = t.setTimeout(function() {
						o(l + c);
					}, c);
					return cn = l + c, p;
				}, Ce = function(o) {
					return clearTimeout(o);
				});
			}
		}, U = {
			defaults: {
				enabled: !1,
				margin: 60,
				container: null,
				speed: 300
			},
			now: Date.now,
			interaction: null,
			i: 0,
			x: 0,
			y: 0,
			isScrolling: !1,
			prevTime: 0,
			margin: 0,
			speed: 0,
			start: function(t) {
				U.isScrolling = !0, be.cancel(U.i), t.autoScroll = U, U.interaction = t, U.prevTime = U.now(), U.i = be.request(U.scroll);
			},
			stop: function() {
				U.isScrolling = !1, U.interaction && (U.interaction.autoScroll = null), be.cancel(U.i);
			},
			scroll: function() {
				var t = U.interaction, e = t.interactable, r = t.element, n = t.prepared.name, o = e.options[n].autoScroll, l = un(o.container, e, r), c = U.now(), p = (c - U.prevTime) / 1e3, h = o.speed * p;
				if (h >= 1) {
					var g = {
						x: U.x * h,
						y: U.y * h
					};
					if (g.x || g.y) {
						var d = pn(l);
						w.window(l) ? l.scrollBy(g.x, g.y) : l && (l.scrollLeft += g.x, l.scrollTop += g.y);
						var b = pn(l), x = {
							x: b.x - d.x,
							y: b.y - d.y
						};
						(x.x || x.y) && e.fire({
							type: "autoscroll",
							target: r,
							interactable: e,
							delta: x,
							interaction: t,
							container: l
						});
					}
					U.prevTime = c;
				}
				U.isScrolling && (be.cancel(U.i), U.i = be.request(U.scroll));
			},
			check: function(t, e) {
				var r;
				return (r = t.options[e].autoScroll) == null ? void 0 : r.enabled;
			},
			onInteractionMove: function(t) {
				var e = t.interaction, r = t.pointer;
				if (e.interacting() && U.check(e.interactable, e.prepared.name)) if (e.simulation) U.x = U.y = 0;
				else {
					var n, o, l, c, p = e.interactable, h = e.element, g = e.prepared.name, d = p.options[g].autoScroll, b = un(d.container, p, h);
					if (w.window(b)) c = r.clientX < U.margin, n = r.clientY < U.margin, o = r.clientX > b.innerWidth - U.margin, l = r.clientY > b.innerHeight - U.margin;
					else {
						var x = Ut(b);
						c = r.clientX < x.left + U.margin, n = r.clientY < x.top + U.margin, o = r.clientX > x.right - U.margin, l = r.clientY > x.bottom - U.margin;
					}
					U.x = o ? 1 : c ? -1 : 0, U.y = l ? 1 : n ? -1 : 0, U.isScrolling || (U.margin = d.margin, U.speed = d.speed, U.start(e));
				}
			}
		};
		function un(t, e, r) {
			return (w.string(t) ? Xr(t, e, r) : t) || B(r);
		}
		function pn(t) {
			return w.window(t) && (t = window.document.body), {
				x: t.scrollLeft,
				y: t.scrollTop
			};
		}
		var vo = {
			id: "auto-scroll",
			install: function(t) {
				var e = t.defaults, r = t.actions;
				t.autoScroll = U, U.now = function() {
					return t.now();
				}, r.phaselessTypes.autoscroll = !0, e.perAction.autoScroll = U.defaults;
			},
			listeners: {
				"interactions:new": function(t) {
					t.interaction.autoScroll = null;
				},
				"interactions:destroy": function(t) {
					t.interaction.autoScroll = null, U.stop(), U.interaction && (U.interaction = null);
				},
				"interactions:stop": U.stop,
				"interactions:action-move": function(t) {
					return U.onInteractionMove(t);
				}
			}
		};
		function Be(t, e) {
			var r = !1;
			return function() {
				return r || (H.console.warn(e), r = !0), t.apply(this, arguments);
			};
		}
		function er(t, e) {
			return t.name = e.name, t.axis = e.axis, t.edges = e.edges, t;
		}
		function go(t) {
			return w.bool(t) ? (this.options.styleCursor = t, this) : t === null ? (delete this.options.styleCursor, this) : this.options.styleCursor;
		}
		function mo(t) {
			return w.func(t) ? (this.options.actionChecker = t, this) : t === null ? (delete this.options.actionChecker, this) : this.options.actionChecker;
		}
		var bo = {
			id: "auto-start/interactableMethods",
			install: function(t) {
				var e = t.Interactable;
				e.prototype.getAction = function(r, n, o, l) {
					var c = function(p, h, g, d, b) {
						var E = {
							action: null,
							interactable: p,
							interaction: g,
							element: d,
							rect: p.getRect(d),
							buttons: h.buttons || {
								0: 1,
								1: 4,
								3: 8,
								4: 16
							}[h.button]
						};
						return b.fire("auto-start:check", E), E.action;
					}(this, n, o, l, t);
					return this.options.actionChecker ? this.options.actionChecker(r, n, c, this, l, o) : c;
				}, e.prototype.ignoreFrom = Be(function(r) {
					return this._backCompatOption("ignoreFrom", r);
				}, "Interactable.ignoreFrom() has been deprecated. Use Interactble.draggable({ignoreFrom: newValue})."), e.prototype.allowFrom = Be(function(r) {
					return this._backCompatOption("allowFrom", r);
				}, "Interactable.allowFrom() has been deprecated. Use Interactble.draggable({allowFrom: newValue})."), e.prototype.actionChecker = mo, e.prototype.styleCursor = go;
			}
		};
		function hn(t, e, r, n, o) {
			return e.testIgnoreAllow(e.options[t.name], r, n) && e.options[t.name].enabled && ut(e, r, t, o) ? t : null;
		}
		function yo(t, e, r, n, o, l, c) {
			for (var p = 0, h = n.length; p < h; p++) {
				var g = n[p], d = o[p], b = g.getAction(e, r, t, d);
				if (b) {
					var x = hn(b, g, d, l, c);
					if (x) return {
						action: x,
						interactable: g,
						element: d
					};
				}
			}
			return {
				action: null,
				interactable: null,
				element: null
			};
		}
		function dn(t, e, r, n, o) {
			var l = [], c = [], p = n;
			function h(d) {
				l.push(d), c.push(p);
			}
			for (; w.element(p);) {
				l = [], c = [], o.interactables.forEachMatch(p, h);
				var g = yo(t, e, r, l, c, n, o);
				if (g.action && !g.interactable.options[g.action.name].manualStart) return g;
				p = pe(p);
			}
			return {
				action: null,
				interactable: null,
				element: null
			};
		}
		function fn(t, e, r) {
			var n = e.action, o = e.interactable, l = e.element;
			n = n || { name: null }, t.interactable = o, t.element = l, er(t.prepared, n), t.rect = o && n.name ? o.getRect(l) : null, gn(t, r), r.fire("autoStart:prepared", { interaction: t });
		}
		function ut(t, e, r, n) {
			var o = t.options, l = o[r.name].max, c = o[r.name].maxPerElement, p = n.autoStart.maxInteractions, h = 0, g = 0, d = 0;
			if (!(l && c && p)) return !1;
			for (var b = 0, x = n.interactions.list; b < x.length; b++) {
				var I = x[b], E = I.prepared.name;
				if (I.interacting() && (++h >= p || I.interactable === t && ((g += E === r.name ? 1 : 0) >= l || I.element === e && (d++, E === r.name && d >= c)))) return !1;
			}
			return p > 0;
		}
		function vn(t, e) {
			return w.number(t) ? (e.autoStart.maxInteractions = t, this) : e.autoStart.maxInteractions;
		}
		function tr(t, e, r) {
			var n = r.autoStart.cursorElement;
			n && n !== t && (n.style.cursor = ""), t.ownerDocument.documentElement.style.cursor = e, t.style.cursor = e, r.autoStart.cursorElement = e ? t : null;
		}
		function gn(t, e) {
			var r = t.interactable, n = t.element, o = t.prepared;
			if (t.pointerType === "mouse" && r && r.options.styleCursor) {
				var l = "";
				if (o.name) {
					var c = r.options[o.name].cursorChecker;
					l = w.func(c) ? c(o, r, n, t._interacting) : e.actions.map[o.name].getCursor(o);
				}
				tr(t.element, l || "", e);
			} else e.autoStart.cursorElement && tr(e.autoStart.cursorElement, "", e);
		}
		var rr = {
			id: "auto-start/base",
			before: ["actions"],
			install: function(t) {
				var e = t.interactStatic, r = t.defaults;
				t.usePlugin(bo), r.base.actionChecker = null, r.base.styleCursor = !0, W(r.perAction, {
					manualStart: !1,
					max: 1 / 0,
					maxPerElement: 1,
					allowFrom: null,
					ignoreFrom: null,
					mouseButtons: 1
				}), e.maxInteractions = function(n) {
					return vn(n, t);
				}, t.autoStart = {
					maxInteractions: 1 / 0,
					withinInteractionLimit: ut,
					cursorElement: null
				};
			},
			listeners: {
				"interactions:down": function(t, e) {
					var r = t.interaction, n = t.pointer, o = t.event, l = t.eventTarget;
					r.interacting() || fn(r, dn(r, n, o, l, e), e);
				},
				"interactions:move": function(t, e) {
					(function(r, n) {
						var o = r.interaction, l = r.pointer, c = r.event, p = r.eventTarget;
						o.pointerType !== "mouse" || o.pointerIsDown || o.interacting() || fn(o, dn(o, l, c, p, n), n);
					})(t, e), function(r, n) {
						var o = r.interaction;
						if (o.pointerIsDown && !o.interacting() && o.pointerWasMoved && o.prepared.name) {
							n.fire("autoStart:before-start", r);
							var l = o.interactable, c = o.prepared.name;
							c && l && (l.options[c].manualStart || !ut(l, o.element, o.prepared, n) ? o.stop() : (o.start(o.prepared, l, o.element), gn(o, n)));
						}
					}(t, e);
				},
				"interactions:stop": function(t, e) {
					var r = t.interaction, n = r.interactable;
					n && n.options.styleCursor && tr(r.element, "", e);
				}
			},
			maxInteractions: vn,
			withinInteractionLimit: ut,
			validateAction: hn
		}, wo = {
			id: "auto-start/dragAxis",
			listeners: { "autoStart:before-start": function(t, e) {
				var r = t.interaction, n = t.eventTarget, o = t.dx, l = t.dy;
				if (r.prepared.name === "drag") {
					var c = Math.abs(o), p = Math.abs(l), h = r.interactable.options.drag, g = h.startAxis, d = c > p ? "x" : c < p ? "y" : "xy";
					if (r.prepared.axis = h.lockAxis === "start" ? d[0] : h.lockAxis, d !== "xy" && g !== "xy" && g !== d) {
						r.prepared.name = null;
						for (var b = n, x = function(E) {
							if (E !== r.interactable) {
								var M = r.interactable.options.drag;
								if (!M.manualStart && E.testIgnoreAllow(M, b, n)) {
									var $ = E.getAction(r.downPointer, r.downEvent, r, b);
									if ($ && $.name === "drag" && function(z, A) {
										if (!A) return !1;
										var N = A.options.drag.startAxis;
										return z === "xy" || N === "xy" || N === z;
									}(d, E) && rr.validateAction($, E, b, n, e)) return E;
								}
							}
						}; w.element(b);) {
							var I = e.interactables.forEachMatch(b, x);
							if (I) {
								r.prepared.name = "drag", r.interactable = I, r.element = b;
								break;
							}
							b = pe(b);
						}
					}
				}
			} }
		};
		function nr(t) {
			var e = t.prepared && t.prepared.name;
			if (!e) return null;
			var r = t.interactable.options;
			return r[e].hold || r[e].delay;
		}
		var So = {
			id: "auto-start/hold",
			install: function(t) {
				var e = t.defaults;
				t.usePlugin(rr), e.perAction.hold = 0, e.perAction.delay = 0;
			},
			listeners: {
				"interactions:new": function(t) {
					t.interaction.autoStartHoldTimer = null;
				},
				"autoStart:prepared": function(t) {
					var e = t.interaction, r = nr(e);
					r > 0 && (e.autoStartHoldTimer = setTimeout(function() {
						e.start(e.prepared, e.interactable, e.element);
					}, r));
				},
				"interactions:move": function(t) {
					var e = t.interaction, r = t.duplicate;
					e.autoStartHoldTimer && e.pointerWasMoved && !r && (clearTimeout(e.autoStartHoldTimer), e.autoStartHoldTimer = null);
				},
				"autoStart:before-start": function(t) {
					var e = t.interaction;
					nr(e) > 0 && (e.prepared.name = null);
				}
			},
			getHoldDuration: nr
		}, Oo = {
			id: "auto-start",
			install: function(t) {
				t.usePlugin(rr), t.usePlugin(So), t.usePlugin(wo);
			}
		}, Co = function(t) {
			return /^(always|never|auto)$/.test(t) ? (this.options.preventDefault = t, this) : w.bool(t) ? (this.options.preventDefault = t ? "always" : "never", this) : this.options.preventDefault;
		};
		function Eo(t) {
			var e = t.interaction, r = t.event;
			e.interactable && e.interactable.checkAndPreventDefault(r);
		}
		var mn = {
			id: "core/interactablePreventDefault",
			install: function(t) {
				var e = t.Interactable;
				e.prototype.preventDefault = Co, e.prototype.checkAndPreventDefault = function(r) {
					return function(n, o, l) {
						var c = n.options.preventDefault;
						if (c !== "never") if (c !== "always") {
							if (o.events.supportsPassive && /^touch(start|move)$/.test(l.type)) {
								var p = B(l.target).document, h = o.getDocOptions(p);
								if (!h || !h.events || h.events.passive !== !1) return;
							}
							/^(mouse|pointer|touch)*(down|start)/i.test(l.type) || w.element(l.target) && me(l.target, "input,select,textarea,[contenteditable=true],[contenteditable=true] *") || l.preventDefault();
						} else l.preventDefault();
					}(this, t, r);
				}, t.interactions.docEvents.push({
					type: "dragstart",
					listener: function(r) {
						for (var n = 0, o = t.interactions.list; n < o.length; n++) {
							var l = o[n];
							if (l.element && (l.element === r.target || Se(l.element, r.target))) return void l.interactable.checkAndPreventDefault(r);
						}
					}
				});
			},
			listeners: [
				"down",
				"move",
				"up",
				"cancel"
			].reduce(function(t, e) {
				return t["interactions:".concat(e)] = Eo, t;
			}, {})
		};
		function pt(t, e) {
			if (e.phaselessTypes[t]) return !0;
			for (var r in e.map) if (t.indexOf(r) === 0 && t.substr(r.length) in e.phases) return !0;
			return !1;
		}
		function ke(t) {
			var e = {};
			for (var r in t) {
				var n = t[r];
				w.plainObject(n) ? e[r] = ke(n) : w.array(n) ? e[r] = rn(n) : e[r] = n;
			}
			return e;
		}
		var ir = function() {
			function t(e) {
				f(this, t), this.states = [], this.startOffset = {
					left: 0,
					right: 0,
					top: 0,
					bottom: 0
				}, this.startDelta = void 0, this.result = void 0, this.endResult = void 0, this.startEdges = void 0, this.edges = void 0, this.interaction = void 0, this.interaction = e, this.result = ht(), this.edges = {
					left: !1,
					right: !1,
					top: !1,
					bottom: !1
				};
			}
			return y(t, [
				{
					key: "start",
					value: function(e, r) {
						var n, o, l = e.phase, c = this.interaction, p = function(g) {
							var d = g.interactable.options[g.prepared.name], b = d.modifiers;
							return b && b.length ? b : [
								"snap",
								"snapSize",
								"snapEdges",
								"restrict",
								"restrictEdges",
								"restrictSize"
							].map(function(x) {
								var I = d[x];
								return I && I.enabled && {
									options: I,
									methods: I._methods
								};
							}).filter(function(x) {
								return !!x;
							});
						}(c);
						this.prepareStates(p), this.startEdges = W({}, c.edges), this.edges = W({}, this.startEdges), this.startOffset = (n = c.rect, o = r, n ? {
							left: o.x - n.left,
							top: o.y - n.top,
							right: n.right - o.x,
							bottom: n.bottom - o.y
						} : {
							left: 0,
							top: 0,
							right: 0,
							bottom: 0
						}), this.startDelta = {
							x: 0,
							y: 0
						};
						var h = this.fillArg({
							phase: l,
							pageCoords: r,
							preEnd: !1
						});
						return this.result = ht(), this.startAll(h), this.result = this.setAll(h);
					}
				},
				{
					key: "fillArg",
					value: function(e) {
						var r = this.interaction;
						return e.interaction = r, e.interactable = r.interactable, e.element = r.element, e.rect || (e.rect = r.rect), e.edges || (e.edges = this.startEdges), e.startOffset = this.startOffset, e;
					}
				},
				{
					key: "startAll",
					value: function(e) {
						for (var r = 0, n = this.states; r < n.length; r++) {
							var o = n[r];
							o.methods.start && (e.state = o, o.methods.start(e));
						}
					}
				},
				{
					key: "setAll",
					value: function(e) {
						var r = e.phase, n = e.preEnd, o = e.skipModifiers, l = e.rect, c = e.edges;
						e.coords = W({}, e.pageCoords), e.rect = W({}, l), e.edges = W({}, c);
						for (var p = o ? this.states.slice(o) : this.states, h = ht(e.coords, e.rect), g = 0; g < p.length; g++) {
							var d, b = p[g], x = b.options, I = W({}, e.coords), E = null;
							(d = b.methods) != null && d.set && this.shouldDo(x, n, r) && (e.state = b, E = b.methods.set(e), ot(e.edges, e.rect, {
								x: e.coords.x - I.x,
								y: e.coords.y - I.y
							})), h.eventProps.push(E);
						}
						W(this.edges, e.edges), h.delta.x = e.coords.x - e.pageCoords.x, h.delta.y = e.coords.y - e.pageCoords.y, h.rectDelta.left = e.rect.left - l.left, h.rectDelta.right = e.rect.right - l.right, h.rectDelta.top = e.rect.top - l.top, h.rectDelta.bottom = e.rect.bottom - l.bottom;
						var M = this.result.coords, $ = this.result.rect;
						if (M && $) h.changed = h.rect.left !== $.left || h.rect.right !== $.right || h.rect.top !== $.top || h.rect.bottom !== $.bottom || M.x !== h.coords.x || M.y !== h.coords.y;
						return h;
					}
				},
				{
					key: "applyToInteraction",
					value: function(e) {
						var r = this.interaction, n = e.phase, o = r.coords.cur, l = r.coords.start, c = this.result, p = this.startDelta, h = c.delta;
						n === "start" && W(this.startDelta, c.delta);
						for (var g = 0, d = [[l, p], [o, h]]; g < d.length; g++) {
							var b = d[g], x = b[0], I = b[1];
							x.page.x += I.x, x.page.y += I.y, x.client.x += I.x, x.client.y += I.y;
						}
						var E = this.result.rectDelta, M = e.rect || r.rect;
						M.left += E.left, M.right += E.right, M.top += E.top, M.bottom += E.bottom, M.width = M.right - M.left, M.height = M.bottom - M.top;
					}
				},
				{
					key: "setAndApply",
					value: function(e) {
						var r = this.interaction, n = e.phase, o = e.preEnd, l = e.skipModifiers, c = this.setAll(this.fillArg({
							preEnd: o,
							phase: n,
							pageCoords: e.modifiedCoords || r.coords.cur.page
						}));
						if (this.result = c, !c.changed && (!l || l < this.states.length) && r.interacting()) return !1;
						if (e.modifiedCoords) {
							var p = r.coords.cur.page, h = {
								x: e.modifiedCoords.x - p.x,
								y: e.modifiedCoords.y - p.y
							};
							c.coords.x += h.x, c.coords.y += h.y, c.delta.x += h.x, c.delta.y += h.y;
						}
						this.applyToInteraction(e);
					}
				},
				{
					key: "beforeEnd",
					value: function(e) {
						var r = e.interaction, n = e.event, o = this.states;
						if (o && o.length) {
							for (var l = !1, c = 0; c < o.length; c++) {
								var p = o[c];
								e.state = p;
								var h = p.options, g = p.methods, d = g.beforeEnd && g.beforeEnd(e);
								if (d) return this.endResult = d, !1;
								l = l || !l && this.shouldDo(h, !0, e.phase, !0);
							}
							l && r.move({
								event: n,
								preEnd: !0
							});
						}
					}
				},
				{
					key: "stop",
					value: function(e) {
						var r = e.interaction;
						if (this.states && this.states.length) {
							var n = W({
								states: this.states,
								interactable: r.interactable,
								element: r.element,
								rect: null
							}, e);
							this.fillArg(n);
							for (var o = 0, l = this.states; o < l.length; o++) {
								var c = l[o];
								n.state = c, c.methods.stop && c.methods.stop(n);
							}
							this.states = null, this.endResult = null;
						}
					}
				},
				{
					key: "prepareStates",
					value: function(e) {
						this.states = [];
						for (var r = 0; r < e.length; r++) {
							var n = e[r], o = n.options, l = n.methods, c = n.name;
							this.states.push({
								options: o,
								methods: l,
								index: r,
								name: c
							});
						}
						return this.states;
					}
				},
				{
					key: "restoreInteractionCoords",
					value: function(e) {
						var r = e.interaction, n = r.coords, o = r.rect, l = r.modification;
						if (l.result) {
							for (var c = l.startDelta, p = l.result, h = p.delta, g = p.rectDelta, d = 0, b = [[n.start, c], [n.cur, h]]; d < b.length; d++) {
								var x = b[d], I = x[0], E = x[1];
								I.page.x -= E.x, I.page.y -= E.y, I.client.x -= E.x, I.client.y -= E.y;
							}
							o.left -= g.left, o.right -= g.right, o.top -= g.top, o.bottom -= g.bottom;
						}
					}
				},
				{
					key: "shouldDo",
					value: function(e, r, n, o) {
						return !(!e || e.enabled === !1 || o && !e.endOnly || e.endOnly && !r || n === "start" && !e.setStart);
					}
				},
				{
					key: "copyFrom",
					value: function(e) {
						this.startOffset = e.startOffset, this.startDelta = e.startDelta, this.startEdges = e.startEdges, this.edges = e.edges, this.states = e.states.map(function(r) {
							return ke(r);
						}), this.result = ht(W({}, e.result.coords), W({}, e.result.rect));
					}
				},
				{
					key: "destroy",
					value: function() {
						for (var e in this) this[e] = null;
					}
				}
			]), t;
		}();
		function ht(t, e) {
			return {
				rect: e,
				coords: t,
				delta: {
					x: 0,
					y: 0
				},
				rectDelta: {
					left: 0,
					right: 0,
					top: 0,
					bottom: 0
				},
				eventProps: [],
				changed: !0
			};
		}
		function ye(t, e) {
			var r = t.defaults, n = {
				start: t.start,
				set: t.set,
				beforeEnd: t.beforeEnd,
				stop: t.stop
			}, o = function(l) {
				var c = l || {};
				for (var p in c.enabled = c.enabled !== !1, r) p in c || (c[p] = r[p]);
				var h = {
					options: c,
					methods: n,
					name: e,
					enable: function() {
						return c.enabled = !0, h;
					},
					disable: function() {
						return c.enabled = !1, h;
					}
				};
				return h;
			};
			return e && typeof e == "string" && (o._defaults = r, o._methods = n), o;
		}
		function Ve(t) {
			var e = t.iEvent, r = t.interaction.modification.result;
			r && (e.modifiers = r.eventProps);
		}
		var bn = {
			id: "modifiers/base",
			before: ["actions"],
			install: function(t) {
				t.defaults.perAction.modifiers = [];
			},
			listeners: {
				"interactions:new": function(t) {
					var e = t.interaction;
					e.modification = new ir(e);
				},
				"interactions:before-action-start": function(t) {
					var e = t.interaction, r = t.interaction.modification;
					r.start(t, e.coords.start.page), e.edges = r.edges, r.applyToInteraction(t);
				},
				"interactions:before-action-move": function(t) {
					var e = t.interaction, r = e.modification, n = r.setAndApply(t);
					return e.edges = r.edges, n;
				},
				"interactions:before-action-end": function(t) {
					var e = t.interaction, r = e.modification, n = r.beforeEnd(t);
					return e.edges = r.startEdges, n;
				},
				"interactions:action-start": Ve,
				"interactions:action-move": Ve,
				"interactions:action-end": Ve,
				"interactions:after-action-start": function(t) {
					return t.interaction.modification.restoreInteractionCoords(t);
				},
				"interactions:after-action-move": function(t) {
					return t.interaction.modification.restoreInteractionCoords(t);
				},
				"interactions:stop": function(t) {
					return t.interaction.modification.stop(t);
				}
			}
		}, yn = {
			base: {
				preventDefault: "auto",
				deltaSource: "page"
			},
			perAction: {
				enabled: !1,
				origin: {
					x: 0,
					y: 0
				}
			},
			actions: {}
		}, or = function(t) {
			C(r, t);
			var e = P(r);
			function r(n, o, l, c, p, h, g) {
				var d;
				f(this, r), (d = e.call(this, n)).relatedTarget = null, d.screenX = void 0, d.screenY = void 0, d.button = void 0, d.buttons = void 0, d.ctrlKey = void 0, d.shiftKey = void 0, d.altKey = void 0, d.metaKey = void 0, d.page = void 0, d.client = void 0, d.delta = void 0, d.rect = void 0, d.x0 = void 0, d.y0 = void 0, d.t0 = void 0, d.dt = void 0, d.duration = void 0, d.clientX0 = void 0, d.clientY0 = void 0, d.velocity = void 0, d.speed = void 0, d.swipe = void 0, d.axes = void 0, d.preEnd = void 0, p = p || n.element;
				var b = n.interactable, x = (b && b.options || yn).deltaSource, I = Ne(b, p, l), E = c === "start", M = c === "end", $ = E ? T(d) : n.prevEvent, z = E ? n.coords.start : M ? {
					page: $.page,
					client: $.client,
					timeStamp: n.coords.cur.timeStamp
				} : n.coords.cur;
				return d.page = W({}, z.page), d.client = W({}, z.client), d.rect = W({}, n.rect), d.timeStamp = z.timeStamp, M || (d.page.x -= I.x, d.page.y -= I.y, d.client.x -= I.x, d.client.y -= I.y), d.ctrlKey = o.ctrlKey, d.altKey = o.altKey, d.shiftKey = o.shiftKey, d.metaKey = o.metaKey, d.button = o.button, d.buttons = o.buttons, d.target = p, d.currentTarget = p, d.preEnd = h, d.type = g || l + (c || ""), d.interactable = b, d.t0 = E ? n.pointers[n.pointers.length - 1].downTime : $.t0, d.x0 = n.coords.start.page.x - I.x, d.y0 = n.coords.start.page.y - I.y, d.clientX0 = n.coords.start.client.x - I.x, d.clientY0 = n.coords.start.client.y - I.y, d.delta = E || M ? {
					x: 0,
					y: 0
				} : {
					x: d[x].x - $[x].x,
					y: d[x].y - $[x].y
				}, d.dt = n.coords.delta.timeStamp, d.duration = d.timeStamp - d.t0, d.velocity = W({}, n.coords.velocity[x]), d.speed = Ge(d.velocity.x, d.velocity.y), d.swipe = M || c === "inertiastart" ? d.getSwipe() : null, d;
			}
			return y(r, [
				{
					key: "getSwipe",
					value: function() {
						var n = this._interaction;
						if (n.prevEvent.speed < 600 || this.timeStamp - n.prevEvent.timeStamp > 150) return null;
						var o = 180 * Math.atan2(n.prevEvent.velocityY, n.prevEvent.velocityX) / Math.PI;
						o < 0 && (o += 360);
						var l = 112.5 <= o && o < 247.5, c = 202.5 <= o && o < 337.5;
						return {
							up: c,
							down: !c && 22.5 <= o && o < 157.5,
							left: l,
							right: !l && (292.5 <= o || o < 67.5),
							angle: o,
							speed: n.prevEvent.speed,
							velocity: {
								x: n.prevEvent.velocityX,
								y: n.prevEvent.velocityY
							}
						};
					}
				},
				{
					key: "preventDefault",
					value: function() {}
				},
				{
					key: "stopImmediatePropagation",
					value: function() {
						this.immediatePropagationStopped = this.propagationStopped = !0;
					}
				},
				{
					key: "stopPropagation",
					value: function() {
						this.propagationStopped = !0;
					}
				}
			]), r;
		}(ct);
		Object.defineProperties(or.prototype, {
			pageX: {
				get: function() {
					return this.page.x;
				},
				set: function(t) {
					this.page.x = t;
				}
			},
			pageY: {
				get: function() {
					return this.page.y;
				},
				set: function(t) {
					this.page.y = t;
				}
			},
			clientX: {
				get: function() {
					return this.client.x;
				},
				set: function(t) {
					this.client.x = t;
				}
			},
			clientY: {
				get: function() {
					return this.client.y;
				},
				set: function(t) {
					this.client.y = t;
				}
			},
			dx: {
				get: function() {
					return this.delta.x;
				},
				set: function(t) {
					this.delta.x = t;
				}
			},
			dy: {
				get: function() {
					return this.delta.y;
				},
				set: function(t) {
					this.delta.y = t;
				}
			},
			velocityX: {
				get: function() {
					return this.velocity.x;
				},
				set: function(t) {
					this.velocity.x = t;
				}
			},
			velocityY: {
				get: function() {
					return this.velocity.y;
				},
				set: function(t) {
					this.velocity.y = t;
				}
			}
		});
		var Po = y(function t(e, r, n, o, l) {
			f(this, t), this.id = void 0, this.pointer = void 0, this.event = void 0, this.downTime = void 0, this.downTarget = void 0, this.id = e, this.pointer = r, this.event = n, this.downTime = o, this.downTarget = l;
		}), Io = function(t) {
			return t.interactable = "", t.element = "", t.prepared = "", t.pointerIsDown = "", t.pointerWasMoved = "", t._proxy = "", t;
		}({}), Tn = function(t) {
			return t.start = "", t.move = "", t.end = "", t.stop = "", t.interacting = "", t;
		}({}), Mo = 0, Ro = function() {
			function t(e) {
				var r = this, n = e.pointerType, o = e.scopeFire;
				f(this, t), this.interactable = null, this.element = null, this.rect = null, this._rects = void 0, this.edges = null, this._scopeFire = void 0, this.prepared = {
					name: null,
					axis: null,
					edges: null
				}, this.pointerType = void 0, this.pointers = [], this.downEvent = null, this.downPointer = {}, this._latestPointer = {
					pointer: null,
					event: null,
					eventTarget: null
				}, this.prevEvent = null, this.pointerIsDown = !1, this.pointerWasMoved = !1, this._interacting = !1, this._ending = !1, this._stopped = !0, this._proxy = void 0, this.simulation = null, this.doMove = Be(function(d) {
					this.move(d);
				}, "The interaction.doMove() method has been renamed to interaction.move()"), this.coords = {
					start: {
						page: {
							x: 0,
							y: 0
						},
						client: {
							x: 0,
							y: 0
						},
						timeStamp: 0
					},
					prev: {
						page: {
							x: 0,
							y: 0
						},
						client: {
							x: 0,
							y: 0
						},
						timeStamp: 0
					},
					cur: {
						page: {
							x: 0,
							y: 0
						},
						client: {
							x: 0,
							y: 0
						},
						timeStamp: 0
					},
					delta: {
						page: {
							x: 0,
							y: 0
						},
						client: {
							x: 0,
							y: 0
						},
						timeStamp: 0
					},
					velocity: {
						page: {
							x: 0,
							y: 0
						},
						client: {
							x: 0,
							y: 0
						},
						timeStamp: 0
					}
				}, this._id = Mo++, this._scopeFire = o, this.pointerType = n;
				var l = this;
				this._proxy = {};
				var c = function(d) {
					Object.defineProperty(r._proxy, d, { get: function() {
						return l[d];
					} });
				};
				for (var p in Io) c(p);
				var h = function(d) {
					Object.defineProperty(r._proxy, d, { value: function() {
						return l[d].apply(l, arguments);
					} });
				};
				for (var g in Tn) h(g);
				this._scopeFire("interactions:new", { interaction: this });
			}
			return y(t, [
				{
					key: "pointerMoveTolerance",
					get: function() {
						return 1;
					}
				},
				{
					key: "pointerDown",
					value: function(e, r, n) {
						var o = this.updatePointer(e, r, n, !0), l = this.pointers[o];
						this._scopeFire("interactions:down", {
							pointer: e,
							event: r,
							eventTarget: n,
							pointerIndex: o,
							pointerInfo: l,
							type: "down",
							interaction: this
						});
					}
				},
				{
					key: "start",
					value: function(e, r, n) {
						return !(this.interacting() || !this.pointerIsDown || this.pointers.length < (e.name === "gesture" ? 2 : 1) || !r.options[e.name].enabled) && (er(this.prepared, e), this.interactable = r, this.element = n, this.rect = r.getRect(n), this.edges = this.prepared.edges ? W({}, this.prepared.edges) : {
							left: !0,
							right: !0,
							top: !0,
							bottom: !0
						}, this._stopped = !1, this._interacting = this._doPhase({
							interaction: this,
							event: this.downEvent,
							phase: "start"
						}) && !this._stopped, this._interacting);
					}
				},
				{
					key: "pointerMove",
					value: function(e, r, n) {
						this.simulation || this.modification && this.modification.endResult || this.updatePointer(e, r, n, !1);
						var o, l, c = this.coords.cur.page.x === this.coords.prev.page.x && this.coords.cur.page.y === this.coords.prev.page.y && this.coords.cur.client.x === this.coords.prev.client.x && this.coords.cur.client.y === this.coords.prev.client.y;
						this.pointerIsDown && !this.pointerWasMoved && (o = this.coords.cur.client.x - this.coords.start.client.x, l = this.coords.cur.client.y - this.coords.start.client.y, this.pointerWasMoved = Ge(o, l) > this.pointerMoveTolerance);
						var p, h, g, d = this.getPointerIndex(e), b = {
							pointer: e,
							pointerIndex: d,
							pointerInfo: this.pointers[d],
							event: r,
							type: "move",
							eventTarget: n,
							dx: o,
							dy: l,
							duplicate: c,
							interaction: this
						};
						c || (p = this.coords.velocity, h = this.coords.delta, g = Math.max(h.timeStamp / 1e3, .001), p.page.x = h.page.x / g, p.page.y = h.page.y / g, p.client.x = h.client.x / g, p.client.y = h.client.y / g, p.timeStamp = g), this._scopeFire("interactions:move", b), c || this.simulation || (this.interacting() && (b.type = null, this.move(b)), this.pointerWasMoved && at(this.coords.prev, this.coords.cur));
					}
				},
				{
					key: "move",
					value: function(e) {
						e && e.event || Vr(this.coords.delta), (e = W({
							pointer: this._latestPointer.pointer,
							event: this._latestPointer.event,
							eventTarget: this._latestPointer.eventTarget,
							interaction: this
						}, e || {})).phase = "move", this._doPhase(e);
					}
				},
				{
					key: "pointerUp",
					value: function(e, r, n, o) {
						var l = this.getPointerIndex(e);
						l === -1 && (l = this.updatePointer(e, r, n, !1));
						var c = /cancel$/i.test(r.type) ? "cancel" : "up";
						this._scopeFire("interactions:".concat(c), {
							pointer: e,
							pointerIndex: l,
							pointerInfo: this.pointers[l],
							event: r,
							eventTarget: n,
							type: c,
							curEventTarget: o,
							interaction: this
						}), this.simulation || this.end(r), this.removePointer(e, r);
					}
				},
				{
					key: "documentBlur",
					value: function(e) {
						this.end(e), this._scopeFire("interactions:blur", {
							event: e,
							type: "blur",
							interaction: this
						});
					}
				},
				{
					key: "end",
					value: function(e) {
						var r;
						this._ending = !0, e = e || this._latestPointer.event, this.interacting() && (r = this._doPhase({
							event: e,
							interaction: this,
							phase: "end"
						})), this._ending = !1, r === !0 && this.stop();
					}
				},
				{
					key: "currentAction",
					value: function() {
						return this._interacting ? this.prepared.name : null;
					}
				},
				{
					key: "interacting",
					value: function() {
						return this._interacting;
					}
				},
				{
					key: "stop",
					value: function() {
						this._scopeFire("interactions:stop", { interaction: this }), this.interactable = this.element = null, this._interacting = !1, this._stopped = !0, this.prepared.name = this.prevEvent = null;
					}
				},
				{
					key: "getPointerIndex",
					value: function(e) {
						var r = Ye(e);
						return this.pointerType === "mouse" || this.pointerType === "pen" ? this.pointers.length - 1 : Ke(this.pointers, function(n) {
							return n.id === r;
						});
					}
				},
				{
					key: "getPointerInfo",
					value: function(e) {
						return this.pointers[this.getPointerIndex(e)];
					}
				},
				{
					key: "updatePointer",
					value: function(e, r, n, o) {
						var l, c, p, h = Ye(e), g = this.getPointerIndex(e), d = this.pointers[g];
						return o = o !== !1 && (o || /(down|start)$/i.test(r.type)), d ? d.pointer = e : (d = new Po(h, e, r, null, null), g = this.pointers.length, this.pointers.push(d)), ao(this.coords.cur, this.pointers.map(function(b) {
							return b.pointer;
						}), this._now()), l = this.coords.delta, c = this.coords.prev, p = this.coords.cur, l.page.x = p.page.x - c.page.x, l.page.y = p.page.y - c.page.y, l.client.x = p.client.x - c.client.x, l.client.y = p.client.y - c.client.y, l.timeStamp = p.timeStamp - c.timeStamp, o && (this.pointerIsDown = !0, d.downTime = this.coords.cur.timeStamp, d.downTarget = n, st(this.downPointer, e), this.interacting() || (at(this.coords.start, this.coords.cur), at(this.coords.prev, this.coords.cur), this.downEvent = r, this.pointerWasMoved = !1)), this._updateLatestPointer(e, r, n), this._scopeFire("interactions:update-pointer", {
							pointer: e,
							event: r,
							eventTarget: n,
							down: o,
							pointerInfo: d,
							pointerIndex: g,
							interaction: this
						}), g;
					}
				},
				{
					key: "removePointer",
					value: function(e, r) {
						var n = this.getPointerIndex(e);
						if (n !== -1) {
							var o = this.pointers[n];
							this._scopeFire("interactions:remove-pointer", {
								pointer: e,
								event: r,
								eventTarget: null,
								pointerIndex: n,
								pointerInfo: o,
								interaction: this
							}), this.pointers.splice(n, 1), this.pointerIsDown = !1;
						}
					}
				},
				{
					key: "_updateLatestPointer",
					value: function(e, r, n) {
						this._latestPointer.pointer = e, this._latestPointer.event = r, this._latestPointer.eventTarget = n;
					}
				},
				{
					key: "destroy",
					value: function() {
						this._latestPointer.pointer = null, this._latestPointer.event = null, this._latestPointer.eventTarget = null;
					}
				},
				{
					key: "_createPreparedEvent",
					value: function(e, r, n, o) {
						return new or(this, e, this.prepared.name, r, this.element, n, o);
					}
				},
				{
					key: "_fireEvent",
					value: function(e) {
						var r;
						(r = this.interactable) == null || r.fire(e), (!this.prevEvent || e.timeStamp >= this.prevEvent.timeStamp) && (this.prevEvent = e);
					}
				},
				{
					key: "_doPhase",
					value: function(e) {
						var r = e.event, n = e.phase, o = e.preEnd, l = e.type, c = this.rect;
						if (c && n === "move" && (ot(this.edges, c, this.coords.delta[this.interactable.options.deltaSource]), c.width = c.right - c.left, c.height = c.bottom - c.top), this._scopeFire("interactions:before-action-".concat(n), e) === !1) return !1;
						var p = e.iEvent = this._createPreparedEvent(r, n, o, l);
						return this._scopeFire("interactions:action-".concat(n), e), n === "start" && (this.prevEvent = p), this._fireEvent(p), this._scopeFire("interactions:after-action-".concat(n), e), !0;
					}
				},
				{
					key: "_now",
					value: function() {
						return Date.now();
					}
				}
			]), t;
		}();
		function wn(t) {
			xn(t.interaction);
		}
		function xn(t) {
			if (!function(r) {
				return !(!r.offset.pending.x && !r.offset.pending.y);
			}(t)) return !1;
			var e = t.offset.pending;
			return sr(t.coords.cur, e), sr(t.coords.delta, e), ot(t.edges, t.rect, e), e.x = 0, e.y = 0, !0;
		}
		function Do(t) {
			var e = t.x, r = t.y;
			this.offset.pending.x += e, this.offset.pending.y += r, this.offset.total.x += e, this.offset.total.y += r;
		}
		function sr(t, e) {
			var r = t.page, n = t.client, o = e.x, l = e.y;
			r.x += o, r.y += l, n.x += o, n.y += l;
		}
		Tn.offsetBy = "";
		var Sn = {
			id: "offset",
			before: [
				"modifiers",
				"pointer-events",
				"actions",
				"inertia"
			],
			install: function(t) {
				t.Interaction.prototype.offsetBy = Do;
			},
			listeners: {
				"interactions:new": function(t) {
					t.interaction.offset = {
						total: {
							x: 0,
							y: 0
						},
						pending: {
							x: 0,
							y: 0
						}
					};
				},
				"interactions:update-pointer": function(t) {
					return function(e) {
						e.pointerIsDown && (sr(e.coords.cur, e.offset.total), e.offset.pending.x = 0, e.offset.pending.y = 0);
					}(t.interaction);
				},
				"interactions:before-action-start": wn,
				"interactions:before-action-move": wn,
				"interactions:before-action-end": function(t) {
					var e = t.interaction;
					if (xn(e)) return e.move({ offset: !0 }), e.end(), !1;
				},
				"interactions:stop": function(t) {
					var e = t.interaction;
					e.offset.total.x = 0, e.offset.total.y = 0, e.offset.pending.x = 0, e.offset.pending.y = 0;
				}
			}
		}, zo = function() {
			function t(e) {
				f(this, t), this.active = !1, this.isModified = !1, this.smoothEnd = !1, this.allowResume = !1, this.modification = void 0, this.modifierCount = 0, this.modifierArg = void 0, this.startCoords = void 0, this.t0 = 0, this.v0 = 0, this.te = 0, this.targetOffset = void 0, this.modifiedOffset = void 0, this.currentOffset = void 0, this.lambda_v0 = 0, this.one_ve_v0 = 0, this.timeout = void 0, this.interaction = void 0, this.interaction = e;
			}
			return y(t, [
				{
					key: "start",
					value: function(e) {
						var r = this.interaction, n = dt(r);
						if (!n || !n.enabled) return !1;
						var o = r.coords.velocity.client, l = Ge(o.x, o.y), c = this.modification || (this.modification = new ir(r));
						if (c.copyFrom(r.modification), this.t0 = r._now(), this.allowResume = n.allowResume, this.v0 = l, this.currentOffset = {
							x: 0,
							y: 0
						}, this.startCoords = r.coords.cur.page, this.modifierArg = c.fillArg({
							pageCoords: this.startCoords,
							preEnd: !0,
							phase: "inertiastart"
						}), this.t0 - r.coords.cur.timeStamp < 50 && l > n.minSpeed && l > n.endSpeed) this.startInertia();
						else {
							if (c.result = c.setAll(this.modifierArg), !c.result.changed) return !1;
							this.startSmoothEnd();
						}
						return r.modification.result.rect = null, r.offsetBy(this.targetOffset), r._doPhase({
							interaction: r,
							event: e,
							phase: "inertiastart"
						}), r.offsetBy({
							x: -this.targetOffset.x,
							y: -this.targetOffset.y
						}), r.modification.result.rect = null, this.active = !0, r.simulation = this, !0;
					}
				},
				{
					key: "startInertia",
					value: function() {
						var e = this, r = this.interaction.coords.velocity.client, n = dt(this.interaction), o = n.resistance, l = -Math.log(n.endSpeed / this.v0) / o;
						this.targetOffset = {
							x: (r.x - l) / o,
							y: (r.y - l) / o
						}, this.te = l, this.lambda_v0 = o / this.v0, this.one_ve_v0 = 1 - n.endSpeed / this.v0;
						var c = this.modification, p = this.modifierArg;
						p.pageCoords = {
							x: this.startCoords.x + this.targetOffset.x,
							y: this.startCoords.y + this.targetOffset.y
						}, c.result = c.setAll(p), c.result.changed && (this.isModified = !0, this.modifiedOffset = {
							x: this.targetOffset.x + c.result.delta.x,
							y: this.targetOffset.y + c.result.delta.y
						}), this.onNextFrame(function() {
							return e.inertiaTick();
						});
					}
				},
				{
					key: "startSmoothEnd",
					value: function() {
						var e = this;
						this.smoothEnd = !0, this.isModified = !0, this.targetOffset = {
							x: this.modification.result.delta.x,
							y: this.modification.result.delta.y
						}, this.onNextFrame(function() {
							return e.smoothEndTick();
						});
					}
				},
				{
					key: "onNextFrame",
					value: function(e) {
						var r = this;
						this.timeout = be.request(function() {
							r.active && e();
						});
					}
				},
				{
					key: "inertiaTick",
					value: function() {
						var e, r, n, o, l, c, p, h = this, g = this.interaction, d = dt(g).resistance, b = (g._now() - this.t0) / 1e3;
						if (b < this.te) {
							var x, I = 1 - (Math.exp(-d * b) - this.lambda_v0) / this.one_ve_v0;
							this.isModified ? (e = 0, r = 0, n = this.targetOffset.x, o = this.targetOffset.y, l = this.modifiedOffset.x, c = this.modifiedOffset.y, x = {
								x: On(p = I, e, n, l),
								y: On(p, r, o, c)
							}) : x = {
								x: this.targetOffset.x * I,
								y: this.targetOffset.y * I
							};
							var E = {
								x: x.x - this.currentOffset.x,
								y: x.y - this.currentOffset.y
							};
							this.currentOffset.x += E.x, this.currentOffset.y += E.y, g.offsetBy(E), g.move(), this.onNextFrame(function() {
								return h.inertiaTick();
							});
						} else g.offsetBy({
							x: this.modifiedOffset.x - this.currentOffset.x,
							y: this.modifiedOffset.y - this.currentOffset.y
						}), this.end();
					}
				},
				{
					key: "smoothEndTick",
					value: function() {
						var e = this, r = this.interaction, n = r._now() - this.t0, o = dt(r).smoothEndDuration;
						if (n < o) {
							var l = {
								x: Cn(n, 0, this.targetOffset.x, o),
								y: Cn(n, 0, this.targetOffset.y, o)
							}, c = {
								x: l.x - this.currentOffset.x,
								y: l.y - this.currentOffset.y
							};
							this.currentOffset.x += c.x, this.currentOffset.y += c.y, r.offsetBy(c), r.move({ skipModifiers: this.modifierCount }), this.onNextFrame(function() {
								return e.smoothEndTick();
							});
						} else r.offsetBy({
							x: this.targetOffset.x - this.currentOffset.x,
							y: this.targetOffset.y - this.currentOffset.y
						}), this.end();
					}
				},
				{
					key: "resume",
					value: function(e) {
						var r = e.pointer, n = e.event, o = e.eventTarget, l = this.interaction;
						l.offsetBy({
							x: -this.currentOffset.x,
							y: -this.currentOffset.y
						}), l.updatePointer(r, n, o, !0), l._doPhase({
							interaction: l,
							event: n,
							phase: "resume"
						}), at(l.coords.prev, l.coords.cur), this.stop();
					}
				},
				{
					key: "end",
					value: function() {
						this.interaction.move(), this.interaction.end(), this.stop();
					}
				},
				{
					key: "stop",
					value: function() {
						this.active = this.smoothEnd = !1, this.interaction.simulation = null, be.cancel(this.timeout);
					}
				}
			]), t;
		}();
		function dt(t) {
			var e = t.interactable, r = t.prepared;
			return e && e.options && r.name && e.options[r.name].inertia;
		}
		var $o = {
			id: "inertia",
			before: ["modifiers", "actions"],
			install: function(t) {
				var e = t.defaults;
				t.usePlugin(Sn), t.usePlugin(bn), t.actions.phases.inertiastart = !0, t.actions.phases.resume = !0, e.perAction.inertia = {
					enabled: !1,
					resistance: 10,
					minSpeed: 100,
					endSpeed: 10,
					allowResume: !0,
					smoothEndDuration: 300
				};
			},
			listeners: {
				"interactions:new": function(t) {
					var e = t.interaction;
					e.inertia = new zo(e);
				},
				"interactions:before-action-end": function(t) {
					var e = t.interaction, r = t.event;
					return (!e._interacting || e.simulation || !e.inertia.start(r)) && null;
				},
				"interactions:down": function(t) {
					var e = t.interaction, r = t.eventTarget, n = e.inertia;
					if (n.active) for (var o = r; w.element(o);) {
						if (o === e.element) {
							n.resume(t);
							break;
						}
						o = pe(o);
					}
				},
				"interactions:stop": function(t) {
					var e = t.interaction.inertia;
					e.active && e.stop();
				},
				"interactions:before-action-resume": function(t) {
					var e = t.interaction.modification;
					e.stop(t), e.start(t, t.interaction.coords.cur.page), e.applyToInteraction(t);
				},
				"interactions:before-action-inertiastart": function(t) {
					return t.interaction.modification.setAndApply(t);
				},
				"interactions:action-resume": Ve,
				"interactions:action-inertiastart": Ve,
				"interactions:after-action-inertiastart": function(t) {
					return t.interaction.modification.restoreInteractionCoords(t);
				},
				"interactions:after-action-resume": function(t) {
					return t.interaction.modification.restoreInteractionCoords(t);
				}
			}
		};
		function On(t, e, r, n) {
			var o = 1 - t;
			return o * o * e + 2 * o * t * r + t * t * n;
		}
		function Cn(t, e, r, n) {
			return -r * (t /= n) * (t - 2) + e;
		}
		var jo = $o;
		function En(t, e) {
			for (var r = 0; r < e.length; r++) {
				var n = e[r];
				if (t.immediatePropagationStopped) break;
				n(t);
			}
		}
		var _n = function() {
			function t(e) {
				f(this, t), this.options = void 0, this.types = {}, this.propagationStopped = !1, this.immediatePropagationStopped = !1, this.global = void 0, this.options = W({}, e || {});
			}
			return y(t, [
				{
					key: "fire",
					value: function(e) {
						var r, n = this.global;
						(r = this.types[e.type]) && En(e, r), !e.propagationStopped && n && (r = n[e.type]) && En(e, r);
					}
				},
				{
					key: "on",
					value: function(e, r) {
						var n = Oe(e, r);
						for (e in n) this.types[e] = tn(this.types[e] || [], n[e]);
					}
				},
				{
					key: "off",
					value: function(e, r) {
						var n = Oe(e, r);
						for (e in n) {
							var o = this.types[e];
							if (o && o.length) for (var l = 0, c = n[e]; l < c.length; l++) {
								var p = c[l], h = o.indexOf(p);
								h !== -1 && o.splice(h, 1);
							}
						}
					}
				},
				{
					key: "getRect",
					value: function(e) {
						return null;
					}
				}
			]), t;
		}(), Ao = function() {
			function t(e) {
				f(this, t), this.currentTarget = void 0, this.originalEvent = void 0, this.type = void 0, this.originalEvent = e, st(this, e);
			}
			return y(t, [
				{
					key: "preventOriginalDefault",
					value: function() {
						this.originalEvent.preventDefault();
					}
				},
				{
					key: "stopPropagation",
					value: function() {
						this.originalEvent.stopPropagation();
					}
				},
				{
					key: "stopImmediatePropagation",
					value: function() {
						this.originalEvent.stopImmediatePropagation();
					}
				}
			]), t;
		}();
		function qe(t) {
			return w.object(t) ? {
				capture: !!t.capture,
				passive: !!t.passive
			} : {
				capture: !!t,
				passive: !1
			};
		}
		function ft(t, e) {
			return t === e || (typeof t == "boolean" ? !!e.capture === t && !e.passive : !!t.capture == !!e.capture && !!t.passive == !!e.passive);
		}
		var Lo = {
			id: "events",
			install: function(t) {
				var e, r = [], n = {}, o = [], l = {
					add: c,
					remove: p,
					addDelegate: function(d, b, x, I, E) {
						var M = qe(E);
						if (!n[x]) {
							n[x] = [];
							for (var $ = 0; $ < o.length; $++) {
								var z = o[$];
								c(z, x, h), c(z, x, g, !0);
							}
						}
						var A = n[x], N = Xe(A, function(K) {
							return K.selector === d && K.context === b;
						});
						N || (N = {
							selector: d,
							context: b,
							listeners: []
						}, A.push(N)), N.listeners.push({
							func: I,
							options: M
						});
					},
					removeDelegate: function(d, b, x, I, E) {
						var M, $ = qe(E), z = n[x], A = !1;
						if (z) for (M = z.length - 1; M >= 0; M--) {
							var N = z[M];
							if (N.selector === d && N.context === b) {
								for (var K = N.listeners, F = K.length - 1; F >= 0; F--) {
									var G = K[F];
									if (G.func === I && ft(G.options, $)) {
										K.splice(F, 1), K.length || (z.splice(M, 1), p(b, x, h), p(b, x, g, !0)), A = !0;
										break;
									}
								}
								if (A) break;
							}
						}
					},
					delegateListener: h,
					delegateUseCapture: g,
					delegatedEvents: n,
					documents: o,
					targets: r,
					supportsOptions: !1,
					supportsPassive: !1
				};
				function c(d, b, x, I) {
					if (d.addEventListener) {
						var E = qe(I), M = Xe(r, function($) {
							return $.eventTarget === d;
						});
						M || (M = {
							eventTarget: d,
							events: {}
						}, r.push(M)), M.events[b] || (M.events[b] = []), Xe(M.events[b], function($) {
							return $.func === x && ft($.options, E);
						}) || (d.addEventListener(b, x, l.supportsOptions ? E : E.capture), M.events[b].push({
							func: x,
							options: E
						}));
					}
				}
				function p(d, b, x, I) {
					if (d.addEventListener && d.removeEventListener) {
						var E = Ke(r, function(te) {
							return te.eventTarget === d;
						}), M = r[E];
						if (M && M.events) if (b !== "all") {
							var $ = !1, z = M.events[b];
							if (z) {
								if (x === "all") {
									for (var A = z.length - 1; A >= 0; A--) {
										var N = z[A];
										p(d, b, N.func, N.options);
									}
									return;
								}
								for (var K = qe(I), F = 0; F < z.length; F++) {
									var G = z[F];
									if (G.func === x && ft(G.options, K)) {
										d.removeEventListener(b, x, l.supportsOptions ? K : K.capture), z.splice(F, 1), z.length === 0 && (delete M.events[b], $ = !0);
										break;
									}
								}
							}
							$ && !Object.keys(M.events).length && r.splice(E, 1);
						} else for (b in M.events) M.events.hasOwnProperty(b) && p(d, b, "all");
					}
				}
				function h(d, b) {
					for (var x = qe(b), I = new Ao(d), E = n[d.type], M = en(d)[0], $ = M; w.element($);) {
						for (var z = 0; z < E.length; z++) {
							var A = E[z], N = A.selector, K = A.context;
							if (me($, N) && Se(K, M) && Se(K, $)) {
								var F = A.listeners;
								I.currentTarget = $;
								for (var G = 0; G < F.length; G++) {
									var te = F[G];
									ft(te.options, x) && te.func(I);
								}
							}
						}
						$ = pe($);
					}
				}
				function g(d) {
					return h(d, !0);
				}
				return (e = t.document) == null || e.createElement("div").addEventListener("test", null, {
					get capture() {
						return l.supportsOptions = !0;
					},
					get passive() {
						return l.supportsPassive = !0;
					}
				}), t.events = l, l;
			}
		}, ar = {
			methodOrder: [
				"simulationResume",
				"mouseOrPen",
				"hasPointer",
				"idle"
			],
			search: function(t) {
				for (var e = 0, r = ar.methodOrder; e < r.length; e++) {
					var o = ar[r[e]](t);
					if (o) return o;
				}
				return null;
			},
			simulationResume: function(t) {
				var e = t.pointerType, r = t.eventType, n = t.eventTarget, o = t.scope;
				if (!/down|start/i.test(r)) return null;
				for (var l = 0, c = o.interactions.list; l < c.length; l++) {
					var p = c[l], h = n;
					if (p.simulation && p.simulation.allowResume && p.pointerType === e) for (; h;) {
						if (h === p.element) return p;
						h = pe(h);
					}
				}
				return null;
			},
			mouseOrPen: function(t) {
				var e, r = t.pointerId, n = t.pointerType, o = t.eventType, l = t.scope;
				if (n !== "mouse" && n !== "pen") return null;
				for (var c = 0, p = l.interactions.list; c < p.length; c++) {
					var h = p[c];
					if (h.pointerType === n) {
						if (h.simulation && !Pn(h, r)) continue;
						if (h.interacting()) return h;
						e || (e = h);
					}
				}
				if (e) return e;
				for (var g = 0, d = l.interactions.list; g < d.length; g++) {
					var b = d[g];
					if (!(b.pointerType !== n || /down/i.test(o) && b.simulation)) return b;
				}
				return null;
			},
			hasPointer: function(t) {
				for (var e = t.pointerId, r = 0, n = t.scope.interactions.list; r < n.length; r++) {
					var o = n[r];
					if (Pn(o, e)) return o;
				}
				return null;
			},
			idle: function(t) {
				for (var e = t.pointerType, r = 0, n = t.scope.interactions.list; r < n.length; r++) {
					var o = n[r];
					if (o.pointers.length === 1) {
						var l = o.interactable;
						if (l && (!l.options.gesture || !l.options.gesture.enabled)) continue;
					} else if (o.pointers.length >= 2) continue;
					if (!o.interacting() && e === o.pointerType) return o;
				}
				return null;
			}
		};
		function Pn(t, e) {
			return t.pointers.some(function(r) {
				return r.id === e;
			});
		}
		var Ho = ar, lr = [
			"pointerDown",
			"pointerMove",
			"pointerUp",
			"updatePointer",
			"removePointer",
			"windowBlur"
		];
		function In(t, e) {
			return function(r) {
				var n = e.interactions.list, o = Qr(r), l = en(r), c = l[0], p = l[1], h = [];
				if (/^touch/.test(r.type)) {
					e.prevTouchTime = e.now();
					for (var g = 0, d = r.changedTouches; g < d.length; g++) {
						var b = d[g], x = {
							pointer: b,
							pointerId: Ye(b),
							pointerType: o,
							eventType: r.type,
							eventTarget: c,
							curEventTarget: p,
							scope: e
						}, I = Mn(x);
						h.push([
							x.pointer,
							x.eventTarget,
							x.curEventTarget,
							I
						]);
					}
				} else {
					var E = !1;
					if (!oe.supportsPointerEvent && /mouse/.test(r.type)) {
						for (var M = 0; M < n.length && !E; M++) E = n[M].pointerType !== "mouse" && n[M].pointerIsDown;
						E = E || e.now() - e.prevTouchTime < 500 || r.timeStamp === 0;
					}
					if (!E) {
						var $ = {
							pointer: r,
							pointerId: Ye(r),
							pointerType: o,
							eventType: r.type,
							curEventTarget: p,
							eventTarget: c,
							scope: e
						}, z = Mn($);
						h.push([
							$.pointer,
							$.eventTarget,
							$.curEventTarget,
							z
						]);
					}
				}
				for (var A = 0; A < h.length; A++) {
					var N = h[A], K = N[0], F = N[1], G = N[2];
					N[3][t](K, r, F, G);
				}
			};
		}
		function Mn(t) {
			var e = t.pointerType, r = t.scope, n = {
				interaction: Ho.search(t),
				searchDetails: t
			};
			return r.fire("interactions:find", n), n.interaction || r.interactions.new({ pointerType: e });
		}
		function cr(t, e) {
			var r = t.doc, n = t.scope, o = t.options, l = n.interactions.docEvents, c = n.events, p = c[e];
			for (var h in n.browser.isIOS && !o.events && (o.events = { passive: !1 }), c.delegatedEvents) p(r, h, c.delegateListener), p(r, h, c.delegateUseCapture, !0);
			for (var g = o && o.events, d = 0; d < l.length; d++) {
				var b = l[d];
				p(r, b.type, b.listener, g);
			}
		}
		var Fo = {
			id: "core/interactions",
			install: function(t) {
				for (var e = {}, r = 0; r < lr.length; r++) {
					var n = lr[r];
					e[n] = In(n, t);
				}
				var o, l = oe.pEventTypes;
				function c() {
					for (var p = 0, h = t.interactions.list; p < h.length; p++) {
						var g = h[p];
						if (g.pointerIsDown && g.pointerType === "touch" && !g._interacting) for (var d = function() {
							var I = x[b];
							t.documents.some(function(E) {
								return Se(E.doc, I.downTarget);
							}) || g.removePointer(I.pointer, I.event);
						}, b = 0, x = g.pointers; b < x.length; b++) d();
					}
				}
				(o = Q.PointerEvent ? [
					{
						type: l.down,
						listener: c
					},
					{
						type: l.down,
						listener: e.pointerDown
					},
					{
						type: l.move,
						listener: e.pointerMove
					},
					{
						type: l.up,
						listener: e.pointerUp
					},
					{
						type: l.cancel,
						listener: e.pointerUp
					}
				] : [
					{
						type: "mousedown",
						listener: e.pointerDown
					},
					{
						type: "mousemove",
						listener: e.pointerMove
					},
					{
						type: "mouseup",
						listener: e.pointerUp
					},
					{
						type: "touchstart",
						listener: c
					},
					{
						type: "touchstart",
						listener: e.pointerDown
					},
					{
						type: "touchmove",
						listener: e.pointerMove
					},
					{
						type: "touchend",
						listener: e.pointerUp
					},
					{
						type: "touchcancel",
						listener: e.pointerUp
					}
				]).push({
					type: "blur",
					listener: function(p) {
						for (var h = 0, g = t.interactions.list; h < g.length; h++) g[h].documentBlur(p);
					}
				}), t.prevTouchTime = 0, t.Interaction = function(p) {
					C(g, p);
					var h = P(g);
					function g() {
						return f(this, g), h.apply(this, arguments);
					}
					return y(g, [{
						key: "pointerMoveTolerance",
						get: function() {
							return t.interactions.pointerMoveTolerance;
						},
						set: function(d) {
							t.interactions.pointerMoveTolerance = d;
						}
					}, {
						key: "_now",
						value: function() {
							return t.now();
						}
					}]), g;
				}(Ro), t.interactions = {
					list: [],
					new: function(p) {
						p.scopeFire = function(g, d) {
							return t.fire(g, d);
						};
						var h = new t.Interaction(p);
						return t.interactions.list.push(h), h;
					},
					listeners: e,
					docEvents: o,
					pointerMoveTolerance: 1
				}, t.usePlugin(mn);
			},
			listeners: {
				"scope:add-document": function(t) {
					return cr(t, "add");
				},
				"scope:remove-document": function(t) {
					return cr(t, "remove");
				},
				"interactable:unset": function(t, e) {
					for (var r = t.interactable, n = e.interactions.list.length - 1; n >= 0; n--) {
						var o = e.interactions.list[n];
						o.interactable === r && (o.stop(), e.fire("interactions:destroy", { interaction: o }), o.destroy(), e.interactions.list.length > 2 && e.interactions.list.splice(n, 1));
					}
				}
			},
			onDocSignal: cr,
			doOnInteractions: In,
			methodNames: lr
		}, Te = function(t) {
			return t[t.On = 0] = "On", t[t.Off = 1] = "Off", t;
		}(Te || {}), Uo = function() {
			function t(e, r, n, o) {
				f(this, t), this.target = void 0, this.options = void 0, this._actions = void 0, this.events = new _n(), this._context = void 0, this._win = void 0, this._doc = void 0, this._scopeEvents = void 0, this._actions = r.actions, this.target = e, this._context = r.context || n, this._win = B(Kr(e) ? this._context : e), this._doc = this._win.document, this._scopeEvents = o, this.set(r);
			}
			return y(t, [
				{
					key: "_defaults",
					get: function() {
						return {
							base: {},
							perAction: {},
							actions: {}
						};
					}
				},
				{
					key: "setOnEvents",
					value: function(e, r) {
						return w.func(r.onstart) && this.on("".concat(e, "start"), r.onstart), w.func(r.onmove) && this.on("".concat(e, "move"), r.onmove), w.func(r.onend) && this.on("".concat(e, "end"), r.onend), w.func(r.oninertiastart) && this.on("".concat(e, "inertiastart"), r.oninertiastart), this;
					}
				},
				{
					key: "updatePerActionListeners",
					value: function(e, r, n) {
						var o, l = this, c = (o = this._actions.map[e]) == null ? void 0 : o.filterEventType, p = function(h) {
							return (c == null || c(h)) && pt(h, l._actions);
						};
						(w.array(r) || w.object(r)) && this._onOff(Te.Off, e, r, void 0, p), (w.array(n) || w.object(n)) && this._onOff(Te.On, e, n, void 0, p);
					}
				},
				{
					key: "setPerAction",
					value: function(e, r) {
						var n = this._defaults;
						for (var o in r) {
							var l = o, c = this.options[e], p = r[l];
							l === "listeners" && this.updatePerActionListeners(e, c.listeners, p), w.array(p) ? c[l] = rn(p) : w.plainObject(p) ? (c[l] = W(c[l] || {}, ke(p)), w.object(n.perAction[l]) && "enabled" in n.perAction[l] && (c[l].enabled = p.enabled !== !1)) : w.bool(p) && w.object(n.perAction[l]) ? c[l].enabled = p : c[l] = p;
						}
					}
				},
				{
					key: "getRect",
					value: function(e) {
						return e = e || (w.element(this.target) ? this.target : null), w.string(this.target) && (e = e || this._context.querySelector(this.target)), Nt(e);
					}
				},
				{
					key: "rectChecker",
					value: function(e) {
						var r = this;
						return w.func(e) ? (this.getRect = function(n) {
							var o = W({}, e.apply(r, n));
							return "width" in o || (o.width = o.right - o.left, o.height = o.bottom - o.top), o;
						}, this) : e === null ? (delete this.getRect, this) : this.getRect;
					}
				},
				{
					key: "_backCompatOption",
					value: function(e, r) {
						if (Kr(r) || w.object(r)) {
							for (var n in this.options[e] = r, this._actions.map) this.options[n][e] = r;
							return this;
						}
						return this.options[e];
					}
				},
				{
					key: "origin",
					value: function(e) {
						return this._backCompatOption("origin", e);
					}
				},
				{
					key: "deltaSource",
					value: function(e) {
						return e === "page" || e === "client" ? (this.options.deltaSource = e, this) : this.options.deltaSource;
					}
				},
				{
					key: "getAllElements",
					value: function() {
						var e = this.target;
						return w.string(e) ? Array.from(this._context.querySelectorAll(e)) : w.func(e) && e.getAllElements ? e.getAllElements() : w.element(e) ? [e] : [];
					}
				},
				{
					key: "context",
					value: function() {
						return this._context;
					}
				},
				{
					key: "inContext",
					value: function(e) {
						return this._context === e.ownerDocument || Se(this._context, e);
					}
				},
				{
					key: "testIgnoreAllow",
					value: function(e, r, n) {
						return !this.testIgnore(e.ignoreFrom, r, n) && this.testAllow(e.allowFrom, r, n);
					}
				},
				{
					key: "testAllow",
					value: function(e, r, n) {
						return !e || !!w.element(n) && (w.string(e) ? Ft(n, e, r) : !!w.element(e) && Se(e, n));
					}
				},
				{
					key: "testIgnore",
					value: function(e, r, n) {
						return !(!e || !w.element(n)) && (w.string(e) ? Ft(n, e, r) : !!w.element(e) && Se(e, n));
					}
				},
				{
					key: "fire",
					value: function(e) {
						return this.events.fire(e), this;
					}
				},
				{
					key: "_onOff",
					value: function(e, r, n, o, l) {
						w.object(r) && !w.array(r) && (o = n, n = null);
						var c = Oe(r, n, l);
						for (var p in c) {
							p === "wheel" && (p = oe.wheelEvent);
							for (var h = 0, g = c[p]; h < g.length; h++) {
								var d = g[h];
								pt(p, this._actions) ? this.events[e === Te.On ? "on" : "off"](p, d) : w.string(this.target) ? this._scopeEvents[e === Te.On ? "addDelegate" : "removeDelegate"](this.target, this._context, p, d, o) : this._scopeEvents[e === Te.On ? "add" : "remove"](this.target, p, d, o);
							}
						}
						return this;
					}
				},
				{
					key: "on",
					value: function(e, r, n) {
						return this._onOff(Te.On, e, r, n);
					}
				},
				{
					key: "off",
					value: function(e, r, n) {
						return this._onOff(Te.Off, e, r, n);
					}
				},
				{
					key: "set",
					value: function(e) {
						var r = this._defaults;
						for (var n in w.object(e) || (e = {}), this.options = ke(r.base), this._actions.methodDict) {
							var o = n, l = this._actions.methodDict[o];
							this.options[o] = {}, this.setPerAction(o, W(W({}, r.perAction), r.actions[o])), this[l](e[o]);
						}
						for (var c in e) c !== "getRect" ? w.func(this[c]) && this[c](e[c]) : this.rectChecker(e.getRect);
						return this;
					}
				},
				{
					key: "unset",
					value: function() {
						if (w.string(this.target)) for (var e in this._scopeEvents.delegatedEvents) for (var r = this._scopeEvents.delegatedEvents[e], n = r.length - 1; n >= 0; n--) {
							var o = r[n], l = o.selector, c = o.context, p = o.listeners;
							l === this.target && c === this._context && r.splice(n, 1);
							for (var h = p.length - 1; h >= 0; h--) this._scopeEvents.removeDelegate(this.target, this._context, e, p[h][0], p[h][1]);
						}
						else this._scopeEvents.remove(this.target, "all");
					}
				}
			]), t;
		}(), No = function() {
			function t(e) {
				var r = this;
				f(this, t), this.list = [], this.selectorMap = {}, this.scope = void 0, this.scope = e, e.addListeners({ "interactable:unset": function(n) {
					var o = n.interactable, l = o.target, c = w.string(l) ? r.selectorMap[l] : l[r.scope.id], p = Ke(c, function(h) {
						return h === o;
					});
					c.splice(p, 1);
				} });
			}
			return y(t, [
				{
					key: "new",
					value: function(e, r) {
						r = W(r || {}, { actions: this.scope.actions });
						var n = new this.scope.Interactable(e, r, this.scope.document, this.scope.events);
						return this.scope.addDocument(n._doc), this.list.push(n), w.string(e) ? (this.selectorMap[e] || (this.selectorMap[e] = []), this.selectorMap[e].push(n)) : (n.target[this.scope.id] || Object.defineProperty(e, this.scope.id, {
							value: [],
							configurable: !0
						}), e[this.scope.id].push(n)), this.scope.fire("interactable:new", {
							target: e,
							options: r,
							interactable: n,
							win: this.scope._win
						}), n;
					}
				},
				{
					key: "getExisting",
					value: function(e, r) {
						var n = r && r.context || this.scope.document, o = w.string(e), l = o ? this.selectorMap[e] : e[this.scope.id];
						if (l) return Xe(l, function(c) {
							return c._context === n && (o || c.inContext(e));
						});
					}
				},
				{
					key: "forEachMatch",
					value: function(e, r) {
						for (var n = 0, o = this.list; n < o.length; n++) {
							var l = o[n], c = void 0;
							if ((w.string(l.target) ? w.element(e) && me(e, l.target) : e === l.target) && l.inContext(e) && (c = r(l)), c !== void 0) return c;
						}
					}
				}
			]), t;
		}(), Go = function() {
			function t() {
				var e = this;
				f(this, t), this.id = "__interact_scope_".concat(Math.floor(100 * Math.random())), this.isInitialized = !1, this.listenerMaps = [], this.browser = oe, this.defaults = ke(yn), this.Eventable = _n, this.actions = {
					map: {},
					phases: {
						start: !0,
						move: !0,
						end: !0
					},
					methodDict: {},
					phaselessTypes: {}
				}, this.interactStatic = function(n) {
					var o = function l(c, p) {
						var h = n.interactables.getExisting(c, p);
						return h || ((h = n.interactables.new(c, p)).events.global = l.globalEvents), h;
					};
					return o.getPointerAverage = Jr, o.getTouchBBox = Kt, o.getTouchDistance = Xt, o.getTouchAngle = Bt, o.getElementRect = Nt, o.getElementClientRect = Ut, o.matchesSelector = me, o.closest = Ur, o.globalEvents = {}, o.version = "1.10.27", o.scope = n, o.use = function(l, c) {
						return this.scope.usePlugin(l, c), this;
					}, o.isSet = function(l, c) {
						return !!this.scope.interactables.get(l, c && c.context);
					}, o.on = Be(function(l, c, p) {
						if (w.string(l) && l.search(" ") !== -1 && (l = l.trim().split(/ +/)), w.array(l)) {
							for (var h = 0, g = l; h < g.length; h++) {
								var d = g[h];
								this.on(d, c, p);
							}
							return this;
						}
						if (w.object(l)) {
							for (var b in l) this.on(b, l[b], c);
							return this;
						}
						return pt(l, this.scope.actions) ? this.globalEvents[l] ? this.globalEvents[l].push(c) : this.globalEvents[l] = [c] : this.scope.events.add(this.scope.document, l, c, { options: p }), this;
					}, "The interact.on() method is being deprecated"), o.off = Be(function(l, c, p) {
						if (w.string(l) && l.search(" ") !== -1 && (l = l.trim().split(/ +/)), w.array(l)) {
							for (var h = 0, g = l; h < g.length; h++) {
								var d = g[h];
								this.off(d, c, p);
							}
							return this;
						}
						if (w.object(l)) {
							for (var b in l) this.off(b, l[b], c);
							return this;
						}
						var x;
						return pt(l, this.scope.actions) ? l in this.globalEvents && (x = this.globalEvents[l].indexOf(c)) !== -1 && this.globalEvents[l].splice(x, 1) : this.scope.events.remove(this.scope.document, l, c, p), this;
					}, "The interact.off() method is being deprecated"), o.debug = function() {
						return this.scope;
					}, o.supportsTouch = function() {
						return oe.supportsTouch;
					}, o.supportsPointerEvent = function() {
						return oe.supportsPointerEvent;
					}, o.stop = function() {
						for (var l = 0, c = this.scope.interactions.list; l < c.length; l++) c[l].stop();
						return this;
					}, o.pointerMoveTolerance = function(l) {
						return w.number(l) ? (this.scope.interactions.pointerMoveTolerance = l, this) : this.scope.interactions.pointerMoveTolerance;
					}, o.addDocument = function(l, c) {
						this.scope.addDocument(l, c);
					}, o.removeDocument = function(l) {
						this.scope.removeDocument(l);
					}, o;
				}(this), this.InteractEvent = or, this.Interactable = void 0, this.interactables = new No(this), this._win = void 0, this.document = void 0, this.window = void 0, this.documents = [], this._plugins = {
					list: [],
					map: {}
				}, this.onWindowUnload = function(n) {
					return e.removeDocument(n.target);
				};
				var r = this;
				this.Interactable = function(n) {
					C(l, n);
					var o = P(l);
					function l() {
						return f(this, l), o.apply(this, arguments);
					}
					return y(l, [
						{
							key: "_defaults",
							get: function() {
								return r.defaults;
							}
						},
						{
							key: "set",
							value: function(c) {
								return _(D(l.prototype), "set", this).call(this, c), r.fire("interactable:set", {
									options: c,
									interactable: this
								}), this;
							}
						},
						{
							key: "unset",
							value: function() {
								_(D(l.prototype), "unset", this).call(this);
								var c = r.interactables.list.indexOf(this);
								c < 0 || (r.interactables.list.splice(c, 1), r.fire("interactable:unset", { interactable: this }));
							}
						}
					]), l;
				}(Uo);
			}
			return y(t, [
				{
					key: "addListeners",
					value: function(e, r) {
						this.listenerMaps.push({
							id: r,
							map: e
						});
					}
				},
				{
					key: "fire",
					value: function(e, r) {
						for (var n = 0, o = this.listenerMaps; n < o.length; n++) {
							var l = o[n].map[e];
							if (l && l(r, this, e) === !1) return !1;
						}
					}
				},
				{
					key: "init",
					value: function(e) {
						return this.isInitialized ? this : function(r, n) {
							return r.isInitialized = !0, w.window(n) && X(n), Q.init(n), oe.init(n), be.init(n), r.window = n, r.document = n.document, r.usePlugin(Fo), r.usePlugin(Lo), r;
						}(this, e);
					}
				},
				{
					key: "pluginIsInstalled",
					value: function(e) {
						var r = e.id;
						return r ? !!this._plugins.map[r] : this._plugins.list.indexOf(e) !== -1;
					}
				},
				{
					key: "usePlugin",
					value: function(e, r) {
						if (!this.isInitialized) return this;
						if (this.pluginIsInstalled(e)) return this;
						if (e.id && (this._plugins.map[e.id] = e), this._plugins.list.push(e), e.install && e.install(this, r), e.listeners && e.before) {
							for (var n = 0, o = this.listenerMaps.length, l = e.before.reduce(function(p, h) {
								return p[h] = !0, p[Rn(h)] = !0, p;
							}, {}); n < o; n++) {
								var c = this.listenerMaps[n].id;
								if (c && (l[c] || l[Rn(c)])) break;
							}
							this.listenerMaps.splice(n, 0, {
								id: e.id,
								map: e.listeners
							});
						} else e.listeners && this.listenerMaps.push({
							id: e.id,
							map: e.listeners
						});
						return this;
					}
				},
				{
					key: "addDocument",
					value: function(e, r) {
						if (this.getDocIndex(e) !== -1) return !1;
						var n = B(e);
						r = r ? W({}, r) : {}, this.documents.push({
							doc: e,
							options: r
						}), this.events.documents.push(e), e !== this.document && this.events.add(n, "unload", this.onWindowUnload), this.fire("scope:add-document", {
							doc: e,
							window: n,
							scope: this,
							options: r
						});
					}
				},
				{
					key: "removeDocument",
					value: function(e) {
						var r = this.getDocIndex(e), n = B(e), o = this.documents[r].options;
						this.events.remove(n, "unload", this.onWindowUnload), this.documents.splice(r, 1), this.events.documents.splice(r, 1), this.fire("scope:remove-document", {
							doc: e,
							window: n,
							scope: this,
							options: o
						});
					}
				},
				{
					key: "getDocIndex",
					value: function(e) {
						for (var r = 0; r < this.documents.length; r++) if (this.documents[r].doc === e) return r;
						return -1;
					}
				},
				{
					key: "getDocOptions",
					value: function(e) {
						var r = this.getDocIndex(e);
						return r === -1 ? null : this.documents[r].options;
					}
				},
				{
					key: "now",
					value: function() {
						return (this.window.Date || Date).now();
					}
				}
			]), t;
		}();
		function Rn(t) {
			return t && t.replace(/\/.*$/, "");
		}
		var Dn = new Go(), ee = Dn.interactStatic, Yo = typeof globalThis < "u" ? globalThis : window;
		Dn.init(Yo);
		var Ko = Object.freeze({
			__proto__: null,
			edgeTarget: function() {},
			elements: function() {},
			grid: function(t) {
				var e = [
					["x", "y"],
					["left", "top"],
					["right", "bottom"],
					["width", "height"]
				].filter(function(n) {
					var o = n[0], l = n[1];
					return o in t || l in t;
				}), r = function(n, o) {
					for (var l = t.range, c = t.limits, p = c === void 0 ? {
						left: -1 / 0,
						right: 1 / 0,
						top: -1 / 0,
						bottom: 1 / 0
					} : c, h = t.offset, g = h === void 0 ? {
						x: 0,
						y: 0
					} : h, d = {
						range: l,
						grid: t,
						x: null,
						y: null
					}, b = 0; b < e.length; b++) {
						var x = e[b], I = x[0], E = x[1], M = Math.round((n - g.x) / t[I]), $ = Math.round((o - g.y) / t[E]);
						d[I] = Math.max(p.left, Math.min(p.right, M * t[I] + g.x)), d[E] = Math.max(p.top, Math.min(p.bottom, $ * t[E] + g.y));
					}
					return d;
				};
				return r.grid = t, r.coordFields = e, r;
			}
		}), Bo = {
			id: "snappers",
			install: function(t) {
				var e = t.interactStatic;
				e.snappers = W(e.snappers || {}, Ko), e.createSnapGrid = e.snappers.grid;
			}
		}, Vo = {
			start: function(t) {
				var e = t.state, r = t.rect, n = t.edges, o = t.pageCoords, l = e.options, c = l.ratio, p = l.enabled, h = e.options, g = h.equalDelta, d = h.modifiers;
				c === "preserve" && (c = r.width / r.height), e.startCoords = W({}, o), e.startRect = W({}, r), e.ratio = c, e.equalDelta = g;
				var b = e.linkedEdges = {
					top: n.top || n.left && !n.bottom,
					left: n.left || n.top && !n.right,
					bottom: n.bottom || n.right && !n.top,
					right: n.right || n.bottom && !n.left
				};
				if (e.xIsPrimaryAxis = !(!n.left && !n.right), e.equalDelta) {
					var x = (b.left ? 1 : -1) * (b.top ? 1 : -1);
					e.edgeSign = {
						x,
						y: x
					};
				} else e.edgeSign = {
					x: b.left ? -1 : 1,
					y: b.top ? -1 : 1
				};
				if (p !== !1 && W(n, b), d != null && d.length) {
					var I = new ir(t.interaction);
					I.copyFrom(t.interaction.modification), I.prepareStates(d), e.subModification = I, I.startAll(u({}, t));
				}
			},
			set: function(t) {
				var e = t.state, r = t.rect, n = t.coords, o = e.linkedEdges, l = W({}, n), c = e.equalDelta ? qo : Zo;
				if (W(t.edges, o), c(e, e.xIsPrimaryAxis, n, r), !e.subModification) return null;
				var p = W({}, r);
				ot(o, p, {
					x: n.x - l.x,
					y: n.y - l.y
				});
				var h = e.subModification.setAll(u(u({}, t), {}, {
					rect: p,
					edges: o,
					pageCoords: n,
					prevCoords: n,
					prevRect: p
				})), g = h.delta;
				return h.changed && (c(e, Math.abs(g.x) > Math.abs(g.y), h.coords, h.rect), W(n, h.coords)), h.eventProps;
			},
			defaults: {
				ratio: "preserve",
				equalDelta: !1,
				modifiers: [],
				enabled: !1
			}
		};
		function qo(t, e, r) {
			var n = t.startCoords, o = t.edgeSign;
			e ? r.y = n.y + (r.x - n.x) * o.y : r.x = n.x + (r.y - n.y) * o.x;
		}
		function Zo(t, e, r, n) {
			var o = t.startRect, l = t.startCoords, c = t.ratio, p = t.edgeSign;
			if (e) {
				var h = n.width / c;
				r.y = l.y + (h - o.height) * p.y;
			} else {
				var g = n.height * c;
				r.x = l.x + (g - o.width) * p.x;
			}
		}
		var Jo = ye(Vo, "aspectRatio"), kn = function() {};
		kn._defaults = {};
		var vt = kn;
		function Ee(t, e, r) {
			return w.func(t) ? Ue(t, e.interactable, e.element, [
				r.x,
				r.y,
				e
			]) : Ue(t, e.interactable, e.element);
		}
		var gt = {
			start: function(t) {
				var e = t.rect, r = t.startOffset, n = t.state, o = t.interaction, l = t.pageCoords, c = n.options, p = c.elementRect, h = W({
					left: 0,
					top: 0,
					right: 0,
					bottom: 0
				}, c.offset || {});
				if (e && p) {
					var g = Ee(c.restriction, o, l);
					if (g) {
						var d = g.right - g.left - e.width, b = g.bottom - g.top - e.height;
						d < 0 && (h.left += d, h.right += d), b < 0 && (h.top += b, h.bottom += b);
					}
					h.left += r.left - e.width * p.left, h.top += r.top - e.height * p.top, h.right += r.right - e.width * (1 - p.right), h.bottom += r.bottom - e.height * (1 - p.bottom);
				}
				n.offset = h;
			},
			set: function(t) {
				var e = t.coords, r = t.interaction, n = t.state, o = n.options, l = n.offset, c = Ee(o.restriction, r, e);
				if (c) {
					var p = function(h) {
						return !h || "left" in h && "top" in h || ((h = W({}, h)).left = h.x || 0, h.top = h.y || 0, h.right = h.right || h.left + h.width, h.bottom = h.bottom || h.top + h.height), h;
					}(c);
					e.x = Math.max(Math.min(p.right - l.right, e.x), p.left + l.left), e.y = Math.max(Math.min(p.bottom - l.bottom, e.y), p.top + l.top);
				}
			},
			defaults: {
				restriction: null,
				elementRect: null,
				offset: null,
				endOnly: !1,
				enabled: !1
			}
		}, Qo = ye(gt, "restrict"), zn = {
			top: 1 / 0,
			left: 1 / 0,
			bottom: -1 / 0,
			right: -1 / 0
		}, $n = {
			top: -1 / 0,
			left: -1 / 0,
			bottom: 1 / 0,
			right: 1 / 0
		};
		function jn(t, e) {
			for (var r = 0, n = [
				"top",
				"left",
				"bottom",
				"right"
			]; r < n.length; r++) {
				var o = n[r];
				o in t || (t[o] = e[o]);
			}
			return t;
		}
		var Ze = {
			noInner: zn,
			noOuter: $n,
			start: function(t) {
				var e, r = t.interaction, n = t.startOffset, o = t.state, l = o.options;
				l && (e = it(Ee(l.offset, r, r.coords.start.page))), e = e || {
					x: 0,
					y: 0
				}, o.offset = {
					top: e.y + n.top,
					left: e.x + n.left,
					bottom: e.y - n.bottom,
					right: e.x - n.right
				};
			},
			set: function(t) {
				var e = t.coords, r = t.edges, n = t.interaction, o = t.state, l = o.offset, c = o.options;
				if (r) {
					var p = W({}, e), h = Ee(c.inner, n, p) || {}, g = Ee(c.outer, n, p) || {};
					jn(h, zn), jn(g, $n), r.top ? e.y = Math.min(Math.max(g.top + l.top, p.y), h.top + l.top) : r.bottom && (e.y = Math.max(Math.min(g.bottom + l.bottom, p.y), h.bottom + l.bottom)), r.left ? e.x = Math.min(Math.max(g.left + l.left, p.x), h.left + l.left) : r.right && (e.x = Math.max(Math.min(g.right + l.right, p.x), h.right + l.right));
				}
			},
			defaults: {
				inner: null,
				outer: null,
				offset: null,
				endOnly: !1,
				enabled: !1
			}
		}, es = ye(Ze, "restrictEdges"), ts = W({
			get elementRect() {
				return {
					top: 0,
					left: 0,
					bottom: 1,
					right: 1
				};
			},
			set elementRect(t) {}
		}, gt.defaults), rs = ye({
			start: gt.start,
			set: gt.set,
			defaults: ts
		}, "restrictRect"), ns = {
			width: -1 / 0,
			height: -1 / 0
		}, is = {
			width: 1 / 0,
			height: 1 / 0
		}, os = ye({
			start: function(t) {
				return Ze.start(t);
			},
			set: function(t) {
				var e = t.interaction, r = t.state, n = t.rect, o = t.edges, l = r.options;
				if (o) {
					var c = Gt(Ee(l.min, e, t.coords)) || ns, p = Gt(Ee(l.max, e, t.coords)) || is;
					r.options = {
						endOnly: l.endOnly,
						inner: W({}, Ze.noInner),
						outer: W({}, Ze.noOuter)
					}, o.top ? (r.options.inner.top = n.bottom - c.height, r.options.outer.top = n.bottom - p.height) : o.bottom && (r.options.inner.bottom = n.top + c.height, r.options.outer.bottom = n.top + p.height), o.left ? (r.options.inner.left = n.right - c.width, r.options.outer.left = n.right - p.width) : o.right && (r.options.inner.right = n.left + c.width, r.options.outer.right = n.left + p.width), Ze.set(t), r.options = l;
				}
			},
			defaults: {
				min: null,
				max: null,
				endOnly: !1,
				enabled: !1
			}
		}, "restrictSize"), ur = {
			start: function(t) {
				var e, r = t.interaction, n = t.interactable, o = t.element, l = t.rect, c = t.state, p = t.startOffset, h = c.options, g = h.offsetWithOrigin ? function(x) {
					var I = x.interaction.element;
					return it(Ue(x.state.options.origin, null, null, [I])) || Ne(x.interactable, I, x.interaction.prepared.name);
				}(t) : {
					x: 0,
					y: 0
				};
				if (h.offset === "startCoords") e = {
					x: r.coords.start.page.x,
					y: r.coords.start.page.y
				};
				else {
					var d = Ue(h.offset, n, o, [r]);
					(e = it(d) || {
						x: 0,
						y: 0
					}).x += g.x, e.y += g.y;
				}
				var b = h.relativePoints;
				c.offsets = l && b && b.length ? b.map(function(x, I) {
					return {
						index: I,
						relativePoint: x,
						x: p.left - l.width * x.x + e.x,
						y: p.top - l.height * x.y + e.y
					};
				}) : [{
					index: 0,
					relativePoint: null,
					x: e.x,
					y: e.y
				}];
			},
			set: function(t) {
				var e = t.interaction, r = t.coords, n = t.state, o = n.options, l = n.offsets, c = Ne(e.interactable, e.element, e.prepared.name), p = W({}, r), h = [];
				o.offsetWithOrigin || (p.x -= c.x, p.y -= c.y);
				for (var g = 0, d = l; g < d.length; g++) for (var b = d[g], x = p.x - b.x, I = p.y - b.y, E = 0, M = o.targets.length; E < M; E++) {
					var $ = o.targets[E], z = void 0;
					(z = w.func($) ? $(x, I, e._proxy, b, E) : $) && h.push({
						x: (w.number(z.x) ? z.x : x) + b.x,
						y: (w.number(z.y) ? z.y : I) + b.y,
						range: w.number(z.range) ? z.range : o.range,
						source: $,
						index: E,
						offset: b
					});
				}
				for (var A = {
					target: null,
					inRange: !1,
					distance: 0,
					range: 0,
					delta: {
						x: 0,
						y: 0
					}
				}, N = 0; N < h.length; N++) {
					var K = h[N], F = K.range, G = K.x - p.x, te = K.y - p.y, J = Ge(G, te), re = J <= F;
					F === 1 / 0 && A.inRange && A.range !== 1 / 0 && (re = !1), A.target && !(re ? A.inRange && F !== 1 / 0 ? J / F < A.distance / A.range : F === 1 / 0 && A.range !== 1 / 0 || J < A.distance : !A.inRange && J < A.distance) || (A.target = K, A.distance = J, A.range = F, A.inRange = re, A.delta.x = G, A.delta.y = te);
				}
				return A.inRange && (r.x = A.target.x, r.y = A.target.y), n.closest = A, A;
			},
			defaults: {
				range: 1 / 0,
				targets: null,
				offset: null,
				offsetWithOrigin: !0,
				origin: null,
				relativePoints: null,
				endOnly: !1,
				enabled: !1
			}
		}, ss = ye(ur, "snap"), mt = {
			start: function(t) {
				var e = t.state, r = t.edges, n = e.options;
				if (!r) return null;
				t.state = { options: {
					targets: null,
					relativePoints: [{
						x: r.left ? 0 : 1,
						y: r.top ? 0 : 1
					}],
					offset: n.offset || "self",
					origin: {
						x: 0,
						y: 0
					},
					range: n.range
				} }, e.targetFields = e.targetFields || [["width", "height"], ["x", "y"]], ur.start(t), e.offsets = t.state.offsets, t.state = e;
			},
			set: function(t) {
				var e = t.interaction, r = t.state, n = t.coords, o = r.options, l = r.offsets, c = {
					x: n.x - l[0].x,
					y: n.y - l[0].y
				};
				r.options = W({}, o), r.options.targets = [];
				for (var p = 0, h = o.targets || []; p < h.length; p++) {
					var g = h[p], d = void 0;
					if (d = w.func(g) ? g(c.x, c.y, e) : g) {
						for (var b = 0, x = r.targetFields; b < x.length; b++) {
							var I = x[b], E = I[0], M = I[1];
							if (E in d || M in d) {
								d.x = d[E], d.y = d[M];
								break;
							}
						}
						r.options.targets.push(d);
					}
				}
				var $ = ur.set(t);
				return r.options = o, $;
			},
			defaults: {
				range: 1 / 0,
				targets: null,
				offset: null,
				endOnly: !1,
				enabled: !1
			}
		}, as = ye(mt, "snapSize"), pr = {
			aspectRatio: Jo,
			restrictEdges: es,
			restrict: Qo,
			restrictRect: rs,
			restrictSize: os,
			snapEdges: ye({
				start: function(t) {
					var e = t.edges;
					return e ? (t.state.targetFields = t.state.targetFields || [[e.left ? "left" : "right", e.top ? "top" : "bottom"]], mt.start(t)) : null;
				},
				set: mt.set,
				defaults: W(ke(mt.defaults), {
					targets: void 0,
					range: void 0,
					offset: {
						x: 0,
						y: 0
					}
				})
			}, "snapEdges"),
			snap: ss,
			snapSize: as,
			spring: vt,
			avoid: vt,
			transform: vt,
			rubberband: vt
		}, cs = {
			id: "modifiers",
			install: function(t) {
				var e = t.interactStatic;
				for (var r in t.usePlugin(bn), t.usePlugin(Bo), e.modifiers = pr, pr) {
					var n = pr[r], o = n._defaults;
					o._methods = n._methods, t.defaults.perAction[r] = o;
				}
			}
		}, An = function(t) {
			C(r, t);
			var e = P(r);
			function r(n, o, l, c, p, h) {
				var g;
				if (f(this, r), st(T(g = e.call(this, p)), l), l !== o && st(T(g), o), g.timeStamp = h, g.originalEvent = l, g.type = n, g.pointerId = Ye(o), g.pointerType = Qr(o), g.target = c, g.currentTarget = null, n === "tap") {
					var d = p.getPointerIndex(o);
					g.dt = g.timeStamp - p.pointers[d].downTime;
					var b = g.timeStamp - p.tapTime;
					g.double = !!p.prevTap && p.prevTap.type !== "doubletap" && p.prevTap.target === g.target && b < 500;
				} else n === "doubletap" && (g.dt = o.timeStamp - p.tapTime, g.double = !0);
				return g;
			}
			return y(r, [
				{
					key: "_subtractOrigin",
					value: function(n) {
						var o = n.x, l = n.y;
						return this.pageX -= o, this.pageY -= l, this.clientX -= o, this.clientY -= l, this;
					}
				},
				{
					key: "_addOrigin",
					value: function(n) {
						var o = n.x, l = n.y;
						return this.pageX += o, this.pageY += l, this.clientX += o, this.clientY += l, this;
					}
				},
				{
					key: "preventDefault",
					value: function() {
						this.originalEvent.preventDefault();
					}
				}
			]), r;
		}(ct), Je = {
			id: "pointer-events/base",
			before: [
				"inertia",
				"modifiers",
				"auto-start",
				"actions"
			],
			install: function(t) {
				t.pointerEvents = Je, t.defaults.actions.pointerEvents = Je.defaults, W(t.actions.phaselessTypes, Je.types);
			},
			listeners: {
				"interactions:new": function(t) {
					var e = t.interaction;
					e.prevTap = null, e.tapTime = 0;
				},
				"interactions:update-pointer": function(t) {
					var e = t.down, r = t.pointerInfo;
					!e && r.hold || (r.hold = {
						duration: 1 / 0,
						timeout: null
					});
				},
				"interactions:move": function(t, e) {
					var r = t.interaction, n = t.pointer, o = t.event, l = t.eventTarget;
					t.duplicate || r.pointerIsDown && !r.pointerWasMoved || (r.pointerIsDown && hr(t), we({
						interaction: r,
						pointer: n,
						event: o,
						eventTarget: l,
						type: "move"
					}, e));
				},
				"interactions:down": function(t, e) {
					(function(r, n) {
						for (var o = r.interaction, l = r.pointer, c = r.event, p = r.eventTarget, h = r.pointerIndex, g = o.pointers[h].hold, d = Yr(p), b = {
							interaction: o,
							pointer: l,
							event: c,
							eventTarget: p,
							type: "hold",
							targets: [],
							path: d,
							node: null
						}, x = 0; x < d.length; x++) b.node = d[x], n.fire("pointerEvents:collect-targets", b);
						if (b.targets.length) {
							for (var E = 1 / 0, M = 0, $ = b.targets; M < $.length; M++) {
								var z = $[M].eventable.options.holdDuration;
								z < E && (E = z);
							}
							g.duration = E, g.timeout = setTimeout(function() {
								we({
									interaction: o,
									eventTarget: p,
									pointer: l,
									event: c,
									type: "hold"
								}, n);
							}, E);
						}
					})(t, e), we(t, e);
				},
				"interactions:up": function(t, e) {
					hr(t), we(t, e), function(r, n) {
						var o = r.interaction, l = r.pointer, c = r.event, p = r.eventTarget;
						o.pointerWasMoved || we({
							interaction: o,
							eventTarget: p,
							pointer: l,
							event: c,
							type: "tap"
						}, n);
					}(t, e);
				},
				"interactions:cancel": function(t, e) {
					hr(t), we(t, e);
				}
			},
			PointerEvent: An,
			fire: we,
			collectEventTargets: Ln,
			defaults: {
				holdDuration: 600,
				ignoreFrom: null,
				allowFrom: null,
				origin: {
					x: 0,
					y: 0
				}
			},
			types: {
				down: !0,
				move: !0,
				up: !0,
				cancel: !0,
				tap: !0,
				doubletap: !0,
				hold: !0
			}
		};
		function we(t, e) {
			var r = t.interaction, n = t.pointer, o = t.event, l = t.eventTarget, c = t.type, p = t.targets, h = p === void 0 ? Ln(t, e) : p, g = new An(c, n, o, l, r, e.now());
			e.fire("pointerEvents:new", { pointerEvent: g });
			for (var d = {
				interaction: r,
				pointer: n,
				event: o,
				eventTarget: l,
				targets: h,
				type: c,
				pointerEvent: g
			}, b = 0; b < h.length; b++) {
				var x = h[b];
				for (var I in x.props || {}) g[I] = x.props[I];
				var E = Ne(x.eventable, x.node);
				if (g._subtractOrigin(E), g.eventable = x.eventable, g.currentTarget = x.node, x.eventable.fire(g), g._addOrigin(E), g.immediatePropagationStopped || g.propagationStopped && b + 1 < h.length && h[b + 1].node !== g.currentTarget) break;
			}
			if (e.fire("pointerEvents:fired", d), c === "tap") {
				var M = g.double ? we({
					interaction: r,
					pointer: n,
					event: o,
					eventTarget: l,
					type: "doubletap"
				}, e) : g;
				r.prevTap = M, r.tapTime = M.timeStamp;
			}
			return g;
		}
		function Ln(t, e) {
			var r = t.interaction, n = t.pointer, o = t.event, l = t.eventTarget, c = t.type, p = r.getPointerIndex(n), h = r.pointers[p];
			if (c === "tap" && (r.pointerWasMoved || !h || h.downTarget !== l)) return [];
			for (var g = Yr(l), d = {
				interaction: r,
				pointer: n,
				event: o,
				eventTarget: l,
				type: c,
				path: g,
				targets: [],
				node: null
			}, b = 0; b < g.length; b++) d.node = g[b], e.fire("pointerEvents:collect-targets", d);
			return c === "hold" && (d.targets = d.targets.filter(function(I) {
				var E, M;
				return I.eventable.options.holdDuration === ((E = r.pointers[p]) == null || (M = E.hold) == null ? void 0 : M.duration);
			})), d.targets;
		}
		function hr(t) {
			var e = t.interaction, r = t.pointerIndex, n = e.pointers[r].hold;
			n && n.timeout && (clearTimeout(n.timeout), n.timeout = null);
		}
		var us = Object.freeze({
			__proto__: null,
			default: Je
		});
		function ps(t) {
			var e = t.interaction;
			e.holdIntervalHandle && (clearInterval(e.holdIntervalHandle), e.holdIntervalHandle = null);
		}
		var ds = {
			id: "pointer-events/holdRepeat",
			install: function(t) {
				t.usePlugin(Je);
				var e = t.pointerEvents;
				e.defaults.holdRepeatInterval = 0, e.types.holdrepeat = t.actions.phaselessTypes.holdrepeat = !0;
			},
			listeners: [
				"move",
				"up",
				"cancel",
				"endall"
			].reduce(function(t, e) {
				return t["pointerEvents:".concat(e)] = ps, t;
			}, {
				"pointerEvents:new": function(t) {
					var e = t.pointerEvent;
					e.type === "hold" && (e.count = (e.count || 0) + 1);
				},
				"pointerEvents:fired": function(t, e) {
					var r = t.interaction, n = t.pointerEvent, o = t.eventTarget, l = t.targets;
					if (n.type === "hold" && l.length) {
						var c = l[0].eventable.options.holdRepeatInterval;
						c <= 0 || (r.holdIntervalHandle = setTimeout(function() {
							e.pointerEvents.fire({
								interaction: r,
								eventTarget: o,
								type: "hold",
								pointer: n,
								event: n
							}, e);
						}, c));
					}
				}
			})
		}, vs = {
			id: "pointer-events/interactableTargets",
			install: function(t) {
				var e = t.Interactable;
				e.prototype.pointerEvents = function(n) {
					return W(this.events.options, n), this;
				};
				var r = e.prototype._backCompatOption;
				e.prototype._backCompatOption = function(n, o) {
					var l = r.call(this, n, o);
					return l === this && (this.events.options[n] = o), l;
				};
			},
			listeners: {
				"pointerEvents:collect-targets": function(t, e) {
					var r = t.targets, n = t.node, o = t.type, l = t.eventTarget;
					e.interactables.forEachMatch(n, function(c) {
						var p = c.events, h = p.options;
						p.types[o] && p.types[o].length && c.testIgnoreAllow(h, n, l) && r.push({
							node: n,
							eventable: p,
							props: { interactable: c }
						});
					});
				},
				"interactable:new": function(t) {
					var e = t.interactable;
					e.events.getRect = function(r) {
						return e.getRect(r);
					};
				},
				"interactable:set": function(t, e) {
					var r = t.interactable, n = t.options;
					W(r.events.options, e.pointerEvents.defaults), W(r.events.options, n.pointerEvents || {});
				}
			}
		};
		if (ee.use(mn), ee.use(Sn), ee.use({
			id: "pointer-events",
			install: function(t) {
				t.usePlugin(us), t.usePlugin(ds), t.usePlugin(vs);
			}
		}), ee.use(jo), ee.use(cs), ee.use(Oo), ee.use(ho), ee.use(vo), ee.use({
			id: "reflow",
			install: function(t) {
				var e = t.Interactable;
				t.actions.phases.reflow = !0, e.prototype.reflow = function(r) {
					return function(n, o, l) {
						for (var c = n.getAllElements(), p = l.window.Promise, h = p ? [] : null, g = function() {
							var b = c[d], x = n.getRect(b);
							if (!x) return 1;
							var I, E = Xe(l.interactions.list, function(z) {
								return z.interacting() && z.interactable === n && z.element === b && z.prepared.name === o.name;
							});
							if (E) E.move(), h && (I = E._reflowPromise || new p(function(z) {
								E._reflowResolve = z;
							}));
							else {
								var M = Gt(x);
								I = function(z, A, N, K, F) {
									var G = z.interactions.new({ pointerType: "reflow" }), te = {
										interaction: G,
										event: F,
										pointer: F,
										eventTarget: N,
										phase: "reflow"
									};
									G.interactable = A, G.element = N, G.prevEvent = F, G.updatePointer(F, F, N, !0), Vr(G.coords.delta), er(G.prepared, K), G._doPhase(te);
									var re = z.window.Promise, se = re ? new re(function(fe) {
										G._reflowResolve = fe;
									}) : void 0;
									return G._reflowPromise = se, G.start(K, A, N), G._interacting ? (G.move(te), G.end(F)) : (G.stop(), G._reflowResolve()), G.removePointer(F, F), se;
								}(l, n, b, o, /* @__PURE__ */ function(z) {
									return {
										coords: z,
										get page() {
											return this.coords.page;
										},
										get client() {
											return this.coords.client;
										},
										get timeStamp() {
											return this.coords.timeStamp;
										},
										get pageX() {
											return this.coords.page.x;
										},
										get pageY() {
											return this.coords.page.y;
										},
										get clientX() {
											return this.coords.client.x;
										},
										get clientY() {
											return this.coords.client.y;
										},
										get pointerId() {
											return this.coords.pointerId;
										},
										get target() {
											return this.coords.target;
										},
										get type() {
											return this.coords.type;
										},
										get pointerType() {
											return this.coords.pointerType;
										},
										get buttons() {
											return this.coords.buttons;
										},
										preventDefault: function() {}
									};
								}({
									page: {
										x: M.x,
										y: M.y
									},
									client: {
										x: M.x,
										y: M.y
									},
									timeStamp: l.now()
								}));
							}
							h && h.push(I);
						}, d = 0; d < c.length && !g(); d++);
						return h && p.all(h).then(function() {
							return n;
						});
					}(this, r, t);
				};
			},
			listeners: { "interactions:stop": function(t, e) {
				var r = t.interaction;
				r.pointerType === "reflow" && (r._reflowResolve && r._reflowResolve(), function(n, o) {
					n.splice(n.indexOf(o), 1);
				}(e.interactions.list, r));
			} }
		}), ee.default = ee, v(a) === "object" && a) try {
			a.exports = ee;
		} catch {}
		return ee.default = ee, ee;
	});
})(Et, Et.exports);
var ws = Et.exports;
var dr = /* @__PURE__ */ rt(ws);
var Si = { exports: {} };
(function(a, i) {
	(function(s, u) {
		a.exports = u();
	})(Ie, function() {
		var s = "minute", u = /[+-]\d\d(?::?\d\d)?/g, v = /([+-]|\d\d)/g;
		return function(f, m, y) {
			var S = m.prototype;
			y.utc = function(O) {
				return new m({
					date: O,
					utc: !0,
					args: arguments
				});
			}, S.utc = function(O) {
				var k = y(this.toDate(), {
					locale: this.$L,
					utc: !0
				});
				return O ? k.add(this.utcOffset(), s) : k;
			}, S.local = function() {
				return y(this.toDate(), {
					locale: this.$L,
					utc: !1
				});
			};
			var C = S.parse;
			S.parse = function(O) {
				O.utc && (this.$u = !0), this.$utils().u(O.$offset) || (this.$offset = O.$offset), C.call(this, O);
			};
			var D = S.init;
			S.init = function() {
				if (this.$u) {
					var O = this.$d;
					this.$y = O.getUTCFullYear(), this.$M = O.getUTCMonth(), this.$D = O.getUTCDate(), this.$W = O.getUTCDay(), this.$H = O.getUTCHours(), this.$m = O.getUTCMinutes(), this.$s = O.getUTCSeconds(), this.$ms = O.getUTCMilliseconds();
				} else D.call(this);
			};
			var R = S.utcOffset;
			S.utcOffset = function(O, k) {
				var L = this.$utils().u;
				if (L(O)) return this.$u ? 0 : L(this.$offset) ? R.call(this) : this.$offset;
				if (typeof O == "string" && (O = function(V) {
					V === void 0 && (V = "");
					var le = V.match(u);
					if (!le) return null;
					var w = ("" + le[0]).match(v) || [
						"-",
						0,
						0
					], ce = w[0], Me = 60 * +w[1] + +w[2];
					return Me === 0 ? 0 : ce === "+" ? Me : -Me;
				}(O), O === null)) return this;
				var H = Math.abs(O) <= 16 ? 60 * O : O;
				if (H === 0) return this.utc(k);
				var X = this.clone();
				if (k) return X.$offset = H, X.$u = !1, X;
				var B = this.$u ? this.toDate().getTimezoneOffset() : -1 * this.utcOffset();
				return (X = this.local().add(H + B, s)).$offset = H, X.$x.$localOffset = B, X;
			};
			var T = S.format;
			S.format = function(O) {
				var k = O || (this.$u ? "YYYY-MM-DDTHH:mm:ss[Z]" : "");
				return T.call(this, k);
			}, S.valueOf = function() {
				var O = this.$utils().u(this.$offset) ? 0 : this.$offset + (this.$x.$localOffset || this.$d.getTimezoneOffset());
				return this.$d.valueOf() - 6e4 * O;
			}, S.isUTC = function() {
				return !!this.$u;
			}, S.toISOString = function() {
				return this.toDate().toISOString();
			}, S.toString = function() {
				return this.toDate().toUTCString();
			};
			var P = S.toDate;
			S.toDate = function(O) {
				return O === "s" && this.$offset ? y(this.format("YYYY-MM-DD HH:mm:ss:SSS")).toDate() : P.call(this);
			};
			var _ = S.diff;
			S.diff = function(O, k, L) {
				if (O && this.$u === O.$u) return _.call(this, O, k, L);
				var H = this.local(), X = y(O).local();
				return _.call(H, X, k, L);
			};
		};
	});
})(Si);
var xs = Si.exports;
var Ss = /* @__PURE__ */ rt(xs);
function Os() {
	this.__data__ = [], this.size = 0;
}
var Cs = Os;
function Es(a, i) {
	return a === i || a !== a && i !== i;
}
var Oi = Es;
var _s = Oi;
function Ps(a, i) {
	for (var s = a.length; s--;) if (_s(a[s][0], i)) return s;
	return -1;
}
var Dt = Ps;
var Is = Dt;
var Rs = Array.prototype.splice;
function Ds(a) {
	var i = this.__data__, s = Is(i, a);
	if (s < 0) return !1;
	return s == i.length - 1 ? i.pop() : Rs.call(i, s, 1), --this.size, !0;
}
var ks = Ds;
var zs = Dt;
function $s(a) {
	var i = this.__data__, s = zs(i, a);
	return s < 0 ? void 0 : i[s][1];
}
var js = $s;
var As = Dt;
function Ls(a) {
	return As(this.__data__, a) > -1;
}
var Hs = Ls;
var Ws = Dt;
function Fs(a, i) {
	var s = this.__data__, u = Ws(s, a);
	return u < 0 ? (++this.size, s.push([a, i])) : s[u][1] = i, this;
}
var Us = Fs;
var Ns = Cs;
var Gs = ks;
var Ys = js;
var Ks = Hs;
var Xs = Us;
function je(a) {
	var i = -1, s = a == null ? 0 : a.length;
	for (this.clear(); ++i < s;) {
		var u = a[i];
		this.set(u[0], u[1]);
	}
}
je.prototype.clear = Ns;
je.prototype.delete = Gs;
je.prototype.get = Ys;
je.prototype.has = Ks;
je.prototype.set = Xs;
var kt = je;
var Bs = kt;
function Vs() {
	this.__data__ = new Bs(), this.size = 0;
}
var qs = Vs;
function Zs(a) {
	var i = this.__data__, s = i.delete(a);
	return this.size = i.size, s;
}
var Js = Zs;
function Qs(a) {
	return this.__data__.get(a);
}
var ea = Qs;
function ta(a) {
	return this.__data__.has(a);
}
var ra = ta;
var Ci = typeof Ie == "object" && Ie && Ie.Object === Object && Ie;
var ia = Ci;
var oa = typeof self == "object" && self && self.Object === Object && self;
var ge = ia || oa || Function("return this")();
var _r = ge.Symbol;
var Wn = _r;
var Ei = Object.prototype;
var ca = Ei.hasOwnProperty;
var ua = Ei.toString;
var et = Wn ? Wn.toStringTag : void 0;
function pa(a) {
	var i = ca.call(a, et), s = a[et];
	try {
		a[et] = void 0;
		var u = !0;
	} catch {}
	var v = ua.call(a);
	return u && (i ? a[et] = s : delete a[et]), v;
}
var ha = pa;
var fa = Object.prototype.toString;
function va(a) {
	return fa.call(a);
}
var ga = va;
var Fn = _r;
var ma = ha;
var ba = ga;
var ya = "[object Null]";
var Ta = "[object Undefined]";
var Un = Fn ? Fn.toStringTag : void 0;
function wa(a) {
	return a == null ? a === void 0 ? Ta : ya : Un && Un in Object(a) ? ma(a) : ba(a);
}
var zt = wa;
function xa(a) {
	var i = typeof a;
	return a != null && (i == "object" || i == "function");
}
var _i = xa;
var Sa = zt;
var Oa = _i;
var Ca = "[object AsyncFunction]";
var Ea = "[object Function]";
var _a = "[object GeneratorFunction]";
var Pa = "[object Proxy]";
function Ia(a) {
	if (!Oa(a)) return !1;
	var i = Sa(a);
	return i == Ea || i == _a || i == Ca || i == Pa;
}
var Pi = Ia;
var fr = ge["__core-js_shared__"];
var Nn = function() {
	var a = /[^.]+$/.exec(fr && fr.keys && fr.keys.IE_PROTO || "");
	return a ? "Symbol(src)_1." + a : "";
}();
function ka(a) {
	return !!Nn && Nn in a;
}
var za = ka;
var ja = Function.prototype.toString;
function Aa(a) {
	if (a != null) {
		try {
			return ja.call(a);
		} catch {}
		try {
			return a + "";
		} catch {}
	}
	return "";
}
var Ii = Aa;
var La = Pi;
var Ha = za;
var Wa = _i;
var Fa = Ii;
var Ua = /[\\^$.*+?()[\]{}|]/g;
var Na = /^\[object .+?Constructor\]$/;
var Ga = Function.prototype;
var Ya = Object.prototype;
var Ka = Ga.toString;
var Xa = Ya.hasOwnProperty;
var Ba = RegExp("^" + Ka.call(Xa).replace(Ua, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
function Va(a) {
	if (!Wa(a) || Ha(a)) return !1;
	return (La(a) ? Ba : Na).test(Fa(a));
}
var qa = Va;
function Za(a, i) {
	return a == null ? void 0 : a[i];
}
var Ja = Za;
var Qa = qa;
var el = Ja;
function tl(a, i) {
	var s = el(a, i);
	return Qa(s) ? s : void 0;
}
var Ae = tl;
var Pr = Ae(ge, "Map");
var $t = Ae(Object, "create");
var Gn = $t;
function al() {
	this.__data__ = Gn ? Gn(null) : {}, this.size = 0;
}
var ll = al;
function cl(a) {
	var i = this.has(a) && delete this.__data__[a];
	return this.size -= i ? 1 : 0, i;
}
var ul = cl;
var pl = $t;
var hl = "__lodash_hash_undefined__";
var fl = Object.prototype.hasOwnProperty;
function vl(a) {
	var i = this.__data__;
	if (pl) {
		var s = i[a];
		return s === hl ? void 0 : s;
	}
	return fl.call(i, a) ? i[a] : void 0;
}
var gl = vl;
var ml = $t;
var yl = Object.prototype.hasOwnProperty;
function Tl(a) {
	var i = this.__data__;
	return ml ? i[a] !== void 0 : yl.call(i, a);
}
var wl = Tl;
var xl = $t;
var Sl = "__lodash_hash_undefined__";
function Ol(a, i) {
	var s = this.__data__;
	return this.size += this.has(a) ? 0 : 1, s[a] = xl && i === void 0 ? Sl : i, this;
}
var Cl = Ol;
var El = ll;
var _l = ul;
var Pl = gl;
var Il = wl;
var Ml = Cl;
function Le(a) {
	var i = -1, s = a == null ? 0 : a.length;
	for (this.clear(); ++i < s;) {
		var u = a[i];
		this.set(u[0], u[1]);
	}
}
Le.prototype.clear = El;
Le.prototype.delete = _l;
Le.prototype.get = Pl;
Le.prototype.has = Il;
Le.prototype.set = Ml;
var Yn = Le;
var Dl = kt;
var kl = Pr;
function zl() {
	this.size = 0, this.__data__ = {
		hash: new Yn(),
		map: new (kl || Dl)(),
		string: new Yn()
	};
}
var $l = zl;
function jl(a) {
	var i = typeof a;
	return i == "string" || i == "number" || i == "symbol" || i == "boolean" ? a !== "__proto__" : a === null;
}
var Ll = jl;
function Hl(a, i) {
	var s = a.__data__;
	return Ll(i) ? s[typeof i == "string" ? "string" : "hash"] : s.map;
}
var jt = Hl;
var Wl = jt;
function Fl(a) {
	var i = Wl(this, a).delete(a);
	return this.size -= i ? 1 : 0, i;
}
var Ul = Fl;
var Nl = jt;
function Gl(a) {
	return Nl(this, a).get(a);
}
var Yl = Gl;
var Kl = jt;
function Xl(a) {
	return Kl(this, a).has(a);
}
var Bl = Xl;
var Vl = jt;
function ql(a, i) {
	var s = Vl(this, a), u = s.size;
	return s.set(a, i), this.size += s.size == u ? 0 : 1, this;
}
var Zl = ql;
var Jl = $l;
var Ql = Ul;
var ec = Yl;
var tc = Bl;
var rc = Zl;
function He(a) {
	var i = -1, s = a == null ? 0 : a.length;
	for (this.clear(); ++i < s;) {
		var u = a[i];
		this.set(u[0], u[1]);
	}
}
He.prototype.clear = Jl;
He.prototype.delete = Ql;
He.prototype.get = ec;
He.prototype.has = tc;
He.prototype.set = rc;
var Mi = He;
var nc = kt;
var ic = Pr;
var oc = Mi;
var sc = 200;
function ac(a, i) {
	var s = this.__data__;
	if (s instanceof nc) {
		var u = s.__data__;
		if (!ic || u.length < sc - 1) return u.push([a, i]), this.size = ++s.size, this;
		s = this.__data__ = new oc(u);
	}
	return s.set(a, i), this.size = s.size, this;
}
var lc = ac;
var cc = kt;
var uc = qs;
var pc = Js;
var hc = ea;
var dc = ra;
var fc = lc;
function We(a) {
	var i = this.__data__ = new cc(a);
	this.size = i.size;
}
We.prototype.clear = uc;
We.prototype.delete = pc;
We.prototype.get = hc;
We.prototype.has = dc;
We.prototype.set = fc;
var vc = We;
var gc = "__lodash_hash_undefined__";
function mc(a) {
	return this.__data__.set(a, gc), this;
}
var bc = mc;
function yc(a) {
	return this.__data__.has(a);
}
var Tc = yc;
var wc = Mi;
var xc = bc;
var Sc = Tc;
function _t(a) {
	var i = -1, s = a == null ? 0 : a.length;
	for (this.__data__ = new wc(); ++i < s;) this.add(a[i]);
}
_t.prototype.add = _t.prototype.push = xc;
_t.prototype.has = Sc;
var Oc = _t;
function Cc(a, i) {
	for (var s = -1, u = a == null ? 0 : a.length; ++s < u;) if (i(a[s], s, a)) return !0;
	return !1;
}
var Ec = Cc;
function _c(a, i) {
	return a.has(i);
}
var Pc = _c;
var Ic = Oc;
var Mc = Ec;
var Rc = Pc;
var Dc = 1;
var kc = 2;
function zc(a, i, s, u, v, f) {
	var m = s & Dc, y = a.length, S = i.length;
	if (y != S && !(m && S > y)) return !1;
	var C = f.get(a), D = f.get(i);
	if (C && D) return C == i && D == a;
	var R = -1, T = !0, P = s & kc ? new Ic() : void 0;
	for (f.set(a, i), f.set(i, a); ++R < y;) {
		var _ = a[R], O = i[R];
		if (u) var k = m ? u(O, _, R, i, a, f) : u(_, O, R, a, i, f);
		if (k !== void 0) {
			if (k) continue;
			T = !1;
			break;
		}
		if (P) {
			if (!Mc(i, function(L, H) {
				if (!Rc(P, H) && (_ === L || v(_, L, s, u, f))) return P.push(H);
			})) {
				T = !1;
				break;
			}
		} else if (!(_ === O || v(_, O, s, u, f))) {
			T = !1;
			break;
		}
	}
	return f.delete(a), f.delete(i), T;
}
var Ri = zc;
var Ac = ge.Uint8Array;
function Lc(a) {
	var i = -1, s = Array(a.size);
	return a.forEach(function(u, v) {
		s[++i] = [v, u];
	}), s;
}
var Hc = Lc;
function Wc(a) {
	var i = -1, s = Array(a.size);
	return a.forEach(function(u) {
		s[++i] = u;
	}), s;
}
var Fc = Wc;
var Kn = _r;
var Xn = Ac;
var Uc = Oi;
var Nc = Ri;
var Gc = Hc;
var Yc = Fc;
var Kc = 1;
var Xc = 2;
var Bc = "[object Boolean]";
var Vc = "[object Date]";
var qc = "[object Error]";
var Zc = "[object Map]";
var Jc = "[object Number]";
var Qc = "[object RegExp]";
var eu = "[object Set]";
var tu = "[object String]";
var ru = "[object Symbol]";
var nu = "[object ArrayBuffer]";
var iu = "[object DataView]";
var Bn = Kn ? Kn.prototype : void 0;
var vr = Bn ? Bn.valueOf : void 0;
function ou(a, i, s, u, v, f, m) {
	switch (s) {
		case iu:
			if (a.byteLength != i.byteLength || a.byteOffset != i.byteOffset) return !1;
			a = a.buffer, i = i.buffer;
		case nu: return !(a.byteLength != i.byteLength || !f(new Xn(a), new Xn(i)));
		case Bc:
		case Vc:
		case Jc: return Uc(+a, +i);
		case qc: return a.name == i.name && a.message == i.message;
		case Qc:
		case tu: return a == i + "";
		case Zc: var y = Gc;
		case eu:
			var S = u & Kc;
			if (y || (y = Yc), a.size != i.size && !S) return !1;
			var C = m.get(a);
			if (C) return C == i;
			u |= Xc, m.set(a, i);
			var D = Nc(y(a), y(i), u, v, f, m);
			return m.delete(a), D;
		case ru: if (vr) return vr.call(a) == vr.call(i);
	}
	return !1;
}
var su = ou;
function au(a, i) {
	for (var s = -1, u = i.length, v = a.length; ++s < u;) a[v + s] = i[s];
	return a;
}
var lu = au;
var Ir = Array.isArray;
var uu = lu;
var pu = Ir;
function hu(a, i, s) {
	var u = i(a);
	return pu(a) ? u : uu(u, s(a));
}
var du = hu;
function fu(a, i) {
	for (var s = -1, u = a == null ? 0 : a.length, v = 0, f = []; ++s < u;) {
		var m = a[s];
		i(m, s, a) && (f[v++] = m);
	}
	return f;
}
var vu = fu;
function gu() {
	return [];
}
var mu = gu;
var bu = vu;
var yu = mu;
var wu = Object.prototype.propertyIsEnumerable;
var Vn = Object.getOwnPropertySymbols;
var Su = Vn ? function(a) {
	return a == null ? [] : (a = Object(a), bu(Vn(a), function(i) {
		return wu.call(a, i);
	}));
} : yu;
function Ou(a, i) {
	for (var s = -1, u = Array(a); ++s < a;) u[s] = i(s);
	return u;
}
var Cu = Ou;
function Eu(a) {
	return a != null && typeof a == "object";
}
var At = Eu;
var _u = zt;
var Pu = At;
var Iu = "[object Arguments]";
function Mu(a) {
	return Pu(a) && _u(a) == Iu;
}
var qn = Mu;
var Du = At;
var Di = Object.prototype;
var ku = Di.hasOwnProperty;
var zu = Di.propertyIsEnumerable;
var ju = qn(/* @__PURE__ */ function() {
	return arguments;
}()) ? qn : function(a) {
	return Du(a) && ku.call(a, "callee") && !zu.call(a, "callee");
};
var Pt = { exports: {} };
function Au() {
	return !1;
}
var Lu = Au;
Pt.exports;
(function(a, i) {
	var s = ge, u = Lu, v = i && !i.nodeType && i, f = v && a && !a.nodeType && a, y = f && f.exports === v ? s.Buffer : void 0;
	a.exports = (y ? y.isBuffer : void 0) || u;
})(Pt, Pt.exports);
var ki = Pt.exports;
var Hu = 9007199254740991;
var Wu = /^(?:0|[1-9]\d*)$/;
function Fu(a, i) {
	var s = typeof a;
	return i = i ?? Hu, !!i && (s == "number" || s != "symbol" && Wu.test(a)) && a > -1 && a % 1 == 0 && a < i;
}
var Uu = Fu;
var Nu = 9007199254740991;
function Gu(a) {
	return typeof a == "number" && a > -1 && a % 1 == 0 && a <= Nu;
}
var zi = Gu;
var Yu = zt;
var Ku = zi;
var Xu = At;
var Bu = "[object Arguments]";
var Vu = "[object Array]";
var qu = "[object Boolean]";
var Zu = "[object Date]";
var Ju = "[object Error]";
var Qu = "[object Function]";
var ep = "[object Map]";
var tp = "[object Number]";
var rp = "[object Object]";
var np = "[object RegExp]";
var ip = "[object Set]";
var op = "[object String]";
var sp = "[object WeakMap]";
var ap = "[object ArrayBuffer]";
var lp = "[object DataView]";
var cp = "[object Float32Array]";
var up = "[object Float64Array]";
var pp = "[object Int8Array]";
var hp = "[object Int16Array]";
var dp = "[object Int32Array]";
var fp = "[object Uint8Array]";
var vp = "[object Uint8ClampedArray]";
var gp = "[object Uint16Array]";
var mp = "[object Uint32Array]";
var q = {};
q[cp] = q[up] = q[pp] = q[hp] = q[dp] = q[fp] = q[vp] = q[gp] = q[mp] = !0;
q[Bu] = q[Vu] = q[ap] = q[qu] = q[lp] = q[Zu] = q[Ju] = q[Qu] = q[ep] = q[tp] = q[rp] = q[np] = q[ip] = q[op] = q[sp] = !1;
function bp(a) {
	return Xu(a) && Ku(a.length) && !!q[Yu(a)];
}
var yp = bp;
function Tp(a) {
	return function(i) {
		return a(i);
	};
}
var wp = Tp;
var It = { exports: {} };
It.exports;
(function(a, i) {
	var s = Ci, u = i && !i.nodeType && i, v = u && a && !a.nodeType && a, m = v && v.exports === u && s.process;
	a.exports = function() {
		try {
			return v && v.require && v.require("util").types || m && m.binding && m.binding("util");
		} catch {}
	}();
})(It, It.exports);
var xp = It.exports;
var Sp = yp;
var Op = wp;
var Zn = xp;
var Jn = Zn && Zn.isTypedArray;
var $i = Jn ? Op(Jn) : Sp;
var Ep = Cu;
var _p = ju;
var Pp = Ir;
var Ip = ki;
var Mp = Uu;
var Rp = $i;
var kp = Object.prototype.hasOwnProperty;
function zp(a, i) {
	var s = Pp(a), u = !s && _p(a), v = !s && !u && Ip(a), f = !s && !u && !v && Rp(a), m = s || u || v || f, y = m ? Ep(a.length, String) : [], S = y.length;
	for (var C in a) (i || kp.call(a, C)) && !(m && (C == "length" || v && (C == "offset" || C == "parent") || f && (C == "buffer" || C == "byteLength" || C == "byteOffset") || Mp(C, S))) && y.push(C);
	return y;
}
var $p = zp;
var jp = Object.prototype;
function Ap(a) {
	var i = a && a.constructor;
	return a === (typeof i == "function" && i.prototype || jp);
}
var Lp = Ap;
function Hp(a, i) {
	return function(s) {
		return a(i(s));
	};
}
var Np = Hp(Object.keys, Object);
var Gp = Lp;
var Yp = Np;
var Xp = Object.prototype.hasOwnProperty;
function Bp(a) {
	if (!Gp(a)) return Yp(a);
	var i = [];
	for (var s in Object(a)) Xp.call(a, s) && s != "constructor" && i.push(s);
	return i;
}
var Vp = Bp;
var qp = Pi;
var Zp = zi;
function Jp(a) {
	return a != null && Zp(a.length) && !qp(a);
}
var Qp = Jp;
var eh = $p;
var th = Vp;
var rh = Qp;
function nh(a) {
	return rh(a) ? eh(a) : th(a);
}
var ih = nh;
var oh = du;
var sh = Su;
var ah = ih;
function lh(a) {
	return oh(a, ah, sh);
}
var Qn = lh;
var uh = 1;
var hh = Object.prototype.hasOwnProperty;
function dh(a, i, s, u, v, f) {
	var m = s & uh, y = Qn(a), S = y.length;
	if (S != Qn(i).length && !m) return !1;
	for (var R = S; R--;) {
		var T = y[R];
		if (!(m ? T in i : hh.call(i, T))) return !1;
	}
	var P = f.get(a), _ = f.get(i);
	if (P && _) return P == i && _ == a;
	var O = !0;
	f.set(a, i), f.set(i, a);
	for (var k = m; ++R < S;) {
		T = y[R];
		var L = a[T], H = i[T];
		if (u) var X = m ? u(H, L, T, i, a, f) : u(L, H, T, a, i, f);
		if (!(X === void 0 ? L === H || v(L, H, s, u, f) : X)) {
			O = !1;
			break;
		}
		k || (k = T == "constructor");
	}
	if (O && !k) {
		var B = a.constructor, V = i.constructor;
		B != V && "constructor" in a && "constructor" in i && !(typeof B == "function" && B instanceof B && typeof V == "function" && V instanceof V) && (O = !1);
	}
	return f.delete(a), f.delete(i), O;
}
var fh = dh;
var bh = Ae(ge, "DataView");
var xh = Ae(ge, "Promise");
var Eh = Ae(ge, "Set");
var Mh = Ae(ge, "WeakMap");
var mr = bh;
var br = Pr;
var yr = xh;
var Tr = Eh;
var wr = Mh;
var ji = zt;
var Fe = Ii;
var ei = "[object Map]";
var Rh = "[object Object]";
var ti = "[object Promise]";
var ri = "[object Set]";
var ni = "[object WeakMap]";
var ii = "[object DataView]";
var Dh = Fe(mr);
var kh = Fe(br);
var zh = Fe(yr);
var $h = Fe(Tr);
var jh = Fe(wr);
var _e = ji;
(mr && _e(new mr(/* @__PURE__ */ new ArrayBuffer(1))) != ii || br && _e(new br()) != ei || yr && _e(yr.resolve()) != ti || Tr && _e(new Tr()) != ri || wr && _e(new wr()) != ni) && (_e = function(a) {
	var i = ji(a), s = i == Rh ? a.constructor : void 0, u = s ? Fe(s) : "";
	if (u) switch (u) {
		case Dh: return ii;
		case kh: return ei;
		case zh: return ti;
		case $h: return ri;
		case jh: return ni;
	}
	return i;
});
var Ah = _e;
var gr = vc;
var Lh = Ri;
var Hh = su;
var Wh = fh;
var oi = Ah;
var si = Ir;
var ai = ki;
var Fh = $i;
var Uh = 1;
var li = "[object Arguments]";
var ci = "[object Array]";
var yt = "[object Object]";
var ui = Object.prototype.hasOwnProperty;
function Gh(a, i, s, u, v, f) {
	var m = si(a), y = si(i), S = m ? ci : oi(a), C = y ? ci : oi(i);
	S = S == li ? yt : S, C = C == li ? yt : C;
	var D = S == yt, R = C == yt, T = S == C;
	if (T && ai(a)) {
		if (!ai(i)) return !1;
		m = !0, D = !1;
	}
	if (T && !D) return f || (f = new gr()), m || Fh(a) ? Lh(a, i, s, u, v, f) : Hh(a, i, S, s, u, v, f);
	if (!(s & Uh)) {
		var P = D && ui.call(a, "__wrapped__"), _ = R && ui.call(i, "__wrapped__");
		if (P || _) {
			var O = P ? a.value() : a, k = _ ? i.value() : i;
			return f || (f = new gr()), v(O, k, s, u, f);
		}
	}
	return T ? (f || (f = new gr()), Wh(a, i, s, u, v, f)) : !1;
}
var Kh = Gh;
var pi = At;
function Ai(a, i, s, u, v) {
	return a === i ? !0 : a == null || i == null || !pi(a) && !pi(i) ? a !== a && i !== i : Kh(a, i, s, u, Ai, v);
}
var Bh = Ai;
function Vh(a, i) {
	return Bh(a, i);
}
var xr = /* @__PURE__ */ rt(Vh);
function Y(a, i) {
	return typeof a.get == "function" ? a.get(i) : a[i];
}
function hi(a) {
	return typeof a.count == "function" ? a.count() : a.length;
}
function tt(a, i) {
	return hi(a) === hi(i) && a.every((s, u) => s === Y(i, u.toString()));
}
function Zh(a, i) {
	const s = {};
	return a.forEach((u) => {
		s[u[i]] = u;
	}), s;
}
function wt() {}
function Pe(...a) {
	return (i, ...s) => {
		i.preventDefault(), a.forEach((u) => u && u(i, ...s));
	};
}
function Li({ item: a, itemContext: i, getItemProps: s, getResizeProps: u }) {
	const { left: v, right: f } = u(), { key: m, ref: y, ...S } = s(a.itemProps ?? {}), { useResizeHandle: C } = i;
	return (0, import_react.createElement)("div", {
		...S,
		ref: y,
		key: `${m}-outer`
	}, C ? (0, import_react.createElement)("div", {
		...v,
		key: `${m}-lr`
	}) : null, (0, import_jsx_runtime.jsx)("div", {
		className: "rct-item-content",
		style: { maxHeight: `${i.dimensions.height}` },
		children: i.title
	}, `${m}-content`), C ? (0, import_react.createElement)("div", {
		...f,
		key: `${m}-rr`
	}) : null);
}
function Mt(a, i, s) {
	return (i - a) / s;
}
function Rt(a, i, s, u) {
	const v = s / (i - a);
	return (u - a) * v;
}
function Mr(a, i, s, u) {
	return (i - a) / s * u + a;
}
function Rr(a, i, s, u, v) {
	let f = (0, import_dayjs_min.default)(a).startOf(s);
	if (u[s] && u[s] > 1) {
		const m = f.get(s);
		f = f.set(s, m - m % u[s]);
	}
	for (; f.valueOf() < i;) {
		let m = (0, import_dayjs_min.default)(f).add(u[s] || 1, s).startOf(s);
		m.valueOf() <= f.valueOf() && (m = m.add(u[s] || 1, s)), v(f, m), f = m;
	}
}
var Sr = 17;
function xt(a, i, s) {
	const u = {
		second: 1e3,
		minute: 60,
		hour: 60,
		day: 24,
		month: 30,
		year: 12
	};
	let v = "year", f = a;
	return Object.keys(u).some((m) => {
		const y = m;
		f = f / u[y];
		if (f / s[y] < i / (s[y] && s[y] > 1 ? 51 : Sr)) return v = m, !0;
	}), v;
}
var Or = {
	second: "minute",
	minute: "hour",
	hour: "day",
	day: "month",
	month: "year",
	year: "year"
};
function Dr(a) {
	if (!Or[a]) throw new Error(`unit ${a} is not acceptable`);
	return Or[a];
}
function Hi({ itemTimeStart: a, itemTimeEnd: i, dragTime: s, isDragging: u, isResizing: v, resizingEdge: f, resizeTime: m }) {
	const y = i - a;
	return [u && s ? s : v && f === "left" && m ? m : a, u && s ? s + y : v && f === "right" && m ? m : i];
}
function Wi({ itemTimeStart: a, itemTimeEnd: i, canvasTimeStart: s, canvasTimeEnd: u, canvasWidth: v }) {
	const f = i - a, m = Math.max(a, s), y = Math.min(i, u), S = Rt(s, u, v, m), D = Rt(s, u, v, y) - S;
	return {
		left: S,
		width: Math.max(D, 3),
		collisionLeft: a,
		collisionWidth: f
	};
}
function kr(a, i) {
	const { groupIdKey: s } = i, u = {};
	for (let v = 0; v < a.length; v++) u[Y(a[v], s)] = {
		index: v,
		group: a[v]
	};
	return u;
}
function Fi(a, i) {
	var v, f;
	const s = {}, u = Object.keys(i);
	for (let m = 0; m < u.length; m++) {
		const y = i[u[m]];
		s[m] = {
			index: y.index,
			group: y.group,
			items: []
		};
	}
	for (let m = 0; m < a.length; m++) if (a[m].dimensions !== void 0 && ((v = a[m].dimensions) == null ? void 0 : v.order) !== void 0) {
		const y = s[((f = a[m].dimensions) == null ? void 0 : f.order.index) ?? 0];
		y && y.items.push(a[m]);
	}
	return s;
}
function zr(a, i, s, u) {
	const { itemTimeStartKey: v, itemTimeEndKey: f } = u;
	return a.filter((m) => {
		const y = (0, import_dayjs_min.default)(Y(m, v)).valueOf() <= s, S = (0, import_dayjs_min.default)(Y(m, f)).valueOf() >= i;
		return y && S;
	});
}
var Jh = .001;
function Ui(a, i, s, u = Jh) {
	return a.collisionLeft + u < i.collisionLeft + i.collisionWidth && a.collisionLeft + a.collisionWidth - u > i.collisionLeft && a.top - s + u < i.top + i.height && a.top + a.height + s - u > i.top;
}
function Ni(a, i, s, u, v, f, m) {
	let y = u;
	const S = m ?? (a - i.dimensions.height) / 2;
	if (i.dimensions.stack && i.dimensions.top === null) {
		i.dimensions.top = v + S, y = Math.max(y, a, i.dimensions.height + S * 2);
		do {
			var C = null;
			for (let D = f - 1, R = 0; D >= R; D--) {
				const T = s[D];
				if (T.dimensions.top !== null && T.dimensions.stack && Ui(i.dimensions, T.dimensions, S)) {
					C = T;
					break;
				}
			}
			C != null && (i.dimensions.top = C.dimensions.top + C.dimensions.height + S * (m !== void 0 ? 1 : 2), y = Math.max(y, i.dimensions.top + i.dimensions.height + S - v));
		} while (C);
	}
	return {
		groupHeight: y,
		verticalMargin: S,
		itemTop: i.dimensions.top
	};
}
function Gi(a, i, s, u, v) {
	var m, y;
	const f = v ?? (a - (((m = i.dimensions) == null ? void 0 : m.height) ?? 1)) / 2;
	return i.dimensions && i.dimensions.top === null && (i.dimensions.top = u + f, s = Math.max(s, a, i.dimensions.height + f)), {
		groupHeight: s,
		verticalMargin: 0,
		itemTop: ((y = i.dimensions) == null ? void 0 : y.top) ?? 0
	};
}
function di(a = []) {
	return a.reduce((i, s) => i + s, 0);
}
function Yi(a, i, s, u, v) {
	const f = [], m = [], y = Fi(a, i);
	for (const S in y) {
		const { items: D, group: R } = y[S], T = di(f), { groupHeight: _ } = Ki(D, R.stackItems !== void 0 ? R.stackItems : u, s, T, v);
		m.push(T), R.height ? f.push(R.height) : f.push(Math.max(_, s));
	}
	return {
		height: di(f),
		groupHeights: f,
		groupTops: m
	};
}
function Ki(a, i, s, u, v) {
	let f = 0, m = 0;
	for (let y = 0; y < a.length; y++) {
		const S = i ? Ni(s, a[y], a, f, u, y, v) : Gi(s, a[y], f, u, v);
		f = S.groupHeight, m = S.verticalMargin;
	}
	return {
		groupHeight: f,
		verticalMargin: m
	};
}
function $e(a, i, s, u, v, f, m, y, S, C, D, R, T, P, _, O) {
	const L = zr(a, u, v, f).map((w) => Bi({
		item: w,
		keys: f,
		draggingItem: C,
		resizingItem: D,
		dragTime: R,
		resizingEdge: T,
		resizeTime: P,
		groups: i,
		newGroupOrder: _
	}));
	if (i.length === 0) return {
		dimensionItems: [],
		height: 0,
		groupHeights: [],
		groupTops: []
	};
	const H = kr(i, f), X = L.map((w) => Xi({
		item: w,
		keys: f,
		canvasTimeStart: u,
		canvasTimeEnd: v,
		canvasWidth: s,
		groupOrders: H,
		lineHeight: m,
		itemHeightRatio: y,
		itemVerticalGap: O
	})).filter((w) => !!w), { height: B, groupHeights: V, groupTops: le } = Yi(X, H, m, S, O);
	return {
		dimensionItems: X,
		height: B,
		groupHeights: V,
		groupTops: le
	};
}
function ve(a, i) {
	return a * i;
}
function Xi({ item: a, keys: i, canvasTimeStart: s, canvasTimeEnd: u, canvasWidth: v, groupOrders: f, lineHeight: m, itemHeightRatio: y, itemVerticalGap: S }) {
	const C = Y(a, i.itemIdKey), D = Wi({
		itemTimeStart: Y(a, i.itemTimeStartKey),
		itemTimeEnd: Y(a, i.itemTimeEndKey),
		canvasTimeStart: s,
		canvasTimeEnd: u,
		canvasWidth: v
	});
	if (D) return D.top = null, D.order = f[Y(a, i.itemGroupKey)], D.stack = !a.isOverlay, D.height = (a.height || m) * (typeof S > "u" ? y : 1), {
		id: C,
		dimensions: D
	};
}
function Bi({ item: a, keys: i, draggingItem: s, resizingItem: u, dragTime: v, resizingEdge: f, resizeTime: m, groups: y, newGroupOrder: S }) {
	if (!u && !s) return a;
	const C = Y(a, i.itemIdKey), D = C === s, R = C === u, [T, P] = Hi({
		itemTimeStart: Y(a, i.itemTimeStartKey),
		itemTimeEnd: Y(a, i.itemTimeEndKey),
		isDragging: D,
		isResizing: R,
		dragTime: v,
		resizingEdge: f,
		resizeTime: m
	});
	return {
		...a,
		[i.itemTimeStartKey]: T,
		[i.itemTimeEndKey]: P,
		[i.itemGroupKey]: D ? Y(y[S], i.groupIdKey) : Y(a, i.itemGroupKey)
	};
}
function $r(a, i, s) {
	const u = i - a, v = a - u * (s - 1) / 2;
	return [v, v + u * s];
}
function Cr(a, i, s, u, v, f, m) {
	const y = f.buffer, S = m.canvasTimeStart, C = m.canvasTimeEnd, D = m.visibleTimeEnd - m.visibleTimeStart, R = i - a, T = {
		...m,
		visibleTimeStart: a,
		visibleTimeEnd: i
	}, P = D * (y - 1) * .25;
	if (R !== D || a <= S + P || i >= C - P || s) {
		const [O, k] = $r(a, i, y);
		T.canvasTimeStart = O, T.canvasTimeEnd = k;
		const L = {
			...m,
			...T
		}, H = ve(L.width, f.buffer);
		Object.assign(T, $e(u, v, H, L.canvasTimeStart, L.canvasTimeEnd, f.keys, f.lineHeight, f.itemHeightRatio, f.stackItems, L.draggingItem, L.resizingItem, L.dragTime, L.resizingEdge, L.resizeTime, L.newGroupOrder, f.itemVerticalGap));
	}
	return T;
}
var mf = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
	__proto__: null,
	NEXT_UNITS: Or,
	calculateDimensions: Wi,
	calculateInteractionNewTimes: Hi,
	calculateScrollCanvas: Cr,
	calculateTimeForXPosition: Mr,
	calculateXPositionForTime: Rt,
	collision: Ui,
	coordinateToTimeRatio: Mt,
	getCanvasBoundariesFromVisibleTime: $r,
	getCanvasWidth: ve,
	getGroupOrders: kr,
	getGroupedItems: Fi,
	getItemDimensions: Xi,
	getItemWithInteractions: Bi,
	getMinUnit: xt,
	getNextUnit: Dr,
	getVisibleItems: zr,
	groupNoStack: Gi,
	groupStack: Ni,
	iterateTimes: Rr,
	minCellWidth: Sr,
	stackAll: Yi,
	stackGroup: Ki,
	stackTimelineItems: $e
}, Symbol.toStringTag, { value: "Module" })), Qh = {
	fontSize: 12,
	color: "white",
	cursor: "pointer",
	background: "#2196f3",
	borderTopWidth: "1px",
	borderBottomWidth: "1px",
	borderLeftWidth: "1px",
	borderRightWidth: "1px",
	borderStyle: "solid",
	borderColor: "#1a6fb3",
	zIndex: 80
}, ed = {
	background: "#ffc107",
	borderTopWidth: "1px",
	borderLeftWidth: "1px",
	borderRightWidth: "1px",
	borderBottomWidth: "1px",
	borderStyle: "solid",
	borderColor: "#ff9800",
	zIndex: 82
}, td = {
	willChange: "left, top, width",
	cursor: "move"
}, rd = { borderLeftWidth: 3 }, nd = { cursor: "w-resize" }, id = { borderRightWidth: "3px" }, od = { cursor: "e-resize" }, sd = {
	position: "absolute",
	width: 24,
	maxWidth: "20%",
	minWidth: 2,
	height: "100%",
	top: 0,
	left: 0,
	cursor: "pointer",
	zIndex: 88
}, ad = {
	position: "absolute",
	width: 24,
	maxWidth: "20%",
	minWidth: 2,
	height: "100%",
	top: 0,
	right: 0,
	cursor: "pointer",
	zIndex: 88
}, jr = import_react.createContext({
	getTimelineState: () => (console.warn("\"getTimelineState\" default func is being used"), {}),
	getLeftOffsetFromDate: () => (console.warn("\"getLeftOffsetFromDate\" default func is being used"), 0),
	getDateFromLeftOffsetPosition: () => (console.warn("\"getDateFromLeftOffsetPosition\" default func is being used"), 0),
	showPeriod: () => {
		console.warn("\"showPeriod\" default func is being used");
	}
}), { Consumer: cd, Provider: ud } = jr;
var pd = class extends import_react.Component {
	constructor(i) {
		super(i), Object.defineProperty(this, "getTimelineState", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: () => {
				const { visibleTimeStart: s, visibleTimeEnd: u, canvasTimeStart: v, canvasTimeEnd: f, canvasWidth: m, timelineUnit: y, timelineWidth: S } = this.props;
				return {
					visibleTimeStart: s,
					visibleTimeEnd: u,
					canvasTimeStart: v,
					canvasTimeEnd: f,
					canvasWidth: m,
					timelineUnit: y,
					timelineWidth: S
				};
			}
		}), Object.defineProperty(this, "getLeftOffsetFromDate", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s) => {
				const { canvasTimeStart: u, canvasTimeEnd: v, canvasWidth: f } = this.props;
				return Rt(u, v, f, s);
			}
		}), Object.defineProperty(this, "getDateFromLeftOffsetPosition", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s) => {
				const { canvasTimeStart: u, canvasTimeEnd: v, canvasWidth: f } = this.props;
				return Mr(u, v, f, s);
			}
		}), this.state = { timelineContext: {
			getTimelineState: this.getTimelineState,
			getLeftOffsetFromDate: this.getLeftOffsetFromDate,
			getDateFromLeftOffsetPosition: this.getDateFromLeftOffsetPosition,
			showPeriod: this.props.showPeriod
		} };
	}
	render() {
		return (0, import_jsx_runtime.jsx)(ud, {
			value: this.state.timelineContext,
			children: this.props.children
		});
	}
};
var Lt = cd;
var hd = () => (0, import_react.useContext)(jr);
import_dayjs_min.default.extend(Ss);
var Ar = class extends import_react.Component {
	constructor(i) {
		super(i), Object.defineProperty(this, "state", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: {
				interactMounted: !1,
				dragging: !1,
				dragStart: null,
				preDragPosition: null,
				dragTime: null,
				dragGroupDelta: null,
				resizing: !1,
				resizeEdge: null,
				resizeStart: null,
				resizeTime: null
			}
		}), Object.defineProperty(this, "itemId", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: ""
		}), Object.defineProperty(this, "itemTitle", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: ""
		}), Object.defineProperty(this, "itemDivTitle", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: void 0
		}), Object.defineProperty(this, "itemTimeStart", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: void 0
		}), Object.defineProperty(this, "itemTimeEnd", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: void 0
		}), Object.defineProperty(this, "itemRef", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (0, import_react.createRef)()
		}), Object.defineProperty(this, "dragLeft", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: void 0
		}), Object.defineProperty(this, "dragRight", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: void 0
		}), Object.defineProperty(this, "startedClicking", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: !1
		}), Object.defineProperty(this, "startedTouching", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: !1
		}), Object.defineProperty(this, "dragInProgress", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: !1
		}), Object.defineProperty(this, "fireInteractEvent", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s) => {
				var u;
				if (this.itemRef && this.itemRef.current) {
					const v = new CustomEvent("itemInteraction", {
						bubbles: !0,
						detail: { itemInteraction: s }
					});
					(u = this.itemRef.current) == null || u.dispatchEvent(v);
				}
			}
		}), Object.defineProperty(this, "onMouseDown", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s) => {
				this.state.interactMounted || (s.preventDefault(), this.startedClicking = !0);
			}
		}), Object.defineProperty(this, "onMouseUp", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s) => {
				!this.state.interactMounted && this.startedClicking && (this.startedClicking = !1, this.actualClick(s, "click"));
			}
		}), Object.defineProperty(this, "onTouchStart", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s) => {
				this.state.interactMounted || (s.preventDefault(), this.startedTouching = !0);
			}
		}), Object.defineProperty(this, "onTouchEnd", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s) => {
				!this.state.interactMounted && this.startedTouching && (this.startedTouching = !1, this.actualClick(s, "touch"));
			}
		}), Object.defineProperty(this, "handleDoubleClick", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s) => {
				s.stopPropagation(), this.props.onItemDoubleClick && this.props.onItemDoubleClick(this.itemId, s);
			}
		}), Object.defineProperty(this, "handleContextMenu", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s) => {
				this.props.onContextMenu && (s.preventDefault(), s.stopPropagation(), this.props.onContextMenu(this.itemId, s));
			}
		}), Object.defineProperty(this, "getDragLeftRef", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s) => this.dragLeft = s
		}), Object.defineProperty(this, "getDragRightRef", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s) => this.dragRight = s
		}), Object.defineProperty(this, "getItemProps", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s = {}) => {
				const u = "rct-item" + (this.props.item.className ? ` ${this.props.item.className}` : "");
				return {
					key: this.itemId,
					ref: this.itemRef,
					title: this.itemDivTitle,
					className: u + ` ${s.className ? s.className : ""}`,
					onMouseDown: Pe(this.onMouseDown, s.onMouseDown),
					onMouseUp: Pe(this.onMouseUp, s.onMouseUp),
					onTouchStart: Pe(this.onTouchStart, s.onTouchStart),
					onTouchEnd: Pe(this.onTouchEnd, s.onTouchEnd),
					onDoubleClick: Pe(this.handleDoubleClick, s.onDoubleClick),
					onContextMenu: Pe(this.handleContextMenu, s.onContextMenu),
					style: Object.assign({}, this.getItemStyle(s))
				};
			}
		}), Object.defineProperty(this, "getResizeProps", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s = {}) => {
				let u = "rct-item-handler rct-item-handler-left rct-item-handler-resize-left";
				s.leftClassName && (u += ` ${s.leftClassName}`);
				let v = "rct-item-handler rct-item-handler-right rct-item-handler-resize-right";
				return s.rightClassName && (v += ` ${s.rightClassName}`), {
					left: {
						ref: this.getDragLeftRef,
						className: u,
						style: Object.assign({}, sd, s.leftStyle)
					},
					right: {
						ref: this.getDragRightRef,
						className: v,
						style: Object.assign({}, ad, s.rightStyle)
					}
				};
			}
		}), this.cacheDataFromProps(i);
	}
	shouldComponentUpdate(i, s) {
		return !xr(this.props, i) || !xr(this.state, s);
	}
	cacheDataFromProps(i) {
		this.itemId = Y(i.item, i.keys.itemIdKey), this.itemTitle = Y(i.item, i.keys.itemTitleKey), this.itemDivTitle = i.keys.itemDivTitleKey ? Y(i.item, i.keys.itemDivTitleKey) : this.itemTitle, this.itemTimeStart = Y(i.item, i.keys.itemTimeStartKey), this.itemTimeEnd = Y(i.item, i.keys.itemTimeEndKey);
	}
	getTimeRatio() {
		const { canvasTimeStart: i, canvasTimeEnd: s, canvasWidth: u } = this.props;
		return Mt(i, s, u);
	}
	dragTimeSnap(i, s) {
		const { dragSnap: u } = this.props;
		if (u) {
			const v = s ? (0, import_dayjs_min.default)().utcOffset() * 60 * 1e3 : 0;
			return Math.round(i / u) * u - v % u;
		} else return i;
	}
	resizeTimeSnap(i) {
		const { dragSnap: s } = this.props;
		if (s) {
			const u = this.itemTimeEnd % s;
			return Math.round((i - u) / s) * s + u;
		} else return i;
	}
	dragTime(i) {
		const s = (0, import_dayjs_min.default)(this.itemTimeStart);
		return this.state.dragging ? this.dragTimeSnap(this.timeFor(i) + this.state.dragStart.offset, !0) : s.valueOf();
	}
	timeFor(i) {
		const s = Mt(this.props.canvasTimeStart, this.props.canvasTimeEnd, this.props.canvasWidth), u = Ct(this.props.scrollRef).offsetLeft, v = Ot(this.props.scrollRef);
		return (i.pageX - u + v.scrollLeft) * s + this.props.canvasTimeStart;
	}
	dragGroupDelta(i) {
		const { groupTops: s, order: u } = this.props;
		if (this.state.dragging) {
			if (!this.props.canChangeGroup) return 0;
			let v = 0;
			const f = Ct(this.props.scrollRef).offsetTop, m = Ot(this.props.scrollRef);
			for (const y of Object.keys(s)) {
				const S = s[y];
				if (i.pageY - f + m.scrollTop > S) v = parseInt(y, 10) - u.index;
				else break;
			}
			return this.props.order.index + v < 0 ? 0 - this.props.order.index : v;
		} else return 0;
	}
	resizeTimeDelta(i, s) {
		const u = this.itemTimeEnd - this.itemTimeStart, v = this.dragTimeSnap((i.pageX - this.state.resizeStart) * this.getTimeRatio());
		return u + (s === "left" ? -v : v) < (this.props.dragSnap || 1e3) ? s === "left" ? u - (this.props.dragSnap || 1e3) : (this.props.dragSnap || 1e3) - u : v;
	}
	mountInteract() {
		const i = this.props.useResizeHandle ? ".rct-item-handler-resize-left" : !0, s = this.props.useResizeHandle ? ".rct-item-handler-resize-right" : !0;
		dr(this.itemRef.current).resizable({
			edges: {
				left: this.canResizeLeft() && i,
				right: this.canResizeRight() && s,
				top: !1,
				bottom: !1
			},
			enabled: this.props.selected && (this.canResizeLeft() || this.canResizeRight())
		}).draggable({ enabled: this.props.selected && this.canMove() }).styleCursor(!1).on("dragstart", (u) => {
			if (this.props.selected) {
				this.dragInProgress = !0, this.fireInteractEvent(!0);
				const v = this.timeFor(u);
				this.setState({
					dragging: !0,
					dragStart: {
						x: u.pageX,
						y: u.pageY,
						offset: this.itemTimeStart - v
					},
					preDragPosition: {
						x: u.target.offsetLeft,
						y: u.target.offsetTop
					},
					dragTime: this.itemTimeStart,
					dragGroupDelta: 0
				});
			} else return !1;
		}).on("dragmove", (u) => {
			this.state.dragging && this.setState((v) => {
				if (!this.dragInProgress) return { ...v };
				let f = this.dragTime(u);
				const m = this.dragGroupDelta(u);
				return this.props.moveResizeValidator && (f = this.props.moveResizeValidator("move", this.props.item, f)), this.props.onDrag && this.props.onDrag(this.itemId, f, this.props.order.index + m), {
					dragTime: f,
					dragGroupDelta: m
				};
			});
		}).on("dragend", (u) => {
			if (this.state.dragging) {
				if (this.props.onDrop) {
					this.dragInProgress = !1, this.fireInteractEvent(!1);
					let v = this.dragTime(u);
					this.props.moveResizeValidator && (v = this.props.moveResizeValidator("move", this.props.item, v)), this.props.onDrop(this.itemId, v, this.props.order.index + this.dragGroupDelta(u));
				}
				this.setState({
					dragging: !1,
					dragStart: null,
					preDragPosition: null,
					dragTime: null,
					dragGroupDelta: null
				});
			}
		}).on("resizestart", (u) => {
			if (this.props.selected) this.fireInteractEvent(!0), this.setState({
				resizing: !0,
				resizeEdge: null,
				resizeStart: u.pageX,
				resizeTime: 0
			});
			else return !1;
		}).on("resizemove", (u) => {
			if (this.state.resizing) {
				let v = this.state.resizeEdge;
				v || (v = u.deltaRect.left !== 0 ? "left" : "right", this.setState({ resizeEdge: v }));
				let f = this.resizeTimeSnap(this.timeFor(u));
				this.props.moveResizeValidator && (f = this.props.moveResizeValidator("resize", this.props.item, f, v)), this.props.onResizing && this.props.onResizing(this.itemId, f, v), this.setState({ resizeTime: f });
			}
		}).on("resizeend", (u) => {
			if (this.state.resizing) {
				this.fireInteractEvent(!1);
				const { resizeEdge: v } = this.state;
				let f = this.resizeTimeSnap(this.timeFor(u));
				this.props.moveResizeValidator && (f = this.props.moveResizeValidator("resize", this.props.item, f, v)), this.props.onResized && this.props.onResized(this.itemId, f, v, this.resizeTimeDelta(u, v)), this.setState({
					resizing: !1,
					resizeStart: null,
					resizeEdge: null,
					resizeTime: null
				});
			}
		}).on("tap", (u) => {
			this.actualClick(u, u.pointerType === "mouse" ? "click" : "touch");
		}), this.setState({ interactMounted: !0 });
	}
	canResizeLeft(i = this.props) {
		var u;
		return !i.canResizeLeft || i.minResizeWidth === void 0 ? !1 : parseInt((u = i.dimensions.width) == null ? void 0 : u.toString(), 10) >= i.minResizeWidth;
	}
	canResizeRight(i = this.props) {
		var u;
		return !i.canResizeRight || i.minResizeWidth === void 0 ? !1 : parseInt((u = i.dimensions.width) == null ? void 0 : u.toString(), 10) >= i.minResizeWidth;
	}
	canMove(i = this.props) {
		return !!i.canMove;
	}
	componentDidUpdate(i) {
		this.cacheDataFromProps(this.props);
		let { interactMounted: s } = this.state;
		const u = i.selected && this.canMove(i), v = i.selected && this.canResizeLeft(i), f = i.selected && this.canResizeRight(i), m = this.props.selected && this.canMove(this.props), y = this.props.selected && this.canResizeLeft(this.props), S = this.props.selected && this.canResizeRight(this.props);
		if (this.itemRef && this.itemRef.current) {
			if (this.props.selected && !s && (this.mountInteract(), s = !0), s && (v !== y || f !== S)) {
				const C = this.props.useResizeHandle ? this.dragLeft : !0, D = this.props.useResizeHandle ? this.dragRight : !0;
				dr(this.itemRef.current).resizable({
					enabled: y || S,
					edges: {
						top: !1,
						bottom: !1,
						left: y && C,
						right: S && D
					}
				});
			}
			s && u !== m && dr(this.itemRef.current).draggable({ enabled: m });
		} else s = !1;
		s !== this.state.interactMounted && this.setState({ interactMounted: s });
	}
	actualClick(i, s) {
		this.props.canSelect && this.props.onSelect && this.props.onSelect(this.itemId, s, i);
	}
	getItemStyle(i) {
		const s = this.props.dimensions, u = {
			position: "absolute",
			boxSizing: "border-box",
			left: `${s.left}px`,
			top: `${s.top}px`,
			width: `${s.width}px`,
			height: `${s.height}px`,
			lineHeight: `${s.height}px`
		};
		return Object.assign({}, Qh, this.props.selected ? ed : {}, this.props.selected && this.canMove(this.props) ? td : {}, this.props.selected && this.canResizeLeft(this.props) ? rd : {}, this.props.selected && this.canResizeLeft(this.props) && this.state.dragging ? nd : {}, this.props.selected && this.canResizeRight(this.props) ? id : {}, this.props.selected && this.canResizeRight(this.props) && this.state.dragging ? od : {}, i.style, u);
	}
	render() {
		if (typeof this.props.order > "u" || this.props.order === null) return null;
		const i = this.context, s = {
			dimensions: this.props.dimensions,
			useResizeHandle: !!this.props.useResizeHandle,
			title: this.itemTitle,
			canMove: this.canMove(this.props),
			canResizeLeft: this.canResizeLeft(this.props),
			canResizeRight: this.canResizeRight(this.props),
			selected: this.props.selected,
			dragging: this.state.dragging,
			dragStart: this.state.dragStart,
			dragTime: this.state.dragTime,
			dragGroupDelta: this.state.dragGroupDelta,
			resizing: this.state.resizing,
			resizeEdge: this.state.resizeEdge,
			resizeStart: this.state.resizeStart,
			resizeTime: this.state.resizeTime
		};
		return this.props.itemRenderer ? this.props.itemRenderer({
			item: this.props.item,
			timelineContext: i,
			itemContext: s,
			getItemProps: this.getItemProps,
			getResizeProps: this.getResizeProps
		}) : Li({
			item: this.props.item,
			itemContext: s,
			getItemProps: this.getItemProps,
			getResizeProps: this.getResizeProps
		});
	}
};
Object.defineProperty(Ar, "defaultProps", {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: {
		selected: !1,
		itemRenderer: Li
	}
});
Object.defineProperty(Ar, "contextType", {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: jr
});
function dd(a, i) {
	const s = Y(a, "canResize") !== void 0 ? Y(a, "canResize") : i;
	return s === "left" || s === "both";
}
function fd(a, i) {
	const s = Y(a, "canResize") !== void 0 ? Y(a, "canResize") : i;
	return s === "right" || s === "both" || s === !0;
}
var vd = class extends import_react.Component {
	shouldComponentUpdate(i) {
		return !(tt(i.groups, this.props.groups) && tt(i.items, this.props.items) && tt(i.dimensionItems, this.props.dimensionItems) && i.keys === this.props.keys && i.canvasTimeStart === this.props.canvasTimeStart && i.canvasTimeEnd === this.props.canvasTimeEnd && i.canvasWidth === this.props.canvasWidth && i.selectedItem === this.props.selectedItem && i.selected === this.props.selected && i.dragSnap === this.props.dragSnap && i.minResizeWidth === this.props.minResizeWidth && i.canChangeGroup === this.props.canChangeGroup && i.canMove === this.props.canMove && i.canResize === this.props.canResize && i.canSelect === this.props.canSelect);
	}
	isSelected(i, s) {
		if (this.props.selected) {
			const u = Y(i, s);
			return this.props.selected.includes(u);
		} else return this.props.selectedItem === Y(i, s);
	}
	getVisibleItems(i, s) {
		const { keys: u, items: v } = this.props;
		return zr(v, i, s, u);
	}
	render() {
		const { canvasTimeStart: i, canvasTimeEnd: s, dimensionItems: u, keys: v, groups: f } = this.props, { itemIdKey: m, itemGroupKey: y } = v, S = kr(f, v), C = this.getVisibleItems(i, s), D = Zh(u, "id");
		return (0, import_jsx_runtime.jsx)("div", {
			className: "rct-items",
			children: C.filter((R) => D[Y(R, m)]).map((R) => (0, import_jsx_runtime.jsx)(Ar, {
				itemProps: R.itemProps,
				item: R,
				keys: this.props.keys,
				order: S[Y(R, y)],
				dimensions: D[Y(R, m)].dimensions,
				selected: this.isSelected(R, m),
				canChangeGroup: Y(R, "canChangeGroup") !== void 0 ? Y(R, "canChangeGroup") : this.props.canChangeGroup,
				canMove: Y(R, "canMove") !== void 0 ? Y(R, "canMove") : this.props.canMove,
				canResizeLeft: dd(R, this.props.canResize),
				canResizeRight: fd(R, this.props.canResize),
				canSelect: Y(R, "canSelect") !== void 0 ? Y(R, "canSelect") : this.props.canSelect,
				useResizeHandle: this.props.useResizeHandle,
				groupTops: this.props.groupTops,
				canvasTimeStart: this.props.canvasTimeStart,
				canvasTimeEnd: this.props.canvasTimeEnd,
				canvasWidth: this.props.canvasWidth,
				dragSnap: this.props.dragSnap,
				minResizeWidth: this.props.minResizeWidth,
				onResizing: this.props.itemResizing,
				onResized: this.props.itemResized,
				moveResizeValidator: this.props.moveResizeValidator,
				onDrag: this.props.itemDrag,
				onDrop: this.props.itemDrop,
				onItemDoubleClick: this.props.onItemDoubleClick,
				onContextMenu: this.props.onItemContextMenu,
				onSelect: this.props.itemSelect,
				itemRenderer: this.props.itemRenderer,
				scrollRef: this.props.scrollRef
			}, Y(R, m)))
		});
	}
};
var fi = class extends import_react.Component {
	shouldComponentUpdate(i) {
		return !(i.keys === this.props.keys && i.width === this.props.width && i.height === this.props.height && tt(i.groups, this.props.groups) && tt(i.groupHeights, this.props.groupHeights));
	}
	renderGroupContent(i, s = !1, u, v) {
		return this.props.groupRenderer ? import_react.createElement(this.props.groupRenderer, {
			group: i,
			isRightSidebar: s
		}) : Y(i, s ? v : u);
	}
	render() {
		const { width: i, groupHeights: s, height: u, isRightSidebar: v } = this.props, { groupIdKey: f, groupTitleKey: m, groupRightTitleKey: y } = this.props.keys, S = {
			width: `${i}px`,
			height: `${u}px`
		}, C = { width: `${i}px` }, D = this.props.groups.map((R, T) => {
			const P = {
				height: `${s[T]}px`,
				lineHeight: `${s[T]}px`
			};
			return (0, import_jsx_runtime.jsx)("div", {
				className: "rct-sidebar-row rct-sidebar-row-" + (T % 2 === 0 ? "even" : "odd"),
				style: P,
				children: this.renderGroupContent(R, v, m, y)
			}, Y(R, f));
		});
		return (0, import_jsx_runtime.jsx)("div", {
			className: "rct-sidebar" + (v ? " rct-sidebar-right" : ""),
			style: S,
			children: (0, import_jsx_runtime.jsx)("div", {
				style: C,
				children: D
			})
		});
	}
};
var gd = class extends import_react.Component {
	shouldComponentUpdate(i) {
		return !(i.canvasTimeStart === this.props.canvasTimeStart && i.canvasTimeEnd === this.props.canvasTimeEnd && i.canvasWidth === this.props.canvasWidth && i.lineCount === this.props.lineCount && i.minUnit === this.props.minUnit && i.timeSteps === this.props.timeSteps && i.height === this.props.height && i.verticalLineClassNamesForTime === this.props.verticalLineClassNamesForTime);
	}
	render() {
		const { canvasTimeStart: i, canvasTimeEnd: s, minUnit: u, timeSteps: v, height: f, verticalLineClassNamesForTime: m, getLeftOffsetFromDate: y } = this.props, S = [];
		return Rr(i, s, u, v, (C, D) => {
			const T = C.get(u === "day" ? "date" : u) === (u === "day" ? 1 : 0);
			let P = [];
			m && (P = m(C.unix() * 1e3, D.unix() * 1e3 - 1));
			const _ = "rct-vl" + (T ? " rct-vl-first" : "") + (u === "day" || u === "hour" || u === "minute" ? ` rct-day-${C.day()} ` : " ") + P.join(" "), O = y(C.valueOf()), k = y(D.valueOf());
			S.push((0, import_jsx_runtime.jsx)("div", {
				className: _,
				style: {
					pointerEvents: "none",
					top: "0px",
					left: `${O}px`,
					width: `${k - O}px`,
					height: `${f}px`
				}
			}, `line-${C.valueOf()}`));
		}), (0, import_jsx_runtime.jsx)("div", {
			className: "rct-vertical-lines",
			children: S
		});
	}
};
var md = ({ ...a }) => (0, import_jsx_runtime.jsx)(Lt, { children: ({ getLeftOffsetFromDate: i }) => (0, import_jsx_runtime.jsx)(gd, {
	getLeftOffsetFromDate: i,
	...a
}) });
var bd = class extends import_react.Component {
	constructor() {
		super(...arguments), Object.defineProperty(this, "handleMouseDown", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (i) => {
				this.originClickX = i.clientX;
			}
		}), Object.defineProperty(this, "handleMouseUp", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (i) => {
				this.props.clickTolerance !== void 0 && Math.abs(this.originClickX - i.clientX) > this.props.clickTolerance && (this.cancelClick = !0);
			}
		}), Object.defineProperty(this, "handleClick", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (i) => {
				this.cancelClick || this.props.onClick(i), this.cancelClick = !1, this.originClickX = null;
			}
		}), Object.defineProperty(this, "originClickX", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: void 0
		}), Object.defineProperty(this, "cancelClick", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: !1
		});
	}
	render() {
		const i = import_react.Children.only(this.props.children);
		return import_react.cloneElement(i, {
			onMouseDown: this.handleMouseDown,
			onMouseUp: this.handleMouseUp,
			onClick: this.handleClick
		});
	}
};
var yd = class extends import_react.Component {
	render() {
		const { onContextMenu: i, onDoubleClick: s, isEvenRow: u, style: v, onClick: f, clickTolerance: m, horizontalLineClassNamesForGroup: y, group: S } = this.props;
		let C = [];
		return y && (C = y(S)), (0, import_jsx_runtime.jsx)(bd, {
			clickTolerance: m,
			onClick: f,
			children: (0, import_jsx_runtime.jsx)("div", {
				onContextMenu: i,
				onDoubleClick: s,
				className: (u ? "rct-hl-even " : "rct-hl-odd ") + (C ? C.join(" ") : ""),
				style: v
			})
		});
	}
};
var Td = class extends import_react.Component {
	shouldComponentUpdate(i) {
		return !(i.canvasWidth === this.props.canvasWidth && i.lineCount === this.props.lineCount && i.groupHeights === this.props.groupHeights && i.groups === this.props.groups);
	}
	render() {
		const { canvasWidth: i, lineCount: s, groupHeights: u, onRowClick: v, onRowDoubleClick: f, clickTolerance: m, groups: y, horizontalLineClassNamesForGroup: S, onRowContextClick: C } = this.props, D = [];
		for (let R = 0; R < s; R++) D.push((0, import_jsx_runtime.jsx)(yd, {
			clickTolerance: m,
			onContextMenu: (T) => C(T, R),
			onClick: (T) => v(T, R),
			onDoubleClick: (T) => f(T, R),
			isEvenRow: R % 2 === 0,
			group: y[R],
			horizontalLineClassNamesForGroup: S,
			style: {
				width: `${i}px`,
				height: `${u[R]}px`
			}
		}, `horizontal-line-${R}`));
		return (0, import_jsx_runtime.jsx)("div", {
			className: "rct-horizontal-lines",
			children: D
		});
	}
};
var wd = class extends import_react.Component {
	constructor(i) {
		super(i), Object.defineProperty(this, "scrollComponentRef", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (0, import_react.createRef)()
		}), Object.defineProperty(this, "dragLastPosition", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: null
		}), Object.defineProperty(this, "lastTouchDistance", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: null
		}), Object.defineProperty(this, "singleTouchStart", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: null
		}), Object.defineProperty(this, "lastSingleTouch", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: null
		}), Object.defineProperty(this, "isItemInteraction", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: !1
		}), Object.defineProperty(this, "handlePointerStart", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s) => {
				s.pointerType === "touch" ? this.handleTouchStart(s) : s.pointerType === "mouse" && this.handleMouseDown(s);
			}
		}), Object.defineProperty(this, "handlePointerMove", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s) => {
				s.pointerType === "touch" ? this.handleTouchMove(s) : s.pointerType === "mouse" && this.handleMouseMove(s);
			}
		}), Object.defineProperty(this, "handlePointerEnd", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s) => {
				s.pointerType === "touch" ? this.handleTouchEnd() : s.pointerType === "mouse" && this.handleMouseUp();
			}
		}), Object.defineProperty(this, "handleScroll", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: () => {
				const s = this.scrollComponentRef.current.scrollLeft;
				this.props.onScroll(s);
			}
		}), Object.defineProperty(this, "handleWheel", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s) => {
				if (s.ctrlKey || s.metaKey || s.altKey) {
					s.preventDefault();
					const u = Hn(s.currentTarget), v = s.clientX - u.x, f = s.ctrlKey ? 10 : s.metaKey ? 3 : 1;
					this.props.onWheelZoom(f, v, s.deltaY);
				} else s.shiftKey && (s.preventDefault(), this.props.onScroll(this.scrollComponentRef.current.scrollLeft + (s.deltaY || s.deltaX)));
			}
		}), Object.defineProperty(this, "handleMouseDown", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s) => {
				s.button === 0 && (this.dragLastPosition = s.pageX, this.setState({ isDragging: !0 }));
			}
		}), Object.defineProperty(this, "handleMouseMove", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s) => {
				this.state.isDragging && !this.isItemInteraction && (this.props.onScroll(this.scrollComponentRef.current.scrollLeft + this.dragLastPosition - s.pageX), this.dragLastPosition = s.pageX);
			}
		}), Object.defineProperty(this, "handleMouseUp", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: () => {
				this.dragLastPosition = null, this.setState({ isDragging: !1 });
			}
		}), Object.defineProperty(this, "handlePointerLeave", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s) => {
				s.pointerType === "mouse" && (this.dragLastPosition = null, this.setState({ isDragging: !1 }));
			}
		}), Object.defineProperty(this, "handleTouchStart", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s) => {
				s.isPrimary ? (s.preventDefault(), this.lastTouchDistance = null, this.singleTouchStart = {
					x: s.clientX,
					y: s.clientY,
					screenY: window.scrollY
				}, this.lastSingleTouch = {
					x: s.clientX,
					y: s.clientY,
					screenY: window.scrollY
				}) : (s.preventDefault(), this.lastTouchDistance = Math.abs(s.clientX - this.singleTouchStart.x), this.singleTouchStart = null, this.lastSingleTouch = null);
			}
		}), Object.defineProperty(this, "handleTouchMove", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s) => {
				const { width: u, onZoom: v } = this.props;
				if (this.isItemInteraction) {
					s.preventDefault();
					return;
				}
				if (this.lastTouchDistance && !s.isPrimary) {
					s.preventDefault();
					const f = Math.abs(s.clientX - this.singleTouchStart.x), m = Hn(s.currentTarget), y = (s.clientX + this.singleTouchStart.x) / 2 - m.x;
					f !== 0 && this.lastTouchDistance !== 0 && (v(this.lastTouchDistance / f, y / u), this.lastTouchDistance = f);
				} else if (this.lastSingleTouch && s.isPrimary) {
					s.preventDefault();
					const f = s.clientX, m = s.clientY, y = f - this.lastSingleTouch.x, S = f - this.singleTouchStart.x, C = m - this.singleTouchStart.y;
					this.lastSingleTouch = {
						x: f,
						y: m,
						screenY: window.pageYOffset
					};
					const D = Math.abs(S) * 3 > Math.abs(C), R = Math.abs(C) * 3 > Math.abs(S);
					y !== 0 && D && this.props.onScroll(this.scrollComponentRef.current.scrollLeft - y), R && window.scrollTo(window.scrollX, this.singleTouchStart.screenY - C);
				}
			}
		}), Object.defineProperty(this, "handleTouchEnd", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: () => {
				this.lastTouchDistance && (this.lastTouchDistance = null), this.lastSingleTouch && (this.lastSingleTouch = null, this.singleTouchStart = null);
			}
		}), Object.defineProperty(this, "handleItemInteract", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s) => {
				this.isItemInteraction = s.detail.itemInteraction;
			}
		}), this.state = { isDragging: !1 };
	}
	componentDidMount() {
		this.scrollComponentRef.current && (this.props.scrollRef(this.scrollComponentRef.current), this.scrollComponentRef.current.addEventListener("wheel", this.handleWheel, { passive: !1 }), this.scrollComponentRef.current.addEventListener("itemInteraction", this.handleItemInteract), this.scrollComponentRef.current.addEventListener("pointerdown", this.handlePointerStart, { passive: !1 }), this.scrollComponentRef.current.addEventListener("pointermove", this.handlePointerMove, { passive: !1 }), this.scrollComponentRef.current.addEventListener("pointerup", this.handlePointerEnd), this.scrollComponentRef.current.addEventListener("pointerleave", this.handlePointerLeave));
	}
	componentWillUnmount() {
		this.scrollComponentRef.current && (this.scrollComponentRef.current.removeEventListener("wheel", this.handleWheel), this.scrollComponentRef.current.removeEventListener("itemInteraction", this.handleItemInteract), this.scrollComponentRef.current.removeEventListener("pointerdown", this.handlePointerStart), this.scrollComponentRef.current.removeEventListener("pointermove", this.handlePointerMove), this.scrollComponentRef.current.removeEventListener("pointerup", this.handlePointerEnd), this.scrollComponentRef.current.removeEventListener("pointerleave", this.handlePointerLeave));
	}
	render() {
		const { width: i, height: s, children: u } = this.props, { isDragging: v } = this.state, f = {
			width: `${i}px`,
			height: `${s + 20}px`,
			cursor: v ? "move" : "default",
			position: "relative"
		};
		return (0, import_jsx_runtime.jsx)("div", {
			ref: this.scrollComponentRef,
			"data-testid": "scroll-element",
			className: "rct-scroll",
			style: f,
			onScroll: this.handleScroll,
			children: u
		});
	}
};
var { Consumer: Sd, Provider: Od } = import_react.createContext({ subscribeToMouseOver: () => (console.warn("\"subscribeToMouseOver\" default func is being used"), () => {}) }), Cd = Od, Ed = Sd, { Consumer: Pd, Provider: Id } = import_react.createContext({
	markers: [],
	subscribeMarker: () => (console.warn("default subscribe marker used"), {
		unsubscribe: wt,
		getMarker: wt
	}),
	updateMarker: () => (console.warn("default subscribe marker used"), wt)
});
var vi = 0;
var Md = () => (vi += 1, vi + 1);
var Rd = class extends import_react.Component {
	constructor(i) {
		super(i), Object.defineProperty(this, "handleSubscribeToMarker", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s) => (s = {
				...s,
				id: Md()
			}, this.setState((u) => ({ markers: [...u.markers, s] })), {
				unsubscribe: () => {
					this.setState((u) => ({ markers: u.markers.filter((v) => v.id !== s.id) }));
				},
				getMarker: () => s
			})
		}), Object.defineProperty(this, "handleUpdateMarker", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (s) => {
				const u = this.state.markers.findIndex((v) => v.id === s.id);
				u < 0 || this.setState((v) => ({ markers: [
					...v.markers.slice(0, u),
					s,
					...v.markers.slice(u + 1)
				] }));
			}
		}), this.state = {
			markers: [],
			subscribeMarker: this.handleSubscribeToMarker,
			updateMarker: this.handleUpdateMarker
		};
	}
	render() {
		return (0, import_jsx_runtime.jsx)(Id, {
			value: this.state,
			children: this.props.children
		});
	}
};
var Ht = Pd;
var xe;
(function(a) {
	a.Today = "Today", a.Custom = "Custom", a.Cursor = "Cursor";
})(xe || (xe = {}));
var Dd = {
	position: "absolute",
	top: 0,
	bottom: 0,
	width: "2px",
	backgroundColor: "black",
	pointerEvents: "none"
};
var Lr = (a) => ({
	...Dd,
	left: a
});
var Hr = (a) => function({ styles: s }) {
	return (0, import_jsx_runtime.jsx)("div", {
		style: s,
		"data-testid": a
	});
};
var kd = Hr("default-today-line");
var Vi = class extends import_react.Component {
	constructor() {
		super(...arguments), Object.defineProperty(this, "state", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: { date: Date.now() }
		}), Object.defineProperty(this, "intervalToken", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: void 0
		});
	}
	componentDidMount() {
		this.intervalToken = this.createIntervalUpdater(this.props.interval);
	}
	componentDidUpdate(i) {
		i.interval !== this.props.interval && (clearInterval(this.intervalToken), this.intervalToken = this.createIntervalUpdater(this.props.interval));
	}
	createIntervalUpdater(i) {
		return setInterval(() => {
			this.setState({ date: Date.now() });
		}, i);
	}
	componentWillUnmount() {
		clearInterval(this.intervalToken);
	}
	render() {
		const { date: i } = this.state, u = Lr(this.props.getLeftOffsetFromDate(i));
		return this.props.renderer({
			styles: u,
			date: i
		});
	}
};
Object.defineProperty(Vi, "defaultProps", {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: { renderer: kd }
});
var zd = Hr("default-customer-marker-id");
var qi = class extends import_react.Component {
	render() {
		const { date: i } = this.props, u = Lr(this.props.getLeftOffsetFromDate(i));
		return this.props.renderer({
			styles: u,
			date: i
		});
	}
};
Object.defineProperty(qi, "defaultProps", {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: { renderer: zd }
});
var $d = Hr("default-cursor-marker");
var Zi = class extends import_react.Component {
	constructor(i) {
		super(i), Object.defineProperty(this, "handleCanvasMouseOver", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: ({ leftOffset: s, date: u, isCursorOverCanvas: v }) => {
				this.setState({
					leftOffset: s,
					date: u,
					isShowingCursor: v
				});
			}
		}), Object.defineProperty(this, "unsubscribe", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: void 0
		}), this.state = {
			leftOffset: 0,
			date: 0,
			isShowingCursor: !1
		};
	}
	componentDidMount() {
		this.unsubscribe = this.props.subscribeToCanvasMouseOver(this.handleCanvasMouseOver);
	}
	componentWillUnmount() {
		this.unsubscribe && (this.unsubscribe(), this.unsubscribe = void 0);
	}
	render() {
		const { isShowingCursor: i, leftOffset: s, date: u } = this.state;
		if (!i) return null;
		const v = Lr(s);
		return this.props.renderer ? this.props.renderer({
			styles: v,
			date: u
		}) : null;
	}
};
Object.defineProperty(Zi, "defaultProps", {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: { renderer: $d }
});
var Ji = (a) => (0, import_jsx_runtime.jsx)(Ed, { children: ({ subscribeToMouseOver: i }) => (0, import_jsx_runtime.jsx)(Zi, {
	subscribeToCanvasMouseOver: i,
	...a
}) });
Ji.displayName = "CursorMarkerWrapper";
var jd = () => (0, import_jsx_runtime.jsx)(Lt, { children: ({ getLeftOffsetFromDate: a, getTimelineState: i }) => (0, import_jsx_runtime.jsx)(Ht, { children: ({ markers: s }) => {
	const u = i();
	return s.map((v) => {
		switch (v.type) {
			case xe.Today: return (/* @__PURE__ */ new Date()).valueOf() >= u.canvasTimeStart && (/* @__PURE__ */ new Date()).valueOf() <= u.canvasTimeEnd ? (0, import_jsx_runtime.jsx)(Vi, {
				getLeftOffsetFromDate: a,
				renderer: v.renderer,
				interval: v.interval
			}, v.id) : null;
			case xe.Custom: return v.date >= u.canvasTimeStart && v.date <= u.canvasTimeEnd ? (0, import_jsx_runtime.jsx)(qi, {
				renderer: v.renderer,
				date: v.date,
				getLeftOffsetFromDate: a
			}, v.id) : null;
			case xe.Cursor: return (0, import_jsx_runtime.jsx)(Ji, {
				renderer: v.renderer,
				getLeftOffsetFromDate: a
			}, v.id);
			default: return null;
		}
	});
} }) });
var Ad = {
	position: "absolute",
	left: 0,
	right: 0,
	top: 0,
	bottom: 0
};
var Ld = class extends import_react.Component {
	constructor() {
		super(...arguments), Object.defineProperty(this, "handleMouseMove", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (i) => {
				var s;
				if (this.subscription !== null) {
					const { pageX: u } = i, { left: v } = ((s = this.containerEl.current) == null ? void 0 : s.getBoundingClientRect()) ?? { left: 0 }, f = u - v, m = this.props.getDateFromLeftOffsetPosition(f);
					this.subscription({
						leftOffset: f,
						date: m,
						isCursorOverCanvas: !0
					});
				}
			}
		}), Object.defineProperty(this, "handleMouseLeave", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: () => {
				this.subscription !== null && this.subscription({
					leftOffset: 0,
					date: 0,
					isCursorOverCanvas: !1
				});
			}
		}), Object.defineProperty(this, "handleMouseMoveSubscribe", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (i) => (this.subscription = i, () => {
				this.subscription = null;
			})
		}), Object.defineProperty(this, "state", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: { subscribeToMouseOver: this.handleMouseMoveSubscribe }
		}), Object.defineProperty(this, "containerEl", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: import_react.createRef()
		}), Object.defineProperty(this, "subscription", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: null
		});
	}
	render() {
		return (0, import_jsx_runtime.jsx)(Cd, {
			value: this.state,
			children: (0, import_jsx_runtime.jsxs)("div", {
				style: Ad,
				onMouseMove: this.handleMouseMove,
				onMouseLeave: this.handleMouseLeave,
				ref: this.containerEl,
				children: [(0, import_jsx_runtime.jsx)(jd, {}), this.props.children]
			})
		});
	}
};
var Hd = (a) => (0, import_jsx_runtime.jsx)(Lt, { children: ({ getDateFromLeftOffsetPosition: i }) => (0, import_jsx_runtime.jsx)(Ld, {
	getDateFromLeftOffsetPosition: i,
	...a
}) });
function Wd(a) {
	a._resizeEventListener = () => a.resize(), window.addEventListener("resize", a._resizeEventListener);
}
function Fd(a) {
	window.removeEventListener("resize", a._resizeEventListener);
}
var gi = {
	addListener: Wd,
	removeListener: Fd
};
var Ud = {
	groupIdKey: "id",
	groupTitleKey: "title",
	groupRightTitleKey: "rightTitle",
	groupLabelKey: "title",
	itemIdKey: "id",
	itemTitleKey: "title",
	itemDivTitleKey: "title",
	itemGroupKey: "group",
	itemTimeStartKey: "start_time",
	itemTimeEndKey: "end_time"
};
var Nd = {
	second: 1,
	minute: 1,
	hour: 1,
	day: 1,
	month: 1,
	year: 1
};
var Gd = {
	year: {
		long: "YYYY",
		mediumLong: "YYYY",
		medium: "YYYY",
		short: "YY"
	},
	month: {
		long: "MMMM YYYY",
		mediumLong: "MMMM",
		medium: "MMMM",
		short: "MM/YY"
	},
	week: {
		long: "w",
		mediumLong: "w",
		medium: "w",
		short: "w"
	},
	day: {
		long: "dddd, LL",
		mediumLong: "dddd, LL",
		medium: "dd D",
		short: "D"
	},
	hour: {
		long: "dddd, LL, HH:00",
		mediumLong: "L, HH:00",
		medium: "HH:00",
		short: "HH"
	},
	minute: {
		long: "HH:mm",
		mediumLong: "HH:mm",
		medium: "HH:mm",
		short: "mm"
	},
	second: {
		long: "mm:ss",
		mediumLong: "mm:ss",
		medium: "mm:ss",
		short: "ss"
	}
};
var Qi = import_react.createContext({
	registerScroll: () => (console.warn("default registerScroll header used"), wt),
	rightSidebarWidth: 0,
	leftSidebarWidth: 150,
	timeSteps: {}
});
var Kd = class extends import_react.Component {
	render() {
		const i = {
			rightSidebarWidth: this.props.rightSidebarWidth,
			leftSidebarWidth: this.props.leftSidebarWidth,
			timeSteps: this.props.timeSteps,
			registerScroll: this.props.registerScroll
		};
		return (0, import_jsx_runtime.jsx)(Qi.Provider, {
			value: i,
			children: this.props.children
		});
	}
};
var Xd = Qi;
var Wr = () => (0, import_react.useContext)(Xd);
var eo = { exports: {} };
/*!
Copyright (c) 2018 Jed Watson.
Licensed under the MIT License (MIT), see
http://jedwatson.github.io/classnames
*/
(function(a) {
	(function() {
		var i = {}.hasOwnProperty;
		function s() {
			for (var f = "", m = 0; m < arguments.length; m++) {
				var y = arguments[m];
				y && (f = v(f, u(y)));
			}
			return f;
		}
		function u(f) {
			if (typeof f == "string" || typeof f == "number") return f;
			if (typeof f != "object") return "";
			if (Array.isArray(f)) return s.apply(null, f);
			if (f.toString !== Object.prototype.toString && !f.toString.toString().includes("[native code]")) return f.toString();
			var m = "";
			for (var y in f) i.call(f, y) && f[y] && (m = v(m, y));
			return m;
		}
		function v(f, m) {
			return m ? f ? f + " " + m : f + m : f;
		}
		a.exports ? (s.default = s, a.exports = s) : window.classNames = s;
	})();
})(eo);
var Bd = eo.exports;
var mi = /* @__PURE__ */ rt(Bd);
var Vd = "left";
var to = "right";
var qd = class extends import_react.PureComponent {
	constructor() {
		super(...arguments), Object.defineProperty(this, "getRootProps", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (i = {}) => {
				const { style: s } = i, u = this.props.variant === to ? this.props.rightSidebarWidth : this.props.leftSidebarWidth;
				return { style: {
					color: (s == null ? void 0 : s.color) ?? "#fff",
					...s,
					width: u
				} };
			}
		}), Object.defineProperty(this, "getStateAndHelpers", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: () => ({
				getRootProps: this.getRootProps,
				data: this.props.headerData
			})
		});
	}
	render() {
		const i = this.getStateAndHelpers();
		return this.props.children(i);
	}
};
var Zd = ({ getRootProps: a }) => (0, import_jsx_runtime.jsx)("div", {
	"data-testid": "sidebarHeader",
	...a()
});
var St = (a) => {
	const { children: i, variant: s = Vd, headerData: u } = a, { leftSidebarWidth: v, rightSidebarWidth: f } = Wr();
	return (0, import_jsx_runtime.jsx)(qd, {
		leftSidebarWidth: v,
		rightSidebarWidth: f,
		variant: s,
		headerData: u,
		children: i || Zd
	});
};
St.secretKey = "SidebarHeader";
var Jd = class extends import_react.Component {
	constructor() {
		super(...arguments), Object.defineProperty(this, "getRootStyle", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: () => ({
				...this.props.style,
				display: "flex",
				width: "100%"
			})
		}), Object.defineProperty(this, "getCalendarHeaderStyle", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: () => {
				const { leftSidebarWidth: i, rightSidebarWidth: s, calendarHeaderStyle: u } = this.props;
				return {
					...u,
					overflow: "hidden",
					width: `calc(100% - ${i + s}px)`
				};
			}
		}), Object.defineProperty(this, "isSidebarHeader", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (i) => i.type === void 0 ? !1 : i.type.secretKey === St.secretKey
		});
	}
	render() {
		let i, s;
		const u = [], v = Array.isArray(this.props.children) ? this.props.children.filter((f) => f) : [this.props.children];
		return import_react.Children.map(v, (f) => {
			var m;
			this.isSidebarHeader(f) ? ((m = f == null ? void 0 : f.props) == null ? void 0 : m.variant) === to ? i = f : s = f : u.push(f);
		}), s || (s = (0, import_jsx_runtime.jsx)(St, {})), !i && this.props.rightSidebarWidth && (i = (0, import_jsx_runtime.jsx)(St, { variant: "right" })), (0, import_jsx_runtime.jsxs)("div", {
			"data-testid": "headerRootDiv",
			style: this.getRootStyle(),
			className: mi("rct-header-root", this.props.className),
			children: [
				s,
				(0, import_jsx_runtime.jsx)("div", {
					ref: this.props.registerScroll,
					style: this.getCalendarHeaderStyle(),
					className: mi("rct-calendar-header", this.props.calendarHeaderClassName),
					"data-testid": "headerContainer",
					children: u
				}),
				i
			]
		});
	}
};
var Er = ({ children: a, style: i, className: s, calendarHeaderStyle: u, calendarHeaderClassName: v }) => {
	const { leftSidebarWidth: f, rightSidebarWidth: m, registerScroll: y } = Wr();
	return (0, import_jsx_runtime.jsx)(Jd, {
		leftSidebarWidth: f,
		rightSidebarWidth: m,
		registerScroll: y,
		style: i,
		className: s,
		calendarHeaderStyle: u,
		calendarHeaderClassName: v,
		children: a
	});
};
Er.secretKey = "TimelineHeaders";
var ro = class extends import_react.Component {
	constructor(i) {
		super(i), Object.defineProperty(this, "getHeaderIntervals", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: ({ canvasTimeStart: S, canvasTimeEnd: C, unit: D, timeSteps: R, getLeftOffsetFromDate: T }) => {
				const P = [];
				return Rr(S, C, D, R, (_, O) => {
					const k = T(_.valueOf()), H = T(O.valueOf()) - k;
					P.push({
						startTime: _,
						endTime: O,
						labelWidth: H,
						left: k
					});
				}), P;
			}
		}), Object.defineProperty(this, "getRootProps", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (S = {}) => {
				const { style: C } = S;
				return { style: Object.assign({}, C || {}, {
					position: "relative",
					width: this.props.canvasWidth,
					height: this.props.height
				}) };
			}
		}), Object.defineProperty(this, "getIntervalProps", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (S = {}) => {
				const { interval: C, style: D } = S;
				if (!C) throw new Error("you should provide interval to the prop getter");
				const { startTime: R, labelWidth: T, left: P } = C;
				return {
					style: {
						...D,
						left: P,
						width: T,
						position: "absolute"
					},
					key: `label-${R.valueOf()}`
				};
			}
		}), Object.defineProperty(this, "getStateAndHelpers", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: () => {
				const { unit: S, showPeriod: C, headerData: D } = this.props;
				return {
					headerContext: {
						unit: S,
						intervals: this.state.intervals
					},
					getRootProps: this.getRootProps,
					getIntervalProps: this.getIntervalProps,
					showPeriod: C,
					data: D
				};
			}
		});
		const { canvasTimeStart: s, canvasTimeEnd: u, unit: v, timeSteps: f, getLeftOffsetFromDate: m } = i, y = this.getHeaderIntervals({
			canvasTimeStart: s,
			canvasTimeEnd: u,
			unit: v,
			timeSteps: f,
			getLeftOffsetFromDate: m
		});
		this.state = { intervals: y };
	}
	componentDidUpdate(i) {
		if (!xr(i, this.props)) {
			const { canvasTimeStart: s, canvasTimeEnd: u, unit: v, timeSteps: f, getLeftOffsetFromDate: m } = this.props, y = this.getHeaderIntervals({
				canvasTimeStart: s,
				canvasTimeEnd: u,
				unit: v,
				timeSteps: f,
				getLeftOffsetFromDate: m
			});
			this.setState({ intervals: y });
		}
	}
	render() {
		const i = this.getStateAndHelpers();
		return this.props.children(i);
	}
};
Object.defineProperty(ro, "defaultProps", {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: { height: 30 }
});
function Qd({ children: a, unit: i, headerData: s, height: u }) {
	const { getTimelineState: v, showPeriod: f, getLeftOffsetFromDate: m } = hd(), y = v(), { timeSteps: S } = Wr();
	return (0, import_jsx_runtime.jsx)(ro, {
		children: a,
		timeSteps: S,
		showPeriod: f,
		unit: i || y.timelineUnit,
		...y,
		headerData: s,
		getLeftOffsetFromDate: m,
		height: u
	});
}
var bi = Number.isNaN || function(i) {
	return typeof i == "number" && i !== i;
};
function ef(a, i) {
	return !!(a === i || bi(a) && bi(i));
}
function tf(a, i) {
	if (a.length !== i.length) return !1;
	for (var s = 0; s < a.length; s++) if (!ef(a[s], i[s])) return !1;
	return !0;
}
function yi(a, i) {
	i === void 0 && (i = tf);
	var s = null;
	function u() {
		for (var v = [], f = 0; f < arguments.length; f++) v[f] = arguments[f];
		if (s && s.lastThis === this && i(v, s.lastArgs)) return s.lastResult;
		var m = a.apply(this, v);
		return s = {
			lastResult: m,
			lastArgs: v,
			lastThis: this
		}, m;
	}
	return u.clear = function() {
		s = null;
	}, u;
}
var rf = class extends import_react.PureComponent {
	constructor() {
		super(...arguments), Object.defineProperty(this, "onIntervalClick", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: () => {
				const { primaryHeader: i, interval: s, unit: u, showPeriod: v } = this.props;
				if (i) {
					const f = Dr(u);
					v(s.startTime.clone().startOf(f), s.startTime.clone().endOf(f));
				} else v(s.startTime, s.endTime);
			}
		}), Object.defineProperty(this, "getIntervalProps", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (i = {}) => ({
				...this.props.getIntervalProps({
					interval: this.props.interval,
					...i
				}),
				onClick: Pe(this.onIntervalClick, i.onClick)
			})
		});
	}
	render() {
		const { intervalText: i, interval: s, intervalRenderer: u, headerData: v } = this.props, f = u;
		if (f) return f({
			getIntervalProps: this.getIntervalProps,
			intervalContext: {
				interval: s,
				intervalText: i
			},
			data: v
		});
		const { key: m, ...y } = this.getIntervalProps();
		return (0, import_react.createElement)("div", {
			"data-testid": "dateHeaderInterval",
			...y,
			key: m,
			className: `rct-dateHeader ${this.props.primaryHeader ? "rct-dateHeader-primary" : ""}`
		}, (0, import_jsx_runtime.jsx)("span", { children: i }));
	}
};
function nf({ headerContext: { intervals: a, unit: i }, getRootProps: s, getIntervalProps: u, showPeriod: v, data: { style: f, intervalRenderer: m, className: y, getLabelFormat: S, unitProp: C, headerData: D } }) {
	return (0, import_jsx_runtime.jsx)("div", {
		"data-testid": "dateHeader",
		className: y,
		...s({ style: f }),
		children: a.map((R) => {
			const T = S([R.startTime, R.endTime], i, R.labelWidth);
			return (0, import_jsx_runtime.jsx)(rf, {
				unit: i,
				interval: R,
				showPeriod: v,
				intervalText: T,
				primaryHeader: C === "primaryHeader",
				getIntervalProps: u,
				intervalRenderer: m,
				headerData: D
			}, `label-${R.startTime.valueOf()}`);
		})
	});
}
var of = class extends import_react.Component {
	constructor() {
		super(...arguments), Object.defineProperty(this, "getHeaderUnit", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: () => this.props.unit === "primaryHeader" ? Dr(this.props.timelineUnit) : this.props.unit ? this.props.unit : this.props.timelineUnit
		}), Object.defineProperty(this, "getRootStyle", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: yi((i) => ({
				height: 30,
				...i
			}))
		}), Object.defineProperty(this, "getLabelFormat", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (i, s, u) => {
				const { labelFormat: v } = this.props;
				if (typeof v == "string") return i[0].format(v);
				if (typeof v == "function") return v(i, s, u);
				throw new Error("labelFormat should be function or string");
			}
		}), Object.defineProperty(this, "getHeaderData", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: yi((i, s, u, v, f, m) => ({
				intervalRenderer: i,
				style: s,
				className: u,
				getLabelFormat: v,
				unitProp: f,
				headerData: m
			}))
		});
	}
	render() {
		const i = this.getHeaderUnit(), { height: s } = this.props;
		return (0, import_jsx_runtime.jsx)(Qd, {
			children: nf,
			unit: i,
			height: s,
			headerData: this.getHeaderData(this.props.intervalRenderer, this.getRootStyle(this.props.style), this.props.className, this.getLabelFormat, this.props.unit, this.props.headerData)
		});
	}
};
function Ti({ labelFormat: a, unit: i, style: s, className: u, intervalRenderer: v, headerData: f, height: m }) {
	return (0, import_jsx_runtime.jsx)(Lt, { children: ({ getTimelineState: y }) => {
		const S = y();
		return (0, import_jsx_runtime.jsx)(of, {
			timelineUnit: S.timelineUnit,
			unit: i,
			labelFormat: a || sf,
			style: s,
			className: u,
			intervalRenderer: v,
			headerData: f,
			height: m
		});
	} });
}
var sf = ([a], i, s = 150, u = Gd) => {
	let v;
	return s >= 150 ? v = u[i].long : s >= 100 ? v = u[i].mediumLong : s >= 50 ? v = u[i].medium : v = u[i].short, a.format(v);
};
var no = { exports: {} };
(function(a, i) {
	(function(s, u) {
		a.exports = u();
	})(Ie, function() {
		var s = {
			LTS: "h:mm:ss A",
			LT: "h:mm A",
			L: "MM/DD/YYYY",
			LL: "MMMM D, YYYY",
			LLL: "MMMM D, YYYY h:mm A",
			LLLL: "dddd, MMMM D, YYYY h:mm A"
		};
		return function(u, v, f) {
			var m = v.prototype, y = m.format;
			f.en.formats = s, m.format = function(S) {
				S === void 0 && (S = "YYYY-MM-DDTHH:mm:ssZ");
				var C = this.$locale().formats, D = function(R, T) {
					return R.replace(/(\[[^\]]+])|(LTS?|l{1,4}|L{1,4})/g, function(P, _, O) {
						var k = O && O.toUpperCase();
						return _ || T[O] || s[O] || T[k].replace(/(\[[^\]]+])|(MMMM|MM|DD|dddd)/g, function(L, H, X) {
							return H || X.slice(1);
						});
					});
				}(S, C === void 0 ? {} : C);
				return y.call(this, D);
			};
		};
	});
})(no);
var af = no.exports;
var lf = /* @__PURE__ */ rt(af);
import_dayjs_min.default.extend(lf);
var io = class extends import_react.Component {
	constructor(i) {
		super(i), Object.defineProperty(this, "getTimelineContext", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: () => {
				const { width: T, visibleTimeStart: P, visibleTimeEnd: _, canvasTimeStart: O, canvasTimeEnd: k } = this.state, L = _ - P;
				return {
					canvasWidth: ve(T, this.props.buffer),
					timelineUnit: xt(L, T, this.props.timeSteps),
					timelineWidth: T,
					visibleTimeStart: P,
					visibleTimeEnd: _,
					canvasTimeStart: O,
					canvasTimeEnd: k
				};
			}
		}), Object.defineProperty(this, "getTimelineUnit", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: () => {
				const { width: T, visibleTimeStart: P, visibleTimeEnd: _ } = this.state, { timeSteps: O } = this.props;
				return xt(_ - P, T, O);
			}
		}), Object.defineProperty(this, "state", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: void 0
		}), Object.defineProperty(this, "scrollComponent", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: null
		}), Object.defineProperty(this, "scrollHeaderRef", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: null
		}), Object.defineProperty(this, "resize", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (T = this.props) => {
				var V;
				const { width: P } = ((V = this.container.current) == null ? void 0 : V.getBoundingClientRect()) ?? { width: 0 }, _ = P - T.sidebarWidth - T.rightSidebarWidth, O = ve(_, T.buffer), { dimensionItems: k, height: L, groupHeights: H, groupTops: X } = $e(T.items, T.groups, O, this.state.canvasTimeStart, this.state.canvasTimeEnd, T.keys, T.lineHeight, T.itemHeightRatio, T.stackItems, this.state.draggingItem, this.state.resizingItem, this.state.dragTime, this.state.resizingEdge, this.state.resizeTime, this.state.newGroupOrder, T.itemVerticalGap);
				this.setState({
					width: _,
					dimensionItems: k,
					height: L,
					groupHeights: H,
					groupTops: X
				});
				const B = _ * ((T.buffer - 1) / 2);
				this.scrollComponent && (this.scrollComponent.scrollLeft = B), this.scrollHeaderRef && (this.scrollHeaderRef.scrollLeft = B);
			}
		}), Object.defineProperty(this, "onScroll", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (T) => {
				var L, H;
				const P = this.state.width, _ = this.state.canvasTimeStart, O = this.state.visibleTimeEnd - this.state.visibleTimeStart, k = _ + O * T / P;
				(this.state.visibleTimeStart !== k || this.state.visibleTimeEnd !== k + O) && ((H = (L = this.props).onTimeChange) == null || H.call(L, k, k + O, this.updateScrollCanvas, this.getTimelineUnit()));
			}
		}), Object.defineProperty(this, "updateScrollCanvas", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (T, P, _ = !1, O = this.props.items, k = this.props.groups) => {
				this.setState(Cr(T, P, _, O, k, this.props, this.state));
			}
		}), Object.defineProperty(this, "handleWheelZoom", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (T, P, _) => {
				this.changeZoom(1 + T * _ / 500, P / this.state.width);
			}
		}), Object.defineProperty(this, "changeZoom", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (T, P = .5) => {
				const { minZoom: _, maxZoom: O } = this.props, k = this.state.visibleTimeEnd - this.state.visibleTimeStart, L = Math.min(Math.max(Math.round(k * T), _), O), H = Math.round(this.state.visibleTimeStart + (k - L) * P);
				this.props.onTimeChange && this.props.onTimeChange(H, H + L, this.updateScrollCanvas, this.getTimelineUnit());
			}
		}), Object.defineProperty(this, "showPeriod", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (T, P) => {
				var L, H;
				const _ = T.valueOf(), k = P.valueOf() - _;
				k < this.props.minZoom || (H = (L = this.props).onTimeChange) == null || H.call(L, _, _ + k, this.updateScrollCanvas, this.getTimelineUnit());
			}
		}), Object.defineProperty(this, "selectItem", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (T, P, _) => {
				if (this.isItemSelected(T) || this.props.itemTouchSendsClick && P === "touch") {
					if (T && this.props.onItemClick) {
						const O = this.timeFromItemEvent(_);
						this.props.onItemClick(T, _, O);
					}
				} else if (this.setState({ selectedItem: T }), T && this.props.onItemSelect) {
					const O = this.timeFromItemEvent(_);
					this.props.onItemSelect(T, _, O);
				} else T === null && this.props.onItemDeselect && this.props.onItemDeselect(_);
			}
		}), Object.defineProperty(this, "doubleClickItem", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (T, P) => {
				if (this.props.onItemDoubleClick) {
					const _ = this.timeFromItemEvent(P);
					this.props.onItemDoubleClick(T, P, _);
				}
			}
		}), Object.defineProperty(this, "contextMenuClickItem", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (T, P) => {
				if (this.props.onItemContextMenu) {
					const _ = this.timeFromItemEvent(P);
					this.props.onItemContextMenu(T, P, _);
				}
			}
		}), Object.defineProperty(this, "getTimeFromRowClickEvent", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (T) => {
				const { dragSnap: P, buffer: _ } = this.props, { width: O, canvasTimeStart: k, canvasTimeEnd: L } = this.state, { offsetX: H } = T.nativeEvent;
				let X = Mr(k, L, ve(O, _), H);
				return X = Math.floor(X / P) * P, X;
			}
		}), Object.defineProperty(this, "timeFromItemEvent", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (T) => {
				const { width: P, visibleTimeStart: _, visibleTimeEnd: O } = this.state, k = this.props.dragSnap, { left: H } = this.scrollComponent.getBoundingClientRect(), le = (T.clientX - H) / P * (O - _);
				let w = Math.round(_ + le);
				return w = Math.floor(w / k) * k, w;
			}
		}), Object.defineProperty(this, "dragItem", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (T, P, _) => {
				const O = this.props.groups[_], k = this.props.keys;
				this.setState({
					draggingItem: T,
					dragTime: P,
					newGroupOrder: _,
					dragGroupTitle: O ? Y(O, k.groupLabelKey) : ""
				}), this.updatingItem({
					eventType: "move",
					itemId: T,
					time: P,
					newGroupOrder: _
				});
			}
		}), Object.defineProperty(this, "dropItem", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (T, P, _) => {
				this.setState({
					draggingItem: null,
					dragTime: null,
					dragGroupTitle: null
				}), this.props.onItemMove && this.props.onItemMove(T, P, _);
			}
		}), Object.defineProperty(this, "resizingItem", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (T, P, _) => {
				this.setState({
					resizingItem: T,
					resizingEdge: _,
					resizeTime: P
				}), this.updatingItem({
					eventType: "resize",
					itemId: T,
					time: P,
					edge: _ || void 0
				});
			}
		}), Object.defineProperty(this, "resizedItem", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (T, P, _, O) => {
				this.setState({
					resizingItem: null,
					resizingEdge: null,
					resizeTime: null
				}), this.props.onItemResize && O !== 0 && this.props.onItemResize(T, P, _);
			}
		}), Object.defineProperty(this, "updatingItem", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: ({ eventType: T, itemId: P, time: _, edge: O, newGroupOrder: k }) => {
				this.props.onItemDrag && (T === "move" ? this.props.onItemDrag({
					eventType: T,
					itemId: P,
					time: _,
					newGroupOrder: k
				}) : this.props.onItemDrag({
					eventType: T,
					itemId: P,
					time: _,
					edge: O
				}));
			}
		}), Object.defineProperty(this, "handleRowClick", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (T, P) => {
				if (this.hasSelectedItem() && this.selectItem(null, "click", T), this.props.onCanvasClick == null) return;
				const _ = this.getTimeFromRowClickEvent(T), O = Y(this.props.groups[P], this.props.keys.groupIdKey);
				this.props.onCanvasClick(O, _, T);
			}
		}), Object.defineProperty(this, "handleRowDoubleClick", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (T, P) => {
				if (this.props.onCanvasDoubleClick == null) return;
				const _ = this.getTimeFromRowClickEvent(T), O = Y(this.props.groups[P], this.props.keys.groupIdKey);
				this.props.onCanvasDoubleClick(O, _, T);
			}
		}), Object.defineProperty(this, "handleScrollContextMenu", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (T, P) => {
				if (this.props.onCanvasContextMenu == null) return;
				const _ = this.getTimeFromRowClickEvent(T), O = Y(this.props.groups[P], this.props.keys.groupIdKey);
				this.props.onCanvasContextMenu && (T.preventDefault(), this.props.onCanvasContextMenu(O, _, T));
			}
		}), Object.defineProperty(this, "handleHeaderRef", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (T) => {
				this.scrollHeaderRef = T, this.props.headerRef && this.props.headerRef(T);
			}
		}), Object.defineProperty(this, "isTimelineHeader", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (T) => T.type === void 0 ? !1 : T.type.secretKey === Er.secretKey
		}), Object.defineProperty(this, "renderHeaders", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: () => {
				if (this.props.children) {
					let T;
					if (import_react.Children.map(this.props.children, (P) => {
						this.isTimelineHeader(P) && (T = P);
					}), T) return T;
				}
				return (0, import_jsx_runtime.jsxs)(Er, { children: [(0, import_jsx_runtime.jsx)(Ti, { unit: "primaryHeader" }), (0, import_jsx_runtime.jsx)(Ti, {})] });
			}
		}), Object.defineProperty(this, "getScrollElementRef", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (T) => {
				this.props.scrollRef && this.props.scrollRef(T), this.scrollComponent = T;
			}
		}), Object.defineProperty(this, "container", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: import_react.createRef()
		}), Object.defineProperty(this, "getBoundingClientRect", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: () => this.scrollComponent.getBoundingClientRect()
		}), Object.defineProperty(this, "calculateDropCoordinatesToTimeAndGroup", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: (T, P) => {
				const _ = ve(this.state.width, this.props.buffer), O = Mt(this.state.canvasTimeStart, this.state.canvasTimeEnd, _), k = Ct(this.scrollComponent).offsetLeft, L = Ot(this.scrollComponent), H = (T - k + L.scrollLeft) * O + this.state.canvasTimeStart;
				let X = 0;
				for (const V of this.state.groupTops) if (P > Number(V)) X = this.state.groupTops.indexOf(V);
				else break;
				if (!this.props.dragSnap) return {
					time: H,
					groupIndex: X
				};
				const B = (0, import_dayjs_min.default)().utcOffset() * 60 * 1e3;
				return {
					time: Math.round(H / this.props.dragSnap) * this.props.dragSnap - B % this.props.dragSnap,
					groupIndex: X
				};
			}
		}), this.getSelected = this.getSelected.bind(this), this.hasSelectedItem = this.hasSelectedItem.bind(this), this.isItemSelected = this.isItemSelected.bind(this);
		let s = null, u = null;
		if (this.props.defaultTimeStart && this.props.defaultTimeEnd) s = this.props.defaultTimeStart, u = this.props.defaultTimeEnd;
		else if (this.props.visibleTimeStart && this.props.visibleTimeEnd) s = this.props.visibleTimeStart, u = this.props.visibleTimeEnd;
		else throw new Error("You must provide either \"defaultTimeStart\" and \"defaultTimeEnd\" or \"visibleTimeStart\" and \"visibleTimeEnd\" to initialize the Timeline");
		const [v, f] = $r(s, u, i.buffer), m = {
			width: 1e3,
			visibleTimeStart: s,
			visibleTimeEnd: u,
			canvasTimeStart: v,
			canvasTimeEnd: f,
			selectedItem: null,
			dragTime: null,
			dragGroupTitle: null,
			resizeTime: null,
			resizingItem: null,
			resizingEdge: null,
			newGroupOrder: 0
		}, y = ve(m.width, i.buffer), { dimensionItems: S, height: C, groupHeights: D, groupTops: R } = $e(i.items, i.groups, y, m.canvasTimeStart, m.canvasTimeEnd, i.keys, i.lineHeight, i.itemHeightRatio, i.stackItems, m.draggingItem, m.resizingItem, m.dragTime, m.resizingEdge, m.resizeTime, m.newGroupOrder, i.itemVerticalGap);
		m.dimensionItems = S, m.height = C, m.groupHeights = D, m.groupTops = R, this.state = m;
	}
	componentDidMount() {
		this.resize(this.props), this.props.resizeDetector && this.props.resizeDetector.addListener && this.props.resizeDetector.addListener(this), gi.addListener(this);
	}
	componentWillUnmount() {
		this.props.resizeDetector && this.props.resizeDetector.addListener && this.props.resizeDetector.removeListener(this), gi.removeListener(this);
	}
	static getDerivedStateFromProps(i, s) {
		const { visibleTimeStart: u, visibleTimeEnd: v, items: f, groups: m } = i, y = {
			items: f,
			groups: m
		}, S = f !== s.items || m !== s.groups;
		if (u && v) Object.assign(y, Cr(u, v, S, f, m, i, s));
		else if (S) {
			const C = ve(s.width, i.buffer);
			Object.assign(y, $e(f, m, C, s.canvasTimeStart, s.canvasTimeEnd, i.keys, i.lineHeight, i.itemHeightRatio, i.stackItems, s.draggingItem, s.resizingItem, s.dragTime, s.resizingEdge, s.resizeTime, s.newGroupOrder, i.itemVerticalGap));
		}
		return y;
	}
	componentDidUpdate(i, s) {
		const u = this.state.visibleTimeEnd - this.state.visibleTimeStart, v = s.visibleTimeEnd - s.visibleTimeStart;
		this.props.onZoom && u !== v && this.props.onZoom(this.getTimelineContext(), this.getTimelineUnit()), this.props.onBoundsChange && this.state.canvasTimeStart !== s.canvasTimeStart && this.props.onBoundsChange(this.state.canvasTimeStart, this.state.canvasTimeStart + u * 3);
		const f = Math.round(this.state.width * (this.state.visibleTimeStart - this.state.canvasTimeStart) / u);
		(Math.round(s.width * (s.visibleTimeStart - s.canvasTimeStart) / v) !== f || this.scrollComponent.scrollLeft !== f) && (this.scrollComponent.scrollLeft = f, this.scrollHeaderRef.scrollLeft = f);
	}
	columns(i, s, u, v, f, m) {
		var y;
		return (0, import_jsx_runtime.jsx)(md, {
			canvasTimeStart: i,
			canvasTimeEnd: s,
			canvasWidth: u,
			lineCount: ((y = this.props.groups) == null ? void 0 : y.length) || 0,
			minUnit: v,
			timeSteps: f,
			height: m,
			verticalLineClassNamesForTime: this.props.verticalLineClassNamesForTime
		});
	}
	rows(i, s, u) {
		var v;
		return (0, import_jsx_runtime.jsx)(Td, {
			groups: u,
			canvasWidth: i,
			lineCount: ((v = this.props.groups) == null ? void 0 : v.length) || 0,
			groupHeights: s,
			clickTolerance: this.props.clickTolerance,
			onRowClick: this.handleRowClick,
			onRowDoubleClick: this.handleRowDoubleClick,
			horizontalLineClassNamesForGroup: this.props.horizontalLineClassNamesForGroup,
			onRowContextClick: this.handleScrollContextMenu
		});
	}
	items({ canvasTimeStart: i, canvasTimeEnd: s, canvasWidth: u, dimensionItems: v, groupTops: f }) {
		return (0, import_jsx_runtime.jsx)(vd, {
			canvasTimeStart: i,
			canvasTimeEnd: s,
			canvasWidth: u,
			dimensionItems: v,
			groupTops: f,
			items: this.props.items,
			groups: this.props.groups,
			keys: this.props.keys,
			selectedItem: this.state.selectedItem || void 0,
			dragSnap: this.props.dragSnap,
			minResizeWidth: this.props.minResizeWidth,
			canChangeGroup: this.props.canChangeGroup,
			canMove: this.props.canMove,
			canResize: this.props.canResize,
			useResizeHandle: this.props.useResizeHandle,
			canSelect: this.props.canSelect,
			moveResizeValidator: this.props.moveResizeValidator,
			itemSelect: this.selectItem,
			itemDrag: this.dragItem,
			itemDrop: this.dropItem,
			onItemDoubleClick: this.doubleClickItem,
			onItemContextMenu: this.props.onItemContextMenu ? this.contextMenuClickItem : void 0,
			itemResizing: this.resizingItem,
			itemResized: this.resizedItem,
			itemRenderer: this.props.itemRenderer,
			selected: this.props.selected,
			scrollRef: this.scrollComponent
		});
	}
	sidebar(i, s) {
		const { sidebarWidth: u } = this.props;
		return u && (0, import_jsx_runtime.jsx)(fi, {
			groups: this.props.groups,
			groupRenderer: this.props.groupRenderer,
			keys: this.props.keys,
			width: u,
			groupHeights: s,
			height: i
		});
	}
	rightSidebar(i, s) {
		const { rightSidebarWidth: u } = this.props;
		return u && (0, import_jsx_runtime.jsx)(fi, {
			groups: this.props.groups,
			keys: this.props.keys,
			groupRenderer: this.props.groupRenderer,
			isRightSidebar: !0,
			width: u,
			groupHeights: s,
			height: i
		});
	}
	childrenWithProps(i, s, u, v, f, m, y, S, C, D, R) {
		if (!this.props.children) return null;
		const T = Array.isArray(this.props.children) ? this.props.children.filter((_) => _) : [this.props.children], P = {
			canvasTimeStart: i,
			canvasTimeEnd: s,
			canvasWidth: u,
			visibleTimeStart: S,
			visibleTimeEnd: C,
			dimensionItems: v,
			items: this.props.items,
			groups: this.props.groups,
			keys: this.props.keys,
			groupHeights: f,
			groupTops: m,
			selected: this.getSelected(),
			height: y,
			minUnit: D,
			timeSteps: R
		};
		return import_react.Children.map(T, (_) => this.isTimelineHeader(_) ? null : import_react.cloneElement(_, P));
	}
	getSelected() {
		return this.state.selectedItem && !this.props.selected ? [this.state.selectedItem] : this.props.selected || [];
	}
	hasSelectedItem() {
		return Array.isArray(this.props.selected) ? this.props.selected.length > 0 : !!this.state.selectedItem;
	}
	isItemSelected(i) {
		return this.getSelected().some((u) => u === i);
	}
	render() {
		const { items: i, groups: s, sidebarWidth: u, rightSidebarWidth: v, timeSteps: f, traditionalZoom: m, buffer: y } = this.props, { draggingItem: S, resizingItem: C, width: D, visibleTimeStart: R, visibleTimeEnd: T, canvasTimeStart: P, canvasTimeEnd: _ } = this.state;
		let { dimensionItems: O, height: k, groupHeights: L, groupTops: H } = this.state;
		const X = T - R, B = ve(D, y), V = xt(X, D, f);
		if (!!S || !!C) {
			const ce = $e(i, s, B, this.state.canvasTimeStart, this.state.canvasTimeEnd, this.props.keys, this.props.lineHeight, this.props.itemHeightRatio, this.props.stackItems, this.state.draggingItem, this.state.resizingItem, this.state.dragTime, this.state.resizingEdge, this.state.resizeTime, this.state.newGroupOrder, this.props.itemVerticalGap);
			O = ce.dimensionItems, k = ce.height, L = ce.groupHeights, H = ce.groupTops;
		}
		const w = { height: `${k}px` };
		return (0, import_jsx_runtime.jsx)(pd, {
			visibleTimeStart: R,
			visibleTimeEnd: T,
			canvasTimeStart: P,
			canvasTimeEnd: _,
			canvasWidth: B,
			showPeriod: this.showPeriod,
			timelineUnit: V,
			timelineWidth: this.state.width,
			children: (0, import_jsx_runtime.jsx)(Rd, { children: (0, import_jsx_runtime.jsx)(Kd, {
				registerScroll: this.handleHeaderRef,
				timeSteps: f,
				leftSidebarWidth: this.props.sidebarWidth,
				rightSidebarWidth: this.props.rightSidebarWidth,
				children: (0, import_jsx_runtime.jsxs)("div", {
					style: this.props.style,
					ref: this.container,
					className: `react-calendar-timeline ${this.props.className}`,
					children: [this.renderHeaders(), (0, import_jsx_runtime.jsxs)("div", {
						style: w,
						className: "rct-outer",
						children: [
							u > 0 ? this.sidebar(k, L) : null,
							(0, import_jsx_runtime.jsx)(wd, {
								scrollRef: this.getScrollElementRef,
								width: D,
								height: k,
								onZoom: this.changeZoom,
								onWheelZoom: this.handleWheelZoom,
								traditionalZoom: !!m,
								onScroll: this.onScroll,
								children: (0, import_jsx_runtime.jsxs)(Hd, { children: [
									this.columns(P, _, B, V, f, k),
									this.rows(B, L, s),
									this.items({
										canvasTimeStart: P,
										canvasTimeEnd: _,
										canvasWidth: B,
										dimensionItems: O,
										groupTops: H
									}),
									this.childrenWithProps(P, _, B, O, L, H, k, R, T, V, f)
								] })
							}),
							v > 0 ? this.rightSidebar(k, L) : null
						]
					})]
				})
			}) })
		});
	}
};
Object.defineProperty(io, "setDayjsLocale", {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: import_dayjs_min.default.locale
});
Object.defineProperty(io, "defaultProps", {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: {
		sidebarWidth: 150,
		rightSidebarWidth: 0,
		dragSnap: 9e5,
		minResizeWidth: 20,
		lineHeight: 30,
		itemHeightRatio: .65,
		buffer: 3,
		minZoom: 36e5,
		maxZoom: 15778368e4,
		clickTolerance: 3,
		canChangeGroup: !0,
		canMove: !0,
		canResize: "right",
		useResizeHandle: !1,
		canSelect: !0,
		stackItems: !1,
		traditionalZoom: !1,
		horizontalLineClassNamesForGroup: null,
		onItemMove: null,
		onItemResize: null,
		onItemClick: null,
		onItemSelect: null,
		onItemDeselect: null,
		onItemDrag: null,
		onCanvasClick: null,
		onItemDoubleClick: null,
		onItemContextMenu: null,
		onZoom: null,
		verticalLineClassNamesForTime: null,
		moveResizeValidator: null,
		dayBackground: null,
		defaultTimeStart: null,
		defaultTimeEnd: null,
		itemTouchSendsClick: !1,
		style: {},
		className: "",
		keys: Ud,
		timeSteps: Nd,
		headerRef: () => {},
		scrollRef: () => {},
		visibleTimeStart: null,
		visibleTimeEnd: null,
		onTimeChange: function(a, i, s) {
			s(a, i);
		},
		onBoundsChange: null,
		children: null,
		selected: null
	}
});
var wf = (a) => a.children || null;
var oo = class extends import_react.Component {
	constructor() {
		super(...arguments), Object.defineProperty(this, "unsubscribe", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: null
		}), Object.defineProperty(this, "getMarker", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: null
		});
	}
	componentDidMount() {
		const { unsubscribe: i, getMarker: s } = this.props.subscribeMarker({
			type: xe.Today,
			renderer: this.props.children,
			interval: this.props.interval
		});
		this.unsubscribe = i, this.getMarker = s;
	}
	componentWillUnmount() {
		this.unsubscribe != null && (this.unsubscribe(), this.unsubscribe = null);
	}
	componentDidUpdate(i) {
		if (i.interval !== this.props.interval && this.getMarker) {
			const s = this.getMarker();
			this.props.updateMarker({
				...s,
				interval: this.props.interval
			});
		}
	}
	render() {
		return null;
	}
};
Object.defineProperty(oo, "defaultProps", {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: { interval: 1e4 }
});
var cf = (a) => (0, import_jsx_runtime.jsx)(Ht, { children: ({ subscribeMarker: i, updateMarker: s }) => (0, import_jsx_runtime.jsx)(oo, {
	subscribeMarker: i,
	updateMarker: s,
	...a
}) });
cf.displayName = "TodayMarkerWrapper";
var uf = class extends import_react.Component {
	constructor() {
		super(...arguments), Object.defineProperty(this, "unsubscribe", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: null
		}), Object.defineProperty(this, "getMarker", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: null
		});
	}
	componentDidUpdate(i) {
		if (i.date !== this.props.date && this.getMarker) {
			const s = this.getMarker();
			this.props.updateMarker({
				...s,
				date: this.props.date
			});
		}
	}
	componentDidMount() {
		const { unsubscribe: i, getMarker: s } = this.props.subscribeMarker({
			type: xe.Custom,
			renderer: this.props.children,
			date: this.props.date
		});
		this.unsubscribe = i, this.getMarker = s;
	}
	componentWillUnmount() {
		this.unsubscribe != null && (this.unsubscribe(), this.unsubscribe = null);
	}
	render() {
		return null;
	}
};
var pf = (a) => (0, import_jsx_runtime.jsx)(Ht, { children: ({ subscribeMarker: i, updateMarker: s }) => (0, import_jsx_runtime.jsx)(uf, {
	subscribeMarker: i,
	updateMarker: s,
	...a
}) });
pf.displayName = "CustomMarkerWrapper";
var hf = class extends import_react.Component {
	constructor() {
		super(...arguments), Object.defineProperty(this, "unsubscribe", {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: null
		});
	}
	componentDidMount() {
		const { unsubscribe: i } = this.props.subscribeMarker({
			type: xe.Cursor,
			renderer: this.props.children
		});
		this.unsubscribe = i;
	}
	componentWillUnmount() {
		this.unsubscribe != null && (this.unsubscribe(), this.unsubscribe = null);
	}
	render() {
		return null;
	}
};
var df = (a) => (0, import_jsx_runtime.jsx)(Ht, { children: ({ subscribeMarker: i }) => (0, import_jsx_runtime.jsx)(hf, {
	subscribeMarker: i,
	...a
}) });
df.displayName = "CursorMarkerWrapper";
export { df as CursorMarker, Qd as CustomHeader, pf as CustomMarker, Ti as DateHeader, yd as GroupRow, vd as RowItems, St as SidebarHeader, io as Timeline, io as default, Er as TimelineHeaders, wf as TimelineMarkers, cf as TodayMarker, mf as calendarUtils };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVhY3QtY2FsZW5kYXItdGltZWxpbmUuanMiLCJuYW1lcyI6WyJhYSIsIk1hIiwicmwiLCJubCIsIm9sIiwiUmwiLCJBbCIsIiRjIiwiUnUiLCJGcCIsImNoIiwidmgiLCJnaCIsInloIiwiVGgiLCJTaCIsIk9oIiwiX2giLCJQaCIsIlloIiwiWGgiLCJxaCIsIlR0IiwiaiIsInVlIiwid2kiLCJhZSIsInhpIiwiemUiLCJUcyJdLCJzb3VyY2VzIjpbIi4uLy4uL2RheWpzL2RheWpzLm1pbi5qcyIsIi4uLy4uL3JlYWN0LWNhbGVuZGFyLXRpbWVsaW5lL2Rpc3QvcmVhY3QtY2FsZW5kYXItdGltZWxpbmUuZXMuanMiXSwic291cmNlc0NvbnRlbnQiOlsiIWZ1bmN0aW9uKHQsZSl7XCJvYmplY3RcIj09dHlwZW9mIGV4cG9ydHMmJlwidW5kZWZpbmVkXCIhPXR5cGVvZiBtb2R1bGU/bW9kdWxlLmV4cG9ydHM9ZSgpOlwiZnVuY3Rpb25cIj09dHlwZW9mIGRlZmluZSYmZGVmaW5lLmFtZD9kZWZpbmUoZSk6KHQ9XCJ1bmRlZmluZWRcIiE9dHlwZW9mIGdsb2JhbFRoaXM/Z2xvYmFsVGhpczp0fHxzZWxmKS5kYXlqcz1lKCl9KHRoaXMsKGZ1bmN0aW9uKCl7XCJ1c2Ugc3RyaWN0XCI7dmFyIHQ9MWUzLGU9NmU0LG49MzZlNSxyPVwibWlsbGlzZWNvbmRcIixpPVwic2Vjb25kXCIscz1cIm1pbnV0ZVwiLHU9XCJob3VyXCIsYT1cImRheVwiLG89XCJ3ZWVrXCIsYz1cIm1vbnRoXCIsZj1cInF1YXJ0ZXJcIixoPVwieWVhclwiLGQ9XCJkYXRlXCIsbD1cIkludmFsaWQgRGF0ZVwiLCQ9L14oXFxkezR9KVstL10/KFxcZHsxLDJ9KT9bLS9dPyhcXGR7MCwyfSlbVHRcXHNdKihcXGR7MSwyfSk/Oj8oXFxkezEsMn0pPzo/KFxcZHsxLDJ9KT9bLjpdPyhcXGQrKT8kLyx5PS9cXFsoW15cXF1dKyldfFl7MSw0fXxNezEsNH18RHsxLDJ9fGR7MSw0fXxIezEsMn18aHsxLDJ9fGF8QXxtezEsMn18c3sxLDJ9fFp7MSwyfXxTU1MvZyxNPXtuYW1lOlwiZW5cIix3ZWVrZGF5czpcIlN1bmRheV9Nb25kYXlfVHVlc2RheV9XZWRuZXNkYXlfVGh1cnNkYXlfRnJpZGF5X1NhdHVyZGF5XCIuc3BsaXQoXCJfXCIpLG1vbnRoczpcIkphbnVhcnlfRmVicnVhcnlfTWFyY2hfQXByaWxfTWF5X0p1bmVfSnVseV9BdWd1c3RfU2VwdGVtYmVyX09jdG9iZXJfTm92ZW1iZXJfRGVjZW1iZXJcIi5zcGxpdChcIl9cIiksb3JkaW5hbDpmdW5jdGlvbih0KXt2YXIgZT1bXCJ0aFwiLFwic3RcIixcIm5kXCIsXCJyZFwiXSxuPXQlMTAwO3JldHVyblwiW1wiK3QrKGVbKG4tMjApJTEwXXx8ZVtuXXx8ZVswXSkrXCJdXCJ9fSxtPWZ1bmN0aW9uKHQsZSxuKXt2YXIgcj1TdHJpbmcodCk7cmV0dXJuIXJ8fHIubGVuZ3RoPj1lP3Q6XCJcIitBcnJheShlKzEtci5sZW5ndGgpLmpvaW4obikrdH0sdj17czptLHo6ZnVuY3Rpb24odCl7dmFyIGU9LXQudXRjT2Zmc2V0KCksbj1NYXRoLmFicyhlKSxyPU1hdGguZmxvb3Iobi82MCksaT1uJTYwO3JldHVybihlPD0wP1wiK1wiOlwiLVwiKSttKHIsMixcIjBcIikrXCI6XCIrbShpLDIsXCIwXCIpfSxtOmZ1bmN0aW9uIHQoZSxuKXtpZihlLmRhdGUoKTxuLmRhdGUoKSlyZXR1cm4tdChuLGUpO3ZhciByPTEyKihuLnllYXIoKS1lLnllYXIoKSkrKG4ubW9udGgoKS1lLm1vbnRoKCkpLGk9ZS5jbG9uZSgpLmFkZChyLGMpLHM9bi1pPDAsdT1lLmNsb25lKCkuYWRkKHIrKHM/LTE6MSksYyk7cmV0dXJuKygtKHIrKG4taSkvKHM/aS11OnUtaSkpfHwwKX0sYTpmdW5jdGlvbih0KXtyZXR1cm4gdDwwP01hdGguY2VpbCh0KXx8MDpNYXRoLmZsb29yKHQpfSxwOmZ1bmN0aW9uKHQpe3JldHVybntNOmMseTpoLHc6byxkOmEsRDpkLGg6dSxtOnMsczppLG1zOnIsUTpmfVt0XXx8U3RyaW5nKHR8fFwiXCIpLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvcyQvLFwiXCIpfSx1OmZ1bmN0aW9uKHQpe3JldHVybiB2b2lkIDA9PT10fX0sZz1cImVuXCIsRD17fTtEW2ddPU07dmFyIHA9XCIkaXNEYXlqc09iamVjdFwiLFM9ZnVuY3Rpb24odCl7cmV0dXJuIHQgaW5zdGFuY2VvZiBffHwhKCF0fHwhdFtwXSl9LHc9ZnVuY3Rpb24gdChlLG4scil7dmFyIGk7aWYoIWUpcmV0dXJuIGc7aWYoXCJzdHJpbmdcIj09dHlwZW9mIGUpe3ZhciBzPWUudG9Mb3dlckNhc2UoKTtEW3NdJiYoaT1zKSxuJiYoRFtzXT1uLGk9cyk7dmFyIHU9ZS5zcGxpdChcIi1cIik7aWYoIWkmJnUubGVuZ3RoPjEpcmV0dXJuIHQodVswXSl9ZWxzZXt2YXIgYT1lLm5hbWU7RFthXT1lLGk9YX1yZXR1cm4hciYmaSYmKGc9aSksaXx8IXImJmd9LE89ZnVuY3Rpb24odCxlKXtpZihTKHQpKXJldHVybiB0LmNsb25lKCk7dmFyIG49XCJvYmplY3RcIj09dHlwZW9mIGU/ZTp7fTtyZXR1cm4gbi5kYXRlPXQsbi5hcmdzPWFyZ3VtZW50cyxuZXcgXyhuKX0sYj12O2IubD13LGIuaT1TLGIudz1mdW5jdGlvbih0LGUpe3JldHVybiBPKHQse2xvY2FsZTplLiRMLHV0YzplLiR1LHg6ZS4keCwkb2Zmc2V0OmUuJG9mZnNldH0pfTt2YXIgXz1mdW5jdGlvbigpe2Z1bmN0aW9uIE0odCl7dGhpcy4kTD13KHQubG9jYWxlLG51bGwsITApLHRoaXMucGFyc2UodCksdGhpcy4keD10aGlzLiR4fHx0Lnh8fHt9LHRoaXNbcF09ITB9dmFyIG09TS5wcm90b3R5cGU7cmV0dXJuIG0ucGFyc2U9ZnVuY3Rpb24odCl7dGhpcy4kZD1mdW5jdGlvbih0KXt2YXIgZT10LmRhdGUsbj10LnV0YztpZihudWxsPT09ZSlyZXR1cm4gbmV3IERhdGUoTmFOKTtpZihiLnUoZSkpcmV0dXJuIG5ldyBEYXRlO2lmKGUgaW5zdGFuY2VvZiBEYXRlKXJldHVybiBuZXcgRGF0ZShlKTtpZihcInN0cmluZ1wiPT10eXBlb2YgZSYmIS9aJC9pLnRlc3QoZSkpe3ZhciByPWUubWF0Y2goJCk7aWYocil7dmFyIGk9clsyXS0xfHwwLHM9KHJbN118fFwiMFwiKS5zdWJzdHJpbmcoMCwzKTtyZXR1cm4gbj9uZXcgRGF0ZShEYXRlLlVUQyhyWzFdLGksclszXXx8MSxyWzRdfHwwLHJbNV18fDAscls2XXx8MCxzKSk6bmV3IERhdGUoclsxXSxpLHJbM118fDEscls0XXx8MCxyWzVdfHwwLHJbNl18fDAscyl9fXJldHVybiBuZXcgRGF0ZShlKX0odCksdGhpcy5pbml0KCl9LG0uaW5pdD1mdW5jdGlvbigpe3ZhciB0PXRoaXMuJGQ7dGhpcy4keT10LmdldEZ1bGxZZWFyKCksdGhpcy4kTT10LmdldE1vbnRoKCksdGhpcy4kRD10LmdldERhdGUoKSx0aGlzLiRXPXQuZ2V0RGF5KCksdGhpcy4kSD10LmdldEhvdXJzKCksdGhpcy4kbT10LmdldE1pbnV0ZXMoKSx0aGlzLiRzPXQuZ2V0U2Vjb25kcygpLHRoaXMuJG1zPXQuZ2V0TWlsbGlzZWNvbmRzKCl9LG0uJHV0aWxzPWZ1bmN0aW9uKCl7cmV0dXJuIGJ9LG0uaXNWYWxpZD1mdW5jdGlvbigpe3JldHVybiEodGhpcy4kZC50b1N0cmluZygpPT09bCl9LG0uaXNTYW1lPWZ1bmN0aW9uKHQsZSl7dmFyIG49Tyh0KTtyZXR1cm4gdGhpcy5zdGFydE9mKGUpPD1uJiZuPD10aGlzLmVuZE9mKGUpfSxtLmlzQWZ0ZXI9ZnVuY3Rpb24odCxlKXtyZXR1cm4gTyh0KTx0aGlzLnN0YXJ0T2YoZSl9LG0uaXNCZWZvcmU9ZnVuY3Rpb24odCxlKXtyZXR1cm4gdGhpcy5lbmRPZihlKTxPKHQpfSxtLiRnPWZ1bmN0aW9uKHQsZSxuKXtyZXR1cm4gYi51KHQpP3RoaXNbZV06dGhpcy5zZXQobix0KX0sbS51bml4PWZ1bmN0aW9uKCl7cmV0dXJuIE1hdGguZmxvb3IodGhpcy52YWx1ZU9mKCkvMWUzKX0sbS52YWx1ZU9mPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuJGQuZ2V0VGltZSgpfSxtLnN0YXJ0T2Y9ZnVuY3Rpb24odCxlKXt2YXIgbj10aGlzLHI9ISFiLnUoZSl8fGUsZj1iLnAodCksbD1mdW5jdGlvbih0LGUpe3ZhciBpPWIudyhuLiR1P0RhdGUuVVRDKG4uJHksZSx0KTpuZXcgRGF0ZShuLiR5LGUsdCksbik7cmV0dXJuIHI/aTppLmVuZE9mKGEpfSwkPWZ1bmN0aW9uKHQsZSl7cmV0dXJuIGIudyhuLnRvRGF0ZSgpW3RdLmFwcGx5KG4udG9EYXRlKFwic1wiKSwocj9bMCwwLDAsMF06WzIzLDU5LDU5LDk5OV0pLnNsaWNlKGUpKSxuKX0seT10aGlzLiRXLE09dGhpcy4kTSxtPXRoaXMuJEQsdj1cInNldFwiKyh0aGlzLiR1P1wiVVRDXCI6XCJcIik7c3dpdGNoKGYpe2Nhc2UgaDpyZXR1cm4gcj9sKDEsMCk6bCgzMSwxMSk7Y2FzZSBjOnJldHVybiByP2woMSxNKTpsKDAsTSsxKTtjYXNlIG86dmFyIGc9dGhpcy4kbG9jYWxlKCkud2Vla1N0YXJ0fHwwLEQ9KHk8Zz95Kzc6eSktZztyZXR1cm4gbChyP20tRDptKyg2LUQpLE0pO2Nhc2UgYTpjYXNlIGQ6cmV0dXJuICQoditcIkhvdXJzXCIsMCk7Y2FzZSB1OnJldHVybiAkKHYrXCJNaW51dGVzXCIsMSk7Y2FzZSBzOnJldHVybiAkKHYrXCJTZWNvbmRzXCIsMik7Y2FzZSBpOnJldHVybiAkKHYrXCJNaWxsaXNlY29uZHNcIiwzKTtkZWZhdWx0OnJldHVybiB0aGlzLmNsb25lKCl9fSxtLmVuZE9mPWZ1bmN0aW9uKHQpe3JldHVybiB0aGlzLnN0YXJ0T2YodCwhMSl9LG0uJHNldD1mdW5jdGlvbih0LGUpe3ZhciBuLG89Yi5wKHQpLGY9XCJzZXRcIisodGhpcy4kdT9cIlVUQ1wiOlwiXCIpLGw9KG49e30sblthXT1mK1wiRGF0ZVwiLG5bZF09ZitcIkRhdGVcIixuW2NdPWYrXCJNb250aFwiLG5baF09ZitcIkZ1bGxZZWFyXCIsblt1XT1mK1wiSG91cnNcIixuW3NdPWYrXCJNaW51dGVzXCIsbltpXT1mK1wiU2Vjb25kc1wiLG5bcl09ZitcIk1pbGxpc2Vjb25kc1wiLG4pW29dLCQ9bz09PWE/dGhpcy4kRCsoZS10aGlzLiRXKTplO2lmKG89PT1jfHxvPT09aCl7dmFyIHk9dGhpcy5jbG9uZSgpLnNldChkLDEpO3kuJGRbbF0oJCkseS5pbml0KCksdGhpcy4kZD15LnNldChkLE1hdGgubWluKHRoaXMuJEQseS5kYXlzSW5Nb250aCgpKSkuJGR9ZWxzZSBsJiZ0aGlzLiRkW2xdKCQpO3JldHVybiB0aGlzLmluaXQoKSx0aGlzfSxtLnNldD1mdW5jdGlvbih0LGUpe3JldHVybiB0aGlzLmNsb25lKCkuJHNldCh0LGUpfSxtLmdldD1mdW5jdGlvbih0KXtyZXR1cm4gdGhpc1tiLnAodCldKCl9LG0uYWRkPWZ1bmN0aW9uKHIsZil7dmFyIGQsbD10aGlzO3I9TnVtYmVyKHIpO3ZhciAkPWIucChmKSx5PWZ1bmN0aW9uKHQpe3ZhciBlPU8obCk7cmV0dXJuIGIudyhlLmRhdGUoZS5kYXRlKCkrTWF0aC5yb3VuZCh0KnIpKSxsKX07aWYoJD09PWMpcmV0dXJuIHRoaXMuc2V0KGMsdGhpcy4kTStyKTtpZigkPT09aClyZXR1cm4gdGhpcy5zZXQoaCx0aGlzLiR5K3IpO2lmKCQ9PT1hKXJldHVybiB5KDEpO2lmKCQ9PT1vKXJldHVybiB5KDcpO3ZhciBNPShkPXt9LGRbc109ZSxkW3VdPW4sZFtpXT10LGQpWyRdfHwxLG09dGhpcy4kZC5nZXRUaW1lKCkrcipNO3JldHVybiBiLncobSx0aGlzKX0sbS5zdWJ0cmFjdD1mdW5jdGlvbih0LGUpe3JldHVybiB0aGlzLmFkZCgtMSp0LGUpfSxtLmZvcm1hdD1mdW5jdGlvbih0KXt2YXIgZT10aGlzLG49dGhpcy4kbG9jYWxlKCk7aWYoIXRoaXMuaXNWYWxpZCgpKXJldHVybiBuLmludmFsaWREYXRlfHxsO3ZhciByPXR8fFwiWVlZWS1NTS1ERFRISDptbTpzc1pcIixpPWIueih0aGlzKSxzPXRoaXMuJEgsdT10aGlzLiRtLGE9dGhpcy4kTSxvPW4ud2Vla2RheXMsYz1uLm1vbnRocyxmPW4ubWVyaWRpZW0saD1mdW5jdGlvbih0LG4saSxzKXtyZXR1cm4gdCYmKHRbbl18fHQoZSxyKSl8fGlbbl0uc2xpY2UoMCxzKX0sZD1mdW5jdGlvbih0KXtyZXR1cm4gYi5zKHMlMTJ8fDEyLHQsXCIwXCIpfSwkPWZ8fGZ1bmN0aW9uKHQsZSxuKXt2YXIgcj10PDEyP1wiQU1cIjpcIlBNXCI7cmV0dXJuIG4/ci50b0xvd2VyQ2FzZSgpOnJ9O3JldHVybiByLnJlcGxhY2UoeSwoZnVuY3Rpb24odCxyKXtyZXR1cm4gcnx8ZnVuY3Rpb24odCl7c3dpdGNoKHQpe2Nhc2VcIllZXCI6cmV0dXJuIFN0cmluZyhlLiR5KS5zbGljZSgtMik7Y2FzZVwiWVlZWVwiOnJldHVybiBiLnMoZS4keSw0LFwiMFwiKTtjYXNlXCJNXCI6cmV0dXJuIGErMTtjYXNlXCJNTVwiOnJldHVybiBiLnMoYSsxLDIsXCIwXCIpO2Nhc2VcIk1NTVwiOnJldHVybiBoKG4ubW9udGhzU2hvcnQsYSxjLDMpO2Nhc2VcIk1NTU1cIjpyZXR1cm4gaChjLGEpO2Nhc2VcIkRcIjpyZXR1cm4gZS4kRDtjYXNlXCJERFwiOnJldHVybiBiLnMoZS4kRCwyLFwiMFwiKTtjYXNlXCJkXCI6cmV0dXJuIFN0cmluZyhlLiRXKTtjYXNlXCJkZFwiOnJldHVybiBoKG4ud2Vla2RheXNNaW4sZS4kVyxvLDIpO2Nhc2VcImRkZFwiOnJldHVybiBoKG4ud2Vla2RheXNTaG9ydCxlLiRXLG8sMyk7Y2FzZVwiZGRkZFwiOnJldHVybiBvW2UuJFddO2Nhc2VcIkhcIjpyZXR1cm4gU3RyaW5nKHMpO2Nhc2VcIkhIXCI6cmV0dXJuIGIucyhzLDIsXCIwXCIpO2Nhc2VcImhcIjpyZXR1cm4gZCgxKTtjYXNlXCJoaFwiOnJldHVybiBkKDIpO2Nhc2VcImFcIjpyZXR1cm4gJChzLHUsITApO2Nhc2VcIkFcIjpyZXR1cm4gJChzLHUsITEpO2Nhc2VcIm1cIjpyZXR1cm4gU3RyaW5nKHUpO2Nhc2VcIm1tXCI6cmV0dXJuIGIucyh1LDIsXCIwXCIpO2Nhc2VcInNcIjpyZXR1cm4gU3RyaW5nKGUuJHMpO2Nhc2VcInNzXCI6cmV0dXJuIGIucyhlLiRzLDIsXCIwXCIpO2Nhc2VcIlNTU1wiOnJldHVybiBiLnMoZS4kbXMsMyxcIjBcIik7Y2FzZVwiWlwiOnJldHVybiBpfXJldHVybiBudWxsfSh0KXx8aS5yZXBsYWNlKFwiOlwiLFwiXCIpfSkpfSxtLnV0Y09mZnNldD1mdW5jdGlvbigpe3JldHVybiAxNSotTWF0aC5yb3VuZCh0aGlzLiRkLmdldFRpbWV6b25lT2Zmc2V0KCkvMTUpfSxtLmRpZmY9ZnVuY3Rpb24ocixkLGwpe3ZhciAkLHk9dGhpcyxNPWIucChkKSxtPU8ociksdj0obS51dGNPZmZzZXQoKS10aGlzLnV0Y09mZnNldCgpKSplLGc9dGhpcy1tLEQ9ZnVuY3Rpb24oKXtyZXR1cm4gYi5tKHksbSl9O3N3aXRjaChNKXtjYXNlIGg6JD1EKCkvMTI7YnJlYWs7Y2FzZSBjOiQ9RCgpO2JyZWFrO2Nhc2UgZjokPUQoKS8zO2JyZWFrO2Nhc2UgbzokPShnLXYpLzYwNDhlNTticmVhaztjYXNlIGE6JD0oZy12KS84NjRlNTticmVhaztjYXNlIHU6JD1nL247YnJlYWs7Y2FzZSBzOiQ9Zy9lO2JyZWFrO2Nhc2UgaTokPWcvdDticmVhaztkZWZhdWx0OiQ9Z31yZXR1cm4gbD8kOmIuYSgkKX0sbS5kYXlzSW5Nb250aD1mdW5jdGlvbigpe3JldHVybiB0aGlzLmVuZE9mKGMpLiREfSxtLiRsb2NhbGU9ZnVuY3Rpb24oKXtyZXR1cm4gRFt0aGlzLiRMXX0sbS5sb2NhbGU9ZnVuY3Rpb24odCxlKXtpZighdClyZXR1cm4gdGhpcy4kTDt2YXIgbj10aGlzLmNsb25lKCkscj13KHQsZSwhMCk7cmV0dXJuIHImJihuLiRMPXIpLG59LG0uY2xvbmU9ZnVuY3Rpb24oKXtyZXR1cm4gYi53KHRoaXMuJGQsdGhpcyl9LG0udG9EYXRlPWZ1bmN0aW9uKCl7cmV0dXJuIG5ldyBEYXRlKHRoaXMudmFsdWVPZigpKX0sbS50b0pTT049ZnVuY3Rpb24oKXtyZXR1cm4gdGhpcy5pc1ZhbGlkKCk/dGhpcy50b0lTT1N0cmluZygpOm51bGx9LG0udG9JU09TdHJpbmc9ZnVuY3Rpb24oKXtyZXR1cm4gdGhpcy4kZC50b0lTT1N0cmluZygpfSxtLnRvU3RyaW5nPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuJGQudG9VVENTdHJpbmcoKX0sTX0oKSxrPV8ucHJvdG90eXBlO3JldHVybiBPLnByb3RvdHlwZT1rLFtbXCIkbXNcIixyXSxbXCIkc1wiLGldLFtcIiRtXCIsc10sW1wiJEhcIix1XSxbXCIkV1wiLGFdLFtcIiRNXCIsY10sW1wiJHlcIixoXSxbXCIkRFwiLGRdXS5mb3JFYWNoKChmdW5jdGlvbih0KXtrW3RbMV1dPWZ1bmN0aW9uKGUpe3JldHVybiB0aGlzLiRnKGUsdFswXSx0WzFdKX19KSksTy5leHRlbmQ9ZnVuY3Rpb24odCxlKXtyZXR1cm4gdC4kaXx8KHQoZSxfLE8pLHQuJGk9ITApLE99LE8ubG9jYWxlPXcsTy5pc0RheWpzPVMsTy51bml4PWZ1bmN0aW9uKHQpe3JldHVybiBPKDFlMyp0KX0sTy5lbj1EW2ddLE8uTHM9RCxPLnA9e30sT30pKTsiLCJpbXBvcnQgeyBqc3ggYXMgaiwganN4cyBhcyB6ZSB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuaW1wb3J0IFosIHsgY3JlYXRlRWxlbWVudCBhcyBUdCwgdXNlQ29udGV4dCBhcyB3aSwgQ29tcG9uZW50IGFzIGFlLCBjcmVhdGVSZWYgYXMgeGksIFB1cmVDb21wb25lbnQgYXMgVHMgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB1ZSBmcm9tIFwiZGF5anNcIjtcbmZ1bmN0aW9uIEhuKGEpIHtcbiAgbGV0IGkgPSAwLCBzID0gMCwgdSA9ICEwO1xuICBmb3IgKDsgYTsgKVxuICAgICFhLm9mZnNldFBhcmVudCAmJiBhLnRhZ05hbWUgPT09IFwiQk9EWVwiICYmIGEuc2Nyb2xsTGVmdCA9PT0gMCAmJiBhLnNjcm9sbFRvcCA9PT0gMCAmJiAoYSA9IGRvY3VtZW50LnNjcm9sbGluZ0VsZW1lbnQgfHwgYSksIGkgKz0gYS5vZmZzZXRMZWZ0IC0gKHUgPyAwIDogYS5zY3JvbGxMZWZ0KSArIGEuY2xpZW50TGVmdCwgcyArPSBhLm9mZnNldFRvcCAtICh1ID8gMCA6IGEuc2Nyb2xsVG9wKSArIGEuY2xpZW50VG9wLCBhID0gYS5vZmZzZXRQYXJlbnQsIHUgPSAhMTtcbiAgcmV0dXJuIHsgeDogaSwgeTogcyB9O1xufVxuZnVuY3Rpb24gT3QoYSkge1xuICBpZiAoYSA9PT0gZG9jdW1lbnQuYm9keSlcbiAgICByZXR1cm4geyBzY3JvbGxMZWZ0OiAwLCBzY3JvbGxUb3A6IDAgfTtcbiAge1xuICAgIGNvbnN0IGkgPSBPdChhLnBhcmVudE5vZGUpO1xuICAgIHJldHVybiB7XG4gICAgICBzY3JvbGxMZWZ0OiBhLnNjcm9sbExlZnQgKyBpLnNjcm9sbExlZnQsXG4gICAgICBzY3JvbGxUb3A6IGEuc2Nyb2xsVG9wICsgaS5zY3JvbGxUb3BcbiAgICB9O1xuICB9XG59XG5mdW5jdGlvbiBDdChhKSB7XG4gIGlmIChhID09PSBkb2N1bWVudC5ib2R5IHx8ICFhLm9mZnNldFBhcmVudClcbiAgICByZXR1cm4geyBvZmZzZXRMZWZ0OiAwLCBvZmZzZXRUb3A6IDAgfTtcbiAge1xuICAgIGNvbnN0IGkgPSBDdChhLm9mZnNldFBhcmVudCk7XG4gICAgcmV0dXJuIHtcbiAgICAgIG9mZnNldExlZnQ6IGEub2Zmc2V0TGVmdCArIGkub2Zmc2V0TGVmdCxcbiAgICAgIG9mZnNldFRvcDogYS5vZmZzZXRUb3AgKyBpLm9mZnNldFRvcFxuICAgIH07XG4gIH1cbn1cbnZhciBJZSA9IHR5cGVvZiBnbG9iYWxUaGlzIDwgXCJ1XCIgPyBnbG9iYWxUaGlzIDogdHlwZW9mIHdpbmRvdyA8IFwidVwiID8gd2luZG93IDogdHlwZW9mIGdsb2JhbCA8IFwidVwiID8gZ2xvYmFsIDogdHlwZW9mIHNlbGYgPCBcInVcIiA/IHNlbGYgOiB7fTtcbmZ1bmN0aW9uIHJ0KGEpIHtcbiAgcmV0dXJuIGEgJiYgYS5fX2VzTW9kdWxlICYmIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChhLCBcImRlZmF1bHRcIikgPyBhLmRlZmF1bHQgOiBhO1xufVxudmFyIEV0ID0geyBleHBvcnRzOiB7fSB9O1xuRXQuZXhwb3J0cztcbihmdW5jdGlvbihhLCBpKSB7XG4gIChmdW5jdGlvbihzLCB1KSB7XG4gICAgYS5leHBvcnRzID0gdSgpO1xuICB9KShJZSwgZnVuY3Rpb24oKSB7XG4gICAgZnVuY3Rpb24gcyh0LCBlKSB7XG4gICAgICB2YXIgciA9IE9iamVjdC5rZXlzKHQpO1xuICAgICAgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHtcbiAgICAgICAgdmFyIG4gPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKHQpO1xuICAgICAgICBlICYmIChuID0gbi5maWx0ZXIoZnVuY3Rpb24obykge1xuICAgICAgICAgIHJldHVybiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHQsIG8pLmVudW1lcmFibGU7XG4gICAgICAgIH0pKSwgci5wdXNoLmFwcGx5KHIsIG4pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHI7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHUodCkge1xuICAgICAgZm9yICh2YXIgZSA9IDE7IGUgPCBhcmd1bWVudHMubGVuZ3RoOyBlKyspIHtcbiAgICAgICAgdmFyIHIgPSBhcmd1bWVudHNbZV0gIT0gbnVsbCA/IGFyZ3VtZW50c1tlXSA6IHt9O1xuICAgICAgICBlICUgMiA/IHMoT2JqZWN0KHIpLCAhMCkuZm9yRWFjaChmdW5jdGlvbihuKSB7XG4gICAgICAgICAgUyh0LCBuLCByW25dKTtcbiAgICAgICAgfSkgOiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKHQsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKHIpKSA6IHMoT2JqZWN0KHIpKS5mb3JFYWNoKGZ1bmN0aW9uKG4pIHtcbiAgICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodCwgbiwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihyLCBuKSk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHQ7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHYodCkge1xuICAgICAgcmV0dXJuIHYgPSB0eXBlb2YgU3ltYm9sID09IFwiZnVuY3Rpb25cIiAmJiB0eXBlb2YgU3ltYm9sLml0ZXJhdG9yID09IFwic3ltYm9sXCIgPyBmdW5jdGlvbihlKSB7XG4gICAgICAgIHJldHVybiB0eXBlb2YgZTtcbiAgICAgIH0gOiBmdW5jdGlvbihlKSB7XG4gICAgICAgIHJldHVybiBlICYmIHR5cGVvZiBTeW1ib2wgPT0gXCJmdW5jdGlvblwiICYmIGUuY29uc3RydWN0b3IgPT09IFN5bWJvbCAmJiBlICE9PSBTeW1ib2wucHJvdG90eXBlID8gXCJzeW1ib2xcIiA6IHR5cGVvZiBlO1xuICAgICAgfSwgdih0KTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZih0LCBlKSB7XG4gICAgICBpZiAoISh0IGluc3RhbmNlb2YgZSkpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDYW5ub3QgY2FsbCBhIGNsYXNzIGFzIGEgZnVuY3Rpb25cIik7XG4gICAgfVxuICAgIGZ1bmN0aW9uIG0odCwgZSkge1xuICAgICAgZm9yICh2YXIgciA9IDA7IHIgPCBlLmxlbmd0aDsgcisrKSB7XG4gICAgICAgIHZhciBuID0gZVtyXTtcbiAgICAgICAgbi5lbnVtZXJhYmxlID0gbi5lbnVtZXJhYmxlIHx8ICExLCBuLmNvbmZpZ3VyYWJsZSA9ICEwLCBcInZhbHVlXCIgaW4gbiAmJiAobi53cml0YWJsZSA9ICEwKSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHQsIE8obi5rZXkpLCBuKTtcbiAgICAgIH1cbiAgICB9XG4gICAgZnVuY3Rpb24geSh0LCBlLCByKSB7XG4gICAgICByZXR1cm4gZSAmJiBtKHQucHJvdG90eXBlLCBlKSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHQsIFwicHJvdG90eXBlXCIsIHsgd3JpdGFibGU6ICExIH0pLCB0O1xuICAgIH1cbiAgICBmdW5jdGlvbiBTKHQsIGUsIHIpIHtcbiAgICAgIHJldHVybiAoZSA9IE8oZSkpIGluIHQgPyBPYmplY3QuZGVmaW5lUHJvcGVydHkodCwgZSwgeyB2YWx1ZTogciwgZW51bWVyYWJsZTogITAsIGNvbmZpZ3VyYWJsZTogITAsIHdyaXRhYmxlOiAhMCB9KSA6IHRbZV0gPSByLCB0O1xuICAgIH1cbiAgICBmdW5jdGlvbiBDKHQsIGUpIHtcbiAgICAgIGlmICh0eXBlb2YgZSAhPSBcImZ1bmN0aW9uXCIgJiYgZSAhPT0gbnVsbCkgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlN1cGVyIGV4cHJlc3Npb24gbXVzdCBlaXRoZXIgYmUgbnVsbCBvciBhIGZ1bmN0aW9uXCIpO1xuICAgICAgdC5wcm90b3R5cGUgPSBPYmplY3QuY3JlYXRlKGUgJiYgZS5wcm90b3R5cGUsIHsgY29uc3RydWN0b3I6IHsgdmFsdWU6IHQsIHdyaXRhYmxlOiAhMCwgY29uZmlndXJhYmxlOiAhMCB9IH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodCwgXCJwcm90b3R5cGVcIiwgeyB3cml0YWJsZTogITEgfSksIGUgJiYgUih0LCBlKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gRCh0KSB7XG4gICAgICByZXR1cm4gRCA9IE9iamVjdC5zZXRQcm90b3R5cGVPZiA/IE9iamVjdC5nZXRQcm90b3R5cGVPZi5iaW5kKCkgOiBmdW5jdGlvbihlKSB7XG4gICAgICAgIHJldHVybiBlLl9fcHJvdG9fXyB8fCBPYmplY3QuZ2V0UHJvdG90eXBlT2YoZSk7XG4gICAgICB9LCBEKHQpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBSKHQsIGUpIHtcbiAgICAgIHJldHVybiBSID0gT2JqZWN0LnNldFByb3RvdHlwZU9mID8gT2JqZWN0LnNldFByb3RvdHlwZU9mLmJpbmQoKSA6IGZ1bmN0aW9uKHIsIG4pIHtcbiAgICAgICAgcmV0dXJuIHIuX19wcm90b19fID0gbiwgcjtcbiAgICAgIH0sIFIodCwgZSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIFQodCkge1xuICAgICAgaWYgKHQgPT09IHZvaWQgMCkgdGhyb3cgbmV3IFJlZmVyZW5jZUVycm9yKFwidGhpcyBoYXNuJ3QgYmVlbiBpbml0aWFsaXNlZCAtIHN1cGVyKCkgaGFzbid0IGJlZW4gY2FsbGVkXCIpO1xuICAgICAgcmV0dXJuIHQ7XG4gICAgfVxuICAgIGZ1bmN0aW9uIFAodCkge1xuICAgICAgdmFyIGUgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgaWYgKHR5cGVvZiBSZWZsZWN0ID4gXCJ1XCIgfHwgIVJlZmxlY3QuY29uc3RydWN0IHx8IFJlZmxlY3QuY29uc3RydWN0LnNoYW0pIHJldHVybiAhMTtcbiAgICAgICAgaWYgKHR5cGVvZiBQcm94eSA9PSBcImZ1bmN0aW9uXCIpIHJldHVybiAhMDtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICByZXR1cm4gQm9vbGVhbi5wcm90b3R5cGUudmFsdWVPZi5jYWxsKFJlZmxlY3QuY29uc3RydWN0KEJvb2xlYW4sIFtdLCBmdW5jdGlvbigpIHtcbiAgICAgICAgICB9KSksICEwO1xuICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICByZXR1cm4gITE7XG4gICAgICAgIH1cbiAgICAgIH0oKTtcbiAgICAgIHJldHVybiBmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIHIsIG4gPSBEKHQpO1xuICAgICAgICBpZiAoZSkge1xuICAgICAgICAgIHZhciBvID0gRCh0aGlzKS5jb25zdHJ1Y3RvcjtcbiAgICAgICAgICByID0gUmVmbGVjdC5jb25zdHJ1Y3QobiwgYXJndW1lbnRzLCBvKTtcbiAgICAgICAgfSBlbHNlIHIgPSBuLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbihsLCBjKSB7XG4gICAgICAgICAgaWYgKGMgJiYgKHR5cGVvZiBjID09IFwib2JqZWN0XCIgfHwgdHlwZW9mIGMgPT0gXCJmdW5jdGlvblwiKSkgcmV0dXJuIGM7XG4gICAgICAgICAgaWYgKGMgIT09IHZvaWQgMCkgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkRlcml2ZWQgY29uc3RydWN0b3JzIG1heSBvbmx5IHJldHVybiBvYmplY3Qgb3IgdW5kZWZpbmVkXCIpO1xuICAgICAgICAgIHJldHVybiBUKGwpO1xuICAgICAgICB9KHRoaXMsIHIpO1xuICAgICAgfTtcbiAgICB9XG4gICAgZnVuY3Rpb24gXygpIHtcbiAgICAgIHJldHVybiBfID0gdHlwZW9mIFJlZmxlY3QgPCBcInVcIiAmJiBSZWZsZWN0LmdldCA/IFJlZmxlY3QuZ2V0LmJpbmQoKSA6IGZ1bmN0aW9uKHQsIGUsIHIpIHtcbiAgICAgICAgdmFyIG4gPSBmdW5jdGlvbihsLCBjKSB7XG4gICAgICAgICAgZm9yICg7ICFPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwobCwgYykgJiYgKGwgPSBEKGwpKSAhPT0gbnVsbDsgKSA7XG4gICAgICAgICAgcmV0dXJuIGw7XG4gICAgICAgIH0odCwgZSk7XG4gICAgICAgIGlmIChuKSB7XG4gICAgICAgICAgdmFyIG8gPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKG4sIGUpO1xuICAgICAgICAgIHJldHVybiBvLmdldCA/IG8uZ2V0LmNhbGwoYXJndW1lbnRzLmxlbmd0aCA8IDMgPyB0IDogcikgOiBvLnZhbHVlO1xuICAgICAgICB9XG4gICAgICB9LCBfLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIE8odCkge1xuICAgICAgdmFyIGUgPSBmdW5jdGlvbihyLCBuKSB7XG4gICAgICAgIGlmICh0eXBlb2YgciAhPSBcIm9iamVjdFwiIHx8IHIgPT09IG51bGwpIHJldHVybiByO1xuICAgICAgICB2YXIgbyA9IHJbU3ltYm9sLnRvUHJpbWl0aXZlXTtcbiAgICAgICAgaWYgKG8gIT09IHZvaWQgMCkge1xuICAgICAgICAgIHZhciBsID0gby5jYWxsKHIsIG4pO1xuICAgICAgICAgIGlmICh0eXBlb2YgbCAhPSBcIm9iamVjdFwiKSByZXR1cm4gbDtcbiAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQEB0b1ByaW1pdGl2ZSBtdXN0IHJldHVybiBhIHByaW1pdGl2ZSB2YWx1ZS5cIik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIFN0cmluZyhyKTtcbiAgICAgIH0odCwgXCJzdHJpbmdcIik7XG4gICAgICByZXR1cm4gdHlwZW9mIGUgPT0gXCJzeW1ib2xcIiA/IGUgOiBlICsgXCJcIjtcbiAgICB9XG4gICAgdmFyIGsgPSBmdW5jdGlvbih0KSB7XG4gICAgICByZXR1cm4gISghdCB8fCAhdC5XaW5kb3cpICYmIHQgaW5zdGFuY2VvZiB0LldpbmRvdztcbiAgICB9LCBMID0gdm9pZCAwLCBIID0gdm9pZCAwO1xuICAgIGZ1bmN0aW9uIFgodCkge1xuICAgICAgTCA9IHQ7XG4gICAgICB2YXIgZSA9IHQuZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUoXCJcIik7XG4gICAgICBlLm93bmVyRG9jdW1lbnQgIT09IHQuZG9jdW1lbnQgJiYgdHlwZW9mIHQud3JhcCA9PSBcImZ1bmN0aW9uXCIgJiYgdC53cmFwKGUpID09PSBlICYmICh0ID0gdC53cmFwKHQpKSwgSCA9IHQ7XG4gICAgfVxuICAgIGZ1bmN0aW9uIEIodCkge1xuICAgICAgcmV0dXJuIGsodCkgPyB0IDogKHQub3duZXJEb2N1bWVudCB8fCB0KS5kZWZhdWx0VmlldyB8fCBILndpbmRvdztcbiAgICB9XG4gICAgdHlwZW9mIHdpbmRvdyA8IFwidVwiICYmIHdpbmRvdyAmJiBYKHdpbmRvdyk7XG4gICAgdmFyIFYgPSBmdW5jdGlvbih0KSB7XG4gICAgICByZXR1cm4gISF0ICYmIHYodCkgPT09IFwib2JqZWN0XCI7XG4gICAgfSwgbGUgPSBmdW5jdGlvbih0KSB7XG4gICAgICByZXR1cm4gdHlwZW9mIHQgPT0gXCJmdW5jdGlvblwiO1xuICAgIH0sIHcgPSB7IHdpbmRvdzogZnVuY3Rpb24odCkge1xuICAgICAgcmV0dXJuIHQgPT09IEggfHwgayh0KTtcbiAgICB9LCBkb2NGcmFnOiBmdW5jdGlvbih0KSB7XG4gICAgICByZXR1cm4gVih0KSAmJiB0Lm5vZGVUeXBlID09PSAxMTtcbiAgICB9LCBvYmplY3Q6IFYsIGZ1bmM6IGxlLCBudW1iZXI6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHJldHVybiB0eXBlb2YgdCA9PSBcIm51bWJlclwiO1xuICAgIH0sIGJvb2w6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHJldHVybiB0eXBlb2YgdCA9PSBcImJvb2xlYW5cIjtcbiAgICB9LCBzdHJpbmc6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHJldHVybiB0eXBlb2YgdCA9PSBcInN0cmluZ1wiO1xuICAgIH0sIGVsZW1lbnQ6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIGlmICghdCB8fCB2KHQpICE9PSBcIm9iamVjdFwiKSByZXR1cm4gITE7XG4gICAgICB2YXIgZSA9IEIodCkgfHwgSDtcbiAgICAgIHJldHVybiAvb2JqZWN0fGZ1bmN0aW9uLy50ZXN0KHR5cGVvZiBFbGVtZW50ID4gXCJ1XCIgPyBcInVuZGVmaW5lZFwiIDogdihFbGVtZW50KSkgPyB0IGluc3RhbmNlb2YgRWxlbWVudCB8fCB0IGluc3RhbmNlb2YgZS5FbGVtZW50IDogdC5ub2RlVHlwZSA9PT0gMSAmJiB0eXBlb2YgdC5ub2RlTmFtZSA9PSBcInN0cmluZ1wiO1xuICAgIH0sIHBsYWluT2JqZWN0OiBmdW5jdGlvbih0KSB7XG4gICAgICByZXR1cm4gVih0KSAmJiAhIXQuY29uc3RydWN0b3IgJiYgL2Z1bmN0aW9uIE9iamVjdFxcYi8udGVzdCh0LmNvbnN0cnVjdG9yLnRvU3RyaW5nKCkpO1xuICAgIH0sIGFycmF5OiBmdW5jdGlvbih0KSB7XG4gICAgICByZXR1cm4gVih0KSAmJiB0Lmxlbmd0aCAhPT0gdm9pZCAwICYmIGxlKHQuc3BsaWNlKTtcbiAgICB9IH07XG4gICAgZnVuY3Rpb24gY2UodCkge1xuICAgICAgdmFyIGUgPSB0LmludGVyYWN0aW9uO1xuICAgICAgaWYgKGUucHJlcGFyZWQubmFtZSA9PT0gXCJkcmFnXCIpIHtcbiAgICAgICAgdmFyIHIgPSBlLnByZXBhcmVkLmF4aXM7XG4gICAgICAgIHIgPT09IFwieFwiID8gKGUuY29vcmRzLmN1ci5wYWdlLnkgPSBlLmNvb3Jkcy5zdGFydC5wYWdlLnksIGUuY29vcmRzLmN1ci5jbGllbnQueSA9IGUuY29vcmRzLnN0YXJ0LmNsaWVudC55LCBlLmNvb3Jkcy52ZWxvY2l0eS5jbGllbnQueSA9IDAsIGUuY29vcmRzLnZlbG9jaXR5LnBhZ2UueSA9IDApIDogciA9PT0gXCJ5XCIgJiYgKGUuY29vcmRzLmN1ci5wYWdlLnggPSBlLmNvb3Jkcy5zdGFydC5wYWdlLngsIGUuY29vcmRzLmN1ci5jbGllbnQueCA9IGUuY29vcmRzLnN0YXJ0LmNsaWVudC54LCBlLmNvb3Jkcy52ZWxvY2l0eS5jbGllbnQueCA9IDAsIGUuY29vcmRzLnZlbG9jaXR5LnBhZ2UueCA9IDApO1xuICAgICAgfVxuICAgIH1cbiAgICBmdW5jdGlvbiBNZSh0KSB7XG4gICAgICB2YXIgZSA9IHQuaUV2ZW50LCByID0gdC5pbnRlcmFjdGlvbjtcbiAgICAgIGlmIChyLnByZXBhcmVkLm5hbWUgPT09IFwiZHJhZ1wiKSB7XG4gICAgICAgIHZhciBuID0gci5wcmVwYXJlZC5heGlzO1xuICAgICAgICBpZiAobiA9PT0gXCJ4XCIgfHwgbiA9PT0gXCJ5XCIpIHtcbiAgICAgICAgICB2YXIgbyA9IG4gPT09IFwieFwiID8gXCJ5XCIgOiBcInhcIjtcbiAgICAgICAgICBlLnBhZ2Vbb10gPSByLmNvb3Jkcy5zdGFydC5wYWdlW29dLCBlLmNsaWVudFtvXSA9IHIuY29vcmRzLnN0YXJ0LmNsaWVudFtvXSwgZS5kZWx0YVtvXSA9IDA7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgdmFyIG50ID0geyBpZDogXCJhY3Rpb25zL2RyYWdcIiwgaW5zdGFsbDogZnVuY3Rpb24odCkge1xuICAgICAgdmFyIGUgPSB0LmFjdGlvbnMsIHIgPSB0LkludGVyYWN0YWJsZSwgbiA9IHQuZGVmYXVsdHM7XG4gICAgICByLnByb3RvdHlwZS5kcmFnZ2FibGUgPSBudC5kcmFnZ2FibGUsIGUubWFwLmRyYWcgPSBudCwgZS5tZXRob2REaWN0LmRyYWcgPSBcImRyYWdnYWJsZVwiLCBuLmFjdGlvbnMuZHJhZyA9IG50LmRlZmF1bHRzO1xuICAgIH0sIGxpc3RlbmVyczogeyBcImludGVyYWN0aW9uczpiZWZvcmUtYWN0aW9uLW1vdmVcIjogY2UsIFwiaW50ZXJhY3Rpb25zOmFjdGlvbi1yZXN1bWVcIjogY2UsIFwiaW50ZXJhY3Rpb25zOmFjdGlvbi1tb3ZlXCI6IE1lLCBcImF1dG8tc3RhcnQ6Y2hlY2tcIjogZnVuY3Rpb24odCkge1xuICAgICAgdmFyIGUgPSB0LmludGVyYWN0aW9uLCByID0gdC5pbnRlcmFjdGFibGUsIG4gPSB0LmJ1dHRvbnMsIG8gPSByLm9wdGlvbnMuZHJhZztcbiAgICAgIGlmIChvICYmIG8uZW5hYmxlZCAmJiAoIWUucG9pbnRlcklzRG93biB8fCAhL21vdXNlfHBvaW50ZXIvLnRlc3QoZS5wb2ludGVyVHlwZSkgfHwgbiAmIHIub3B0aW9ucy5kcmFnLm1vdXNlQnV0dG9ucykpIHJldHVybiB0LmFjdGlvbiA9IHsgbmFtZTogXCJkcmFnXCIsIGF4aXM6IG8ubG9ja0F4aXMgPT09IFwic3RhcnRcIiA/IG8uc3RhcnRBeGlzIDogby5sb2NrQXhpcyB9LCAhMTtcbiAgICB9IH0sIGRyYWdnYWJsZTogZnVuY3Rpb24odCkge1xuICAgICAgcmV0dXJuIHcub2JqZWN0KHQpID8gKHRoaXMub3B0aW9ucy5kcmFnLmVuYWJsZWQgPSB0LmVuYWJsZWQgIT09ICExLCB0aGlzLnNldFBlckFjdGlvbihcImRyYWdcIiwgdCksIHRoaXMuc2V0T25FdmVudHMoXCJkcmFnXCIsIHQpLCAvXih4eXx4fHl8c3RhcnQpJC8udGVzdCh0LmxvY2tBeGlzKSAmJiAodGhpcy5vcHRpb25zLmRyYWcubG9ja0F4aXMgPSB0LmxvY2tBeGlzKSwgL14oeHl8eHx5KSQvLnRlc3QodC5zdGFydEF4aXMpICYmICh0aGlzLm9wdGlvbnMuZHJhZy5zdGFydEF4aXMgPSB0LnN0YXJ0QXhpcyksIHRoaXMpIDogdy5ib29sKHQpID8gKHRoaXMub3B0aW9ucy5kcmFnLmVuYWJsZWQgPSB0LCB0aGlzKSA6IHRoaXMub3B0aW9ucy5kcmFnO1xuICAgIH0sIGJlZm9yZU1vdmU6IGNlLCBtb3ZlOiBNZSwgZGVmYXVsdHM6IHsgc3RhcnRBeGlzOiBcInh5XCIsIGxvY2tBeGlzOiBcInh5XCIgfSwgZ2V0Q3Vyc29yOiBmdW5jdGlvbigpIHtcbiAgICAgIHJldHVybiBcIm1vdmVcIjtcbiAgICB9LCBmaWx0ZXJFdmVudFR5cGU6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHJldHVybiB0LnNlYXJjaChcImRyYWdcIikgPT09IDA7XG4gICAgfSB9LCBGciA9IG50LCBuZSA9IHsgaW5pdDogZnVuY3Rpb24odCkge1xuICAgICAgdmFyIGUgPSB0O1xuICAgICAgbmUuZG9jdW1lbnQgPSBlLmRvY3VtZW50LCBuZS5Eb2N1bWVudEZyYWdtZW50ID0gZS5Eb2N1bWVudEZyYWdtZW50IHx8IFJlLCBuZS5TVkdFbGVtZW50ID0gZS5TVkdFbGVtZW50IHx8IFJlLCBuZS5TVkdTVkdFbGVtZW50ID0gZS5TVkdTVkdFbGVtZW50IHx8IFJlLCBuZS5TVkdFbGVtZW50SW5zdGFuY2UgPSBlLlNWR0VsZW1lbnRJbnN0YW5jZSB8fCBSZSwgbmUuRWxlbWVudCA9IGUuRWxlbWVudCB8fCBSZSwgbmUuSFRNTEVsZW1lbnQgPSBlLkhUTUxFbGVtZW50IHx8IG5lLkVsZW1lbnQsIG5lLkV2ZW50ID0gZS5FdmVudCwgbmUuVG91Y2ggPSBlLlRvdWNoIHx8IFJlLCBuZS5Qb2ludGVyRXZlbnQgPSBlLlBvaW50ZXJFdmVudCB8fCBlLk1TUG9pbnRlckV2ZW50O1xuICAgIH0sIGRvY3VtZW50OiBudWxsLCBEb2N1bWVudEZyYWdtZW50OiBudWxsLCBTVkdFbGVtZW50OiBudWxsLCBTVkdTVkdFbGVtZW50OiBudWxsLCBTVkdFbGVtZW50SW5zdGFuY2U6IG51bGwsIEVsZW1lbnQ6IG51bGwsIEhUTUxFbGVtZW50OiBudWxsLCBFdmVudDogbnVsbCwgVG91Y2g6IG51bGwsIFBvaW50ZXJFdmVudDogbnVsbCB9O1xuICAgIGZ1bmN0aW9uIFJlKCkge1xuICAgIH1cbiAgICB2YXIgUSA9IG5lLCBpZSA9IHsgaW5pdDogZnVuY3Rpb24odCkge1xuICAgICAgdmFyIGUgPSBRLkVsZW1lbnQsIHIgPSB0Lm5hdmlnYXRvciB8fCB7fTtcbiAgICAgIGllLnN1cHBvcnRzVG91Y2ggPSBcIm9udG91Y2hzdGFydFwiIGluIHQgfHwgdy5mdW5jKHQuRG9jdW1lbnRUb3VjaCkgJiYgUS5kb2N1bWVudCBpbnN0YW5jZW9mIHQuRG9jdW1lbnRUb3VjaCwgaWUuc3VwcG9ydHNQb2ludGVyRXZlbnQgPSByLnBvaW50ZXJFbmFibGVkICE9PSAhMSAmJiAhIVEuUG9pbnRlckV2ZW50LCBpZS5pc0lPUyA9IC9pUChob25lfG9kfGFkKS8udGVzdChyLnBsYXRmb3JtKSwgaWUuaXNJT1M3ID0gL2lQKGhvbmV8b2R8YWQpLy50ZXN0KHIucGxhdGZvcm0pICYmIC9PUyA3W15cXGRdLy50ZXN0KHIuYXBwVmVyc2lvbiksIGllLmlzSWU5ID0gL01TSUUgOS8udGVzdChyLnVzZXJBZ2VudCksIGllLmlzT3BlcmFNb2JpbGUgPSByLmFwcE5hbWUgPT09IFwiT3BlcmFcIiAmJiBpZS5zdXBwb3J0c1RvdWNoICYmIC9QcmVzdG8vLnRlc3Qoci51c2VyQWdlbnQpLCBpZS5wcmVmaXhlZE1hdGNoZXNTZWxlY3RvciA9IFwibWF0Y2hlc1wiIGluIGUucHJvdG90eXBlID8gXCJtYXRjaGVzXCIgOiBcIndlYmtpdE1hdGNoZXNTZWxlY3RvclwiIGluIGUucHJvdG90eXBlID8gXCJ3ZWJraXRNYXRjaGVzU2VsZWN0b3JcIiA6IFwibW96TWF0Y2hlc1NlbGVjdG9yXCIgaW4gZS5wcm90b3R5cGUgPyBcIm1vek1hdGNoZXNTZWxlY3RvclwiIDogXCJvTWF0Y2hlc1NlbGVjdG9yXCIgaW4gZS5wcm90b3R5cGUgPyBcIm9NYXRjaGVzU2VsZWN0b3JcIiA6IFwibXNNYXRjaGVzU2VsZWN0b3JcIiwgaWUucEV2ZW50VHlwZXMgPSBpZS5zdXBwb3J0c1BvaW50ZXJFdmVudCA/IFEuUG9pbnRlckV2ZW50ID09PSB0Lk1TUG9pbnRlckV2ZW50ID8geyB1cDogXCJNU1BvaW50ZXJVcFwiLCBkb3duOiBcIk1TUG9pbnRlckRvd25cIiwgb3ZlcjogXCJtb3VzZW92ZXJcIiwgb3V0OiBcIm1vdXNlb3V0XCIsIG1vdmU6IFwiTVNQb2ludGVyTW92ZVwiLCBjYW5jZWw6IFwiTVNQb2ludGVyQ2FuY2VsXCIgfSA6IHsgdXA6IFwicG9pbnRlcnVwXCIsIGRvd246IFwicG9pbnRlcmRvd25cIiwgb3ZlcjogXCJwb2ludGVyb3ZlclwiLCBvdXQ6IFwicG9pbnRlcm91dFwiLCBtb3ZlOiBcInBvaW50ZXJtb3ZlXCIsIGNhbmNlbDogXCJwb2ludGVyY2FuY2VsXCIgfSA6IG51bGwsIGllLndoZWVsRXZlbnQgPSBRLmRvY3VtZW50ICYmIFwib25tb3VzZXdoZWVsXCIgaW4gUS5kb2N1bWVudCA/IFwibW91c2V3aGVlbFwiIDogXCJ3aGVlbFwiO1xuICAgIH0sIHN1cHBvcnRzVG91Y2g6IG51bGwsIHN1cHBvcnRzUG9pbnRlckV2ZW50OiBudWxsLCBpc0lPUzc6IG51bGwsIGlzSU9TOiBudWxsLCBpc0llOTogbnVsbCwgaXNPcGVyYU1vYmlsZTogbnVsbCwgcHJlZml4ZWRNYXRjaGVzU2VsZWN0b3I6IG51bGwsIHBFdmVudFR5cGVzOiBudWxsLCB3aGVlbEV2ZW50OiBudWxsIH0sIG9lID0gaWU7XG4gICAgZnVuY3Rpb24gU2UodCwgZSkge1xuICAgICAgaWYgKHQuY29udGFpbnMpIHJldHVybiB0LmNvbnRhaW5zKGUpO1xuICAgICAgZm9yICg7IGU7ICkge1xuICAgICAgICBpZiAoZSA9PT0gdCkgcmV0dXJuICEwO1xuICAgICAgICBlID0gZS5wYXJlbnROb2RlO1xuICAgICAgfVxuICAgICAgcmV0dXJuICExO1xuICAgIH1cbiAgICBmdW5jdGlvbiBVcih0LCBlKSB7XG4gICAgICBmb3IgKDsgdy5lbGVtZW50KHQpOyApIHtcbiAgICAgICAgaWYgKG1lKHQsIGUpKSByZXR1cm4gdDtcbiAgICAgICAgdCA9IHBlKHQpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHBlKHQpIHtcbiAgICAgIHZhciBlID0gdC5wYXJlbnROb2RlO1xuICAgICAgaWYgKHcuZG9jRnJhZyhlKSkge1xuICAgICAgICBmb3IgKDsgKGUgPSBlLmhvc3QpICYmIHcuZG9jRnJhZyhlKTsgKSA7XG4gICAgICAgIHJldHVybiBlO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGU7XG4gICAgfVxuICAgIGZ1bmN0aW9uIG1lKHQsIGUpIHtcbiAgICAgIHJldHVybiBIICE9PSBMICYmIChlID0gZS5yZXBsYWNlKC9cXC9kZWVwXFwvL2csIFwiIFwiKSksIHRbb2UucHJlZml4ZWRNYXRjaGVzU2VsZWN0b3JdKGUpO1xuICAgIH1cbiAgICB2YXIgV3QgPSBmdW5jdGlvbih0KSB7XG4gICAgICByZXR1cm4gdC5wYXJlbnROb2RlIHx8IHQuaG9zdDtcbiAgICB9O1xuICAgIGZ1bmN0aW9uIE5yKHQsIGUpIHtcbiAgICAgIGZvciAodmFyIHIsIG4gPSBbXSwgbyA9IHQ7IChyID0gV3QobykpICYmIG8gIT09IGUgJiYgciAhPT0gby5vd25lckRvY3VtZW50OyApIG4udW5zaGlmdChvKSwgbyA9IHI7XG4gICAgICByZXR1cm4gbjtcbiAgICB9XG4gICAgZnVuY3Rpb24gRnQodCwgZSwgcikge1xuICAgICAgZm9yICg7IHcuZWxlbWVudCh0KTsgKSB7XG4gICAgICAgIGlmIChtZSh0LCBlKSkgcmV0dXJuICEwO1xuICAgICAgICBpZiAoKHQgPSBwZSh0KSkgPT09IHIpIHJldHVybiBtZSh0LCBlKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiAhMTtcbiAgICB9XG4gICAgZnVuY3Rpb24gR3IodCkge1xuICAgICAgcmV0dXJuIHQuY29ycmVzcG9uZGluZ1VzZUVsZW1lbnQgfHwgdDtcbiAgICB9XG4gICAgZnVuY3Rpb24gVXQodCkge1xuICAgICAgdmFyIGUgPSB0IGluc3RhbmNlb2YgUS5TVkdFbGVtZW50ID8gdC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSA6IHQuZ2V0Q2xpZW50UmVjdHMoKVswXTtcbiAgICAgIHJldHVybiBlICYmIHsgbGVmdDogZS5sZWZ0LCByaWdodDogZS5yaWdodCwgdG9wOiBlLnRvcCwgYm90dG9tOiBlLmJvdHRvbSwgd2lkdGg6IGUud2lkdGggfHwgZS5yaWdodCAtIGUubGVmdCwgaGVpZ2h0OiBlLmhlaWdodCB8fCBlLmJvdHRvbSAtIGUudG9wIH07XG4gICAgfVxuICAgIGZ1bmN0aW9uIE50KHQpIHtcbiAgICAgIHZhciBlLCByID0gVXQodCk7XG4gICAgICBpZiAoIW9lLmlzSU9TNyAmJiByKSB7XG4gICAgICAgIHZhciBuID0geyB4OiAoZSA9IChlID0gQih0KSkgfHwgSCkuc2Nyb2xsWCB8fCBlLmRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zY3JvbGxMZWZ0LCB5OiBlLnNjcm9sbFkgfHwgZS5kb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuc2Nyb2xsVG9wIH07XG4gICAgICAgIHIubGVmdCArPSBuLngsIHIucmlnaHQgKz0gbi54LCByLnRvcCArPSBuLnksIHIuYm90dG9tICs9IG4ueTtcbiAgICAgIH1cbiAgICAgIHJldHVybiByO1xuICAgIH1cbiAgICBmdW5jdGlvbiBZcih0KSB7XG4gICAgICBmb3IgKHZhciBlID0gW107IHQ7ICkgZS5wdXNoKHQpLCB0ID0gcGUodCk7XG4gICAgICByZXR1cm4gZTtcbiAgICB9XG4gICAgZnVuY3Rpb24gS3IodCkge1xuICAgICAgcmV0dXJuICEhdy5zdHJpbmcodCkgJiYgKFEuZG9jdW1lbnQucXVlcnlTZWxlY3Rvcih0KSwgITApO1xuICAgIH1cbiAgICBmdW5jdGlvbiBXKHQsIGUpIHtcbiAgICAgIGZvciAodmFyIHIgaW4gZSkgdFtyXSA9IGVbcl07XG4gICAgICByZXR1cm4gdDtcbiAgICB9XG4gICAgZnVuY3Rpb24gWHIodCwgZSwgcikge1xuICAgICAgcmV0dXJuIHQgPT09IFwicGFyZW50XCIgPyBwZShyKSA6IHQgPT09IFwic2VsZlwiID8gZS5nZXRSZWN0KHIpIDogVXIociwgdCk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIFVlKHQsIGUsIHIsIG4pIHtcbiAgICAgIHZhciBvID0gdDtcbiAgICAgIHJldHVybiB3LnN0cmluZyhvKSA/IG8gPSBYcihvLCBlLCByKSA6IHcuZnVuYyhvKSAmJiAobyA9IG8uYXBwbHkodm9pZCAwLCBuKSksIHcuZWxlbWVudChvKSAmJiAobyA9IE50KG8pKSwgbztcbiAgICB9XG4gICAgZnVuY3Rpb24gaXQodCkge1xuICAgICAgcmV0dXJuIHQgJiYgeyB4OiBcInhcIiBpbiB0ID8gdC54IDogdC5sZWZ0LCB5OiBcInlcIiBpbiB0ID8gdC55IDogdC50b3AgfTtcbiAgICB9XG4gICAgZnVuY3Rpb24gR3QodCkge1xuICAgICAgcmV0dXJuICF0IHx8IFwieFwiIGluIHQgJiYgXCJ5XCIgaW4gdCB8fCAoKHQgPSBXKHt9LCB0KSkueCA9IHQubGVmdCB8fCAwLCB0LnkgPSB0LnRvcCB8fCAwLCB0LndpZHRoID0gdC53aWR0aCB8fCAodC5yaWdodCB8fCAwKSAtIHQueCwgdC5oZWlnaHQgPSB0LmhlaWdodCB8fCAodC5ib3R0b20gfHwgMCkgLSB0LnkpLCB0O1xuICAgIH1cbiAgICBmdW5jdGlvbiBvdCh0LCBlLCByKSB7XG4gICAgICB0LmxlZnQgJiYgKGUubGVmdCArPSByLngpLCB0LnJpZ2h0ICYmIChlLnJpZ2h0ICs9IHIueCksIHQudG9wICYmIChlLnRvcCArPSByLnkpLCB0LmJvdHRvbSAmJiAoZS5ib3R0b20gKz0gci55KSwgZS53aWR0aCA9IGUucmlnaHQgLSBlLmxlZnQsIGUuaGVpZ2h0ID0gZS5ib3R0b20gLSBlLnRvcDtcbiAgICB9XG4gICAgZnVuY3Rpb24gTmUodCwgZSwgcikge1xuICAgICAgdmFyIG4gPSByICYmIHQub3B0aW9uc1tyXTtcbiAgICAgIHJldHVybiBpdChVZShuICYmIG4ub3JpZ2luIHx8IHQub3B0aW9ucy5vcmlnaW4sIHQsIGUsIFt0ICYmIGVdKSkgfHwgeyB4OiAwLCB5OiAwIH07XG4gICAgfVxuICAgIGZ1bmN0aW9uIE9lKHQsIGUpIHtcbiAgICAgIHZhciByID0gYXJndW1lbnRzLmxlbmd0aCA+IDIgJiYgYXJndW1lbnRzWzJdICE9PSB2b2lkIDAgPyBhcmd1bWVudHNbMl0gOiBmdW5jdGlvbihoKSB7XG4gICAgICAgIHJldHVybiAhMDtcbiAgICAgIH0sIG4gPSBhcmd1bWVudHMubGVuZ3RoID4gMyA/IGFyZ3VtZW50c1szXSA6IHZvaWQgMDtcbiAgICAgIGlmIChuID0gbiB8fCB7fSwgdy5zdHJpbmcodCkgJiYgdC5zZWFyY2goXCIgXCIpICE9PSAtMSAmJiAodCA9IEJyKHQpKSwgdy5hcnJheSh0KSkgcmV0dXJuIHQuZm9yRWFjaChmdW5jdGlvbihoKSB7XG4gICAgICAgIHJldHVybiBPZShoLCBlLCByLCBuKTtcbiAgICAgIH0pLCBuO1xuICAgICAgaWYgKHcub2JqZWN0KHQpICYmIChlID0gdCwgdCA9IFwiXCIpLCB3LmZ1bmMoZSkgJiYgcih0KSkgblt0XSA9IG5bdF0gfHwgW10sIG5bdF0ucHVzaChlKTtcbiAgICAgIGVsc2UgaWYgKHcuYXJyYXkoZSkpIGZvciAodmFyIG8gPSAwLCBsID0gZTsgbyA8IGwubGVuZ3RoOyBvKyspIHtcbiAgICAgICAgdmFyIGMgPSBsW29dO1xuICAgICAgICBPZSh0LCBjLCByLCBuKTtcbiAgICAgIH1cbiAgICAgIGVsc2UgaWYgKHcub2JqZWN0KGUpKSBmb3IgKHZhciBwIGluIGUpXG4gICAgICAgIE9lKEJyKHApLm1hcChmdW5jdGlvbihoKSB7XG4gICAgICAgICAgcmV0dXJuIFwiXCIuY29uY2F0KHQpLmNvbmNhdChoKTtcbiAgICAgICAgfSksIGVbcF0sIHIsIG4pO1xuICAgICAgcmV0dXJuIG47XG4gICAgfVxuICAgIGZ1bmN0aW9uIEJyKHQpIHtcbiAgICAgIHJldHVybiB0LnRyaW0oKS5zcGxpdCgvICsvKTtcbiAgICB9XG4gICAgdmFyIEdlID0gZnVuY3Rpb24odCwgZSkge1xuICAgICAgcmV0dXJuIE1hdGguc3FydCh0ICogdCArIGUgKiBlKTtcbiAgICB9LCBzbyA9IFtcIndlYmtpdFwiLCBcIm1velwiXTtcbiAgICBmdW5jdGlvbiBzdCh0LCBlKSB7XG4gICAgICB0Ll9fc2V0IHx8ICh0Ll9fc2V0ID0ge30pO1xuICAgICAgdmFyIHIgPSBmdW5jdGlvbihvKSB7XG4gICAgICAgIGlmIChzby5zb21lKGZ1bmN0aW9uKGwpIHtcbiAgICAgICAgICByZXR1cm4gby5pbmRleE9mKGwpID09PSAwO1xuICAgICAgICB9KSkgcmV0dXJuIDE7XG4gICAgICAgIHR5cGVvZiB0W29dICE9IFwiZnVuY3Rpb25cIiAmJiBvICE9PSBcIl9fc2V0XCIgJiYgT2JqZWN0LmRlZmluZVByb3BlcnR5KHQsIG8sIHsgZ2V0OiBmdW5jdGlvbigpIHtcbiAgICAgICAgICByZXR1cm4gbyBpbiB0Ll9fc2V0ID8gdC5fX3NldFtvXSA6IHQuX19zZXRbb10gPSBlW29dO1xuICAgICAgICB9LCBzZXQ6IGZ1bmN0aW9uKGwpIHtcbiAgICAgICAgICB0Ll9fc2V0W29dID0gbDtcbiAgICAgICAgfSwgY29uZmlndXJhYmxlOiAhMCB9KTtcbiAgICAgIH07XG4gICAgICBmb3IgKHZhciBuIGluIGUpIHIobik7XG4gICAgICByZXR1cm4gdDtcbiAgICB9XG4gICAgZnVuY3Rpb24gYXQodCwgZSkge1xuICAgICAgdC5wYWdlID0gdC5wYWdlIHx8IHt9LCB0LnBhZ2UueCA9IGUucGFnZS54LCB0LnBhZ2UueSA9IGUucGFnZS55LCB0LmNsaWVudCA9IHQuY2xpZW50IHx8IHt9LCB0LmNsaWVudC54ID0gZS5jbGllbnQueCwgdC5jbGllbnQueSA9IGUuY2xpZW50LnksIHQudGltZVN0YW1wID0gZS50aW1lU3RhbXA7XG4gICAgfVxuICAgIGZ1bmN0aW9uIFZyKHQpIHtcbiAgICAgIHQucGFnZS54ID0gMCwgdC5wYWdlLnkgPSAwLCB0LmNsaWVudC54ID0gMCwgdC5jbGllbnQueSA9IDA7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHFyKHQpIHtcbiAgICAgIHJldHVybiB0IGluc3RhbmNlb2YgUS5FdmVudCB8fCB0IGluc3RhbmNlb2YgUS5Ub3VjaDtcbiAgICB9XG4gICAgZnVuY3Rpb24gbHQodCwgZSwgcikge1xuICAgICAgcmV0dXJuIHQgPSB0IHx8IFwicGFnZVwiLCAociA9IHIgfHwge30pLnggPSBlW3QgKyBcIlhcIl0sIHIueSA9IGVbdCArIFwiWVwiXSwgcjtcbiAgICB9XG4gICAgZnVuY3Rpb24gWnIodCwgZSkge1xuICAgICAgcmV0dXJuIGUgPSBlIHx8IHsgeDogMCwgeTogMCB9LCBvZS5pc09wZXJhTW9iaWxlICYmIHFyKHQpID8gKGx0KFwic2NyZWVuXCIsIHQsIGUpLCBlLnggKz0gd2luZG93LnNjcm9sbFgsIGUueSArPSB3aW5kb3cuc2Nyb2xsWSkgOiBsdChcInBhZ2VcIiwgdCwgZSksIGU7XG4gICAgfVxuICAgIGZ1bmN0aW9uIFllKHQpIHtcbiAgICAgIHJldHVybiB3Lm51bWJlcih0LnBvaW50ZXJJZCkgPyB0LnBvaW50ZXJJZCA6IHQuaWRlbnRpZmllcjtcbiAgICB9XG4gICAgZnVuY3Rpb24gYW8odCwgZSwgcikge1xuICAgICAgdmFyIG4gPSBlLmxlbmd0aCA+IDEgPyBKcihlKSA6IGVbMF07XG4gICAgICBacihuLCB0LnBhZ2UpLCBmdW5jdGlvbihvLCBsKSB7XG4gICAgICAgIGwgPSBsIHx8IHt9LCBvZS5pc09wZXJhTW9iaWxlICYmIHFyKG8pID8gbHQoXCJzY3JlZW5cIiwgbywgbCkgOiBsdChcImNsaWVudFwiLCBvLCBsKTtcbiAgICAgIH0obiwgdC5jbGllbnQpLCB0LnRpbWVTdGFtcCA9IHI7XG4gICAgfVxuICAgIGZ1bmN0aW9uIFl0KHQpIHtcbiAgICAgIHZhciBlID0gW107XG4gICAgICByZXR1cm4gdy5hcnJheSh0KSA/IChlWzBdID0gdFswXSwgZVsxXSA9IHRbMV0pIDogdC50eXBlID09PSBcInRvdWNoZW5kXCIgPyB0LnRvdWNoZXMubGVuZ3RoID09PSAxID8gKGVbMF0gPSB0LnRvdWNoZXNbMF0sIGVbMV0gPSB0LmNoYW5nZWRUb3VjaGVzWzBdKSA6IHQudG91Y2hlcy5sZW5ndGggPT09IDAgJiYgKGVbMF0gPSB0LmNoYW5nZWRUb3VjaGVzWzBdLCBlWzFdID0gdC5jaGFuZ2VkVG91Y2hlc1sxXSkgOiAoZVswXSA9IHQudG91Y2hlc1swXSwgZVsxXSA9IHQudG91Y2hlc1sxXSksIGU7XG4gICAgfVxuICAgIGZ1bmN0aW9uIEpyKHQpIHtcbiAgICAgIGZvciAodmFyIGUgPSB7IHBhZ2VYOiAwLCBwYWdlWTogMCwgY2xpZW50WDogMCwgY2xpZW50WTogMCwgc2NyZWVuWDogMCwgc2NyZWVuWTogMCB9LCByID0gMDsgciA8IHQubGVuZ3RoOyByKyspIHtcbiAgICAgICAgdmFyIG4gPSB0W3JdO1xuICAgICAgICBmb3IgKHZhciBvIGluIGUpIGVbb10gKz0gbltvXTtcbiAgICAgIH1cbiAgICAgIGZvciAodmFyIGwgaW4gZSkgZVtsXSAvPSB0Lmxlbmd0aDtcbiAgICAgIHJldHVybiBlO1xuICAgIH1cbiAgICBmdW5jdGlvbiBLdCh0KSB7XG4gICAgICBpZiAoIXQubGVuZ3RoKSByZXR1cm4gbnVsbDtcbiAgICAgIHZhciBlID0gWXQodCksIHIgPSBNYXRoLm1pbihlWzBdLnBhZ2VYLCBlWzFdLnBhZ2VYKSwgbiA9IE1hdGgubWluKGVbMF0ucGFnZVksIGVbMV0ucGFnZVkpLCBvID0gTWF0aC5tYXgoZVswXS5wYWdlWCwgZVsxXS5wYWdlWCksIGwgPSBNYXRoLm1heChlWzBdLnBhZ2VZLCBlWzFdLnBhZ2VZKTtcbiAgICAgIHJldHVybiB7IHg6IHIsIHk6IG4sIGxlZnQ6IHIsIHRvcDogbiwgcmlnaHQ6IG8sIGJvdHRvbTogbCwgd2lkdGg6IG8gLSByLCBoZWlnaHQ6IGwgLSBuIH07XG4gICAgfVxuICAgIGZ1bmN0aW9uIFh0KHQsIGUpIHtcbiAgICAgIHZhciByID0gZSArIFwiWFwiLCBuID0gZSArIFwiWVwiLCBvID0gWXQodCksIGwgPSBvWzBdW3JdIC0gb1sxXVtyXSwgYyA9IG9bMF1bbl0gLSBvWzFdW25dO1xuICAgICAgcmV0dXJuIEdlKGwsIGMpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBCdCh0LCBlKSB7XG4gICAgICB2YXIgciA9IGUgKyBcIlhcIiwgbiA9IGUgKyBcIllcIiwgbyA9IFl0KHQpLCBsID0gb1sxXVtyXSAtIG9bMF1bcl0sIGMgPSBvWzFdW25dIC0gb1swXVtuXTtcbiAgICAgIHJldHVybiAxODAgKiBNYXRoLmF0YW4yKGMsIGwpIC8gTWF0aC5QSTtcbiAgICB9XG4gICAgZnVuY3Rpb24gUXIodCkge1xuICAgICAgcmV0dXJuIHcuc3RyaW5nKHQucG9pbnRlclR5cGUpID8gdC5wb2ludGVyVHlwZSA6IHcubnVtYmVyKHQucG9pbnRlclR5cGUpID8gW3ZvaWQgMCwgdm9pZCAwLCBcInRvdWNoXCIsIFwicGVuXCIsIFwibW91c2VcIl1bdC5wb2ludGVyVHlwZV0gOiAvdG91Y2gvLnRlc3QodC50eXBlIHx8IFwiXCIpIHx8IHQgaW5zdGFuY2VvZiBRLlRvdWNoID8gXCJ0b3VjaFwiIDogXCJtb3VzZVwiO1xuICAgIH1cbiAgICBmdW5jdGlvbiBlbih0KSB7XG4gICAgICB2YXIgZSA9IHcuZnVuYyh0LmNvbXBvc2VkUGF0aCkgPyB0LmNvbXBvc2VkUGF0aCgpIDogdC5wYXRoO1xuICAgICAgcmV0dXJuIFtHcihlID8gZVswXSA6IHQudGFyZ2V0KSwgR3IodC5jdXJyZW50VGFyZ2V0KV07XG4gICAgfVxuICAgIHZhciBjdCA9IGZ1bmN0aW9uKCkge1xuICAgICAgZnVuY3Rpb24gdChlKSB7XG4gICAgICAgIGYodGhpcywgdCksIHRoaXMuaW1tZWRpYXRlUHJvcGFnYXRpb25TdG9wcGVkID0gITEsIHRoaXMucHJvcGFnYXRpb25TdG9wcGVkID0gITEsIHRoaXMuX2ludGVyYWN0aW9uID0gZTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB5KHQsIFt7IGtleTogXCJwcmV2ZW50RGVmYXVsdFwiLCB2YWx1ZTogZnVuY3Rpb24oKSB7XG4gICAgICB9IH0sIHsga2V5OiBcInN0b3BQcm9wYWdhdGlvblwiLCB2YWx1ZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMucHJvcGFnYXRpb25TdG9wcGVkID0gITA7XG4gICAgICB9IH0sIHsga2V5OiBcInN0b3BJbW1lZGlhdGVQcm9wYWdhdGlvblwiLCB2YWx1ZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMuaW1tZWRpYXRlUHJvcGFnYXRpb25TdG9wcGVkID0gdGhpcy5wcm9wYWdhdGlvblN0b3BwZWQgPSAhMDtcbiAgICAgIH0gfV0pLCB0O1xuICAgIH0oKTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoY3QucHJvdG90eXBlLCBcImludGVyYWN0aW9uXCIsIHsgZ2V0OiBmdW5jdGlvbigpIHtcbiAgICAgIHJldHVybiB0aGlzLl9pbnRlcmFjdGlvbi5fcHJveHk7XG4gICAgfSwgc2V0OiBmdW5jdGlvbigpIHtcbiAgICB9IH0pO1xuICAgIHZhciB0biA9IGZ1bmN0aW9uKHQsIGUpIHtcbiAgICAgIGZvciAodmFyIHIgPSAwOyByIDwgZS5sZW5ndGg7IHIrKykge1xuICAgICAgICB2YXIgbiA9IGVbcl07XG4gICAgICAgIHQucHVzaChuKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB0O1xuICAgIH0sIHJuID0gZnVuY3Rpb24odCkge1xuICAgICAgcmV0dXJuIHRuKFtdLCB0KTtcbiAgICB9LCBLZSA9IGZ1bmN0aW9uKHQsIGUpIHtcbiAgICAgIGZvciAodmFyIHIgPSAwOyByIDwgdC5sZW5ndGg7IHIrKykgaWYgKGUodFtyXSwgciwgdCkpIHJldHVybiByO1xuICAgICAgcmV0dXJuIC0xO1xuICAgIH0sIFhlID0gZnVuY3Rpb24odCwgZSkge1xuICAgICAgcmV0dXJuIHRbS2UodCwgZSldO1xuICAgIH0sIERlID0gZnVuY3Rpb24odCkge1xuICAgICAgQyhyLCB0KTtcbiAgICAgIHZhciBlID0gUChyKTtcbiAgICAgIGZ1bmN0aW9uIHIobiwgbywgbCkge1xuICAgICAgICB2YXIgYztcbiAgICAgICAgZih0aGlzLCByKSwgKGMgPSBlLmNhbGwodGhpcywgby5faW50ZXJhY3Rpb24pKS5kcm9wem9uZSA9IHZvaWQgMCwgYy5kcmFnRXZlbnQgPSB2b2lkIDAsIGMucmVsYXRlZFRhcmdldCA9IHZvaWQgMCwgYy5kcmFnZ2FibGUgPSB2b2lkIDAsIGMucHJvcGFnYXRpb25TdG9wcGVkID0gITEsIGMuaW1tZWRpYXRlUHJvcGFnYXRpb25TdG9wcGVkID0gITE7XG4gICAgICAgIHZhciBwID0gbCA9PT0gXCJkcmFnbGVhdmVcIiA/IG4ucHJldiA6IG4uY3VyLCBoID0gcC5lbGVtZW50LCBnID0gcC5kcm9wem9uZTtcbiAgICAgICAgcmV0dXJuIGMudHlwZSA9IGwsIGMudGFyZ2V0ID0gaCwgYy5jdXJyZW50VGFyZ2V0ID0gaCwgYy5kcm9wem9uZSA9IGcsIGMuZHJhZ0V2ZW50ID0gbywgYy5yZWxhdGVkVGFyZ2V0ID0gby50YXJnZXQsIGMuZHJhZ2dhYmxlID0gby5pbnRlcmFjdGFibGUsIGMudGltZVN0YW1wID0gby50aW1lU3RhbXAsIGM7XG4gICAgICB9XG4gICAgICByZXR1cm4geShyLCBbeyBrZXk6IFwicmVqZWN0XCIsIHZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIG4gPSB0aGlzLCBvID0gdGhpcy5faW50ZXJhY3Rpb24uZHJvcFN0YXRlO1xuICAgICAgICBpZiAodGhpcy50eXBlID09PSBcImRyb3BhY3RpdmF0ZVwiIHx8IHRoaXMuZHJvcHpvbmUgJiYgby5jdXIuZHJvcHpvbmUgPT09IHRoaXMuZHJvcHpvbmUgJiYgby5jdXIuZWxlbWVudCA9PT0gdGhpcy50YXJnZXQpIGlmIChvLnByZXYuZHJvcHpvbmUgPSB0aGlzLmRyb3B6b25lLCBvLnByZXYuZWxlbWVudCA9IHRoaXMudGFyZ2V0LCBvLnJlamVjdGVkID0gITAsIG8uZXZlbnRzLmVudGVyID0gbnVsbCwgdGhpcy5zdG9wSW1tZWRpYXRlUHJvcGFnYXRpb24oKSwgdGhpcy50eXBlID09PSBcImRyb3BhY3RpdmF0ZVwiKSB7XG4gICAgICAgICAgdmFyIGwgPSBvLmFjdGl2ZURyb3BzLCBjID0gS2UobCwgZnVuY3Rpb24oaCkge1xuICAgICAgICAgICAgdmFyIGcgPSBoLmRyb3B6b25lLCBkID0gaC5lbGVtZW50O1xuICAgICAgICAgICAgcmV0dXJuIGcgPT09IG4uZHJvcHpvbmUgJiYgZCA9PT0gbi50YXJnZXQ7XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgby5hY3RpdmVEcm9wcy5zcGxpY2UoYywgMSk7XG4gICAgICAgICAgdmFyIHAgPSBuZXcgcihvLCB0aGlzLmRyYWdFdmVudCwgXCJkcm9wZGVhY3RpdmF0ZVwiKTtcbiAgICAgICAgICBwLmRyb3B6b25lID0gdGhpcy5kcm9wem9uZSwgcC50YXJnZXQgPSB0aGlzLnRhcmdldCwgdGhpcy5kcm9wem9uZS5maXJlKHApO1xuICAgICAgICB9IGVsc2UgdGhpcy5kcm9wem9uZS5maXJlKG5ldyByKG8sIHRoaXMuZHJhZ0V2ZW50LCBcImRyYWdsZWF2ZVwiKSk7XG4gICAgICB9IH0sIHsga2V5OiBcInByZXZlbnREZWZhdWx0XCIsIHZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgIH0gfSwgeyBrZXk6IFwic3RvcFByb3BhZ2F0aW9uXCIsIHZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy5wcm9wYWdhdGlvblN0b3BwZWQgPSAhMDtcbiAgICAgIH0gfSwgeyBrZXk6IFwic3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uXCIsIHZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy5pbW1lZGlhdGVQcm9wYWdhdGlvblN0b3BwZWQgPSB0aGlzLnByb3BhZ2F0aW9uU3RvcHBlZCA9ICEwO1xuICAgICAgfSB9XSksIHI7XG4gICAgfShjdCk7XG4gICAgZnVuY3Rpb24gbm4odCwgZSkge1xuICAgICAgZm9yICh2YXIgciA9IDAsIG4gPSB0LnNsaWNlKCk7IHIgPCBuLmxlbmd0aDsgcisrKSB7XG4gICAgICAgIHZhciBvID0gbltyXSwgbCA9IG8uZHJvcHpvbmUsIGMgPSBvLmVsZW1lbnQ7XG4gICAgICAgIGUuZHJvcHpvbmUgPSBsLCBlLnRhcmdldCA9IGMsIGwuZmlyZShlKSwgZS5wcm9wYWdhdGlvblN0b3BwZWQgPSBlLmltbWVkaWF0ZVByb3BhZ2F0aW9uU3RvcHBlZCA9ICExO1xuICAgICAgfVxuICAgIH1cbiAgICBmdW5jdGlvbiBWdCh0LCBlKSB7XG4gICAgICBmb3IgKHZhciByID0gZnVuY3Rpb24obCwgYykge1xuICAgICAgICBmb3IgKHZhciBwID0gW10sIGggPSAwLCBnID0gbC5pbnRlcmFjdGFibGVzLmxpc3Q7IGggPCBnLmxlbmd0aDsgaCsrKSB7XG4gICAgICAgICAgdmFyIGQgPSBnW2hdO1xuICAgICAgICAgIGlmIChkLm9wdGlvbnMuZHJvcC5lbmFibGVkKSB7XG4gICAgICAgICAgICB2YXIgYiA9IGQub3B0aW9ucy5kcm9wLmFjY2VwdDtcbiAgICAgICAgICAgIGlmICghKHcuZWxlbWVudChiKSAmJiBiICE9PSBjIHx8IHcuc3RyaW5nKGIpICYmICFtZShjLCBiKSB8fCB3LmZ1bmMoYikgJiYgIWIoeyBkcm9wem9uZTogZCwgZHJhZ2dhYmxlRWxlbWVudDogYyB9KSkpIGZvciAodmFyIHggPSAwLCBJID0gZC5nZXRBbGxFbGVtZW50cygpOyB4IDwgSS5sZW5ndGg7IHgrKykge1xuICAgICAgICAgICAgICB2YXIgRSA9IElbeF07XG4gICAgICAgICAgICAgIEUgIT09IGMgJiYgcC5wdXNoKHsgZHJvcHpvbmU6IGQsIGVsZW1lbnQ6IEUsIHJlY3Q6IGQuZ2V0UmVjdChFKSB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHA7XG4gICAgICB9KHQsIGUpLCBuID0gMDsgbiA8IHIubGVuZ3RoOyBuKyspIHtcbiAgICAgICAgdmFyIG8gPSByW25dO1xuICAgICAgICBvLnJlY3QgPSBvLmRyb3B6b25lLmdldFJlY3Qoby5lbGVtZW50KTtcbiAgICAgIH1cbiAgICAgIHJldHVybiByO1xuICAgIH1cbiAgICBmdW5jdGlvbiBvbih0LCBlLCByKSB7XG4gICAgICBmb3IgKHZhciBuID0gdC5kcm9wU3RhdGUsIG8gPSB0LmludGVyYWN0YWJsZSwgbCA9IHQuZWxlbWVudCwgYyA9IFtdLCBwID0gMCwgaCA9IG4uYWN0aXZlRHJvcHM7IHAgPCBoLmxlbmd0aDsgcCsrKSB7XG4gICAgICAgIHZhciBnID0gaFtwXSwgZCA9IGcuZHJvcHpvbmUsIGIgPSBnLmVsZW1lbnQsIHggPSBnLnJlY3QsIEkgPSBkLmRyb3BDaGVjayhlLCByLCBvLCBsLCBiLCB4KTtcbiAgICAgICAgYy5wdXNoKEkgPyBiIDogbnVsbCk7XG4gICAgICB9XG4gICAgICB2YXIgRSA9IGZ1bmN0aW9uKE0pIHtcbiAgICAgICAgZm9yICh2YXIgJCwgeiwgQSwgTiA9IFtdLCBLID0gMDsgSyA8IE0ubGVuZ3RoOyBLKyspIHtcbiAgICAgICAgICB2YXIgRiA9IE1bS10sIEcgPSBNWyRdO1xuICAgICAgICAgIGlmIChGICYmIEsgIT09ICQpIGlmIChHKSB7XG4gICAgICAgICAgICB2YXIgdGUgPSBXdChGKSwgSiA9IFd0KEcpO1xuICAgICAgICAgICAgaWYgKHRlICE9PSBGLm93bmVyRG9jdW1lbnQpIGlmIChKICE9PSBGLm93bmVyRG9jdW1lbnQpIGlmICh0ZSAhPT0gSikge1xuICAgICAgICAgICAgICBOID0gTi5sZW5ndGggPyBOIDogTnIoRyk7XG4gICAgICAgICAgICAgIHZhciByZSA9IHZvaWQgMDtcbiAgICAgICAgICAgICAgaWYgKEcgaW5zdGFuY2VvZiBRLkhUTUxFbGVtZW50ICYmIEYgaW5zdGFuY2VvZiBRLlNWR0VsZW1lbnQgJiYgIShGIGluc3RhbmNlb2YgUS5TVkdTVkdFbGVtZW50KSkge1xuICAgICAgICAgICAgICAgIGlmIChGID09PSBKKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgICByZSA9IEYub3duZXJTVkdFbGVtZW50O1xuICAgICAgICAgICAgICB9IGVsc2UgcmUgPSBGO1xuICAgICAgICAgICAgICBmb3IgKHZhciBzZSA9IE5yKHJlLCBHLm93bmVyRG9jdW1lbnQpLCBmZSA9IDA7IHNlW2ZlXSAmJiBzZVtmZV0gPT09IE5bZmVdOyApIGZlKys7XG4gICAgICAgICAgICAgIHZhciBidCA9IFtzZVtmZSAtIDFdLCBzZVtmZV0sIE5bZmVdXTtcbiAgICAgICAgICAgICAgaWYgKGJ0WzBdKSBmb3IgKHZhciBRZSA9IGJ0WzBdLmxhc3RDaGlsZDsgUWU7ICkge1xuICAgICAgICAgICAgICAgIGlmIChRZSA9PT0gYnRbMV0pIHtcbiAgICAgICAgICAgICAgICAgICQgPSBLLCBOID0gc2U7XG4gICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKFFlID09PSBidFsyXSkgYnJlYWs7XG4gICAgICAgICAgICAgICAgUWUgPSBRZS5wcmV2aW91c1NpYmxpbmc7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSBBID0gRywgKHBhcnNlSW50KEIoeiA9IEYpLmdldENvbXB1dGVkU3R5bGUoeikuekluZGV4LCAxMCkgfHwgMCkgPj0gKHBhcnNlSW50KEIoQSkuZ2V0Q29tcHV0ZWRTdHlsZShBKS56SW5kZXgsIDEwKSB8fCAwKSAmJiAoJCA9IEspO1xuICAgICAgICAgICAgZWxzZSAkID0gSztcbiAgICAgICAgICB9IGVsc2UgJCA9IEs7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuICQ7XG4gICAgICB9KGMpO1xuICAgICAgcmV0dXJuIG4uYWN0aXZlRHJvcHNbRV0gfHwgbnVsbDtcbiAgICB9XG4gICAgZnVuY3Rpb24gcXQodCwgZSwgcikge1xuICAgICAgdmFyIG4gPSB0LmRyb3BTdGF0ZSwgbyA9IHsgZW50ZXI6IG51bGwsIGxlYXZlOiBudWxsLCBhY3RpdmF0ZTogbnVsbCwgZGVhY3RpdmF0ZTogbnVsbCwgbW92ZTogbnVsbCwgZHJvcDogbnVsbCB9O1xuICAgICAgcmV0dXJuIHIudHlwZSA9PT0gXCJkcmFnc3RhcnRcIiAmJiAoby5hY3RpdmF0ZSA9IG5ldyBEZShuLCByLCBcImRyb3BhY3RpdmF0ZVwiKSwgby5hY3RpdmF0ZS50YXJnZXQgPSBudWxsLCBvLmFjdGl2YXRlLmRyb3B6b25lID0gbnVsbCksIHIudHlwZSA9PT0gXCJkcmFnZW5kXCIgJiYgKG8uZGVhY3RpdmF0ZSA9IG5ldyBEZShuLCByLCBcImRyb3BkZWFjdGl2YXRlXCIpLCBvLmRlYWN0aXZhdGUudGFyZ2V0ID0gbnVsbCwgby5kZWFjdGl2YXRlLmRyb3B6b25lID0gbnVsbCksIG4ucmVqZWN0ZWQgfHwgKG4uY3VyLmVsZW1lbnQgIT09IG4ucHJldi5lbGVtZW50ICYmIChuLnByZXYuZHJvcHpvbmUgJiYgKG8ubGVhdmUgPSBuZXcgRGUobiwgciwgXCJkcmFnbGVhdmVcIiksIHIuZHJhZ0xlYXZlID0gby5sZWF2ZS50YXJnZXQgPSBuLnByZXYuZWxlbWVudCwgci5wcmV2RHJvcHpvbmUgPSBvLmxlYXZlLmRyb3B6b25lID0gbi5wcmV2LmRyb3B6b25lKSwgbi5jdXIuZHJvcHpvbmUgJiYgKG8uZW50ZXIgPSBuZXcgRGUobiwgciwgXCJkcmFnZW50ZXJcIiksIHIuZHJhZ0VudGVyID0gbi5jdXIuZWxlbWVudCwgci5kcm9wem9uZSA9IG4uY3VyLmRyb3B6b25lKSksIHIudHlwZSA9PT0gXCJkcmFnZW5kXCIgJiYgbi5jdXIuZHJvcHpvbmUgJiYgKG8uZHJvcCA9IG5ldyBEZShuLCByLCBcImRyb3BcIiksIHIuZHJvcHpvbmUgPSBuLmN1ci5kcm9wem9uZSwgci5yZWxhdGVkVGFyZ2V0ID0gbi5jdXIuZWxlbWVudCksIHIudHlwZSA9PT0gXCJkcmFnbW92ZVwiICYmIG4uY3VyLmRyb3B6b25lICYmIChvLm1vdmUgPSBuZXcgRGUobiwgciwgXCJkcm9wbW92ZVwiKSwgci5kcm9wem9uZSA9IG4uY3VyLmRyb3B6b25lKSksIG87XG4gICAgfVxuICAgIGZ1bmN0aW9uIFp0KHQsIGUpIHtcbiAgICAgIHZhciByID0gdC5kcm9wU3RhdGUsIG4gPSByLmFjdGl2ZURyb3BzLCBvID0gci5jdXIsIGwgPSByLnByZXY7XG4gICAgICBlLmxlYXZlICYmIGwuZHJvcHpvbmUuZmlyZShlLmxlYXZlKSwgZS5lbnRlciAmJiBvLmRyb3B6b25lLmZpcmUoZS5lbnRlciksIGUubW92ZSAmJiBvLmRyb3B6b25lLmZpcmUoZS5tb3ZlKSwgZS5kcm9wICYmIG8uZHJvcHpvbmUuZmlyZShlLmRyb3ApLCBlLmRlYWN0aXZhdGUgJiYgbm4obiwgZS5kZWFjdGl2YXRlKSwgci5wcmV2LmRyb3B6b25lID0gby5kcm9wem9uZSwgci5wcmV2LmVsZW1lbnQgPSBvLmVsZW1lbnQ7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHNuKHQsIGUpIHtcbiAgICAgIHZhciByID0gdC5pbnRlcmFjdGlvbiwgbiA9IHQuaUV2ZW50LCBvID0gdC5ldmVudDtcbiAgICAgIGlmIChuLnR5cGUgPT09IFwiZHJhZ21vdmVcIiB8fCBuLnR5cGUgPT09IFwiZHJhZ2VuZFwiKSB7XG4gICAgICAgIHZhciBsID0gci5kcm9wU3RhdGU7XG4gICAgICAgIGUuZHluYW1pY0Ryb3AgJiYgKGwuYWN0aXZlRHJvcHMgPSBWdChlLCByLmVsZW1lbnQpKTtcbiAgICAgICAgdmFyIGMgPSBuLCBwID0gb24ociwgYywgbyk7XG4gICAgICAgIGwucmVqZWN0ZWQgPSBsLnJlamVjdGVkICYmICEhcCAmJiBwLmRyb3B6b25lID09PSBsLmN1ci5kcm9wem9uZSAmJiBwLmVsZW1lbnQgPT09IGwuY3VyLmVsZW1lbnQsIGwuY3VyLmRyb3B6b25lID0gcCAmJiBwLmRyb3B6b25lLCBsLmN1ci5lbGVtZW50ID0gcCAmJiBwLmVsZW1lbnQsIGwuZXZlbnRzID0gcXQociwgMCwgYyk7XG4gICAgICB9XG4gICAgfVxuICAgIHZhciBhbiA9IHsgaWQ6IFwiYWN0aW9ucy9kcm9wXCIsIGluc3RhbGw6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHZhciBlID0gdC5hY3Rpb25zLCByID0gdC5pbnRlcmFjdFN0YXRpYywgbiA9IHQuSW50ZXJhY3RhYmxlLCBvID0gdC5kZWZhdWx0cztcbiAgICAgIHQudXNlUGx1Z2luKEZyKSwgbi5wcm90b3R5cGUuZHJvcHpvbmUgPSBmdW5jdGlvbihsKSB7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbihjLCBwKSB7XG4gICAgICAgICAgaWYgKHcub2JqZWN0KHApKSB7XG4gICAgICAgICAgICBpZiAoYy5vcHRpb25zLmRyb3AuZW5hYmxlZCA9IHAuZW5hYmxlZCAhPT0gITEsIHAubGlzdGVuZXJzKSB7XG4gICAgICAgICAgICAgIHZhciBoID0gT2UocC5saXN0ZW5lcnMpLCBnID0gT2JqZWN0LmtleXMoaCkucmVkdWNlKGZ1bmN0aW9uKGIsIHgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gYlsvXihlbnRlcnxsZWF2ZSkvLnRlc3QoeCkgPyBcImRyYWdcIi5jb25jYXQoeCkgOiAvXihhY3RpdmF0ZXxkZWFjdGl2YXRlfG1vdmUpLy50ZXN0KHgpID8gXCJkcm9wXCIuY29uY2F0KHgpIDogeF0gPSBoW3hdLCBiO1xuICAgICAgICAgICAgICB9LCB7fSksIGQgPSBjLm9wdGlvbnMuZHJvcC5saXN0ZW5lcnM7XG4gICAgICAgICAgICAgIGQgJiYgYy5vZmYoZCksIGMub24oZyksIGMub3B0aW9ucy5kcm9wLmxpc3RlbmVycyA9IGc7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdy5mdW5jKHAub25kcm9wKSAmJiBjLm9uKFwiZHJvcFwiLCBwLm9uZHJvcCksIHcuZnVuYyhwLm9uZHJvcGFjdGl2YXRlKSAmJiBjLm9uKFwiZHJvcGFjdGl2YXRlXCIsIHAub25kcm9wYWN0aXZhdGUpLCB3LmZ1bmMocC5vbmRyb3BkZWFjdGl2YXRlKSAmJiBjLm9uKFwiZHJvcGRlYWN0aXZhdGVcIiwgcC5vbmRyb3BkZWFjdGl2YXRlKSwgdy5mdW5jKHAub25kcmFnZW50ZXIpICYmIGMub24oXCJkcmFnZW50ZXJcIiwgcC5vbmRyYWdlbnRlciksIHcuZnVuYyhwLm9uZHJhZ2xlYXZlKSAmJiBjLm9uKFwiZHJhZ2xlYXZlXCIsIHAub25kcmFnbGVhdmUpLCB3LmZ1bmMocC5vbmRyb3Btb3ZlKSAmJiBjLm9uKFwiZHJvcG1vdmVcIiwgcC5vbmRyb3Btb3ZlKSwgL14ocG9pbnRlcnxjZW50ZXIpJC8udGVzdChwLm92ZXJsYXApID8gYy5vcHRpb25zLmRyb3Aub3ZlcmxhcCA9IHAub3ZlcmxhcCA6IHcubnVtYmVyKHAub3ZlcmxhcCkgJiYgKGMub3B0aW9ucy5kcm9wLm92ZXJsYXAgPSBNYXRoLm1heChNYXRoLm1pbigxLCBwLm92ZXJsYXApLCAwKSksIFwiYWNjZXB0XCIgaW4gcCAmJiAoYy5vcHRpb25zLmRyb3AuYWNjZXB0ID0gcC5hY2NlcHQpLCBcImNoZWNrZXJcIiBpbiBwICYmIChjLm9wdGlvbnMuZHJvcC5jaGVja2VyID0gcC5jaGVja2VyKSwgYztcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHcuYm9vbChwKSA/IChjLm9wdGlvbnMuZHJvcC5lbmFibGVkID0gcCwgYykgOiBjLm9wdGlvbnMuZHJvcDtcbiAgICAgICAgfSh0aGlzLCBsKTtcbiAgICAgIH0sIG4ucHJvdG90eXBlLmRyb3BDaGVjayA9IGZ1bmN0aW9uKGwsIGMsIHAsIGgsIGcsIGQpIHtcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uKGIsIHgsIEksIEUsIE0sICQsIHopIHtcbiAgICAgICAgICB2YXIgQSA9ICExO1xuICAgICAgICAgIGlmICghKHogPSB6IHx8IGIuZ2V0UmVjdCgkKSkpIHJldHVybiAhIWIub3B0aW9ucy5kcm9wLmNoZWNrZXIgJiYgYi5vcHRpb25zLmRyb3AuY2hlY2tlcih4LCBJLCBBLCBiLCAkLCBFLCBNKTtcbiAgICAgICAgICB2YXIgTiA9IGIub3B0aW9ucy5kcm9wLm92ZXJsYXA7XG4gICAgICAgICAgaWYgKE4gPT09IFwicG9pbnRlclwiKSB7XG4gICAgICAgICAgICB2YXIgSyA9IE5lKEUsIE0sIFwiZHJhZ1wiKSwgRiA9IFpyKHgpO1xuICAgICAgICAgICAgRi54ICs9IEsueCwgRi55ICs9IEsueTtcbiAgICAgICAgICAgIHZhciBHID0gRi54ID4gei5sZWZ0ICYmIEYueCA8IHoucmlnaHQsIHRlID0gRi55ID4gei50b3AgJiYgRi55IDwgei5ib3R0b207XG4gICAgICAgICAgICBBID0gRyAmJiB0ZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdmFyIEogPSBFLmdldFJlY3QoTSk7XG4gICAgICAgICAgaWYgKEogJiYgTiA9PT0gXCJjZW50ZXJcIikge1xuICAgICAgICAgICAgdmFyIHJlID0gSi5sZWZ0ICsgSi53aWR0aCAvIDIsIHNlID0gSi50b3AgKyBKLmhlaWdodCAvIDI7XG4gICAgICAgICAgICBBID0gcmUgPj0gei5sZWZ0ICYmIHJlIDw9IHoucmlnaHQgJiYgc2UgPj0gei50b3AgJiYgc2UgPD0gei5ib3R0b207XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBKICYmIHcubnVtYmVyKE4pICYmIChBID0gTWF0aC5tYXgoMCwgTWF0aC5taW4oei5yaWdodCwgSi5yaWdodCkgLSBNYXRoLm1heCh6LmxlZnQsIEoubGVmdCkpICogTWF0aC5tYXgoMCwgTWF0aC5taW4oei5ib3R0b20sIEouYm90dG9tKSAtIE1hdGgubWF4KHoudG9wLCBKLnRvcCkpIC8gKEoud2lkdGggKiBKLmhlaWdodCkgPj0gTiksIGIub3B0aW9ucy5kcm9wLmNoZWNrZXIgJiYgKEEgPSBiLm9wdGlvbnMuZHJvcC5jaGVja2VyKHgsIEksIEEsIGIsICQsIEUsIE0pKSwgQTtcbiAgICAgICAgfSh0aGlzLCBsLCBjLCBwLCBoLCBnLCBkKTtcbiAgICAgIH0sIHIuZHluYW1pY0Ryb3AgPSBmdW5jdGlvbihsKSB7XG4gICAgICAgIHJldHVybiB3LmJvb2wobCkgPyAodC5keW5hbWljRHJvcCA9IGwsIHIpIDogdC5keW5hbWljRHJvcDtcbiAgICAgIH0sIFcoZS5waGFzZWxlc3NUeXBlcywgeyBkcmFnZW50ZXI6ICEwLCBkcmFnbGVhdmU6ICEwLCBkcm9wYWN0aXZhdGU6ICEwLCBkcm9wZGVhY3RpdmF0ZTogITAsIGRyb3Btb3ZlOiAhMCwgZHJvcDogITAgfSksIGUubWV0aG9kRGljdC5kcm9wID0gXCJkcm9wem9uZVwiLCB0LmR5bmFtaWNEcm9wID0gITEsIG8uYWN0aW9ucy5kcm9wID0gYW4uZGVmYXVsdHM7XG4gICAgfSwgbGlzdGVuZXJzOiB7IFwiaW50ZXJhY3Rpb25zOmJlZm9yZS1hY3Rpb24tc3RhcnRcIjogZnVuY3Rpb24odCkge1xuICAgICAgdmFyIGUgPSB0LmludGVyYWN0aW9uO1xuICAgICAgZS5wcmVwYXJlZC5uYW1lID09PSBcImRyYWdcIiAmJiAoZS5kcm9wU3RhdGUgPSB7IGN1cjogeyBkcm9wem9uZTogbnVsbCwgZWxlbWVudDogbnVsbCB9LCBwcmV2OiB7IGRyb3B6b25lOiBudWxsLCBlbGVtZW50OiBudWxsIH0sIHJlamVjdGVkOiBudWxsLCBldmVudHM6IG51bGwsIGFjdGl2ZURyb3BzOiBbXSB9KTtcbiAgICB9LCBcImludGVyYWN0aW9uczphZnRlci1hY3Rpb24tc3RhcnRcIjogZnVuY3Rpb24odCwgZSkge1xuICAgICAgdmFyIHIgPSB0LmludGVyYWN0aW9uLCBuID0gKHQuZXZlbnQsIHQuaUV2ZW50KTtcbiAgICAgIGlmIChyLnByZXBhcmVkLm5hbWUgPT09IFwiZHJhZ1wiKSB7XG4gICAgICAgIHZhciBvID0gci5kcm9wU3RhdGU7XG4gICAgICAgIG8uYWN0aXZlRHJvcHMgPSBbXSwgby5ldmVudHMgPSB7fSwgby5hY3RpdmVEcm9wcyA9IFZ0KGUsIHIuZWxlbWVudCksIG8uZXZlbnRzID0gcXQociwgMCwgbiksIG8uZXZlbnRzLmFjdGl2YXRlICYmIChubihvLmFjdGl2ZURyb3BzLCBvLmV2ZW50cy5hY3RpdmF0ZSksIGUuZmlyZShcImFjdGlvbnMvZHJvcDpzdGFydFwiLCB7IGludGVyYWN0aW9uOiByLCBkcmFnRXZlbnQ6IG4gfSkpO1xuICAgICAgfVxuICAgIH0sIFwiaW50ZXJhY3Rpb25zOmFjdGlvbi1tb3ZlXCI6IHNuLCBcImludGVyYWN0aW9uczphZnRlci1hY3Rpb24tbW92ZVwiOiBmdW5jdGlvbih0LCBlKSB7XG4gICAgICB2YXIgciA9IHQuaW50ZXJhY3Rpb24sIG4gPSB0LmlFdmVudDtcbiAgICAgIGlmIChyLnByZXBhcmVkLm5hbWUgPT09IFwiZHJhZ1wiKSB7XG4gICAgICAgIHZhciBvID0gci5kcm9wU3RhdGU7XG4gICAgICAgIFp0KHIsIG8uZXZlbnRzKSwgZS5maXJlKFwiYWN0aW9ucy9kcm9wOm1vdmVcIiwgeyBpbnRlcmFjdGlvbjogciwgZHJhZ0V2ZW50OiBuIH0pLCBvLmV2ZW50cyA9IHt9O1xuICAgICAgfVxuICAgIH0sIFwiaW50ZXJhY3Rpb25zOmFjdGlvbi1lbmRcIjogZnVuY3Rpb24odCwgZSkge1xuICAgICAgaWYgKHQuaW50ZXJhY3Rpb24ucHJlcGFyZWQubmFtZSA9PT0gXCJkcmFnXCIpIHtcbiAgICAgICAgdmFyIHIgPSB0LmludGVyYWN0aW9uLCBuID0gdC5pRXZlbnQ7XG4gICAgICAgIHNuKHQsIGUpLCBadChyLCByLmRyb3BTdGF0ZS5ldmVudHMpLCBlLmZpcmUoXCJhY3Rpb25zL2Ryb3A6ZW5kXCIsIHsgaW50ZXJhY3Rpb246IHIsIGRyYWdFdmVudDogbiB9KTtcbiAgICAgIH1cbiAgICB9LCBcImludGVyYWN0aW9uczpzdG9wXCI6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHZhciBlID0gdC5pbnRlcmFjdGlvbjtcbiAgICAgIGlmIChlLnByZXBhcmVkLm5hbWUgPT09IFwiZHJhZ1wiKSB7XG4gICAgICAgIHZhciByID0gZS5kcm9wU3RhdGU7XG4gICAgICAgIHIgJiYgKHIuYWN0aXZlRHJvcHMgPSBudWxsLCByLmV2ZW50cyA9IG51bGwsIHIuY3VyLmRyb3B6b25lID0gbnVsbCwgci5jdXIuZWxlbWVudCA9IG51bGwsIHIucHJldi5kcm9wem9uZSA9IG51bGwsIHIucHJldi5lbGVtZW50ID0gbnVsbCwgci5yZWplY3RlZCA9ICExKTtcbiAgICAgIH1cbiAgICB9IH0sIGdldEFjdGl2ZURyb3BzOiBWdCwgZ2V0RHJvcDogb24sIGdldERyb3BFdmVudHM6IHF0LCBmaXJlRHJvcEV2ZW50czogWnQsIGZpbHRlckV2ZW50VHlwZTogZnVuY3Rpb24odCkge1xuICAgICAgcmV0dXJuIHQuc2VhcmNoKFwiZHJhZ1wiKSA9PT0gMCB8fCB0LnNlYXJjaChcImRyb3BcIikgPT09IDA7XG4gICAgfSwgZGVmYXVsdHM6IHsgZW5hYmxlZDogITEsIGFjY2VwdDogbnVsbCwgb3ZlcmxhcDogXCJwb2ludGVyXCIgfSB9LCBsbyA9IGFuO1xuICAgIGZ1bmN0aW9uIEp0KHQpIHtcbiAgICAgIHZhciBlID0gdC5pbnRlcmFjdGlvbiwgciA9IHQuaUV2ZW50LCBuID0gdC5waGFzZTtcbiAgICAgIGlmIChlLnByZXBhcmVkLm5hbWUgPT09IFwiZ2VzdHVyZVwiKSB7XG4gICAgICAgIHZhciBvID0gZS5wb2ludGVycy5tYXAoZnVuY3Rpb24oZykge1xuICAgICAgICAgIHJldHVybiBnLnBvaW50ZXI7XG4gICAgICAgIH0pLCBsID0gbiA9PT0gXCJzdGFydFwiLCBjID0gbiA9PT0gXCJlbmRcIiwgcCA9IGUuaW50ZXJhY3RhYmxlLm9wdGlvbnMuZGVsdGFTb3VyY2U7XG4gICAgICAgIGlmIChyLnRvdWNoZXMgPSBbb1swXSwgb1sxXV0sIGwpIHIuZGlzdGFuY2UgPSBYdChvLCBwKSwgci5ib3ggPSBLdChvKSwgci5zY2FsZSA9IDEsIHIuZHMgPSAwLCByLmFuZ2xlID0gQnQobywgcCksIHIuZGEgPSAwLCBlLmdlc3R1cmUuc3RhcnREaXN0YW5jZSA9IHIuZGlzdGFuY2UsIGUuZ2VzdHVyZS5zdGFydEFuZ2xlID0gci5hbmdsZTtcbiAgICAgICAgZWxzZSBpZiAoYyB8fCBlLnBvaW50ZXJzLmxlbmd0aCA8IDIpIHtcbiAgICAgICAgICB2YXIgaCA9IGUucHJldkV2ZW50O1xuICAgICAgICAgIHIuZGlzdGFuY2UgPSBoLmRpc3RhbmNlLCByLmJveCA9IGguYm94LCByLnNjYWxlID0gaC5zY2FsZSwgci5kcyA9IDAsIHIuYW5nbGUgPSBoLmFuZ2xlLCByLmRhID0gMDtcbiAgICAgICAgfSBlbHNlIHIuZGlzdGFuY2UgPSBYdChvLCBwKSwgci5ib3ggPSBLdChvKSwgci5zY2FsZSA9IHIuZGlzdGFuY2UgLyBlLmdlc3R1cmUuc3RhcnREaXN0YW5jZSwgci5hbmdsZSA9IEJ0KG8sIHApLCByLmRzID0gci5zY2FsZSAtIGUuZ2VzdHVyZS5zY2FsZSwgci5kYSA9IHIuYW5nbGUgLSBlLmdlc3R1cmUuYW5nbGU7XG4gICAgICAgIGUuZ2VzdHVyZS5kaXN0YW5jZSA9IHIuZGlzdGFuY2UsIGUuZ2VzdHVyZS5hbmdsZSA9IHIuYW5nbGUsIHcubnVtYmVyKHIuc2NhbGUpICYmIHIuc2NhbGUgIT09IDEgLyAwICYmICFpc05hTihyLnNjYWxlKSAmJiAoZS5nZXN0dXJlLnNjYWxlID0gci5zY2FsZSk7XG4gICAgICB9XG4gICAgfVxuICAgIHZhciBRdCA9IHsgaWQ6IFwiYWN0aW9ucy9nZXN0dXJlXCIsIGJlZm9yZTogW1wiYWN0aW9ucy9kcmFnXCIsIFwiYWN0aW9ucy9yZXNpemVcIl0sIGluc3RhbGw6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHZhciBlID0gdC5hY3Rpb25zLCByID0gdC5JbnRlcmFjdGFibGUsIG4gPSB0LmRlZmF1bHRzO1xuICAgICAgci5wcm90b3R5cGUuZ2VzdHVyYWJsZSA9IGZ1bmN0aW9uKG8pIHtcbiAgICAgICAgcmV0dXJuIHcub2JqZWN0KG8pID8gKHRoaXMub3B0aW9ucy5nZXN0dXJlLmVuYWJsZWQgPSBvLmVuYWJsZWQgIT09ICExLCB0aGlzLnNldFBlckFjdGlvbihcImdlc3R1cmVcIiwgbyksIHRoaXMuc2V0T25FdmVudHMoXCJnZXN0dXJlXCIsIG8pLCB0aGlzKSA6IHcuYm9vbChvKSA/ICh0aGlzLm9wdGlvbnMuZ2VzdHVyZS5lbmFibGVkID0gbywgdGhpcykgOiB0aGlzLm9wdGlvbnMuZ2VzdHVyZTtcbiAgICAgIH0sIGUubWFwLmdlc3R1cmUgPSBRdCwgZS5tZXRob2REaWN0Lmdlc3R1cmUgPSBcImdlc3R1cmFibGVcIiwgbi5hY3Rpb25zLmdlc3R1cmUgPSBRdC5kZWZhdWx0cztcbiAgICB9LCBsaXN0ZW5lcnM6IHsgXCJpbnRlcmFjdGlvbnM6YWN0aW9uLXN0YXJ0XCI6IEp0LCBcImludGVyYWN0aW9uczphY3Rpb24tbW92ZVwiOiBKdCwgXCJpbnRlcmFjdGlvbnM6YWN0aW9uLWVuZFwiOiBKdCwgXCJpbnRlcmFjdGlvbnM6bmV3XCI6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHQuaW50ZXJhY3Rpb24uZ2VzdHVyZSA9IHsgYW5nbGU6IDAsIGRpc3RhbmNlOiAwLCBzY2FsZTogMSwgc3RhcnRBbmdsZTogMCwgc3RhcnREaXN0YW5jZTogMCB9O1xuICAgIH0sIFwiYXV0by1zdGFydDpjaGVja1wiOiBmdW5jdGlvbih0KSB7XG4gICAgICBpZiAoISh0LmludGVyYWN0aW9uLnBvaW50ZXJzLmxlbmd0aCA8IDIpKSB7XG4gICAgICAgIHZhciBlID0gdC5pbnRlcmFjdGFibGUub3B0aW9ucy5nZXN0dXJlO1xuICAgICAgICBpZiAoZSAmJiBlLmVuYWJsZWQpIHJldHVybiB0LmFjdGlvbiA9IHsgbmFtZTogXCJnZXN0dXJlXCIgfSwgITE7XG4gICAgICB9XG4gICAgfSB9LCBkZWZhdWx0czoge30sIGdldEN1cnNvcjogZnVuY3Rpb24oKSB7XG4gICAgICByZXR1cm4gXCJcIjtcbiAgICB9LCBmaWx0ZXJFdmVudFR5cGU6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHJldHVybiB0LnNlYXJjaChcImdlc3R1cmVcIikgPT09IDA7XG4gICAgfSB9LCBjbyA9IFF0O1xuICAgIGZ1bmN0aW9uIHVvKHQsIGUsIHIsIG4sIG8sIGwsIGMpIHtcbiAgICAgIGlmICghZSkgcmV0dXJuICExO1xuICAgICAgaWYgKGUgPT09ICEwKSB7XG4gICAgICAgIHZhciBwID0gdy5udW1iZXIobC53aWR0aCkgPyBsLndpZHRoIDogbC5yaWdodCAtIGwubGVmdCwgaCA9IHcubnVtYmVyKGwuaGVpZ2h0KSA/IGwuaGVpZ2h0IDogbC5ib3R0b20gLSBsLnRvcDtcbiAgICAgICAgaWYgKGMgPSBNYXRoLm1pbihjLCBNYXRoLmFicygodCA9PT0gXCJsZWZ0XCIgfHwgdCA9PT0gXCJyaWdodFwiID8gcCA6IGgpIC8gMikpLCBwIDwgMCAmJiAodCA9PT0gXCJsZWZ0XCIgPyB0ID0gXCJyaWdodFwiIDogdCA9PT0gXCJyaWdodFwiICYmICh0ID0gXCJsZWZ0XCIpKSwgaCA8IDAgJiYgKHQgPT09IFwidG9wXCIgPyB0ID0gXCJib3R0b21cIiA6IHQgPT09IFwiYm90dG9tXCIgJiYgKHQgPSBcInRvcFwiKSksIHQgPT09IFwibGVmdFwiKSB7XG4gICAgICAgICAgdmFyIGcgPSBwID49IDAgPyBsLmxlZnQgOiBsLnJpZ2h0O1xuICAgICAgICAgIHJldHVybiByLnggPCBnICsgYztcbiAgICAgICAgfVxuICAgICAgICBpZiAodCA9PT0gXCJ0b3BcIikge1xuICAgICAgICAgIHZhciBkID0gaCA+PSAwID8gbC50b3AgOiBsLmJvdHRvbTtcbiAgICAgICAgICByZXR1cm4gci55IDwgZCArIGM7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHQgPT09IFwicmlnaHRcIikgcmV0dXJuIHIueCA+IChwID49IDAgPyBsLnJpZ2h0IDogbC5sZWZ0KSAtIGM7XG4gICAgICAgIGlmICh0ID09PSBcImJvdHRvbVwiKSByZXR1cm4gci55ID4gKGggPj0gMCA/IGwuYm90dG9tIDogbC50b3ApIC0gYztcbiAgICAgIH1cbiAgICAgIHJldHVybiAhIXcuZWxlbWVudChuKSAmJiAody5lbGVtZW50KGUpID8gZSA9PT0gbiA6IEZ0KG4sIGUsIG8pKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gbG4odCkge1xuICAgICAgdmFyIGUgPSB0LmlFdmVudCwgciA9IHQuaW50ZXJhY3Rpb247XG4gICAgICBpZiAoci5wcmVwYXJlZC5uYW1lID09PSBcInJlc2l6ZVwiICYmIHIucmVzaXplQXhlcykge1xuICAgICAgICB2YXIgbiA9IGU7XG4gICAgICAgIHIuaW50ZXJhY3RhYmxlLm9wdGlvbnMucmVzaXplLnNxdWFyZSA/IChyLnJlc2l6ZUF4ZXMgPT09IFwieVwiID8gbi5kZWx0YS54ID0gbi5kZWx0YS55IDogbi5kZWx0YS55ID0gbi5kZWx0YS54LCBuLmF4ZXMgPSBcInh5XCIpIDogKG4uYXhlcyA9IHIucmVzaXplQXhlcywgci5yZXNpemVBeGVzID09PSBcInhcIiA/IG4uZGVsdGEueSA9IDAgOiByLnJlc2l6ZUF4ZXMgPT09IFwieVwiICYmIChuLmRlbHRhLnggPSAwKSk7XG4gICAgICB9XG4gICAgfVxuICAgIHZhciBoZSwgQ2UsIGRlID0geyBpZDogXCJhY3Rpb25zL3Jlc2l6ZVwiLCBiZWZvcmU6IFtcImFjdGlvbnMvZHJhZ1wiXSwgaW5zdGFsbDogZnVuY3Rpb24odCkge1xuICAgICAgdmFyIGUgPSB0LmFjdGlvbnMsIHIgPSB0LmJyb3dzZXIsIG4gPSB0LkludGVyYWN0YWJsZSwgbyA9IHQuZGVmYXVsdHM7XG4gICAgICBkZS5jdXJzb3JzID0gZnVuY3Rpb24obCkge1xuICAgICAgICByZXR1cm4gbC5pc0llOSA/IHsgeDogXCJlLXJlc2l6ZVwiLCB5OiBcInMtcmVzaXplXCIsIHh5OiBcInNlLXJlc2l6ZVwiLCB0b3A6IFwibi1yZXNpemVcIiwgbGVmdDogXCJ3LXJlc2l6ZVwiLCBib3R0b206IFwicy1yZXNpemVcIiwgcmlnaHQ6IFwiZS1yZXNpemVcIiwgdG9wbGVmdDogXCJzZS1yZXNpemVcIiwgYm90dG9tcmlnaHQ6IFwic2UtcmVzaXplXCIsIHRvcHJpZ2h0OiBcIm5lLXJlc2l6ZVwiLCBib3R0b21sZWZ0OiBcIm5lLXJlc2l6ZVwiIH0gOiB7IHg6IFwiZXctcmVzaXplXCIsIHk6IFwibnMtcmVzaXplXCIsIHh5OiBcIm53c2UtcmVzaXplXCIsIHRvcDogXCJucy1yZXNpemVcIiwgbGVmdDogXCJldy1yZXNpemVcIiwgYm90dG9tOiBcIm5zLXJlc2l6ZVwiLCByaWdodDogXCJldy1yZXNpemVcIiwgdG9wbGVmdDogXCJud3NlLXJlc2l6ZVwiLCBib3R0b21yaWdodDogXCJud3NlLXJlc2l6ZVwiLCB0b3ByaWdodDogXCJuZXN3LXJlc2l6ZVwiLCBib3R0b21sZWZ0OiBcIm5lc3ctcmVzaXplXCIgfTtcbiAgICAgIH0ociksIGRlLmRlZmF1bHRNYXJnaW4gPSByLnN1cHBvcnRzVG91Y2ggfHwgci5zdXBwb3J0c1BvaW50ZXJFdmVudCA/IDIwIDogMTAsIG4ucHJvdG90eXBlLnJlc2l6YWJsZSA9IGZ1bmN0aW9uKGwpIHtcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uKGMsIHAsIGgpIHtcbiAgICAgICAgICByZXR1cm4gdy5vYmplY3QocCkgPyAoYy5vcHRpb25zLnJlc2l6ZS5lbmFibGVkID0gcC5lbmFibGVkICE9PSAhMSwgYy5zZXRQZXJBY3Rpb24oXCJyZXNpemVcIiwgcCksIGMuc2V0T25FdmVudHMoXCJyZXNpemVcIiwgcCksIHcuc3RyaW5nKHAuYXhpcykgJiYgL154JHxeeSR8Xnh5JC8udGVzdChwLmF4aXMpID8gYy5vcHRpb25zLnJlc2l6ZS5heGlzID0gcC5heGlzIDogcC5heGlzID09PSBudWxsICYmIChjLm9wdGlvbnMucmVzaXplLmF4aXMgPSBoLmRlZmF1bHRzLmFjdGlvbnMucmVzaXplLmF4aXMpLCB3LmJvb2wocC5wcmVzZXJ2ZUFzcGVjdFJhdGlvKSA/IGMub3B0aW9ucy5yZXNpemUucHJlc2VydmVBc3BlY3RSYXRpbyA9IHAucHJlc2VydmVBc3BlY3RSYXRpbyA6IHcuYm9vbChwLnNxdWFyZSkgJiYgKGMub3B0aW9ucy5yZXNpemUuc3F1YXJlID0gcC5zcXVhcmUpLCBjKSA6IHcuYm9vbChwKSA/IChjLm9wdGlvbnMucmVzaXplLmVuYWJsZWQgPSBwLCBjKSA6IGMub3B0aW9ucy5yZXNpemU7XG4gICAgICAgIH0odGhpcywgbCwgdCk7XG4gICAgICB9LCBlLm1hcC5yZXNpemUgPSBkZSwgZS5tZXRob2REaWN0LnJlc2l6ZSA9IFwicmVzaXphYmxlXCIsIG8uYWN0aW9ucy5yZXNpemUgPSBkZS5kZWZhdWx0cztcbiAgICB9LCBsaXN0ZW5lcnM6IHsgXCJpbnRlcmFjdGlvbnM6bmV3XCI6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHQuaW50ZXJhY3Rpb24ucmVzaXplQXhlcyA9IFwieHlcIjtcbiAgICB9LCBcImludGVyYWN0aW9uczphY3Rpb24tc3RhcnRcIjogZnVuY3Rpb24odCkge1xuICAgICAgKGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgdmFyIHIgPSBlLmlFdmVudCwgbiA9IGUuaW50ZXJhY3Rpb247XG4gICAgICAgIGlmIChuLnByZXBhcmVkLm5hbWUgPT09IFwicmVzaXplXCIgJiYgbi5wcmVwYXJlZC5lZGdlcykge1xuICAgICAgICAgIHZhciBvID0gciwgbCA9IG4ucmVjdDtcbiAgICAgICAgICBuLl9yZWN0cyA9IHsgc3RhcnQ6IFcoe30sIGwpLCBjb3JyZWN0ZWQ6IFcoe30sIGwpLCBwcmV2aW91czogVyh7fSwgbCksIGRlbHRhOiB7IGxlZnQ6IDAsIHJpZ2h0OiAwLCB3aWR0aDogMCwgdG9wOiAwLCBib3R0b206IDAsIGhlaWdodDogMCB9IH0sIG8uZWRnZXMgPSBuLnByZXBhcmVkLmVkZ2VzLCBvLnJlY3QgPSBuLl9yZWN0cy5jb3JyZWN0ZWQsIG8uZGVsdGFSZWN0ID0gbi5fcmVjdHMuZGVsdGE7XG4gICAgICAgIH1cbiAgICAgIH0pKHQpLCBsbih0KTtcbiAgICB9LCBcImludGVyYWN0aW9uczphY3Rpb24tbW92ZVwiOiBmdW5jdGlvbih0KSB7XG4gICAgICAoZnVuY3Rpb24oZSkge1xuICAgICAgICB2YXIgciA9IGUuaUV2ZW50LCBuID0gZS5pbnRlcmFjdGlvbjtcbiAgICAgICAgaWYgKG4ucHJlcGFyZWQubmFtZSA9PT0gXCJyZXNpemVcIiAmJiBuLnByZXBhcmVkLmVkZ2VzKSB7XG4gICAgICAgICAgdmFyIG8gPSByLCBsID0gbi5pbnRlcmFjdGFibGUub3B0aW9ucy5yZXNpemUuaW52ZXJ0LCBjID0gbCA9PT0gXCJyZXBvc2l0aW9uXCIgfHwgbCA9PT0gXCJuZWdhdGVcIiwgcCA9IG4ucmVjdCwgaCA9IG4uX3JlY3RzLCBnID0gaC5zdGFydCwgZCA9IGguY29ycmVjdGVkLCBiID0gaC5kZWx0YSwgeCA9IGgucHJldmlvdXM7XG4gICAgICAgICAgaWYgKFcoeCwgZCksIGMpIHtcbiAgICAgICAgICAgIGlmIChXKGQsIHApLCBsID09PSBcInJlcG9zaXRpb25cIikge1xuICAgICAgICAgICAgICBpZiAoZC50b3AgPiBkLmJvdHRvbSkge1xuICAgICAgICAgICAgICAgIHZhciBJID0gZC50b3A7XG4gICAgICAgICAgICAgICAgZC50b3AgPSBkLmJvdHRvbSwgZC5ib3R0b20gPSBJO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGlmIChkLmxlZnQgPiBkLnJpZ2h0KSB7XG4gICAgICAgICAgICAgICAgdmFyIEUgPSBkLmxlZnQ7XG4gICAgICAgICAgICAgICAgZC5sZWZ0ID0gZC5yaWdodCwgZC5yaWdodCA9IEU7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGVsc2UgZC50b3AgPSBNYXRoLm1pbihwLnRvcCwgZy5ib3R0b20pLCBkLmJvdHRvbSA9IE1hdGgubWF4KHAuYm90dG9tLCBnLnRvcCksIGQubGVmdCA9IE1hdGgubWluKHAubGVmdCwgZy5yaWdodCksIGQucmlnaHQgPSBNYXRoLm1heChwLnJpZ2h0LCBnLmxlZnQpO1xuICAgICAgICAgIGZvciAodmFyIE0gaW4gZC53aWR0aCA9IGQucmlnaHQgLSBkLmxlZnQsIGQuaGVpZ2h0ID0gZC5ib3R0b20gLSBkLnRvcCwgZCkgYltNXSA9IGRbTV0gLSB4W01dO1xuICAgICAgICAgIG8uZWRnZXMgPSBuLnByZXBhcmVkLmVkZ2VzLCBvLnJlY3QgPSBkLCBvLmRlbHRhUmVjdCA9IGI7XG4gICAgICAgIH1cbiAgICAgIH0pKHQpLCBsbih0KTtcbiAgICB9LCBcImludGVyYWN0aW9uczphY3Rpb24tZW5kXCI6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHZhciBlID0gdC5pRXZlbnQsIHIgPSB0LmludGVyYWN0aW9uO1xuICAgICAgaWYgKHIucHJlcGFyZWQubmFtZSA9PT0gXCJyZXNpemVcIiAmJiByLnByZXBhcmVkLmVkZ2VzKSB7XG4gICAgICAgIHZhciBuID0gZTtcbiAgICAgICAgbi5lZGdlcyA9IHIucHJlcGFyZWQuZWRnZXMsIG4ucmVjdCA9IHIuX3JlY3RzLmNvcnJlY3RlZCwgbi5kZWx0YVJlY3QgPSByLl9yZWN0cy5kZWx0YTtcbiAgICAgIH1cbiAgICB9LCBcImF1dG8tc3RhcnQ6Y2hlY2tcIjogZnVuY3Rpb24odCkge1xuICAgICAgdmFyIGUgPSB0LmludGVyYWN0aW9uLCByID0gdC5pbnRlcmFjdGFibGUsIG4gPSB0LmVsZW1lbnQsIG8gPSB0LnJlY3QsIGwgPSB0LmJ1dHRvbnM7XG4gICAgICBpZiAobykge1xuICAgICAgICB2YXIgYyA9IFcoe30sIGUuY29vcmRzLmN1ci5wYWdlKSwgcCA9IHIub3B0aW9ucy5yZXNpemU7XG4gICAgICAgIGlmIChwICYmIHAuZW5hYmxlZCAmJiAoIWUucG9pbnRlcklzRG93biB8fCAhL21vdXNlfHBvaW50ZXIvLnRlc3QoZS5wb2ludGVyVHlwZSkgfHwgbCAmIHAubW91c2VCdXR0b25zKSkge1xuICAgICAgICAgIGlmICh3Lm9iamVjdChwLmVkZ2VzKSkge1xuICAgICAgICAgICAgdmFyIGggPSB7IGxlZnQ6ICExLCByaWdodDogITEsIHRvcDogITEsIGJvdHRvbTogITEgfTtcbiAgICAgICAgICAgIGZvciAodmFyIGcgaW4gaCkgaFtnXSA9IHVvKGcsIHAuZWRnZXNbZ10sIGMsIGUuX2xhdGVzdFBvaW50ZXIuZXZlbnRUYXJnZXQsIG4sIG8sIHAubWFyZ2luIHx8IGRlLmRlZmF1bHRNYXJnaW4pO1xuICAgICAgICAgICAgaC5sZWZ0ID0gaC5sZWZ0ICYmICFoLnJpZ2h0LCBoLnRvcCA9IGgudG9wICYmICFoLmJvdHRvbSwgKGgubGVmdCB8fCBoLnJpZ2h0IHx8IGgudG9wIHx8IGguYm90dG9tKSAmJiAodC5hY3Rpb24gPSB7IG5hbWU6IFwicmVzaXplXCIsIGVkZ2VzOiBoIH0pO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB2YXIgZCA9IHAuYXhpcyAhPT0gXCJ5XCIgJiYgYy54ID4gby5yaWdodCAtIGRlLmRlZmF1bHRNYXJnaW4sIGIgPSBwLmF4aXMgIT09IFwieFwiICYmIGMueSA+IG8uYm90dG9tIC0gZGUuZGVmYXVsdE1hcmdpbjtcbiAgICAgICAgICAgIChkIHx8IGIpICYmICh0LmFjdGlvbiA9IHsgbmFtZTogXCJyZXNpemVcIiwgYXhlczogKGQgPyBcInhcIiA6IFwiXCIpICsgKGIgPyBcInlcIiA6IFwiXCIpIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gIXQuYWN0aW9uICYmIHZvaWQgMDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gfSwgZGVmYXVsdHM6IHsgc3F1YXJlOiAhMSwgcHJlc2VydmVBc3BlY3RSYXRpbzogITEsIGF4aXM6IFwieHlcIiwgbWFyZ2luOiBOYU4sIGVkZ2VzOiBudWxsLCBpbnZlcnQ6IFwibm9uZVwiIH0sIGN1cnNvcnM6IG51bGwsIGdldEN1cnNvcjogZnVuY3Rpb24odCkge1xuICAgICAgdmFyIGUgPSB0LmVkZ2VzLCByID0gdC5heGlzLCBuID0gdC5uYW1lLCBvID0gZGUuY3Vyc29ycywgbCA9IG51bGw7XG4gICAgICBpZiAocikgbCA9IG9bbiArIHJdO1xuICAgICAgZWxzZSBpZiAoZSkge1xuICAgICAgICBmb3IgKHZhciBjID0gXCJcIiwgcCA9IDAsIGggPSBbXCJ0b3BcIiwgXCJib3R0b21cIiwgXCJsZWZ0XCIsIFwicmlnaHRcIl07IHAgPCBoLmxlbmd0aDsgcCsrKSB7XG4gICAgICAgICAgdmFyIGcgPSBoW3BdO1xuICAgICAgICAgIGVbZ10gJiYgKGMgKz0gZyk7XG4gICAgICAgIH1cbiAgICAgICAgbCA9IG9bY107XG4gICAgICB9XG4gICAgICByZXR1cm4gbDtcbiAgICB9LCBmaWx0ZXJFdmVudFR5cGU6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHJldHVybiB0LnNlYXJjaChcInJlc2l6ZVwiKSA9PT0gMDtcbiAgICB9LCBkZWZhdWx0TWFyZ2luOiBudWxsIH0sIHBvID0gZGUsIGhvID0geyBpZDogXCJhY3Rpb25zXCIsIGluc3RhbGw6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHQudXNlUGx1Z2luKGNvKSwgdC51c2VQbHVnaW4ocG8pLCB0LnVzZVBsdWdpbihGciksIHQudXNlUGx1Z2luKGxvKTtcbiAgICB9IH0sIGNuID0gMCwgYmUgPSB7IHJlcXVlc3Q6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHJldHVybiBoZSh0KTtcbiAgICB9LCBjYW5jZWw6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHJldHVybiBDZSh0KTtcbiAgICB9LCBpbml0OiBmdW5jdGlvbih0KSB7XG4gICAgICBpZiAoaGUgPSB0LnJlcXVlc3RBbmltYXRpb25GcmFtZSwgQ2UgPSB0LmNhbmNlbEFuaW1hdGlvbkZyYW1lLCAhaGUpIGZvciAodmFyIGUgPSBbXCJtc1wiLCBcIm1velwiLCBcIndlYmtpdFwiLCBcIm9cIl0sIHIgPSAwOyByIDwgZS5sZW5ndGg7IHIrKykge1xuICAgICAgICB2YXIgbiA9IGVbcl07XG4gICAgICAgIGhlID0gdFtcIlwiLmNvbmNhdChuLCBcIlJlcXVlc3RBbmltYXRpb25GcmFtZVwiKV0sIENlID0gdFtcIlwiLmNvbmNhdChuLCBcIkNhbmNlbEFuaW1hdGlvbkZyYW1lXCIpXSB8fCB0W1wiXCIuY29uY2F0KG4sIFwiQ2FuY2VsUmVxdWVzdEFuaW1hdGlvbkZyYW1lXCIpXTtcbiAgICAgIH1cbiAgICAgIGhlID0gaGUgJiYgaGUuYmluZCh0KSwgQ2UgPSBDZSAmJiBDZS5iaW5kKHQpLCBoZSB8fCAoaGUgPSBmdW5jdGlvbihvKSB7XG4gICAgICAgIHZhciBsID0gRGF0ZS5ub3coKSwgYyA9IE1hdGgubWF4KDAsIDE2IC0gKGwgLSBjbikpLCBwID0gdC5zZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xuICAgICAgICAgIG8obCArIGMpO1xuICAgICAgICB9LCBjKTtcbiAgICAgICAgcmV0dXJuIGNuID0gbCArIGMsIHA7XG4gICAgICB9LCBDZSA9IGZ1bmN0aW9uKG8pIHtcbiAgICAgICAgcmV0dXJuIGNsZWFyVGltZW91dChvKTtcbiAgICAgIH0pO1xuICAgIH0gfSwgVSA9IHsgZGVmYXVsdHM6IHsgZW5hYmxlZDogITEsIG1hcmdpbjogNjAsIGNvbnRhaW5lcjogbnVsbCwgc3BlZWQ6IDMwMCB9LCBub3c6IERhdGUubm93LCBpbnRlcmFjdGlvbjogbnVsbCwgaTogMCwgeDogMCwgeTogMCwgaXNTY3JvbGxpbmc6ICExLCBwcmV2VGltZTogMCwgbWFyZ2luOiAwLCBzcGVlZDogMCwgc3RhcnQ6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIFUuaXNTY3JvbGxpbmcgPSAhMCwgYmUuY2FuY2VsKFUuaSksIHQuYXV0b1Njcm9sbCA9IFUsIFUuaW50ZXJhY3Rpb24gPSB0LCBVLnByZXZUaW1lID0gVS5ub3coKSwgVS5pID0gYmUucmVxdWVzdChVLnNjcm9sbCk7XG4gICAgfSwgc3RvcDogZnVuY3Rpb24oKSB7XG4gICAgICBVLmlzU2Nyb2xsaW5nID0gITEsIFUuaW50ZXJhY3Rpb24gJiYgKFUuaW50ZXJhY3Rpb24uYXV0b1Njcm9sbCA9IG51bGwpLCBiZS5jYW5jZWwoVS5pKTtcbiAgICB9LCBzY3JvbGw6IGZ1bmN0aW9uKCkge1xuICAgICAgdmFyIHQgPSBVLmludGVyYWN0aW9uLCBlID0gdC5pbnRlcmFjdGFibGUsIHIgPSB0LmVsZW1lbnQsIG4gPSB0LnByZXBhcmVkLm5hbWUsIG8gPSBlLm9wdGlvbnNbbl0uYXV0b1Njcm9sbCwgbCA9IHVuKG8uY29udGFpbmVyLCBlLCByKSwgYyA9IFUubm93KCksIHAgPSAoYyAtIFUucHJldlRpbWUpIC8gMWUzLCBoID0gby5zcGVlZCAqIHA7XG4gICAgICBpZiAoaCA+PSAxKSB7XG4gICAgICAgIHZhciBnID0geyB4OiBVLnggKiBoLCB5OiBVLnkgKiBoIH07XG4gICAgICAgIGlmIChnLnggfHwgZy55KSB7XG4gICAgICAgICAgdmFyIGQgPSBwbihsKTtcbiAgICAgICAgICB3LndpbmRvdyhsKSA/IGwuc2Nyb2xsQnkoZy54LCBnLnkpIDogbCAmJiAobC5zY3JvbGxMZWZ0ICs9IGcueCwgbC5zY3JvbGxUb3AgKz0gZy55KTtcbiAgICAgICAgICB2YXIgYiA9IHBuKGwpLCB4ID0geyB4OiBiLnggLSBkLngsIHk6IGIueSAtIGQueSB9O1xuICAgICAgICAgICh4LnggfHwgeC55KSAmJiBlLmZpcmUoeyB0eXBlOiBcImF1dG9zY3JvbGxcIiwgdGFyZ2V0OiByLCBpbnRlcmFjdGFibGU6IGUsIGRlbHRhOiB4LCBpbnRlcmFjdGlvbjogdCwgY29udGFpbmVyOiBsIH0pO1xuICAgICAgICB9XG4gICAgICAgIFUucHJldlRpbWUgPSBjO1xuICAgICAgfVxuICAgICAgVS5pc1Njcm9sbGluZyAmJiAoYmUuY2FuY2VsKFUuaSksIFUuaSA9IGJlLnJlcXVlc3QoVS5zY3JvbGwpKTtcbiAgICB9LCBjaGVjazogZnVuY3Rpb24odCwgZSkge1xuICAgICAgdmFyIHI7XG4gICAgICByZXR1cm4gKHIgPSB0Lm9wdGlvbnNbZV0uYXV0b1Njcm9sbCkgPT0gbnVsbCA/IHZvaWQgMCA6IHIuZW5hYmxlZDtcbiAgICB9LCBvbkludGVyYWN0aW9uTW92ZTogZnVuY3Rpb24odCkge1xuICAgICAgdmFyIGUgPSB0LmludGVyYWN0aW9uLCByID0gdC5wb2ludGVyO1xuICAgICAgaWYgKGUuaW50ZXJhY3RpbmcoKSAmJiBVLmNoZWNrKGUuaW50ZXJhY3RhYmxlLCBlLnByZXBhcmVkLm5hbWUpKSBpZiAoZS5zaW11bGF0aW9uKSBVLnggPSBVLnkgPSAwO1xuICAgICAgZWxzZSB7XG4gICAgICAgIHZhciBuLCBvLCBsLCBjLCBwID0gZS5pbnRlcmFjdGFibGUsIGggPSBlLmVsZW1lbnQsIGcgPSBlLnByZXBhcmVkLm5hbWUsIGQgPSBwLm9wdGlvbnNbZ10uYXV0b1Njcm9sbCwgYiA9IHVuKGQuY29udGFpbmVyLCBwLCBoKTtcbiAgICAgICAgaWYgKHcud2luZG93KGIpKSBjID0gci5jbGllbnRYIDwgVS5tYXJnaW4sIG4gPSByLmNsaWVudFkgPCBVLm1hcmdpbiwgbyA9IHIuY2xpZW50WCA+IGIuaW5uZXJXaWR0aCAtIFUubWFyZ2luLCBsID0gci5jbGllbnRZID4gYi5pbm5lckhlaWdodCAtIFUubWFyZ2luO1xuICAgICAgICBlbHNlIHtcbiAgICAgICAgICB2YXIgeCA9IFV0KGIpO1xuICAgICAgICAgIGMgPSByLmNsaWVudFggPCB4LmxlZnQgKyBVLm1hcmdpbiwgbiA9IHIuY2xpZW50WSA8IHgudG9wICsgVS5tYXJnaW4sIG8gPSByLmNsaWVudFggPiB4LnJpZ2h0IC0gVS5tYXJnaW4sIGwgPSByLmNsaWVudFkgPiB4LmJvdHRvbSAtIFUubWFyZ2luO1xuICAgICAgICB9XG4gICAgICAgIFUueCA9IG8gPyAxIDogYyA/IC0xIDogMCwgVS55ID0gbCA/IDEgOiBuID8gLTEgOiAwLCBVLmlzU2Nyb2xsaW5nIHx8IChVLm1hcmdpbiA9IGQubWFyZ2luLCBVLnNwZWVkID0gZC5zcGVlZCwgVS5zdGFydChlKSk7XG4gICAgICB9XG4gICAgfSB9O1xuICAgIGZ1bmN0aW9uIHVuKHQsIGUsIHIpIHtcbiAgICAgIHJldHVybiAody5zdHJpbmcodCkgPyBYcih0LCBlLCByKSA6IHQpIHx8IEIocik7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHBuKHQpIHtcbiAgICAgIHJldHVybiB3LndpbmRvdyh0KSAmJiAodCA9IHdpbmRvdy5kb2N1bWVudC5ib2R5KSwgeyB4OiB0LnNjcm9sbExlZnQsIHk6IHQuc2Nyb2xsVG9wIH07XG4gICAgfVxuICAgIHZhciBmbyA9IHsgaWQ6IFwiYXV0by1zY3JvbGxcIiwgaW5zdGFsbDogZnVuY3Rpb24odCkge1xuICAgICAgdmFyIGUgPSB0LmRlZmF1bHRzLCByID0gdC5hY3Rpb25zO1xuICAgICAgdC5hdXRvU2Nyb2xsID0gVSwgVS5ub3cgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIHQubm93KCk7XG4gICAgICB9LCByLnBoYXNlbGVzc1R5cGVzLmF1dG9zY3JvbGwgPSAhMCwgZS5wZXJBY3Rpb24uYXV0b1Njcm9sbCA9IFUuZGVmYXVsdHM7XG4gICAgfSwgbGlzdGVuZXJzOiB7IFwiaW50ZXJhY3Rpb25zOm5ld1wiOiBmdW5jdGlvbih0KSB7XG4gICAgICB0LmludGVyYWN0aW9uLmF1dG9TY3JvbGwgPSBudWxsO1xuICAgIH0sIFwiaW50ZXJhY3Rpb25zOmRlc3Ryb3lcIjogZnVuY3Rpb24odCkge1xuICAgICAgdC5pbnRlcmFjdGlvbi5hdXRvU2Nyb2xsID0gbnVsbCwgVS5zdG9wKCksIFUuaW50ZXJhY3Rpb24gJiYgKFUuaW50ZXJhY3Rpb24gPSBudWxsKTtcbiAgICB9LCBcImludGVyYWN0aW9uczpzdG9wXCI6IFUuc3RvcCwgXCJpbnRlcmFjdGlvbnM6YWN0aW9uLW1vdmVcIjogZnVuY3Rpb24odCkge1xuICAgICAgcmV0dXJuIFUub25JbnRlcmFjdGlvbk1vdmUodCk7XG4gICAgfSB9IH0sIHZvID0gZm87XG4gICAgZnVuY3Rpb24gQmUodCwgZSkge1xuICAgICAgdmFyIHIgPSAhMTtcbiAgICAgIHJldHVybiBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIHIgfHwgKEguY29uc29sZS53YXJuKGUpLCByID0gITApLCB0LmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgICB9O1xuICAgIH1cbiAgICBmdW5jdGlvbiBlcih0LCBlKSB7XG4gICAgICByZXR1cm4gdC5uYW1lID0gZS5uYW1lLCB0LmF4aXMgPSBlLmF4aXMsIHQuZWRnZXMgPSBlLmVkZ2VzLCB0O1xuICAgIH1cbiAgICBmdW5jdGlvbiBnbyh0KSB7XG4gICAgICByZXR1cm4gdy5ib29sKHQpID8gKHRoaXMub3B0aW9ucy5zdHlsZUN1cnNvciA9IHQsIHRoaXMpIDogdCA9PT0gbnVsbCA/IChkZWxldGUgdGhpcy5vcHRpb25zLnN0eWxlQ3Vyc29yLCB0aGlzKSA6IHRoaXMub3B0aW9ucy5zdHlsZUN1cnNvcjtcbiAgICB9XG4gICAgZnVuY3Rpb24gbW8odCkge1xuICAgICAgcmV0dXJuIHcuZnVuYyh0KSA/ICh0aGlzLm9wdGlvbnMuYWN0aW9uQ2hlY2tlciA9IHQsIHRoaXMpIDogdCA9PT0gbnVsbCA/IChkZWxldGUgdGhpcy5vcHRpb25zLmFjdGlvbkNoZWNrZXIsIHRoaXMpIDogdGhpcy5vcHRpb25zLmFjdGlvbkNoZWNrZXI7XG4gICAgfVxuICAgIHZhciBibyA9IHsgaWQ6IFwiYXV0by1zdGFydC9pbnRlcmFjdGFibGVNZXRob2RzXCIsIGluc3RhbGw6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHZhciBlID0gdC5JbnRlcmFjdGFibGU7XG4gICAgICBlLnByb3RvdHlwZS5nZXRBY3Rpb24gPSBmdW5jdGlvbihyLCBuLCBvLCBsKSB7XG4gICAgICAgIHZhciBjID0gZnVuY3Rpb24ocCwgaCwgZywgZCwgYikge1xuICAgICAgICAgIHZhciB4ID0gcC5nZXRSZWN0KGQpLCBJID0gaC5idXR0b25zIHx8IHsgMDogMSwgMTogNCwgMzogOCwgNDogMTYgfVtoLmJ1dHRvbl0sIEUgPSB7IGFjdGlvbjogbnVsbCwgaW50ZXJhY3RhYmxlOiBwLCBpbnRlcmFjdGlvbjogZywgZWxlbWVudDogZCwgcmVjdDogeCwgYnV0dG9uczogSSB9O1xuICAgICAgICAgIHJldHVybiBiLmZpcmUoXCJhdXRvLXN0YXJ0OmNoZWNrXCIsIEUpLCBFLmFjdGlvbjtcbiAgICAgICAgfSh0aGlzLCBuLCBvLCBsLCB0KTtcbiAgICAgICAgcmV0dXJuIHRoaXMub3B0aW9ucy5hY3Rpb25DaGVja2VyID8gdGhpcy5vcHRpb25zLmFjdGlvbkNoZWNrZXIociwgbiwgYywgdGhpcywgbCwgbykgOiBjO1xuICAgICAgfSwgZS5wcm90b3R5cGUuaWdub3JlRnJvbSA9IEJlKGZ1bmN0aW9uKHIpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2JhY2tDb21wYXRPcHRpb24oXCJpZ25vcmVGcm9tXCIsIHIpO1xuICAgICAgfSwgXCJJbnRlcmFjdGFibGUuaWdub3JlRnJvbSgpIGhhcyBiZWVuIGRlcHJlY2F0ZWQuIFVzZSBJbnRlcmFjdGJsZS5kcmFnZ2FibGUoe2lnbm9yZUZyb206IG5ld1ZhbHVlfSkuXCIpLCBlLnByb3RvdHlwZS5hbGxvd0Zyb20gPSBCZShmdW5jdGlvbihyKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9iYWNrQ29tcGF0T3B0aW9uKFwiYWxsb3dGcm9tXCIsIHIpO1xuICAgICAgfSwgXCJJbnRlcmFjdGFibGUuYWxsb3dGcm9tKCkgaGFzIGJlZW4gZGVwcmVjYXRlZC4gVXNlIEludGVyYWN0YmxlLmRyYWdnYWJsZSh7YWxsb3dGcm9tOiBuZXdWYWx1ZX0pLlwiKSwgZS5wcm90b3R5cGUuYWN0aW9uQ2hlY2tlciA9IG1vLCBlLnByb3RvdHlwZS5zdHlsZUN1cnNvciA9IGdvO1xuICAgIH0gfTtcbiAgICBmdW5jdGlvbiBobih0LCBlLCByLCBuLCBvKSB7XG4gICAgICByZXR1cm4gZS50ZXN0SWdub3JlQWxsb3coZS5vcHRpb25zW3QubmFtZV0sIHIsIG4pICYmIGUub3B0aW9uc1t0Lm5hbWVdLmVuYWJsZWQgJiYgdXQoZSwgciwgdCwgbykgPyB0IDogbnVsbDtcbiAgICB9XG4gICAgZnVuY3Rpb24geW8odCwgZSwgciwgbiwgbywgbCwgYykge1xuICAgICAgZm9yICh2YXIgcCA9IDAsIGggPSBuLmxlbmd0aDsgcCA8IGg7IHArKykge1xuICAgICAgICB2YXIgZyA9IG5bcF0sIGQgPSBvW3BdLCBiID0gZy5nZXRBY3Rpb24oZSwgciwgdCwgZCk7XG4gICAgICAgIGlmIChiKSB7XG4gICAgICAgICAgdmFyIHggPSBobihiLCBnLCBkLCBsLCBjKTtcbiAgICAgICAgICBpZiAoeCkgcmV0dXJuIHsgYWN0aW9uOiB4LCBpbnRlcmFjdGFibGU6IGcsIGVsZW1lbnQ6IGQgfTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHsgYWN0aW9uOiBudWxsLCBpbnRlcmFjdGFibGU6IG51bGwsIGVsZW1lbnQ6IG51bGwgfTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZG4odCwgZSwgciwgbiwgbykge1xuICAgICAgdmFyIGwgPSBbXSwgYyA9IFtdLCBwID0gbjtcbiAgICAgIGZ1bmN0aW9uIGgoZCkge1xuICAgICAgICBsLnB1c2goZCksIGMucHVzaChwKTtcbiAgICAgIH1cbiAgICAgIGZvciAoOyB3LmVsZW1lbnQocCk7ICkge1xuICAgICAgICBsID0gW10sIGMgPSBbXSwgby5pbnRlcmFjdGFibGVzLmZvckVhY2hNYXRjaChwLCBoKTtcbiAgICAgICAgdmFyIGcgPSB5byh0LCBlLCByLCBsLCBjLCBuLCBvKTtcbiAgICAgICAgaWYgKGcuYWN0aW9uICYmICFnLmludGVyYWN0YWJsZS5vcHRpb25zW2cuYWN0aW9uLm5hbWVdLm1hbnVhbFN0YXJ0KSByZXR1cm4gZztcbiAgICAgICAgcCA9IHBlKHApO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHsgYWN0aW9uOiBudWxsLCBpbnRlcmFjdGFibGU6IG51bGwsIGVsZW1lbnQ6IG51bGwgfTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZm4odCwgZSwgcikge1xuICAgICAgdmFyIG4gPSBlLmFjdGlvbiwgbyA9IGUuaW50ZXJhY3RhYmxlLCBsID0gZS5lbGVtZW50O1xuICAgICAgbiA9IG4gfHwgeyBuYW1lOiBudWxsIH0sIHQuaW50ZXJhY3RhYmxlID0gbywgdC5lbGVtZW50ID0gbCwgZXIodC5wcmVwYXJlZCwgbiksIHQucmVjdCA9IG8gJiYgbi5uYW1lID8gby5nZXRSZWN0KGwpIDogbnVsbCwgZ24odCwgciksIHIuZmlyZShcImF1dG9TdGFydDpwcmVwYXJlZFwiLCB7IGludGVyYWN0aW9uOiB0IH0pO1xuICAgIH1cbiAgICBmdW5jdGlvbiB1dCh0LCBlLCByLCBuKSB7XG4gICAgICB2YXIgbyA9IHQub3B0aW9ucywgbCA9IG9bci5uYW1lXS5tYXgsIGMgPSBvW3IubmFtZV0ubWF4UGVyRWxlbWVudCwgcCA9IG4uYXV0b1N0YXJ0Lm1heEludGVyYWN0aW9ucywgaCA9IDAsIGcgPSAwLCBkID0gMDtcbiAgICAgIGlmICghKGwgJiYgYyAmJiBwKSkgcmV0dXJuICExO1xuICAgICAgZm9yICh2YXIgYiA9IDAsIHggPSBuLmludGVyYWN0aW9ucy5saXN0OyBiIDwgeC5sZW5ndGg7IGIrKykge1xuICAgICAgICB2YXIgSSA9IHhbYl0sIEUgPSBJLnByZXBhcmVkLm5hbWU7XG4gICAgICAgIGlmIChJLmludGVyYWN0aW5nKCkgJiYgKCsraCA+PSBwIHx8IEkuaW50ZXJhY3RhYmxlID09PSB0ICYmICgoZyArPSBFID09PSByLm5hbWUgPyAxIDogMCkgPj0gbCB8fCBJLmVsZW1lbnQgPT09IGUgJiYgKGQrKywgRSA9PT0gci5uYW1lICYmIGQgPj0gYykpKSlcbiAgICAgICAgICByZXR1cm4gITE7XG4gICAgICB9XG4gICAgICByZXR1cm4gcCA+IDA7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHZuKHQsIGUpIHtcbiAgICAgIHJldHVybiB3Lm51bWJlcih0KSA/IChlLmF1dG9TdGFydC5tYXhJbnRlcmFjdGlvbnMgPSB0LCB0aGlzKSA6IGUuYXV0b1N0YXJ0Lm1heEludGVyYWN0aW9ucztcbiAgICB9XG4gICAgZnVuY3Rpb24gdHIodCwgZSwgcikge1xuICAgICAgdmFyIG4gPSByLmF1dG9TdGFydC5jdXJzb3JFbGVtZW50O1xuICAgICAgbiAmJiBuICE9PSB0ICYmIChuLnN0eWxlLmN1cnNvciA9IFwiXCIpLCB0Lm93bmVyRG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnN0eWxlLmN1cnNvciA9IGUsIHQuc3R5bGUuY3Vyc29yID0gZSwgci5hdXRvU3RhcnQuY3Vyc29yRWxlbWVudCA9IGUgPyB0IDogbnVsbDtcbiAgICB9XG4gICAgZnVuY3Rpb24gZ24odCwgZSkge1xuICAgICAgdmFyIHIgPSB0LmludGVyYWN0YWJsZSwgbiA9IHQuZWxlbWVudCwgbyA9IHQucHJlcGFyZWQ7XG4gICAgICBpZiAodC5wb2ludGVyVHlwZSA9PT0gXCJtb3VzZVwiICYmIHIgJiYgci5vcHRpb25zLnN0eWxlQ3Vyc29yKSB7XG4gICAgICAgIHZhciBsID0gXCJcIjtcbiAgICAgICAgaWYgKG8ubmFtZSkge1xuICAgICAgICAgIHZhciBjID0gci5vcHRpb25zW28ubmFtZV0uY3Vyc29yQ2hlY2tlcjtcbiAgICAgICAgICBsID0gdy5mdW5jKGMpID8gYyhvLCByLCBuLCB0Ll9pbnRlcmFjdGluZykgOiBlLmFjdGlvbnMubWFwW28ubmFtZV0uZ2V0Q3Vyc29yKG8pO1xuICAgICAgICB9XG4gICAgICAgIHRyKHQuZWxlbWVudCwgbCB8fCBcIlwiLCBlKTtcbiAgICAgIH0gZWxzZSBlLmF1dG9TdGFydC5jdXJzb3JFbGVtZW50ICYmIHRyKGUuYXV0b1N0YXJ0LmN1cnNvckVsZW1lbnQsIFwiXCIsIGUpO1xuICAgIH1cbiAgICB2YXIgVG8gPSB7IGlkOiBcImF1dG8tc3RhcnQvYmFzZVwiLCBiZWZvcmU6IFtcImFjdGlvbnNcIl0sIGluc3RhbGw6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHZhciBlID0gdC5pbnRlcmFjdFN0YXRpYywgciA9IHQuZGVmYXVsdHM7XG4gICAgICB0LnVzZVBsdWdpbihibyksIHIuYmFzZS5hY3Rpb25DaGVja2VyID0gbnVsbCwgci5iYXNlLnN0eWxlQ3Vyc29yID0gITAsIFcoci5wZXJBY3Rpb24sIHsgbWFudWFsU3RhcnQ6ICExLCBtYXg6IDEgLyAwLCBtYXhQZXJFbGVtZW50OiAxLCBhbGxvd0Zyb206IG51bGwsIGlnbm9yZUZyb206IG51bGwsIG1vdXNlQnV0dG9uczogMSB9KSwgZS5tYXhJbnRlcmFjdGlvbnMgPSBmdW5jdGlvbihuKSB7XG4gICAgICAgIHJldHVybiB2bihuLCB0KTtcbiAgICAgIH0sIHQuYXV0b1N0YXJ0ID0geyBtYXhJbnRlcmFjdGlvbnM6IDEgLyAwLCB3aXRoaW5JbnRlcmFjdGlvbkxpbWl0OiB1dCwgY3Vyc29yRWxlbWVudDogbnVsbCB9O1xuICAgIH0sIGxpc3RlbmVyczogeyBcImludGVyYWN0aW9uczpkb3duXCI6IGZ1bmN0aW9uKHQsIGUpIHtcbiAgICAgIHZhciByID0gdC5pbnRlcmFjdGlvbiwgbiA9IHQucG9pbnRlciwgbyA9IHQuZXZlbnQsIGwgPSB0LmV2ZW50VGFyZ2V0O1xuICAgICAgci5pbnRlcmFjdGluZygpIHx8IGZuKHIsIGRuKHIsIG4sIG8sIGwsIGUpLCBlKTtcbiAgICB9LCBcImludGVyYWN0aW9uczptb3ZlXCI6IGZ1bmN0aW9uKHQsIGUpIHtcbiAgICAgIChmdW5jdGlvbihyLCBuKSB7XG4gICAgICAgIHZhciBvID0gci5pbnRlcmFjdGlvbiwgbCA9IHIucG9pbnRlciwgYyA9IHIuZXZlbnQsIHAgPSByLmV2ZW50VGFyZ2V0O1xuICAgICAgICBvLnBvaW50ZXJUeXBlICE9PSBcIm1vdXNlXCIgfHwgby5wb2ludGVySXNEb3duIHx8IG8uaW50ZXJhY3RpbmcoKSB8fCBmbihvLCBkbihvLCBsLCBjLCBwLCBuKSwgbik7XG4gICAgICB9KSh0LCBlKSwgZnVuY3Rpb24ociwgbikge1xuICAgICAgICB2YXIgbyA9IHIuaW50ZXJhY3Rpb247XG4gICAgICAgIGlmIChvLnBvaW50ZXJJc0Rvd24gJiYgIW8uaW50ZXJhY3RpbmcoKSAmJiBvLnBvaW50ZXJXYXNNb3ZlZCAmJiBvLnByZXBhcmVkLm5hbWUpIHtcbiAgICAgICAgICBuLmZpcmUoXCJhdXRvU3RhcnQ6YmVmb3JlLXN0YXJ0XCIsIHIpO1xuICAgICAgICAgIHZhciBsID0gby5pbnRlcmFjdGFibGUsIGMgPSBvLnByZXBhcmVkLm5hbWU7XG4gICAgICAgICAgYyAmJiBsICYmIChsLm9wdGlvbnNbY10ubWFudWFsU3RhcnQgfHwgIXV0KGwsIG8uZWxlbWVudCwgby5wcmVwYXJlZCwgbikgPyBvLnN0b3AoKSA6IChvLnN0YXJ0KG8ucHJlcGFyZWQsIGwsIG8uZWxlbWVudCksIGduKG8sIG4pKSk7XG4gICAgICAgIH1cbiAgICAgIH0odCwgZSk7XG4gICAgfSwgXCJpbnRlcmFjdGlvbnM6c3RvcFwiOiBmdW5jdGlvbih0LCBlKSB7XG4gICAgICB2YXIgciA9IHQuaW50ZXJhY3Rpb24sIG4gPSByLmludGVyYWN0YWJsZTtcbiAgICAgIG4gJiYgbi5vcHRpb25zLnN0eWxlQ3Vyc29yICYmIHRyKHIuZWxlbWVudCwgXCJcIiwgZSk7XG4gICAgfSB9LCBtYXhJbnRlcmFjdGlvbnM6IHZuLCB3aXRoaW5JbnRlcmFjdGlvbkxpbWl0OiB1dCwgdmFsaWRhdGVBY3Rpb246IGhuIH0sIHJyID0gVG8sIHdvID0geyBpZDogXCJhdXRvLXN0YXJ0L2RyYWdBeGlzXCIsIGxpc3RlbmVyczogeyBcImF1dG9TdGFydDpiZWZvcmUtc3RhcnRcIjogZnVuY3Rpb24odCwgZSkge1xuICAgICAgdmFyIHIgPSB0LmludGVyYWN0aW9uLCBuID0gdC5ldmVudFRhcmdldCwgbyA9IHQuZHgsIGwgPSB0LmR5O1xuICAgICAgaWYgKHIucHJlcGFyZWQubmFtZSA9PT0gXCJkcmFnXCIpIHtcbiAgICAgICAgdmFyIGMgPSBNYXRoLmFicyhvKSwgcCA9IE1hdGguYWJzKGwpLCBoID0gci5pbnRlcmFjdGFibGUub3B0aW9ucy5kcmFnLCBnID0gaC5zdGFydEF4aXMsIGQgPSBjID4gcCA/IFwieFwiIDogYyA8IHAgPyBcInlcIiA6IFwieHlcIjtcbiAgICAgICAgaWYgKHIucHJlcGFyZWQuYXhpcyA9IGgubG9ja0F4aXMgPT09IFwic3RhcnRcIiA/IGRbMF0gOiBoLmxvY2tBeGlzLCBkICE9PSBcInh5XCIgJiYgZyAhPT0gXCJ4eVwiICYmIGcgIT09IGQpIHtcbiAgICAgICAgICByLnByZXBhcmVkLm5hbWUgPSBudWxsO1xuICAgICAgICAgIGZvciAodmFyIGIgPSBuLCB4ID0gZnVuY3Rpb24oRSkge1xuICAgICAgICAgICAgaWYgKEUgIT09IHIuaW50ZXJhY3RhYmxlKSB7XG4gICAgICAgICAgICAgIHZhciBNID0gci5pbnRlcmFjdGFibGUub3B0aW9ucy5kcmFnO1xuICAgICAgICAgICAgICBpZiAoIU0ubWFudWFsU3RhcnQgJiYgRS50ZXN0SWdub3JlQWxsb3coTSwgYiwgbikpIHtcbiAgICAgICAgICAgICAgICB2YXIgJCA9IEUuZ2V0QWN0aW9uKHIuZG93blBvaW50ZXIsIHIuZG93bkV2ZW50LCByLCBiKTtcbiAgICAgICAgICAgICAgICBpZiAoJCAmJiAkLm5hbWUgPT09IFwiZHJhZ1wiICYmIGZ1bmN0aW9uKHosIEEpIHtcbiAgICAgICAgICAgICAgICAgIGlmICghQSkgcmV0dXJuICExO1xuICAgICAgICAgICAgICAgICAgdmFyIE4gPSBBLm9wdGlvbnMuZHJhZy5zdGFydEF4aXM7XG4gICAgICAgICAgICAgICAgICByZXR1cm4geiA9PT0gXCJ4eVwiIHx8IE4gPT09IFwieHlcIiB8fCBOID09PSB6O1xuICAgICAgICAgICAgICAgIH0oZCwgRSkgJiYgcnIudmFsaWRhdGVBY3Rpb24oJCwgRSwgYiwgbiwgZSkpIHJldHVybiBFO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfTsgdy5lbGVtZW50KGIpOyApIHtcbiAgICAgICAgICAgIHZhciBJID0gZS5pbnRlcmFjdGFibGVzLmZvckVhY2hNYXRjaChiLCB4KTtcbiAgICAgICAgICAgIGlmIChJKSB7XG4gICAgICAgICAgICAgIHIucHJlcGFyZWQubmFtZSA9IFwiZHJhZ1wiLCByLmludGVyYWN0YWJsZSA9IEksIHIuZWxlbWVudCA9IGI7XG4gICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYiA9IHBlKGIpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gfSB9O1xuICAgIGZ1bmN0aW9uIG5yKHQpIHtcbiAgICAgIHZhciBlID0gdC5wcmVwYXJlZCAmJiB0LnByZXBhcmVkLm5hbWU7XG4gICAgICBpZiAoIWUpIHJldHVybiBudWxsO1xuICAgICAgdmFyIHIgPSB0LmludGVyYWN0YWJsZS5vcHRpb25zO1xuICAgICAgcmV0dXJuIHJbZV0uaG9sZCB8fCByW2VdLmRlbGF5O1xuICAgIH1cbiAgICB2YXIgeG8gPSB7IGlkOiBcImF1dG8tc3RhcnQvaG9sZFwiLCBpbnN0YWxsOiBmdW5jdGlvbih0KSB7XG4gICAgICB2YXIgZSA9IHQuZGVmYXVsdHM7XG4gICAgICB0LnVzZVBsdWdpbihyciksIGUucGVyQWN0aW9uLmhvbGQgPSAwLCBlLnBlckFjdGlvbi5kZWxheSA9IDA7XG4gICAgfSwgbGlzdGVuZXJzOiB7IFwiaW50ZXJhY3Rpb25zOm5ld1wiOiBmdW5jdGlvbih0KSB7XG4gICAgICB0LmludGVyYWN0aW9uLmF1dG9TdGFydEhvbGRUaW1lciA9IG51bGw7XG4gICAgfSwgXCJhdXRvU3RhcnQ6cHJlcGFyZWRcIjogZnVuY3Rpb24odCkge1xuICAgICAgdmFyIGUgPSB0LmludGVyYWN0aW9uLCByID0gbnIoZSk7XG4gICAgICByID4gMCAmJiAoZS5hdXRvU3RhcnRIb2xkVGltZXIgPSBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xuICAgICAgICBlLnN0YXJ0KGUucHJlcGFyZWQsIGUuaW50ZXJhY3RhYmxlLCBlLmVsZW1lbnQpO1xuICAgICAgfSwgcikpO1xuICAgIH0sIFwiaW50ZXJhY3Rpb25zOm1vdmVcIjogZnVuY3Rpb24odCkge1xuICAgICAgdmFyIGUgPSB0LmludGVyYWN0aW9uLCByID0gdC5kdXBsaWNhdGU7XG4gICAgICBlLmF1dG9TdGFydEhvbGRUaW1lciAmJiBlLnBvaW50ZXJXYXNNb3ZlZCAmJiAhciAmJiAoY2xlYXJUaW1lb3V0KGUuYXV0b1N0YXJ0SG9sZFRpbWVyKSwgZS5hdXRvU3RhcnRIb2xkVGltZXIgPSBudWxsKTtcbiAgICB9LCBcImF1dG9TdGFydDpiZWZvcmUtc3RhcnRcIjogZnVuY3Rpb24odCkge1xuICAgICAgdmFyIGUgPSB0LmludGVyYWN0aW9uO1xuICAgICAgbnIoZSkgPiAwICYmIChlLnByZXBhcmVkLm5hbWUgPSBudWxsKTtcbiAgICB9IH0sIGdldEhvbGREdXJhdGlvbjogbnIgfSwgU28gPSB4bywgT28gPSB7IGlkOiBcImF1dG8tc3RhcnRcIiwgaW5zdGFsbDogZnVuY3Rpb24odCkge1xuICAgICAgdC51c2VQbHVnaW4ocnIpLCB0LnVzZVBsdWdpbihTbyksIHQudXNlUGx1Z2luKHdvKTtcbiAgICB9IH0sIENvID0gZnVuY3Rpb24odCkge1xuICAgICAgcmV0dXJuIC9eKGFsd2F5c3xuZXZlcnxhdXRvKSQvLnRlc3QodCkgPyAodGhpcy5vcHRpb25zLnByZXZlbnREZWZhdWx0ID0gdCwgdGhpcykgOiB3LmJvb2wodCkgPyAodGhpcy5vcHRpb25zLnByZXZlbnREZWZhdWx0ID0gdCA/IFwiYWx3YXlzXCIgOiBcIm5ldmVyXCIsIHRoaXMpIDogdGhpcy5vcHRpb25zLnByZXZlbnREZWZhdWx0O1xuICAgIH07XG4gICAgZnVuY3Rpb24gRW8odCkge1xuICAgICAgdmFyIGUgPSB0LmludGVyYWN0aW9uLCByID0gdC5ldmVudDtcbiAgICAgIGUuaW50ZXJhY3RhYmxlICYmIGUuaW50ZXJhY3RhYmxlLmNoZWNrQW5kUHJldmVudERlZmF1bHQocik7XG4gICAgfVxuICAgIHZhciBtbiA9IHsgaWQ6IFwiY29yZS9pbnRlcmFjdGFibGVQcmV2ZW50RGVmYXVsdFwiLCBpbnN0YWxsOiBmdW5jdGlvbih0KSB7XG4gICAgICB2YXIgZSA9IHQuSW50ZXJhY3RhYmxlO1xuICAgICAgZS5wcm90b3R5cGUucHJldmVudERlZmF1bHQgPSBDbywgZS5wcm90b3R5cGUuY2hlY2tBbmRQcmV2ZW50RGVmYXVsdCA9IGZ1bmN0aW9uKHIpIHtcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uKG4sIG8sIGwpIHtcbiAgICAgICAgICB2YXIgYyA9IG4ub3B0aW9ucy5wcmV2ZW50RGVmYXVsdDtcbiAgICAgICAgICBpZiAoYyAhPT0gXCJuZXZlclwiKSBpZiAoYyAhPT0gXCJhbHdheXNcIikge1xuICAgICAgICAgICAgaWYgKG8uZXZlbnRzLnN1cHBvcnRzUGFzc2l2ZSAmJiAvXnRvdWNoKHN0YXJ0fG1vdmUpJC8udGVzdChsLnR5cGUpKSB7XG4gICAgICAgICAgICAgIHZhciBwID0gQihsLnRhcmdldCkuZG9jdW1lbnQsIGggPSBvLmdldERvY09wdGlvbnMocCk7XG4gICAgICAgICAgICAgIGlmICghaCB8fCAhaC5ldmVudHMgfHwgaC5ldmVudHMucGFzc2l2ZSAhPT0gITEpIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC9eKG1vdXNlfHBvaW50ZXJ8dG91Y2gpKihkb3dufHN0YXJ0KS9pLnRlc3QobC50eXBlKSB8fCB3LmVsZW1lbnQobC50YXJnZXQpICYmIG1lKGwudGFyZ2V0LCBcImlucHV0LHNlbGVjdCx0ZXh0YXJlYSxbY29udGVudGVkaXRhYmxlPXRydWVdLFtjb250ZW50ZWRpdGFibGU9dHJ1ZV0gKlwiKSB8fCBsLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgfSBlbHNlIGwucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgfSh0aGlzLCB0LCByKTtcbiAgICAgIH0sIHQuaW50ZXJhY3Rpb25zLmRvY0V2ZW50cy5wdXNoKHsgdHlwZTogXCJkcmFnc3RhcnRcIiwgbGlzdGVuZXI6IGZ1bmN0aW9uKHIpIHtcbiAgICAgICAgZm9yICh2YXIgbiA9IDAsIG8gPSB0LmludGVyYWN0aW9ucy5saXN0OyBuIDwgby5sZW5ndGg7IG4rKykge1xuICAgICAgICAgIHZhciBsID0gb1tuXTtcbiAgICAgICAgICBpZiAobC5lbGVtZW50ICYmIChsLmVsZW1lbnQgPT09IHIudGFyZ2V0IHx8IFNlKGwuZWxlbWVudCwgci50YXJnZXQpKSkgcmV0dXJuIHZvaWQgbC5pbnRlcmFjdGFibGUuY2hlY2tBbmRQcmV2ZW50RGVmYXVsdChyKTtcbiAgICAgICAgfVxuICAgICAgfSB9KTtcbiAgICB9LCBsaXN0ZW5lcnM6IFtcImRvd25cIiwgXCJtb3ZlXCIsIFwidXBcIiwgXCJjYW5jZWxcIl0ucmVkdWNlKGZ1bmN0aW9uKHQsIGUpIHtcbiAgICAgIHJldHVybiB0W1wiaW50ZXJhY3Rpb25zOlwiLmNvbmNhdChlKV0gPSBFbywgdDtcbiAgICB9LCB7fSkgfTtcbiAgICBmdW5jdGlvbiBwdCh0LCBlKSB7XG4gICAgICBpZiAoZS5waGFzZWxlc3NUeXBlc1t0XSkgcmV0dXJuICEwO1xuICAgICAgZm9yICh2YXIgciBpbiBlLm1hcCkgaWYgKHQuaW5kZXhPZihyKSA9PT0gMCAmJiB0LnN1YnN0cihyLmxlbmd0aCkgaW4gZS5waGFzZXMpIHJldHVybiAhMDtcbiAgICAgIHJldHVybiAhMTtcbiAgICB9XG4gICAgZnVuY3Rpb24ga2UodCkge1xuICAgICAgdmFyIGUgPSB7fTtcbiAgICAgIGZvciAodmFyIHIgaW4gdCkge1xuICAgICAgICB2YXIgbiA9IHRbcl07XG4gICAgICAgIHcucGxhaW5PYmplY3QobikgPyBlW3JdID0ga2UobikgOiB3LmFycmF5KG4pID8gZVtyXSA9IHJuKG4pIDogZVtyXSA9IG47XG4gICAgICB9XG4gICAgICByZXR1cm4gZTtcbiAgICB9XG4gICAgdmFyIGlyID0gZnVuY3Rpb24oKSB7XG4gICAgICBmdW5jdGlvbiB0KGUpIHtcbiAgICAgICAgZih0aGlzLCB0KSwgdGhpcy5zdGF0ZXMgPSBbXSwgdGhpcy5zdGFydE9mZnNldCA9IHsgbGVmdDogMCwgcmlnaHQ6IDAsIHRvcDogMCwgYm90dG9tOiAwIH0sIHRoaXMuc3RhcnREZWx0YSA9IHZvaWQgMCwgdGhpcy5yZXN1bHQgPSB2b2lkIDAsIHRoaXMuZW5kUmVzdWx0ID0gdm9pZCAwLCB0aGlzLnN0YXJ0RWRnZXMgPSB2b2lkIDAsIHRoaXMuZWRnZXMgPSB2b2lkIDAsIHRoaXMuaW50ZXJhY3Rpb24gPSB2b2lkIDAsIHRoaXMuaW50ZXJhY3Rpb24gPSBlLCB0aGlzLnJlc3VsdCA9IGh0KCksIHRoaXMuZWRnZXMgPSB7IGxlZnQ6ICExLCByaWdodDogITEsIHRvcDogITEsIGJvdHRvbTogITEgfTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB5KHQsIFt7IGtleTogXCJzdGFydFwiLCB2YWx1ZTogZnVuY3Rpb24oZSwgcikge1xuICAgICAgICB2YXIgbiwgbywgbCA9IGUucGhhc2UsIGMgPSB0aGlzLmludGVyYWN0aW9uLCBwID0gZnVuY3Rpb24oZykge1xuICAgICAgICAgIHZhciBkID0gZy5pbnRlcmFjdGFibGUub3B0aW9uc1tnLnByZXBhcmVkLm5hbWVdLCBiID0gZC5tb2RpZmllcnM7XG4gICAgICAgICAgcmV0dXJuIGIgJiYgYi5sZW5ndGggPyBiIDogW1wic25hcFwiLCBcInNuYXBTaXplXCIsIFwic25hcEVkZ2VzXCIsIFwicmVzdHJpY3RcIiwgXCJyZXN0cmljdEVkZ2VzXCIsIFwicmVzdHJpY3RTaXplXCJdLm1hcChmdW5jdGlvbih4KSB7XG4gICAgICAgICAgICB2YXIgSSA9IGRbeF07XG4gICAgICAgICAgICByZXR1cm4gSSAmJiBJLmVuYWJsZWQgJiYgeyBvcHRpb25zOiBJLCBtZXRob2RzOiBJLl9tZXRob2RzIH07XG4gICAgICAgICAgfSkuZmlsdGVyKGZ1bmN0aW9uKHgpIHtcbiAgICAgICAgICAgIHJldHVybiAhIXg7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0oYyk7XG4gICAgICAgIHRoaXMucHJlcGFyZVN0YXRlcyhwKSwgdGhpcy5zdGFydEVkZ2VzID0gVyh7fSwgYy5lZGdlcyksIHRoaXMuZWRnZXMgPSBXKHt9LCB0aGlzLnN0YXJ0RWRnZXMpLCB0aGlzLnN0YXJ0T2Zmc2V0ID0gKG4gPSBjLnJlY3QsIG8gPSByLCBuID8geyBsZWZ0OiBvLnggLSBuLmxlZnQsIHRvcDogby55IC0gbi50b3AsIHJpZ2h0OiBuLnJpZ2h0IC0gby54LCBib3R0b206IG4uYm90dG9tIC0gby55IH0gOiB7IGxlZnQ6IDAsIHRvcDogMCwgcmlnaHQ6IDAsIGJvdHRvbTogMCB9KSwgdGhpcy5zdGFydERlbHRhID0geyB4OiAwLCB5OiAwIH07XG4gICAgICAgIHZhciBoID0gdGhpcy5maWxsQXJnKHsgcGhhc2U6IGwsIHBhZ2VDb29yZHM6IHIsIHByZUVuZDogITEgfSk7XG4gICAgICAgIHJldHVybiB0aGlzLnJlc3VsdCA9IGh0KCksIHRoaXMuc3RhcnRBbGwoaCksIHRoaXMucmVzdWx0ID0gdGhpcy5zZXRBbGwoaCk7XG4gICAgICB9IH0sIHsga2V5OiBcImZpbGxBcmdcIiwgdmFsdWU6IGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgdmFyIHIgPSB0aGlzLmludGVyYWN0aW9uO1xuICAgICAgICByZXR1cm4gZS5pbnRlcmFjdGlvbiA9IHIsIGUuaW50ZXJhY3RhYmxlID0gci5pbnRlcmFjdGFibGUsIGUuZWxlbWVudCA9IHIuZWxlbWVudCwgZS5yZWN0IHx8IChlLnJlY3QgPSByLnJlY3QpLCBlLmVkZ2VzIHx8IChlLmVkZ2VzID0gdGhpcy5zdGFydEVkZ2VzKSwgZS5zdGFydE9mZnNldCA9IHRoaXMuc3RhcnRPZmZzZXQsIGU7XG4gICAgICB9IH0sIHsga2V5OiBcInN0YXJ0QWxsXCIsIHZhbHVlOiBmdW5jdGlvbihlKSB7XG4gICAgICAgIGZvciAodmFyIHIgPSAwLCBuID0gdGhpcy5zdGF0ZXM7IHIgPCBuLmxlbmd0aDsgcisrKSB7XG4gICAgICAgICAgdmFyIG8gPSBuW3JdO1xuICAgICAgICAgIG8ubWV0aG9kcy5zdGFydCAmJiAoZS5zdGF0ZSA9IG8sIG8ubWV0aG9kcy5zdGFydChlKSk7XG4gICAgICAgIH1cbiAgICAgIH0gfSwgeyBrZXk6IFwic2V0QWxsXCIsIHZhbHVlOiBmdW5jdGlvbihlKSB7XG4gICAgICAgIHZhciByID0gZS5waGFzZSwgbiA9IGUucHJlRW5kLCBvID0gZS5za2lwTW9kaWZpZXJzLCBsID0gZS5yZWN0LCBjID0gZS5lZGdlcztcbiAgICAgICAgZS5jb29yZHMgPSBXKHt9LCBlLnBhZ2VDb29yZHMpLCBlLnJlY3QgPSBXKHt9LCBsKSwgZS5lZGdlcyA9IFcoe30sIGMpO1xuICAgICAgICBmb3IgKHZhciBwID0gbyA/IHRoaXMuc3RhdGVzLnNsaWNlKG8pIDogdGhpcy5zdGF0ZXMsIGggPSBodChlLmNvb3JkcywgZS5yZWN0KSwgZyA9IDA7IGcgPCBwLmxlbmd0aDsgZysrKSB7XG4gICAgICAgICAgdmFyIGQsIGIgPSBwW2ddLCB4ID0gYi5vcHRpb25zLCBJID0gVyh7fSwgZS5jb29yZHMpLCBFID0gbnVsbDtcbiAgICAgICAgICAoZCA9IGIubWV0aG9kcykgIT0gbnVsbCAmJiBkLnNldCAmJiB0aGlzLnNob3VsZERvKHgsIG4sIHIpICYmIChlLnN0YXRlID0gYiwgRSA9IGIubWV0aG9kcy5zZXQoZSksIG90KGUuZWRnZXMsIGUucmVjdCwgeyB4OiBlLmNvb3Jkcy54IC0gSS54LCB5OiBlLmNvb3Jkcy55IC0gSS55IH0pKSwgaC5ldmVudFByb3BzLnB1c2goRSk7XG4gICAgICAgIH1cbiAgICAgICAgVyh0aGlzLmVkZ2VzLCBlLmVkZ2VzKSwgaC5kZWx0YS54ID0gZS5jb29yZHMueCAtIGUucGFnZUNvb3Jkcy54LCBoLmRlbHRhLnkgPSBlLmNvb3Jkcy55IC0gZS5wYWdlQ29vcmRzLnksIGgucmVjdERlbHRhLmxlZnQgPSBlLnJlY3QubGVmdCAtIGwubGVmdCwgaC5yZWN0RGVsdGEucmlnaHQgPSBlLnJlY3QucmlnaHQgLSBsLnJpZ2h0LCBoLnJlY3REZWx0YS50b3AgPSBlLnJlY3QudG9wIC0gbC50b3AsIGgucmVjdERlbHRhLmJvdHRvbSA9IGUucmVjdC5ib3R0b20gLSBsLmJvdHRvbTtcbiAgICAgICAgdmFyIE0gPSB0aGlzLnJlc3VsdC5jb29yZHMsICQgPSB0aGlzLnJlc3VsdC5yZWN0O1xuICAgICAgICBpZiAoTSAmJiAkKSB7XG4gICAgICAgICAgdmFyIHogPSBoLnJlY3QubGVmdCAhPT0gJC5sZWZ0IHx8IGgucmVjdC5yaWdodCAhPT0gJC5yaWdodCB8fCBoLnJlY3QudG9wICE9PSAkLnRvcCB8fCBoLnJlY3QuYm90dG9tICE9PSAkLmJvdHRvbTtcbiAgICAgICAgICBoLmNoYW5nZWQgPSB6IHx8IE0ueCAhPT0gaC5jb29yZHMueCB8fCBNLnkgIT09IGguY29vcmRzLnk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGg7XG4gICAgICB9IH0sIHsga2V5OiBcImFwcGx5VG9JbnRlcmFjdGlvblwiLCB2YWx1ZTogZnVuY3Rpb24oZSkge1xuICAgICAgICB2YXIgciA9IHRoaXMuaW50ZXJhY3Rpb24sIG4gPSBlLnBoYXNlLCBvID0gci5jb29yZHMuY3VyLCBsID0gci5jb29yZHMuc3RhcnQsIGMgPSB0aGlzLnJlc3VsdCwgcCA9IHRoaXMuc3RhcnREZWx0YSwgaCA9IGMuZGVsdGE7XG4gICAgICAgIG4gPT09IFwic3RhcnRcIiAmJiBXKHRoaXMuc3RhcnREZWx0YSwgYy5kZWx0YSk7XG4gICAgICAgIGZvciAodmFyIGcgPSAwLCBkID0gW1tsLCBwXSwgW28sIGhdXTsgZyA8IGQubGVuZ3RoOyBnKyspIHtcbiAgICAgICAgICB2YXIgYiA9IGRbZ10sIHggPSBiWzBdLCBJID0gYlsxXTtcbiAgICAgICAgICB4LnBhZ2UueCArPSBJLngsIHgucGFnZS55ICs9IEkueSwgeC5jbGllbnQueCArPSBJLngsIHguY2xpZW50LnkgKz0gSS55O1xuICAgICAgICB9XG4gICAgICAgIHZhciBFID0gdGhpcy5yZXN1bHQucmVjdERlbHRhLCBNID0gZS5yZWN0IHx8IHIucmVjdDtcbiAgICAgICAgTS5sZWZ0ICs9IEUubGVmdCwgTS5yaWdodCArPSBFLnJpZ2h0LCBNLnRvcCArPSBFLnRvcCwgTS5ib3R0b20gKz0gRS5ib3R0b20sIE0ud2lkdGggPSBNLnJpZ2h0IC0gTS5sZWZ0LCBNLmhlaWdodCA9IE0uYm90dG9tIC0gTS50b3A7XG4gICAgICB9IH0sIHsga2V5OiBcInNldEFuZEFwcGx5XCIsIHZhbHVlOiBmdW5jdGlvbihlKSB7XG4gICAgICAgIHZhciByID0gdGhpcy5pbnRlcmFjdGlvbiwgbiA9IGUucGhhc2UsIG8gPSBlLnByZUVuZCwgbCA9IGUuc2tpcE1vZGlmaWVycywgYyA9IHRoaXMuc2V0QWxsKHRoaXMuZmlsbEFyZyh7IHByZUVuZDogbywgcGhhc2U6IG4sIHBhZ2VDb29yZHM6IGUubW9kaWZpZWRDb29yZHMgfHwgci5jb29yZHMuY3VyLnBhZ2UgfSkpO1xuICAgICAgICBpZiAodGhpcy5yZXN1bHQgPSBjLCAhYy5jaGFuZ2VkICYmICghbCB8fCBsIDwgdGhpcy5zdGF0ZXMubGVuZ3RoKSAmJiByLmludGVyYWN0aW5nKCkpIHJldHVybiAhMTtcbiAgICAgICAgaWYgKGUubW9kaWZpZWRDb29yZHMpIHtcbiAgICAgICAgICB2YXIgcCA9IHIuY29vcmRzLmN1ci5wYWdlLCBoID0geyB4OiBlLm1vZGlmaWVkQ29vcmRzLnggLSBwLngsIHk6IGUubW9kaWZpZWRDb29yZHMueSAtIHAueSB9O1xuICAgICAgICAgIGMuY29vcmRzLnggKz0gaC54LCBjLmNvb3Jkcy55ICs9IGgueSwgYy5kZWx0YS54ICs9IGgueCwgYy5kZWx0YS55ICs9IGgueTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmFwcGx5VG9JbnRlcmFjdGlvbihlKTtcbiAgICAgIH0gfSwgeyBrZXk6IFwiYmVmb3JlRW5kXCIsIHZhbHVlOiBmdW5jdGlvbihlKSB7XG4gICAgICAgIHZhciByID0gZS5pbnRlcmFjdGlvbiwgbiA9IGUuZXZlbnQsIG8gPSB0aGlzLnN0YXRlcztcbiAgICAgICAgaWYgKG8gJiYgby5sZW5ndGgpIHtcbiAgICAgICAgICBmb3IgKHZhciBsID0gITEsIGMgPSAwOyBjIDwgby5sZW5ndGg7IGMrKykge1xuICAgICAgICAgICAgdmFyIHAgPSBvW2NdO1xuICAgICAgICAgICAgZS5zdGF0ZSA9IHA7XG4gICAgICAgICAgICB2YXIgaCA9IHAub3B0aW9ucywgZyA9IHAubWV0aG9kcywgZCA9IGcuYmVmb3JlRW5kICYmIGcuYmVmb3JlRW5kKGUpO1xuICAgICAgICAgICAgaWYgKGQpIHJldHVybiB0aGlzLmVuZFJlc3VsdCA9IGQsICExO1xuICAgICAgICAgICAgbCA9IGwgfHwgIWwgJiYgdGhpcy5zaG91bGREbyhoLCAhMCwgZS5waGFzZSwgITApO1xuICAgICAgICAgIH1cbiAgICAgICAgICBsICYmIHIubW92ZSh7IGV2ZW50OiBuLCBwcmVFbmQ6ICEwIH0pO1xuICAgICAgICB9XG4gICAgICB9IH0sIHsga2V5OiBcInN0b3BcIiwgdmFsdWU6IGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgdmFyIHIgPSBlLmludGVyYWN0aW9uO1xuICAgICAgICBpZiAodGhpcy5zdGF0ZXMgJiYgdGhpcy5zdGF0ZXMubGVuZ3RoKSB7XG4gICAgICAgICAgdmFyIG4gPSBXKHsgc3RhdGVzOiB0aGlzLnN0YXRlcywgaW50ZXJhY3RhYmxlOiByLmludGVyYWN0YWJsZSwgZWxlbWVudDogci5lbGVtZW50LCByZWN0OiBudWxsIH0sIGUpO1xuICAgICAgICAgIHRoaXMuZmlsbEFyZyhuKTtcbiAgICAgICAgICBmb3IgKHZhciBvID0gMCwgbCA9IHRoaXMuc3RhdGVzOyBvIDwgbC5sZW5ndGg7IG8rKykge1xuICAgICAgICAgICAgdmFyIGMgPSBsW29dO1xuICAgICAgICAgICAgbi5zdGF0ZSA9IGMsIGMubWV0aG9kcy5zdG9wICYmIGMubWV0aG9kcy5zdG9wKG4pO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aGlzLnN0YXRlcyA9IG51bGwsIHRoaXMuZW5kUmVzdWx0ID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgfSB9LCB7IGtleTogXCJwcmVwYXJlU3RhdGVzXCIsIHZhbHVlOiBmdW5jdGlvbihlKSB7XG4gICAgICAgIHRoaXMuc3RhdGVzID0gW107XG4gICAgICAgIGZvciAodmFyIHIgPSAwOyByIDwgZS5sZW5ndGg7IHIrKykge1xuICAgICAgICAgIHZhciBuID0gZVtyXSwgbyA9IG4ub3B0aW9ucywgbCA9IG4ubWV0aG9kcywgYyA9IG4ubmFtZTtcbiAgICAgICAgICB0aGlzLnN0YXRlcy5wdXNoKHsgb3B0aW9uczogbywgbWV0aG9kczogbCwgaW5kZXg6IHIsIG5hbWU6IGMgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuc3RhdGVzO1xuICAgICAgfSB9LCB7IGtleTogXCJyZXN0b3JlSW50ZXJhY3Rpb25Db29yZHNcIiwgdmFsdWU6IGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgdmFyIHIgPSBlLmludGVyYWN0aW9uLCBuID0gci5jb29yZHMsIG8gPSByLnJlY3QsIGwgPSByLm1vZGlmaWNhdGlvbjtcbiAgICAgICAgaWYgKGwucmVzdWx0KSB7XG4gICAgICAgICAgZm9yICh2YXIgYyA9IGwuc3RhcnREZWx0YSwgcCA9IGwucmVzdWx0LCBoID0gcC5kZWx0YSwgZyA9IHAucmVjdERlbHRhLCBkID0gMCwgYiA9IFtbbi5zdGFydCwgY10sIFtuLmN1ciwgaF1dOyBkIDwgYi5sZW5ndGg7IGQrKykge1xuICAgICAgICAgICAgdmFyIHggPSBiW2RdLCBJID0geFswXSwgRSA9IHhbMV07XG4gICAgICAgICAgICBJLnBhZ2UueCAtPSBFLngsIEkucGFnZS55IC09IEUueSwgSS5jbGllbnQueCAtPSBFLngsIEkuY2xpZW50LnkgLT0gRS55O1xuICAgICAgICAgIH1cbiAgICAgICAgICBvLmxlZnQgLT0gZy5sZWZ0LCBvLnJpZ2h0IC09IGcucmlnaHQsIG8udG9wIC09IGcudG9wLCBvLmJvdHRvbSAtPSBnLmJvdHRvbTtcbiAgICAgICAgfVxuICAgICAgfSB9LCB7IGtleTogXCJzaG91bGREb1wiLCB2YWx1ZTogZnVuY3Rpb24oZSwgciwgbiwgbykge1xuICAgICAgICByZXR1cm4gISghZSB8fCBlLmVuYWJsZWQgPT09ICExIHx8IG8gJiYgIWUuZW5kT25seSB8fCBlLmVuZE9ubHkgJiYgIXIgfHwgbiA9PT0gXCJzdGFydFwiICYmICFlLnNldFN0YXJ0KTtcbiAgICAgIH0gfSwgeyBrZXk6IFwiY29weUZyb21cIiwgdmFsdWU6IGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgdGhpcy5zdGFydE9mZnNldCA9IGUuc3RhcnRPZmZzZXQsIHRoaXMuc3RhcnREZWx0YSA9IGUuc3RhcnREZWx0YSwgdGhpcy5zdGFydEVkZ2VzID0gZS5zdGFydEVkZ2VzLCB0aGlzLmVkZ2VzID0gZS5lZGdlcywgdGhpcy5zdGF0ZXMgPSBlLnN0YXRlcy5tYXAoZnVuY3Rpb24ocikge1xuICAgICAgICAgIHJldHVybiBrZShyKTtcbiAgICAgICAgfSksIHRoaXMucmVzdWx0ID0gaHQoVyh7fSwgZS5yZXN1bHQuY29vcmRzKSwgVyh7fSwgZS5yZXN1bHQucmVjdCkpO1xuICAgICAgfSB9LCB7IGtleTogXCJkZXN0cm95XCIsIHZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgZm9yICh2YXIgZSBpbiB0aGlzKSB0aGlzW2VdID0gbnVsbDtcbiAgICAgIH0gfV0pLCB0O1xuICAgIH0oKTtcbiAgICBmdW5jdGlvbiBodCh0LCBlKSB7XG4gICAgICByZXR1cm4geyByZWN0OiBlLCBjb29yZHM6IHQsIGRlbHRhOiB7IHg6IDAsIHk6IDAgfSwgcmVjdERlbHRhOiB7IGxlZnQ6IDAsIHJpZ2h0OiAwLCB0b3A6IDAsIGJvdHRvbTogMCB9LCBldmVudFByb3BzOiBbXSwgY2hhbmdlZDogITAgfTtcbiAgICB9XG4gICAgZnVuY3Rpb24geWUodCwgZSkge1xuICAgICAgdmFyIHIgPSB0LmRlZmF1bHRzLCBuID0geyBzdGFydDogdC5zdGFydCwgc2V0OiB0LnNldCwgYmVmb3JlRW5kOiB0LmJlZm9yZUVuZCwgc3RvcDogdC5zdG9wIH0sIG8gPSBmdW5jdGlvbihsKSB7XG4gICAgICAgIHZhciBjID0gbCB8fCB7fTtcbiAgICAgICAgZm9yICh2YXIgcCBpbiBjLmVuYWJsZWQgPSBjLmVuYWJsZWQgIT09ICExLCByKSBwIGluIGMgfHwgKGNbcF0gPSByW3BdKTtcbiAgICAgICAgdmFyIGggPSB7IG9wdGlvbnM6IGMsIG1ldGhvZHM6IG4sIG5hbWU6IGUsIGVuYWJsZTogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgcmV0dXJuIGMuZW5hYmxlZCA9ICEwLCBoO1xuICAgICAgICB9LCBkaXNhYmxlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICByZXR1cm4gYy5lbmFibGVkID0gITEsIGg7XG4gICAgICAgIH0gfTtcbiAgICAgICAgcmV0dXJuIGg7XG4gICAgICB9O1xuICAgICAgcmV0dXJuIGUgJiYgdHlwZW9mIGUgPT0gXCJzdHJpbmdcIiAmJiAoby5fZGVmYXVsdHMgPSByLCBvLl9tZXRob2RzID0gbiksIG87XG4gICAgfVxuICAgIGZ1bmN0aW9uIFZlKHQpIHtcbiAgICAgIHZhciBlID0gdC5pRXZlbnQsIHIgPSB0LmludGVyYWN0aW9uLm1vZGlmaWNhdGlvbi5yZXN1bHQ7XG4gICAgICByICYmIChlLm1vZGlmaWVycyA9IHIuZXZlbnRQcm9wcyk7XG4gICAgfVxuICAgIHZhciBfbyA9IHsgaWQ6IFwibW9kaWZpZXJzL2Jhc2VcIiwgYmVmb3JlOiBbXCJhY3Rpb25zXCJdLCBpbnN0YWxsOiBmdW5jdGlvbih0KSB7XG4gICAgICB0LmRlZmF1bHRzLnBlckFjdGlvbi5tb2RpZmllcnMgPSBbXTtcbiAgICB9LCBsaXN0ZW5lcnM6IHsgXCJpbnRlcmFjdGlvbnM6bmV3XCI6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHZhciBlID0gdC5pbnRlcmFjdGlvbjtcbiAgICAgIGUubW9kaWZpY2F0aW9uID0gbmV3IGlyKGUpO1xuICAgIH0sIFwiaW50ZXJhY3Rpb25zOmJlZm9yZS1hY3Rpb24tc3RhcnRcIjogZnVuY3Rpb24odCkge1xuICAgICAgdmFyIGUgPSB0LmludGVyYWN0aW9uLCByID0gdC5pbnRlcmFjdGlvbi5tb2RpZmljYXRpb247XG4gICAgICByLnN0YXJ0KHQsIGUuY29vcmRzLnN0YXJ0LnBhZ2UpLCBlLmVkZ2VzID0gci5lZGdlcywgci5hcHBseVRvSW50ZXJhY3Rpb24odCk7XG4gICAgfSwgXCJpbnRlcmFjdGlvbnM6YmVmb3JlLWFjdGlvbi1tb3ZlXCI6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHZhciBlID0gdC5pbnRlcmFjdGlvbiwgciA9IGUubW9kaWZpY2F0aW9uLCBuID0gci5zZXRBbmRBcHBseSh0KTtcbiAgICAgIHJldHVybiBlLmVkZ2VzID0gci5lZGdlcywgbjtcbiAgICB9LCBcImludGVyYWN0aW9uczpiZWZvcmUtYWN0aW9uLWVuZFwiOiBmdW5jdGlvbih0KSB7XG4gICAgICB2YXIgZSA9IHQuaW50ZXJhY3Rpb24sIHIgPSBlLm1vZGlmaWNhdGlvbiwgbiA9IHIuYmVmb3JlRW5kKHQpO1xuICAgICAgcmV0dXJuIGUuZWRnZXMgPSByLnN0YXJ0RWRnZXMsIG47XG4gICAgfSwgXCJpbnRlcmFjdGlvbnM6YWN0aW9uLXN0YXJ0XCI6IFZlLCBcImludGVyYWN0aW9uczphY3Rpb24tbW92ZVwiOiBWZSwgXCJpbnRlcmFjdGlvbnM6YWN0aW9uLWVuZFwiOiBWZSwgXCJpbnRlcmFjdGlvbnM6YWZ0ZXItYWN0aW9uLXN0YXJ0XCI6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHJldHVybiB0LmludGVyYWN0aW9uLm1vZGlmaWNhdGlvbi5yZXN0b3JlSW50ZXJhY3Rpb25Db29yZHModCk7XG4gICAgfSwgXCJpbnRlcmFjdGlvbnM6YWZ0ZXItYWN0aW9uLW1vdmVcIjogZnVuY3Rpb24odCkge1xuICAgICAgcmV0dXJuIHQuaW50ZXJhY3Rpb24ubW9kaWZpY2F0aW9uLnJlc3RvcmVJbnRlcmFjdGlvbkNvb3Jkcyh0KTtcbiAgICB9LCBcImludGVyYWN0aW9uczpzdG9wXCI6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHJldHVybiB0LmludGVyYWN0aW9uLm1vZGlmaWNhdGlvbi5zdG9wKHQpO1xuICAgIH0gfSB9LCBibiA9IF9vLCB5biA9IHsgYmFzZTogeyBwcmV2ZW50RGVmYXVsdDogXCJhdXRvXCIsIGRlbHRhU291cmNlOiBcInBhZ2VcIiB9LCBwZXJBY3Rpb246IHsgZW5hYmxlZDogITEsIG9yaWdpbjogeyB4OiAwLCB5OiAwIH0gfSwgYWN0aW9uczoge30gfSwgb3IgPSBmdW5jdGlvbih0KSB7XG4gICAgICBDKHIsIHQpO1xuICAgICAgdmFyIGUgPSBQKHIpO1xuICAgICAgZnVuY3Rpb24gcihuLCBvLCBsLCBjLCBwLCBoLCBnKSB7XG4gICAgICAgIHZhciBkO1xuICAgICAgICBmKHRoaXMsIHIpLCAoZCA9IGUuY2FsbCh0aGlzLCBuKSkucmVsYXRlZFRhcmdldCA9IG51bGwsIGQuc2NyZWVuWCA9IHZvaWQgMCwgZC5zY3JlZW5ZID0gdm9pZCAwLCBkLmJ1dHRvbiA9IHZvaWQgMCwgZC5idXR0b25zID0gdm9pZCAwLCBkLmN0cmxLZXkgPSB2b2lkIDAsIGQuc2hpZnRLZXkgPSB2b2lkIDAsIGQuYWx0S2V5ID0gdm9pZCAwLCBkLm1ldGFLZXkgPSB2b2lkIDAsIGQucGFnZSA9IHZvaWQgMCwgZC5jbGllbnQgPSB2b2lkIDAsIGQuZGVsdGEgPSB2b2lkIDAsIGQucmVjdCA9IHZvaWQgMCwgZC54MCA9IHZvaWQgMCwgZC55MCA9IHZvaWQgMCwgZC50MCA9IHZvaWQgMCwgZC5kdCA9IHZvaWQgMCwgZC5kdXJhdGlvbiA9IHZvaWQgMCwgZC5jbGllbnRYMCA9IHZvaWQgMCwgZC5jbGllbnRZMCA9IHZvaWQgMCwgZC52ZWxvY2l0eSA9IHZvaWQgMCwgZC5zcGVlZCA9IHZvaWQgMCwgZC5zd2lwZSA9IHZvaWQgMCwgZC5heGVzID0gdm9pZCAwLCBkLnByZUVuZCA9IHZvaWQgMCwgcCA9IHAgfHwgbi5lbGVtZW50O1xuICAgICAgICB2YXIgYiA9IG4uaW50ZXJhY3RhYmxlLCB4ID0gKGIgJiYgYi5vcHRpb25zIHx8IHluKS5kZWx0YVNvdXJjZSwgSSA9IE5lKGIsIHAsIGwpLCBFID0gYyA9PT0gXCJzdGFydFwiLCBNID0gYyA9PT0gXCJlbmRcIiwgJCA9IEUgPyBUKGQpIDogbi5wcmV2RXZlbnQsIHogPSBFID8gbi5jb29yZHMuc3RhcnQgOiBNID8geyBwYWdlOiAkLnBhZ2UsIGNsaWVudDogJC5jbGllbnQsIHRpbWVTdGFtcDogbi5jb29yZHMuY3VyLnRpbWVTdGFtcCB9IDogbi5jb29yZHMuY3VyO1xuICAgICAgICByZXR1cm4gZC5wYWdlID0gVyh7fSwgei5wYWdlKSwgZC5jbGllbnQgPSBXKHt9LCB6LmNsaWVudCksIGQucmVjdCA9IFcoe30sIG4ucmVjdCksIGQudGltZVN0YW1wID0gei50aW1lU3RhbXAsIE0gfHwgKGQucGFnZS54IC09IEkueCwgZC5wYWdlLnkgLT0gSS55LCBkLmNsaWVudC54IC09IEkueCwgZC5jbGllbnQueSAtPSBJLnkpLCBkLmN0cmxLZXkgPSBvLmN0cmxLZXksIGQuYWx0S2V5ID0gby5hbHRLZXksIGQuc2hpZnRLZXkgPSBvLnNoaWZ0S2V5LCBkLm1ldGFLZXkgPSBvLm1ldGFLZXksIGQuYnV0dG9uID0gby5idXR0b24sIGQuYnV0dG9ucyA9IG8uYnV0dG9ucywgZC50YXJnZXQgPSBwLCBkLmN1cnJlbnRUYXJnZXQgPSBwLCBkLnByZUVuZCA9IGgsIGQudHlwZSA9IGcgfHwgbCArIChjIHx8IFwiXCIpLCBkLmludGVyYWN0YWJsZSA9IGIsIGQudDAgPSBFID8gbi5wb2ludGVyc1tuLnBvaW50ZXJzLmxlbmd0aCAtIDFdLmRvd25UaW1lIDogJC50MCwgZC54MCA9IG4uY29vcmRzLnN0YXJ0LnBhZ2UueCAtIEkueCwgZC55MCA9IG4uY29vcmRzLnN0YXJ0LnBhZ2UueSAtIEkueSwgZC5jbGllbnRYMCA9IG4uY29vcmRzLnN0YXJ0LmNsaWVudC54IC0gSS54LCBkLmNsaWVudFkwID0gbi5jb29yZHMuc3RhcnQuY2xpZW50LnkgLSBJLnksIGQuZGVsdGEgPSBFIHx8IE0gPyB7IHg6IDAsIHk6IDAgfSA6IHsgeDogZFt4XS54IC0gJFt4XS54LCB5OiBkW3hdLnkgLSAkW3hdLnkgfSwgZC5kdCA9IG4uY29vcmRzLmRlbHRhLnRpbWVTdGFtcCwgZC5kdXJhdGlvbiA9IGQudGltZVN0YW1wIC0gZC50MCwgZC52ZWxvY2l0eSA9IFcoe30sIG4uY29vcmRzLnZlbG9jaXR5W3hdKSwgZC5zcGVlZCA9IEdlKGQudmVsb2NpdHkueCwgZC52ZWxvY2l0eS55KSwgZC5zd2lwZSA9IE0gfHwgYyA9PT0gXCJpbmVydGlhc3RhcnRcIiA/IGQuZ2V0U3dpcGUoKSA6IG51bGwsIGQ7XG4gICAgICB9XG4gICAgICByZXR1cm4geShyLCBbeyBrZXk6IFwiZ2V0U3dpcGVcIiwgdmFsdWU6IGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgbiA9IHRoaXMuX2ludGVyYWN0aW9uO1xuICAgICAgICBpZiAobi5wcmV2RXZlbnQuc3BlZWQgPCA2MDAgfHwgdGhpcy50aW1lU3RhbXAgLSBuLnByZXZFdmVudC50aW1lU3RhbXAgPiAxNTApIHJldHVybiBudWxsO1xuICAgICAgICB2YXIgbyA9IDE4MCAqIE1hdGguYXRhbjIobi5wcmV2RXZlbnQudmVsb2NpdHlZLCBuLnByZXZFdmVudC52ZWxvY2l0eVgpIC8gTWF0aC5QSTtcbiAgICAgICAgbyA8IDAgJiYgKG8gKz0gMzYwKTtcbiAgICAgICAgdmFyIGwgPSAxMTIuNSA8PSBvICYmIG8gPCAyNDcuNSwgYyA9IDIwMi41IDw9IG8gJiYgbyA8IDMzNy41O1xuICAgICAgICByZXR1cm4geyB1cDogYywgZG93bjogIWMgJiYgMjIuNSA8PSBvICYmIG8gPCAxNTcuNSwgbGVmdDogbCwgcmlnaHQ6ICFsICYmICgyOTIuNSA8PSBvIHx8IG8gPCA2Ny41KSwgYW5nbGU6IG8sIHNwZWVkOiBuLnByZXZFdmVudC5zcGVlZCwgdmVsb2NpdHk6IHsgeDogbi5wcmV2RXZlbnQudmVsb2NpdHlYLCB5OiBuLnByZXZFdmVudC52ZWxvY2l0eVkgfSB9O1xuICAgICAgfSB9LCB7IGtleTogXCJwcmV2ZW50RGVmYXVsdFwiLCB2YWx1ZTogZnVuY3Rpb24oKSB7XG4gICAgICB9IH0sIHsga2V5OiBcInN0b3BJbW1lZGlhdGVQcm9wYWdhdGlvblwiLCB2YWx1ZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMuaW1tZWRpYXRlUHJvcGFnYXRpb25TdG9wcGVkID0gdGhpcy5wcm9wYWdhdGlvblN0b3BwZWQgPSAhMDtcbiAgICAgIH0gfSwgeyBrZXk6IFwic3RvcFByb3BhZ2F0aW9uXCIsIHZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy5wcm9wYWdhdGlvblN0b3BwZWQgPSAhMDtcbiAgICAgIH0gfV0pLCByO1xuICAgIH0oY3QpO1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKG9yLnByb3RvdHlwZSwgeyBwYWdlWDogeyBnZXQ6IGZ1bmN0aW9uKCkge1xuICAgICAgcmV0dXJuIHRoaXMucGFnZS54O1xuICAgIH0sIHNldDogZnVuY3Rpb24odCkge1xuICAgICAgdGhpcy5wYWdlLnggPSB0O1xuICAgIH0gfSwgcGFnZVk6IHsgZ2V0OiBmdW5jdGlvbigpIHtcbiAgICAgIHJldHVybiB0aGlzLnBhZ2UueTtcbiAgICB9LCBzZXQ6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHRoaXMucGFnZS55ID0gdDtcbiAgICB9IH0sIGNsaWVudFg6IHsgZ2V0OiBmdW5jdGlvbigpIHtcbiAgICAgIHJldHVybiB0aGlzLmNsaWVudC54O1xuICAgIH0sIHNldDogZnVuY3Rpb24odCkge1xuICAgICAgdGhpcy5jbGllbnQueCA9IHQ7XG4gICAgfSB9LCBjbGllbnRZOiB7IGdldDogZnVuY3Rpb24oKSB7XG4gICAgICByZXR1cm4gdGhpcy5jbGllbnQueTtcbiAgICB9LCBzZXQ6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHRoaXMuY2xpZW50LnkgPSB0O1xuICAgIH0gfSwgZHg6IHsgZ2V0OiBmdW5jdGlvbigpIHtcbiAgICAgIHJldHVybiB0aGlzLmRlbHRhLng7XG4gICAgfSwgc2V0OiBmdW5jdGlvbih0KSB7XG4gICAgICB0aGlzLmRlbHRhLnggPSB0O1xuICAgIH0gfSwgZHk6IHsgZ2V0OiBmdW5jdGlvbigpIHtcbiAgICAgIHJldHVybiB0aGlzLmRlbHRhLnk7XG4gICAgfSwgc2V0OiBmdW5jdGlvbih0KSB7XG4gICAgICB0aGlzLmRlbHRhLnkgPSB0O1xuICAgIH0gfSwgdmVsb2NpdHlYOiB7IGdldDogZnVuY3Rpb24oKSB7XG4gICAgICByZXR1cm4gdGhpcy52ZWxvY2l0eS54O1xuICAgIH0sIHNldDogZnVuY3Rpb24odCkge1xuICAgICAgdGhpcy52ZWxvY2l0eS54ID0gdDtcbiAgICB9IH0sIHZlbG9jaXR5WTogeyBnZXQ6IGZ1bmN0aW9uKCkge1xuICAgICAgcmV0dXJuIHRoaXMudmVsb2NpdHkueTtcbiAgICB9LCBzZXQ6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHRoaXMudmVsb2NpdHkueSA9IHQ7XG4gICAgfSB9IH0pO1xuICAgIHZhciBQbyA9IHkoZnVuY3Rpb24gdChlLCByLCBuLCBvLCBsKSB7XG4gICAgICBmKHRoaXMsIHQpLCB0aGlzLmlkID0gdm9pZCAwLCB0aGlzLnBvaW50ZXIgPSB2b2lkIDAsIHRoaXMuZXZlbnQgPSB2b2lkIDAsIHRoaXMuZG93blRpbWUgPSB2b2lkIDAsIHRoaXMuZG93blRhcmdldCA9IHZvaWQgMCwgdGhpcy5pZCA9IGUsIHRoaXMucG9pbnRlciA9IHIsIHRoaXMuZXZlbnQgPSBuLCB0aGlzLmRvd25UaW1lID0gbywgdGhpcy5kb3duVGFyZ2V0ID0gbDtcbiAgICB9KSwgSW8gPSBmdW5jdGlvbih0KSB7XG4gICAgICByZXR1cm4gdC5pbnRlcmFjdGFibGUgPSBcIlwiLCB0LmVsZW1lbnQgPSBcIlwiLCB0LnByZXBhcmVkID0gXCJcIiwgdC5wb2ludGVySXNEb3duID0gXCJcIiwgdC5wb2ludGVyV2FzTW92ZWQgPSBcIlwiLCB0Ll9wcm94eSA9IFwiXCIsIHQ7XG4gICAgfSh7fSksIFRuID0gZnVuY3Rpb24odCkge1xuICAgICAgcmV0dXJuIHQuc3RhcnQgPSBcIlwiLCB0Lm1vdmUgPSBcIlwiLCB0LmVuZCA9IFwiXCIsIHQuc3RvcCA9IFwiXCIsIHQuaW50ZXJhY3RpbmcgPSBcIlwiLCB0O1xuICAgIH0oe30pLCBNbyA9IDAsIFJvID0gZnVuY3Rpb24oKSB7XG4gICAgICBmdW5jdGlvbiB0KGUpIHtcbiAgICAgICAgdmFyIHIgPSB0aGlzLCBuID0gZS5wb2ludGVyVHlwZSwgbyA9IGUuc2NvcGVGaXJlO1xuICAgICAgICBmKHRoaXMsIHQpLCB0aGlzLmludGVyYWN0YWJsZSA9IG51bGwsIHRoaXMuZWxlbWVudCA9IG51bGwsIHRoaXMucmVjdCA9IG51bGwsIHRoaXMuX3JlY3RzID0gdm9pZCAwLCB0aGlzLmVkZ2VzID0gbnVsbCwgdGhpcy5fc2NvcGVGaXJlID0gdm9pZCAwLCB0aGlzLnByZXBhcmVkID0geyBuYW1lOiBudWxsLCBheGlzOiBudWxsLCBlZGdlczogbnVsbCB9LCB0aGlzLnBvaW50ZXJUeXBlID0gdm9pZCAwLCB0aGlzLnBvaW50ZXJzID0gW10sIHRoaXMuZG93bkV2ZW50ID0gbnVsbCwgdGhpcy5kb3duUG9pbnRlciA9IHt9LCB0aGlzLl9sYXRlc3RQb2ludGVyID0geyBwb2ludGVyOiBudWxsLCBldmVudDogbnVsbCwgZXZlbnRUYXJnZXQ6IG51bGwgfSwgdGhpcy5wcmV2RXZlbnQgPSBudWxsLCB0aGlzLnBvaW50ZXJJc0Rvd24gPSAhMSwgdGhpcy5wb2ludGVyV2FzTW92ZWQgPSAhMSwgdGhpcy5faW50ZXJhY3RpbmcgPSAhMSwgdGhpcy5fZW5kaW5nID0gITEsIHRoaXMuX3N0b3BwZWQgPSAhMCwgdGhpcy5fcHJveHkgPSB2b2lkIDAsIHRoaXMuc2ltdWxhdGlvbiA9IG51bGwsIHRoaXMuZG9Nb3ZlID0gQmUoZnVuY3Rpb24oZCkge1xuICAgICAgICAgIHRoaXMubW92ZShkKTtcbiAgICAgICAgfSwgXCJUaGUgaW50ZXJhY3Rpb24uZG9Nb3ZlKCkgbWV0aG9kIGhhcyBiZWVuIHJlbmFtZWQgdG8gaW50ZXJhY3Rpb24ubW92ZSgpXCIpLCB0aGlzLmNvb3JkcyA9IHsgc3RhcnQ6IHsgcGFnZTogeyB4OiAwLCB5OiAwIH0sIGNsaWVudDogeyB4OiAwLCB5OiAwIH0sIHRpbWVTdGFtcDogMCB9LCBwcmV2OiB7IHBhZ2U6IHsgeDogMCwgeTogMCB9LCBjbGllbnQ6IHsgeDogMCwgeTogMCB9LCB0aW1lU3RhbXA6IDAgfSwgY3VyOiB7IHBhZ2U6IHsgeDogMCwgeTogMCB9LCBjbGllbnQ6IHsgeDogMCwgeTogMCB9LCB0aW1lU3RhbXA6IDAgfSwgZGVsdGE6IHsgcGFnZTogeyB4OiAwLCB5OiAwIH0sIGNsaWVudDogeyB4OiAwLCB5OiAwIH0sIHRpbWVTdGFtcDogMCB9LCB2ZWxvY2l0eTogeyBwYWdlOiB7IHg6IDAsIHk6IDAgfSwgY2xpZW50OiB7IHg6IDAsIHk6IDAgfSwgdGltZVN0YW1wOiAwIH0gfSwgdGhpcy5faWQgPSBNbysrLCB0aGlzLl9zY29wZUZpcmUgPSBvLCB0aGlzLnBvaW50ZXJUeXBlID0gbjtcbiAgICAgICAgdmFyIGwgPSB0aGlzO1xuICAgICAgICB0aGlzLl9wcm94eSA9IHt9O1xuICAgICAgICB2YXIgYyA9IGZ1bmN0aW9uKGQpIHtcbiAgICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoci5fcHJveHksIGQsIHsgZ2V0OiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHJldHVybiBsW2RdO1xuICAgICAgICAgIH0gfSk7XG4gICAgICAgIH07XG4gICAgICAgIGZvciAodmFyIHAgaW4gSW8pIGMocCk7XG4gICAgICAgIHZhciBoID0gZnVuY3Rpb24oZCkge1xuICAgICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShyLl9wcm94eSwgZCwgeyB2YWx1ZTogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICByZXR1cm4gbFtkXS5hcHBseShsLCBhcmd1bWVudHMpO1xuICAgICAgICAgIH0gfSk7XG4gICAgICAgIH07XG4gICAgICAgIGZvciAodmFyIGcgaW4gVG4pIGgoZyk7XG4gICAgICAgIHRoaXMuX3Njb3BlRmlyZShcImludGVyYWN0aW9uczpuZXdcIiwgeyBpbnRlcmFjdGlvbjogdGhpcyB9KTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB5KHQsIFt7IGtleTogXCJwb2ludGVyTW92ZVRvbGVyYW5jZVwiLCBnZXQ6IGZ1bmN0aW9uKCkge1xuICAgICAgICByZXR1cm4gMTtcbiAgICAgIH0gfSwgeyBrZXk6IFwicG9pbnRlckRvd25cIiwgdmFsdWU6IGZ1bmN0aW9uKGUsIHIsIG4pIHtcbiAgICAgICAgdmFyIG8gPSB0aGlzLnVwZGF0ZVBvaW50ZXIoZSwgciwgbiwgITApLCBsID0gdGhpcy5wb2ludGVyc1tvXTtcbiAgICAgICAgdGhpcy5fc2NvcGVGaXJlKFwiaW50ZXJhY3Rpb25zOmRvd25cIiwgeyBwb2ludGVyOiBlLCBldmVudDogciwgZXZlbnRUYXJnZXQ6IG4sIHBvaW50ZXJJbmRleDogbywgcG9pbnRlckluZm86IGwsIHR5cGU6IFwiZG93blwiLCBpbnRlcmFjdGlvbjogdGhpcyB9KTtcbiAgICAgIH0gfSwgeyBrZXk6IFwic3RhcnRcIiwgdmFsdWU6IGZ1bmN0aW9uKGUsIHIsIG4pIHtcbiAgICAgICAgcmV0dXJuICEodGhpcy5pbnRlcmFjdGluZygpIHx8ICF0aGlzLnBvaW50ZXJJc0Rvd24gfHwgdGhpcy5wb2ludGVycy5sZW5ndGggPCAoZS5uYW1lID09PSBcImdlc3R1cmVcIiA/IDIgOiAxKSB8fCAhci5vcHRpb25zW2UubmFtZV0uZW5hYmxlZCkgJiYgKGVyKHRoaXMucHJlcGFyZWQsIGUpLCB0aGlzLmludGVyYWN0YWJsZSA9IHIsIHRoaXMuZWxlbWVudCA9IG4sIHRoaXMucmVjdCA9IHIuZ2V0UmVjdChuKSwgdGhpcy5lZGdlcyA9IHRoaXMucHJlcGFyZWQuZWRnZXMgPyBXKHt9LCB0aGlzLnByZXBhcmVkLmVkZ2VzKSA6IHsgbGVmdDogITAsIHJpZ2h0OiAhMCwgdG9wOiAhMCwgYm90dG9tOiAhMCB9LCB0aGlzLl9zdG9wcGVkID0gITEsIHRoaXMuX2ludGVyYWN0aW5nID0gdGhpcy5fZG9QaGFzZSh7IGludGVyYWN0aW9uOiB0aGlzLCBldmVudDogdGhpcy5kb3duRXZlbnQsIHBoYXNlOiBcInN0YXJ0XCIgfSkgJiYgIXRoaXMuX3N0b3BwZWQsIHRoaXMuX2ludGVyYWN0aW5nKTtcbiAgICAgIH0gfSwgeyBrZXk6IFwicG9pbnRlck1vdmVcIiwgdmFsdWU6IGZ1bmN0aW9uKGUsIHIsIG4pIHtcbiAgICAgICAgdGhpcy5zaW11bGF0aW9uIHx8IHRoaXMubW9kaWZpY2F0aW9uICYmIHRoaXMubW9kaWZpY2F0aW9uLmVuZFJlc3VsdCB8fCB0aGlzLnVwZGF0ZVBvaW50ZXIoZSwgciwgbiwgITEpO1xuICAgICAgICB2YXIgbywgbCwgYyA9IHRoaXMuY29vcmRzLmN1ci5wYWdlLnggPT09IHRoaXMuY29vcmRzLnByZXYucGFnZS54ICYmIHRoaXMuY29vcmRzLmN1ci5wYWdlLnkgPT09IHRoaXMuY29vcmRzLnByZXYucGFnZS55ICYmIHRoaXMuY29vcmRzLmN1ci5jbGllbnQueCA9PT0gdGhpcy5jb29yZHMucHJldi5jbGllbnQueCAmJiB0aGlzLmNvb3Jkcy5jdXIuY2xpZW50LnkgPT09IHRoaXMuY29vcmRzLnByZXYuY2xpZW50Lnk7XG4gICAgICAgIHRoaXMucG9pbnRlcklzRG93biAmJiAhdGhpcy5wb2ludGVyV2FzTW92ZWQgJiYgKG8gPSB0aGlzLmNvb3Jkcy5jdXIuY2xpZW50LnggLSB0aGlzLmNvb3Jkcy5zdGFydC5jbGllbnQueCwgbCA9IHRoaXMuY29vcmRzLmN1ci5jbGllbnQueSAtIHRoaXMuY29vcmRzLnN0YXJ0LmNsaWVudC55LCB0aGlzLnBvaW50ZXJXYXNNb3ZlZCA9IEdlKG8sIGwpID4gdGhpcy5wb2ludGVyTW92ZVRvbGVyYW5jZSk7XG4gICAgICAgIHZhciBwLCBoLCBnLCBkID0gdGhpcy5nZXRQb2ludGVySW5kZXgoZSksIGIgPSB7IHBvaW50ZXI6IGUsIHBvaW50ZXJJbmRleDogZCwgcG9pbnRlckluZm86IHRoaXMucG9pbnRlcnNbZF0sIGV2ZW50OiByLCB0eXBlOiBcIm1vdmVcIiwgZXZlbnRUYXJnZXQ6IG4sIGR4OiBvLCBkeTogbCwgZHVwbGljYXRlOiBjLCBpbnRlcmFjdGlvbjogdGhpcyB9O1xuICAgICAgICBjIHx8IChwID0gdGhpcy5jb29yZHMudmVsb2NpdHksIGggPSB0aGlzLmNvb3Jkcy5kZWx0YSwgZyA9IE1hdGgubWF4KGgudGltZVN0YW1wIC8gMWUzLCAxZS0zKSwgcC5wYWdlLnggPSBoLnBhZ2UueCAvIGcsIHAucGFnZS55ID0gaC5wYWdlLnkgLyBnLCBwLmNsaWVudC54ID0gaC5jbGllbnQueCAvIGcsIHAuY2xpZW50LnkgPSBoLmNsaWVudC55IC8gZywgcC50aW1lU3RhbXAgPSBnKSwgdGhpcy5fc2NvcGVGaXJlKFwiaW50ZXJhY3Rpb25zOm1vdmVcIiwgYiksIGMgfHwgdGhpcy5zaW11bGF0aW9uIHx8ICh0aGlzLmludGVyYWN0aW5nKCkgJiYgKGIudHlwZSA9IG51bGwsIHRoaXMubW92ZShiKSksIHRoaXMucG9pbnRlcldhc01vdmVkICYmIGF0KHRoaXMuY29vcmRzLnByZXYsIHRoaXMuY29vcmRzLmN1cikpO1xuICAgICAgfSB9LCB7IGtleTogXCJtb3ZlXCIsIHZhbHVlOiBmdW5jdGlvbihlKSB7XG4gICAgICAgIGUgJiYgZS5ldmVudCB8fCBWcih0aGlzLmNvb3Jkcy5kZWx0YSksIChlID0gVyh7IHBvaW50ZXI6IHRoaXMuX2xhdGVzdFBvaW50ZXIucG9pbnRlciwgZXZlbnQ6IHRoaXMuX2xhdGVzdFBvaW50ZXIuZXZlbnQsIGV2ZW50VGFyZ2V0OiB0aGlzLl9sYXRlc3RQb2ludGVyLmV2ZW50VGFyZ2V0LCBpbnRlcmFjdGlvbjogdGhpcyB9LCBlIHx8IHt9KSkucGhhc2UgPSBcIm1vdmVcIiwgdGhpcy5fZG9QaGFzZShlKTtcbiAgICAgIH0gfSwgeyBrZXk6IFwicG9pbnRlclVwXCIsIHZhbHVlOiBmdW5jdGlvbihlLCByLCBuLCBvKSB7XG4gICAgICAgIHZhciBsID0gdGhpcy5nZXRQb2ludGVySW5kZXgoZSk7XG4gICAgICAgIGwgPT09IC0xICYmIChsID0gdGhpcy51cGRhdGVQb2ludGVyKGUsIHIsIG4sICExKSk7XG4gICAgICAgIHZhciBjID0gL2NhbmNlbCQvaS50ZXN0KHIudHlwZSkgPyBcImNhbmNlbFwiIDogXCJ1cFwiO1xuICAgICAgICB0aGlzLl9zY29wZUZpcmUoXCJpbnRlcmFjdGlvbnM6XCIuY29uY2F0KGMpLCB7IHBvaW50ZXI6IGUsIHBvaW50ZXJJbmRleDogbCwgcG9pbnRlckluZm86IHRoaXMucG9pbnRlcnNbbF0sIGV2ZW50OiByLCBldmVudFRhcmdldDogbiwgdHlwZTogYywgY3VyRXZlbnRUYXJnZXQ6IG8sIGludGVyYWN0aW9uOiB0aGlzIH0pLCB0aGlzLnNpbXVsYXRpb24gfHwgdGhpcy5lbmQociksIHRoaXMucmVtb3ZlUG9pbnRlcihlLCByKTtcbiAgICAgIH0gfSwgeyBrZXk6IFwiZG9jdW1lbnRCbHVyXCIsIHZhbHVlOiBmdW5jdGlvbihlKSB7XG4gICAgICAgIHRoaXMuZW5kKGUpLCB0aGlzLl9zY29wZUZpcmUoXCJpbnRlcmFjdGlvbnM6Ymx1clwiLCB7IGV2ZW50OiBlLCB0eXBlOiBcImJsdXJcIiwgaW50ZXJhY3Rpb246IHRoaXMgfSk7XG4gICAgICB9IH0sIHsga2V5OiBcImVuZFwiLCB2YWx1ZTogZnVuY3Rpb24oZSkge1xuICAgICAgICB2YXIgcjtcbiAgICAgICAgdGhpcy5fZW5kaW5nID0gITAsIGUgPSBlIHx8IHRoaXMuX2xhdGVzdFBvaW50ZXIuZXZlbnQsIHRoaXMuaW50ZXJhY3RpbmcoKSAmJiAociA9IHRoaXMuX2RvUGhhc2UoeyBldmVudDogZSwgaW50ZXJhY3Rpb246IHRoaXMsIHBoYXNlOiBcImVuZFwiIH0pKSwgdGhpcy5fZW5kaW5nID0gITEsIHIgPT09ICEwICYmIHRoaXMuc3RvcCgpO1xuICAgICAgfSB9LCB7IGtleTogXCJjdXJyZW50QWN0aW9uXCIsIHZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2ludGVyYWN0aW5nID8gdGhpcy5wcmVwYXJlZC5uYW1lIDogbnVsbDtcbiAgICAgIH0gfSwgeyBrZXk6IFwiaW50ZXJhY3RpbmdcIiwgdmFsdWU6IGZ1bmN0aW9uKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5faW50ZXJhY3Rpbmc7XG4gICAgICB9IH0sIHsga2V5OiBcInN0b3BcIiwgdmFsdWU6IGZ1bmN0aW9uKCkge1xuICAgICAgICB0aGlzLl9zY29wZUZpcmUoXCJpbnRlcmFjdGlvbnM6c3RvcFwiLCB7IGludGVyYWN0aW9uOiB0aGlzIH0pLCB0aGlzLmludGVyYWN0YWJsZSA9IHRoaXMuZWxlbWVudCA9IG51bGwsIHRoaXMuX2ludGVyYWN0aW5nID0gITEsIHRoaXMuX3N0b3BwZWQgPSAhMCwgdGhpcy5wcmVwYXJlZC5uYW1lID0gdGhpcy5wcmV2RXZlbnQgPSBudWxsO1xuICAgICAgfSB9LCB7IGtleTogXCJnZXRQb2ludGVySW5kZXhcIiwgdmFsdWU6IGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgdmFyIHIgPSBZZShlKTtcbiAgICAgICAgcmV0dXJuIHRoaXMucG9pbnRlclR5cGUgPT09IFwibW91c2VcIiB8fCB0aGlzLnBvaW50ZXJUeXBlID09PSBcInBlblwiID8gdGhpcy5wb2ludGVycy5sZW5ndGggLSAxIDogS2UodGhpcy5wb2ludGVycywgZnVuY3Rpb24obikge1xuICAgICAgICAgIHJldHVybiBuLmlkID09PSByO1xuICAgICAgICB9KTtcbiAgICAgIH0gfSwgeyBrZXk6IFwiZ2V0UG9pbnRlckluZm9cIiwgdmFsdWU6IGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucG9pbnRlcnNbdGhpcy5nZXRQb2ludGVySW5kZXgoZSldO1xuICAgICAgfSB9LCB7IGtleTogXCJ1cGRhdGVQb2ludGVyXCIsIHZhbHVlOiBmdW5jdGlvbihlLCByLCBuLCBvKSB7XG4gICAgICAgIHZhciBsLCBjLCBwLCBoID0gWWUoZSksIGcgPSB0aGlzLmdldFBvaW50ZXJJbmRleChlKSwgZCA9IHRoaXMucG9pbnRlcnNbZ107XG4gICAgICAgIHJldHVybiBvID0gbyAhPT0gITEgJiYgKG8gfHwgLyhkb3dufHN0YXJ0KSQvaS50ZXN0KHIudHlwZSkpLCBkID8gZC5wb2ludGVyID0gZSA6IChkID0gbmV3IFBvKGgsIGUsIHIsIG51bGwsIG51bGwpLCBnID0gdGhpcy5wb2ludGVycy5sZW5ndGgsIHRoaXMucG9pbnRlcnMucHVzaChkKSksIGFvKHRoaXMuY29vcmRzLmN1ciwgdGhpcy5wb2ludGVycy5tYXAoZnVuY3Rpb24oYikge1xuICAgICAgICAgIHJldHVybiBiLnBvaW50ZXI7XG4gICAgICAgIH0pLCB0aGlzLl9ub3coKSksIGwgPSB0aGlzLmNvb3Jkcy5kZWx0YSwgYyA9IHRoaXMuY29vcmRzLnByZXYsIHAgPSB0aGlzLmNvb3Jkcy5jdXIsIGwucGFnZS54ID0gcC5wYWdlLnggLSBjLnBhZ2UueCwgbC5wYWdlLnkgPSBwLnBhZ2UueSAtIGMucGFnZS55LCBsLmNsaWVudC54ID0gcC5jbGllbnQueCAtIGMuY2xpZW50LngsIGwuY2xpZW50LnkgPSBwLmNsaWVudC55IC0gYy5jbGllbnQueSwgbC50aW1lU3RhbXAgPSBwLnRpbWVTdGFtcCAtIGMudGltZVN0YW1wLCBvICYmICh0aGlzLnBvaW50ZXJJc0Rvd24gPSAhMCwgZC5kb3duVGltZSA9IHRoaXMuY29vcmRzLmN1ci50aW1lU3RhbXAsIGQuZG93blRhcmdldCA9IG4sIHN0KHRoaXMuZG93blBvaW50ZXIsIGUpLCB0aGlzLmludGVyYWN0aW5nKCkgfHwgKGF0KHRoaXMuY29vcmRzLnN0YXJ0LCB0aGlzLmNvb3Jkcy5jdXIpLCBhdCh0aGlzLmNvb3Jkcy5wcmV2LCB0aGlzLmNvb3Jkcy5jdXIpLCB0aGlzLmRvd25FdmVudCA9IHIsIHRoaXMucG9pbnRlcldhc01vdmVkID0gITEpKSwgdGhpcy5fdXBkYXRlTGF0ZXN0UG9pbnRlcihlLCByLCBuKSwgdGhpcy5fc2NvcGVGaXJlKFwiaW50ZXJhY3Rpb25zOnVwZGF0ZS1wb2ludGVyXCIsIHsgcG9pbnRlcjogZSwgZXZlbnQ6IHIsIGV2ZW50VGFyZ2V0OiBuLCBkb3duOiBvLCBwb2ludGVySW5mbzogZCwgcG9pbnRlckluZGV4OiBnLCBpbnRlcmFjdGlvbjogdGhpcyB9KSwgZztcbiAgICAgIH0gfSwgeyBrZXk6IFwicmVtb3ZlUG9pbnRlclwiLCB2YWx1ZTogZnVuY3Rpb24oZSwgcikge1xuICAgICAgICB2YXIgbiA9IHRoaXMuZ2V0UG9pbnRlckluZGV4KGUpO1xuICAgICAgICBpZiAobiAhPT0gLTEpIHtcbiAgICAgICAgICB2YXIgbyA9IHRoaXMucG9pbnRlcnNbbl07XG4gICAgICAgICAgdGhpcy5fc2NvcGVGaXJlKFwiaW50ZXJhY3Rpb25zOnJlbW92ZS1wb2ludGVyXCIsIHsgcG9pbnRlcjogZSwgZXZlbnQ6IHIsIGV2ZW50VGFyZ2V0OiBudWxsLCBwb2ludGVySW5kZXg6IG4sIHBvaW50ZXJJbmZvOiBvLCBpbnRlcmFjdGlvbjogdGhpcyB9KSwgdGhpcy5wb2ludGVycy5zcGxpY2UobiwgMSksIHRoaXMucG9pbnRlcklzRG93biA9ICExO1xuICAgICAgICB9XG4gICAgICB9IH0sIHsga2V5OiBcIl91cGRhdGVMYXRlc3RQb2ludGVyXCIsIHZhbHVlOiBmdW5jdGlvbihlLCByLCBuKSB7XG4gICAgICAgIHRoaXMuX2xhdGVzdFBvaW50ZXIucG9pbnRlciA9IGUsIHRoaXMuX2xhdGVzdFBvaW50ZXIuZXZlbnQgPSByLCB0aGlzLl9sYXRlc3RQb2ludGVyLmV2ZW50VGFyZ2V0ID0gbjtcbiAgICAgIH0gfSwgeyBrZXk6IFwiZGVzdHJveVwiLCB2YWx1ZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMuX2xhdGVzdFBvaW50ZXIucG9pbnRlciA9IG51bGwsIHRoaXMuX2xhdGVzdFBvaW50ZXIuZXZlbnQgPSBudWxsLCB0aGlzLl9sYXRlc3RQb2ludGVyLmV2ZW50VGFyZ2V0ID0gbnVsbDtcbiAgICAgIH0gfSwgeyBrZXk6IFwiX2NyZWF0ZVByZXBhcmVkRXZlbnRcIiwgdmFsdWU6IGZ1bmN0aW9uKGUsIHIsIG4sIG8pIHtcbiAgICAgICAgcmV0dXJuIG5ldyBvcih0aGlzLCBlLCB0aGlzLnByZXBhcmVkLm5hbWUsIHIsIHRoaXMuZWxlbWVudCwgbiwgbyk7XG4gICAgICB9IH0sIHsga2V5OiBcIl9maXJlRXZlbnRcIiwgdmFsdWU6IGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgdmFyIHI7XG4gICAgICAgIChyID0gdGhpcy5pbnRlcmFjdGFibGUpID09IG51bGwgfHwgci5maXJlKGUpLCAoIXRoaXMucHJldkV2ZW50IHx8IGUudGltZVN0YW1wID49IHRoaXMucHJldkV2ZW50LnRpbWVTdGFtcCkgJiYgKHRoaXMucHJldkV2ZW50ID0gZSk7XG4gICAgICB9IH0sIHsga2V5OiBcIl9kb1BoYXNlXCIsIHZhbHVlOiBmdW5jdGlvbihlKSB7XG4gICAgICAgIHZhciByID0gZS5ldmVudCwgbiA9IGUucGhhc2UsIG8gPSBlLnByZUVuZCwgbCA9IGUudHlwZSwgYyA9IHRoaXMucmVjdDtcbiAgICAgICAgaWYgKGMgJiYgbiA9PT0gXCJtb3ZlXCIgJiYgKG90KHRoaXMuZWRnZXMsIGMsIHRoaXMuY29vcmRzLmRlbHRhW3RoaXMuaW50ZXJhY3RhYmxlLm9wdGlvbnMuZGVsdGFTb3VyY2VdKSwgYy53aWR0aCA9IGMucmlnaHQgLSBjLmxlZnQsIGMuaGVpZ2h0ID0gYy5ib3R0b20gLSBjLnRvcCksIHRoaXMuX3Njb3BlRmlyZShcImludGVyYWN0aW9uczpiZWZvcmUtYWN0aW9uLVwiLmNvbmNhdChuKSwgZSkgPT09ICExKSByZXR1cm4gITE7XG4gICAgICAgIHZhciBwID0gZS5pRXZlbnQgPSB0aGlzLl9jcmVhdGVQcmVwYXJlZEV2ZW50KHIsIG4sIG8sIGwpO1xuICAgICAgICByZXR1cm4gdGhpcy5fc2NvcGVGaXJlKFwiaW50ZXJhY3Rpb25zOmFjdGlvbi1cIi5jb25jYXQobiksIGUpLCBuID09PSBcInN0YXJ0XCIgJiYgKHRoaXMucHJldkV2ZW50ID0gcCksIHRoaXMuX2ZpcmVFdmVudChwKSwgdGhpcy5fc2NvcGVGaXJlKFwiaW50ZXJhY3Rpb25zOmFmdGVyLWFjdGlvbi1cIi5jb25jYXQobiksIGUpLCAhMDtcbiAgICAgIH0gfSwgeyBrZXk6IFwiX25vd1wiLCB2YWx1ZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIHJldHVybiBEYXRlLm5vdygpO1xuICAgICAgfSB9XSksIHQ7XG4gICAgfSgpO1xuICAgIGZ1bmN0aW9uIHduKHQpIHtcbiAgICAgIHhuKHQuaW50ZXJhY3Rpb24pO1xuICAgIH1cbiAgICBmdW5jdGlvbiB4bih0KSB7XG4gICAgICBpZiAoIWZ1bmN0aW9uKHIpIHtcbiAgICAgICAgcmV0dXJuICEoIXIub2Zmc2V0LnBlbmRpbmcueCAmJiAhci5vZmZzZXQucGVuZGluZy55KTtcbiAgICAgIH0odCkpIHJldHVybiAhMTtcbiAgICAgIHZhciBlID0gdC5vZmZzZXQucGVuZGluZztcbiAgICAgIHJldHVybiBzcih0LmNvb3Jkcy5jdXIsIGUpLCBzcih0LmNvb3Jkcy5kZWx0YSwgZSksIG90KHQuZWRnZXMsIHQucmVjdCwgZSksIGUueCA9IDAsIGUueSA9IDAsICEwO1xuICAgIH1cbiAgICBmdW5jdGlvbiBEbyh0KSB7XG4gICAgICB2YXIgZSA9IHQueCwgciA9IHQueTtcbiAgICAgIHRoaXMub2Zmc2V0LnBlbmRpbmcueCArPSBlLCB0aGlzLm9mZnNldC5wZW5kaW5nLnkgKz0gciwgdGhpcy5vZmZzZXQudG90YWwueCArPSBlLCB0aGlzLm9mZnNldC50b3RhbC55ICs9IHI7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHNyKHQsIGUpIHtcbiAgICAgIHZhciByID0gdC5wYWdlLCBuID0gdC5jbGllbnQsIG8gPSBlLngsIGwgPSBlLnk7XG4gICAgICByLnggKz0gbywgci55ICs9IGwsIG4ueCArPSBvLCBuLnkgKz0gbDtcbiAgICB9XG4gICAgVG4ub2Zmc2V0QnkgPSBcIlwiO1xuICAgIHZhciBrbyA9IHsgaWQ6IFwib2Zmc2V0XCIsIGJlZm9yZTogW1wibW9kaWZpZXJzXCIsIFwicG9pbnRlci1ldmVudHNcIiwgXCJhY3Rpb25zXCIsIFwiaW5lcnRpYVwiXSwgaW5zdGFsbDogZnVuY3Rpb24odCkge1xuICAgICAgdC5JbnRlcmFjdGlvbi5wcm90b3R5cGUub2Zmc2V0QnkgPSBEbztcbiAgICB9LCBsaXN0ZW5lcnM6IHsgXCJpbnRlcmFjdGlvbnM6bmV3XCI6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHQuaW50ZXJhY3Rpb24ub2Zmc2V0ID0geyB0b3RhbDogeyB4OiAwLCB5OiAwIH0sIHBlbmRpbmc6IHsgeDogMCwgeTogMCB9IH07XG4gICAgfSwgXCJpbnRlcmFjdGlvbnM6dXBkYXRlLXBvaW50ZXJcIjogZnVuY3Rpb24odCkge1xuICAgICAgcmV0dXJuIGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgZS5wb2ludGVySXNEb3duICYmIChzcihlLmNvb3Jkcy5jdXIsIGUub2Zmc2V0LnRvdGFsKSwgZS5vZmZzZXQucGVuZGluZy54ID0gMCwgZS5vZmZzZXQucGVuZGluZy55ID0gMCk7XG4gICAgICB9KHQuaW50ZXJhY3Rpb24pO1xuICAgIH0sIFwiaW50ZXJhY3Rpb25zOmJlZm9yZS1hY3Rpb24tc3RhcnRcIjogd24sIFwiaW50ZXJhY3Rpb25zOmJlZm9yZS1hY3Rpb24tbW92ZVwiOiB3biwgXCJpbnRlcmFjdGlvbnM6YmVmb3JlLWFjdGlvbi1lbmRcIjogZnVuY3Rpb24odCkge1xuICAgICAgdmFyIGUgPSB0LmludGVyYWN0aW9uO1xuICAgICAgaWYgKHhuKGUpKSByZXR1cm4gZS5tb3ZlKHsgb2Zmc2V0OiAhMCB9KSwgZS5lbmQoKSwgITE7XG4gICAgfSwgXCJpbnRlcmFjdGlvbnM6c3RvcFwiOiBmdW5jdGlvbih0KSB7XG4gICAgICB2YXIgZSA9IHQuaW50ZXJhY3Rpb247XG4gICAgICBlLm9mZnNldC50b3RhbC54ID0gMCwgZS5vZmZzZXQudG90YWwueSA9IDAsIGUub2Zmc2V0LnBlbmRpbmcueCA9IDAsIGUub2Zmc2V0LnBlbmRpbmcueSA9IDA7XG4gICAgfSB9IH0sIFNuID0ga28sIHpvID0gZnVuY3Rpb24oKSB7XG4gICAgICBmdW5jdGlvbiB0KGUpIHtcbiAgICAgICAgZih0aGlzLCB0KSwgdGhpcy5hY3RpdmUgPSAhMSwgdGhpcy5pc01vZGlmaWVkID0gITEsIHRoaXMuc21vb3RoRW5kID0gITEsIHRoaXMuYWxsb3dSZXN1bWUgPSAhMSwgdGhpcy5tb2RpZmljYXRpb24gPSB2b2lkIDAsIHRoaXMubW9kaWZpZXJDb3VudCA9IDAsIHRoaXMubW9kaWZpZXJBcmcgPSB2b2lkIDAsIHRoaXMuc3RhcnRDb29yZHMgPSB2b2lkIDAsIHRoaXMudDAgPSAwLCB0aGlzLnYwID0gMCwgdGhpcy50ZSA9IDAsIHRoaXMudGFyZ2V0T2Zmc2V0ID0gdm9pZCAwLCB0aGlzLm1vZGlmaWVkT2Zmc2V0ID0gdm9pZCAwLCB0aGlzLmN1cnJlbnRPZmZzZXQgPSB2b2lkIDAsIHRoaXMubGFtYmRhX3YwID0gMCwgdGhpcy5vbmVfdmVfdjAgPSAwLCB0aGlzLnRpbWVvdXQgPSB2b2lkIDAsIHRoaXMuaW50ZXJhY3Rpb24gPSB2b2lkIDAsIHRoaXMuaW50ZXJhY3Rpb24gPSBlO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHkodCwgW3sga2V5OiBcInN0YXJ0XCIsIHZhbHVlOiBmdW5jdGlvbihlKSB7XG4gICAgICAgIHZhciByID0gdGhpcy5pbnRlcmFjdGlvbiwgbiA9IGR0KHIpO1xuICAgICAgICBpZiAoIW4gfHwgIW4uZW5hYmxlZCkgcmV0dXJuICExO1xuICAgICAgICB2YXIgbyA9IHIuY29vcmRzLnZlbG9jaXR5LmNsaWVudCwgbCA9IEdlKG8ueCwgby55KSwgYyA9IHRoaXMubW9kaWZpY2F0aW9uIHx8ICh0aGlzLm1vZGlmaWNhdGlvbiA9IG5ldyBpcihyKSk7XG4gICAgICAgIGlmIChjLmNvcHlGcm9tKHIubW9kaWZpY2F0aW9uKSwgdGhpcy50MCA9IHIuX25vdygpLCB0aGlzLmFsbG93UmVzdW1lID0gbi5hbGxvd1Jlc3VtZSwgdGhpcy52MCA9IGwsIHRoaXMuY3VycmVudE9mZnNldCA9IHsgeDogMCwgeTogMCB9LCB0aGlzLnN0YXJ0Q29vcmRzID0gci5jb29yZHMuY3VyLnBhZ2UsIHRoaXMubW9kaWZpZXJBcmcgPSBjLmZpbGxBcmcoeyBwYWdlQ29vcmRzOiB0aGlzLnN0YXJ0Q29vcmRzLCBwcmVFbmQ6ICEwLCBwaGFzZTogXCJpbmVydGlhc3RhcnRcIiB9KSwgdGhpcy50MCAtIHIuY29vcmRzLmN1ci50aW1lU3RhbXAgPCA1MCAmJiBsID4gbi5taW5TcGVlZCAmJiBsID4gbi5lbmRTcGVlZCkgdGhpcy5zdGFydEluZXJ0aWEoKTtcbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgaWYgKGMucmVzdWx0ID0gYy5zZXRBbGwodGhpcy5tb2RpZmllckFyZyksICFjLnJlc3VsdC5jaGFuZ2VkKSByZXR1cm4gITE7XG4gICAgICAgICAgdGhpcy5zdGFydFNtb290aEVuZCgpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByLm1vZGlmaWNhdGlvbi5yZXN1bHQucmVjdCA9IG51bGwsIHIub2Zmc2V0QnkodGhpcy50YXJnZXRPZmZzZXQpLCByLl9kb1BoYXNlKHsgaW50ZXJhY3Rpb246IHIsIGV2ZW50OiBlLCBwaGFzZTogXCJpbmVydGlhc3RhcnRcIiB9KSwgci5vZmZzZXRCeSh7IHg6IC10aGlzLnRhcmdldE9mZnNldC54LCB5OiAtdGhpcy50YXJnZXRPZmZzZXQueSB9KSwgci5tb2RpZmljYXRpb24ucmVzdWx0LnJlY3QgPSBudWxsLCB0aGlzLmFjdGl2ZSA9ICEwLCByLnNpbXVsYXRpb24gPSB0aGlzLCAhMDtcbiAgICAgIH0gfSwgeyBrZXk6IFwic3RhcnRJbmVydGlhXCIsIHZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIGUgPSB0aGlzLCByID0gdGhpcy5pbnRlcmFjdGlvbi5jb29yZHMudmVsb2NpdHkuY2xpZW50LCBuID0gZHQodGhpcy5pbnRlcmFjdGlvbiksIG8gPSBuLnJlc2lzdGFuY2UsIGwgPSAtTWF0aC5sb2cobi5lbmRTcGVlZCAvIHRoaXMudjApIC8gbztcbiAgICAgICAgdGhpcy50YXJnZXRPZmZzZXQgPSB7IHg6IChyLnggLSBsKSAvIG8sIHk6IChyLnkgLSBsKSAvIG8gfSwgdGhpcy50ZSA9IGwsIHRoaXMubGFtYmRhX3YwID0gbyAvIHRoaXMudjAsIHRoaXMub25lX3ZlX3YwID0gMSAtIG4uZW5kU3BlZWQgLyB0aGlzLnYwO1xuICAgICAgICB2YXIgYyA9IHRoaXMubW9kaWZpY2F0aW9uLCBwID0gdGhpcy5tb2RpZmllckFyZztcbiAgICAgICAgcC5wYWdlQ29vcmRzID0geyB4OiB0aGlzLnN0YXJ0Q29vcmRzLnggKyB0aGlzLnRhcmdldE9mZnNldC54LCB5OiB0aGlzLnN0YXJ0Q29vcmRzLnkgKyB0aGlzLnRhcmdldE9mZnNldC55IH0sIGMucmVzdWx0ID0gYy5zZXRBbGwocCksIGMucmVzdWx0LmNoYW5nZWQgJiYgKHRoaXMuaXNNb2RpZmllZCA9ICEwLCB0aGlzLm1vZGlmaWVkT2Zmc2V0ID0geyB4OiB0aGlzLnRhcmdldE9mZnNldC54ICsgYy5yZXN1bHQuZGVsdGEueCwgeTogdGhpcy50YXJnZXRPZmZzZXQueSArIGMucmVzdWx0LmRlbHRhLnkgfSksIHRoaXMub25OZXh0RnJhbWUoZnVuY3Rpb24oKSB7XG4gICAgICAgICAgcmV0dXJuIGUuaW5lcnRpYVRpY2soKTtcbiAgICAgICAgfSk7XG4gICAgICB9IH0sIHsga2V5OiBcInN0YXJ0U21vb3RoRW5kXCIsIHZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIGUgPSB0aGlzO1xuICAgICAgICB0aGlzLnNtb290aEVuZCA9ICEwLCB0aGlzLmlzTW9kaWZpZWQgPSAhMCwgdGhpcy50YXJnZXRPZmZzZXQgPSB7IHg6IHRoaXMubW9kaWZpY2F0aW9uLnJlc3VsdC5kZWx0YS54LCB5OiB0aGlzLm1vZGlmaWNhdGlvbi5yZXN1bHQuZGVsdGEueSB9LCB0aGlzLm9uTmV4dEZyYW1lKGZ1bmN0aW9uKCkge1xuICAgICAgICAgIHJldHVybiBlLnNtb290aEVuZFRpY2soKTtcbiAgICAgICAgfSk7XG4gICAgICB9IH0sIHsga2V5OiBcIm9uTmV4dEZyYW1lXCIsIHZhbHVlOiBmdW5jdGlvbihlKSB7XG4gICAgICAgIHZhciByID0gdGhpcztcbiAgICAgICAgdGhpcy50aW1lb3V0ID0gYmUucmVxdWVzdChmdW5jdGlvbigpIHtcbiAgICAgICAgICByLmFjdGl2ZSAmJiBlKCk7XG4gICAgICAgIH0pO1xuICAgICAgfSB9LCB7IGtleTogXCJpbmVydGlhVGlja1wiLCB2YWx1ZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIHZhciBlLCByLCBuLCBvLCBsLCBjLCBwLCBoID0gdGhpcywgZyA9IHRoaXMuaW50ZXJhY3Rpb24sIGQgPSBkdChnKS5yZXNpc3RhbmNlLCBiID0gKGcuX25vdygpIC0gdGhpcy50MCkgLyAxZTM7XG4gICAgICAgIGlmIChiIDwgdGhpcy50ZSkge1xuICAgICAgICAgIHZhciB4LCBJID0gMSAtIChNYXRoLmV4cCgtZCAqIGIpIC0gdGhpcy5sYW1iZGFfdjApIC8gdGhpcy5vbmVfdmVfdjA7XG4gICAgICAgICAgdGhpcy5pc01vZGlmaWVkID8gKGUgPSAwLCByID0gMCwgbiA9IHRoaXMudGFyZ2V0T2Zmc2V0LngsIG8gPSB0aGlzLnRhcmdldE9mZnNldC55LCBsID0gdGhpcy5tb2RpZmllZE9mZnNldC54LCBjID0gdGhpcy5tb2RpZmllZE9mZnNldC55LCB4ID0geyB4OiBPbihwID0gSSwgZSwgbiwgbCksIHk6IE9uKHAsIHIsIG8sIGMpIH0pIDogeCA9IHsgeDogdGhpcy50YXJnZXRPZmZzZXQueCAqIEksIHk6IHRoaXMudGFyZ2V0T2Zmc2V0LnkgKiBJIH07XG4gICAgICAgICAgdmFyIEUgPSB7IHg6IHgueCAtIHRoaXMuY3VycmVudE9mZnNldC54LCB5OiB4LnkgLSB0aGlzLmN1cnJlbnRPZmZzZXQueSB9O1xuICAgICAgICAgIHRoaXMuY3VycmVudE9mZnNldC54ICs9IEUueCwgdGhpcy5jdXJyZW50T2Zmc2V0LnkgKz0gRS55LCBnLm9mZnNldEJ5KEUpLCBnLm1vdmUoKSwgdGhpcy5vbk5leHRGcmFtZShmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHJldHVybiBoLmluZXJ0aWFUaWNrKCk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSBnLm9mZnNldEJ5KHsgeDogdGhpcy5tb2RpZmllZE9mZnNldC54IC0gdGhpcy5jdXJyZW50T2Zmc2V0LngsIHk6IHRoaXMubW9kaWZpZWRPZmZzZXQueSAtIHRoaXMuY3VycmVudE9mZnNldC55IH0pLCB0aGlzLmVuZCgpO1xuICAgICAgfSB9LCB7IGtleTogXCJzbW9vdGhFbmRUaWNrXCIsIHZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIGUgPSB0aGlzLCByID0gdGhpcy5pbnRlcmFjdGlvbiwgbiA9IHIuX25vdygpIC0gdGhpcy50MCwgbyA9IGR0KHIpLnNtb290aEVuZER1cmF0aW9uO1xuICAgICAgICBpZiAobiA8IG8pIHtcbiAgICAgICAgICB2YXIgbCA9IHsgeDogQ24obiwgMCwgdGhpcy50YXJnZXRPZmZzZXQueCwgbyksIHk6IENuKG4sIDAsIHRoaXMudGFyZ2V0T2Zmc2V0LnksIG8pIH0sIGMgPSB7IHg6IGwueCAtIHRoaXMuY3VycmVudE9mZnNldC54LCB5OiBsLnkgLSB0aGlzLmN1cnJlbnRPZmZzZXQueSB9O1xuICAgICAgICAgIHRoaXMuY3VycmVudE9mZnNldC54ICs9IGMueCwgdGhpcy5jdXJyZW50T2Zmc2V0LnkgKz0gYy55LCByLm9mZnNldEJ5KGMpLCByLm1vdmUoeyBza2lwTW9kaWZpZXJzOiB0aGlzLm1vZGlmaWVyQ291bnQgfSksIHRoaXMub25OZXh0RnJhbWUoZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICByZXR1cm4gZS5zbW9vdGhFbmRUaWNrKCk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSByLm9mZnNldEJ5KHsgeDogdGhpcy50YXJnZXRPZmZzZXQueCAtIHRoaXMuY3VycmVudE9mZnNldC54LCB5OiB0aGlzLnRhcmdldE9mZnNldC55IC0gdGhpcy5jdXJyZW50T2Zmc2V0LnkgfSksIHRoaXMuZW5kKCk7XG4gICAgICB9IH0sIHsga2V5OiBcInJlc3VtZVwiLCB2YWx1ZTogZnVuY3Rpb24oZSkge1xuICAgICAgICB2YXIgciA9IGUucG9pbnRlciwgbiA9IGUuZXZlbnQsIG8gPSBlLmV2ZW50VGFyZ2V0LCBsID0gdGhpcy5pbnRlcmFjdGlvbjtcbiAgICAgICAgbC5vZmZzZXRCeSh7IHg6IC10aGlzLmN1cnJlbnRPZmZzZXQueCwgeTogLXRoaXMuY3VycmVudE9mZnNldC55IH0pLCBsLnVwZGF0ZVBvaW50ZXIociwgbiwgbywgITApLCBsLl9kb1BoYXNlKHsgaW50ZXJhY3Rpb246IGwsIGV2ZW50OiBuLCBwaGFzZTogXCJyZXN1bWVcIiB9KSwgYXQobC5jb29yZHMucHJldiwgbC5jb29yZHMuY3VyKSwgdGhpcy5zdG9wKCk7XG4gICAgICB9IH0sIHsga2V5OiBcImVuZFwiLCB2YWx1ZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMuaW50ZXJhY3Rpb24ubW92ZSgpLCB0aGlzLmludGVyYWN0aW9uLmVuZCgpLCB0aGlzLnN0b3AoKTtcbiAgICAgIH0gfSwgeyBrZXk6IFwic3RvcFwiLCB2YWx1ZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMuYWN0aXZlID0gdGhpcy5zbW9vdGhFbmQgPSAhMSwgdGhpcy5pbnRlcmFjdGlvbi5zaW11bGF0aW9uID0gbnVsbCwgYmUuY2FuY2VsKHRoaXMudGltZW91dCk7XG4gICAgICB9IH1dKSwgdDtcbiAgICB9KCk7XG4gICAgZnVuY3Rpb24gZHQodCkge1xuICAgICAgdmFyIGUgPSB0LmludGVyYWN0YWJsZSwgciA9IHQucHJlcGFyZWQ7XG4gICAgICByZXR1cm4gZSAmJiBlLm9wdGlvbnMgJiYgci5uYW1lICYmIGUub3B0aW9uc1tyLm5hbWVdLmluZXJ0aWE7XG4gICAgfVxuICAgIHZhciAkbyA9IHsgaWQ6IFwiaW5lcnRpYVwiLCBiZWZvcmU6IFtcIm1vZGlmaWVyc1wiLCBcImFjdGlvbnNcIl0sIGluc3RhbGw6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHZhciBlID0gdC5kZWZhdWx0cztcbiAgICAgIHQudXNlUGx1Z2luKFNuKSwgdC51c2VQbHVnaW4oYm4pLCB0LmFjdGlvbnMucGhhc2VzLmluZXJ0aWFzdGFydCA9ICEwLCB0LmFjdGlvbnMucGhhc2VzLnJlc3VtZSA9ICEwLCBlLnBlckFjdGlvbi5pbmVydGlhID0geyBlbmFibGVkOiAhMSwgcmVzaXN0YW5jZTogMTAsIG1pblNwZWVkOiAxMDAsIGVuZFNwZWVkOiAxMCwgYWxsb3dSZXN1bWU6ICEwLCBzbW9vdGhFbmREdXJhdGlvbjogMzAwIH07XG4gICAgfSwgbGlzdGVuZXJzOiB7IFwiaW50ZXJhY3Rpb25zOm5ld1wiOiBmdW5jdGlvbih0KSB7XG4gICAgICB2YXIgZSA9IHQuaW50ZXJhY3Rpb247XG4gICAgICBlLmluZXJ0aWEgPSBuZXcgem8oZSk7XG4gICAgfSwgXCJpbnRlcmFjdGlvbnM6YmVmb3JlLWFjdGlvbi1lbmRcIjogZnVuY3Rpb24odCkge1xuICAgICAgdmFyIGUgPSB0LmludGVyYWN0aW9uLCByID0gdC5ldmVudDtcbiAgICAgIHJldHVybiAoIWUuX2ludGVyYWN0aW5nIHx8IGUuc2ltdWxhdGlvbiB8fCAhZS5pbmVydGlhLnN0YXJ0KHIpKSAmJiBudWxsO1xuICAgIH0sIFwiaW50ZXJhY3Rpb25zOmRvd25cIjogZnVuY3Rpb24odCkge1xuICAgICAgdmFyIGUgPSB0LmludGVyYWN0aW9uLCByID0gdC5ldmVudFRhcmdldCwgbiA9IGUuaW5lcnRpYTtcbiAgICAgIGlmIChuLmFjdGl2ZSkgZm9yICh2YXIgbyA9IHI7IHcuZWxlbWVudChvKTsgKSB7XG4gICAgICAgIGlmIChvID09PSBlLmVsZW1lbnQpIHtcbiAgICAgICAgICBuLnJlc3VtZSh0KTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBvID0gcGUobyk7XG4gICAgICB9XG4gICAgfSwgXCJpbnRlcmFjdGlvbnM6c3RvcFwiOiBmdW5jdGlvbih0KSB7XG4gICAgICB2YXIgZSA9IHQuaW50ZXJhY3Rpb24uaW5lcnRpYTtcbiAgICAgIGUuYWN0aXZlICYmIGUuc3RvcCgpO1xuICAgIH0sIFwiaW50ZXJhY3Rpb25zOmJlZm9yZS1hY3Rpb24tcmVzdW1lXCI6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHZhciBlID0gdC5pbnRlcmFjdGlvbi5tb2RpZmljYXRpb247XG4gICAgICBlLnN0b3AodCksIGUuc3RhcnQodCwgdC5pbnRlcmFjdGlvbi5jb29yZHMuY3VyLnBhZ2UpLCBlLmFwcGx5VG9JbnRlcmFjdGlvbih0KTtcbiAgICB9LCBcImludGVyYWN0aW9uczpiZWZvcmUtYWN0aW9uLWluZXJ0aWFzdGFydFwiOiBmdW5jdGlvbih0KSB7XG4gICAgICByZXR1cm4gdC5pbnRlcmFjdGlvbi5tb2RpZmljYXRpb24uc2V0QW5kQXBwbHkodCk7XG4gICAgfSwgXCJpbnRlcmFjdGlvbnM6YWN0aW9uLXJlc3VtZVwiOiBWZSwgXCJpbnRlcmFjdGlvbnM6YWN0aW9uLWluZXJ0aWFzdGFydFwiOiBWZSwgXCJpbnRlcmFjdGlvbnM6YWZ0ZXItYWN0aW9uLWluZXJ0aWFzdGFydFwiOiBmdW5jdGlvbih0KSB7XG4gICAgICByZXR1cm4gdC5pbnRlcmFjdGlvbi5tb2RpZmljYXRpb24ucmVzdG9yZUludGVyYWN0aW9uQ29vcmRzKHQpO1xuICAgIH0sIFwiaW50ZXJhY3Rpb25zOmFmdGVyLWFjdGlvbi1yZXN1bWVcIjogZnVuY3Rpb24odCkge1xuICAgICAgcmV0dXJuIHQuaW50ZXJhY3Rpb24ubW9kaWZpY2F0aW9uLnJlc3RvcmVJbnRlcmFjdGlvbkNvb3Jkcyh0KTtcbiAgICB9IH0gfTtcbiAgICBmdW5jdGlvbiBPbih0LCBlLCByLCBuKSB7XG4gICAgICB2YXIgbyA9IDEgLSB0O1xuICAgICAgcmV0dXJuIG8gKiBvICogZSArIDIgKiBvICogdCAqIHIgKyB0ICogdCAqIG47XG4gICAgfVxuICAgIGZ1bmN0aW9uIENuKHQsIGUsIHIsIG4pIHtcbiAgICAgIHJldHVybiAtciAqICh0IC89IG4pICogKHQgLSAyKSArIGU7XG4gICAgfVxuICAgIHZhciBqbyA9ICRvO1xuICAgIGZ1bmN0aW9uIEVuKHQsIGUpIHtcbiAgICAgIGZvciAodmFyIHIgPSAwOyByIDwgZS5sZW5ndGg7IHIrKykge1xuICAgICAgICB2YXIgbiA9IGVbcl07XG4gICAgICAgIGlmICh0LmltbWVkaWF0ZVByb3BhZ2F0aW9uU3RvcHBlZCkgYnJlYWs7XG4gICAgICAgIG4odCk7XG4gICAgICB9XG4gICAgfVxuICAgIHZhciBfbiA9IGZ1bmN0aW9uKCkge1xuICAgICAgZnVuY3Rpb24gdChlKSB7XG4gICAgICAgIGYodGhpcywgdCksIHRoaXMub3B0aW9ucyA9IHZvaWQgMCwgdGhpcy50eXBlcyA9IHt9LCB0aGlzLnByb3BhZ2F0aW9uU3RvcHBlZCA9ICExLCB0aGlzLmltbWVkaWF0ZVByb3BhZ2F0aW9uU3RvcHBlZCA9ICExLCB0aGlzLmdsb2JhbCA9IHZvaWQgMCwgdGhpcy5vcHRpb25zID0gVyh7fSwgZSB8fCB7fSk7XG4gICAgICB9XG4gICAgICByZXR1cm4geSh0LCBbeyBrZXk6IFwiZmlyZVwiLCB2YWx1ZTogZnVuY3Rpb24oZSkge1xuICAgICAgICB2YXIgciwgbiA9IHRoaXMuZ2xvYmFsO1xuICAgICAgICAociA9IHRoaXMudHlwZXNbZS50eXBlXSkgJiYgRW4oZSwgciksICFlLnByb3BhZ2F0aW9uU3RvcHBlZCAmJiBuICYmIChyID0gbltlLnR5cGVdKSAmJiBFbihlLCByKTtcbiAgICAgIH0gfSwgeyBrZXk6IFwib25cIiwgdmFsdWU6IGZ1bmN0aW9uKGUsIHIpIHtcbiAgICAgICAgdmFyIG4gPSBPZShlLCByKTtcbiAgICAgICAgZm9yIChlIGluIG4pIHRoaXMudHlwZXNbZV0gPSB0bih0aGlzLnR5cGVzW2VdIHx8IFtdLCBuW2VdKTtcbiAgICAgIH0gfSwgeyBrZXk6IFwib2ZmXCIsIHZhbHVlOiBmdW5jdGlvbihlLCByKSB7XG4gICAgICAgIHZhciBuID0gT2UoZSwgcik7XG4gICAgICAgIGZvciAoZSBpbiBuKSB7XG4gICAgICAgICAgdmFyIG8gPSB0aGlzLnR5cGVzW2VdO1xuICAgICAgICAgIGlmIChvICYmIG8ubGVuZ3RoKSBmb3IgKHZhciBsID0gMCwgYyA9IG5bZV07IGwgPCBjLmxlbmd0aDsgbCsrKSB7XG4gICAgICAgICAgICB2YXIgcCA9IGNbbF0sIGggPSBvLmluZGV4T2YocCk7XG4gICAgICAgICAgICBoICE9PSAtMSAmJiBvLnNwbGljZShoLCAxKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0gfSwgeyBrZXk6IFwiZ2V0UmVjdFwiLCB2YWx1ZTogZnVuY3Rpb24oZSkge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH0gfV0pLCB0O1xuICAgIH0oKSwgQW8gPSBmdW5jdGlvbigpIHtcbiAgICAgIGZ1bmN0aW9uIHQoZSkge1xuICAgICAgICBmKHRoaXMsIHQpLCB0aGlzLmN1cnJlbnRUYXJnZXQgPSB2b2lkIDAsIHRoaXMub3JpZ2luYWxFdmVudCA9IHZvaWQgMCwgdGhpcy50eXBlID0gdm9pZCAwLCB0aGlzLm9yaWdpbmFsRXZlbnQgPSBlLCBzdCh0aGlzLCBlKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB5KHQsIFt7IGtleTogXCJwcmV2ZW50T3JpZ2luYWxEZWZhdWx0XCIsIHZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy5vcmlnaW5hbEV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICB9IH0sIHsga2V5OiBcInN0b3BQcm9wYWdhdGlvblwiLCB2YWx1ZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMub3JpZ2luYWxFdmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgIH0gfSwgeyBrZXk6IFwic3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uXCIsIHZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy5vcmlnaW5hbEV2ZW50LnN0b3BJbW1lZGlhdGVQcm9wYWdhdGlvbigpO1xuICAgICAgfSB9XSksIHQ7XG4gICAgfSgpO1xuICAgIGZ1bmN0aW9uIHFlKHQpIHtcbiAgICAgIHJldHVybiB3Lm9iamVjdCh0KSA/IHsgY2FwdHVyZTogISF0LmNhcHR1cmUsIHBhc3NpdmU6ICEhdC5wYXNzaXZlIH0gOiB7IGNhcHR1cmU6ICEhdCwgcGFzc2l2ZTogITEgfTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZnQodCwgZSkge1xuICAgICAgcmV0dXJuIHQgPT09IGUgfHwgKHR5cGVvZiB0ID09IFwiYm9vbGVhblwiID8gISFlLmNhcHR1cmUgPT09IHQgJiYgIWUucGFzc2l2ZSA6ICEhdC5jYXB0dXJlID09ICEhZS5jYXB0dXJlICYmICEhdC5wYXNzaXZlID09ICEhZS5wYXNzaXZlKTtcbiAgICB9XG4gICAgdmFyIExvID0geyBpZDogXCJldmVudHNcIiwgaW5zdGFsbDogZnVuY3Rpb24odCkge1xuICAgICAgdmFyIGUsIHIgPSBbXSwgbiA9IHt9LCBvID0gW10sIGwgPSB7IGFkZDogYywgcmVtb3ZlOiBwLCBhZGREZWxlZ2F0ZTogZnVuY3Rpb24oZCwgYiwgeCwgSSwgRSkge1xuICAgICAgICB2YXIgTSA9IHFlKEUpO1xuICAgICAgICBpZiAoIW5beF0pIHtcbiAgICAgICAgICBuW3hdID0gW107XG4gICAgICAgICAgZm9yICh2YXIgJCA9IDA7ICQgPCBvLmxlbmd0aDsgJCsrKSB7XG4gICAgICAgICAgICB2YXIgeiA9IG9bJF07XG4gICAgICAgICAgICBjKHosIHgsIGgpLCBjKHosIHgsIGcsICEwKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdmFyIEEgPSBuW3hdLCBOID0gWGUoQSwgZnVuY3Rpb24oSykge1xuICAgICAgICAgIHJldHVybiBLLnNlbGVjdG9yID09PSBkICYmIEsuY29udGV4dCA9PT0gYjtcbiAgICAgICAgfSk7XG4gICAgICAgIE4gfHwgKE4gPSB7IHNlbGVjdG9yOiBkLCBjb250ZXh0OiBiLCBsaXN0ZW5lcnM6IFtdIH0sIEEucHVzaChOKSksIE4ubGlzdGVuZXJzLnB1c2goeyBmdW5jOiBJLCBvcHRpb25zOiBNIH0pO1xuICAgICAgfSwgcmVtb3ZlRGVsZWdhdGU6IGZ1bmN0aW9uKGQsIGIsIHgsIEksIEUpIHtcbiAgICAgICAgdmFyIE0sICQgPSBxZShFKSwgeiA9IG5beF0sIEEgPSAhMTtcbiAgICAgICAgaWYgKHopXG4gICAgICAgICAgZm9yIChNID0gei5sZW5ndGggLSAxOyBNID49IDA7IE0tLSkge1xuICAgICAgICAgICAgdmFyIE4gPSB6W01dO1xuICAgICAgICAgICAgaWYgKE4uc2VsZWN0b3IgPT09IGQgJiYgTi5jb250ZXh0ID09PSBiKSB7XG4gICAgICAgICAgICAgIGZvciAodmFyIEsgPSBOLmxpc3RlbmVycywgRiA9IEsubGVuZ3RoIC0gMTsgRiA+PSAwOyBGLS0pIHtcbiAgICAgICAgICAgICAgICB2YXIgRyA9IEtbRl07XG4gICAgICAgICAgICAgICAgaWYgKEcuZnVuYyA9PT0gSSAmJiBmdChHLm9wdGlvbnMsICQpKSB7XG4gICAgICAgICAgICAgICAgICBLLnNwbGljZShGLCAxKSwgSy5sZW5ndGggfHwgKHouc3BsaWNlKE0sIDEpLCBwKGIsIHgsIGgpLCBwKGIsIHgsIGcsICEwKSksIEEgPSAhMDtcbiAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBpZiAoQSkgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgfSwgZGVsZWdhdGVMaXN0ZW5lcjogaCwgZGVsZWdhdGVVc2VDYXB0dXJlOiBnLCBkZWxlZ2F0ZWRFdmVudHM6IG4sIGRvY3VtZW50czogbywgdGFyZ2V0czogciwgc3VwcG9ydHNPcHRpb25zOiAhMSwgc3VwcG9ydHNQYXNzaXZlOiAhMSB9O1xuICAgICAgZnVuY3Rpb24gYyhkLCBiLCB4LCBJKSB7XG4gICAgICAgIGlmIChkLmFkZEV2ZW50TGlzdGVuZXIpIHtcbiAgICAgICAgICB2YXIgRSA9IHFlKEkpLCBNID0gWGUociwgZnVuY3Rpb24oJCkge1xuICAgICAgICAgICAgcmV0dXJuICQuZXZlbnRUYXJnZXQgPT09IGQ7XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgTSB8fCAoTSA9IHsgZXZlbnRUYXJnZXQ6IGQsIGV2ZW50czoge30gfSwgci5wdXNoKE0pKSwgTS5ldmVudHNbYl0gfHwgKE0uZXZlbnRzW2JdID0gW10pLCBYZShNLmV2ZW50c1tiXSwgZnVuY3Rpb24oJCkge1xuICAgICAgICAgICAgcmV0dXJuICQuZnVuYyA9PT0geCAmJiBmdCgkLm9wdGlvbnMsIEUpO1xuICAgICAgICAgIH0pIHx8IChkLmFkZEV2ZW50TGlzdGVuZXIoYiwgeCwgbC5zdXBwb3J0c09wdGlvbnMgPyBFIDogRS5jYXB0dXJlKSwgTS5ldmVudHNbYl0ucHVzaCh7IGZ1bmM6IHgsIG9wdGlvbnM6IEUgfSkpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBmdW5jdGlvbiBwKGQsIGIsIHgsIEkpIHtcbiAgICAgICAgaWYgKGQuYWRkRXZlbnRMaXN0ZW5lciAmJiBkLnJlbW92ZUV2ZW50TGlzdGVuZXIpIHtcbiAgICAgICAgICB2YXIgRSA9IEtlKHIsIGZ1bmN0aW9uKHRlKSB7XG4gICAgICAgICAgICByZXR1cm4gdGUuZXZlbnRUYXJnZXQgPT09IGQ7XG4gICAgICAgICAgfSksIE0gPSByW0VdO1xuICAgICAgICAgIGlmIChNICYmIE0uZXZlbnRzKSBpZiAoYiAhPT0gXCJhbGxcIikge1xuICAgICAgICAgICAgdmFyICQgPSAhMSwgeiA9IE0uZXZlbnRzW2JdO1xuICAgICAgICAgICAgaWYgKHopIHtcbiAgICAgICAgICAgICAgaWYgKHggPT09IFwiYWxsXCIpIHtcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBBID0gei5sZW5ndGggLSAxOyBBID49IDA7IEEtLSkge1xuICAgICAgICAgICAgICAgICAgdmFyIE4gPSB6W0FdO1xuICAgICAgICAgICAgICAgICAgcChkLCBiLCBOLmZ1bmMsIE4ub3B0aW9ucyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBmb3IgKHZhciBLID0gcWUoSSksIEYgPSAwOyBGIDwgei5sZW5ndGg7IEYrKykge1xuICAgICAgICAgICAgICAgIHZhciBHID0geltGXTtcbiAgICAgICAgICAgICAgICBpZiAoRy5mdW5jID09PSB4ICYmIGZ0KEcub3B0aW9ucywgSykpIHtcbiAgICAgICAgICAgICAgICAgIGQucmVtb3ZlRXZlbnRMaXN0ZW5lcihiLCB4LCBsLnN1cHBvcnRzT3B0aW9ucyA/IEsgOiBLLmNhcHR1cmUpLCB6LnNwbGljZShGLCAxKSwgei5sZW5ndGggPT09IDAgJiYgKGRlbGV0ZSBNLmV2ZW50c1tiXSwgJCA9ICEwKTtcbiAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgJCAmJiAhT2JqZWN0LmtleXMoTS5ldmVudHMpLmxlbmd0aCAmJiByLnNwbGljZShFLCAxKTtcbiAgICAgICAgICB9IGVsc2UgZm9yIChiIGluIE0uZXZlbnRzKSBNLmV2ZW50cy5oYXNPd25Qcm9wZXJ0eShiKSAmJiBwKGQsIGIsIFwiYWxsXCIpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBmdW5jdGlvbiBoKGQsIGIpIHtcbiAgICAgICAgZm9yICh2YXIgeCA9IHFlKGIpLCBJID0gbmV3IEFvKGQpLCBFID0gbltkLnR5cGVdLCBNID0gZW4oZClbMF0sICQgPSBNOyB3LmVsZW1lbnQoJCk7ICkge1xuICAgICAgICAgIGZvciAodmFyIHogPSAwOyB6IDwgRS5sZW5ndGg7IHorKykge1xuICAgICAgICAgICAgdmFyIEEgPSBFW3pdLCBOID0gQS5zZWxlY3RvciwgSyA9IEEuY29udGV4dDtcbiAgICAgICAgICAgIGlmIChtZSgkLCBOKSAmJiBTZShLLCBNKSAmJiBTZShLLCAkKSkge1xuICAgICAgICAgICAgICB2YXIgRiA9IEEubGlzdGVuZXJzO1xuICAgICAgICAgICAgICBJLmN1cnJlbnRUYXJnZXQgPSAkO1xuICAgICAgICAgICAgICBmb3IgKHZhciBHID0gMDsgRyA8IEYubGVuZ3RoOyBHKyspIHtcbiAgICAgICAgICAgICAgICB2YXIgdGUgPSBGW0ddO1xuICAgICAgICAgICAgICAgIGZ0KHRlLm9wdGlvbnMsIHgpICYmIHRlLmZ1bmMoSSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgJCA9IHBlKCQpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBmdW5jdGlvbiBnKGQpIHtcbiAgICAgICAgcmV0dXJuIGgoZCwgITApO1xuICAgICAgfVxuICAgICAgcmV0dXJuIChlID0gdC5kb2N1bWVudCkgPT0gbnVsbCB8fCBlLmNyZWF0ZUVsZW1lbnQoXCJkaXZcIikuYWRkRXZlbnRMaXN0ZW5lcihcInRlc3RcIiwgbnVsbCwgeyBnZXQgY2FwdHVyZSgpIHtcbiAgICAgICAgcmV0dXJuIGwuc3VwcG9ydHNPcHRpb25zID0gITA7XG4gICAgICB9LCBnZXQgcGFzc2l2ZSgpIHtcbiAgICAgICAgcmV0dXJuIGwuc3VwcG9ydHNQYXNzaXZlID0gITA7XG4gICAgICB9IH0pLCB0LmV2ZW50cyA9IGwsIGw7XG4gICAgfSB9LCBhciA9IHsgbWV0aG9kT3JkZXI6IFtcInNpbXVsYXRpb25SZXN1bWVcIiwgXCJtb3VzZU9yUGVuXCIsIFwiaGFzUG9pbnRlclwiLCBcImlkbGVcIl0sIHNlYXJjaDogZnVuY3Rpb24odCkge1xuICAgICAgZm9yICh2YXIgZSA9IDAsIHIgPSBhci5tZXRob2RPcmRlcjsgZSA8IHIubGVuZ3RoOyBlKyspIHtcbiAgICAgICAgdmFyIG4gPSByW2VdLCBvID0gYXJbbl0odCk7XG4gICAgICAgIGlmIChvKSByZXR1cm4gbztcbiAgICAgIH1cbiAgICAgIHJldHVybiBudWxsO1xuICAgIH0sIHNpbXVsYXRpb25SZXN1bWU6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHZhciBlID0gdC5wb2ludGVyVHlwZSwgciA9IHQuZXZlbnRUeXBlLCBuID0gdC5ldmVudFRhcmdldCwgbyA9IHQuc2NvcGU7XG4gICAgICBpZiAoIS9kb3dufHN0YXJ0L2kudGVzdChyKSkgcmV0dXJuIG51bGw7XG4gICAgICBmb3IgKHZhciBsID0gMCwgYyA9IG8uaW50ZXJhY3Rpb25zLmxpc3Q7IGwgPCBjLmxlbmd0aDsgbCsrKSB7XG4gICAgICAgIHZhciBwID0gY1tsXSwgaCA9IG47XG4gICAgICAgIGlmIChwLnNpbXVsYXRpb24gJiYgcC5zaW11bGF0aW9uLmFsbG93UmVzdW1lICYmIHAucG9pbnRlclR5cGUgPT09IGUpIGZvciAoOyBoOyApIHtcbiAgICAgICAgICBpZiAoaCA9PT0gcC5lbGVtZW50KSByZXR1cm4gcDtcbiAgICAgICAgICBoID0gcGUoaCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiBudWxsO1xuICAgIH0sIG1vdXNlT3JQZW46IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHZhciBlLCByID0gdC5wb2ludGVySWQsIG4gPSB0LnBvaW50ZXJUeXBlLCBvID0gdC5ldmVudFR5cGUsIGwgPSB0LnNjb3BlO1xuICAgICAgaWYgKG4gIT09IFwibW91c2VcIiAmJiBuICE9PSBcInBlblwiKSByZXR1cm4gbnVsbDtcbiAgICAgIGZvciAodmFyIGMgPSAwLCBwID0gbC5pbnRlcmFjdGlvbnMubGlzdDsgYyA8IHAubGVuZ3RoOyBjKyspIHtcbiAgICAgICAgdmFyIGggPSBwW2NdO1xuICAgICAgICBpZiAoaC5wb2ludGVyVHlwZSA9PT0gbikge1xuICAgICAgICAgIGlmIChoLnNpbXVsYXRpb24gJiYgIVBuKGgsIHIpKSBjb250aW51ZTtcbiAgICAgICAgICBpZiAoaC5pbnRlcmFjdGluZygpKSByZXR1cm4gaDtcbiAgICAgICAgICBlIHx8IChlID0gaCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChlKSByZXR1cm4gZTtcbiAgICAgIGZvciAodmFyIGcgPSAwLCBkID0gbC5pbnRlcmFjdGlvbnMubGlzdDsgZyA8IGQubGVuZ3RoOyBnKyspIHtcbiAgICAgICAgdmFyIGIgPSBkW2ddO1xuICAgICAgICBpZiAoIShiLnBvaW50ZXJUeXBlICE9PSBuIHx8IC9kb3duL2kudGVzdChvKSAmJiBiLnNpbXVsYXRpb24pKSByZXR1cm4gYjtcbiAgICAgIH1cbiAgICAgIHJldHVybiBudWxsO1xuICAgIH0sIGhhc1BvaW50ZXI6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIGZvciAodmFyIGUgPSB0LnBvaW50ZXJJZCwgciA9IDAsIG4gPSB0LnNjb3BlLmludGVyYWN0aW9ucy5saXN0OyByIDwgbi5sZW5ndGg7IHIrKykge1xuICAgICAgICB2YXIgbyA9IG5bcl07XG4gICAgICAgIGlmIChQbihvLCBlKSkgcmV0dXJuIG87XG4gICAgICB9XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9LCBpZGxlOiBmdW5jdGlvbih0KSB7XG4gICAgICBmb3IgKHZhciBlID0gdC5wb2ludGVyVHlwZSwgciA9IDAsIG4gPSB0LnNjb3BlLmludGVyYWN0aW9ucy5saXN0OyByIDwgbi5sZW5ndGg7IHIrKykge1xuICAgICAgICB2YXIgbyA9IG5bcl07XG4gICAgICAgIGlmIChvLnBvaW50ZXJzLmxlbmd0aCA9PT0gMSkge1xuICAgICAgICAgIHZhciBsID0gby5pbnRlcmFjdGFibGU7XG4gICAgICAgICAgaWYgKGwgJiYgKCFsLm9wdGlvbnMuZ2VzdHVyZSB8fCAhbC5vcHRpb25zLmdlc3R1cmUuZW5hYmxlZCkpIGNvbnRpbnVlO1xuICAgICAgICB9IGVsc2UgaWYgKG8ucG9pbnRlcnMubGVuZ3RoID49IDIpIGNvbnRpbnVlO1xuICAgICAgICBpZiAoIW8uaW50ZXJhY3RpbmcoKSAmJiBlID09PSBvLnBvaW50ZXJUeXBlKSByZXR1cm4gbztcbiAgICAgIH1cbiAgICAgIHJldHVybiBudWxsO1xuICAgIH0gfTtcbiAgICBmdW5jdGlvbiBQbih0LCBlKSB7XG4gICAgICByZXR1cm4gdC5wb2ludGVycy5zb21lKGZ1bmN0aW9uKHIpIHtcbiAgICAgICAgcmV0dXJuIHIuaWQgPT09IGU7XG4gICAgICB9KTtcbiAgICB9XG4gICAgdmFyIEhvID0gYXIsIGxyID0gW1wicG9pbnRlckRvd25cIiwgXCJwb2ludGVyTW92ZVwiLCBcInBvaW50ZXJVcFwiLCBcInVwZGF0ZVBvaW50ZXJcIiwgXCJyZW1vdmVQb2ludGVyXCIsIFwid2luZG93Qmx1clwiXTtcbiAgICBmdW5jdGlvbiBJbih0LCBlKSB7XG4gICAgICByZXR1cm4gZnVuY3Rpb24ocikge1xuICAgICAgICB2YXIgbiA9IGUuaW50ZXJhY3Rpb25zLmxpc3QsIG8gPSBRcihyKSwgbCA9IGVuKHIpLCBjID0gbFswXSwgcCA9IGxbMV0sIGggPSBbXTtcbiAgICAgICAgaWYgKC9edG91Y2gvLnRlc3Qoci50eXBlKSkge1xuICAgICAgICAgIGUucHJldlRvdWNoVGltZSA9IGUubm93KCk7XG4gICAgICAgICAgZm9yICh2YXIgZyA9IDAsIGQgPSByLmNoYW5nZWRUb3VjaGVzOyBnIDwgZC5sZW5ndGg7IGcrKykge1xuICAgICAgICAgICAgdmFyIGIgPSBkW2ddLCB4ID0geyBwb2ludGVyOiBiLCBwb2ludGVySWQ6IFllKGIpLCBwb2ludGVyVHlwZTogbywgZXZlbnRUeXBlOiByLnR5cGUsIGV2ZW50VGFyZ2V0OiBjLCBjdXJFdmVudFRhcmdldDogcCwgc2NvcGU6IGUgfSwgSSA9IE1uKHgpO1xuICAgICAgICAgICAgaC5wdXNoKFt4LnBvaW50ZXIsIHguZXZlbnRUYXJnZXQsIHguY3VyRXZlbnRUYXJnZXQsIEldKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdmFyIEUgPSAhMTtcbiAgICAgICAgICBpZiAoIW9lLnN1cHBvcnRzUG9pbnRlckV2ZW50ICYmIC9tb3VzZS8udGVzdChyLnR5cGUpKSB7XG4gICAgICAgICAgICBmb3IgKHZhciBNID0gMDsgTSA8IG4ubGVuZ3RoICYmICFFOyBNKyspIEUgPSBuW01dLnBvaW50ZXJUeXBlICE9PSBcIm1vdXNlXCIgJiYgbltNXS5wb2ludGVySXNEb3duO1xuICAgICAgICAgICAgRSA9IEUgfHwgZS5ub3coKSAtIGUucHJldlRvdWNoVGltZSA8IDUwMCB8fCByLnRpbWVTdGFtcCA9PT0gMDtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKCFFKSB7XG4gICAgICAgICAgICB2YXIgJCA9IHsgcG9pbnRlcjogciwgcG9pbnRlcklkOiBZZShyKSwgcG9pbnRlclR5cGU6IG8sIGV2ZW50VHlwZTogci50eXBlLCBjdXJFdmVudFRhcmdldDogcCwgZXZlbnRUYXJnZXQ6IGMsIHNjb3BlOiBlIH0sIHogPSBNbigkKTtcbiAgICAgICAgICAgIGgucHVzaChbJC5wb2ludGVyLCAkLmV2ZW50VGFyZ2V0LCAkLmN1ckV2ZW50VGFyZ2V0LCB6XSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGZvciAodmFyIEEgPSAwOyBBIDwgaC5sZW5ndGg7IEErKykge1xuICAgICAgICAgIHZhciBOID0gaFtBXSwgSyA9IE5bMF0sIEYgPSBOWzFdLCBHID0gTlsyXTtcbiAgICAgICAgICBOWzNdW3RdKEssIHIsIEYsIEcpO1xuICAgICAgICB9XG4gICAgICB9O1xuICAgIH1cbiAgICBmdW5jdGlvbiBNbih0KSB7XG4gICAgICB2YXIgZSA9IHQucG9pbnRlclR5cGUsIHIgPSB0LnNjb3BlLCBuID0geyBpbnRlcmFjdGlvbjogSG8uc2VhcmNoKHQpLCBzZWFyY2hEZXRhaWxzOiB0IH07XG4gICAgICByZXR1cm4gci5maXJlKFwiaW50ZXJhY3Rpb25zOmZpbmRcIiwgbiksIG4uaW50ZXJhY3Rpb24gfHwgci5pbnRlcmFjdGlvbnMubmV3KHsgcG9pbnRlclR5cGU6IGUgfSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGNyKHQsIGUpIHtcbiAgICAgIHZhciByID0gdC5kb2MsIG4gPSB0LnNjb3BlLCBvID0gdC5vcHRpb25zLCBsID0gbi5pbnRlcmFjdGlvbnMuZG9jRXZlbnRzLCBjID0gbi5ldmVudHMsIHAgPSBjW2VdO1xuICAgICAgZm9yICh2YXIgaCBpbiBuLmJyb3dzZXIuaXNJT1MgJiYgIW8uZXZlbnRzICYmIChvLmV2ZW50cyA9IHsgcGFzc2l2ZTogITEgfSksIGMuZGVsZWdhdGVkRXZlbnRzKSBwKHIsIGgsIGMuZGVsZWdhdGVMaXN0ZW5lciksIHAociwgaCwgYy5kZWxlZ2F0ZVVzZUNhcHR1cmUsICEwKTtcbiAgICAgIGZvciAodmFyIGcgPSBvICYmIG8uZXZlbnRzLCBkID0gMDsgZCA8IGwubGVuZ3RoOyBkKyspIHtcbiAgICAgICAgdmFyIGIgPSBsW2RdO1xuICAgICAgICBwKHIsIGIudHlwZSwgYi5saXN0ZW5lciwgZyk7XG4gICAgICB9XG4gICAgfVxuICAgIHZhciBXbyA9IHsgaWQ6IFwiY29yZS9pbnRlcmFjdGlvbnNcIiwgaW5zdGFsbDogZnVuY3Rpb24odCkge1xuICAgICAgZm9yICh2YXIgZSA9IHt9LCByID0gMDsgciA8IGxyLmxlbmd0aDsgcisrKSB7XG4gICAgICAgIHZhciBuID0gbHJbcl07XG4gICAgICAgIGVbbl0gPSBJbihuLCB0KTtcbiAgICAgIH1cbiAgICAgIHZhciBvLCBsID0gb2UucEV2ZW50VHlwZXM7XG4gICAgICBmdW5jdGlvbiBjKCkge1xuICAgICAgICBmb3IgKHZhciBwID0gMCwgaCA9IHQuaW50ZXJhY3Rpb25zLmxpc3Q7IHAgPCBoLmxlbmd0aDsgcCsrKSB7XG4gICAgICAgICAgdmFyIGcgPSBoW3BdO1xuICAgICAgICAgIGlmIChnLnBvaW50ZXJJc0Rvd24gJiYgZy5wb2ludGVyVHlwZSA9PT0gXCJ0b3VjaFwiICYmICFnLl9pbnRlcmFjdGluZykgZm9yICh2YXIgZCA9IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgdmFyIEkgPSB4W2JdO1xuICAgICAgICAgICAgdC5kb2N1bWVudHMuc29tZShmdW5jdGlvbihFKSB7XG4gICAgICAgICAgICAgIHJldHVybiBTZShFLmRvYywgSS5kb3duVGFyZ2V0KTtcbiAgICAgICAgICAgIH0pIHx8IGcucmVtb3ZlUG9pbnRlcihJLnBvaW50ZXIsIEkuZXZlbnQpO1xuICAgICAgICAgIH0sIGIgPSAwLCB4ID0gZy5wb2ludGVyczsgYiA8IHgubGVuZ3RoOyBiKyspIGQoKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgKG8gPSBRLlBvaW50ZXJFdmVudCA/IFt7IHR5cGU6IGwuZG93biwgbGlzdGVuZXI6IGMgfSwgeyB0eXBlOiBsLmRvd24sIGxpc3RlbmVyOiBlLnBvaW50ZXJEb3duIH0sIHsgdHlwZTogbC5tb3ZlLCBsaXN0ZW5lcjogZS5wb2ludGVyTW92ZSB9LCB7IHR5cGU6IGwudXAsIGxpc3RlbmVyOiBlLnBvaW50ZXJVcCB9LCB7IHR5cGU6IGwuY2FuY2VsLCBsaXN0ZW5lcjogZS5wb2ludGVyVXAgfV0gOiBbeyB0eXBlOiBcIm1vdXNlZG93blwiLCBsaXN0ZW5lcjogZS5wb2ludGVyRG93biB9LCB7IHR5cGU6IFwibW91c2Vtb3ZlXCIsIGxpc3RlbmVyOiBlLnBvaW50ZXJNb3ZlIH0sIHsgdHlwZTogXCJtb3VzZXVwXCIsIGxpc3RlbmVyOiBlLnBvaW50ZXJVcCB9LCB7IHR5cGU6IFwidG91Y2hzdGFydFwiLCBsaXN0ZW5lcjogYyB9LCB7IHR5cGU6IFwidG91Y2hzdGFydFwiLCBsaXN0ZW5lcjogZS5wb2ludGVyRG93biB9LCB7IHR5cGU6IFwidG91Y2htb3ZlXCIsIGxpc3RlbmVyOiBlLnBvaW50ZXJNb3ZlIH0sIHsgdHlwZTogXCJ0b3VjaGVuZFwiLCBsaXN0ZW5lcjogZS5wb2ludGVyVXAgfSwgeyB0eXBlOiBcInRvdWNoY2FuY2VsXCIsIGxpc3RlbmVyOiBlLnBvaW50ZXJVcCB9XSkucHVzaCh7IHR5cGU6IFwiYmx1clwiLCBsaXN0ZW5lcjogZnVuY3Rpb24ocCkge1xuICAgICAgICBmb3IgKHZhciBoID0gMCwgZyA9IHQuaW50ZXJhY3Rpb25zLmxpc3Q7IGggPCBnLmxlbmd0aDsgaCsrKVxuICAgICAgICAgIGdbaF0uZG9jdW1lbnRCbHVyKHApO1xuICAgICAgfSB9KSwgdC5wcmV2VG91Y2hUaW1lID0gMCwgdC5JbnRlcmFjdGlvbiA9IGZ1bmN0aW9uKHApIHtcbiAgICAgICAgQyhnLCBwKTtcbiAgICAgICAgdmFyIGggPSBQKGcpO1xuICAgICAgICBmdW5jdGlvbiBnKCkge1xuICAgICAgICAgIHJldHVybiBmKHRoaXMsIGcpLCBoLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHkoZywgW3sga2V5OiBcInBvaW50ZXJNb3ZlVG9sZXJhbmNlXCIsIGdldDogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgcmV0dXJuIHQuaW50ZXJhY3Rpb25zLnBvaW50ZXJNb3ZlVG9sZXJhbmNlO1xuICAgICAgICB9LCBzZXQ6IGZ1bmN0aW9uKGQpIHtcbiAgICAgICAgICB0LmludGVyYWN0aW9ucy5wb2ludGVyTW92ZVRvbGVyYW5jZSA9IGQ7XG4gICAgICAgIH0gfSwgeyBrZXk6IFwiX25vd1wiLCB2YWx1ZTogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgcmV0dXJuIHQubm93KCk7XG4gICAgICAgIH0gfV0pLCBnO1xuICAgICAgfShSbyksIHQuaW50ZXJhY3Rpb25zID0geyBsaXN0OiBbXSwgbmV3OiBmdW5jdGlvbihwKSB7XG4gICAgICAgIHAuc2NvcGVGaXJlID0gZnVuY3Rpb24oZywgZCkge1xuICAgICAgICAgIHJldHVybiB0LmZpcmUoZywgZCk7XG4gICAgICAgIH07XG4gICAgICAgIHZhciBoID0gbmV3IHQuSW50ZXJhY3Rpb24ocCk7XG4gICAgICAgIHJldHVybiB0LmludGVyYWN0aW9ucy5saXN0LnB1c2goaCksIGg7XG4gICAgICB9LCBsaXN0ZW5lcnM6IGUsIGRvY0V2ZW50czogbywgcG9pbnRlck1vdmVUb2xlcmFuY2U6IDEgfSwgdC51c2VQbHVnaW4obW4pO1xuICAgIH0sIGxpc3RlbmVyczogeyBcInNjb3BlOmFkZC1kb2N1bWVudFwiOiBmdW5jdGlvbih0KSB7XG4gICAgICByZXR1cm4gY3IodCwgXCJhZGRcIik7XG4gICAgfSwgXCJzY29wZTpyZW1vdmUtZG9jdW1lbnRcIjogZnVuY3Rpb24odCkge1xuICAgICAgcmV0dXJuIGNyKHQsIFwicmVtb3ZlXCIpO1xuICAgIH0sIFwiaW50ZXJhY3RhYmxlOnVuc2V0XCI6IGZ1bmN0aW9uKHQsIGUpIHtcbiAgICAgIGZvciAodmFyIHIgPSB0LmludGVyYWN0YWJsZSwgbiA9IGUuaW50ZXJhY3Rpb25zLmxpc3QubGVuZ3RoIC0gMTsgbiA+PSAwOyBuLS0pIHtcbiAgICAgICAgdmFyIG8gPSBlLmludGVyYWN0aW9ucy5saXN0W25dO1xuICAgICAgICBvLmludGVyYWN0YWJsZSA9PT0gciAmJiAoby5zdG9wKCksIGUuZmlyZShcImludGVyYWN0aW9uczpkZXN0cm95XCIsIHsgaW50ZXJhY3Rpb246IG8gfSksIG8uZGVzdHJveSgpLCBlLmludGVyYWN0aW9ucy5saXN0Lmxlbmd0aCA+IDIgJiYgZS5pbnRlcmFjdGlvbnMubGlzdC5zcGxpY2UobiwgMSkpO1xuICAgICAgfVxuICAgIH0gfSwgb25Eb2NTaWduYWw6IGNyLCBkb09uSW50ZXJhY3Rpb25zOiBJbiwgbWV0aG9kTmFtZXM6IGxyIH0sIEZvID0gV28sIFRlID0gZnVuY3Rpb24odCkge1xuICAgICAgcmV0dXJuIHRbdC5PbiA9IDBdID0gXCJPblwiLCB0W3QuT2ZmID0gMV0gPSBcIk9mZlwiLCB0O1xuICAgIH0oVGUgfHwge30pLCBVbyA9IGZ1bmN0aW9uKCkge1xuICAgICAgZnVuY3Rpb24gdChlLCByLCBuLCBvKSB7XG4gICAgICAgIGYodGhpcywgdCksIHRoaXMudGFyZ2V0ID0gdm9pZCAwLCB0aGlzLm9wdGlvbnMgPSB2b2lkIDAsIHRoaXMuX2FjdGlvbnMgPSB2b2lkIDAsIHRoaXMuZXZlbnRzID0gbmV3IF9uKCksIHRoaXMuX2NvbnRleHQgPSB2b2lkIDAsIHRoaXMuX3dpbiA9IHZvaWQgMCwgdGhpcy5fZG9jID0gdm9pZCAwLCB0aGlzLl9zY29wZUV2ZW50cyA9IHZvaWQgMCwgdGhpcy5fYWN0aW9ucyA9IHIuYWN0aW9ucywgdGhpcy50YXJnZXQgPSBlLCB0aGlzLl9jb250ZXh0ID0gci5jb250ZXh0IHx8IG4sIHRoaXMuX3dpbiA9IEIoS3IoZSkgPyB0aGlzLl9jb250ZXh0IDogZSksIHRoaXMuX2RvYyA9IHRoaXMuX3dpbi5kb2N1bWVudCwgdGhpcy5fc2NvcGVFdmVudHMgPSBvLCB0aGlzLnNldChyKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB5KHQsIFt7IGtleTogXCJfZGVmYXVsdHNcIiwgZ2V0OiBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIHsgYmFzZToge30sIHBlckFjdGlvbjoge30sIGFjdGlvbnM6IHt9IH07XG4gICAgICB9IH0sIHsga2V5OiBcInNldE9uRXZlbnRzXCIsIHZhbHVlOiBmdW5jdGlvbihlLCByKSB7XG4gICAgICAgIHJldHVybiB3LmZ1bmMoci5vbnN0YXJ0KSAmJiB0aGlzLm9uKFwiXCIuY29uY2F0KGUsIFwic3RhcnRcIiksIHIub25zdGFydCksIHcuZnVuYyhyLm9ubW92ZSkgJiYgdGhpcy5vbihcIlwiLmNvbmNhdChlLCBcIm1vdmVcIiksIHIub25tb3ZlKSwgdy5mdW5jKHIub25lbmQpICYmIHRoaXMub24oXCJcIi5jb25jYXQoZSwgXCJlbmRcIiksIHIub25lbmQpLCB3LmZ1bmMoci5vbmluZXJ0aWFzdGFydCkgJiYgdGhpcy5vbihcIlwiLmNvbmNhdChlLCBcImluZXJ0aWFzdGFydFwiKSwgci5vbmluZXJ0aWFzdGFydCksIHRoaXM7XG4gICAgICB9IH0sIHsga2V5OiBcInVwZGF0ZVBlckFjdGlvbkxpc3RlbmVyc1wiLCB2YWx1ZTogZnVuY3Rpb24oZSwgciwgbikge1xuICAgICAgICB2YXIgbywgbCA9IHRoaXMsIGMgPSAobyA9IHRoaXMuX2FjdGlvbnMubWFwW2VdKSA9PSBudWxsID8gdm9pZCAwIDogby5maWx0ZXJFdmVudFR5cGUsIHAgPSBmdW5jdGlvbihoKSB7XG4gICAgICAgICAgcmV0dXJuIChjID09IG51bGwgfHwgYyhoKSkgJiYgcHQoaCwgbC5fYWN0aW9ucyk7XG4gICAgICAgIH07XG4gICAgICAgICh3LmFycmF5KHIpIHx8IHcub2JqZWN0KHIpKSAmJiB0aGlzLl9vbk9mZihUZS5PZmYsIGUsIHIsIHZvaWQgMCwgcCksICh3LmFycmF5KG4pIHx8IHcub2JqZWN0KG4pKSAmJiB0aGlzLl9vbk9mZihUZS5PbiwgZSwgbiwgdm9pZCAwLCBwKTtcbiAgICAgIH0gfSwgeyBrZXk6IFwic2V0UGVyQWN0aW9uXCIsIHZhbHVlOiBmdW5jdGlvbihlLCByKSB7XG4gICAgICAgIHZhciBuID0gdGhpcy5fZGVmYXVsdHM7XG4gICAgICAgIGZvciAodmFyIG8gaW4gcikge1xuICAgICAgICAgIHZhciBsID0gbywgYyA9IHRoaXMub3B0aW9uc1tlXSwgcCA9IHJbbF07XG4gICAgICAgICAgbCA9PT0gXCJsaXN0ZW5lcnNcIiAmJiB0aGlzLnVwZGF0ZVBlckFjdGlvbkxpc3RlbmVycyhlLCBjLmxpc3RlbmVycywgcCksIHcuYXJyYXkocCkgPyBjW2xdID0gcm4ocCkgOiB3LnBsYWluT2JqZWN0KHApID8gKGNbbF0gPSBXKGNbbF0gfHwge30sIGtlKHApKSwgdy5vYmplY3Qobi5wZXJBY3Rpb25bbF0pICYmIFwiZW5hYmxlZFwiIGluIG4ucGVyQWN0aW9uW2xdICYmIChjW2xdLmVuYWJsZWQgPSBwLmVuYWJsZWQgIT09ICExKSkgOiB3LmJvb2wocCkgJiYgdy5vYmplY3Qobi5wZXJBY3Rpb25bbF0pID8gY1tsXS5lbmFibGVkID0gcCA6IGNbbF0gPSBwO1xuICAgICAgICB9XG4gICAgICB9IH0sIHsga2V5OiBcImdldFJlY3RcIiwgdmFsdWU6IGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgcmV0dXJuIGUgPSBlIHx8ICh3LmVsZW1lbnQodGhpcy50YXJnZXQpID8gdGhpcy50YXJnZXQgOiBudWxsKSwgdy5zdHJpbmcodGhpcy50YXJnZXQpICYmIChlID0gZSB8fCB0aGlzLl9jb250ZXh0LnF1ZXJ5U2VsZWN0b3IodGhpcy50YXJnZXQpKSwgTnQoZSk7XG4gICAgICB9IH0sIHsga2V5OiBcInJlY3RDaGVja2VyXCIsIHZhbHVlOiBmdW5jdGlvbihlKSB7XG4gICAgICAgIHZhciByID0gdGhpcztcbiAgICAgICAgcmV0dXJuIHcuZnVuYyhlKSA/ICh0aGlzLmdldFJlY3QgPSBmdW5jdGlvbihuKSB7XG4gICAgICAgICAgdmFyIG8gPSBXKHt9LCBlLmFwcGx5KHIsIG4pKTtcbiAgICAgICAgICByZXR1cm4gXCJ3aWR0aFwiIGluIG8gfHwgKG8ud2lkdGggPSBvLnJpZ2h0IC0gby5sZWZ0LCBvLmhlaWdodCA9IG8uYm90dG9tIC0gby50b3ApLCBvO1xuICAgICAgICB9LCB0aGlzKSA6IGUgPT09IG51bGwgPyAoZGVsZXRlIHRoaXMuZ2V0UmVjdCwgdGhpcykgOiB0aGlzLmdldFJlY3Q7XG4gICAgICB9IH0sIHsga2V5OiBcIl9iYWNrQ29tcGF0T3B0aW9uXCIsIHZhbHVlOiBmdW5jdGlvbihlLCByKSB7XG4gICAgICAgIGlmIChLcihyKSB8fCB3Lm9iamVjdChyKSkge1xuICAgICAgICAgIGZvciAodmFyIG4gaW4gdGhpcy5vcHRpb25zW2VdID0gciwgdGhpcy5fYWN0aW9ucy5tYXApIHRoaXMub3B0aW9uc1tuXVtlXSA9IHI7XG4gICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMub3B0aW9uc1tlXTtcbiAgICAgIH0gfSwgeyBrZXk6IFwib3JpZ2luXCIsIHZhbHVlOiBmdW5jdGlvbihlKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9iYWNrQ29tcGF0T3B0aW9uKFwib3JpZ2luXCIsIGUpO1xuICAgICAgfSB9LCB7IGtleTogXCJkZWx0YVNvdXJjZVwiLCB2YWx1ZTogZnVuY3Rpb24oZSkge1xuICAgICAgICByZXR1cm4gZSA9PT0gXCJwYWdlXCIgfHwgZSA9PT0gXCJjbGllbnRcIiA/ICh0aGlzLm9wdGlvbnMuZGVsdGFTb3VyY2UgPSBlLCB0aGlzKSA6IHRoaXMub3B0aW9ucy5kZWx0YVNvdXJjZTtcbiAgICAgIH0gfSwgeyBrZXk6IFwiZ2V0QWxsRWxlbWVudHNcIiwgdmFsdWU6IGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgZSA9IHRoaXMudGFyZ2V0O1xuICAgICAgICByZXR1cm4gdy5zdHJpbmcoZSkgPyBBcnJheS5mcm9tKHRoaXMuX2NvbnRleHQucXVlcnlTZWxlY3RvckFsbChlKSkgOiB3LmZ1bmMoZSkgJiYgZS5nZXRBbGxFbGVtZW50cyA/IGUuZ2V0QWxsRWxlbWVudHMoKSA6IHcuZWxlbWVudChlKSA/IFtlXSA6IFtdO1xuICAgICAgfSB9LCB7IGtleTogXCJjb250ZXh0XCIsIHZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NvbnRleHQ7XG4gICAgICB9IH0sIHsga2V5OiBcImluQ29udGV4dFwiLCB2YWx1ZTogZnVuY3Rpb24oZSkge1xuICAgICAgICByZXR1cm4gdGhpcy5fY29udGV4dCA9PT0gZS5vd25lckRvY3VtZW50IHx8IFNlKHRoaXMuX2NvbnRleHQsIGUpO1xuICAgICAgfSB9LCB7IGtleTogXCJ0ZXN0SWdub3JlQWxsb3dcIiwgdmFsdWU6IGZ1bmN0aW9uKGUsIHIsIG4pIHtcbiAgICAgICAgcmV0dXJuICF0aGlzLnRlc3RJZ25vcmUoZS5pZ25vcmVGcm9tLCByLCBuKSAmJiB0aGlzLnRlc3RBbGxvdyhlLmFsbG93RnJvbSwgciwgbik7XG4gICAgICB9IH0sIHsga2V5OiBcInRlc3RBbGxvd1wiLCB2YWx1ZTogZnVuY3Rpb24oZSwgciwgbikge1xuICAgICAgICByZXR1cm4gIWUgfHwgISF3LmVsZW1lbnQobikgJiYgKHcuc3RyaW5nKGUpID8gRnQobiwgZSwgcikgOiAhIXcuZWxlbWVudChlKSAmJiBTZShlLCBuKSk7XG4gICAgICB9IH0sIHsga2V5OiBcInRlc3RJZ25vcmVcIiwgdmFsdWU6IGZ1bmN0aW9uKGUsIHIsIG4pIHtcbiAgICAgICAgcmV0dXJuICEoIWUgfHwgIXcuZWxlbWVudChuKSkgJiYgKHcuc3RyaW5nKGUpID8gRnQobiwgZSwgcikgOiAhIXcuZWxlbWVudChlKSAmJiBTZShlLCBuKSk7XG4gICAgICB9IH0sIHsga2V5OiBcImZpcmVcIiwgdmFsdWU6IGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZXZlbnRzLmZpcmUoZSksIHRoaXM7XG4gICAgICB9IH0sIHsga2V5OiBcIl9vbk9mZlwiLCB2YWx1ZTogZnVuY3Rpb24oZSwgciwgbiwgbywgbCkge1xuICAgICAgICB3Lm9iamVjdChyKSAmJiAhdy5hcnJheShyKSAmJiAobyA9IG4sIG4gPSBudWxsKTtcbiAgICAgICAgdmFyIGMgPSBPZShyLCBuLCBsKTtcbiAgICAgICAgZm9yICh2YXIgcCBpbiBjKSB7XG4gICAgICAgICAgcCA9PT0gXCJ3aGVlbFwiICYmIChwID0gb2Uud2hlZWxFdmVudCk7XG4gICAgICAgICAgZm9yICh2YXIgaCA9IDAsIGcgPSBjW3BdOyBoIDwgZy5sZW5ndGg7IGgrKykge1xuICAgICAgICAgICAgdmFyIGQgPSBnW2hdO1xuICAgICAgICAgICAgcHQocCwgdGhpcy5fYWN0aW9ucykgPyB0aGlzLmV2ZW50c1tlID09PSBUZS5PbiA/IFwib25cIiA6IFwib2ZmXCJdKHAsIGQpIDogdy5zdHJpbmcodGhpcy50YXJnZXQpID8gdGhpcy5fc2NvcGVFdmVudHNbZSA9PT0gVGUuT24gPyBcImFkZERlbGVnYXRlXCIgOiBcInJlbW92ZURlbGVnYXRlXCJdKHRoaXMudGFyZ2V0LCB0aGlzLl9jb250ZXh0LCBwLCBkLCBvKSA6IHRoaXMuX3Njb3BlRXZlbnRzW2UgPT09IFRlLk9uID8gXCJhZGRcIiA6IFwicmVtb3ZlXCJdKHRoaXMudGFyZ2V0LCBwLCBkLCBvKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICB9IH0sIHsga2V5OiBcIm9uXCIsIHZhbHVlOiBmdW5jdGlvbihlLCByLCBuKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9vbk9mZihUZS5PbiwgZSwgciwgbik7XG4gICAgICB9IH0sIHsga2V5OiBcIm9mZlwiLCB2YWx1ZTogZnVuY3Rpb24oZSwgciwgbikge1xuICAgICAgICByZXR1cm4gdGhpcy5fb25PZmYoVGUuT2ZmLCBlLCByLCBuKTtcbiAgICAgIH0gfSwgeyBrZXk6IFwic2V0XCIsIHZhbHVlOiBmdW5jdGlvbihlKSB7XG4gICAgICAgIHZhciByID0gdGhpcy5fZGVmYXVsdHM7XG4gICAgICAgIGZvciAodmFyIG4gaW4gdy5vYmplY3QoZSkgfHwgKGUgPSB7fSksIHRoaXMub3B0aW9ucyA9IGtlKHIuYmFzZSksIHRoaXMuX2FjdGlvbnMubWV0aG9kRGljdCkge1xuICAgICAgICAgIHZhciBvID0gbiwgbCA9IHRoaXMuX2FjdGlvbnMubWV0aG9kRGljdFtvXTtcbiAgICAgICAgICB0aGlzLm9wdGlvbnNbb10gPSB7fSwgdGhpcy5zZXRQZXJBY3Rpb24obywgVyhXKHt9LCByLnBlckFjdGlvbiksIHIuYWN0aW9uc1tvXSkpLCB0aGlzW2xdKGVbb10pO1xuICAgICAgICB9XG4gICAgICAgIGZvciAodmFyIGMgaW4gZSkgYyAhPT0gXCJnZXRSZWN0XCIgPyB3LmZ1bmModGhpc1tjXSkgJiYgdGhpc1tjXShlW2NdKSA6IHRoaXMucmVjdENoZWNrZXIoZS5nZXRSZWN0KTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICB9IH0sIHsga2V5OiBcInVuc2V0XCIsIHZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgaWYgKHcuc3RyaW5nKHRoaXMudGFyZ2V0KSkgZm9yICh2YXIgZSBpbiB0aGlzLl9zY29wZUV2ZW50cy5kZWxlZ2F0ZWRFdmVudHMpIGZvciAodmFyIHIgPSB0aGlzLl9zY29wZUV2ZW50cy5kZWxlZ2F0ZWRFdmVudHNbZV0sIG4gPSByLmxlbmd0aCAtIDE7IG4gPj0gMDsgbi0tKSB7XG4gICAgICAgICAgdmFyIG8gPSByW25dLCBsID0gby5zZWxlY3RvciwgYyA9IG8uY29udGV4dCwgcCA9IG8ubGlzdGVuZXJzO1xuICAgICAgICAgIGwgPT09IHRoaXMudGFyZ2V0ICYmIGMgPT09IHRoaXMuX2NvbnRleHQgJiYgci5zcGxpY2UobiwgMSk7XG4gICAgICAgICAgZm9yICh2YXIgaCA9IHAubGVuZ3RoIC0gMTsgaCA+PSAwOyBoLS0pIHRoaXMuX3Njb3BlRXZlbnRzLnJlbW92ZURlbGVnYXRlKHRoaXMudGFyZ2V0LCB0aGlzLl9jb250ZXh0LCBlLCBwW2hdWzBdLCBwW2hdWzFdKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHRoaXMuX3Njb3BlRXZlbnRzLnJlbW92ZSh0aGlzLnRhcmdldCwgXCJhbGxcIik7XG4gICAgICB9IH1dKSwgdDtcbiAgICB9KCksIE5vID0gZnVuY3Rpb24oKSB7XG4gICAgICBmdW5jdGlvbiB0KGUpIHtcbiAgICAgICAgdmFyIHIgPSB0aGlzO1xuICAgICAgICBmKHRoaXMsIHQpLCB0aGlzLmxpc3QgPSBbXSwgdGhpcy5zZWxlY3Rvck1hcCA9IHt9LCB0aGlzLnNjb3BlID0gdm9pZCAwLCB0aGlzLnNjb3BlID0gZSwgZS5hZGRMaXN0ZW5lcnMoeyBcImludGVyYWN0YWJsZTp1bnNldFwiOiBmdW5jdGlvbihuKSB7XG4gICAgICAgICAgdmFyIG8gPSBuLmludGVyYWN0YWJsZSwgbCA9IG8udGFyZ2V0LCBjID0gdy5zdHJpbmcobCkgPyByLnNlbGVjdG9yTWFwW2xdIDogbFtyLnNjb3BlLmlkXSwgcCA9IEtlKGMsIGZ1bmN0aW9uKGgpIHtcbiAgICAgICAgICAgIHJldHVybiBoID09PSBvO1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIGMuc3BsaWNlKHAsIDEpO1xuICAgICAgICB9IH0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHkodCwgW3sga2V5OiBcIm5ld1wiLCB2YWx1ZTogZnVuY3Rpb24oZSwgcikge1xuICAgICAgICByID0gVyhyIHx8IHt9LCB7IGFjdGlvbnM6IHRoaXMuc2NvcGUuYWN0aW9ucyB9KTtcbiAgICAgICAgdmFyIG4gPSBuZXcgdGhpcy5zY29wZS5JbnRlcmFjdGFibGUoZSwgciwgdGhpcy5zY29wZS5kb2N1bWVudCwgdGhpcy5zY29wZS5ldmVudHMpO1xuICAgICAgICByZXR1cm4gdGhpcy5zY29wZS5hZGREb2N1bWVudChuLl9kb2MpLCB0aGlzLmxpc3QucHVzaChuKSwgdy5zdHJpbmcoZSkgPyAodGhpcy5zZWxlY3Rvck1hcFtlXSB8fCAodGhpcy5zZWxlY3Rvck1hcFtlXSA9IFtdKSwgdGhpcy5zZWxlY3Rvck1hcFtlXS5wdXNoKG4pKSA6IChuLnRhcmdldFt0aGlzLnNjb3BlLmlkXSB8fCBPYmplY3QuZGVmaW5lUHJvcGVydHkoZSwgdGhpcy5zY29wZS5pZCwgeyB2YWx1ZTogW10sIGNvbmZpZ3VyYWJsZTogITAgfSksIGVbdGhpcy5zY29wZS5pZF0ucHVzaChuKSksIHRoaXMuc2NvcGUuZmlyZShcImludGVyYWN0YWJsZTpuZXdcIiwgeyB0YXJnZXQ6IGUsIG9wdGlvbnM6IHIsIGludGVyYWN0YWJsZTogbiwgd2luOiB0aGlzLnNjb3BlLl93aW4gfSksIG47XG4gICAgICB9IH0sIHsga2V5OiBcImdldEV4aXN0aW5nXCIsIHZhbHVlOiBmdW5jdGlvbihlLCByKSB7XG4gICAgICAgIHZhciBuID0gciAmJiByLmNvbnRleHQgfHwgdGhpcy5zY29wZS5kb2N1bWVudCwgbyA9IHcuc3RyaW5nKGUpLCBsID0gbyA/IHRoaXMuc2VsZWN0b3JNYXBbZV0gOiBlW3RoaXMuc2NvcGUuaWRdO1xuICAgICAgICBpZiAobCkgcmV0dXJuIFhlKGwsIGZ1bmN0aW9uKGMpIHtcbiAgICAgICAgICByZXR1cm4gYy5fY29udGV4dCA9PT0gbiAmJiAobyB8fCBjLmluQ29udGV4dChlKSk7XG4gICAgICAgIH0pO1xuICAgICAgfSB9LCB7IGtleTogXCJmb3JFYWNoTWF0Y2hcIiwgdmFsdWU6IGZ1bmN0aW9uKGUsIHIpIHtcbiAgICAgICAgZm9yICh2YXIgbiA9IDAsIG8gPSB0aGlzLmxpc3Q7IG4gPCBvLmxlbmd0aDsgbisrKSB7XG4gICAgICAgICAgdmFyIGwgPSBvW25dLCBjID0gdm9pZCAwO1xuICAgICAgICAgIGlmICgody5zdHJpbmcobC50YXJnZXQpID8gdy5lbGVtZW50KGUpICYmIG1lKGUsIGwudGFyZ2V0KSA6IGUgPT09IGwudGFyZ2V0KSAmJiBsLmluQ29udGV4dChlKSAmJiAoYyA9IHIobCkpLCBjICE9PSB2b2lkIDApIHJldHVybiBjO1xuICAgICAgICB9XG4gICAgICB9IH1dKSwgdDtcbiAgICB9KCksIEdvID0gZnVuY3Rpb24oKSB7XG4gICAgICBmdW5jdGlvbiB0KCkge1xuICAgICAgICB2YXIgZSA9IHRoaXM7XG4gICAgICAgIGYodGhpcywgdCksIHRoaXMuaWQgPSBcIl9faW50ZXJhY3Rfc2NvcGVfXCIuY29uY2F0KE1hdGguZmxvb3IoMTAwICogTWF0aC5yYW5kb20oKSkpLCB0aGlzLmlzSW5pdGlhbGl6ZWQgPSAhMSwgdGhpcy5saXN0ZW5lck1hcHMgPSBbXSwgdGhpcy5icm93c2VyID0gb2UsIHRoaXMuZGVmYXVsdHMgPSBrZSh5biksIHRoaXMuRXZlbnRhYmxlID0gX24sIHRoaXMuYWN0aW9ucyA9IHsgbWFwOiB7fSwgcGhhc2VzOiB7IHN0YXJ0OiAhMCwgbW92ZTogITAsIGVuZDogITAgfSwgbWV0aG9kRGljdDoge30sIHBoYXNlbGVzc1R5cGVzOiB7fSB9LCB0aGlzLmludGVyYWN0U3RhdGljID0gZnVuY3Rpb24obikge1xuICAgICAgICAgIHZhciBvID0gZnVuY3Rpb24gbChjLCBwKSB7XG4gICAgICAgICAgICB2YXIgaCA9IG4uaW50ZXJhY3RhYmxlcy5nZXRFeGlzdGluZyhjLCBwKTtcbiAgICAgICAgICAgIHJldHVybiBoIHx8ICgoaCA9IG4uaW50ZXJhY3RhYmxlcy5uZXcoYywgcCkpLmV2ZW50cy5nbG9iYWwgPSBsLmdsb2JhbEV2ZW50cyksIGg7XG4gICAgICAgICAgfTtcbiAgICAgICAgICByZXR1cm4gby5nZXRQb2ludGVyQXZlcmFnZSA9IEpyLCBvLmdldFRvdWNoQkJveCA9IEt0LCBvLmdldFRvdWNoRGlzdGFuY2UgPSBYdCwgby5nZXRUb3VjaEFuZ2xlID0gQnQsIG8uZ2V0RWxlbWVudFJlY3QgPSBOdCwgby5nZXRFbGVtZW50Q2xpZW50UmVjdCA9IFV0LCBvLm1hdGNoZXNTZWxlY3RvciA9IG1lLCBvLmNsb3Nlc3QgPSBVciwgby5nbG9iYWxFdmVudHMgPSB7fSwgby52ZXJzaW9uID0gXCIxLjEwLjI3XCIsIG8uc2NvcGUgPSBuLCBvLnVzZSA9IGZ1bmN0aW9uKGwsIGMpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnNjb3BlLnVzZVBsdWdpbihsLCBjKSwgdGhpcztcbiAgICAgICAgICB9LCBvLmlzU2V0ID0gZnVuY3Rpb24obCwgYykge1xuICAgICAgICAgICAgcmV0dXJuICEhdGhpcy5zY29wZS5pbnRlcmFjdGFibGVzLmdldChsLCBjICYmIGMuY29udGV4dCk7XG4gICAgICAgICAgfSwgby5vbiA9IEJlKGZ1bmN0aW9uKGwsIGMsIHApIHtcbiAgICAgICAgICAgIGlmICh3LnN0cmluZyhsKSAmJiBsLnNlYXJjaChcIiBcIikgIT09IC0xICYmIChsID0gbC50cmltKCkuc3BsaXQoLyArLykpLCB3LmFycmF5KGwpKSB7XG4gICAgICAgICAgICAgIGZvciAodmFyIGggPSAwLCBnID0gbDsgaCA8IGcubGVuZ3RoOyBoKyspIHtcbiAgICAgICAgICAgICAgICB2YXIgZCA9IGdbaF07XG4gICAgICAgICAgICAgICAgdGhpcy5vbihkLCBjLCBwKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICh3Lm9iamVjdChsKSkge1xuICAgICAgICAgICAgICBmb3IgKHZhciBiIGluIGwpIHRoaXMub24oYiwgbFtiXSwgYyk7XG4gICAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHB0KGwsIHRoaXMuc2NvcGUuYWN0aW9ucykgPyB0aGlzLmdsb2JhbEV2ZW50c1tsXSA/IHRoaXMuZ2xvYmFsRXZlbnRzW2xdLnB1c2goYykgOiB0aGlzLmdsb2JhbEV2ZW50c1tsXSA9IFtjXSA6IHRoaXMuc2NvcGUuZXZlbnRzLmFkZCh0aGlzLnNjb3BlLmRvY3VtZW50LCBsLCBjLCB7IG9wdGlvbnM6IHAgfSksIHRoaXM7XG4gICAgICAgICAgfSwgXCJUaGUgaW50ZXJhY3Qub24oKSBtZXRob2QgaXMgYmVpbmcgZGVwcmVjYXRlZFwiKSwgby5vZmYgPSBCZShmdW5jdGlvbihsLCBjLCBwKSB7XG4gICAgICAgICAgICBpZiAody5zdHJpbmcobCkgJiYgbC5zZWFyY2goXCIgXCIpICE9PSAtMSAmJiAobCA9IGwudHJpbSgpLnNwbGl0KC8gKy8pKSwgdy5hcnJheShsKSkge1xuICAgICAgICAgICAgICBmb3IgKHZhciBoID0gMCwgZyA9IGw7IGggPCBnLmxlbmd0aDsgaCsrKSB7XG4gICAgICAgICAgICAgICAgdmFyIGQgPSBnW2hdO1xuICAgICAgICAgICAgICAgIHRoaXMub2ZmKGQsIGMsIHApO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHcub2JqZWN0KGwpKSB7XG4gICAgICAgICAgICAgIGZvciAodmFyIGIgaW4gbCkgdGhpcy5vZmYoYiwgbFtiXSwgYyk7XG4gICAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdmFyIHg7XG4gICAgICAgICAgICByZXR1cm4gcHQobCwgdGhpcy5zY29wZS5hY3Rpb25zKSA/IGwgaW4gdGhpcy5nbG9iYWxFdmVudHMgJiYgKHggPSB0aGlzLmdsb2JhbEV2ZW50c1tsXS5pbmRleE9mKGMpKSAhPT0gLTEgJiYgdGhpcy5nbG9iYWxFdmVudHNbbF0uc3BsaWNlKHgsIDEpIDogdGhpcy5zY29wZS5ldmVudHMucmVtb3ZlKHRoaXMuc2NvcGUuZG9jdW1lbnQsIGwsIGMsIHApLCB0aGlzO1xuICAgICAgICAgIH0sIFwiVGhlIGludGVyYWN0Lm9mZigpIG1ldGhvZCBpcyBiZWluZyBkZXByZWNhdGVkXCIpLCBvLmRlYnVnID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5zY29wZTtcbiAgICAgICAgICB9LCBvLnN1cHBvcnRzVG91Y2ggPSBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHJldHVybiBvZS5zdXBwb3J0c1RvdWNoO1xuICAgICAgICAgIH0sIG8uc3VwcG9ydHNQb2ludGVyRXZlbnQgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHJldHVybiBvZS5zdXBwb3J0c1BvaW50ZXJFdmVudDtcbiAgICAgICAgICB9LCBvLnN0b3AgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIGZvciAodmFyIGwgPSAwLCBjID0gdGhpcy5zY29wZS5pbnRlcmFjdGlvbnMubGlzdDsgbCA8IGMubGVuZ3RoOyBsKyspIGNbbF0uc3RvcCgpO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgICAgfSwgby5wb2ludGVyTW92ZVRvbGVyYW5jZSA9IGZ1bmN0aW9uKGwpIHtcbiAgICAgICAgICAgIHJldHVybiB3Lm51bWJlcihsKSA/ICh0aGlzLnNjb3BlLmludGVyYWN0aW9ucy5wb2ludGVyTW92ZVRvbGVyYW5jZSA9IGwsIHRoaXMpIDogdGhpcy5zY29wZS5pbnRlcmFjdGlvbnMucG9pbnRlck1vdmVUb2xlcmFuY2U7XG4gICAgICAgICAgfSwgby5hZGREb2N1bWVudCA9IGZ1bmN0aW9uKGwsIGMpIHtcbiAgICAgICAgICAgIHRoaXMuc2NvcGUuYWRkRG9jdW1lbnQobCwgYyk7XG4gICAgICAgICAgfSwgby5yZW1vdmVEb2N1bWVudCA9IGZ1bmN0aW9uKGwpIHtcbiAgICAgICAgICAgIHRoaXMuc2NvcGUucmVtb3ZlRG9jdW1lbnQobCk7XG4gICAgICAgICAgfSwgbztcbiAgICAgICAgfSh0aGlzKSwgdGhpcy5JbnRlcmFjdEV2ZW50ID0gb3IsIHRoaXMuSW50ZXJhY3RhYmxlID0gdm9pZCAwLCB0aGlzLmludGVyYWN0YWJsZXMgPSBuZXcgTm8odGhpcyksIHRoaXMuX3dpbiA9IHZvaWQgMCwgdGhpcy5kb2N1bWVudCA9IHZvaWQgMCwgdGhpcy53aW5kb3cgPSB2b2lkIDAsIHRoaXMuZG9jdW1lbnRzID0gW10sIHRoaXMuX3BsdWdpbnMgPSB7IGxpc3Q6IFtdLCBtYXA6IHt9IH0sIHRoaXMub25XaW5kb3dVbmxvYWQgPSBmdW5jdGlvbihuKSB7XG4gICAgICAgICAgcmV0dXJuIGUucmVtb3ZlRG9jdW1lbnQobi50YXJnZXQpO1xuICAgICAgICB9O1xuICAgICAgICB2YXIgciA9IHRoaXM7XG4gICAgICAgIHRoaXMuSW50ZXJhY3RhYmxlID0gZnVuY3Rpb24obikge1xuICAgICAgICAgIEMobCwgbik7XG4gICAgICAgICAgdmFyIG8gPSBQKGwpO1xuICAgICAgICAgIGZ1bmN0aW9uIGwoKSB7XG4gICAgICAgICAgICByZXR1cm4gZih0aGlzLCBsKSwgby5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4geShsLCBbeyBrZXk6IFwiX2RlZmF1bHRzXCIsIGdldDogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICByZXR1cm4gci5kZWZhdWx0cztcbiAgICAgICAgICB9IH0sIHsga2V5OiBcInNldFwiLCB2YWx1ZTogZnVuY3Rpb24oYykge1xuICAgICAgICAgICAgcmV0dXJuIF8oRChsLnByb3RvdHlwZSksIFwic2V0XCIsIHRoaXMpLmNhbGwodGhpcywgYyksIHIuZmlyZShcImludGVyYWN0YWJsZTpzZXRcIiwgeyBvcHRpb25zOiBjLCBpbnRlcmFjdGFibGU6IHRoaXMgfSksIHRoaXM7XG4gICAgICAgICAgfSB9LCB7IGtleTogXCJ1bnNldFwiLCB2YWx1ZTogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICBfKEQobC5wcm90b3R5cGUpLCBcInVuc2V0XCIsIHRoaXMpLmNhbGwodGhpcyk7XG4gICAgICAgICAgICB2YXIgYyA9IHIuaW50ZXJhY3RhYmxlcy5saXN0LmluZGV4T2YodGhpcyk7XG4gICAgICAgICAgICBjIDwgMCB8fCAoci5pbnRlcmFjdGFibGVzLmxpc3Quc3BsaWNlKGMsIDEpLCByLmZpcmUoXCJpbnRlcmFjdGFibGU6dW5zZXRcIiwgeyBpbnRlcmFjdGFibGU6IHRoaXMgfSkpO1xuICAgICAgICAgIH0gfV0pLCBsO1xuICAgICAgICB9KFVvKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB5KHQsIFt7IGtleTogXCJhZGRMaXN0ZW5lcnNcIiwgdmFsdWU6IGZ1bmN0aW9uKGUsIHIpIHtcbiAgICAgICAgdGhpcy5saXN0ZW5lck1hcHMucHVzaCh7IGlkOiByLCBtYXA6IGUgfSk7XG4gICAgICB9IH0sIHsga2V5OiBcImZpcmVcIiwgdmFsdWU6IGZ1bmN0aW9uKGUsIHIpIHtcbiAgICAgICAgZm9yICh2YXIgbiA9IDAsIG8gPSB0aGlzLmxpc3RlbmVyTWFwczsgbiA8IG8ubGVuZ3RoOyBuKyspIHtcbiAgICAgICAgICB2YXIgbCA9IG9bbl0ubWFwW2VdO1xuICAgICAgICAgIGlmIChsICYmIGwociwgdGhpcywgZSkgPT09ICExKSByZXR1cm4gITE7XG4gICAgICAgIH1cbiAgICAgIH0gfSwgeyBrZXk6IFwiaW5pdFwiLCB2YWx1ZTogZnVuY3Rpb24oZSkge1xuICAgICAgICByZXR1cm4gdGhpcy5pc0luaXRpYWxpemVkID8gdGhpcyA6IGZ1bmN0aW9uKHIsIG4pIHtcbiAgICAgICAgICByZXR1cm4gci5pc0luaXRpYWxpemVkID0gITAsIHcud2luZG93KG4pICYmIFgobiksIFEuaW5pdChuKSwgb2UuaW5pdChuKSwgYmUuaW5pdChuKSwgci53aW5kb3cgPSBuLCByLmRvY3VtZW50ID0gbi5kb2N1bWVudCwgci51c2VQbHVnaW4oRm8pLCByLnVzZVBsdWdpbihMbyksIHI7XG4gICAgICAgIH0odGhpcywgZSk7XG4gICAgICB9IH0sIHsga2V5OiBcInBsdWdpbklzSW5zdGFsbGVkXCIsIHZhbHVlOiBmdW5jdGlvbihlKSB7XG4gICAgICAgIHZhciByID0gZS5pZDtcbiAgICAgICAgcmV0dXJuIHIgPyAhIXRoaXMuX3BsdWdpbnMubWFwW3JdIDogdGhpcy5fcGx1Z2lucy5saXN0LmluZGV4T2YoZSkgIT09IC0xO1xuICAgICAgfSB9LCB7IGtleTogXCJ1c2VQbHVnaW5cIiwgdmFsdWU6IGZ1bmN0aW9uKGUsIHIpIHtcbiAgICAgICAgaWYgKCF0aGlzLmlzSW5pdGlhbGl6ZWQpIHJldHVybiB0aGlzO1xuICAgICAgICBpZiAodGhpcy5wbHVnaW5Jc0luc3RhbGxlZChlKSkgcmV0dXJuIHRoaXM7XG4gICAgICAgIGlmIChlLmlkICYmICh0aGlzLl9wbHVnaW5zLm1hcFtlLmlkXSA9IGUpLCB0aGlzLl9wbHVnaW5zLmxpc3QucHVzaChlKSwgZS5pbnN0YWxsICYmIGUuaW5zdGFsbCh0aGlzLCByKSwgZS5saXN0ZW5lcnMgJiYgZS5iZWZvcmUpIHtcbiAgICAgICAgICBmb3IgKHZhciBuID0gMCwgbyA9IHRoaXMubGlzdGVuZXJNYXBzLmxlbmd0aCwgbCA9IGUuYmVmb3JlLnJlZHVjZShmdW5jdGlvbihwLCBoKSB7XG4gICAgICAgICAgICByZXR1cm4gcFtoXSA9ICEwLCBwW1JuKGgpXSA9ICEwLCBwO1xuICAgICAgICAgIH0sIHt9KTsgbiA8IG87IG4rKykge1xuICAgICAgICAgICAgdmFyIGMgPSB0aGlzLmxpc3RlbmVyTWFwc1tuXS5pZDtcbiAgICAgICAgICAgIGlmIChjICYmIChsW2NdIHx8IGxbUm4oYyldKSkgYnJlYWs7XG4gICAgICAgICAgfVxuICAgICAgICAgIHRoaXMubGlzdGVuZXJNYXBzLnNwbGljZShuLCAwLCB7IGlkOiBlLmlkLCBtYXA6IGUubGlzdGVuZXJzIH0pO1xuICAgICAgICB9IGVsc2UgZS5saXN0ZW5lcnMgJiYgdGhpcy5saXN0ZW5lck1hcHMucHVzaCh7IGlkOiBlLmlkLCBtYXA6IGUubGlzdGVuZXJzIH0pO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgIH0gfSwgeyBrZXk6IFwiYWRkRG9jdW1lbnRcIiwgdmFsdWU6IGZ1bmN0aW9uKGUsIHIpIHtcbiAgICAgICAgaWYgKHRoaXMuZ2V0RG9jSW5kZXgoZSkgIT09IC0xKSByZXR1cm4gITE7XG4gICAgICAgIHZhciBuID0gQihlKTtcbiAgICAgICAgciA9IHIgPyBXKHt9LCByKSA6IHt9LCB0aGlzLmRvY3VtZW50cy5wdXNoKHsgZG9jOiBlLCBvcHRpb25zOiByIH0pLCB0aGlzLmV2ZW50cy5kb2N1bWVudHMucHVzaChlKSwgZSAhPT0gdGhpcy5kb2N1bWVudCAmJiB0aGlzLmV2ZW50cy5hZGQobiwgXCJ1bmxvYWRcIiwgdGhpcy5vbldpbmRvd1VubG9hZCksIHRoaXMuZmlyZShcInNjb3BlOmFkZC1kb2N1bWVudFwiLCB7IGRvYzogZSwgd2luZG93OiBuLCBzY29wZTogdGhpcywgb3B0aW9uczogciB9KTtcbiAgICAgIH0gfSwgeyBrZXk6IFwicmVtb3ZlRG9jdW1lbnRcIiwgdmFsdWU6IGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgdmFyIHIgPSB0aGlzLmdldERvY0luZGV4KGUpLCBuID0gQihlKSwgbyA9IHRoaXMuZG9jdW1lbnRzW3JdLm9wdGlvbnM7XG4gICAgICAgIHRoaXMuZXZlbnRzLnJlbW92ZShuLCBcInVubG9hZFwiLCB0aGlzLm9uV2luZG93VW5sb2FkKSwgdGhpcy5kb2N1bWVudHMuc3BsaWNlKHIsIDEpLCB0aGlzLmV2ZW50cy5kb2N1bWVudHMuc3BsaWNlKHIsIDEpLCB0aGlzLmZpcmUoXCJzY29wZTpyZW1vdmUtZG9jdW1lbnRcIiwgeyBkb2M6IGUsIHdpbmRvdzogbiwgc2NvcGU6IHRoaXMsIG9wdGlvbnM6IG8gfSk7XG4gICAgICB9IH0sIHsga2V5OiBcImdldERvY0luZGV4XCIsIHZhbHVlOiBmdW5jdGlvbihlKSB7XG4gICAgICAgIGZvciAodmFyIHIgPSAwOyByIDwgdGhpcy5kb2N1bWVudHMubGVuZ3RoOyByKyspIGlmICh0aGlzLmRvY3VtZW50c1tyXS5kb2MgPT09IGUpIHJldHVybiByO1xuICAgICAgICByZXR1cm4gLTE7XG4gICAgICB9IH0sIHsga2V5OiBcImdldERvY09wdGlvbnNcIiwgdmFsdWU6IGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgdmFyIHIgPSB0aGlzLmdldERvY0luZGV4KGUpO1xuICAgICAgICByZXR1cm4gciA9PT0gLTEgPyBudWxsIDogdGhpcy5kb2N1bWVudHNbcl0ub3B0aW9ucztcbiAgICAgIH0gfSwgeyBrZXk6IFwibm93XCIsIHZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuICh0aGlzLndpbmRvdy5EYXRlIHx8IERhdGUpLm5vdygpO1xuICAgICAgfSB9XSksIHQ7XG4gICAgfSgpO1xuICAgIGZ1bmN0aW9uIFJuKHQpIHtcbiAgICAgIHJldHVybiB0ICYmIHQucmVwbGFjZSgvXFwvLiokLywgXCJcIik7XG4gICAgfVxuICAgIHZhciBEbiA9IG5ldyBHbygpLCBlZSA9IERuLmludGVyYWN0U3RhdGljLCBZbyA9IHR5cGVvZiBnbG9iYWxUaGlzIDwgXCJ1XCIgPyBnbG9iYWxUaGlzIDogd2luZG93O1xuICAgIERuLmluaXQoWW8pO1xuICAgIHZhciBLbyA9IE9iamVjdC5mcmVlemUoeyBfX3Byb3RvX186IG51bGwsIGVkZ2VUYXJnZXQ6IGZ1bmN0aW9uKCkge1xuICAgIH0sIGVsZW1lbnRzOiBmdW5jdGlvbigpIHtcbiAgICB9LCBncmlkOiBmdW5jdGlvbih0KSB7XG4gICAgICB2YXIgZSA9IFtbXCJ4XCIsIFwieVwiXSwgW1wibGVmdFwiLCBcInRvcFwiXSwgW1wicmlnaHRcIiwgXCJib3R0b21cIl0sIFtcIndpZHRoXCIsIFwiaGVpZ2h0XCJdXS5maWx0ZXIoZnVuY3Rpb24obikge1xuICAgICAgICB2YXIgbyA9IG5bMF0sIGwgPSBuWzFdO1xuICAgICAgICByZXR1cm4gbyBpbiB0IHx8IGwgaW4gdDtcbiAgICAgIH0pLCByID0gZnVuY3Rpb24obiwgbykge1xuICAgICAgICBmb3IgKHZhciBsID0gdC5yYW5nZSwgYyA9IHQubGltaXRzLCBwID0gYyA9PT0gdm9pZCAwID8geyBsZWZ0OiAtMSAvIDAsIHJpZ2h0OiAxIC8gMCwgdG9wOiAtMSAvIDAsIGJvdHRvbTogMSAvIDAgfSA6IGMsIGggPSB0Lm9mZnNldCwgZyA9IGggPT09IHZvaWQgMCA/IHsgeDogMCwgeTogMCB9IDogaCwgZCA9IHsgcmFuZ2U6IGwsIGdyaWQ6IHQsIHg6IG51bGwsIHk6IG51bGwgfSwgYiA9IDA7IGIgPCBlLmxlbmd0aDsgYisrKSB7XG4gICAgICAgICAgdmFyIHggPSBlW2JdLCBJID0geFswXSwgRSA9IHhbMV0sIE0gPSBNYXRoLnJvdW5kKChuIC0gZy54KSAvIHRbSV0pLCAkID0gTWF0aC5yb3VuZCgobyAtIGcueSkgLyB0W0VdKTtcbiAgICAgICAgICBkW0ldID0gTWF0aC5tYXgocC5sZWZ0LCBNYXRoLm1pbihwLnJpZ2h0LCBNICogdFtJXSArIGcueCkpLCBkW0VdID0gTWF0aC5tYXgocC50b3AsIE1hdGgubWluKHAuYm90dG9tLCAkICogdFtFXSArIGcueSkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBkO1xuICAgICAgfTtcbiAgICAgIHJldHVybiByLmdyaWQgPSB0LCByLmNvb3JkRmllbGRzID0gZSwgcjtcbiAgICB9IH0pLCBYbyA9IHsgaWQ6IFwic25hcHBlcnNcIiwgaW5zdGFsbDogZnVuY3Rpb24odCkge1xuICAgICAgdmFyIGUgPSB0LmludGVyYWN0U3RhdGljO1xuICAgICAgZS5zbmFwcGVycyA9IFcoZS5zbmFwcGVycyB8fCB7fSwgS28pLCBlLmNyZWF0ZVNuYXBHcmlkID0gZS5zbmFwcGVycy5ncmlkO1xuICAgIH0gfSwgQm8gPSBYbywgVm8gPSB7IHN0YXJ0OiBmdW5jdGlvbih0KSB7XG4gICAgICB2YXIgZSA9IHQuc3RhdGUsIHIgPSB0LnJlY3QsIG4gPSB0LmVkZ2VzLCBvID0gdC5wYWdlQ29vcmRzLCBsID0gZS5vcHRpb25zLCBjID0gbC5yYXRpbywgcCA9IGwuZW5hYmxlZCwgaCA9IGUub3B0aW9ucywgZyA9IGguZXF1YWxEZWx0YSwgZCA9IGgubW9kaWZpZXJzO1xuICAgICAgYyA9PT0gXCJwcmVzZXJ2ZVwiICYmIChjID0gci53aWR0aCAvIHIuaGVpZ2h0KSwgZS5zdGFydENvb3JkcyA9IFcoe30sIG8pLCBlLnN0YXJ0UmVjdCA9IFcoe30sIHIpLCBlLnJhdGlvID0gYywgZS5lcXVhbERlbHRhID0gZztcbiAgICAgIHZhciBiID0gZS5saW5rZWRFZGdlcyA9IHsgdG9wOiBuLnRvcCB8fCBuLmxlZnQgJiYgIW4uYm90dG9tLCBsZWZ0OiBuLmxlZnQgfHwgbi50b3AgJiYgIW4ucmlnaHQsIGJvdHRvbTogbi5ib3R0b20gfHwgbi5yaWdodCAmJiAhbi50b3AsIHJpZ2h0OiBuLnJpZ2h0IHx8IG4uYm90dG9tICYmICFuLmxlZnQgfTtcbiAgICAgIGlmIChlLnhJc1ByaW1hcnlBeGlzID0gISghbi5sZWZ0ICYmICFuLnJpZ2h0KSwgZS5lcXVhbERlbHRhKSB7XG4gICAgICAgIHZhciB4ID0gKGIubGVmdCA/IDEgOiAtMSkgKiAoYi50b3AgPyAxIDogLTEpO1xuICAgICAgICBlLmVkZ2VTaWduID0geyB4LCB5OiB4IH07XG4gICAgICB9IGVsc2UgZS5lZGdlU2lnbiA9IHsgeDogYi5sZWZ0ID8gLTEgOiAxLCB5OiBiLnRvcCA/IC0xIDogMSB9O1xuICAgICAgaWYgKHAgIT09ICExICYmIFcobiwgYiksIGQgIT0gbnVsbCAmJiBkLmxlbmd0aCkge1xuICAgICAgICB2YXIgSSA9IG5ldyBpcih0LmludGVyYWN0aW9uKTtcbiAgICAgICAgSS5jb3B5RnJvbSh0LmludGVyYWN0aW9uLm1vZGlmaWNhdGlvbiksIEkucHJlcGFyZVN0YXRlcyhkKSwgZS5zdWJNb2RpZmljYXRpb24gPSBJLCBJLnN0YXJ0QWxsKHUoe30sIHQpKTtcbiAgICAgIH1cbiAgICB9LCBzZXQ6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHZhciBlID0gdC5zdGF0ZSwgciA9IHQucmVjdCwgbiA9IHQuY29vcmRzLCBvID0gZS5saW5rZWRFZGdlcywgbCA9IFcoe30sIG4pLCBjID0gZS5lcXVhbERlbHRhID8gcW8gOiBabztcbiAgICAgIGlmIChXKHQuZWRnZXMsIG8pLCBjKGUsIGUueElzUHJpbWFyeUF4aXMsIG4sIHIpLCAhZS5zdWJNb2RpZmljYXRpb24pIHJldHVybiBudWxsO1xuICAgICAgdmFyIHAgPSBXKHt9LCByKTtcbiAgICAgIG90KG8sIHAsIHsgeDogbi54IC0gbC54LCB5OiBuLnkgLSBsLnkgfSk7XG4gICAgICB2YXIgaCA9IGUuc3ViTW9kaWZpY2F0aW9uLnNldEFsbCh1KHUoe30sIHQpLCB7fSwgeyByZWN0OiBwLCBlZGdlczogbywgcGFnZUNvb3JkczogbiwgcHJldkNvb3JkczogbiwgcHJldlJlY3Q6IHAgfSkpLCBnID0gaC5kZWx0YTtcbiAgICAgIHJldHVybiBoLmNoYW5nZWQgJiYgKGMoZSwgTWF0aC5hYnMoZy54KSA+IE1hdGguYWJzKGcueSksIGguY29vcmRzLCBoLnJlY3QpLCBXKG4sIGguY29vcmRzKSksIGguZXZlbnRQcm9wcztcbiAgICB9LCBkZWZhdWx0czogeyByYXRpbzogXCJwcmVzZXJ2ZVwiLCBlcXVhbERlbHRhOiAhMSwgbW9kaWZpZXJzOiBbXSwgZW5hYmxlZDogITEgfSB9O1xuICAgIGZ1bmN0aW9uIHFvKHQsIGUsIHIpIHtcbiAgICAgIHZhciBuID0gdC5zdGFydENvb3JkcywgbyA9IHQuZWRnZVNpZ247XG4gICAgICBlID8gci55ID0gbi55ICsgKHIueCAtIG4ueCkgKiBvLnkgOiByLnggPSBuLnggKyAoci55IC0gbi55KSAqIG8ueDtcbiAgICB9XG4gICAgZnVuY3Rpb24gWm8odCwgZSwgciwgbikge1xuICAgICAgdmFyIG8gPSB0LnN0YXJ0UmVjdCwgbCA9IHQuc3RhcnRDb29yZHMsIGMgPSB0LnJhdGlvLCBwID0gdC5lZGdlU2lnbjtcbiAgICAgIGlmIChlKSB7XG4gICAgICAgIHZhciBoID0gbi53aWR0aCAvIGM7XG4gICAgICAgIHIueSA9IGwueSArIChoIC0gby5oZWlnaHQpICogcC55O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdmFyIGcgPSBuLmhlaWdodCAqIGM7XG4gICAgICAgIHIueCA9IGwueCArIChnIC0gby53aWR0aCkgKiBwLng7XG4gICAgICB9XG4gICAgfVxuICAgIHZhciBKbyA9IHllKFZvLCBcImFzcGVjdFJhdGlvXCIpLCBrbiA9IGZ1bmN0aW9uKCkge1xuICAgIH07XG4gICAga24uX2RlZmF1bHRzID0ge307XG4gICAgdmFyIHZ0ID0ga247XG4gICAgZnVuY3Rpb24gRWUodCwgZSwgcikge1xuICAgICAgcmV0dXJuIHcuZnVuYyh0KSA/IFVlKHQsIGUuaW50ZXJhY3RhYmxlLCBlLmVsZW1lbnQsIFtyLngsIHIueSwgZV0pIDogVWUodCwgZS5pbnRlcmFjdGFibGUsIGUuZWxlbWVudCk7XG4gICAgfVxuICAgIHZhciBndCA9IHsgc3RhcnQ6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHZhciBlID0gdC5yZWN0LCByID0gdC5zdGFydE9mZnNldCwgbiA9IHQuc3RhdGUsIG8gPSB0LmludGVyYWN0aW9uLCBsID0gdC5wYWdlQ29vcmRzLCBjID0gbi5vcHRpb25zLCBwID0gYy5lbGVtZW50UmVjdCwgaCA9IFcoeyBsZWZ0OiAwLCB0b3A6IDAsIHJpZ2h0OiAwLCBib3R0b206IDAgfSwgYy5vZmZzZXQgfHwge30pO1xuICAgICAgaWYgKGUgJiYgcCkge1xuICAgICAgICB2YXIgZyA9IEVlKGMucmVzdHJpY3Rpb24sIG8sIGwpO1xuICAgICAgICBpZiAoZykge1xuICAgICAgICAgIHZhciBkID0gZy5yaWdodCAtIGcubGVmdCAtIGUud2lkdGgsIGIgPSBnLmJvdHRvbSAtIGcudG9wIC0gZS5oZWlnaHQ7XG4gICAgICAgICAgZCA8IDAgJiYgKGgubGVmdCArPSBkLCBoLnJpZ2h0ICs9IGQpLCBiIDwgMCAmJiAoaC50b3AgKz0gYiwgaC5ib3R0b20gKz0gYik7XG4gICAgICAgIH1cbiAgICAgICAgaC5sZWZ0ICs9IHIubGVmdCAtIGUud2lkdGggKiBwLmxlZnQsIGgudG9wICs9IHIudG9wIC0gZS5oZWlnaHQgKiBwLnRvcCwgaC5yaWdodCArPSByLnJpZ2h0IC0gZS53aWR0aCAqICgxIC0gcC5yaWdodCksIGguYm90dG9tICs9IHIuYm90dG9tIC0gZS5oZWlnaHQgKiAoMSAtIHAuYm90dG9tKTtcbiAgICAgIH1cbiAgICAgIG4ub2Zmc2V0ID0gaDtcbiAgICB9LCBzZXQ6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHZhciBlID0gdC5jb29yZHMsIHIgPSB0LmludGVyYWN0aW9uLCBuID0gdC5zdGF0ZSwgbyA9IG4ub3B0aW9ucywgbCA9IG4ub2Zmc2V0LCBjID0gRWUoby5yZXN0cmljdGlvbiwgciwgZSk7XG4gICAgICBpZiAoYykge1xuICAgICAgICB2YXIgcCA9IGZ1bmN0aW9uKGgpIHtcbiAgICAgICAgICByZXR1cm4gIWggfHwgXCJsZWZ0XCIgaW4gaCAmJiBcInRvcFwiIGluIGggfHwgKChoID0gVyh7fSwgaCkpLmxlZnQgPSBoLnggfHwgMCwgaC50b3AgPSBoLnkgfHwgMCwgaC5yaWdodCA9IGgucmlnaHQgfHwgaC5sZWZ0ICsgaC53aWR0aCwgaC5ib3R0b20gPSBoLmJvdHRvbSB8fCBoLnRvcCArIGguaGVpZ2h0KSwgaDtcbiAgICAgICAgfShjKTtcbiAgICAgICAgZS54ID0gTWF0aC5tYXgoTWF0aC5taW4ocC5yaWdodCAtIGwucmlnaHQsIGUueCksIHAubGVmdCArIGwubGVmdCksIGUueSA9IE1hdGgubWF4KE1hdGgubWluKHAuYm90dG9tIC0gbC5ib3R0b20sIGUueSksIHAudG9wICsgbC50b3ApO1xuICAgICAgfVxuICAgIH0sIGRlZmF1bHRzOiB7IHJlc3RyaWN0aW9uOiBudWxsLCBlbGVtZW50UmVjdDogbnVsbCwgb2Zmc2V0OiBudWxsLCBlbmRPbmx5OiAhMSwgZW5hYmxlZDogITEgfSB9LCBRbyA9IHllKGd0LCBcInJlc3RyaWN0XCIpLCB6biA9IHsgdG9wOiAxIC8gMCwgbGVmdDogMSAvIDAsIGJvdHRvbTogLTEgLyAwLCByaWdodDogLTEgLyAwIH0sICRuID0geyB0b3A6IC0xIC8gMCwgbGVmdDogLTEgLyAwLCBib3R0b206IDEgLyAwLCByaWdodDogMSAvIDAgfTtcbiAgICBmdW5jdGlvbiBqbih0LCBlKSB7XG4gICAgICBmb3IgKHZhciByID0gMCwgbiA9IFtcInRvcFwiLCBcImxlZnRcIiwgXCJib3R0b21cIiwgXCJyaWdodFwiXTsgciA8IG4ubGVuZ3RoOyByKyspIHtcbiAgICAgICAgdmFyIG8gPSBuW3JdO1xuICAgICAgICBvIGluIHQgfHwgKHRbb10gPSBlW29dKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB0O1xuICAgIH1cbiAgICB2YXIgWmUgPSB7IG5vSW5uZXI6IHpuLCBub091dGVyOiAkbiwgc3RhcnQ6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHZhciBlLCByID0gdC5pbnRlcmFjdGlvbiwgbiA9IHQuc3RhcnRPZmZzZXQsIG8gPSB0LnN0YXRlLCBsID0gby5vcHRpb25zO1xuICAgICAgbCAmJiAoZSA9IGl0KEVlKGwub2Zmc2V0LCByLCByLmNvb3Jkcy5zdGFydC5wYWdlKSkpLCBlID0gZSB8fCB7IHg6IDAsIHk6IDAgfSwgby5vZmZzZXQgPSB7IHRvcDogZS55ICsgbi50b3AsIGxlZnQ6IGUueCArIG4ubGVmdCwgYm90dG9tOiBlLnkgLSBuLmJvdHRvbSwgcmlnaHQ6IGUueCAtIG4ucmlnaHQgfTtcbiAgICB9LCBzZXQ6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHZhciBlID0gdC5jb29yZHMsIHIgPSB0LmVkZ2VzLCBuID0gdC5pbnRlcmFjdGlvbiwgbyA9IHQuc3RhdGUsIGwgPSBvLm9mZnNldCwgYyA9IG8ub3B0aW9ucztcbiAgICAgIGlmIChyKSB7XG4gICAgICAgIHZhciBwID0gVyh7fSwgZSksIGggPSBFZShjLmlubmVyLCBuLCBwKSB8fCB7fSwgZyA9IEVlKGMub3V0ZXIsIG4sIHApIHx8IHt9O1xuICAgICAgICBqbihoLCB6biksIGpuKGcsICRuKSwgci50b3AgPyBlLnkgPSBNYXRoLm1pbihNYXRoLm1heChnLnRvcCArIGwudG9wLCBwLnkpLCBoLnRvcCArIGwudG9wKSA6IHIuYm90dG9tICYmIChlLnkgPSBNYXRoLm1heChNYXRoLm1pbihnLmJvdHRvbSArIGwuYm90dG9tLCBwLnkpLCBoLmJvdHRvbSArIGwuYm90dG9tKSksIHIubGVmdCA/IGUueCA9IE1hdGgubWluKE1hdGgubWF4KGcubGVmdCArIGwubGVmdCwgcC54KSwgaC5sZWZ0ICsgbC5sZWZ0KSA6IHIucmlnaHQgJiYgKGUueCA9IE1hdGgubWF4KE1hdGgubWluKGcucmlnaHQgKyBsLnJpZ2h0LCBwLngpLCBoLnJpZ2h0ICsgbC5yaWdodCkpO1xuICAgICAgfVxuICAgIH0sIGRlZmF1bHRzOiB7IGlubmVyOiBudWxsLCBvdXRlcjogbnVsbCwgb2Zmc2V0OiBudWxsLCBlbmRPbmx5OiAhMSwgZW5hYmxlZDogITEgfSB9LCBlcyA9IHllKFplLCBcInJlc3RyaWN0RWRnZXNcIiksIHRzID0gVyh7IGdldCBlbGVtZW50UmVjdCgpIHtcbiAgICAgIHJldHVybiB7IHRvcDogMCwgbGVmdDogMCwgYm90dG9tOiAxLCByaWdodDogMSB9O1xuICAgIH0sIHNldCBlbGVtZW50UmVjdCh0KSB7XG4gICAgfSB9LCBndC5kZWZhdWx0cyksIHJzID0geWUoeyBzdGFydDogZ3Quc3RhcnQsIHNldDogZ3Quc2V0LCBkZWZhdWx0czogdHMgfSwgXCJyZXN0cmljdFJlY3RcIiksIG5zID0geyB3aWR0aDogLTEgLyAwLCBoZWlnaHQ6IC0xIC8gMCB9LCBpcyA9IHsgd2lkdGg6IDEgLyAwLCBoZWlnaHQ6IDEgLyAwIH0sIG9zID0geWUoeyBzdGFydDogZnVuY3Rpb24odCkge1xuICAgICAgcmV0dXJuIFplLnN0YXJ0KHQpO1xuICAgIH0sIHNldDogZnVuY3Rpb24odCkge1xuICAgICAgdmFyIGUgPSB0LmludGVyYWN0aW9uLCByID0gdC5zdGF0ZSwgbiA9IHQucmVjdCwgbyA9IHQuZWRnZXMsIGwgPSByLm9wdGlvbnM7XG4gICAgICBpZiAobykge1xuICAgICAgICB2YXIgYyA9IEd0KEVlKGwubWluLCBlLCB0LmNvb3JkcykpIHx8IG5zLCBwID0gR3QoRWUobC5tYXgsIGUsIHQuY29vcmRzKSkgfHwgaXM7XG4gICAgICAgIHIub3B0aW9ucyA9IHsgZW5kT25seTogbC5lbmRPbmx5LCBpbm5lcjogVyh7fSwgWmUubm9Jbm5lciksIG91dGVyOiBXKHt9LCBaZS5ub091dGVyKSB9LCBvLnRvcCA/IChyLm9wdGlvbnMuaW5uZXIudG9wID0gbi5ib3R0b20gLSBjLmhlaWdodCwgci5vcHRpb25zLm91dGVyLnRvcCA9IG4uYm90dG9tIC0gcC5oZWlnaHQpIDogby5ib3R0b20gJiYgKHIub3B0aW9ucy5pbm5lci5ib3R0b20gPSBuLnRvcCArIGMuaGVpZ2h0LCByLm9wdGlvbnMub3V0ZXIuYm90dG9tID0gbi50b3AgKyBwLmhlaWdodCksIG8ubGVmdCA/IChyLm9wdGlvbnMuaW5uZXIubGVmdCA9IG4ucmlnaHQgLSBjLndpZHRoLCByLm9wdGlvbnMub3V0ZXIubGVmdCA9IG4ucmlnaHQgLSBwLndpZHRoKSA6IG8ucmlnaHQgJiYgKHIub3B0aW9ucy5pbm5lci5yaWdodCA9IG4ubGVmdCArIGMud2lkdGgsIHIub3B0aW9ucy5vdXRlci5yaWdodCA9IG4ubGVmdCArIHAud2lkdGgpLCBaZS5zZXQodCksIHIub3B0aW9ucyA9IGw7XG4gICAgICB9XG4gICAgfSwgZGVmYXVsdHM6IHsgbWluOiBudWxsLCBtYXg6IG51bGwsIGVuZE9ubHk6ICExLCBlbmFibGVkOiAhMSB9IH0sIFwicmVzdHJpY3RTaXplXCIpLCB1ciA9IHsgc3RhcnQ6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHZhciBlLCByID0gdC5pbnRlcmFjdGlvbiwgbiA9IHQuaW50ZXJhY3RhYmxlLCBvID0gdC5lbGVtZW50LCBsID0gdC5yZWN0LCBjID0gdC5zdGF0ZSwgcCA9IHQuc3RhcnRPZmZzZXQsIGggPSBjLm9wdGlvbnMsIGcgPSBoLm9mZnNldFdpdGhPcmlnaW4gPyBmdW5jdGlvbih4KSB7XG4gICAgICAgIHZhciBJID0geC5pbnRlcmFjdGlvbi5lbGVtZW50LCBFID0gaXQoVWUoeC5zdGF0ZS5vcHRpb25zLm9yaWdpbiwgbnVsbCwgbnVsbCwgW0ldKSksIE0gPSBFIHx8IE5lKHguaW50ZXJhY3RhYmxlLCBJLCB4LmludGVyYWN0aW9uLnByZXBhcmVkLm5hbWUpO1xuICAgICAgICByZXR1cm4gTTtcbiAgICAgIH0odCkgOiB7IHg6IDAsIHk6IDAgfTtcbiAgICAgIGlmIChoLm9mZnNldCA9PT0gXCJzdGFydENvb3Jkc1wiKSBlID0geyB4OiByLmNvb3Jkcy5zdGFydC5wYWdlLngsIHk6IHIuY29vcmRzLnN0YXJ0LnBhZ2UueSB9O1xuICAgICAgZWxzZSB7XG4gICAgICAgIHZhciBkID0gVWUoaC5vZmZzZXQsIG4sIG8sIFtyXSk7XG4gICAgICAgIChlID0gaXQoZCkgfHwgeyB4OiAwLCB5OiAwIH0pLnggKz0gZy54LCBlLnkgKz0gZy55O1xuICAgICAgfVxuICAgICAgdmFyIGIgPSBoLnJlbGF0aXZlUG9pbnRzO1xuICAgICAgYy5vZmZzZXRzID0gbCAmJiBiICYmIGIubGVuZ3RoID8gYi5tYXAoZnVuY3Rpb24oeCwgSSkge1xuICAgICAgICByZXR1cm4geyBpbmRleDogSSwgcmVsYXRpdmVQb2ludDogeCwgeDogcC5sZWZ0IC0gbC53aWR0aCAqIHgueCArIGUueCwgeTogcC50b3AgLSBsLmhlaWdodCAqIHgueSArIGUueSB9O1xuICAgICAgfSkgOiBbeyBpbmRleDogMCwgcmVsYXRpdmVQb2ludDogbnVsbCwgeDogZS54LCB5OiBlLnkgfV07XG4gICAgfSwgc2V0OiBmdW5jdGlvbih0KSB7XG4gICAgICB2YXIgZSA9IHQuaW50ZXJhY3Rpb24sIHIgPSB0LmNvb3JkcywgbiA9IHQuc3RhdGUsIG8gPSBuLm9wdGlvbnMsIGwgPSBuLm9mZnNldHMsIGMgPSBOZShlLmludGVyYWN0YWJsZSwgZS5lbGVtZW50LCBlLnByZXBhcmVkLm5hbWUpLCBwID0gVyh7fSwgciksIGggPSBbXTtcbiAgICAgIG8ub2Zmc2V0V2l0aE9yaWdpbiB8fCAocC54IC09IGMueCwgcC55IC09IGMueSk7XG4gICAgICBmb3IgKHZhciBnID0gMCwgZCA9IGw7IGcgPCBkLmxlbmd0aDsgZysrKSBmb3IgKHZhciBiID0gZFtnXSwgeCA9IHAueCAtIGIueCwgSSA9IHAueSAtIGIueSwgRSA9IDAsIE0gPSBvLnRhcmdldHMubGVuZ3RoOyBFIDwgTTsgRSsrKSB7XG4gICAgICAgIHZhciAkID0gby50YXJnZXRzW0VdLCB6ID0gdm9pZCAwO1xuICAgICAgICAoeiA9IHcuZnVuYygkKSA/ICQoeCwgSSwgZS5fcHJveHksIGIsIEUpIDogJCkgJiYgaC5wdXNoKHsgeDogKHcubnVtYmVyKHoueCkgPyB6LnggOiB4KSArIGIueCwgeTogKHcubnVtYmVyKHoueSkgPyB6LnkgOiBJKSArIGIueSwgcmFuZ2U6IHcubnVtYmVyKHoucmFuZ2UpID8gei5yYW5nZSA6IG8ucmFuZ2UsIHNvdXJjZTogJCwgaW5kZXg6IEUsIG9mZnNldDogYiB9KTtcbiAgICAgIH1cbiAgICAgIGZvciAodmFyIEEgPSB7IHRhcmdldDogbnVsbCwgaW5SYW5nZTogITEsIGRpc3RhbmNlOiAwLCByYW5nZTogMCwgZGVsdGE6IHsgeDogMCwgeTogMCB9IH0sIE4gPSAwOyBOIDwgaC5sZW5ndGg7IE4rKykge1xuICAgICAgICB2YXIgSyA9IGhbTl0sIEYgPSBLLnJhbmdlLCBHID0gSy54IC0gcC54LCB0ZSA9IEsueSAtIHAueSwgSiA9IEdlKEcsIHRlKSwgcmUgPSBKIDw9IEY7XG4gICAgICAgIEYgPT09IDEgLyAwICYmIEEuaW5SYW5nZSAmJiBBLnJhbmdlICE9PSAxIC8gMCAmJiAocmUgPSAhMSksIEEudGFyZ2V0ICYmICEocmUgPyBBLmluUmFuZ2UgJiYgRiAhPT0gMSAvIDAgPyBKIC8gRiA8IEEuZGlzdGFuY2UgLyBBLnJhbmdlIDogRiA9PT0gMSAvIDAgJiYgQS5yYW5nZSAhPT0gMSAvIDAgfHwgSiA8IEEuZGlzdGFuY2UgOiAhQS5pblJhbmdlICYmIEogPCBBLmRpc3RhbmNlKSB8fCAoQS50YXJnZXQgPSBLLCBBLmRpc3RhbmNlID0gSiwgQS5yYW5nZSA9IEYsIEEuaW5SYW5nZSA9IHJlLCBBLmRlbHRhLnggPSBHLCBBLmRlbHRhLnkgPSB0ZSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gQS5pblJhbmdlICYmIChyLnggPSBBLnRhcmdldC54LCByLnkgPSBBLnRhcmdldC55KSwgbi5jbG9zZXN0ID0gQSwgQTtcbiAgICB9LCBkZWZhdWx0czogeyByYW5nZTogMSAvIDAsIHRhcmdldHM6IG51bGwsIG9mZnNldDogbnVsbCwgb2Zmc2V0V2l0aE9yaWdpbjogITAsIG9yaWdpbjogbnVsbCwgcmVsYXRpdmVQb2ludHM6IG51bGwsIGVuZE9ubHk6ICExLCBlbmFibGVkOiAhMSB9IH0sIHNzID0geWUodXIsIFwic25hcFwiKSwgbXQgPSB7IHN0YXJ0OiBmdW5jdGlvbih0KSB7XG4gICAgICB2YXIgZSA9IHQuc3RhdGUsIHIgPSB0LmVkZ2VzLCBuID0gZS5vcHRpb25zO1xuICAgICAgaWYgKCFyKSByZXR1cm4gbnVsbDtcbiAgICAgIHQuc3RhdGUgPSB7IG9wdGlvbnM6IHsgdGFyZ2V0czogbnVsbCwgcmVsYXRpdmVQb2ludHM6IFt7IHg6IHIubGVmdCA/IDAgOiAxLCB5OiByLnRvcCA/IDAgOiAxIH1dLCBvZmZzZXQ6IG4ub2Zmc2V0IHx8IFwic2VsZlwiLCBvcmlnaW46IHsgeDogMCwgeTogMCB9LCByYW5nZTogbi5yYW5nZSB9IH0sIGUudGFyZ2V0RmllbGRzID0gZS50YXJnZXRGaWVsZHMgfHwgW1tcIndpZHRoXCIsIFwiaGVpZ2h0XCJdLCBbXCJ4XCIsIFwieVwiXV0sIHVyLnN0YXJ0KHQpLCBlLm9mZnNldHMgPSB0LnN0YXRlLm9mZnNldHMsIHQuc3RhdGUgPSBlO1xuICAgIH0sIHNldDogZnVuY3Rpb24odCkge1xuICAgICAgdmFyIGUgPSB0LmludGVyYWN0aW9uLCByID0gdC5zdGF0ZSwgbiA9IHQuY29vcmRzLCBvID0gci5vcHRpb25zLCBsID0gci5vZmZzZXRzLCBjID0geyB4OiBuLnggLSBsWzBdLngsIHk6IG4ueSAtIGxbMF0ueSB9O1xuICAgICAgci5vcHRpb25zID0gVyh7fSwgbyksIHIub3B0aW9ucy50YXJnZXRzID0gW107XG4gICAgICBmb3IgKHZhciBwID0gMCwgaCA9IG8udGFyZ2V0cyB8fCBbXTsgcCA8IGgubGVuZ3RoOyBwKyspIHtcbiAgICAgICAgdmFyIGcgPSBoW3BdLCBkID0gdm9pZCAwO1xuICAgICAgICBpZiAoZCA9IHcuZnVuYyhnKSA/IGcoYy54LCBjLnksIGUpIDogZykge1xuICAgICAgICAgIGZvciAodmFyIGIgPSAwLCB4ID0gci50YXJnZXRGaWVsZHM7IGIgPCB4Lmxlbmd0aDsgYisrKSB7XG4gICAgICAgICAgICB2YXIgSSA9IHhbYl0sIEUgPSBJWzBdLCBNID0gSVsxXTtcbiAgICAgICAgICAgIGlmIChFIGluIGQgfHwgTSBpbiBkKSB7XG4gICAgICAgICAgICAgIGQueCA9IGRbRV0sIGQueSA9IGRbTV07XG4gICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICByLm9wdGlvbnMudGFyZ2V0cy5wdXNoKGQpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICB2YXIgJCA9IHVyLnNldCh0KTtcbiAgICAgIHJldHVybiByLm9wdGlvbnMgPSBvLCAkO1xuICAgIH0sIGRlZmF1bHRzOiB7IHJhbmdlOiAxIC8gMCwgdGFyZ2V0czogbnVsbCwgb2Zmc2V0OiBudWxsLCBlbmRPbmx5OiAhMSwgZW5hYmxlZDogITEgfSB9LCBhcyA9IHllKG10LCBcInNuYXBTaXplXCIpLCBwciA9IHsgYXNwZWN0UmF0aW86IEpvLCByZXN0cmljdEVkZ2VzOiBlcywgcmVzdHJpY3Q6IFFvLCByZXN0cmljdFJlY3Q6IHJzLCByZXN0cmljdFNpemU6IG9zLCBzbmFwRWRnZXM6IHllKHsgc3RhcnQ6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHZhciBlID0gdC5lZGdlcztcbiAgICAgIHJldHVybiBlID8gKHQuc3RhdGUudGFyZ2V0RmllbGRzID0gdC5zdGF0ZS50YXJnZXRGaWVsZHMgfHwgW1tlLmxlZnQgPyBcImxlZnRcIiA6IFwicmlnaHRcIiwgZS50b3AgPyBcInRvcFwiIDogXCJib3R0b21cIl1dLCBtdC5zdGFydCh0KSkgOiBudWxsO1xuICAgIH0sIHNldDogbXQuc2V0LCBkZWZhdWx0czogVyhrZShtdC5kZWZhdWx0cyksIHsgdGFyZ2V0czogdm9pZCAwLCByYW5nZTogdm9pZCAwLCBvZmZzZXQ6IHsgeDogMCwgeTogMCB9IH0pIH0sIFwic25hcEVkZ2VzXCIpLCBzbmFwOiBzcywgc25hcFNpemU6IGFzLCBzcHJpbmc6IHZ0LCBhdm9pZDogdnQsIHRyYW5zZm9ybTogdnQsIHJ1YmJlcmJhbmQ6IHZ0IH0sIGxzID0geyBpZDogXCJtb2RpZmllcnNcIiwgaW5zdGFsbDogZnVuY3Rpb24odCkge1xuICAgICAgdmFyIGUgPSB0LmludGVyYWN0U3RhdGljO1xuICAgICAgZm9yICh2YXIgciBpbiB0LnVzZVBsdWdpbihibiksIHQudXNlUGx1Z2luKEJvKSwgZS5tb2RpZmllcnMgPSBwciwgcHIpIHtcbiAgICAgICAgdmFyIG4gPSBwcltyXSwgbyA9IG4uX2RlZmF1bHRzLCBsID0gbi5fbWV0aG9kcztcbiAgICAgICAgby5fbWV0aG9kcyA9IGwsIHQuZGVmYXVsdHMucGVyQWN0aW9uW3JdID0gbztcbiAgICAgIH1cbiAgICB9IH0sIGNzID0gbHMsIEFuID0gZnVuY3Rpb24odCkge1xuICAgICAgQyhyLCB0KTtcbiAgICAgIHZhciBlID0gUChyKTtcbiAgICAgIGZ1bmN0aW9uIHIobiwgbywgbCwgYywgcCwgaCkge1xuICAgICAgICB2YXIgZztcbiAgICAgICAgaWYgKGYodGhpcywgciksIHN0KFQoZyA9IGUuY2FsbCh0aGlzLCBwKSksIGwpLCBsICE9PSBvICYmIHN0KFQoZyksIG8pLCBnLnRpbWVTdGFtcCA9IGgsIGcub3JpZ2luYWxFdmVudCA9IGwsIGcudHlwZSA9IG4sIGcucG9pbnRlcklkID0gWWUobyksIGcucG9pbnRlclR5cGUgPSBRcihvKSwgZy50YXJnZXQgPSBjLCBnLmN1cnJlbnRUYXJnZXQgPSBudWxsLCBuID09PSBcInRhcFwiKSB7XG4gICAgICAgICAgdmFyIGQgPSBwLmdldFBvaW50ZXJJbmRleChvKTtcbiAgICAgICAgICBnLmR0ID0gZy50aW1lU3RhbXAgLSBwLnBvaW50ZXJzW2RdLmRvd25UaW1lO1xuICAgICAgICAgIHZhciBiID0gZy50aW1lU3RhbXAgLSBwLnRhcFRpbWU7XG4gICAgICAgICAgZy5kb3VibGUgPSAhIXAucHJldlRhcCAmJiBwLnByZXZUYXAudHlwZSAhPT0gXCJkb3VibGV0YXBcIiAmJiBwLnByZXZUYXAudGFyZ2V0ID09PSBnLnRhcmdldCAmJiBiIDwgNTAwO1xuICAgICAgICB9IGVsc2UgbiA9PT0gXCJkb3VibGV0YXBcIiAmJiAoZy5kdCA9IG8udGltZVN0YW1wIC0gcC50YXBUaW1lLCBnLmRvdWJsZSA9ICEwKTtcbiAgICAgICAgcmV0dXJuIGc7XG4gICAgICB9XG4gICAgICByZXR1cm4geShyLCBbeyBrZXk6IFwiX3N1YnRyYWN0T3JpZ2luXCIsIHZhbHVlOiBmdW5jdGlvbihuKSB7XG4gICAgICAgIHZhciBvID0gbi54LCBsID0gbi55O1xuICAgICAgICByZXR1cm4gdGhpcy5wYWdlWCAtPSBvLCB0aGlzLnBhZ2VZIC09IGwsIHRoaXMuY2xpZW50WCAtPSBvLCB0aGlzLmNsaWVudFkgLT0gbCwgdGhpcztcbiAgICAgIH0gfSwgeyBrZXk6IFwiX2FkZE9yaWdpblwiLCB2YWx1ZTogZnVuY3Rpb24obikge1xuICAgICAgICB2YXIgbyA9IG4ueCwgbCA9IG4ueTtcbiAgICAgICAgcmV0dXJuIHRoaXMucGFnZVggKz0gbywgdGhpcy5wYWdlWSArPSBsLCB0aGlzLmNsaWVudFggKz0gbywgdGhpcy5jbGllbnRZICs9IGwsIHRoaXM7XG4gICAgICB9IH0sIHsga2V5OiBcInByZXZlbnREZWZhdWx0XCIsIHZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy5vcmlnaW5hbEV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICB9IH1dKSwgcjtcbiAgICB9KGN0KSwgSmUgPSB7IGlkOiBcInBvaW50ZXItZXZlbnRzL2Jhc2VcIiwgYmVmb3JlOiBbXCJpbmVydGlhXCIsIFwibW9kaWZpZXJzXCIsIFwiYXV0by1zdGFydFwiLCBcImFjdGlvbnNcIl0sIGluc3RhbGw6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHQucG9pbnRlckV2ZW50cyA9IEplLCB0LmRlZmF1bHRzLmFjdGlvbnMucG9pbnRlckV2ZW50cyA9IEplLmRlZmF1bHRzLCBXKHQuYWN0aW9ucy5waGFzZWxlc3NUeXBlcywgSmUudHlwZXMpO1xuICAgIH0sIGxpc3RlbmVyczogeyBcImludGVyYWN0aW9uczpuZXdcIjogZnVuY3Rpb24odCkge1xuICAgICAgdmFyIGUgPSB0LmludGVyYWN0aW9uO1xuICAgICAgZS5wcmV2VGFwID0gbnVsbCwgZS50YXBUaW1lID0gMDtcbiAgICB9LCBcImludGVyYWN0aW9uczp1cGRhdGUtcG9pbnRlclwiOiBmdW5jdGlvbih0KSB7XG4gICAgICB2YXIgZSA9IHQuZG93biwgciA9IHQucG9pbnRlckluZm87XG4gICAgICAhZSAmJiByLmhvbGQgfHwgKHIuaG9sZCA9IHsgZHVyYXRpb246IDEgLyAwLCB0aW1lb3V0OiBudWxsIH0pO1xuICAgIH0sIFwiaW50ZXJhY3Rpb25zOm1vdmVcIjogZnVuY3Rpb24odCwgZSkge1xuICAgICAgdmFyIHIgPSB0LmludGVyYWN0aW9uLCBuID0gdC5wb2ludGVyLCBvID0gdC5ldmVudCwgbCA9IHQuZXZlbnRUYXJnZXQ7XG4gICAgICB0LmR1cGxpY2F0ZSB8fCByLnBvaW50ZXJJc0Rvd24gJiYgIXIucG9pbnRlcldhc01vdmVkIHx8IChyLnBvaW50ZXJJc0Rvd24gJiYgaHIodCksIHdlKHsgaW50ZXJhY3Rpb246IHIsIHBvaW50ZXI6IG4sIGV2ZW50OiBvLCBldmVudFRhcmdldDogbCwgdHlwZTogXCJtb3ZlXCIgfSwgZSkpO1xuICAgIH0sIFwiaW50ZXJhY3Rpb25zOmRvd25cIjogZnVuY3Rpb24odCwgZSkge1xuICAgICAgKGZ1bmN0aW9uKHIsIG4pIHtcbiAgICAgICAgZm9yICh2YXIgbyA9IHIuaW50ZXJhY3Rpb24sIGwgPSByLnBvaW50ZXIsIGMgPSByLmV2ZW50LCBwID0gci5ldmVudFRhcmdldCwgaCA9IHIucG9pbnRlckluZGV4LCBnID0gby5wb2ludGVyc1toXS5ob2xkLCBkID0gWXIocCksIGIgPSB7IGludGVyYWN0aW9uOiBvLCBwb2ludGVyOiBsLCBldmVudDogYywgZXZlbnRUYXJnZXQ6IHAsIHR5cGU6IFwiaG9sZFwiLCB0YXJnZXRzOiBbXSwgcGF0aDogZCwgbm9kZTogbnVsbCB9LCB4ID0gMDsgeCA8IGQubGVuZ3RoOyB4KyspIHtcbiAgICAgICAgICB2YXIgSSA9IGRbeF07XG4gICAgICAgICAgYi5ub2RlID0gSSwgbi5maXJlKFwicG9pbnRlckV2ZW50czpjb2xsZWN0LXRhcmdldHNcIiwgYik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGIudGFyZ2V0cy5sZW5ndGgpIHtcbiAgICAgICAgICBmb3IgKHZhciBFID0gMSAvIDAsIE0gPSAwLCAkID0gYi50YXJnZXRzOyBNIDwgJC5sZW5ndGg7IE0rKykge1xuICAgICAgICAgICAgdmFyIHogPSAkW01dLmV2ZW50YWJsZS5vcHRpb25zLmhvbGREdXJhdGlvbjtcbiAgICAgICAgICAgIHogPCBFICYmIChFID0geik7XG4gICAgICAgICAgfVxuICAgICAgICAgIGcuZHVyYXRpb24gPSBFLCBnLnRpbWVvdXQgPSBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgd2UoeyBpbnRlcmFjdGlvbjogbywgZXZlbnRUYXJnZXQ6IHAsIHBvaW50ZXI6IGwsIGV2ZW50OiBjLCB0eXBlOiBcImhvbGRcIiB9LCBuKTtcbiAgICAgICAgICB9LCBFKTtcbiAgICAgICAgfVxuICAgICAgfSkodCwgZSksIHdlKHQsIGUpO1xuICAgIH0sIFwiaW50ZXJhY3Rpb25zOnVwXCI6IGZ1bmN0aW9uKHQsIGUpIHtcbiAgICAgIGhyKHQpLCB3ZSh0LCBlKSwgZnVuY3Rpb24ociwgbikge1xuICAgICAgICB2YXIgbyA9IHIuaW50ZXJhY3Rpb24sIGwgPSByLnBvaW50ZXIsIGMgPSByLmV2ZW50LCBwID0gci5ldmVudFRhcmdldDtcbiAgICAgICAgby5wb2ludGVyV2FzTW92ZWQgfHwgd2UoeyBpbnRlcmFjdGlvbjogbywgZXZlbnRUYXJnZXQ6IHAsIHBvaW50ZXI6IGwsIGV2ZW50OiBjLCB0eXBlOiBcInRhcFwiIH0sIG4pO1xuICAgICAgfSh0LCBlKTtcbiAgICB9LCBcImludGVyYWN0aW9uczpjYW5jZWxcIjogZnVuY3Rpb24odCwgZSkge1xuICAgICAgaHIodCksIHdlKHQsIGUpO1xuICAgIH0gfSwgUG9pbnRlckV2ZW50OiBBbiwgZmlyZTogd2UsIGNvbGxlY3RFdmVudFRhcmdldHM6IExuLCBkZWZhdWx0czogeyBob2xkRHVyYXRpb246IDYwMCwgaWdub3JlRnJvbTogbnVsbCwgYWxsb3dGcm9tOiBudWxsLCBvcmlnaW46IHsgeDogMCwgeTogMCB9IH0sIHR5cGVzOiB7IGRvd246ICEwLCBtb3ZlOiAhMCwgdXA6ICEwLCBjYW5jZWw6ICEwLCB0YXA6ICEwLCBkb3VibGV0YXA6ICEwLCBob2xkOiAhMCB9IH07XG4gICAgZnVuY3Rpb24gd2UodCwgZSkge1xuICAgICAgdmFyIHIgPSB0LmludGVyYWN0aW9uLCBuID0gdC5wb2ludGVyLCBvID0gdC5ldmVudCwgbCA9IHQuZXZlbnRUYXJnZXQsIGMgPSB0LnR5cGUsIHAgPSB0LnRhcmdldHMsIGggPSBwID09PSB2b2lkIDAgPyBMbih0LCBlKSA6IHAsIGcgPSBuZXcgQW4oYywgbiwgbywgbCwgciwgZS5ub3coKSk7XG4gICAgICBlLmZpcmUoXCJwb2ludGVyRXZlbnRzOm5ld1wiLCB7IHBvaW50ZXJFdmVudDogZyB9KTtcbiAgICAgIGZvciAodmFyIGQgPSB7IGludGVyYWN0aW9uOiByLCBwb2ludGVyOiBuLCBldmVudDogbywgZXZlbnRUYXJnZXQ6IGwsIHRhcmdldHM6IGgsIHR5cGU6IGMsIHBvaW50ZXJFdmVudDogZyB9LCBiID0gMDsgYiA8IGgubGVuZ3RoOyBiKyspIHtcbiAgICAgICAgdmFyIHggPSBoW2JdO1xuICAgICAgICBmb3IgKHZhciBJIGluIHgucHJvcHMgfHwge30pIGdbSV0gPSB4LnByb3BzW0ldO1xuICAgICAgICB2YXIgRSA9IE5lKHguZXZlbnRhYmxlLCB4Lm5vZGUpO1xuICAgICAgICBpZiAoZy5fc3VidHJhY3RPcmlnaW4oRSksIGcuZXZlbnRhYmxlID0geC5ldmVudGFibGUsIGcuY3VycmVudFRhcmdldCA9IHgubm9kZSwgeC5ldmVudGFibGUuZmlyZShnKSwgZy5fYWRkT3JpZ2luKEUpLCBnLmltbWVkaWF0ZVByb3BhZ2F0aW9uU3RvcHBlZCB8fCBnLnByb3BhZ2F0aW9uU3RvcHBlZCAmJiBiICsgMSA8IGgubGVuZ3RoICYmIGhbYiArIDFdLm5vZGUgIT09IGcuY3VycmVudFRhcmdldCkgYnJlYWs7XG4gICAgICB9XG4gICAgICBpZiAoZS5maXJlKFwicG9pbnRlckV2ZW50czpmaXJlZFwiLCBkKSwgYyA9PT0gXCJ0YXBcIikge1xuICAgICAgICB2YXIgTSA9IGcuZG91YmxlID8gd2UoeyBpbnRlcmFjdGlvbjogciwgcG9pbnRlcjogbiwgZXZlbnQ6IG8sIGV2ZW50VGFyZ2V0OiBsLCB0eXBlOiBcImRvdWJsZXRhcFwiIH0sIGUpIDogZztcbiAgICAgICAgci5wcmV2VGFwID0gTSwgci50YXBUaW1lID0gTS50aW1lU3RhbXA7XG4gICAgICB9XG4gICAgICByZXR1cm4gZztcbiAgICB9XG4gICAgZnVuY3Rpb24gTG4odCwgZSkge1xuICAgICAgdmFyIHIgPSB0LmludGVyYWN0aW9uLCBuID0gdC5wb2ludGVyLCBvID0gdC5ldmVudCwgbCA9IHQuZXZlbnRUYXJnZXQsIGMgPSB0LnR5cGUsIHAgPSByLmdldFBvaW50ZXJJbmRleChuKSwgaCA9IHIucG9pbnRlcnNbcF07XG4gICAgICBpZiAoYyA9PT0gXCJ0YXBcIiAmJiAoci5wb2ludGVyV2FzTW92ZWQgfHwgIWggfHwgaC5kb3duVGFyZ2V0ICE9PSBsKSkgcmV0dXJuIFtdO1xuICAgICAgZm9yICh2YXIgZyA9IFlyKGwpLCBkID0geyBpbnRlcmFjdGlvbjogciwgcG9pbnRlcjogbiwgZXZlbnQ6IG8sIGV2ZW50VGFyZ2V0OiBsLCB0eXBlOiBjLCBwYXRoOiBnLCB0YXJnZXRzOiBbXSwgbm9kZTogbnVsbCB9LCBiID0gMDsgYiA8IGcubGVuZ3RoOyBiKyspIHtcbiAgICAgICAgdmFyIHggPSBnW2JdO1xuICAgICAgICBkLm5vZGUgPSB4LCBlLmZpcmUoXCJwb2ludGVyRXZlbnRzOmNvbGxlY3QtdGFyZ2V0c1wiLCBkKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBjID09PSBcImhvbGRcIiAmJiAoZC50YXJnZXRzID0gZC50YXJnZXRzLmZpbHRlcihmdW5jdGlvbihJKSB7XG4gICAgICAgIHZhciBFLCBNO1xuICAgICAgICByZXR1cm4gSS5ldmVudGFibGUub3B0aW9ucy5ob2xkRHVyYXRpb24gPT09ICgoRSA9IHIucG9pbnRlcnNbcF0pID09IG51bGwgfHwgKE0gPSBFLmhvbGQpID09IG51bGwgPyB2b2lkIDAgOiBNLmR1cmF0aW9uKTtcbiAgICAgIH0pKSwgZC50YXJnZXRzO1xuICAgIH1cbiAgICBmdW5jdGlvbiBocih0KSB7XG4gICAgICB2YXIgZSA9IHQuaW50ZXJhY3Rpb24sIHIgPSB0LnBvaW50ZXJJbmRleCwgbiA9IGUucG9pbnRlcnNbcl0uaG9sZDtcbiAgICAgIG4gJiYgbi50aW1lb3V0ICYmIChjbGVhclRpbWVvdXQobi50aW1lb3V0KSwgbi50aW1lb3V0ID0gbnVsbCk7XG4gICAgfVxuICAgIHZhciB1cyA9IE9iamVjdC5mcmVlemUoeyBfX3Byb3RvX186IG51bGwsIGRlZmF1bHQ6IEplIH0pO1xuICAgIGZ1bmN0aW9uIHBzKHQpIHtcbiAgICAgIHZhciBlID0gdC5pbnRlcmFjdGlvbjtcbiAgICAgIGUuaG9sZEludGVydmFsSGFuZGxlICYmIChjbGVhckludGVydmFsKGUuaG9sZEludGVydmFsSGFuZGxlKSwgZS5ob2xkSW50ZXJ2YWxIYW5kbGUgPSBudWxsKTtcbiAgICB9XG4gICAgdmFyIGhzID0geyBpZDogXCJwb2ludGVyLWV2ZW50cy9ob2xkUmVwZWF0XCIsIGluc3RhbGw6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHQudXNlUGx1Z2luKEplKTtcbiAgICAgIHZhciBlID0gdC5wb2ludGVyRXZlbnRzO1xuICAgICAgZS5kZWZhdWx0cy5ob2xkUmVwZWF0SW50ZXJ2YWwgPSAwLCBlLnR5cGVzLmhvbGRyZXBlYXQgPSB0LmFjdGlvbnMucGhhc2VsZXNzVHlwZXMuaG9sZHJlcGVhdCA9ICEwO1xuICAgIH0sIGxpc3RlbmVyczogW1wibW92ZVwiLCBcInVwXCIsIFwiY2FuY2VsXCIsIFwiZW5kYWxsXCJdLnJlZHVjZShmdW5jdGlvbih0LCBlKSB7XG4gICAgICByZXR1cm4gdFtcInBvaW50ZXJFdmVudHM6XCIuY29uY2F0KGUpXSA9IHBzLCB0O1xuICAgIH0sIHsgXCJwb2ludGVyRXZlbnRzOm5ld1wiOiBmdW5jdGlvbih0KSB7XG4gICAgICB2YXIgZSA9IHQucG9pbnRlckV2ZW50O1xuICAgICAgZS50eXBlID09PSBcImhvbGRcIiAmJiAoZS5jb3VudCA9IChlLmNvdW50IHx8IDApICsgMSk7XG4gICAgfSwgXCJwb2ludGVyRXZlbnRzOmZpcmVkXCI6IGZ1bmN0aW9uKHQsIGUpIHtcbiAgICAgIHZhciByID0gdC5pbnRlcmFjdGlvbiwgbiA9IHQucG9pbnRlckV2ZW50LCBvID0gdC5ldmVudFRhcmdldCwgbCA9IHQudGFyZ2V0cztcbiAgICAgIGlmIChuLnR5cGUgPT09IFwiaG9sZFwiICYmIGwubGVuZ3RoKSB7XG4gICAgICAgIHZhciBjID0gbFswXS5ldmVudGFibGUub3B0aW9ucy5ob2xkUmVwZWF0SW50ZXJ2YWw7XG4gICAgICAgIGMgPD0gMCB8fCAoci5ob2xkSW50ZXJ2YWxIYW5kbGUgPSBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xuICAgICAgICAgIGUucG9pbnRlckV2ZW50cy5maXJlKHsgaW50ZXJhY3Rpb246IHIsIGV2ZW50VGFyZ2V0OiBvLCB0eXBlOiBcImhvbGRcIiwgcG9pbnRlcjogbiwgZXZlbnQ6IG4gfSwgZSk7XG4gICAgICAgIH0sIGMpKTtcbiAgICAgIH1cbiAgICB9IH0pIH0sIGRzID0gaHMsIGZzID0geyBpZDogXCJwb2ludGVyLWV2ZW50cy9pbnRlcmFjdGFibGVUYXJnZXRzXCIsIGluc3RhbGw6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHZhciBlID0gdC5JbnRlcmFjdGFibGU7XG4gICAgICBlLnByb3RvdHlwZS5wb2ludGVyRXZlbnRzID0gZnVuY3Rpb24obikge1xuICAgICAgICByZXR1cm4gVyh0aGlzLmV2ZW50cy5vcHRpb25zLCBuKSwgdGhpcztcbiAgICAgIH07XG4gICAgICB2YXIgciA9IGUucHJvdG90eXBlLl9iYWNrQ29tcGF0T3B0aW9uO1xuICAgICAgZS5wcm90b3R5cGUuX2JhY2tDb21wYXRPcHRpb24gPSBmdW5jdGlvbihuLCBvKSB7XG4gICAgICAgIHZhciBsID0gci5jYWxsKHRoaXMsIG4sIG8pO1xuICAgICAgICByZXR1cm4gbCA9PT0gdGhpcyAmJiAodGhpcy5ldmVudHMub3B0aW9uc1tuXSA9IG8pLCBsO1xuICAgICAgfTtcbiAgICB9LCBsaXN0ZW5lcnM6IHsgXCJwb2ludGVyRXZlbnRzOmNvbGxlY3QtdGFyZ2V0c1wiOiBmdW5jdGlvbih0LCBlKSB7XG4gICAgICB2YXIgciA9IHQudGFyZ2V0cywgbiA9IHQubm9kZSwgbyA9IHQudHlwZSwgbCA9IHQuZXZlbnRUYXJnZXQ7XG4gICAgICBlLmludGVyYWN0YWJsZXMuZm9yRWFjaE1hdGNoKG4sIGZ1bmN0aW9uKGMpIHtcbiAgICAgICAgdmFyIHAgPSBjLmV2ZW50cywgaCA9IHAub3B0aW9ucztcbiAgICAgICAgcC50eXBlc1tvXSAmJiBwLnR5cGVzW29dLmxlbmd0aCAmJiBjLnRlc3RJZ25vcmVBbGxvdyhoLCBuLCBsKSAmJiByLnB1c2goeyBub2RlOiBuLCBldmVudGFibGU6IHAsIHByb3BzOiB7IGludGVyYWN0YWJsZTogYyB9IH0pO1xuICAgICAgfSk7XG4gICAgfSwgXCJpbnRlcmFjdGFibGU6bmV3XCI6IGZ1bmN0aW9uKHQpIHtcbiAgICAgIHZhciBlID0gdC5pbnRlcmFjdGFibGU7XG4gICAgICBlLmV2ZW50cy5nZXRSZWN0ID0gZnVuY3Rpb24ocikge1xuICAgICAgICByZXR1cm4gZS5nZXRSZWN0KHIpO1xuICAgICAgfTtcbiAgICB9LCBcImludGVyYWN0YWJsZTpzZXRcIjogZnVuY3Rpb24odCwgZSkge1xuICAgICAgdmFyIHIgPSB0LmludGVyYWN0YWJsZSwgbiA9IHQub3B0aW9ucztcbiAgICAgIFcoci5ldmVudHMub3B0aW9ucywgZS5wb2ludGVyRXZlbnRzLmRlZmF1bHRzKSwgVyhyLmV2ZW50cy5vcHRpb25zLCBuLnBvaW50ZXJFdmVudHMgfHwge30pO1xuICAgIH0gfSB9LCB2cyA9IGZzLCBncyA9IHsgaWQ6IFwicG9pbnRlci1ldmVudHNcIiwgaW5zdGFsbDogZnVuY3Rpb24odCkge1xuICAgICAgdC51c2VQbHVnaW4odXMpLCB0LnVzZVBsdWdpbihkcyksIHQudXNlUGx1Z2luKHZzKTtcbiAgICB9IH0sIG1zID0gZ3MsIGJzID0geyBpZDogXCJyZWZsb3dcIiwgaW5zdGFsbDogZnVuY3Rpb24odCkge1xuICAgICAgdmFyIGUgPSB0LkludGVyYWN0YWJsZTtcbiAgICAgIHQuYWN0aW9ucy5waGFzZXMucmVmbG93ID0gITAsIGUucHJvdG90eXBlLnJlZmxvdyA9IGZ1bmN0aW9uKHIpIHtcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uKG4sIG8sIGwpIHtcbiAgICAgICAgICBmb3IgKHZhciBjID0gbi5nZXRBbGxFbGVtZW50cygpLCBwID0gbC53aW5kb3cuUHJvbWlzZSwgaCA9IHAgPyBbXSA6IG51bGwsIGcgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHZhciBiID0gY1tkXSwgeCA9IG4uZ2V0UmVjdChiKTtcbiAgICAgICAgICAgIGlmICgheCkgcmV0dXJuIDE7XG4gICAgICAgICAgICB2YXIgSSwgRSA9IFhlKGwuaW50ZXJhY3Rpb25zLmxpc3QsIGZ1bmN0aW9uKHopIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHouaW50ZXJhY3RpbmcoKSAmJiB6LmludGVyYWN0YWJsZSA9PT0gbiAmJiB6LmVsZW1lbnQgPT09IGIgJiYgei5wcmVwYXJlZC5uYW1lID09PSBvLm5hbWU7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmIChFKSBFLm1vdmUoKSwgaCAmJiAoSSA9IEUuX3JlZmxvd1Byb21pc2UgfHwgbmV3IHAoZnVuY3Rpb24oeikge1xuICAgICAgICAgICAgICBFLl9yZWZsb3dSZXNvbHZlID0gejtcbiAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICB2YXIgTSA9IEd0KHgpLCAkID0gLyogQF9fUFVSRV9fICovIGZ1bmN0aW9uKHopIHtcbiAgICAgICAgICAgICAgICByZXR1cm4geyBjb29yZHM6IHosIGdldCBwYWdlKCkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29vcmRzLnBhZ2U7XG4gICAgICAgICAgICAgICAgfSwgZ2V0IGNsaWVudCgpIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmNvb3Jkcy5jbGllbnQ7XG4gICAgICAgICAgICAgICAgfSwgZ2V0IHRpbWVTdGFtcCgpIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmNvb3Jkcy50aW1lU3RhbXA7XG4gICAgICAgICAgICAgICAgfSwgZ2V0IHBhZ2VYKCkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29vcmRzLnBhZ2UueDtcbiAgICAgICAgICAgICAgICB9LCBnZXQgcGFnZVkoKSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5jb29yZHMucGFnZS55O1xuICAgICAgICAgICAgICAgIH0sIGdldCBjbGllbnRYKCkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29vcmRzLmNsaWVudC54O1xuICAgICAgICAgICAgICAgIH0sIGdldCBjbGllbnRZKCkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29vcmRzLmNsaWVudC55O1xuICAgICAgICAgICAgICAgIH0sIGdldCBwb2ludGVySWQoKSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5jb29yZHMucG9pbnRlcklkO1xuICAgICAgICAgICAgICAgIH0sIGdldCB0YXJnZXQoKSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5jb29yZHMudGFyZ2V0O1xuICAgICAgICAgICAgICAgIH0sIGdldCB0eXBlKCkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29vcmRzLnR5cGU7XG4gICAgICAgICAgICAgICAgfSwgZ2V0IHBvaW50ZXJUeXBlKCkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29vcmRzLnBvaW50ZXJUeXBlO1xuICAgICAgICAgICAgICAgIH0sIGdldCBidXR0b25zKCkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29vcmRzLmJ1dHRvbnM7XG4gICAgICAgICAgICAgICAgfSwgcHJldmVudERlZmF1bHQ6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgIH0gfTtcbiAgICAgICAgICAgICAgfSh7IHBhZ2U6IHsgeDogTS54LCB5OiBNLnkgfSwgY2xpZW50OiB7IHg6IE0ueCwgeTogTS55IH0sIHRpbWVTdGFtcDogbC5ub3coKSB9KTtcbiAgICAgICAgICAgICAgSSA9IGZ1bmN0aW9uKHosIEEsIE4sIEssIEYpIHtcbiAgICAgICAgICAgICAgICB2YXIgRyA9IHouaW50ZXJhY3Rpb25zLm5ldyh7IHBvaW50ZXJUeXBlOiBcInJlZmxvd1wiIH0pLCB0ZSA9IHsgaW50ZXJhY3Rpb246IEcsIGV2ZW50OiBGLCBwb2ludGVyOiBGLCBldmVudFRhcmdldDogTiwgcGhhc2U6IFwicmVmbG93XCIgfTtcbiAgICAgICAgICAgICAgICBHLmludGVyYWN0YWJsZSA9IEEsIEcuZWxlbWVudCA9IE4sIEcucHJldkV2ZW50ID0gRiwgRy51cGRhdGVQb2ludGVyKEYsIEYsIE4sICEwKSwgVnIoRy5jb29yZHMuZGVsdGEpLCBlcihHLnByZXBhcmVkLCBLKSwgRy5fZG9QaGFzZSh0ZSk7XG4gICAgICAgICAgICAgICAgdmFyIEogPSB6LndpbmRvdywgcmUgPSBKLlByb21pc2UsIHNlID0gcmUgPyBuZXcgcmUoZnVuY3Rpb24oZmUpIHtcbiAgICAgICAgICAgICAgICAgIEcuX3JlZmxvd1Jlc29sdmUgPSBmZTtcbiAgICAgICAgICAgICAgICB9KSA6IHZvaWQgMDtcbiAgICAgICAgICAgICAgICByZXR1cm4gRy5fcmVmbG93UHJvbWlzZSA9IHNlLCBHLnN0YXJ0KEssIEEsIE4pLCBHLl9pbnRlcmFjdGluZyA/IChHLm1vdmUodGUpLCBHLmVuZChGKSkgOiAoRy5zdG9wKCksIEcuX3JlZmxvd1Jlc29sdmUoKSksIEcucmVtb3ZlUG9pbnRlcihGLCBGKSwgc2U7XG4gICAgICAgICAgICAgIH0obCwgbiwgYiwgbywgJCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBoICYmIGgucHVzaChJKTtcbiAgICAgICAgICB9LCBkID0gMDsgZCA8IGMubGVuZ3RoICYmICFnKCk7IGQrKykgO1xuICAgICAgICAgIHJldHVybiBoICYmIHAuYWxsKGgpLnRoZW4oZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICByZXR1cm4gbjtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSh0aGlzLCByLCB0KTtcbiAgICAgIH07XG4gICAgfSwgbGlzdGVuZXJzOiB7IFwiaW50ZXJhY3Rpb25zOnN0b3BcIjogZnVuY3Rpb24odCwgZSkge1xuICAgICAgdmFyIHIgPSB0LmludGVyYWN0aW9uO1xuICAgICAgci5wb2ludGVyVHlwZSA9PT0gXCJyZWZsb3dcIiAmJiAoci5fcmVmbG93UmVzb2x2ZSAmJiByLl9yZWZsb3dSZXNvbHZlKCksIGZ1bmN0aW9uKG4sIG8pIHtcbiAgICAgICAgbi5zcGxpY2Uobi5pbmRleE9mKG8pLCAxKTtcbiAgICAgIH0oZS5pbnRlcmFjdGlvbnMubGlzdCwgcikpO1xuICAgIH0gfSB9LCB5cyA9IGJzO1xuICAgIGlmIChlZS51c2UobW4pLCBlZS51c2UoU24pLCBlZS51c2UobXMpLCBlZS51c2Uoam8pLCBlZS51c2UoY3MpLCBlZS51c2UoT28pLCBlZS51c2UoaG8pLCBlZS51c2Uodm8pLCBlZS51c2UoeXMpLCBlZS5kZWZhdWx0ID0gZWUsIHYoYSkgPT09IFwib2JqZWN0XCIgJiYgYSkgdHJ5IHtcbiAgICAgIGEuZXhwb3J0cyA9IGVlO1xuICAgIH0gY2F0Y2gge1xuICAgIH1cbiAgICByZXR1cm4gZWUuZGVmYXVsdCA9IGVlLCBlZTtcbiAgfSk7XG59KShFdCwgRXQuZXhwb3J0cyk7XG52YXIgd3MgPSBFdC5leHBvcnRzO1xuY29uc3QgZHIgPSAvKiBAX19QVVJFX18gKi8gcnQod3MpO1xudmFyIFNpID0geyBleHBvcnRzOiB7fSB9O1xuKGZ1bmN0aW9uKGEsIGkpIHtcbiAgKGZ1bmN0aW9uKHMsIHUpIHtcbiAgICBhLmV4cG9ydHMgPSB1KCk7XG4gIH0pKEllLCBmdW5jdGlvbigpIHtcbiAgICB2YXIgcyA9IFwibWludXRlXCIsIHUgPSAvWystXVxcZFxcZCg/Ojo/XFxkXFxkKT8vZywgdiA9IC8oWystXXxcXGRcXGQpL2c7XG4gICAgcmV0dXJuIGZ1bmN0aW9uKGYsIG0sIHkpIHtcbiAgICAgIHZhciBTID0gbS5wcm90b3R5cGU7XG4gICAgICB5LnV0YyA9IGZ1bmN0aW9uKE8pIHtcbiAgICAgICAgdmFyIGsgPSB7IGRhdGU6IE8sIHV0YzogITAsIGFyZ3M6IGFyZ3VtZW50cyB9O1xuICAgICAgICByZXR1cm4gbmV3IG0oayk7XG4gICAgICB9LCBTLnV0YyA9IGZ1bmN0aW9uKE8pIHtcbiAgICAgICAgdmFyIGsgPSB5KHRoaXMudG9EYXRlKCksIHsgbG9jYWxlOiB0aGlzLiRMLCB1dGM6ICEwIH0pO1xuICAgICAgICByZXR1cm4gTyA/IGsuYWRkKHRoaXMudXRjT2Zmc2V0KCksIHMpIDogaztcbiAgICAgIH0sIFMubG9jYWwgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIHkodGhpcy50b0RhdGUoKSwgeyBsb2NhbGU6IHRoaXMuJEwsIHV0YzogITEgfSk7XG4gICAgICB9O1xuICAgICAgdmFyIEMgPSBTLnBhcnNlO1xuICAgICAgUy5wYXJzZSA9IGZ1bmN0aW9uKE8pIHtcbiAgICAgICAgTy51dGMgJiYgKHRoaXMuJHUgPSAhMCksIHRoaXMuJHV0aWxzKCkudShPLiRvZmZzZXQpIHx8ICh0aGlzLiRvZmZzZXQgPSBPLiRvZmZzZXQpLCBDLmNhbGwodGhpcywgTyk7XG4gICAgICB9O1xuICAgICAgdmFyIEQgPSBTLmluaXQ7XG4gICAgICBTLmluaXQgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgaWYgKHRoaXMuJHUpIHtcbiAgICAgICAgICB2YXIgTyA9IHRoaXMuJGQ7XG4gICAgICAgICAgdGhpcy4keSA9IE8uZ2V0VVRDRnVsbFllYXIoKSwgdGhpcy4kTSA9IE8uZ2V0VVRDTW9udGgoKSwgdGhpcy4kRCA9IE8uZ2V0VVRDRGF0ZSgpLCB0aGlzLiRXID0gTy5nZXRVVENEYXkoKSwgdGhpcy4kSCA9IE8uZ2V0VVRDSG91cnMoKSwgdGhpcy4kbSA9IE8uZ2V0VVRDTWludXRlcygpLCB0aGlzLiRzID0gTy5nZXRVVENTZWNvbmRzKCksIHRoaXMuJG1zID0gTy5nZXRVVENNaWxsaXNlY29uZHMoKTtcbiAgICAgICAgfSBlbHNlIEQuY2FsbCh0aGlzKTtcbiAgICAgIH07XG4gICAgICB2YXIgUiA9IFMudXRjT2Zmc2V0O1xuICAgICAgUy51dGNPZmZzZXQgPSBmdW5jdGlvbihPLCBrKSB7XG4gICAgICAgIHZhciBMID0gdGhpcy4kdXRpbHMoKS51O1xuICAgICAgICBpZiAoTChPKSkgcmV0dXJuIHRoaXMuJHUgPyAwIDogTCh0aGlzLiRvZmZzZXQpID8gUi5jYWxsKHRoaXMpIDogdGhpcy4kb2Zmc2V0O1xuICAgICAgICBpZiAodHlwZW9mIE8gPT0gXCJzdHJpbmdcIiAmJiAoTyA9IGZ1bmN0aW9uKFYpIHtcbiAgICAgICAgICBWID09PSB2b2lkIDAgJiYgKFYgPSBcIlwiKTtcbiAgICAgICAgICB2YXIgbGUgPSBWLm1hdGNoKHUpO1xuICAgICAgICAgIGlmICghbGUpIHJldHVybiBudWxsO1xuICAgICAgICAgIHZhciB3ID0gKFwiXCIgKyBsZVswXSkubWF0Y2godikgfHwgW1wiLVwiLCAwLCAwXSwgY2UgPSB3WzBdLCBNZSA9IDYwICogK3dbMV0gKyArd1syXTtcbiAgICAgICAgICByZXR1cm4gTWUgPT09IDAgPyAwIDogY2UgPT09IFwiK1wiID8gTWUgOiAtTWU7XG4gICAgICAgIH0oTyksIE8gPT09IG51bGwpKSByZXR1cm4gdGhpcztcbiAgICAgICAgdmFyIEggPSBNYXRoLmFicyhPKSA8PSAxNiA/IDYwICogTyA6IE87XG4gICAgICAgIGlmIChIID09PSAwKSByZXR1cm4gdGhpcy51dGMoayk7XG4gICAgICAgIHZhciBYID0gdGhpcy5jbG9uZSgpO1xuICAgICAgICBpZiAoaykgcmV0dXJuIFguJG9mZnNldCA9IEgsIFguJHUgPSAhMSwgWDtcbiAgICAgICAgdmFyIEIgPSB0aGlzLiR1ID8gdGhpcy50b0RhdGUoKS5nZXRUaW1lem9uZU9mZnNldCgpIDogLTEgKiB0aGlzLnV0Y09mZnNldCgpO1xuICAgICAgICByZXR1cm4gKFggPSB0aGlzLmxvY2FsKCkuYWRkKEggKyBCLCBzKSkuJG9mZnNldCA9IEgsIFguJHguJGxvY2FsT2Zmc2V0ID0gQiwgWDtcbiAgICAgIH07XG4gICAgICB2YXIgVCA9IFMuZm9ybWF0O1xuICAgICAgUy5mb3JtYXQgPSBmdW5jdGlvbihPKSB7XG4gICAgICAgIHZhciBrID0gTyB8fCAodGhpcy4kdSA/IFwiWVlZWS1NTS1ERFRISDptbTpzc1taXVwiIDogXCJcIik7XG4gICAgICAgIHJldHVybiBULmNhbGwodGhpcywgayk7XG4gICAgICB9LCBTLnZhbHVlT2YgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIE8gPSB0aGlzLiR1dGlscygpLnUodGhpcy4kb2Zmc2V0KSA/IDAgOiB0aGlzLiRvZmZzZXQgKyAodGhpcy4keC4kbG9jYWxPZmZzZXQgfHwgdGhpcy4kZC5nZXRUaW1lem9uZU9mZnNldCgpKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuJGQudmFsdWVPZigpIC0gNmU0ICogTztcbiAgICAgIH0sIFMuaXNVVEMgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuICEhdGhpcy4kdTtcbiAgICAgIH0sIFMudG9JU09TdHJpbmcgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMudG9EYXRlKCkudG9JU09TdHJpbmcoKTtcbiAgICAgIH0sIFMudG9TdHJpbmcgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMudG9EYXRlKCkudG9VVENTdHJpbmcoKTtcbiAgICAgIH07XG4gICAgICB2YXIgUCA9IFMudG9EYXRlO1xuICAgICAgUy50b0RhdGUgPSBmdW5jdGlvbihPKSB7XG4gICAgICAgIHJldHVybiBPID09PSBcInNcIiAmJiB0aGlzLiRvZmZzZXQgPyB5KHRoaXMuZm9ybWF0KFwiWVlZWS1NTS1ERCBISDptbTpzczpTU1NcIikpLnRvRGF0ZSgpIDogUC5jYWxsKHRoaXMpO1xuICAgICAgfTtcbiAgICAgIHZhciBfID0gUy5kaWZmO1xuICAgICAgUy5kaWZmID0gZnVuY3Rpb24oTywgaywgTCkge1xuICAgICAgICBpZiAoTyAmJiB0aGlzLiR1ID09PSBPLiR1KSByZXR1cm4gXy5jYWxsKHRoaXMsIE8sIGssIEwpO1xuICAgICAgICB2YXIgSCA9IHRoaXMubG9jYWwoKSwgWCA9IHkoTykubG9jYWwoKTtcbiAgICAgICAgcmV0dXJuIF8uY2FsbChILCBYLCBrLCBMKTtcbiAgICAgIH07XG4gICAgfTtcbiAgfSk7XG59KShTaSk7XG52YXIgeHMgPSBTaS5leHBvcnRzO1xuY29uc3QgU3MgPSAvKiBAX19QVVJFX18gKi8gcnQoeHMpO1xuZnVuY3Rpb24gT3MoKSB7XG4gIHRoaXMuX19kYXRhX18gPSBbXSwgdGhpcy5zaXplID0gMDtcbn1cbnZhciBDcyA9IE9zO1xuZnVuY3Rpb24gRXMoYSwgaSkge1xuICByZXR1cm4gYSA9PT0gaSB8fCBhICE9PSBhICYmIGkgIT09IGk7XG59XG52YXIgT2kgPSBFcywgX3MgPSBPaTtcbmZ1bmN0aW9uIFBzKGEsIGkpIHtcbiAgZm9yICh2YXIgcyA9IGEubGVuZ3RoOyBzLS07IClcbiAgICBpZiAoX3MoYVtzXVswXSwgaSkpXG4gICAgICByZXR1cm4gcztcbiAgcmV0dXJuIC0xO1xufVxudmFyIER0ID0gUHMsIElzID0gRHQsIE1zID0gQXJyYXkucHJvdG90eXBlLCBScyA9IE1zLnNwbGljZTtcbmZ1bmN0aW9uIERzKGEpIHtcbiAgdmFyIGkgPSB0aGlzLl9fZGF0YV9fLCBzID0gSXMoaSwgYSk7XG4gIGlmIChzIDwgMClcbiAgICByZXR1cm4gITE7XG4gIHZhciB1ID0gaS5sZW5ndGggLSAxO1xuICByZXR1cm4gcyA9PSB1ID8gaS5wb3AoKSA6IFJzLmNhbGwoaSwgcywgMSksIC0tdGhpcy5zaXplLCAhMDtcbn1cbnZhciBrcyA9IERzLCB6cyA9IER0O1xuZnVuY3Rpb24gJHMoYSkge1xuICB2YXIgaSA9IHRoaXMuX19kYXRhX18sIHMgPSB6cyhpLCBhKTtcbiAgcmV0dXJuIHMgPCAwID8gdm9pZCAwIDogaVtzXVsxXTtcbn1cbnZhciBqcyA9ICRzLCBBcyA9IER0O1xuZnVuY3Rpb24gTHMoYSkge1xuICByZXR1cm4gQXModGhpcy5fX2RhdGFfXywgYSkgPiAtMTtcbn1cbnZhciBIcyA9IExzLCBXcyA9IER0O1xuZnVuY3Rpb24gRnMoYSwgaSkge1xuICB2YXIgcyA9IHRoaXMuX19kYXRhX18sIHUgPSBXcyhzLCBhKTtcbiAgcmV0dXJuIHUgPCAwID8gKCsrdGhpcy5zaXplLCBzLnB1c2goW2EsIGldKSkgOiBzW3VdWzFdID0gaSwgdGhpcztcbn1cbnZhciBVcyA9IEZzLCBOcyA9IENzLCBHcyA9IGtzLCBZcyA9IGpzLCBLcyA9IEhzLCBYcyA9IFVzO1xuZnVuY3Rpb24gamUoYSkge1xuICB2YXIgaSA9IC0xLCBzID0gYSA9PSBudWxsID8gMCA6IGEubGVuZ3RoO1xuICBmb3IgKHRoaXMuY2xlYXIoKTsgKytpIDwgczsgKSB7XG4gICAgdmFyIHUgPSBhW2ldO1xuICAgIHRoaXMuc2V0KHVbMF0sIHVbMV0pO1xuICB9XG59XG5qZS5wcm90b3R5cGUuY2xlYXIgPSBOcztcbmplLnByb3RvdHlwZS5kZWxldGUgPSBHcztcbmplLnByb3RvdHlwZS5nZXQgPSBZcztcbmplLnByb3RvdHlwZS5oYXMgPSBLcztcbmplLnByb3RvdHlwZS5zZXQgPSBYcztcbnZhciBrdCA9IGplLCBCcyA9IGt0O1xuZnVuY3Rpb24gVnMoKSB7XG4gIHRoaXMuX19kYXRhX18gPSBuZXcgQnMoKSwgdGhpcy5zaXplID0gMDtcbn1cbnZhciBxcyA9IFZzO1xuZnVuY3Rpb24gWnMoYSkge1xuICB2YXIgaSA9IHRoaXMuX19kYXRhX18sIHMgPSBpLmRlbGV0ZShhKTtcbiAgcmV0dXJuIHRoaXMuc2l6ZSA9IGkuc2l6ZSwgcztcbn1cbnZhciBKcyA9IFpzO1xuZnVuY3Rpb24gUXMoYSkge1xuICByZXR1cm4gdGhpcy5fX2RhdGFfXy5nZXQoYSk7XG59XG52YXIgZWEgPSBRcztcbmZ1bmN0aW9uIHRhKGEpIHtcbiAgcmV0dXJuIHRoaXMuX19kYXRhX18uaGFzKGEpO1xufVxudmFyIHJhID0gdGEsIG5hID0gdHlwZW9mIEllID09IFwib2JqZWN0XCIgJiYgSWUgJiYgSWUuT2JqZWN0ID09PSBPYmplY3QgJiYgSWUsIENpID0gbmEsIGlhID0gQ2ksIG9hID0gdHlwZW9mIHNlbGYgPT0gXCJvYmplY3RcIiAmJiBzZWxmICYmIHNlbGYuT2JqZWN0ID09PSBPYmplY3QgJiYgc2VsZiwgc2EgPSBpYSB8fCBvYSB8fCBGdW5jdGlvbihcInJldHVybiB0aGlzXCIpKCksIGdlID0gc2EsIGFhID0gZ2UsIGxhID0gYWEuU3ltYm9sLCBfciA9IGxhLCBXbiA9IF9yLCBFaSA9IE9iamVjdC5wcm90b3R5cGUsIGNhID0gRWkuaGFzT3duUHJvcGVydHksIHVhID0gRWkudG9TdHJpbmcsIGV0ID0gV24gPyBXbi50b1N0cmluZ1RhZyA6IHZvaWQgMDtcbmZ1bmN0aW9uIHBhKGEpIHtcbiAgdmFyIGkgPSBjYS5jYWxsKGEsIGV0KSwgcyA9IGFbZXRdO1xuICB0cnkge1xuICAgIGFbZXRdID0gdm9pZCAwO1xuICAgIHZhciB1ID0gITA7XG4gIH0gY2F0Y2gge1xuICB9XG4gIHZhciB2ID0gdWEuY2FsbChhKTtcbiAgcmV0dXJuIHUgJiYgKGkgPyBhW2V0XSA9IHMgOiBkZWxldGUgYVtldF0pLCB2O1xufVxudmFyIGhhID0gcGEsIGRhID0gT2JqZWN0LnByb3RvdHlwZSwgZmEgPSBkYS50b1N0cmluZztcbmZ1bmN0aW9uIHZhKGEpIHtcbiAgcmV0dXJuIGZhLmNhbGwoYSk7XG59XG52YXIgZ2EgPSB2YSwgRm4gPSBfciwgbWEgPSBoYSwgYmEgPSBnYSwgeWEgPSBcIltvYmplY3QgTnVsbF1cIiwgVGEgPSBcIltvYmplY3QgVW5kZWZpbmVkXVwiLCBVbiA9IEZuID8gRm4udG9TdHJpbmdUYWcgOiB2b2lkIDA7XG5mdW5jdGlvbiB3YShhKSB7XG4gIHJldHVybiBhID09IG51bGwgPyBhID09PSB2b2lkIDAgPyBUYSA6IHlhIDogVW4gJiYgVW4gaW4gT2JqZWN0KGEpID8gbWEoYSkgOiBiYShhKTtcbn1cbnZhciB6dCA9IHdhO1xuZnVuY3Rpb24geGEoYSkge1xuICB2YXIgaSA9IHR5cGVvZiBhO1xuICByZXR1cm4gYSAhPSBudWxsICYmIChpID09IFwib2JqZWN0XCIgfHwgaSA9PSBcImZ1bmN0aW9uXCIpO1xufVxudmFyIF9pID0geGEsIFNhID0genQsIE9hID0gX2ksIENhID0gXCJbb2JqZWN0IEFzeW5jRnVuY3Rpb25dXCIsIEVhID0gXCJbb2JqZWN0IEZ1bmN0aW9uXVwiLCBfYSA9IFwiW29iamVjdCBHZW5lcmF0b3JGdW5jdGlvbl1cIiwgUGEgPSBcIltvYmplY3QgUHJveHldXCI7XG5mdW5jdGlvbiBJYShhKSB7XG4gIGlmICghT2EoYSkpXG4gICAgcmV0dXJuICExO1xuICB2YXIgaSA9IFNhKGEpO1xuICByZXR1cm4gaSA9PSBFYSB8fCBpID09IF9hIHx8IGkgPT0gQ2EgfHwgaSA9PSBQYTtcbn1cbnZhciBQaSA9IElhLCBNYSA9IGdlLCBSYSA9IE1hW1wiX19jb3JlLWpzX3NoYXJlZF9fXCJdLCBEYSA9IFJhLCBmciA9IERhLCBObiA9IGZ1bmN0aW9uKCkge1xuICB2YXIgYSA9IC9bXi5dKyQvLmV4ZWMoZnIgJiYgZnIua2V5cyAmJiBmci5rZXlzLklFX1BST1RPIHx8IFwiXCIpO1xuICByZXR1cm4gYSA/IFwiU3ltYm9sKHNyYylfMS5cIiArIGEgOiBcIlwiO1xufSgpO1xuZnVuY3Rpb24ga2EoYSkge1xuICByZXR1cm4gISFObiAmJiBObiBpbiBhO1xufVxudmFyIHphID0ga2EsICRhID0gRnVuY3Rpb24ucHJvdG90eXBlLCBqYSA9ICRhLnRvU3RyaW5nO1xuZnVuY3Rpb24gQWEoYSkge1xuICBpZiAoYSAhPSBudWxsKSB7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBqYS5jYWxsKGEpO1xuICAgIH0gY2F0Y2gge1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgcmV0dXJuIGEgKyBcIlwiO1xuICAgIH0gY2F0Y2gge1xuICAgIH1cbiAgfVxuICByZXR1cm4gXCJcIjtcbn1cbnZhciBJaSA9IEFhLCBMYSA9IFBpLCBIYSA9IHphLCBXYSA9IF9pLCBGYSA9IElpLCBVYSA9IC9bXFxcXF4kLiorPygpW1xcXXt9fF0vZywgTmEgPSAvXlxcW29iamVjdCAuKz9Db25zdHJ1Y3RvclxcXSQvLCBHYSA9IEZ1bmN0aW9uLnByb3RvdHlwZSwgWWEgPSBPYmplY3QucHJvdG90eXBlLCBLYSA9IEdhLnRvU3RyaW5nLCBYYSA9IFlhLmhhc093blByb3BlcnR5LCBCYSA9IFJlZ0V4cChcbiAgXCJeXCIgKyBLYS5jYWxsKFhhKS5yZXBsYWNlKFVhLCBcIlxcXFwkJlwiKS5yZXBsYWNlKC9oYXNPd25Qcm9wZXJ0eXwoZnVuY3Rpb24pLio/KD89XFxcXFxcKCl8IGZvciAuKz8oPz1cXFxcXFxdKS9nLCBcIiQxLio/XCIpICsgXCIkXCJcbik7XG5mdW5jdGlvbiBWYShhKSB7XG4gIGlmICghV2EoYSkgfHwgSGEoYSkpXG4gICAgcmV0dXJuICExO1xuICB2YXIgaSA9IExhKGEpID8gQmEgOiBOYTtcbiAgcmV0dXJuIGkudGVzdChGYShhKSk7XG59XG52YXIgcWEgPSBWYTtcbmZ1bmN0aW9uIFphKGEsIGkpIHtcbiAgcmV0dXJuIGEgPT0gbnVsbCA/IHZvaWQgMCA6IGFbaV07XG59XG52YXIgSmEgPSBaYSwgUWEgPSBxYSwgZWwgPSBKYTtcbmZ1bmN0aW9uIHRsKGEsIGkpIHtcbiAgdmFyIHMgPSBlbChhLCBpKTtcbiAgcmV0dXJuIFFhKHMpID8gcyA6IHZvaWQgMDtcbn1cbnZhciBBZSA9IHRsLCBybCA9IEFlLCBubCA9IGdlLCBpbCA9IHJsKG5sLCBcIk1hcFwiKSwgUHIgPSBpbCwgb2wgPSBBZSwgc2wgPSBvbChPYmplY3QsIFwiY3JlYXRlXCIpLCAkdCA9IHNsLCBHbiA9ICR0O1xuZnVuY3Rpb24gYWwoKSB7XG4gIHRoaXMuX19kYXRhX18gPSBHbiA/IEduKG51bGwpIDoge30sIHRoaXMuc2l6ZSA9IDA7XG59XG52YXIgbGwgPSBhbDtcbmZ1bmN0aW9uIGNsKGEpIHtcbiAgdmFyIGkgPSB0aGlzLmhhcyhhKSAmJiBkZWxldGUgdGhpcy5fX2RhdGFfX1thXTtcbiAgcmV0dXJuIHRoaXMuc2l6ZSAtPSBpID8gMSA6IDAsIGk7XG59XG52YXIgdWwgPSBjbCwgcGwgPSAkdCwgaGwgPSBcIl9fbG9kYXNoX2hhc2hfdW5kZWZpbmVkX19cIiwgZGwgPSBPYmplY3QucHJvdG90eXBlLCBmbCA9IGRsLmhhc093blByb3BlcnR5O1xuZnVuY3Rpb24gdmwoYSkge1xuICB2YXIgaSA9IHRoaXMuX19kYXRhX187XG4gIGlmIChwbCkge1xuICAgIHZhciBzID0gaVthXTtcbiAgICByZXR1cm4gcyA9PT0gaGwgPyB2b2lkIDAgOiBzO1xuICB9XG4gIHJldHVybiBmbC5jYWxsKGksIGEpID8gaVthXSA6IHZvaWQgMDtcbn1cbnZhciBnbCA9IHZsLCBtbCA9ICR0LCBibCA9IE9iamVjdC5wcm90b3R5cGUsIHlsID0gYmwuaGFzT3duUHJvcGVydHk7XG5mdW5jdGlvbiBUbChhKSB7XG4gIHZhciBpID0gdGhpcy5fX2RhdGFfXztcbiAgcmV0dXJuIG1sID8gaVthXSAhPT0gdm9pZCAwIDogeWwuY2FsbChpLCBhKTtcbn1cbnZhciB3bCA9IFRsLCB4bCA9ICR0LCBTbCA9IFwiX19sb2Rhc2hfaGFzaF91bmRlZmluZWRfX1wiO1xuZnVuY3Rpb24gT2woYSwgaSkge1xuICB2YXIgcyA9IHRoaXMuX19kYXRhX187XG4gIHJldHVybiB0aGlzLnNpemUgKz0gdGhpcy5oYXMoYSkgPyAwIDogMSwgc1thXSA9IHhsICYmIGkgPT09IHZvaWQgMCA/IFNsIDogaSwgdGhpcztcbn1cbnZhciBDbCA9IE9sLCBFbCA9IGxsLCBfbCA9IHVsLCBQbCA9IGdsLCBJbCA9IHdsLCBNbCA9IENsO1xuZnVuY3Rpb24gTGUoYSkge1xuICB2YXIgaSA9IC0xLCBzID0gYSA9PSBudWxsID8gMCA6IGEubGVuZ3RoO1xuICBmb3IgKHRoaXMuY2xlYXIoKTsgKytpIDwgczsgKSB7XG4gICAgdmFyIHUgPSBhW2ldO1xuICAgIHRoaXMuc2V0KHVbMF0sIHVbMV0pO1xuICB9XG59XG5MZS5wcm90b3R5cGUuY2xlYXIgPSBFbDtcbkxlLnByb3RvdHlwZS5kZWxldGUgPSBfbDtcbkxlLnByb3RvdHlwZS5nZXQgPSBQbDtcbkxlLnByb3RvdHlwZS5oYXMgPSBJbDtcbkxlLnByb3RvdHlwZS5zZXQgPSBNbDtcbnZhciBSbCA9IExlLCBZbiA9IFJsLCBEbCA9IGt0LCBrbCA9IFByO1xuZnVuY3Rpb24gemwoKSB7XG4gIHRoaXMuc2l6ZSA9IDAsIHRoaXMuX19kYXRhX18gPSB7XG4gICAgaGFzaDogbmV3IFluKCksXG4gICAgbWFwOiBuZXcgKGtsIHx8IERsKSgpLFxuICAgIHN0cmluZzogbmV3IFluKClcbiAgfTtcbn1cbnZhciAkbCA9IHpsO1xuZnVuY3Rpb24gamwoYSkge1xuICB2YXIgaSA9IHR5cGVvZiBhO1xuICByZXR1cm4gaSA9PSBcInN0cmluZ1wiIHx8IGkgPT0gXCJudW1iZXJcIiB8fCBpID09IFwic3ltYm9sXCIgfHwgaSA9PSBcImJvb2xlYW5cIiA/IGEgIT09IFwiX19wcm90b19fXCIgOiBhID09PSBudWxsO1xufVxudmFyIEFsID0gamwsIExsID0gQWw7XG5mdW5jdGlvbiBIbChhLCBpKSB7XG4gIHZhciBzID0gYS5fX2RhdGFfXztcbiAgcmV0dXJuIExsKGkpID8gc1t0eXBlb2YgaSA9PSBcInN0cmluZ1wiID8gXCJzdHJpbmdcIiA6IFwiaGFzaFwiXSA6IHMubWFwO1xufVxudmFyIGp0ID0gSGwsIFdsID0ganQ7XG5mdW5jdGlvbiBGbChhKSB7XG4gIHZhciBpID0gV2wodGhpcywgYSkuZGVsZXRlKGEpO1xuICByZXR1cm4gdGhpcy5zaXplIC09IGkgPyAxIDogMCwgaTtcbn1cbnZhciBVbCA9IEZsLCBObCA9IGp0O1xuZnVuY3Rpb24gR2woYSkge1xuICByZXR1cm4gTmwodGhpcywgYSkuZ2V0KGEpO1xufVxudmFyIFlsID0gR2wsIEtsID0ganQ7XG5mdW5jdGlvbiBYbChhKSB7XG4gIHJldHVybiBLbCh0aGlzLCBhKS5oYXMoYSk7XG59XG52YXIgQmwgPSBYbCwgVmwgPSBqdDtcbmZ1bmN0aW9uIHFsKGEsIGkpIHtcbiAgdmFyIHMgPSBWbCh0aGlzLCBhKSwgdSA9IHMuc2l6ZTtcbiAgcmV0dXJuIHMuc2V0KGEsIGkpLCB0aGlzLnNpemUgKz0gcy5zaXplID09IHUgPyAwIDogMSwgdGhpcztcbn1cbnZhciBabCA9IHFsLCBKbCA9ICRsLCBRbCA9IFVsLCBlYyA9IFlsLCB0YyA9IEJsLCByYyA9IFpsO1xuZnVuY3Rpb24gSGUoYSkge1xuICB2YXIgaSA9IC0xLCBzID0gYSA9PSBudWxsID8gMCA6IGEubGVuZ3RoO1xuICBmb3IgKHRoaXMuY2xlYXIoKTsgKytpIDwgczsgKSB7XG4gICAgdmFyIHUgPSBhW2ldO1xuICAgIHRoaXMuc2V0KHVbMF0sIHVbMV0pO1xuICB9XG59XG5IZS5wcm90b3R5cGUuY2xlYXIgPSBKbDtcbkhlLnByb3RvdHlwZS5kZWxldGUgPSBRbDtcbkhlLnByb3RvdHlwZS5nZXQgPSBlYztcbkhlLnByb3RvdHlwZS5oYXMgPSB0YztcbkhlLnByb3RvdHlwZS5zZXQgPSByYztcbnZhciBNaSA9IEhlLCBuYyA9IGt0LCBpYyA9IFByLCBvYyA9IE1pLCBzYyA9IDIwMDtcbmZ1bmN0aW9uIGFjKGEsIGkpIHtcbiAgdmFyIHMgPSB0aGlzLl9fZGF0YV9fO1xuICBpZiAocyBpbnN0YW5jZW9mIG5jKSB7XG4gICAgdmFyIHUgPSBzLl9fZGF0YV9fO1xuICAgIGlmICghaWMgfHwgdS5sZW5ndGggPCBzYyAtIDEpXG4gICAgICByZXR1cm4gdS5wdXNoKFthLCBpXSksIHRoaXMuc2l6ZSA9ICsrcy5zaXplLCB0aGlzO1xuICAgIHMgPSB0aGlzLl9fZGF0YV9fID0gbmV3IG9jKHUpO1xuICB9XG4gIHJldHVybiBzLnNldChhLCBpKSwgdGhpcy5zaXplID0gcy5zaXplLCB0aGlzO1xufVxudmFyIGxjID0gYWMsIGNjID0ga3QsIHVjID0gcXMsIHBjID0gSnMsIGhjID0gZWEsIGRjID0gcmEsIGZjID0gbGM7XG5mdW5jdGlvbiBXZShhKSB7XG4gIHZhciBpID0gdGhpcy5fX2RhdGFfXyA9IG5ldyBjYyhhKTtcbiAgdGhpcy5zaXplID0gaS5zaXplO1xufVxuV2UucHJvdG90eXBlLmNsZWFyID0gdWM7XG5XZS5wcm90b3R5cGUuZGVsZXRlID0gcGM7XG5XZS5wcm90b3R5cGUuZ2V0ID0gaGM7XG5XZS5wcm90b3R5cGUuaGFzID0gZGM7XG5XZS5wcm90b3R5cGUuc2V0ID0gZmM7XG52YXIgdmMgPSBXZSwgZ2MgPSBcIl9fbG9kYXNoX2hhc2hfdW5kZWZpbmVkX19cIjtcbmZ1bmN0aW9uIG1jKGEpIHtcbiAgcmV0dXJuIHRoaXMuX19kYXRhX18uc2V0KGEsIGdjKSwgdGhpcztcbn1cbnZhciBiYyA9IG1jO1xuZnVuY3Rpb24geWMoYSkge1xuICByZXR1cm4gdGhpcy5fX2RhdGFfXy5oYXMoYSk7XG59XG52YXIgVGMgPSB5Yywgd2MgPSBNaSwgeGMgPSBiYywgU2MgPSBUYztcbmZ1bmN0aW9uIF90KGEpIHtcbiAgdmFyIGkgPSAtMSwgcyA9IGEgPT0gbnVsbCA/IDAgOiBhLmxlbmd0aDtcbiAgZm9yICh0aGlzLl9fZGF0YV9fID0gbmV3IHdjKCk7ICsraSA8IHM7IClcbiAgICB0aGlzLmFkZChhW2ldKTtcbn1cbl90LnByb3RvdHlwZS5hZGQgPSBfdC5wcm90b3R5cGUucHVzaCA9IHhjO1xuX3QucHJvdG90eXBlLmhhcyA9IFNjO1xudmFyIE9jID0gX3Q7XG5mdW5jdGlvbiBDYyhhLCBpKSB7XG4gIGZvciAodmFyIHMgPSAtMSwgdSA9IGEgPT0gbnVsbCA/IDAgOiBhLmxlbmd0aDsgKytzIDwgdTsgKVxuICAgIGlmIChpKGFbc10sIHMsIGEpKVxuICAgICAgcmV0dXJuICEwO1xuICByZXR1cm4gITE7XG59XG52YXIgRWMgPSBDYztcbmZ1bmN0aW9uIF9jKGEsIGkpIHtcbiAgcmV0dXJuIGEuaGFzKGkpO1xufVxudmFyIFBjID0gX2MsIEljID0gT2MsIE1jID0gRWMsIFJjID0gUGMsIERjID0gMSwga2MgPSAyO1xuZnVuY3Rpb24gemMoYSwgaSwgcywgdSwgdiwgZikge1xuICB2YXIgbSA9IHMgJiBEYywgeSA9IGEubGVuZ3RoLCBTID0gaS5sZW5ndGg7XG4gIGlmICh5ICE9IFMgJiYgIShtICYmIFMgPiB5KSlcbiAgICByZXR1cm4gITE7XG4gIHZhciBDID0gZi5nZXQoYSksIEQgPSBmLmdldChpKTtcbiAgaWYgKEMgJiYgRClcbiAgICByZXR1cm4gQyA9PSBpICYmIEQgPT0gYTtcbiAgdmFyIFIgPSAtMSwgVCA9ICEwLCBQID0gcyAmIGtjID8gbmV3IEljKCkgOiB2b2lkIDA7XG4gIGZvciAoZi5zZXQoYSwgaSksIGYuc2V0KGksIGEpOyArK1IgPCB5OyApIHtcbiAgICB2YXIgXyA9IGFbUl0sIE8gPSBpW1JdO1xuICAgIGlmICh1KVxuICAgICAgdmFyIGsgPSBtID8gdShPLCBfLCBSLCBpLCBhLCBmKSA6IHUoXywgTywgUiwgYSwgaSwgZik7XG4gICAgaWYgKGsgIT09IHZvaWQgMCkge1xuICAgICAgaWYgKGspXG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgVCA9ICExO1xuICAgICAgYnJlYWs7XG4gICAgfVxuICAgIGlmIChQKSB7XG4gICAgICBpZiAoIU1jKGksIGZ1bmN0aW9uKEwsIEgpIHtcbiAgICAgICAgaWYgKCFSYyhQLCBIKSAmJiAoXyA9PT0gTCB8fCB2KF8sIEwsIHMsIHUsIGYpKSlcbiAgICAgICAgICByZXR1cm4gUC5wdXNoKEgpO1xuICAgICAgfSkpIHtcbiAgICAgICAgVCA9ICExO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKCEoXyA9PT0gTyB8fCB2KF8sIE8sIHMsIHUsIGYpKSkge1xuICAgICAgVCA9ICExO1xuICAgICAgYnJlYWs7XG4gICAgfVxuICB9XG4gIHJldHVybiBmLmRlbGV0ZShhKSwgZi5kZWxldGUoaSksIFQ7XG59XG52YXIgUmkgPSB6YywgJGMgPSBnZSwgamMgPSAkYy5VaW50OEFycmF5LCBBYyA9IGpjO1xuZnVuY3Rpb24gTGMoYSkge1xuICB2YXIgaSA9IC0xLCBzID0gQXJyYXkoYS5zaXplKTtcbiAgcmV0dXJuIGEuZm9yRWFjaChmdW5jdGlvbih1LCB2KSB7XG4gICAgc1srK2ldID0gW3YsIHVdO1xuICB9KSwgcztcbn1cbnZhciBIYyA9IExjO1xuZnVuY3Rpb24gV2MoYSkge1xuICB2YXIgaSA9IC0xLCBzID0gQXJyYXkoYS5zaXplKTtcbiAgcmV0dXJuIGEuZm9yRWFjaChmdW5jdGlvbih1KSB7XG4gICAgc1srK2ldID0gdTtcbiAgfSksIHM7XG59XG52YXIgRmMgPSBXYywgS24gPSBfciwgWG4gPSBBYywgVWMgPSBPaSwgTmMgPSBSaSwgR2MgPSBIYywgWWMgPSBGYywgS2MgPSAxLCBYYyA9IDIsIEJjID0gXCJbb2JqZWN0IEJvb2xlYW5dXCIsIFZjID0gXCJbb2JqZWN0IERhdGVdXCIsIHFjID0gXCJbb2JqZWN0IEVycm9yXVwiLCBaYyA9IFwiW29iamVjdCBNYXBdXCIsIEpjID0gXCJbb2JqZWN0IE51bWJlcl1cIiwgUWMgPSBcIltvYmplY3QgUmVnRXhwXVwiLCBldSA9IFwiW29iamVjdCBTZXRdXCIsIHR1ID0gXCJbb2JqZWN0IFN0cmluZ11cIiwgcnUgPSBcIltvYmplY3QgU3ltYm9sXVwiLCBudSA9IFwiW29iamVjdCBBcnJheUJ1ZmZlcl1cIiwgaXUgPSBcIltvYmplY3QgRGF0YVZpZXddXCIsIEJuID0gS24gPyBLbi5wcm90b3R5cGUgOiB2b2lkIDAsIHZyID0gQm4gPyBCbi52YWx1ZU9mIDogdm9pZCAwO1xuZnVuY3Rpb24gb3UoYSwgaSwgcywgdSwgdiwgZiwgbSkge1xuICBzd2l0Y2ggKHMpIHtcbiAgICBjYXNlIGl1OlxuICAgICAgaWYgKGEuYnl0ZUxlbmd0aCAhPSBpLmJ5dGVMZW5ndGggfHwgYS5ieXRlT2Zmc2V0ICE9IGkuYnl0ZU9mZnNldClcbiAgICAgICAgcmV0dXJuICExO1xuICAgICAgYSA9IGEuYnVmZmVyLCBpID0gaS5idWZmZXI7XG4gICAgY2FzZSBudTpcbiAgICAgIHJldHVybiAhKGEuYnl0ZUxlbmd0aCAhPSBpLmJ5dGVMZW5ndGggfHwgIWYobmV3IFhuKGEpLCBuZXcgWG4oaSkpKTtcbiAgICBjYXNlIEJjOlxuICAgIGNhc2UgVmM6XG4gICAgY2FzZSBKYzpcbiAgICAgIHJldHVybiBVYygrYSwgK2kpO1xuICAgIGNhc2UgcWM6XG4gICAgICByZXR1cm4gYS5uYW1lID09IGkubmFtZSAmJiBhLm1lc3NhZ2UgPT0gaS5tZXNzYWdlO1xuICAgIGNhc2UgUWM6XG4gICAgY2FzZSB0dTpcbiAgICAgIHJldHVybiBhID09IGkgKyBcIlwiO1xuICAgIGNhc2UgWmM6XG4gICAgICB2YXIgeSA9IEdjO1xuICAgIGNhc2UgZXU6XG4gICAgICB2YXIgUyA9IHUgJiBLYztcbiAgICAgIGlmICh5IHx8ICh5ID0gWWMpLCBhLnNpemUgIT0gaS5zaXplICYmICFTKVxuICAgICAgICByZXR1cm4gITE7XG4gICAgICB2YXIgQyA9IG0uZ2V0KGEpO1xuICAgICAgaWYgKEMpXG4gICAgICAgIHJldHVybiBDID09IGk7XG4gICAgICB1IHw9IFhjLCBtLnNldChhLCBpKTtcbiAgICAgIHZhciBEID0gTmMoeShhKSwgeShpKSwgdSwgdiwgZiwgbSk7XG4gICAgICByZXR1cm4gbS5kZWxldGUoYSksIEQ7XG4gICAgY2FzZSBydTpcbiAgICAgIGlmICh2cilcbiAgICAgICAgcmV0dXJuIHZyLmNhbGwoYSkgPT0gdnIuY2FsbChpKTtcbiAgfVxuICByZXR1cm4gITE7XG59XG52YXIgc3UgPSBvdTtcbmZ1bmN0aW9uIGF1KGEsIGkpIHtcbiAgZm9yICh2YXIgcyA9IC0xLCB1ID0gaS5sZW5ndGgsIHYgPSBhLmxlbmd0aDsgKytzIDwgdTsgKVxuICAgIGFbdiArIHNdID0gaVtzXTtcbiAgcmV0dXJuIGE7XG59XG52YXIgbHUgPSBhdSwgY3UgPSBBcnJheS5pc0FycmF5LCBJciA9IGN1LCB1dSA9IGx1LCBwdSA9IElyO1xuZnVuY3Rpb24gaHUoYSwgaSwgcykge1xuICB2YXIgdSA9IGkoYSk7XG4gIHJldHVybiBwdShhKSA/IHUgOiB1dSh1LCBzKGEpKTtcbn1cbnZhciBkdSA9IGh1O1xuZnVuY3Rpb24gZnUoYSwgaSkge1xuICBmb3IgKHZhciBzID0gLTEsIHUgPSBhID09IG51bGwgPyAwIDogYS5sZW5ndGgsIHYgPSAwLCBmID0gW107ICsrcyA8IHU7ICkge1xuICAgIHZhciBtID0gYVtzXTtcbiAgICBpKG0sIHMsIGEpICYmIChmW3YrK10gPSBtKTtcbiAgfVxuICByZXR1cm4gZjtcbn1cbnZhciB2dSA9IGZ1O1xuZnVuY3Rpb24gZ3UoKSB7XG4gIHJldHVybiBbXTtcbn1cbnZhciBtdSA9IGd1LCBidSA9IHZ1LCB5dSA9IG11LCBUdSA9IE9iamVjdC5wcm90b3R5cGUsIHd1ID0gVHUucHJvcGVydHlJc0VudW1lcmFibGUsIFZuID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scywgeHUgPSBWbiA/IGZ1bmN0aW9uKGEpIHtcbiAgcmV0dXJuIGEgPT0gbnVsbCA/IFtdIDogKGEgPSBPYmplY3QoYSksIGJ1KFZuKGEpLCBmdW5jdGlvbihpKSB7XG4gICAgcmV0dXJuIHd1LmNhbGwoYSwgaSk7XG4gIH0pKTtcbn0gOiB5dSwgU3UgPSB4dTtcbmZ1bmN0aW9uIE91KGEsIGkpIHtcbiAgZm9yICh2YXIgcyA9IC0xLCB1ID0gQXJyYXkoYSk7ICsrcyA8IGE7IClcbiAgICB1W3NdID0gaShzKTtcbiAgcmV0dXJuIHU7XG59XG52YXIgQ3UgPSBPdTtcbmZ1bmN0aW9uIEV1KGEpIHtcbiAgcmV0dXJuIGEgIT0gbnVsbCAmJiB0eXBlb2YgYSA9PSBcIm9iamVjdFwiO1xufVxudmFyIEF0ID0gRXUsIF91ID0genQsIFB1ID0gQXQsIEl1ID0gXCJbb2JqZWN0IEFyZ3VtZW50c11cIjtcbmZ1bmN0aW9uIE11KGEpIHtcbiAgcmV0dXJuIFB1KGEpICYmIF91KGEpID09IEl1O1xufVxudmFyIFJ1ID0gTXUsIHFuID0gUnUsIER1ID0gQXQsIERpID0gT2JqZWN0LnByb3RvdHlwZSwga3UgPSBEaS5oYXNPd25Qcm9wZXJ0eSwgenUgPSBEaS5wcm9wZXJ0eUlzRW51bWVyYWJsZSwgJHUgPSBxbigvKiBAX19QVVJFX18gKi8gZnVuY3Rpb24oKSB7XG4gIHJldHVybiBhcmd1bWVudHM7XG59KCkpID8gcW4gOiBmdW5jdGlvbihhKSB7XG4gIHJldHVybiBEdShhKSAmJiBrdS5jYWxsKGEsIFwiY2FsbGVlXCIpICYmICF6dS5jYWxsKGEsIFwiY2FsbGVlXCIpO1xufSwganUgPSAkdSwgUHQgPSB7IGV4cG9ydHM6IHt9IH07XG5mdW5jdGlvbiBBdSgpIHtcbiAgcmV0dXJuICExO1xufVxudmFyIEx1ID0gQXU7XG5QdC5leHBvcnRzO1xuKGZ1bmN0aW9uKGEsIGkpIHtcbiAgdmFyIHMgPSBnZSwgdSA9IEx1LCB2ID0gaSAmJiAhaS5ub2RlVHlwZSAmJiBpLCBmID0gdiAmJiAhMCAmJiBhICYmICFhLm5vZGVUeXBlICYmIGEsIG0gPSBmICYmIGYuZXhwb3J0cyA9PT0gdiwgeSA9IG0gPyBzLkJ1ZmZlciA6IHZvaWQgMCwgUyA9IHkgPyB5LmlzQnVmZmVyIDogdm9pZCAwLCBDID0gUyB8fCB1O1xuICBhLmV4cG9ydHMgPSBDO1xufSkoUHQsIFB0LmV4cG9ydHMpO1xudmFyIGtpID0gUHQuZXhwb3J0cywgSHUgPSA5MDA3MTk5MjU0NzQwOTkxLCBXdSA9IC9eKD86MHxbMS05XVxcZCopJC87XG5mdW5jdGlvbiBGdShhLCBpKSB7XG4gIHZhciBzID0gdHlwZW9mIGE7XG4gIHJldHVybiBpID0gaSA/PyBIdSwgISFpICYmIChzID09IFwibnVtYmVyXCIgfHwgcyAhPSBcInN5bWJvbFwiICYmIFd1LnRlc3QoYSkpICYmIGEgPiAtMSAmJiBhICUgMSA9PSAwICYmIGEgPCBpO1xufVxudmFyIFV1ID0gRnUsIE51ID0gOTAwNzE5OTI1NDc0MDk5MTtcbmZ1bmN0aW9uIEd1KGEpIHtcbiAgcmV0dXJuIHR5cGVvZiBhID09IFwibnVtYmVyXCIgJiYgYSA+IC0xICYmIGEgJSAxID09IDAgJiYgYSA8PSBOdTtcbn1cbnZhciB6aSA9IEd1LCBZdSA9IHp0LCBLdSA9IHppLCBYdSA9IEF0LCBCdSA9IFwiW29iamVjdCBBcmd1bWVudHNdXCIsIFZ1ID0gXCJbb2JqZWN0IEFycmF5XVwiLCBxdSA9IFwiW29iamVjdCBCb29sZWFuXVwiLCBadSA9IFwiW29iamVjdCBEYXRlXVwiLCBKdSA9IFwiW29iamVjdCBFcnJvcl1cIiwgUXUgPSBcIltvYmplY3QgRnVuY3Rpb25dXCIsIGVwID0gXCJbb2JqZWN0IE1hcF1cIiwgdHAgPSBcIltvYmplY3QgTnVtYmVyXVwiLCBycCA9IFwiW29iamVjdCBPYmplY3RdXCIsIG5wID0gXCJbb2JqZWN0IFJlZ0V4cF1cIiwgaXAgPSBcIltvYmplY3QgU2V0XVwiLCBvcCA9IFwiW29iamVjdCBTdHJpbmddXCIsIHNwID0gXCJbb2JqZWN0IFdlYWtNYXBdXCIsIGFwID0gXCJbb2JqZWN0IEFycmF5QnVmZmVyXVwiLCBscCA9IFwiW29iamVjdCBEYXRhVmlld11cIiwgY3AgPSBcIltvYmplY3QgRmxvYXQzMkFycmF5XVwiLCB1cCA9IFwiW29iamVjdCBGbG9hdDY0QXJyYXldXCIsIHBwID0gXCJbb2JqZWN0IEludDhBcnJheV1cIiwgaHAgPSBcIltvYmplY3QgSW50MTZBcnJheV1cIiwgZHAgPSBcIltvYmplY3QgSW50MzJBcnJheV1cIiwgZnAgPSBcIltvYmplY3QgVWludDhBcnJheV1cIiwgdnAgPSBcIltvYmplY3QgVWludDhDbGFtcGVkQXJyYXldXCIsIGdwID0gXCJbb2JqZWN0IFVpbnQxNkFycmF5XVwiLCBtcCA9IFwiW29iamVjdCBVaW50MzJBcnJheV1cIiwgcSA9IHt9O1xucVtjcF0gPSBxW3VwXSA9IHFbcHBdID0gcVtocF0gPSBxW2RwXSA9IHFbZnBdID0gcVt2cF0gPSBxW2dwXSA9IHFbbXBdID0gITA7XG5xW0J1XSA9IHFbVnVdID0gcVthcF0gPSBxW3F1XSA9IHFbbHBdID0gcVtadV0gPSBxW0p1XSA9IHFbUXVdID0gcVtlcF0gPSBxW3RwXSA9IHFbcnBdID0gcVtucF0gPSBxW2lwXSA9IHFbb3BdID0gcVtzcF0gPSAhMTtcbmZ1bmN0aW9uIGJwKGEpIHtcbiAgcmV0dXJuIFh1KGEpICYmIEt1KGEubGVuZ3RoKSAmJiAhIXFbWXUoYSldO1xufVxudmFyIHlwID0gYnA7XG5mdW5jdGlvbiBUcChhKSB7XG4gIHJldHVybiBmdW5jdGlvbihpKSB7XG4gICAgcmV0dXJuIGEoaSk7XG4gIH07XG59XG52YXIgd3AgPSBUcCwgSXQgPSB7IGV4cG9ydHM6IHt9IH07XG5JdC5leHBvcnRzO1xuKGZ1bmN0aW9uKGEsIGkpIHtcbiAgdmFyIHMgPSBDaSwgdSA9IGkgJiYgIWkubm9kZVR5cGUgJiYgaSwgdiA9IHUgJiYgITAgJiYgYSAmJiAhYS5ub2RlVHlwZSAmJiBhLCBmID0gdiAmJiB2LmV4cG9ydHMgPT09IHUsIG0gPSBmICYmIHMucHJvY2VzcywgeSA9IGZ1bmN0aW9uKCkge1xuICAgIHRyeSB7XG4gICAgICB2YXIgUyA9IHYgJiYgdi5yZXF1aXJlICYmIHYucmVxdWlyZShcInV0aWxcIikudHlwZXM7XG4gICAgICByZXR1cm4gUyB8fCBtICYmIG0uYmluZGluZyAmJiBtLmJpbmRpbmcoXCJ1dGlsXCIpO1xuICAgIH0gY2F0Y2gge1xuICAgIH1cbiAgfSgpO1xuICBhLmV4cG9ydHMgPSB5O1xufSkoSXQsIEl0LmV4cG9ydHMpO1xudmFyIHhwID0gSXQuZXhwb3J0cywgU3AgPSB5cCwgT3AgPSB3cCwgWm4gPSB4cCwgSm4gPSBabiAmJiBabi5pc1R5cGVkQXJyYXksIENwID0gSm4gPyBPcChKbikgOiBTcCwgJGkgPSBDcCwgRXAgPSBDdSwgX3AgPSBqdSwgUHAgPSBJciwgSXAgPSBraSwgTXAgPSBVdSwgUnAgPSAkaSwgRHAgPSBPYmplY3QucHJvdG90eXBlLCBrcCA9IERwLmhhc093blByb3BlcnR5O1xuZnVuY3Rpb24genAoYSwgaSkge1xuICB2YXIgcyA9IFBwKGEpLCB1ID0gIXMgJiYgX3AoYSksIHYgPSAhcyAmJiAhdSAmJiBJcChhKSwgZiA9ICFzICYmICF1ICYmICF2ICYmIFJwKGEpLCBtID0gcyB8fCB1IHx8IHYgfHwgZiwgeSA9IG0gPyBFcChhLmxlbmd0aCwgU3RyaW5nKSA6IFtdLCBTID0geS5sZW5ndGg7XG4gIGZvciAodmFyIEMgaW4gYSlcbiAgICAoaSB8fCBrcC5jYWxsKGEsIEMpKSAmJiAhKG0gJiYgLy8gU2FmYXJpIDkgaGFzIGVudW1lcmFibGUgYGFyZ3VtZW50cy5sZW5ndGhgIGluIHN0cmljdCBtb2RlLlxuICAgIChDID09IFwibGVuZ3RoXCIgfHwgLy8gTm9kZS5qcyAwLjEwIGhhcyBlbnVtZXJhYmxlIG5vbi1pbmRleCBwcm9wZXJ0aWVzIG9uIGJ1ZmZlcnMuXG4gICAgdiAmJiAoQyA9PSBcIm9mZnNldFwiIHx8IEMgPT0gXCJwYXJlbnRcIikgfHwgLy8gUGhhbnRvbUpTIDIgaGFzIGVudW1lcmFibGUgbm9uLWluZGV4IHByb3BlcnRpZXMgb24gdHlwZWQgYXJyYXlzLlxuICAgIGYgJiYgKEMgPT0gXCJidWZmZXJcIiB8fCBDID09IFwiYnl0ZUxlbmd0aFwiIHx8IEMgPT0gXCJieXRlT2Zmc2V0XCIpIHx8IC8vIFNraXAgaW5kZXggcHJvcGVydGllcy5cbiAgICBNcChDLCBTKSkpICYmIHkucHVzaChDKTtcbiAgcmV0dXJuIHk7XG59XG52YXIgJHAgPSB6cCwganAgPSBPYmplY3QucHJvdG90eXBlO1xuZnVuY3Rpb24gQXAoYSkge1xuICB2YXIgaSA9IGEgJiYgYS5jb25zdHJ1Y3RvciwgcyA9IHR5cGVvZiBpID09IFwiZnVuY3Rpb25cIiAmJiBpLnByb3RvdHlwZSB8fCBqcDtcbiAgcmV0dXJuIGEgPT09IHM7XG59XG52YXIgTHAgPSBBcDtcbmZ1bmN0aW9uIEhwKGEsIGkpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uKHMpIHtcbiAgICByZXR1cm4gYShpKHMpKTtcbiAgfTtcbn1cbnZhciBXcCA9IEhwLCBGcCA9IFdwLCBVcCA9IEZwKE9iamVjdC5rZXlzLCBPYmplY3QpLCBOcCA9IFVwLCBHcCA9IExwLCBZcCA9IE5wLCBLcCA9IE9iamVjdC5wcm90b3R5cGUsIFhwID0gS3AuaGFzT3duUHJvcGVydHk7XG5mdW5jdGlvbiBCcChhKSB7XG4gIGlmICghR3AoYSkpXG4gICAgcmV0dXJuIFlwKGEpO1xuICB2YXIgaSA9IFtdO1xuICBmb3IgKHZhciBzIGluIE9iamVjdChhKSlcbiAgICBYcC5jYWxsKGEsIHMpICYmIHMgIT0gXCJjb25zdHJ1Y3RvclwiICYmIGkucHVzaChzKTtcbiAgcmV0dXJuIGk7XG59XG52YXIgVnAgPSBCcCwgcXAgPSBQaSwgWnAgPSB6aTtcbmZ1bmN0aW9uIEpwKGEpIHtcbiAgcmV0dXJuIGEgIT0gbnVsbCAmJiBacChhLmxlbmd0aCkgJiYgIXFwKGEpO1xufVxudmFyIFFwID0gSnAsIGVoID0gJHAsIHRoID0gVnAsIHJoID0gUXA7XG5mdW5jdGlvbiBuaChhKSB7XG4gIHJldHVybiByaChhKSA/IGVoKGEpIDogdGgoYSk7XG59XG52YXIgaWggPSBuaCwgb2ggPSBkdSwgc2ggPSBTdSwgYWggPSBpaDtcbmZ1bmN0aW9uIGxoKGEpIHtcbiAgcmV0dXJuIG9oKGEsIGFoLCBzaCk7XG59XG52YXIgY2ggPSBsaCwgUW4gPSBjaCwgdWggPSAxLCBwaCA9IE9iamVjdC5wcm90b3R5cGUsIGhoID0gcGguaGFzT3duUHJvcGVydHk7XG5mdW5jdGlvbiBkaChhLCBpLCBzLCB1LCB2LCBmKSB7XG4gIHZhciBtID0gcyAmIHVoLCB5ID0gUW4oYSksIFMgPSB5Lmxlbmd0aCwgQyA9IFFuKGkpLCBEID0gQy5sZW5ndGg7XG4gIGlmIChTICE9IEQgJiYgIW0pXG4gICAgcmV0dXJuICExO1xuICBmb3IgKHZhciBSID0gUzsgUi0tOyApIHtcbiAgICB2YXIgVCA9IHlbUl07XG4gICAgaWYgKCEobSA/IFQgaW4gaSA6IGhoLmNhbGwoaSwgVCkpKVxuICAgICAgcmV0dXJuICExO1xuICB9XG4gIHZhciBQID0gZi5nZXQoYSksIF8gPSBmLmdldChpKTtcbiAgaWYgKFAgJiYgXylcbiAgICByZXR1cm4gUCA9PSBpICYmIF8gPT0gYTtcbiAgdmFyIE8gPSAhMDtcbiAgZi5zZXQoYSwgaSksIGYuc2V0KGksIGEpO1xuICBmb3IgKHZhciBrID0gbTsgKytSIDwgUzsgKSB7XG4gICAgVCA9IHlbUl07XG4gICAgdmFyIEwgPSBhW1RdLCBIID0gaVtUXTtcbiAgICBpZiAodSlcbiAgICAgIHZhciBYID0gbSA/IHUoSCwgTCwgVCwgaSwgYSwgZikgOiB1KEwsIEgsIFQsIGEsIGksIGYpO1xuICAgIGlmICghKFggPT09IHZvaWQgMCA/IEwgPT09IEggfHwgdihMLCBILCBzLCB1LCBmKSA6IFgpKSB7XG4gICAgICBPID0gITE7XG4gICAgICBicmVhaztcbiAgICB9XG4gICAgayB8fCAoayA9IFQgPT0gXCJjb25zdHJ1Y3RvclwiKTtcbiAgfVxuICBpZiAoTyAmJiAhaykge1xuICAgIHZhciBCID0gYS5jb25zdHJ1Y3RvciwgViA9IGkuY29uc3RydWN0b3I7XG4gICAgQiAhPSBWICYmIFwiY29uc3RydWN0b3JcIiBpbiBhICYmIFwiY29uc3RydWN0b3JcIiBpbiBpICYmICEodHlwZW9mIEIgPT0gXCJmdW5jdGlvblwiICYmIEIgaW5zdGFuY2VvZiBCICYmIHR5cGVvZiBWID09IFwiZnVuY3Rpb25cIiAmJiBWIGluc3RhbmNlb2YgVikgJiYgKE8gPSAhMSk7XG4gIH1cbiAgcmV0dXJuIGYuZGVsZXRlKGEpLCBmLmRlbGV0ZShpKSwgTztcbn1cbnZhciBmaCA9IGRoLCB2aCA9IEFlLCBnaCA9IGdlLCBtaCA9IHZoKGdoLCBcIkRhdGFWaWV3XCIpLCBiaCA9IG1oLCB5aCA9IEFlLCBUaCA9IGdlLCB3aCA9IHloKFRoLCBcIlByb21pc2VcIiksIHhoID0gd2gsIFNoID0gQWUsIE9oID0gZ2UsIENoID0gU2goT2gsIFwiU2V0XCIpLCBFaCA9IENoLCBfaCA9IEFlLCBQaCA9IGdlLCBJaCA9IF9oKFBoLCBcIldlYWtNYXBcIiksIE1oID0gSWgsIG1yID0gYmgsIGJyID0gUHIsIHlyID0geGgsIFRyID0gRWgsIHdyID0gTWgsIGppID0genQsIEZlID0gSWksIGVpID0gXCJbb2JqZWN0IE1hcF1cIiwgUmggPSBcIltvYmplY3QgT2JqZWN0XVwiLCB0aSA9IFwiW29iamVjdCBQcm9taXNlXVwiLCByaSA9IFwiW29iamVjdCBTZXRdXCIsIG5pID0gXCJbb2JqZWN0IFdlYWtNYXBdXCIsIGlpID0gXCJbb2JqZWN0IERhdGFWaWV3XVwiLCBEaCA9IEZlKG1yKSwga2ggPSBGZShiciksIHpoID0gRmUoeXIpLCAkaCA9IEZlKFRyKSwgamggPSBGZSh3ciksIF9lID0gamk7XG4obXIgJiYgX2UobmV3IG1yKG5ldyBBcnJheUJ1ZmZlcigxKSkpICE9IGlpIHx8IGJyICYmIF9lKG5ldyBicigpKSAhPSBlaSB8fCB5ciAmJiBfZSh5ci5yZXNvbHZlKCkpICE9IHRpIHx8IFRyICYmIF9lKG5ldyBUcigpKSAhPSByaSB8fCB3ciAmJiBfZShuZXcgd3IoKSkgIT0gbmkpICYmIChfZSA9IGZ1bmN0aW9uKGEpIHtcbiAgdmFyIGkgPSBqaShhKSwgcyA9IGkgPT0gUmggPyBhLmNvbnN0cnVjdG9yIDogdm9pZCAwLCB1ID0gcyA/IEZlKHMpIDogXCJcIjtcbiAgaWYgKHUpXG4gICAgc3dpdGNoICh1KSB7XG4gICAgICBjYXNlIERoOlxuICAgICAgICByZXR1cm4gaWk7XG4gICAgICBjYXNlIGtoOlxuICAgICAgICByZXR1cm4gZWk7XG4gICAgICBjYXNlIHpoOlxuICAgICAgICByZXR1cm4gdGk7XG4gICAgICBjYXNlICRoOlxuICAgICAgICByZXR1cm4gcmk7XG4gICAgICBjYXNlIGpoOlxuICAgICAgICByZXR1cm4gbmk7XG4gICAgfVxuICByZXR1cm4gaTtcbn0pO1xudmFyIEFoID0gX2UsIGdyID0gdmMsIExoID0gUmksIEhoID0gc3UsIFdoID0gZmgsIG9pID0gQWgsIHNpID0gSXIsIGFpID0ga2ksIEZoID0gJGksIFVoID0gMSwgbGkgPSBcIltvYmplY3QgQXJndW1lbnRzXVwiLCBjaSA9IFwiW29iamVjdCBBcnJheV1cIiwgeXQgPSBcIltvYmplY3QgT2JqZWN0XVwiLCBOaCA9IE9iamVjdC5wcm90b3R5cGUsIHVpID0gTmguaGFzT3duUHJvcGVydHk7XG5mdW5jdGlvbiBHaChhLCBpLCBzLCB1LCB2LCBmKSB7XG4gIHZhciBtID0gc2koYSksIHkgPSBzaShpKSwgUyA9IG0gPyBjaSA6IG9pKGEpLCBDID0geSA/IGNpIDogb2koaSk7XG4gIFMgPSBTID09IGxpID8geXQgOiBTLCBDID0gQyA9PSBsaSA/IHl0IDogQztcbiAgdmFyIEQgPSBTID09IHl0LCBSID0gQyA9PSB5dCwgVCA9IFMgPT0gQztcbiAgaWYgKFQgJiYgYWkoYSkpIHtcbiAgICBpZiAoIWFpKGkpKVxuICAgICAgcmV0dXJuICExO1xuICAgIG0gPSAhMCwgRCA9ICExO1xuICB9XG4gIGlmIChUICYmICFEKVxuICAgIHJldHVybiBmIHx8IChmID0gbmV3IGdyKCkpLCBtIHx8IEZoKGEpID8gTGgoYSwgaSwgcywgdSwgdiwgZikgOiBIaChhLCBpLCBTLCBzLCB1LCB2LCBmKTtcbiAgaWYgKCEocyAmIFVoKSkge1xuICAgIHZhciBQID0gRCAmJiB1aS5jYWxsKGEsIFwiX193cmFwcGVkX19cIiksIF8gPSBSICYmIHVpLmNhbGwoaSwgXCJfX3dyYXBwZWRfX1wiKTtcbiAgICBpZiAoUCB8fCBfKSB7XG4gICAgICB2YXIgTyA9IFAgPyBhLnZhbHVlKCkgOiBhLCBrID0gXyA/IGkudmFsdWUoKSA6IGk7XG4gICAgICByZXR1cm4gZiB8fCAoZiA9IG5ldyBncigpKSwgdihPLCBrLCBzLCB1LCBmKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIFQgPyAoZiB8fCAoZiA9IG5ldyBncigpKSwgV2goYSwgaSwgcywgdSwgdiwgZikpIDogITE7XG59XG52YXIgWWggPSBHaCwgS2ggPSBZaCwgcGkgPSBBdDtcbmZ1bmN0aW9uIEFpKGEsIGksIHMsIHUsIHYpIHtcbiAgcmV0dXJuIGEgPT09IGkgPyAhMCA6IGEgPT0gbnVsbCB8fCBpID09IG51bGwgfHwgIXBpKGEpICYmICFwaShpKSA/IGEgIT09IGEgJiYgaSAhPT0gaSA6IEtoKGEsIGksIHMsIHUsIEFpLCB2KTtcbn1cbnZhciBYaCA9IEFpLCBCaCA9IFhoO1xuZnVuY3Rpb24gVmgoYSwgaSkge1xuICByZXR1cm4gQmgoYSwgaSk7XG59XG52YXIgcWggPSBWaDtcbmNvbnN0IHhyID0gLyogQF9fUFVSRV9fICovIHJ0KHFoKTtcbmZ1bmN0aW9uIFkoYSwgaSkge1xuICByZXR1cm4gdHlwZW9mIGEuZ2V0ID09IFwiZnVuY3Rpb25cIiA/IGEuZ2V0KGkpIDogYVtpXTtcbn1cbmZ1bmN0aW9uIGhpKGEpIHtcbiAgcmV0dXJuIHR5cGVvZiBhLmNvdW50ID09IFwiZnVuY3Rpb25cIiA/IGEuY291bnQoKSA6IGEubGVuZ3RoO1xufVxuZnVuY3Rpb24gdHQoYSwgaSkge1xuICByZXR1cm4gaGkoYSkgPT09IGhpKGkpICYmIGEuZXZlcnkoKHMsIHUpID0+IHMgPT09IFkoaSwgdS50b1N0cmluZygpKSk7XG59XG5mdW5jdGlvbiBaaChhLCBpKSB7XG4gIGNvbnN0IHMgPSB7fTtcbiAgcmV0dXJuIGEuZm9yRWFjaCgodSkgPT4ge1xuICAgIHNbdVtpXV0gPSB1O1xuICB9KSwgcztcbn1cbmZ1bmN0aW9uIHd0KCkge1xufVxuZnVuY3Rpb24gUGUoLi4uYSkge1xuICByZXR1cm4gKGksIC4uLnMpID0+IHtcbiAgICBpLnByZXZlbnREZWZhdWx0KCksIGEuZm9yRWFjaCgodSkgPT4gdSAmJiB1KGksIC4uLnMpKTtcbiAgfTtcbn1cbmZ1bmN0aW9uIExpKHsgaXRlbTogYSwgaXRlbUNvbnRleHQ6IGksIGdldEl0ZW1Qcm9wczogcywgZ2V0UmVzaXplUHJvcHM6IHUgfSkge1xuICBjb25zdCB7IGxlZnQ6IHYsIHJpZ2h0OiBmIH0gPSB1KCksIHsga2V5OiBtLCByZWY6IHksIC4uLlMgfSA9IHMoYS5pdGVtUHJvcHMgPz8ge30pLCB7IHVzZVJlc2l6ZUhhbmRsZTogQyB9ID0gaTtcbiAgcmV0dXJuIFR0KFxuICAgIFwiZGl2XCIsXG4gICAgeyAuLi5TLCByZWY6IHksIGtleTogYCR7bX0tb3V0ZXJgIH0sXG4gICAgQyA/IFR0KFwiZGl2XCIsIHsgLi4udiwga2V5OiBgJHttfS1scmAgfSkgOiBudWxsLFxuICAgIGooXCJkaXZcIiwgeyBjbGFzc05hbWU6IFwicmN0LWl0ZW0tY29udGVudFwiLCBzdHlsZTogeyBtYXhIZWlnaHQ6IGAke2kuZGltZW5zaW9ucy5oZWlnaHR9YCB9LCBjaGlsZHJlbjogaS50aXRsZSB9LCBgJHttfS1jb250ZW50YCksXG4gICAgQyA/IFR0KFwiZGl2XCIsIHsgLi4uZiwga2V5OiBgJHttfS1ycmAgfSkgOiBudWxsXG4gICk7XG59XG5mdW5jdGlvbiBNdChhLCBpLCBzKSB7XG4gIHJldHVybiAoaSAtIGEpIC8gcztcbn1cbmZ1bmN0aW9uIFJ0KGEsIGksIHMsIHUpIHtcbiAgY29uc3QgdiA9IHMgLyAoaSAtIGEpO1xuICByZXR1cm4gKHUgLSBhKSAqIHY7XG59XG5mdW5jdGlvbiBNcihhLCBpLCBzLCB1KSB7XG4gIHJldHVybiAoaSAtIGEpIC8gcyAqIHUgKyBhO1xufVxuZnVuY3Rpb24gUnIoYSwgaSwgcywgdSwgdikge1xuICBsZXQgZiA9IHVlKGEpLnN0YXJ0T2Yocyk7XG4gIGlmICh1W3NdICYmIHVbc10gPiAxKSB7XG4gICAgY29uc3QgbSA9IGYuZ2V0KHMpO1xuICAgIGYgPSBmLnNldChzLCBtIC0gbSAlIHVbc10pO1xuICB9XG4gIGZvciAoOyBmLnZhbHVlT2YoKSA8IGk7ICkge1xuICAgIGxldCBtID0gdWUoZikuYWRkKHVbc10gfHwgMSwgcykuc3RhcnRPZihzKTtcbiAgICBtLnZhbHVlT2YoKSA8PSBmLnZhbHVlT2YoKSAmJiAobSA9IG0uYWRkKHVbc10gfHwgMSwgcykpLCB2KGYsIG0pLCBmID0gbTtcbiAgfVxufVxuY29uc3QgU3IgPSAxNztcbmZ1bmN0aW9uIHh0KGEsIGksIHMpIHtcbiAgY29uc3QgdSA9IHtcbiAgICBzZWNvbmQ6IDFlMyxcbiAgICBtaW51dGU6IDYwLFxuICAgIGhvdXI6IDYwLFxuICAgIGRheTogMjQsXG4gICAgbW9udGg6IDMwLFxuICAgIHllYXI6IDEyXG4gIH07XG4gIGxldCB2ID0gXCJ5ZWFyXCIsIGYgPSBhO1xuICByZXR1cm4gT2JqZWN0LmtleXModSkuc29tZSgobSkgPT4ge1xuICAgIGNvbnN0IHkgPSBtO1xuICAgIGYgPSBmIC8gdVt5XTtcbiAgICBjb25zdCBTID0gZiAvIHNbeV0sIEMgPSBzW3ldICYmIHNbeV0gPiAxID8gMyAqIFNyIDogU3IsIEQgPSBpIC8gQztcbiAgICBpZiAoUyA8IEQpXG4gICAgICByZXR1cm4gdiA9IG0sICEwO1xuICB9KSwgdjtcbn1cbmNvbnN0IE9yID0ge1xuICBzZWNvbmQ6IFwibWludXRlXCIsXG4gIG1pbnV0ZTogXCJob3VyXCIsXG4gIGhvdXI6IFwiZGF5XCIsXG4gIGRheTogXCJtb250aFwiLFxuICBtb250aDogXCJ5ZWFyXCIsXG4gIHllYXI6IFwieWVhclwiXG59O1xuZnVuY3Rpb24gRHIoYSkge1xuICBpZiAoIU9yW2FdKVxuICAgIHRocm93IG5ldyBFcnJvcihgdW5pdCAke2F9IGlzIG5vdCBhY2NlcHRhYmxlYCk7XG4gIHJldHVybiBPclthXTtcbn1cbmZ1bmN0aW9uIEhpKHsgaXRlbVRpbWVTdGFydDogYSwgaXRlbVRpbWVFbmQ6IGksIGRyYWdUaW1lOiBzLCBpc0RyYWdnaW5nOiB1LCBpc1Jlc2l6aW5nOiB2LCByZXNpemluZ0VkZ2U6IGYsIHJlc2l6ZVRpbWU6IG0gfSkge1xuICBjb25zdCB5ID0gaSAtIGE7XG4gIHJldHVybiBbXG4gICAgdSAmJiBzID8gcyA6IHYgJiYgZiA9PT0gXCJsZWZ0XCIgJiYgbSA/IG0gOiBhLFxuICAgIHUgJiYgcyA/IHMgKyB5IDogdiAmJiBmID09PSBcInJpZ2h0XCIgJiYgbSA/IG0gOiBpXG4gIF07XG59XG5mdW5jdGlvbiBXaSh7IGl0ZW1UaW1lU3RhcnQ6IGEsIGl0ZW1UaW1lRW5kOiBpLCBjYW52YXNUaW1lU3RhcnQ6IHMsIGNhbnZhc1RpbWVFbmQ6IHUsIGNhbnZhc1dpZHRoOiB2IH0pIHtcbiAgY29uc3QgZiA9IGkgLSBhLCBtID0gTWF0aC5tYXgoYSwgcyksIHkgPSBNYXRoLm1pbihpLCB1KSwgUyA9IFJ0KHMsIHUsIHYsIG0pLCBEID0gUnQocywgdSwgdiwgeSkgLSBTO1xuICByZXR1cm4ge1xuICAgIGxlZnQ6IFMsXG4gICAgd2lkdGg6IE1hdGgubWF4KEQsIDMpLFxuICAgIGNvbGxpc2lvbkxlZnQ6IGEsXG4gICAgY29sbGlzaW9uV2lkdGg6IGZcbiAgfTtcbn1cbmZ1bmN0aW9uIGtyKGEsIGkpIHtcbiAgY29uc3QgeyBncm91cElkS2V5OiBzIH0gPSBpLCB1ID0ge307XG4gIGZvciAobGV0IHYgPSAwOyB2IDwgYS5sZW5ndGg7IHYrKylcbiAgICB1W1koYVt2XSwgcyldID0ge1xuICAgICAgaW5kZXg6IHYsXG4gICAgICBncm91cDogYVt2XVxuICAgIH07XG4gIHJldHVybiB1O1xufVxuZnVuY3Rpb24gRmkoYSwgaSkge1xuICB2YXIgdiwgZjtcbiAgY29uc3QgcyA9IHt9LCB1ID0gT2JqZWN0LmtleXMoaSk7XG4gIGZvciAobGV0IG0gPSAwOyBtIDwgdS5sZW5ndGg7IG0rKykge1xuICAgIGNvbnN0IHkgPSBpW3VbbV1dO1xuICAgIHNbbV0gPSB7XG4gICAgICBpbmRleDogeS5pbmRleCxcbiAgICAgIGdyb3VwOiB5Lmdyb3VwLFxuICAgICAgaXRlbXM6IFtdXG4gICAgfTtcbiAgfVxuICBmb3IgKGxldCBtID0gMDsgbSA8IGEubGVuZ3RoOyBtKyspXG4gICAgaWYgKGFbbV0uZGltZW5zaW9ucyAhPT0gdm9pZCAwICYmICgodiA9IGFbbV0uZGltZW5zaW9ucykgPT0gbnVsbCA/IHZvaWQgMCA6IHYub3JkZXIpICE9PSB2b2lkIDApIHtcbiAgICAgIGNvbnN0IHkgPSBzWygoZiA9IGFbbV0uZGltZW5zaW9ucykgPT0gbnVsbCA/IHZvaWQgMCA6IGYub3JkZXIuaW5kZXgpID8/IDBdO1xuICAgICAgeSAmJiB5Lml0ZW1zLnB1c2goYVttXSk7XG4gICAgfVxuICByZXR1cm4gcztcbn1cbmZ1bmN0aW9uIHpyKGEsIGksIHMsIHUpIHtcbiAgY29uc3QgeyBpdGVtVGltZVN0YXJ0S2V5OiB2LCBpdGVtVGltZUVuZEtleTogZiB9ID0gdTtcbiAgcmV0dXJuIGEuZmlsdGVyKChtKSA9PiB7XG4gICAgY29uc3QgeSA9IHVlKFkobSwgdikpLnZhbHVlT2YoKSA8PSBzLCBTID0gdWUoWShtLCBmKSkudmFsdWVPZigpID49IGk7XG4gICAgcmV0dXJuIHkgJiYgUztcbiAgfSk7XG59XG5jb25zdCBKaCA9IDFlLTM7XG5mdW5jdGlvbiBVaShhLCBpLCBzLCB1ID0gSmgpIHtcbiAgcmV0dXJuIGEuY29sbGlzaW9uTGVmdCArIHUgPCBpLmNvbGxpc2lvbkxlZnQgKyBpLmNvbGxpc2lvbldpZHRoICYmIGEuY29sbGlzaW9uTGVmdCArIGEuY29sbGlzaW9uV2lkdGggLSB1ID4gaS5jb2xsaXNpb25MZWZ0ICYmIGEudG9wIC0gcyArIHUgPCBpLnRvcCArIGkuaGVpZ2h0ICYmIGEudG9wICsgYS5oZWlnaHQgKyBzIC0gdSA+IGkudG9wO1xufVxuZnVuY3Rpb24gTmkoYSwgaSwgcywgdSwgdiwgZiwgbSkge1xuICBsZXQgeSA9IHU7XG4gIGNvbnN0IFMgPSBtID8/IChhIC0gaS5kaW1lbnNpb25zLmhlaWdodCkgLyAyO1xuICBpZiAoaS5kaW1lbnNpb25zLnN0YWNrICYmIGkuZGltZW5zaW9ucy50b3AgPT09IG51bGwpIHtcbiAgICBpLmRpbWVuc2lvbnMudG9wID0gdiArIFMsIHkgPSBNYXRoLm1heCh5LCBhLCBpLmRpbWVuc2lvbnMuaGVpZ2h0ICsgUyAqIDIpO1xuICAgIGRvIHtcbiAgICAgIHZhciBDID0gbnVsbDtcbiAgICAgIGZvciAobGV0IEQgPSBmIC0gMSwgUiA9IDA7IEQgPj0gUjsgRC0tKSB7XG4gICAgICAgIGNvbnN0IFQgPSBzW0RdO1xuICAgICAgICBpZiAoVC5kaW1lbnNpb25zLnRvcCAhPT0gbnVsbCAmJiBULmRpbWVuc2lvbnMuc3RhY2sgJiYgVWkoaS5kaW1lbnNpb25zLCBULmRpbWVuc2lvbnMsIFMpKSB7XG4gICAgICAgICAgQyA9IFQ7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIEMgIT0gbnVsbCAmJiAoaS5kaW1lbnNpb25zLnRvcCA9IEMuZGltZW5zaW9ucy50b3AgKyBDLmRpbWVuc2lvbnMuaGVpZ2h0ICsgLyogYmFja3dhcmQgY29tcGF0aWJpbGl0eSB3aGVyZSBnYXAgYmV0d2VlbiBpdGVtcyBpcyAyICovXG4gICAgICBTICogKG0gIT09IHZvaWQgMCA/IDEgOiAyKSwgeSA9IE1hdGgubWF4KHksIGkuZGltZW5zaW9ucy50b3AgKyBpLmRpbWVuc2lvbnMuaGVpZ2h0ICsgUyAtIHYpKTtcbiAgICB9IHdoaWxlIChDKTtcbiAgfVxuICByZXR1cm4ge1xuICAgIGdyb3VwSGVpZ2h0OiB5LFxuICAgIHZlcnRpY2FsTWFyZ2luOiBTLFxuICAgIGl0ZW1Ub3A6IGkuZGltZW5zaW9ucy50b3BcbiAgfTtcbn1cbmZ1bmN0aW9uIEdpKGEsIGksIHMsIHUsIHYpIHtcbiAgdmFyIG0sIHk7XG4gIGNvbnN0IGYgPSB2ID8/IChhIC0gKCgobSA9IGkuZGltZW5zaW9ucykgPT0gbnVsbCA/IHZvaWQgMCA6IG0uaGVpZ2h0KSA/PyAxKSkgLyAyO1xuICByZXR1cm4gaS5kaW1lbnNpb25zICYmIGkuZGltZW5zaW9ucy50b3AgPT09IG51bGwgJiYgKGkuZGltZW5zaW9ucy50b3AgPSB1ICsgZiwgcyA9IE1hdGgubWF4KHMsIGEsIGkuZGltZW5zaW9ucy5oZWlnaHQgKyBmKSksIHsgZ3JvdXBIZWlnaHQ6IHMsIHZlcnRpY2FsTWFyZ2luOiAwLCBpdGVtVG9wOiAoKHkgPSBpLmRpbWVuc2lvbnMpID09IG51bGwgPyB2b2lkIDAgOiB5LnRvcCkgPz8gMCB9O1xufVxuZnVuY3Rpb24gZGkoYSA9IFtdKSB7XG4gIHJldHVybiBhLnJlZHVjZSgoaSwgcykgPT4gaSArIHMsIDApO1xufVxuZnVuY3Rpb24gWWkoYSwgaSwgcywgdSwgdikge1xuICBjb25zdCBmID0gW10sIG0gPSBbXSwgeSA9IEZpKGEsIGkpO1xuICBmb3IgKGNvbnN0IFMgaW4geSkge1xuICAgIGNvbnN0IEMgPSB5W1NdLCB7IGl0ZW1zOiBELCBncm91cDogUiB9ID0gQywgVCA9IGRpKGYpLCBQID0gUi5zdGFja0l0ZW1zICE9PSB2b2lkIDAgPyBSLnN0YWNrSXRlbXMgOiB1LCB7IGdyb3VwSGVpZ2h0OiBfIH0gPSBLaShELCBQLCBzLCBULCB2KTtcbiAgICBtLnB1c2goVCksIFIuaGVpZ2h0ID8gZi5wdXNoKFIuaGVpZ2h0KSA6IGYucHVzaChNYXRoLm1heChfLCBzKSk7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBoZWlnaHQ6IGRpKGYpLFxuICAgIGdyb3VwSGVpZ2h0czogZixcbiAgICBncm91cFRvcHM6IG1cbiAgfTtcbn1cbmZ1bmN0aW9uIEtpKGEsIGksIHMsIHUsIHYpIHtcbiAgbGV0IGYgPSAwLCBtID0gMDtcbiAgZm9yIChsZXQgeSA9IDA7IHkgPCBhLmxlbmd0aDsgeSsrKSB7XG4gICAgY29uc3QgUyA9IGkgPyBOaShzLCBhW3ldLCBhLCBmLCB1LCB5LCB2KSA6IEdpKHMsIGFbeV0sIGYsIHUsIHYpO1xuICAgIGYgPSBTLmdyb3VwSGVpZ2h0LCBtID0gUy52ZXJ0aWNhbE1hcmdpbjtcbiAgfVxuICByZXR1cm4geyBncm91cEhlaWdodDogZiwgdmVydGljYWxNYXJnaW46IG0gfTtcbn1cbmZ1bmN0aW9uICRlKGEsIGksIHMsIHUsIHYsIGYsIG0sIHksIFMsIEMsIEQsIFIsIFQsIFAsIF8sIE8pIHtcbiAgY29uc3QgTCA9IHpyKGEsIHUsIHYsIGYpLm1hcCgodykgPT4gQmkoe1xuICAgIGl0ZW06IHcsXG4gICAga2V5czogZixcbiAgICBkcmFnZ2luZ0l0ZW06IEMsXG4gICAgcmVzaXppbmdJdGVtOiBELFxuICAgIGRyYWdUaW1lOiBSLFxuICAgIHJlc2l6aW5nRWRnZTogVCxcbiAgICByZXNpemVUaW1lOiBQLFxuICAgIGdyb3VwczogaSxcbiAgICBuZXdHcm91cE9yZGVyOiBfXG4gIH0pKTtcbiAgaWYgKGkubGVuZ3RoID09PSAwKVxuICAgIHJldHVybiB7XG4gICAgICBkaW1lbnNpb25JdGVtczogW10sXG4gICAgICBoZWlnaHQ6IDAsXG4gICAgICBncm91cEhlaWdodHM6IFtdLFxuICAgICAgZ3JvdXBUb3BzOiBbXVxuICAgIH07XG4gIGNvbnN0IEggPSBrcihpLCBmKSwgWCA9IEwubWFwKCh3KSA9PiBYaSh7XG4gICAgaXRlbTogdyxcbiAgICBrZXlzOiBmLFxuICAgIGNhbnZhc1RpbWVTdGFydDogdSxcbiAgICBjYW52YXNUaW1lRW5kOiB2LFxuICAgIGNhbnZhc1dpZHRoOiBzLFxuICAgIGdyb3VwT3JkZXJzOiBILFxuICAgIGxpbmVIZWlnaHQ6IG0sXG4gICAgaXRlbUhlaWdodFJhdGlvOiB5LFxuICAgIGl0ZW1WZXJ0aWNhbEdhcDogT1xuICB9KSkuZmlsdGVyKCh3KSA9PiAhIXcpLCB7IGhlaWdodDogQiwgZ3JvdXBIZWlnaHRzOiBWLCBncm91cFRvcHM6IGxlIH0gPSBZaShYLCBILCBtLCBTLCBPKTtcbiAgcmV0dXJuIHsgZGltZW5zaW9uSXRlbXM6IFgsIGhlaWdodDogQiwgZ3JvdXBIZWlnaHRzOiBWLCBncm91cFRvcHM6IGxlIH07XG59XG5mdW5jdGlvbiB2ZShhLCBpKSB7XG4gIHJldHVybiBhICogaTtcbn1cbmZ1bmN0aW9uIFhpKHsgaXRlbTogYSwga2V5czogaSwgY2FudmFzVGltZVN0YXJ0OiBzLCBjYW52YXNUaW1lRW5kOiB1LCBjYW52YXNXaWR0aDogdiwgZ3JvdXBPcmRlcnM6IGYsIGxpbmVIZWlnaHQ6IG0sIGl0ZW1IZWlnaHRSYXRpbzogeSwgaXRlbVZlcnRpY2FsR2FwOiBTIH0pIHtcbiAgY29uc3QgQyA9IFkoYSwgaS5pdGVtSWRLZXkpLCBEID0gV2koe1xuICAgIGl0ZW1UaW1lU3RhcnQ6IFkoYSwgaS5pdGVtVGltZVN0YXJ0S2V5KSxcbiAgICBpdGVtVGltZUVuZDogWShhLCBpLml0ZW1UaW1lRW5kS2V5KSxcbiAgICBjYW52YXNUaW1lU3RhcnQ6IHMsXG4gICAgY2FudmFzVGltZUVuZDogdSxcbiAgICBjYW52YXNXaWR0aDogdlxuICB9KTtcbiAgaWYgKEQpXG4gICAgcmV0dXJuIEQudG9wID0gbnVsbCwgRC5vcmRlciA9IGZbWShhLCBpLml0ZW1Hcm91cEtleSldLCBELnN0YWNrID0gIWEuaXNPdmVybGF5LCBELmhlaWdodCA9IChhLmhlaWdodCB8fCBtKSAqICh0eXBlb2YgUyA+IFwidVwiID8geSA6IDEpLCB7XG4gICAgICBpZDogQyxcbiAgICAgIGRpbWVuc2lvbnM6IERcbiAgICB9O1xufVxuZnVuY3Rpb24gQmkoeyBpdGVtOiBhLCBrZXlzOiBpLCBkcmFnZ2luZ0l0ZW06IHMsIHJlc2l6aW5nSXRlbTogdSwgZHJhZ1RpbWU6IHYsIHJlc2l6aW5nRWRnZTogZiwgcmVzaXplVGltZTogbSwgZ3JvdXBzOiB5LCBuZXdHcm91cE9yZGVyOiBTIH0pIHtcbiAgaWYgKCF1ICYmICFzKVxuICAgIHJldHVybiBhO1xuICBjb25zdCBDID0gWShhLCBpLml0ZW1JZEtleSksIEQgPSBDID09PSBzLCBSID0gQyA9PT0gdSwgW1QsIFBdID0gSGkoe1xuICAgIGl0ZW1UaW1lU3RhcnQ6IFkoYSwgaS5pdGVtVGltZVN0YXJ0S2V5KSxcbiAgICBpdGVtVGltZUVuZDogWShhLCBpLml0ZW1UaW1lRW5kS2V5KSxcbiAgICBpc0RyYWdnaW5nOiBELFxuICAgIGlzUmVzaXppbmc6IFIsXG4gICAgZHJhZ1RpbWU6IHYsXG4gICAgcmVzaXppbmdFZGdlOiBmLFxuICAgIHJlc2l6ZVRpbWU6IG1cbiAgfSk7XG4gIHJldHVybiB7XG4gICAgLi4uYSxcbiAgICBbaS5pdGVtVGltZVN0YXJ0S2V5XTogVCxcbiAgICBbaS5pdGVtVGltZUVuZEtleV06IFAsXG4gICAgW2kuaXRlbUdyb3VwS2V5XTogRCA/IFkoeVtTXSwgaS5ncm91cElkS2V5KSA6IFkoYSwgaS5pdGVtR3JvdXBLZXkpXG4gIH07XG59XG5mdW5jdGlvbiAkcihhLCBpLCBzKSB7XG4gIGNvbnN0IHUgPSBpIC0gYSwgdiA9IGEgLSB1ICogKHMgLSAxKSAvIDIsIGYgPSB2ICsgdSAqIHM7XG4gIHJldHVybiBbdiwgZl07XG59XG5mdW5jdGlvbiBDcihhLCBpLCBzLCB1LCB2LCBmLCBtKSB7XG4gIGNvbnN0IHkgPSBmLmJ1ZmZlciwgUyA9IG0uY2FudmFzVGltZVN0YXJ0LCBDID0gbS5jYW52YXNUaW1lRW5kLCBEID0gbS52aXNpYmxlVGltZUVuZCAtIG0udmlzaWJsZVRpbWVTdGFydCwgUiA9IGkgLSBhLCBUID0ge1xuICAgIC4uLm0sXG4gICAgdmlzaWJsZVRpbWVTdGFydDogYSxcbiAgICB2aXNpYmxlVGltZUVuZDogaVxuICB9LCBQID0gRCAqICh5IC0gMSkgKiAwLjI1O1xuICBpZiAoUiAhPT0gRCB8fCBhIDw9IFMgKyBQIHx8IGkgPj0gQyAtIFAgfHwgcykge1xuICAgIGNvbnN0IFtPLCBrXSA9ICRyKGEsIGksIHkpO1xuICAgIFQuY2FudmFzVGltZVN0YXJ0ID0gTywgVC5jYW52YXNUaW1lRW5kID0gaztcbiAgICBjb25zdCBMID0ge1xuICAgICAgLi4ubSxcbiAgICAgIC4uLlRcbiAgICB9LCBIID0gdmUoTC53aWR0aCwgZi5idWZmZXIpO1xuICAgIE9iamVjdC5hc3NpZ24oVCwgJGUodSwgdiwgSCwgTC5jYW52YXNUaW1lU3RhcnQsIEwuY2FudmFzVGltZUVuZCwgZi5rZXlzLCBmLmxpbmVIZWlnaHQsIGYuaXRlbUhlaWdodFJhdGlvLCBmLnN0YWNrSXRlbXMsIEwuZHJhZ2dpbmdJdGVtLCBMLnJlc2l6aW5nSXRlbSwgTC5kcmFnVGltZSwgTC5yZXNpemluZ0VkZ2UsIEwucmVzaXplVGltZSwgTC5uZXdHcm91cE9yZGVyLCBmLml0ZW1WZXJ0aWNhbEdhcCkpO1xuICB9XG4gIHJldHVybiBUO1xufVxuY29uc3QgbWYgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmZyZWV6ZSgvKiBAX19QVVJFX18gKi8gT2JqZWN0LmRlZmluZVByb3BlcnR5KHtcbiAgX19wcm90b19fOiBudWxsLFxuICBORVhUX1VOSVRTOiBPcixcbiAgY2FsY3VsYXRlRGltZW5zaW9uczogV2ksXG4gIGNhbGN1bGF0ZUludGVyYWN0aW9uTmV3VGltZXM6IEhpLFxuICBjYWxjdWxhdGVTY3JvbGxDYW52YXM6IENyLFxuICBjYWxjdWxhdGVUaW1lRm9yWFBvc2l0aW9uOiBNcixcbiAgY2FsY3VsYXRlWFBvc2l0aW9uRm9yVGltZTogUnQsXG4gIGNvbGxpc2lvbjogVWksXG4gIGNvb3JkaW5hdGVUb1RpbWVSYXRpbzogTXQsXG4gIGdldENhbnZhc0JvdW5kYXJpZXNGcm9tVmlzaWJsZVRpbWU6ICRyLFxuICBnZXRDYW52YXNXaWR0aDogdmUsXG4gIGdldEdyb3VwT3JkZXJzOiBrcixcbiAgZ2V0R3JvdXBlZEl0ZW1zOiBGaSxcbiAgZ2V0SXRlbURpbWVuc2lvbnM6IFhpLFxuICBnZXRJdGVtV2l0aEludGVyYWN0aW9uczogQmksXG4gIGdldE1pblVuaXQ6IHh0LFxuICBnZXROZXh0VW5pdDogRHIsXG4gIGdldFZpc2libGVJdGVtczogenIsXG4gIGdyb3VwTm9TdGFjazogR2ksXG4gIGdyb3VwU3RhY2s6IE5pLFxuICBpdGVyYXRlVGltZXM6IFJyLFxuICBtaW5DZWxsV2lkdGg6IFNyLFxuICBzdGFja0FsbDogWWksXG4gIHN0YWNrR3JvdXA6IEtpLFxuICBzdGFja1RpbWVsaW5lSXRlbXM6ICRlXG59LCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6IFwiTW9kdWxlXCIgfSkpLCBRaCA9IHtcbiAgZm9udFNpemU6IDEyLFxuICBjb2xvcjogXCJ3aGl0ZVwiLFxuICBjdXJzb3I6IFwicG9pbnRlclwiLFxuICBiYWNrZ3JvdW5kOiBcIiMyMTk2ZjNcIixcbiAgYm9yZGVyVG9wV2lkdGg6IFwiMXB4XCIsXG4gIGJvcmRlckJvdHRvbVdpZHRoOiBcIjFweFwiLFxuICBib3JkZXJMZWZ0V2lkdGg6IFwiMXB4XCIsXG4gIGJvcmRlclJpZ2h0V2lkdGg6IFwiMXB4XCIsXG4gIGJvcmRlclN0eWxlOiBcInNvbGlkXCIsXG4gIGJvcmRlckNvbG9yOiBcIiMxYTZmYjNcIixcbiAgekluZGV4OiA4MFxufSwgZWQgPSB7XG4gIGJhY2tncm91bmQ6IFwiI2ZmYzEwN1wiLFxuICBib3JkZXJUb3BXaWR0aDogXCIxcHhcIixcbiAgYm9yZGVyTGVmdFdpZHRoOiBcIjFweFwiLFxuICBib3JkZXJSaWdodFdpZHRoOiBcIjFweFwiLFxuICBib3JkZXJCb3R0b21XaWR0aDogXCIxcHhcIixcbiAgYm9yZGVyU3R5bGU6IFwic29saWRcIixcbiAgYm9yZGVyQ29sb3I6IFwiI2ZmOTgwMFwiLFxuICB6SW5kZXg6IDgyXG59LCB0ZCA9IHtcbiAgd2lsbENoYW5nZTogXCJsZWZ0LCB0b3AsIHdpZHRoXCIsXG4gIGN1cnNvcjogXCJtb3ZlXCJcbn0sIHJkID0ge1xuICBib3JkZXJMZWZ0V2lkdGg6IDNcbn0sIG5kID0ge1xuICBjdXJzb3I6IFwidy1yZXNpemVcIlxufSwgaWQgPSB7XG4gIGJvcmRlclJpZ2h0V2lkdGg6IFwiM3B4XCJcbn0sIG9kID0ge1xuICBjdXJzb3I6IFwiZS1yZXNpemVcIlxufSwgc2QgPSB7XG4gIHBvc2l0aW9uOiBcImFic29sdXRlXCIsXG4gIHdpZHRoOiAyNCxcbiAgbWF4V2lkdGg6IFwiMjAlXCIsXG4gIG1pbldpZHRoOiAyLFxuICBoZWlnaHQ6IFwiMTAwJVwiLFxuICB0b3A6IDAsXG4gIGxlZnQ6IDAsXG4gIGN1cnNvcjogXCJwb2ludGVyXCIsXG4gIHpJbmRleDogODhcbn0sIGFkID0ge1xuICBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLFxuICB3aWR0aDogMjQsXG4gIG1heFdpZHRoOiBcIjIwJVwiLFxuICBtaW5XaWR0aDogMixcbiAgaGVpZ2h0OiBcIjEwMCVcIixcbiAgdG9wOiAwLFxuICByaWdodDogMCxcbiAgY3Vyc29yOiBcInBvaW50ZXJcIixcbiAgekluZGV4OiA4OFxufSwgbGQgPSB7XG4gIGdldFRpbWVsaW5lU3RhdGU6ICgpID0+IChjb25zb2xlLndhcm4oJ1wiZ2V0VGltZWxpbmVTdGF0ZVwiIGRlZmF1bHQgZnVuYyBpcyBiZWluZyB1c2VkJyksIHt9KSxcbiAgZ2V0TGVmdE9mZnNldEZyb21EYXRlOiAoKSA9PiAoY29uc29sZS53YXJuKCdcImdldExlZnRPZmZzZXRGcm9tRGF0ZVwiIGRlZmF1bHQgZnVuYyBpcyBiZWluZyB1c2VkJyksIDApLFxuICBnZXREYXRlRnJvbUxlZnRPZmZzZXRQb3NpdGlvbjogKCkgPT4gKGNvbnNvbGUud2FybignXCJnZXREYXRlRnJvbUxlZnRPZmZzZXRQb3NpdGlvblwiIGRlZmF1bHQgZnVuYyBpcyBiZWluZyB1c2VkJyksIDApLFxuICBzaG93UGVyaW9kOiAoKSA9PiB7XG4gICAgY29uc29sZS53YXJuKCdcInNob3dQZXJpb2RcIiBkZWZhdWx0IGZ1bmMgaXMgYmVpbmcgdXNlZCcpO1xuICB9XG59LCBqciA9IFouY3JlYXRlQ29udGV4dChsZCksIHsgQ29uc3VtZXI6IGNkLCBQcm92aWRlcjogdWQgfSA9IGpyO1xuY2xhc3MgcGQgZXh0ZW5kcyBaLkNvbXBvbmVudCB7XG4gIGNvbnN0cnVjdG9yKGkpIHtcbiAgICBzdXBlcihpKSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwiZ2V0VGltZWxpbmVTdGF0ZVwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKCkgPT4ge1xuICAgICAgICBjb25zdCB7IHZpc2libGVUaW1lU3RhcnQ6IHMsIHZpc2libGVUaW1lRW5kOiB1LCBjYW52YXNUaW1lU3RhcnQ6IHYsIGNhbnZhc1RpbWVFbmQ6IGYsIGNhbnZhc1dpZHRoOiBtLCB0aW1lbGluZVVuaXQ6IHksIHRpbWVsaW5lV2lkdGg6IFMgfSA9IHRoaXMucHJvcHM7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgdmlzaWJsZVRpbWVTdGFydDogcyxcbiAgICAgICAgICB2aXNpYmxlVGltZUVuZDogdSxcbiAgICAgICAgICBjYW52YXNUaW1lU3RhcnQ6IHYsXG4gICAgICAgICAgY2FudmFzVGltZUVuZDogZixcbiAgICAgICAgICBjYW52YXNXaWR0aDogbSxcbiAgICAgICAgICB0aW1lbGluZVVuaXQ6IHksXG4gICAgICAgICAgdGltZWxpbmVXaWR0aDogU1xuICAgICAgICB9O1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJnZXRMZWZ0T2Zmc2V0RnJvbURhdGVcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IChzKSA9PiB7XG4gICAgICAgIGNvbnN0IHsgY2FudmFzVGltZVN0YXJ0OiB1LCBjYW52YXNUaW1lRW5kOiB2LCBjYW52YXNXaWR0aDogZiB9ID0gdGhpcy5wcm9wcztcbiAgICAgICAgcmV0dXJuIFJ0KHUsIHYsIGYsIHMpO1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJnZXREYXRlRnJvbUxlZnRPZmZzZXRQb3NpdGlvblwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKHMpID0+IHtcbiAgICAgICAgY29uc3QgeyBjYW52YXNUaW1lU3RhcnQ6IHUsIGNhbnZhc1RpbWVFbmQ6IHYsIGNhbnZhc1dpZHRoOiBmIH0gPSB0aGlzLnByb3BzO1xuICAgICAgICByZXR1cm4gTXIodSwgdiwgZiwgcyk7XG4gICAgICB9XG4gICAgfSksIHRoaXMuc3RhdGUgPSB7XG4gICAgICB0aW1lbGluZUNvbnRleHQ6IHtcbiAgICAgICAgZ2V0VGltZWxpbmVTdGF0ZTogdGhpcy5nZXRUaW1lbGluZVN0YXRlLFxuICAgICAgICBnZXRMZWZ0T2Zmc2V0RnJvbURhdGU6IHRoaXMuZ2V0TGVmdE9mZnNldEZyb21EYXRlLFxuICAgICAgICBnZXREYXRlRnJvbUxlZnRPZmZzZXRQb3NpdGlvbjogdGhpcy5nZXREYXRlRnJvbUxlZnRPZmZzZXRQb3NpdGlvbixcbiAgICAgICAgc2hvd1BlcmlvZDogdGhpcy5wcm9wcy5zaG93UGVyaW9kXG4gICAgICB9XG4gICAgfTtcbiAgfVxuICByZW5kZXIoKSB7XG4gICAgcmV0dXJuIGoodWQsIHsgdmFsdWU6IHRoaXMuc3RhdGUudGltZWxpbmVDb250ZXh0LCBjaGlsZHJlbjogdGhpcy5wcm9wcy5jaGlsZHJlbiB9KTtcbiAgfVxufVxuY29uc3QgTHQgPSBjZCwgaGQgPSAoKSA9PiB3aShqcik7XG51ZS5leHRlbmQoU3MpO1xuY2xhc3MgQXIgZXh0ZW5kcyBhZSB7XG4gIGNvbnN0cnVjdG9yKGkpIHtcbiAgICBzdXBlcihpKSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwic3RhdGVcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IHtcbiAgICAgICAgaW50ZXJhY3RNb3VudGVkOiAhMSxcbiAgICAgICAgZHJhZ2dpbmc6ICExLFxuICAgICAgICBkcmFnU3RhcnQ6IG51bGwsXG4gICAgICAgIHByZURyYWdQb3NpdGlvbjogbnVsbCxcbiAgICAgICAgZHJhZ1RpbWU6IG51bGwsXG4gICAgICAgIGRyYWdHcm91cERlbHRhOiBudWxsLFxuICAgICAgICByZXNpemluZzogITEsXG4gICAgICAgIHJlc2l6ZUVkZ2U6IG51bGwsXG4gICAgICAgIHJlc2l6ZVN0YXJ0OiBudWxsLFxuICAgICAgICByZXNpemVUaW1lOiBudWxsXG4gICAgICB9XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcIml0ZW1JZFwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogXCJcIlxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJpdGVtVGl0bGVcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IFwiXCJcbiAgICB9KSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwiaXRlbURpdlRpdGxlXCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiB2b2lkIDBcbiAgICB9KSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwiaXRlbVRpbWVTdGFydFwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogdm9pZCAwXG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcIml0ZW1UaW1lRW5kXCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiB2b2lkIDBcbiAgICB9KSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwiaXRlbVJlZlwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogeGkoKVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJkcmFnTGVmdFwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogdm9pZCAwXG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImRyYWdSaWdodFwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogdm9pZCAwXG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcInN0YXJ0ZWRDbGlja2luZ1wiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogITFcbiAgICB9KSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwic3RhcnRlZFRvdWNoaW5nXCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiAhMVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJkcmFnSW5Qcm9ncmVzc1wiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogITFcbiAgICB9KSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwiZmlyZUludGVyYWN0RXZlbnRcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IChzKSA9PiB7XG4gICAgICAgIHZhciB1O1xuICAgICAgICBpZiAodGhpcy5pdGVtUmVmICYmIHRoaXMuaXRlbVJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgY29uc3QgdiA9IG5ldyBDdXN0b21FdmVudChcIml0ZW1JbnRlcmFjdGlvblwiLCB7XG4gICAgICAgICAgICBidWJibGVzOiAhMCxcbiAgICAgICAgICAgIGRldGFpbDoge1xuICAgICAgICAgICAgICBpdGVtSW50ZXJhY3Rpb246IHNcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcbiAgICAgICAgICAodSA9IHRoaXMuaXRlbVJlZi5jdXJyZW50KSA9PSBudWxsIHx8IHUuZGlzcGF0Y2hFdmVudCh2KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJvbk1vdXNlRG93blwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKHMpID0+IHtcbiAgICAgICAgdGhpcy5zdGF0ZS5pbnRlcmFjdE1vdW50ZWQgfHwgKHMucHJldmVudERlZmF1bHQoKSwgdGhpcy5zdGFydGVkQ2xpY2tpbmcgPSAhMCk7XG4gICAgICB9XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcIm9uTW91c2VVcFwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKHMpID0+IHtcbiAgICAgICAgIXRoaXMuc3RhdGUuaW50ZXJhY3RNb3VudGVkICYmIHRoaXMuc3RhcnRlZENsaWNraW5nICYmICh0aGlzLnN0YXJ0ZWRDbGlja2luZyA9ICExLCB0aGlzLmFjdHVhbENsaWNrKHMsIFwiY2xpY2tcIikpO1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJvblRvdWNoU3RhcnRcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IChzKSA9PiB7XG4gICAgICAgIHRoaXMuc3RhdGUuaW50ZXJhY3RNb3VudGVkIHx8IChzLnByZXZlbnREZWZhdWx0KCksIHRoaXMuc3RhcnRlZFRvdWNoaW5nID0gITApO1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJvblRvdWNoRW5kXCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiAocykgPT4ge1xuICAgICAgICAhdGhpcy5zdGF0ZS5pbnRlcmFjdE1vdW50ZWQgJiYgdGhpcy5zdGFydGVkVG91Y2hpbmcgJiYgKHRoaXMuc3RhcnRlZFRvdWNoaW5nID0gITEsIHRoaXMuYWN0dWFsQ2xpY2socywgXCJ0b3VjaFwiKSk7XG4gICAgICB9XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImhhbmRsZURvdWJsZUNsaWNrXCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiAocykgPT4ge1xuICAgICAgICBzLnN0b3BQcm9wYWdhdGlvbigpLCB0aGlzLnByb3BzLm9uSXRlbURvdWJsZUNsaWNrICYmIHRoaXMucHJvcHMub25JdGVtRG91YmxlQ2xpY2sodGhpcy5pdGVtSWQsIHMpO1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJoYW5kbGVDb250ZXh0TWVudVwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKHMpID0+IHtcbiAgICAgICAgdGhpcy5wcm9wcy5vbkNvbnRleHRNZW51ICYmIChzLnByZXZlbnREZWZhdWx0KCksIHMuc3RvcFByb3BhZ2F0aW9uKCksIHRoaXMucHJvcHMub25Db250ZXh0TWVudSh0aGlzLml0ZW1JZCwgcykpO1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJnZXREcmFnTGVmdFJlZlwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKHMpID0+IHRoaXMuZHJhZ0xlZnQgPSBzXG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImdldERyYWdSaWdodFJlZlwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKHMpID0+IHRoaXMuZHJhZ1JpZ2h0ID0gc1xuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJnZXRJdGVtUHJvcHNcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IChzID0ge30pID0+IHtcbiAgICAgICAgY29uc3QgdSA9IFwicmN0LWl0ZW1cIiArICh0aGlzLnByb3BzLml0ZW0uY2xhc3NOYW1lID8gYCAke3RoaXMucHJvcHMuaXRlbS5jbGFzc05hbWV9YCA6IFwiXCIpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIGtleTogdGhpcy5pdGVtSWQsXG4gICAgICAgICAgcmVmOiB0aGlzLml0ZW1SZWYsXG4gICAgICAgICAgdGl0bGU6IHRoaXMuaXRlbURpdlRpdGxlLFxuICAgICAgICAgIGNsYXNzTmFtZTogdSArIGAgJHtzLmNsYXNzTmFtZSA/IHMuY2xhc3NOYW1lIDogXCJcIn1gLFxuICAgICAgICAgIG9uTW91c2VEb3duOiBQZSh0aGlzLm9uTW91c2VEb3duLCBzLm9uTW91c2VEb3duKSxcbiAgICAgICAgICBvbk1vdXNlVXA6IFBlKHRoaXMub25Nb3VzZVVwLCBzLm9uTW91c2VVcCksXG4gICAgICAgICAgb25Ub3VjaFN0YXJ0OiBQZSh0aGlzLm9uVG91Y2hTdGFydCwgcy5vblRvdWNoU3RhcnQpLFxuICAgICAgICAgIG9uVG91Y2hFbmQ6IFBlKHRoaXMub25Ub3VjaEVuZCwgcy5vblRvdWNoRW5kKSxcbiAgICAgICAgICBvbkRvdWJsZUNsaWNrOiBQZSh0aGlzLmhhbmRsZURvdWJsZUNsaWNrLCBzLm9uRG91YmxlQ2xpY2spLFxuICAgICAgICAgIG9uQ29udGV4dE1lbnU6IFBlKHRoaXMuaGFuZGxlQ29udGV4dE1lbnUsIHMub25Db250ZXh0TWVudSksXG4gICAgICAgICAgc3R5bGU6IE9iamVjdC5hc3NpZ24oe30sIHRoaXMuZ2V0SXRlbVN0eWxlKHMpKVxuICAgICAgICB9O1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJnZXRSZXNpemVQcm9wc1wiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKHMgPSB7fSkgPT4ge1xuICAgICAgICBsZXQgdSA9IFwicmN0LWl0ZW0taGFuZGxlciByY3QtaXRlbS1oYW5kbGVyLWxlZnQgcmN0LWl0ZW0taGFuZGxlci1yZXNpemUtbGVmdFwiO1xuICAgICAgICBzLmxlZnRDbGFzc05hbWUgJiYgKHUgKz0gYCAke3MubGVmdENsYXNzTmFtZX1gKTtcbiAgICAgICAgbGV0IHYgPSBcInJjdC1pdGVtLWhhbmRsZXIgcmN0LWl0ZW0taGFuZGxlci1yaWdodCByY3QtaXRlbS1oYW5kbGVyLXJlc2l6ZS1yaWdodFwiO1xuICAgICAgICByZXR1cm4gcy5yaWdodENsYXNzTmFtZSAmJiAodiArPSBgICR7cy5yaWdodENsYXNzTmFtZX1gKSwge1xuICAgICAgICAgIGxlZnQ6IHtcbiAgICAgICAgICAgIHJlZjogdGhpcy5nZXREcmFnTGVmdFJlZixcbiAgICAgICAgICAgIGNsYXNzTmFtZTogdSxcbiAgICAgICAgICAgIHN0eWxlOiBPYmplY3QuYXNzaWduKHt9LCBzZCwgcy5sZWZ0U3R5bGUpXG4gICAgICAgICAgfSxcbiAgICAgICAgICByaWdodDoge1xuICAgICAgICAgICAgcmVmOiB0aGlzLmdldERyYWdSaWdodFJlZixcbiAgICAgICAgICAgIGNsYXNzTmFtZTogdixcbiAgICAgICAgICAgIHN0eWxlOiBPYmplY3QuYXNzaWduKHt9LCBhZCwgcy5yaWdodFN0eWxlKVxuICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICB9KSwgdGhpcy5jYWNoZURhdGFGcm9tUHJvcHMoaSk7XG4gIH1cbiAgc2hvdWxkQ29tcG9uZW50VXBkYXRlKGksIHMpIHtcbiAgICByZXR1cm4gIXhyKHRoaXMucHJvcHMsIGkpIHx8ICF4cih0aGlzLnN0YXRlLCBzKTtcbiAgfVxuICBjYWNoZURhdGFGcm9tUHJvcHMoaSkge1xuICAgIHRoaXMuaXRlbUlkID0gWShpLml0ZW0sIGkua2V5cy5pdGVtSWRLZXkpLCB0aGlzLml0ZW1UaXRsZSA9IFkoaS5pdGVtLCBpLmtleXMuaXRlbVRpdGxlS2V5KSwgdGhpcy5pdGVtRGl2VGl0bGUgPSBpLmtleXMuaXRlbURpdlRpdGxlS2V5ID8gWShpLml0ZW0sIGkua2V5cy5pdGVtRGl2VGl0bGVLZXkpIDogdGhpcy5pdGVtVGl0bGUsIHRoaXMuaXRlbVRpbWVTdGFydCA9IFkoaS5pdGVtLCBpLmtleXMuaXRlbVRpbWVTdGFydEtleSksIHRoaXMuaXRlbVRpbWVFbmQgPSBZKGkuaXRlbSwgaS5rZXlzLml0ZW1UaW1lRW5kS2V5KTtcbiAgfVxuICBnZXRUaW1lUmF0aW8oKSB7XG4gICAgY29uc3QgeyBjYW52YXNUaW1lU3RhcnQ6IGksIGNhbnZhc1RpbWVFbmQ6IHMsIGNhbnZhc1dpZHRoOiB1IH0gPSB0aGlzLnByb3BzO1xuICAgIHJldHVybiBNdChpLCBzLCB1KTtcbiAgfVxuICBkcmFnVGltZVNuYXAoaSwgcykge1xuICAgIGNvbnN0IHsgZHJhZ1NuYXA6IHUgfSA9IHRoaXMucHJvcHM7XG4gICAgaWYgKHUpIHtcbiAgICAgIGNvbnN0IHYgPSBzID8gdWUoKS51dGNPZmZzZXQoKSAqIDYwICogMWUzIDogMDtcbiAgICAgIHJldHVybiBNYXRoLnJvdW5kKGkgLyB1KSAqIHUgLSB2ICUgdTtcbiAgICB9IGVsc2VcbiAgICAgIHJldHVybiBpO1xuICB9XG4gIHJlc2l6ZVRpbWVTbmFwKGkpIHtcbiAgICBjb25zdCB7IGRyYWdTbmFwOiBzIH0gPSB0aGlzLnByb3BzO1xuICAgIGlmIChzKSB7XG4gICAgICBjb25zdCB1ID0gdGhpcy5pdGVtVGltZUVuZCAlIHM7XG4gICAgICByZXR1cm4gTWF0aC5yb3VuZCgoaSAtIHUpIC8gcykgKiBzICsgdTtcbiAgICB9IGVsc2VcbiAgICAgIHJldHVybiBpO1xuICB9XG4gIGRyYWdUaW1lKGkpIHtcbiAgICBjb25zdCBzID0gdWUodGhpcy5pdGVtVGltZVN0YXJ0KTtcbiAgICByZXR1cm4gdGhpcy5zdGF0ZS5kcmFnZ2luZyA/IHRoaXMuZHJhZ1RpbWVTbmFwKHRoaXMudGltZUZvcihpKSArIHRoaXMuc3RhdGUuZHJhZ1N0YXJ0Lm9mZnNldCwgITApIDogcy52YWx1ZU9mKCk7XG4gIH1cbiAgdGltZUZvcihpKSB7XG4gICAgY29uc3QgcyA9IE10KHRoaXMucHJvcHMuY2FudmFzVGltZVN0YXJ0LCB0aGlzLnByb3BzLmNhbnZhc1RpbWVFbmQsIHRoaXMucHJvcHMuY2FudmFzV2lkdGgpLCB1ID0gQ3QodGhpcy5wcm9wcy5zY3JvbGxSZWYpLm9mZnNldExlZnQsIHYgPSBPdCh0aGlzLnByb3BzLnNjcm9sbFJlZik7XG4gICAgcmV0dXJuIChpLnBhZ2VYIC0gdSArIHYuc2Nyb2xsTGVmdCkgKiBzICsgdGhpcy5wcm9wcy5jYW52YXNUaW1lU3RhcnQ7XG4gIH1cbiAgZHJhZ0dyb3VwRGVsdGEoaSkge1xuICAgIGNvbnN0IHsgZ3JvdXBUb3BzOiBzLCBvcmRlcjogdSB9ID0gdGhpcy5wcm9wcztcbiAgICBpZiAodGhpcy5zdGF0ZS5kcmFnZ2luZykge1xuICAgICAgaWYgKCF0aGlzLnByb3BzLmNhbkNoYW5nZUdyb3VwKVxuICAgICAgICByZXR1cm4gMDtcbiAgICAgIGxldCB2ID0gMDtcbiAgICAgIGNvbnN0IGYgPSBDdCh0aGlzLnByb3BzLnNjcm9sbFJlZikub2Zmc2V0VG9wLCBtID0gT3QodGhpcy5wcm9wcy5zY3JvbGxSZWYpO1xuICAgICAgZm9yIChjb25zdCB5IG9mIE9iamVjdC5rZXlzKHMpKSB7XG4gICAgICAgIGNvbnN0IFMgPSBzW3ldO1xuICAgICAgICBpZiAoaS5wYWdlWSAtIGYgKyBtLnNjcm9sbFRvcCA+IFMpXG4gICAgICAgICAgdiA9IHBhcnNlSW50KHksIDEwKSAtIHUuaW5kZXg7XG4gICAgICAgIGVsc2VcbiAgICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIHJldHVybiB0aGlzLnByb3BzLm9yZGVyLmluZGV4ICsgdiA8IDAgPyAwIC0gdGhpcy5wcm9wcy5vcmRlci5pbmRleCA6IHY7XG4gICAgfSBlbHNlXG4gICAgICByZXR1cm4gMDtcbiAgfVxuICByZXNpemVUaW1lRGVsdGEoaSwgcykge1xuICAgIGNvbnN0IHUgPSB0aGlzLml0ZW1UaW1lRW5kIC0gdGhpcy5pdGVtVGltZVN0YXJ0LCB2ID0gdGhpcy5kcmFnVGltZVNuYXAoKGkucGFnZVggLSB0aGlzLnN0YXRlLnJlc2l6ZVN0YXJ0KSAqIHRoaXMuZ2V0VGltZVJhdGlvKCkpO1xuICAgIHJldHVybiB1ICsgKHMgPT09IFwibGVmdFwiID8gLXYgOiB2KSA8ICh0aGlzLnByb3BzLmRyYWdTbmFwIHx8IDFlMykgPyBzID09PSBcImxlZnRcIiA/IHUgLSAodGhpcy5wcm9wcy5kcmFnU25hcCB8fCAxZTMpIDogKHRoaXMucHJvcHMuZHJhZ1NuYXAgfHwgMWUzKSAtIHUgOiB2O1xuICB9XG4gIG1vdW50SW50ZXJhY3QoKSB7XG4gICAgY29uc3QgaSA9IHRoaXMucHJvcHMudXNlUmVzaXplSGFuZGxlID8gXCIucmN0LWl0ZW0taGFuZGxlci1yZXNpemUtbGVmdFwiIDogITAsIHMgPSB0aGlzLnByb3BzLnVzZVJlc2l6ZUhhbmRsZSA/IFwiLnJjdC1pdGVtLWhhbmRsZXItcmVzaXplLXJpZ2h0XCIgOiAhMDtcbiAgICBkcih0aGlzLml0ZW1SZWYuY3VycmVudCkucmVzaXphYmxlKHtcbiAgICAgIGVkZ2VzOiB7XG4gICAgICAgIGxlZnQ6IHRoaXMuY2FuUmVzaXplTGVmdCgpICYmIGksXG4gICAgICAgIHJpZ2h0OiB0aGlzLmNhblJlc2l6ZVJpZ2h0KCkgJiYgcyxcbiAgICAgICAgdG9wOiAhMSxcbiAgICAgICAgYm90dG9tOiAhMVxuICAgICAgfSxcbiAgICAgIGVuYWJsZWQ6IHRoaXMucHJvcHMuc2VsZWN0ZWQgJiYgKHRoaXMuY2FuUmVzaXplTGVmdCgpIHx8IHRoaXMuY2FuUmVzaXplUmlnaHQoKSlcbiAgICB9KS5kcmFnZ2FibGUoe1xuICAgICAgZW5hYmxlZDogdGhpcy5wcm9wcy5zZWxlY3RlZCAmJiB0aGlzLmNhbk1vdmUoKVxuICAgIH0pLnN0eWxlQ3Vyc29yKCExKS5vbihcImRyYWdzdGFydFwiLCAodSkgPT4ge1xuICAgICAgaWYgKHRoaXMucHJvcHMuc2VsZWN0ZWQpIHtcbiAgICAgICAgdGhpcy5kcmFnSW5Qcm9ncmVzcyA9ICEwLCB0aGlzLmZpcmVJbnRlcmFjdEV2ZW50KCEwKTtcbiAgICAgICAgY29uc3QgdiA9IHRoaXMudGltZUZvcih1KTtcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7XG4gICAgICAgICAgZHJhZ2dpbmc6ICEwLFxuICAgICAgICAgIGRyYWdTdGFydDoge1xuICAgICAgICAgICAgeDogdS5wYWdlWCxcbiAgICAgICAgICAgIHk6IHUucGFnZVksXG4gICAgICAgICAgICBvZmZzZXQ6IHRoaXMuaXRlbVRpbWVTdGFydCAtIHZcbiAgICAgICAgICB9LFxuICAgICAgICAgIHByZURyYWdQb3NpdGlvbjogeyB4OiB1LnRhcmdldC5vZmZzZXRMZWZ0LCB5OiB1LnRhcmdldC5vZmZzZXRUb3AgfSxcbiAgICAgICAgICBkcmFnVGltZTogdGhpcy5pdGVtVGltZVN0YXJ0LFxuICAgICAgICAgIGRyYWdHcm91cERlbHRhOiAwXG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlXG4gICAgICAgIHJldHVybiAhMTtcbiAgICB9KS5vbihcImRyYWdtb3ZlXCIsICh1KSA9PiB7XG4gICAgICB0aGlzLnN0YXRlLmRyYWdnaW5nICYmIHRoaXMuc2V0U3RhdGUoKHYpID0+IHtcbiAgICAgICAgaWYgKCF0aGlzLmRyYWdJblByb2dyZXNzKVxuICAgICAgICAgIHJldHVybiB7IC4uLnYgfTtcbiAgICAgICAgbGV0IGYgPSB0aGlzLmRyYWdUaW1lKHUpO1xuICAgICAgICBjb25zdCBtID0gdGhpcy5kcmFnR3JvdXBEZWx0YSh1KTtcbiAgICAgICAgcmV0dXJuIHRoaXMucHJvcHMubW92ZVJlc2l6ZVZhbGlkYXRvciAmJiAoZiA9IHRoaXMucHJvcHMubW92ZVJlc2l6ZVZhbGlkYXRvcihcIm1vdmVcIiwgdGhpcy5wcm9wcy5pdGVtLCBmKSksIHRoaXMucHJvcHMub25EcmFnICYmIHRoaXMucHJvcHMub25EcmFnKHRoaXMuaXRlbUlkLCBmLCB0aGlzLnByb3BzLm9yZGVyLmluZGV4ICsgbSksIHtcbiAgICAgICAgICBkcmFnVGltZTogZixcbiAgICAgICAgICBkcmFnR3JvdXBEZWx0YTogbVxuICAgICAgICB9O1xuICAgICAgfSk7XG4gICAgfSkub24oXCJkcmFnZW5kXCIsICh1KSA9PiB7XG4gICAgICBpZiAodGhpcy5zdGF0ZS5kcmFnZ2luZykge1xuICAgICAgICBpZiAodGhpcy5wcm9wcy5vbkRyb3ApIHtcbiAgICAgICAgICB0aGlzLmRyYWdJblByb2dyZXNzID0gITEsIHRoaXMuZmlyZUludGVyYWN0RXZlbnQoITEpO1xuICAgICAgICAgIGxldCB2ID0gdGhpcy5kcmFnVGltZSh1KTtcbiAgICAgICAgICB0aGlzLnByb3BzLm1vdmVSZXNpemVWYWxpZGF0b3IgJiYgKHYgPSB0aGlzLnByb3BzLm1vdmVSZXNpemVWYWxpZGF0b3IoXCJtb3ZlXCIsIHRoaXMucHJvcHMuaXRlbSwgdikpLCB0aGlzLnByb3BzLm9uRHJvcCh0aGlzLml0ZW1JZCwgdiwgdGhpcy5wcm9wcy5vcmRlci5pbmRleCArIHRoaXMuZHJhZ0dyb3VwRGVsdGEodSkpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuc2V0U3RhdGUoe1xuICAgICAgICAgIGRyYWdnaW5nOiAhMSxcbiAgICAgICAgICBkcmFnU3RhcnQ6IG51bGwsXG4gICAgICAgICAgcHJlRHJhZ1Bvc2l0aW9uOiBudWxsLFxuICAgICAgICAgIGRyYWdUaW1lOiBudWxsLFxuICAgICAgICAgIGRyYWdHcm91cERlbHRhOiBudWxsXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0pLm9uKFwicmVzaXplc3RhcnRcIiwgKHUpID0+IHtcbiAgICAgIGlmICh0aGlzLnByb3BzLnNlbGVjdGVkKVxuICAgICAgICB0aGlzLmZpcmVJbnRlcmFjdEV2ZW50KCEwKSwgdGhpcy5zZXRTdGF0ZSh7XG4gICAgICAgICAgcmVzaXppbmc6ICEwLFxuICAgICAgICAgIHJlc2l6ZUVkZ2U6IG51bGwsXG4gICAgICAgICAgLy8gd2UgZG9uJ3Qga25vdyB5ZXRcbiAgICAgICAgICByZXNpemVTdGFydDogdS5wYWdlWCxcbiAgICAgICAgICByZXNpemVUaW1lOiAwXG4gICAgICAgIH0pO1xuICAgICAgZWxzZVxuICAgICAgICByZXR1cm4gITE7XG4gICAgfSkub24oXCJyZXNpemVtb3ZlXCIsICh1KSA9PiB7XG4gICAgICBpZiAodGhpcy5zdGF0ZS5yZXNpemluZykge1xuICAgICAgICBsZXQgdiA9IHRoaXMuc3RhdGUucmVzaXplRWRnZTtcbiAgICAgICAgdiB8fCAodiA9IHUuZGVsdGFSZWN0LmxlZnQgIT09IDAgPyBcImxlZnRcIiA6IFwicmlnaHRcIiwgdGhpcy5zZXRTdGF0ZSh7IHJlc2l6ZUVkZ2U6IHYgfSkpO1xuICAgICAgICBsZXQgZiA9IHRoaXMucmVzaXplVGltZVNuYXAodGhpcy50aW1lRm9yKHUpKTtcbiAgICAgICAgdGhpcy5wcm9wcy5tb3ZlUmVzaXplVmFsaWRhdG9yICYmIChmID0gdGhpcy5wcm9wcy5tb3ZlUmVzaXplVmFsaWRhdG9yKFwicmVzaXplXCIsIHRoaXMucHJvcHMuaXRlbSwgZiwgdikpLCB0aGlzLnByb3BzLm9uUmVzaXppbmcgJiYgdGhpcy5wcm9wcy5vblJlc2l6aW5nKHRoaXMuaXRlbUlkLCBmLCB2KSwgdGhpcy5zZXRTdGF0ZSh7XG4gICAgICAgICAgcmVzaXplVGltZTogZlxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9KS5vbihcInJlc2l6ZWVuZFwiLCAodSkgPT4ge1xuICAgICAgaWYgKHRoaXMuc3RhdGUucmVzaXppbmcpIHtcbiAgICAgICAgdGhpcy5maXJlSW50ZXJhY3RFdmVudCghMSk7XG4gICAgICAgIGNvbnN0IHsgcmVzaXplRWRnZTogdiB9ID0gdGhpcy5zdGF0ZTtcbiAgICAgICAgbGV0IGYgPSB0aGlzLnJlc2l6ZVRpbWVTbmFwKHRoaXMudGltZUZvcih1KSk7XG4gICAgICAgIHRoaXMucHJvcHMubW92ZVJlc2l6ZVZhbGlkYXRvciAmJiAoZiA9IHRoaXMucHJvcHMubW92ZVJlc2l6ZVZhbGlkYXRvcihcInJlc2l6ZVwiLCB0aGlzLnByb3BzLml0ZW0sIGYsIHYpKSwgdGhpcy5wcm9wcy5vblJlc2l6ZWQgJiYgdGhpcy5wcm9wcy5vblJlc2l6ZWQodGhpcy5pdGVtSWQsIGYsIHYsIHRoaXMucmVzaXplVGltZURlbHRhKHUsIHYpKSwgdGhpcy5zZXRTdGF0ZSh7XG4gICAgICAgICAgcmVzaXppbmc6ICExLFxuICAgICAgICAgIHJlc2l6ZVN0YXJ0OiBudWxsLFxuICAgICAgICAgIHJlc2l6ZUVkZ2U6IG51bGwsXG4gICAgICAgICAgcmVzaXplVGltZTogbnVsbFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9KS5vbihcInRhcFwiLCAodSkgPT4ge1xuICAgICAgdGhpcy5hY3R1YWxDbGljayh1LCB1LnBvaW50ZXJUeXBlID09PSBcIm1vdXNlXCIgPyBcImNsaWNrXCIgOiBcInRvdWNoXCIpO1xuICAgIH0pLCB0aGlzLnNldFN0YXRlKHtcbiAgICAgIGludGVyYWN0TW91bnRlZDogITBcbiAgICB9KTtcbiAgfVxuICBjYW5SZXNpemVMZWZ0KGkgPSB0aGlzLnByb3BzKSB7XG4gICAgdmFyIHU7XG4gICAgcmV0dXJuICFpLmNhblJlc2l6ZUxlZnQgfHwgaS5taW5SZXNpemVXaWR0aCA9PT0gdm9pZCAwID8gITEgOiBwYXJzZUludCgodSA9IGkuZGltZW5zaW9ucy53aWR0aCkgPT0gbnVsbCA/IHZvaWQgMCA6IHUudG9TdHJpbmcoKSwgMTApID49IGkubWluUmVzaXplV2lkdGg7XG4gIH1cbiAgY2FuUmVzaXplUmlnaHQoaSA9IHRoaXMucHJvcHMpIHtcbiAgICB2YXIgdTtcbiAgICByZXR1cm4gIWkuY2FuUmVzaXplUmlnaHQgfHwgaS5taW5SZXNpemVXaWR0aCA9PT0gdm9pZCAwID8gITEgOiBwYXJzZUludCgodSA9IGkuZGltZW5zaW9ucy53aWR0aCkgPT0gbnVsbCA/IHZvaWQgMCA6IHUudG9TdHJpbmcoKSwgMTApID49IGkubWluUmVzaXplV2lkdGg7XG4gIH1cbiAgY2FuTW92ZShpID0gdGhpcy5wcm9wcykge1xuICAgIHJldHVybiAhIWkuY2FuTW92ZTtcbiAgfVxuICBjb21wb25lbnREaWRVcGRhdGUoaSkge1xuICAgIHRoaXMuY2FjaGVEYXRhRnJvbVByb3BzKHRoaXMucHJvcHMpO1xuICAgIGxldCB7IGludGVyYWN0TW91bnRlZDogcyB9ID0gdGhpcy5zdGF0ZTtcbiAgICBjb25zdCB1ID0gaS5zZWxlY3RlZCAmJiB0aGlzLmNhbk1vdmUoaSksIHYgPSBpLnNlbGVjdGVkICYmIHRoaXMuY2FuUmVzaXplTGVmdChpKSwgZiA9IGkuc2VsZWN0ZWQgJiYgdGhpcy5jYW5SZXNpemVSaWdodChpKSwgbSA9IHRoaXMucHJvcHMuc2VsZWN0ZWQgJiYgdGhpcy5jYW5Nb3ZlKHRoaXMucHJvcHMpLCB5ID0gdGhpcy5wcm9wcy5zZWxlY3RlZCAmJiB0aGlzLmNhblJlc2l6ZUxlZnQodGhpcy5wcm9wcyksIFMgPSB0aGlzLnByb3BzLnNlbGVjdGVkICYmIHRoaXMuY2FuUmVzaXplUmlnaHQodGhpcy5wcm9wcyk7XG4gICAgaWYgKHRoaXMuaXRlbVJlZiAmJiB0aGlzLml0ZW1SZWYuY3VycmVudCkge1xuICAgICAgaWYgKHRoaXMucHJvcHMuc2VsZWN0ZWQgJiYgIXMgJiYgKHRoaXMubW91bnRJbnRlcmFjdCgpLCBzID0gITApLCBzICYmICh2ICE9PSB5IHx8IGYgIT09IFMpKSB7XG4gICAgICAgIGNvbnN0IEMgPSB0aGlzLnByb3BzLnVzZVJlc2l6ZUhhbmRsZSA/IHRoaXMuZHJhZ0xlZnQgOiAhMCwgRCA9IHRoaXMucHJvcHMudXNlUmVzaXplSGFuZGxlID8gdGhpcy5kcmFnUmlnaHQgOiAhMDtcbiAgICAgICAgZHIodGhpcy5pdGVtUmVmLmN1cnJlbnQpLnJlc2l6YWJsZSh7XG4gICAgICAgICAgZW5hYmxlZDogeSB8fCBTLFxuICAgICAgICAgIGVkZ2VzOiB7XG4gICAgICAgICAgICB0b3A6ICExLFxuICAgICAgICAgICAgYm90dG9tOiAhMSxcbiAgICAgICAgICAgIGxlZnQ6IHkgJiYgQyxcbiAgICAgICAgICAgIHJpZ2h0OiBTICYmIERcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgcyAmJiB1ICE9PSBtICYmIGRyKHRoaXMuaXRlbVJlZi5jdXJyZW50KS5kcmFnZ2FibGUoeyBlbmFibGVkOiBtIH0pO1xuICAgIH0gZWxzZVxuICAgICAgcyA9ICExO1xuICAgIHMgIT09IHRoaXMuc3RhdGUuaW50ZXJhY3RNb3VudGVkICYmIHRoaXMuc2V0U3RhdGUoe1xuICAgICAgaW50ZXJhY3RNb3VudGVkOiBzXG4gICAgfSk7XG4gIH1cbiAgYWN0dWFsQ2xpY2soaSwgcykge1xuICAgIHRoaXMucHJvcHMuY2FuU2VsZWN0ICYmIHRoaXMucHJvcHMub25TZWxlY3QgJiYgdGhpcy5wcm9wcy5vblNlbGVjdCh0aGlzLml0ZW1JZCwgcywgaSk7XG4gIH1cbiAgZ2V0SXRlbVN0eWxlKGkpIHtcbiAgICBjb25zdCBzID0gdGhpcy5wcm9wcy5kaW1lbnNpb25zLCB1ID0ge1xuICAgICAgcG9zaXRpb246IFwiYWJzb2x1dGVcIixcbiAgICAgIGJveFNpemluZzogXCJib3JkZXItYm94XCIsXG4gICAgICBsZWZ0OiBgJHtzLmxlZnR9cHhgLFxuICAgICAgdG9wOiBgJHtzLnRvcH1weGAsXG4gICAgICB3aWR0aDogYCR7cy53aWR0aH1weGAsXG4gICAgICBoZWlnaHQ6IGAke3MuaGVpZ2h0fXB4YCxcbiAgICAgIGxpbmVIZWlnaHQ6IGAke3MuaGVpZ2h0fXB4YFxuICAgIH07XG4gICAgcmV0dXJuIE9iamVjdC5hc3NpZ24oe30sIFFoLCB0aGlzLnByb3BzLnNlbGVjdGVkID8gZWQgOiB7fSwgdGhpcy5wcm9wcy5zZWxlY3RlZCAmJiB0aGlzLmNhbk1vdmUodGhpcy5wcm9wcykgPyB0ZCA6IHt9LCB0aGlzLnByb3BzLnNlbGVjdGVkICYmIHRoaXMuY2FuUmVzaXplTGVmdCh0aGlzLnByb3BzKSA/IHJkIDoge30sIHRoaXMucHJvcHMuc2VsZWN0ZWQgJiYgdGhpcy5jYW5SZXNpemVMZWZ0KHRoaXMucHJvcHMpICYmIHRoaXMuc3RhdGUuZHJhZ2dpbmcgPyBuZCA6IHt9LCB0aGlzLnByb3BzLnNlbGVjdGVkICYmIHRoaXMuY2FuUmVzaXplUmlnaHQodGhpcy5wcm9wcykgPyBpZCA6IHt9LCB0aGlzLnByb3BzLnNlbGVjdGVkICYmIHRoaXMuY2FuUmVzaXplUmlnaHQodGhpcy5wcm9wcykgJiYgdGhpcy5zdGF0ZS5kcmFnZ2luZyA/IG9kIDoge30sIGkuc3R5bGUsIHUpO1xuICB9XG4gIHJlbmRlcigpIHtcbiAgICBpZiAodHlwZW9mIHRoaXMucHJvcHMub3JkZXIgPiBcInVcIiB8fCB0aGlzLnByb3BzLm9yZGVyID09PSBudWxsKVxuICAgICAgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgaSA9IHRoaXMuY29udGV4dCwgcyA9IHtcbiAgICAgIGRpbWVuc2lvbnM6IHRoaXMucHJvcHMuZGltZW5zaW9ucyxcbiAgICAgIHVzZVJlc2l6ZUhhbmRsZTogISF0aGlzLnByb3BzLnVzZVJlc2l6ZUhhbmRsZSxcbiAgICAgIHRpdGxlOiB0aGlzLml0ZW1UaXRsZSxcbiAgICAgIGNhbk1vdmU6IHRoaXMuY2FuTW92ZSh0aGlzLnByb3BzKSxcbiAgICAgIGNhblJlc2l6ZUxlZnQ6IHRoaXMuY2FuUmVzaXplTGVmdCh0aGlzLnByb3BzKSxcbiAgICAgIGNhblJlc2l6ZVJpZ2h0OiB0aGlzLmNhblJlc2l6ZVJpZ2h0KHRoaXMucHJvcHMpLFxuICAgICAgc2VsZWN0ZWQ6IHRoaXMucHJvcHMuc2VsZWN0ZWQsXG4gICAgICBkcmFnZ2luZzogdGhpcy5zdGF0ZS5kcmFnZ2luZyxcbiAgICAgIGRyYWdTdGFydDogdGhpcy5zdGF0ZS5kcmFnU3RhcnQsXG4gICAgICBkcmFnVGltZTogdGhpcy5zdGF0ZS5kcmFnVGltZSxcbiAgICAgIGRyYWdHcm91cERlbHRhOiB0aGlzLnN0YXRlLmRyYWdHcm91cERlbHRhLFxuICAgICAgcmVzaXppbmc6IHRoaXMuc3RhdGUucmVzaXppbmcsXG4gICAgICByZXNpemVFZGdlOiB0aGlzLnN0YXRlLnJlc2l6ZUVkZ2UsXG4gICAgICByZXNpemVTdGFydDogdGhpcy5zdGF0ZS5yZXNpemVTdGFydCxcbiAgICAgIHJlc2l6ZVRpbWU6IHRoaXMuc3RhdGUucmVzaXplVGltZVxuICAgIH07XG4gICAgcmV0dXJuIHRoaXMucHJvcHMuaXRlbVJlbmRlcmVyID8gdGhpcy5wcm9wcy5pdGVtUmVuZGVyZXIoe1xuICAgICAgaXRlbTogdGhpcy5wcm9wcy5pdGVtLFxuICAgICAgdGltZWxpbmVDb250ZXh0OiBpLFxuICAgICAgaXRlbUNvbnRleHQ6IHMsXG4gICAgICBnZXRJdGVtUHJvcHM6IHRoaXMuZ2V0SXRlbVByb3BzLFxuICAgICAgZ2V0UmVzaXplUHJvcHM6IHRoaXMuZ2V0UmVzaXplUHJvcHNcbiAgICB9KSA6IExpKHtcbiAgICAgIGl0ZW06IHRoaXMucHJvcHMuaXRlbSxcbiAgICAgIGl0ZW1Db250ZXh0OiBzLFxuICAgICAgZ2V0SXRlbVByb3BzOiB0aGlzLmdldEl0ZW1Qcm9wcyxcbiAgICAgIGdldFJlc2l6ZVByb3BzOiB0aGlzLmdldFJlc2l6ZVByb3BzXG4gICAgfSk7XG4gIH1cbn1cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShBciwgXCJkZWZhdWx0UHJvcHNcIiwge1xuICBlbnVtZXJhYmxlOiAhMCxcbiAgY29uZmlndXJhYmxlOiAhMCxcbiAgd3JpdGFibGU6ICEwLFxuICB2YWx1ZToge1xuICAgIHNlbGVjdGVkOiAhMSxcbiAgICBpdGVtUmVuZGVyZXI6IExpXG4gIH1cbn0pO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KEFyLCBcImNvbnRleHRUeXBlXCIsIHtcbiAgZW51bWVyYWJsZTogITAsXG4gIGNvbmZpZ3VyYWJsZTogITAsXG4gIHdyaXRhYmxlOiAhMCxcbiAgdmFsdWU6IGpyXG59KTtcbmZ1bmN0aW9uIGRkKGEsIGkpIHtcbiAgY29uc3QgcyA9IFkoYSwgXCJjYW5SZXNpemVcIikgIT09IHZvaWQgMCA/IFkoYSwgXCJjYW5SZXNpemVcIikgOiBpO1xuICByZXR1cm4gcyA9PT0gXCJsZWZ0XCIgfHwgcyA9PT0gXCJib3RoXCI7XG59XG5mdW5jdGlvbiBmZChhLCBpKSB7XG4gIGNvbnN0IHMgPSBZKGEsIFwiY2FuUmVzaXplXCIpICE9PSB2b2lkIDAgPyBZKGEsIFwiY2FuUmVzaXplXCIpIDogaTtcbiAgcmV0dXJuIHMgPT09IFwicmlnaHRcIiB8fCBzID09PSBcImJvdGhcIiB8fCBzID09PSAhMDtcbn1cbmNsYXNzIHZkIGV4dGVuZHMgYWUge1xuICBzaG91bGRDb21wb25lbnRVcGRhdGUoaSkge1xuICAgIHJldHVybiAhKHR0KGkuZ3JvdXBzLCB0aGlzLnByb3BzLmdyb3VwcykgJiYgdHQoaS5pdGVtcywgdGhpcy5wcm9wcy5pdGVtcykgJiYgdHQoaS5kaW1lbnNpb25JdGVtcywgdGhpcy5wcm9wcy5kaW1lbnNpb25JdGVtcykgJiYgaS5rZXlzID09PSB0aGlzLnByb3BzLmtleXMgJiYgaS5jYW52YXNUaW1lU3RhcnQgPT09IHRoaXMucHJvcHMuY2FudmFzVGltZVN0YXJ0ICYmIGkuY2FudmFzVGltZUVuZCA9PT0gdGhpcy5wcm9wcy5jYW52YXNUaW1lRW5kICYmIGkuY2FudmFzV2lkdGggPT09IHRoaXMucHJvcHMuY2FudmFzV2lkdGggJiYgaS5zZWxlY3RlZEl0ZW0gPT09IHRoaXMucHJvcHMuc2VsZWN0ZWRJdGVtICYmIGkuc2VsZWN0ZWQgPT09IHRoaXMucHJvcHMuc2VsZWN0ZWQgJiYgaS5kcmFnU25hcCA9PT0gdGhpcy5wcm9wcy5kcmFnU25hcCAmJiBpLm1pblJlc2l6ZVdpZHRoID09PSB0aGlzLnByb3BzLm1pblJlc2l6ZVdpZHRoICYmIGkuY2FuQ2hhbmdlR3JvdXAgPT09IHRoaXMucHJvcHMuY2FuQ2hhbmdlR3JvdXAgJiYgaS5jYW5Nb3ZlID09PSB0aGlzLnByb3BzLmNhbk1vdmUgJiYgaS5jYW5SZXNpemUgPT09IHRoaXMucHJvcHMuY2FuUmVzaXplICYmIGkuY2FuU2VsZWN0ID09PSB0aGlzLnByb3BzLmNhblNlbGVjdCk7XG4gIH1cbiAgaXNTZWxlY3RlZChpLCBzKSB7XG4gICAgaWYgKHRoaXMucHJvcHMuc2VsZWN0ZWQpIHtcbiAgICAgIGNvbnN0IHUgPSBZKGksIHMpO1xuICAgICAgcmV0dXJuIHRoaXMucHJvcHMuc2VsZWN0ZWQuaW5jbHVkZXModSk7XG4gICAgfSBlbHNlXG4gICAgICByZXR1cm4gdGhpcy5wcm9wcy5zZWxlY3RlZEl0ZW0gPT09IFkoaSwgcyk7XG4gIH1cbiAgZ2V0VmlzaWJsZUl0ZW1zKGksIHMpIHtcbiAgICBjb25zdCB7IGtleXM6IHUsIGl0ZW1zOiB2IH0gPSB0aGlzLnByb3BzO1xuICAgIHJldHVybiB6cih2LCBpLCBzLCB1KTtcbiAgfVxuICByZW5kZXIoKSB7XG4gICAgY29uc3QgeyBjYW52YXNUaW1lU3RhcnQ6IGksIGNhbnZhc1RpbWVFbmQ6IHMsIGRpbWVuc2lvbkl0ZW1zOiB1LCBrZXlzOiB2LCBncm91cHM6IGYgfSA9IHRoaXMucHJvcHMsIHsgaXRlbUlkS2V5OiBtLCBpdGVtR3JvdXBLZXk6IHkgfSA9IHYsIFMgPSBrcihmLCB2KSwgQyA9IHRoaXMuZ2V0VmlzaWJsZUl0ZW1zKGksIHMpLCBEID0gWmgodSwgXCJpZFwiKTtcbiAgICByZXR1cm4gaihcImRpdlwiLCB7IGNsYXNzTmFtZTogXCJyY3QtaXRlbXNcIiwgY2hpbGRyZW46IEMuZmlsdGVyKChSKSA9PiBEW1koUiwgbSldKS5tYXAoKFIpID0+IGooQXIsIHsgaXRlbVByb3BzOiBSLml0ZW1Qcm9wcywgaXRlbTogUiwga2V5czogdGhpcy5wcm9wcy5rZXlzLCBvcmRlcjogU1tZKFIsIHkpXSwgZGltZW5zaW9uczogRFtZKFIsIG0pXS5kaW1lbnNpb25zLCBzZWxlY3RlZDogdGhpcy5pc1NlbGVjdGVkKFIsIG0pLCBjYW5DaGFuZ2VHcm91cDogWShSLCBcImNhbkNoYW5nZUdyb3VwXCIpICE9PSB2b2lkIDAgPyBZKFIsIFwiY2FuQ2hhbmdlR3JvdXBcIikgOiB0aGlzLnByb3BzLmNhbkNoYW5nZUdyb3VwLCBjYW5Nb3ZlOiBZKFIsIFwiY2FuTW92ZVwiKSAhPT0gdm9pZCAwID8gWShSLCBcImNhbk1vdmVcIikgOiB0aGlzLnByb3BzLmNhbk1vdmUsIGNhblJlc2l6ZUxlZnQ6IGRkKFIsIHRoaXMucHJvcHMuY2FuUmVzaXplKSwgY2FuUmVzaXplUmlnaHQ6IGZkKFIsIHRoaXMucHJvcHMuY2FuUmVzaXplKSwgY2FuU2VsZWN0OiBZKFIsIFwiY2FuU2VsZWN0XCIpICE9PSB2b2lkIDAgPyBZKFIsIFwiY2FuU2VsZWN0XCIpIDogdGhpcy5wcm9wcy5jYW5TZWxlY3QsIHVzZVJlc2l6ZUhhbmRsZTogdGhpcy5wcm9wcy51c2VSZXNpemVIYW5kbGUsIGdyb3VwVG9wczogdGhpcy5wcm9wcy5ncm91cFRvcHMsIGNhbnZhc1RpbWVTdGFydDogdGhpcy5wcm9wcy5jYW52YXNUaW1lU3RhcnQsIGNhbnZhc1RpbWVFbmQ6IHRoaXMucHJvcHMuY2FudmFzVGltZUVuZCwgY2FudmFzV2lkdGg6IHRoaXMucHJvcHMuY2FudmFzV2lkdGgsIGRyYWdTbmFwOiB0aGlzLnByb3BzLmRyYWdTbmFwLCBtaW5SZXNpemVXaWR0aDogdGhpcy5wcm9wcy5taW5SZXNpemVXaWR0aCwgb25SZXNpemluZzogdGhpcy5wcm9wcy5pdGVtUmVzaXppbmcsIG9uUmVzaXplZDogdGhpcy5wcm9wcy5pdGVtUmVzaXplZCwgbW92ZVJlc2l6ZVZhbGlkYXRvcjogdGhpcy5wcm9wcy5tb3ZlUmVzaXplVmFsaWRhdG9yLCBvbkRyYWc6IHRoaXMucHJvcHMuaXRlbURyYWcsIG9uRHJvcDogdGhpcy5wcm9wcy5pdGVtRHJvcCwgb25JdGVtRG91YmxlQ2xpY2s6IHRoaXMucHJvcHMub25JdGVtRG91YmxlQ2xpY2ssIG9uQ29udGV4dE1lbnU6IHRoaXMucHJvcHMub25JdGVtQ29udGV4dE1lbnUsIG9uU2VsZWN0OiB0aGlzLnByb3BzLml0ZW1TZWxlY3QsIGl0ZW1SZW5kZXJlcjogdGhpcy5wcm9wcy5pdGVtUmVuZGVyZXIsIHNjcm9sbFJlZjogdGhpcy5wcm9wcy5zY3JvbGxSZWYgfSwgWShSLCBtKSkpIH0pO1xuICB9XG59XG5jbGFzcyBmaSBleHRlbmRzIGFlIHtcbiAgc2hvdWxkQ29tcG9uZW50VXBkYXRlKGkpIHtcbiAgICByZXR1cm4gIShpLmtleXMgPT09IHRoaXMucHJvcHMua2V5cyAmJiBpLndpZHRoID09PSB0aGlzLnByb3BzLndpZHRoICYmIGkuaGVpZ2h0ID09PSB0aGlzLnByb3BzLmhlaWdodCAmJiB0dChpLmdyb3VwcywgdGhpcy5wcm9wcy5ncm91cHMpICYmIHR0KGkuZ3JvdXBIZWlnaHRzLCB0aGlzLnByb3BzLmdyb3VwSGVpZ2h0cykpO1xuICB9XG4gIHJlbmRlckdyb3VwQ29udGVudChpLCBzID0gITEsIHUsIHYpIHtcbiAgICByZXR1cm4gdGhpcy5wcm9wcy5ncm91cFJlbmRlcmVyID8gWi5jcmVhdGVFbGVtZW50KHRoaXMucHJvcHMuZ3JvdXBSZW5kZXJlciwge1xuICAgICAgZ3JvdXA6IGksXG4gICAgICBpc1JpZ2h0U2lkZWJhcjogc1xuICAgIH0pIDogWShpLCBzID8gdiA6IHUpO1xuICB9XG4gIHJlbmRlcigpIHtcbiAgICBjb25zdCB7IHdpZHRoOiBpLCBncm91cEhlaWdodHM6IHMsIGhlaWdodDogdSwgaXNSaWdodFNpZGViYXI6IHYgfSA9IHRoaXMucHJvcHMsIHsgZ3JvdXBJZEtleTogZiwgZ3JvdXBUaXRsZUtleTogbSwgZ3JvdXBSaWdodFRpdGxlS2V5OiB5IH0gPSB0aGlzLnByb3BzLmtleXMsIFMgPSB7XG4gICAgICB3aWR0aDogYCR7aX1weGAsXG4gICAgICBoZWlnaHQ6IGAke3V9cHhgXG4gICAgfSwgQyA9IHtcbiAgICAgIHdpZHRoOiBgJHtpfXB4YFxuICAgIH0sIEQgPSB0aGlzLnByb3BzLmdyb3Vwcy5tYXAoKFIsIFQpID0+IHtcbiAgICAgIGNvbnN0IFAgPSB7XG4gICAgICAgIGhlaWdodDogYCR7c1tUXX1weGAsXG4gICAgICAgIGxpbmVIZWlnaHQ6IGAke3NbVF19cHhgXG4gICAgICB9O1xuICAgICAgcmV0dXJuIGooXCJkaXZcIiwgeyBjbGFzc05hbWU6IFwicmN0LXNpZGViYXItcm93IHJjdC1zaWRlYmFyLXJvdy1cIiArIChUICUgMiA9PT0gMCA/IFwiZXZlblwiIDogXCJvZGRcIiksIHN0eWxlOiBQLCBjaGlsZHJlbjogdGhpcy5yZW5kZXJHcm91cENvbnRlbnQoUiwgdiwgbSwgeSkgfSwgWShSLCBmKSk7XG4gICAgfSk7XG4gICAgcmV0dXJuIGooXCJkaXZcIiwgeyBjbGFzc05hbWU6IFwicmN0LXNpZGViYXJcIiArICh2ID8gXCIgcmN0LXNpZGViYXItcmlnaHRcIiA6IFwiXCIpLCBzdHlsZTogUywgY2hpbGRyZW46IGooXCJkaXZcIiwgeyBzdHlsZTogQywgY2hpbGRyZW46IEQgfSkgfSk7XG4gIH1cbn1cbmNsYXNzIGdkIGV4dGVuZHMgYWUge1xuICBzaG91bGRDb21wb25lbnRVcGRhdGUoaSkge1xuICAgIHJldHVybiAhKGkuY2FudmFzVGltZVN0YXJ0ID09PSB0aGlzLnByb3BzLmNhbnZhc1RpbWVTdGFydCAmJiBpLmNhbnZhc1RpbWVFbmQgPT09IHRoaXMucHJvcHMuY2FudmFzVGltZUVuZCAmJiBpLmNhbnZhc1dpZHRoID09PSB0aGlzLnByb3BzLmNhbnZhc1dpZHRoICYmIGkubGluZUNvdW50ID09PSB0aGlzLnByb3BzLmxpbmVDb3VudCAmJiBpLm1pblVuaXQgPT09IHRoaXMucHJvcHMubWluVW5pdCAmJiBpLnRpbWVTdGVwcyA9PT0gdGhpcy5wcm9wcy50aW1lU3RlcHMgJiYgaS5oZWlnaHQgPT09IHRoaXMucHJvcHMuaGVpZ2h0ICYmIGkudmVydGljYWxMaW5lQ2xhc3NOYW1lc0ZvclRpbWUgPT09IHRoaXMucHJvcHMudmVydGljYWxMaW5lQ2xhc3NOYW1lc0ZvclRpbWUpO1xuICB9XG4gIHJlbmRlcigpIHtcbiAgICBjb25zdCB7XG4gICAgICBjYW52YXNUaW1lU3RhcnQ6IGksXG4gICAgICBjYW52YXNUaW1lRW5kOiBzLFxuICAgICAgLy8gY2FudmFzV2lkdGgsXG4gICAgICBtaW5Vbml0OiB1LFxuICAgICAgdGltZVN0ZXBzOiB2LFxuICAgICAgaGVpZ2h0OiBmLFxuICAgICAgdmVydGljYWxMaW5lQ2xhc3NOYW1lc0ZvclRpbWU6IG0sXG4gICAgICBnZXRMZWZ0T2Zmc2V0RnJvbURhdGU6IHlcbiAgICB9ID0gdGhpcy5wcm9wcywgUyA9IFtdO1xuICAgIHJldHVybiBScihpLCBzLCB1LCB2LCAoQywgRCkgPT4ge1xuICAgICAgY29uc3QgVCA9IEMuZ2V0KHUgPT09IFwiZGF5XCIgPyBcImRhdGVcIiA6IHUpID09PSAodSA9PT0gXCJkYXlcIiA/IDEgOiAwKTtcbiAgICAgIGxldCBQID0gW107XG4gICAgICBtICYmIChQID0gbShcbiAgICAgICAgQy51bml4KCkgKiAxZTMsXG4gICAgICAgIC8vIHR1cm4gaW50byBtcywgd2hpY2ggaXMgd2hhdCB2ZXJ0aWNhbExpbmVDbGFzc05hbWVzRm9yVGltZSBleHBlY3RzXG4gICAgICAgIEQudW5peCgpICogMWUzIC0gMVxuICAgICAgKSk7XG4gICAgICBjb25zdCBfID0gXCJyY3QtdmxcIiArIChUID8gXCIgcmN0LXZsLWZpcnN0XCIgOiBcIlwiKSArICh1ID09PSBcImRheVwiIHx8IHUgPT09IFwiaG91clwiIHx8IHUgPT09IFwibWludXRlXCIgPyBgIHJjdC1kYXktJHtDLmRheSgpfSBgIDogXCIgXCIpICsgUC5qb2luKFwiIFwiKSwgTyA9IHkoQy52YWx1ZU9mKCkpLCBrID0geShELnZhbHVlT2YoKSk7XG4gICAgICBTLnB1c2goaihcImRpdlwiLCB7IGNsYXNzTmFtZTogXywgc3R5bGU6IHtcbiAgICAgICAgcG9pbnRlckV2ZW50czogXCJub25lXCIsXG4gICAgICAgIHRvcDogXCIwcHhcIixcbiAgICAgICAgbGVmdDogYCR7T31weGAsXG4gICAgICAgIHdpZHRoOiBgJHtrIC0gT31weGAsXG4gICAgICAgIGhlaWdodDogYCR7Zn1weGBcbiAgICAgIH0gfSwgYGxpbmUtJHtDLnZhbHVlT2YoKX1gKSk7XG4gICAgfSksIGooXCJkaXZcIiwgeyBjbGFzc05hbWU6IFwicmN0LXZlcnRpY2FsLWxpbmVzXCIsIGNoaWxkcmVuOiBTIH0pO1xuICB9XG59XG5jb25zdCBtZCA9ICh7IC4uLmEgfSkgPT4gaihMdCwgeyBjaGlsZHJlbjogKHsgZ2V0TGVmdE9mZnNldEZyb21EYXRlOiBpIH0pID0+IGooZ2QsIHsgZ2V0TGVmdE9mZnNldEZyb21EYXRlOiBpLCAuLi5hIH0pIH0pO1xuY2xhc3MgYmQgZXh0ZW5kcyBhZSB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKC4uLmFyZ3VtZW50cyksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImhhbmRsZU1vdXNlRG93blwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKGkpID0+IHtcbiAgICAgICAgdGhpcy5vcmlnaW5DbGlja1ggPSBpLmNsaWVudFg7XG4gICAgICB9XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImhhbmRsZU1vdXNlVXBcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IChpKSA9PiB7XG4gICAgICAgIHRoaXMucHJvcHMuY2xpY2tUb2xlcmFuY2UgIT09IHZvaWQgMCAmJiBNYXRoLmFicyh0aGlzLm9yaWdpbkNsaWNrWCAtIGkuY2xpZW50WCkgPiB0aGlzLnByb3BzLmNsaWNrVG9sZXJhbmNlICYmICh0aGlzLmNhbmNlbENsaWNrID0gITApO1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJoYW5kbGVDbGlja1wiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKGkpID0+IHtcbiAgICAgICAgdGhpcy5jYW5jZWxDbGljayB8fCB0aGlzLnByb3BzLm9uQ2xpY2soaSksIHRoaXMuY2FuY2VsQ2xpY2sgPSAhMSwgdGhpcy5vcmlnaW5DbGlja1ggPSBudWxsO1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJvcmlnaW5DbGlja1hcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IHZvaWQgMFxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJjYW5jZWxDbGlja1wiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogITFcbiAgICB9KTtcbiAgfVxuICByZW5kZXIoKSB7XG4gICAgY29uc3QgaSA9IFouQ2hpbGRyZW4ub25seSh0aGlzLnByb3BzLmNoaWxkcmVuKTtcbiAgICByZXR1cm4gWi5jbG9uZUVsZW1lbnQoaSwge1xuICAgICAgb25Nb3VzZURvd246IHRoaXMuaGFuZGxlTW91c2VEb3duLFxuICAgICAgb25Nb3VzZVVwOiB0aGlzLmhhbmRsZU1vdXNlVXAsXG4gICAgICBvbkNsaWNrOiB0aGlzLmhhbmRsZUNsaWNrXG4gICAgfSk7XG4gIH1cbn1cbmNsYXNzIHlkIGV4dGVuZHMgYWUge1xuICByZW5kZXIoKSB7XG4gICAgY29uc3QgeyBvbkNvbnRleHRNZW51OiBpLCBvbkRvdWJsZUNsaWNrOiBzLCBpc0V2ZW5Sb3c6IHUsIHN0eWxlOiB2LCBvbkNsaWNrOiBmLCBjbGlja1RvbGVyYW5jZTogbSwgaG9yaXpvbnRhbExpbmVDbGFzc05hbWVzRm9yR3JvdXA6IHksIGdyb3VwOiBTIH0gPSB0aGlzLnByb3BzO1xuICAgIGxldCBDID0gW107XG4gICAgcmV0dXJuIHkgJiYgKEMgPSB5KFMpKSwgaihiZCwgeyBjbGlja1RvbGVyYW5jZTogbSwgb25DbGljazogZiwgY2hpbGRyZW46IGooXCJkaXZcIiwgeyBvbkNvbnRleHRNZW51OiBpLCBvbkRvdWJsZUNsaWNrOiBzLCBjbGFzc05hbWU6ICh1ID8gXCJyY3QtaGwtZXZlbiBcIiA6IFwicmN0LWhsLW9kZCBcIikgKyAoQyA/IEMuam9pbihcIiBcIikgOiBcIlwiKSwgc3R5bGU6IHYgfSkgfSk7XG4gIH1cbn1cbmNsYXNzIFRkIGV4dGVuZHMgYWUge1xuICBzaG91bGRDb21wb25lbnRVcGRhdGUoaSkge1xuICAgIHJldHVybiAhKGkuY2FudmFzV2lkdGggPT09IHRoaXMucHJvcHMuY2FudmFzV2lkdGggJiYgaS5saW5lQ291bnQgPT09IHRoaXMucHJvcHMubGluZUNvdW50ICYmIGkuZ3JvdXBIZWlnaHRzID09PSB0aGlzLnByb3BzLmdyb3VwSGVpZ2h0cyAmJiBpLmdyb3VwcyA9PT0gdGhpcy5wcm9wcy5ncm91cHMpO1xuICB9XG4gIHJlbmRlcigpIHtcbiAgICBjb25zdCB7IGNhbnZhc1dpZHRoOiBpLCBsaW5lQ291bnQ6IHMsIGdyb3VwSGVpZ2h0czogdSwgb25Sb3dDbGljazogdiwgb25Sb3dEb3VibGVDbGljazogZiwgY2xpY2tUb2xlcmFuY2U6IG0sIGdyb3VwczogeSwgaG9yaXpvbnRhbExpbmVDbGFzc05hbWVzRm9yR3JvdXA6IFMsIG9uUm93Q29udGV4dENsaWNrOiBDIH0gPSB0aGlzLnByb3BzLCBEID0gW107XG4gICAgZm9yIChsZXQgUiA9IDA7IFIgPCBzOyBSKyspXG4gICAgICBELnB1c2goaih5ZCwgeyBjbGlja1RvbGVyYW5jZTogbSwgb25Db250ZXh0TWVudTogKFQpID0+IEMoVCwgUiksIG9uQ2xpY2s6IChUKSA9PiB2KFQsIFIpLCBvbkRvdWJsZUNsaWNrOiAoVCkgPT4gZihULCBSKSwgaXNFdmVuUm93OiBSICUgMiA9PT0gMCwgZ3JvdXA6IHlbUl0sIGhvcml6b250YWxMaW5lQ2xhc3NOYW1lc0Zvckdyb3VwOiBTLCBzdHlsZToge1xuICAgICAgICB3aWR0aDogYCR7aX1weGAsXG4gICAgICAgIGhlaWdodDogYCR7dVtSXX1weGBcbiAgICAgIH0gfSwgYGhvcml6b250YWwtbGluZS0ke1J9YCkpO1xuICAgIHJldHVybiBqKFwiZGl2XCIsIHsgY2xhc3NOYW1lOiBcInJjdC1ob3Jpem9udGFsLWxpbmVzXCIsIGNoaWxkcmVuOiBEIH0pO1xuICB9XG59XG5jbGFzcyB3ZCBleHRlbmRzIGFlIHtcbiAgY29uc3RydWN0b3IoaSkge1xuICAgIHN1cGVyKGkpLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJzY3JvbGxDb21wb25lbnRSZWZcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IHhpKClcbiAgICB9KSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwiZHJhZ0xhc3RQb3NpdGlvblwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogbnVsbFxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJsYXN0VG91Y2hEaXN0YW5jZVwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogbnVsbFxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJzaW5nbGVUb3VjaFN0YXJ0XCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiBudWxsXG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImxhc3RTaW5nbGVUb3VjaFwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogbnVsbFxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJpc0l0ZW1JbnRlcmFjdGlvblwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogITFcbiAgICB9KSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwiaGFuZGxlUG9pbnRlclN0YXJ0XCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiAocykgPT4ge1xuICAgICAgICBzLnBvaW50ZXJUeXBlID09PSBcInRvdWNoXCIgPyB0aGlzLmhhbmRsZVRvdWNoU3RhcnQocykgOiBzLnBvaW50ZXJUeXBlID09PSBcIm1vdXNlXCIgJiYgdGhpcy5oYW5kbGVNb3VzZURvd24ocyk7XG4gICAgICB9XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImhhbmRsZVBvaW50ZXJNb3ZlXCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiAocykgPT4ge1xuICAgICAgICBzLnBvaW50ZXJUeXBlID09PSBcInRvdWNoXCIgPyB0aGlzLmhhbmRsZVRvdWNoTW92ZShzKSA6IHMucG9pbnRlclR5cGUgPT09IFwibW91c2VcIiAmJiB0aGlzLmhhbmRsZU1vdXNlTW92ZShzKTtcbiAgICAgIH1cbiAgICB9KSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwiaGFuZGxlUG9pbnRlckVuZFwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKHMpID0+IHtcbiAgICAgICAgcy5wb2ludGVyVHlwZSA9PT0gXCJ0b3VjaFwiID8gdGhpcy5oYW5kbGVUb3VjaEVuZCgpIDogcy5wb2ludGVyVHlwZSA9PT0gXCJtb3VzZVwiICYmIHRoaXMuaGFuZGxlTW91c2VVcCgpO1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJoYW5kbGVTY3JvbGxcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6ICgpID0+IHtcbiAgICAgICAgY29uc3QgcyA9IHRoaXMuc2Nyb2xsQ29tcG9uZW50UmVmLmN1cnJlbnQuc2Nyb2xsTGVmdDtcbiAgICAgICAgdGhpcy5wcm9wcy5vblNjcm9sbChzKTtcbiAgICAgIH1cbiAgICB9KSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwiaGFuZGxlV2hlZWxcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IChzKSA9PiB7XG4gICAgICAgIGlmIChzLmN0cmxLZXkgfHwgcy5tZXRhS2V5IHx8IHMuYWx0S2V5KSB7XG4gICAgICAgICAgcy5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIGNvbnN0IHUgPSBIbihzLmN1cnJlbnRUYXJnZXQpLCB2ID0gcy5jbGllbnRYIC0gdS54LCBmID0gcy5jdHJsS2V5ID8gMTAgOiBzLm1ldGFLZXkgPyAzIDogMTtcbiAgICAgICAgICB0aGlzLnByb3BzLm9uV2hlZWxab29tKGYsIHYsIHMuZGVsdGFZKTtcbiAgICAgICAgfSBlbHNlIHMuc2hpZnRLZXkgJiYgKHMucHJldmVudERlZmF1bHQoKSwgdGhpcy5wcm9wcy5vblNjcm9sbCh0aGlzLnNjcm9sbENvbXBvbmVudFJlZi5jdXJyZW50LnNjcm9sbExlZnQgKyAocy5kZWx0YVkgfHwgcy5kZWx0YVgpKSk7XG4gICAgICB9XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImhhbmRsZU1vdXNlRG93blwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKHMpID0+IHtcbiAgICAgICAgcy5idXR0b24gPT09IDAgJiYgKHRoaXMuZHJhZ0xhc3RQb3NpdGlvbiA9IHMucGFnZVgsIHRoaXMuc2V0U3RhdGUoe1xuICAgICAgICAgIGlzRHJhZ2dpbmc6ICEwXG4gICAgICAgIH0pKTtcbiAgICAgIH1cbiAgICB9KSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwiaGFuZGxlTW91c2VNb3ZlXCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiAocykgPT4ge1xuICAgICAgICB0aGlzLnN0YXRlLmlzRHJhZ2dpbmcgJiYgIXRoaXMuaXNJdGVtSW50ZXJhY3Rpb24gJiYgKHRoaXMucHJvcHMub25TY3JvbGwodGhpcy5zY3JvbGxDb21wb25lbnRSZWYuY3VycmVudC5zY3JvbGxMZWZ0ICsgdGhpcy5kcmFnTGFzdFBvc2l0aW9uIC0gcy5wYWdlWCksIHRoaXMuZHJhZ0xhc3RQb3NpdGlvbiA9IHMucGFnZVgpO1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJoYW5kbGVNb3VzZVVwXCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiAoKSA9PiB7XG4gICAgICAgIHRoaXMuZHJhZ0xhc3RQb3NpdGlvbiA9IG51bGwsIHRoaXMuc2V0U3RhdGUoe1xuICAgICAgICAgIGlzRHJhZ2dpbmc6ICExXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJoYW5kbGVQb2ludGVyTGVhdmVcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IChzKSA9PiB7XG4gICAgICAgIHMucG9pbnRlclR5cGUgPT09IFwibW91c2VcIiAmJiAodGhpcy5kcmFnTGFzdFBvc2l0aW9uID0gbnVsbCwgdGhpcy5zZXRTdGF0ZSh7XG4gICAgICAgICAgaXNEcmFnZ2luZzogITFcbiAgICAgICAgfSkpO1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJoYW5kbGVUb3VjaFN0YXJ0XCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiAocykgPT4ge1xuICAgICAgICBzLmlzUHJpbWFyeSA/IChzLnByZXZlbnREZWZhdWx0KCksIHRoaXMubGFzdFRvdWNoRGlzdGFuY2UgPSBudWxsLCB0aGlzLnNpbmdsZVRvdWNoU3RhcnQgPSB7IHg6IHMuY2xpZW50WCwgeTogcy5jbGllbnRZLCBzY3JlZW5ZOiB3aW5kb3cuc2Nyb2xsWSB9LCB0aGlzLmxhc3RTaW5nbGVUb3VjaCA9IHsgeDogcy5jbGllbnRYLCB5OiBzLmNsaWVudFksIHNjcmVlblk6IHdpbmRvdy5zY3JvbGxZIH0pIDogKHMucHJldmVudERlZmF1bHQoKSwgdGhpcy5sYXN0VG91Y2hEaXN0YW5jZSA9IE1hdGguYWJzKHMuY2xpZW50WCAtIHRoaXMuc2luZ2xlVG91Y2hTdGFydC54KSwgdGhpcy5zaW5nbGVUb3VjaFN0YXJ0ID0gbnVsbCwgdGhpcy5sYXN0U2luZ2xlVG91Y2ggPSBudWxsKTtcbiAgICAgIH1cbiAgICB9KSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwiaGFuZGxlVG91Y2hNb3ZlXCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiAocykgPT4ge1xuICAgICAgICBjb25zdCB7IHdpZHRoOiB1LCBvblpvb206IHYgfSA9IHRoaXMucHJvcHM7XG4gICAgICAgIGlmICh0aGlzLmlzSXRlbUludGVyYWN0aW9uKSB7XG4gICAgICAgICAgcy5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5sYXN0VG91Y2hEaXN0YW5jZSAmJiAhcy5pc1ByaW1hcnkpIHtcbiAgICAgICAgICBzLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgY29uc3QgZiA9IE1hdGguYWJzKHMuY2xpZW50WCAtIHRoaXMuc2luZ2xlVG91Y2hTdGFydC54KSwgbSA9IEhuKHMuY3VycmVudFRhcmdldCksIHkgPSAocy5jbGllbnRYICsgdGhpcy5zaW5nbGVUb3VjaFN0YXJ0LngpIC8gMiAtIG0ueDtcbiAgICAgICAgICBmICE9PSAwICYmIHRoaXMubGFzdFRvdWNoRGlzdGFuY2UgIT09IDAgJiYgKHYodGhpcy5sYXN0VG91Y2hEaXN0YW5jZSAvIGYsIHkgLyB1KSwgdGhpcy5sYXN0VG91Y2hEaXN0YW5jZSA9IGYpO1xuICAgICAgICB9IGVsc2UgaWYgKHRoaXMubGFzdFNpbmdsZVRvdWNoICYmIHMuaXNQcmltYXJ5KSB7XG4gICAgICAgICAgcy5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIGNvbnN0IGYgPSBzLmNsaWVudFgsIG0gPSBzLmNsaWVudFksIHkgPSBmIC0gdGhpcy5sYXN0U2luZ2xlVG91Y2gueCwgUyA9IGYgLSB0aGlzLnNpbmdsZVRvdWNoU3RhcnQueCwgQyA9IG0gLSB0aGlzLnNpbmdsZVRvdWNoU3RhcnQueTtcbiAgICAgICAgICB0aGlzLmxhc3RTaW5nbGVUb3VjaCA9IHsgeDogZiwgeTogbSwgc2NyZWVuWTogd2luZG93LnBhZ2VZT2Zmc2V0IH07XG4gICAgICAgICAgY29uc3QgRCA9IE1hdGguYWJzKFMpICogMyA+IE1hdGguYWJzKEMpLCBSID0gTWF0aC5hYnMoQykgKiAzID4gTWF0aC5hYnMoUyk7XG4gICAgICAgICAgeSAhPT0gMCAmJiBEICYmIHRoaXMucHJvcHMub25TY3JvbGwodGhpcy5zY3JvbGxDb21wb25lbnRSZWYuY3VycmVudC5zY3JvbGxMZWZ0IC0geSksIFIgJiYgd2luZG93LnNjcm9sbFRvKHdpbmRvdy5zY3JvbGxYLCB0aGlzLnNpbmdsZVRvdWNoU3RhcnQuc2NyZWVuWSAtIEMpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImhhbmRsZVRvdWNoRW5kXCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiAoKSA9PiB7XG4gICAgICAgIHRoaXMubGFzdFRvdWNoRGlzdGFuY2UgJiYgKHRoaXMubGFzdFRvdWNoRGlzdGFuY2UgPSBudWxsKSwgdGhpcy5sYXN0U2luZ2xlVG91Y2ggJiYgKHRoaXMubGFzdFNpbmdsZVRvdWNoID0gbnVsbCwgdGhpcy5zaW5nbGVUb3VjaFN0YXJ0ID0gbnVsbCk7XG4gICAgICB9XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImhhbmRsZUl0ZW1JbnRlcmFjdFwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKHMpID0+IHtcbiAgICAgICAgdGhpcy5pc0l0ZW1JbnRlcmFjdGlvbiA9IHMuZGV0YWlsLml0ZW1JbnRlcmFjdGlvbjtcbiAgICAgIH1cbiAgICB9KSwgdGhpcy5zdGF0ZSA9IHtcbiAgICAgIGlzRHJhZ2dpbmc6ICExXG4gICAgfTtcbiAgfVxuICBjb21wb25lbnREaWRNb3VudCgpIHtcbiAgICB0aGlzLnNjcm9sbENvbXBvbmVudFJlZi5jdXJyZW50ICYmICh0aGlzLnByb3BzLnNjcm9sbFJlZih0aGlzLnNjcm9sbENvbXBvbmVudFJlZi5jdXJyZW50KSwgdGhpcy5zY3JvbGxDb21wb25lbnRSZWYuY3VycmVudC5hZGRFdmVudExpc3RlbmVyKFwid2hlZWxcIiwgdGhpcy5oYW5kbGVXaGVlbCwgeyBwYXNzaXZlOiAhMSB9KSwgdGhpcy5zY3JvbGxDb21wb25lbnRSZWYuY3VycmVudC5hZGRFdmVudExpc3RlbmVyKFwiaXRlbUludGVyYWN0aW9uXCIsIHRoaXMuaGFuZGxlSXRlbUludGVyYWN0KSwgdGhpcy5zY3JvbGxDb21wb25lbnRSZWYuY3VycmVudC5hZGRFdmVudExpc3RlbmVyKFwicG9pbnRlcmRvd25cIiwgdGhpcy5oYW5kbGVQb2ludGVyU3RhcnQsIHsgcGFzc2l2ZTogITEgfSksIHRoaXMuc2Nyb2xsQ29tcG9uZW50UmVmLmN1cnJlbnQuYWRkRXZlbnRMaXN0ZW5lcihcInBvaW50ZXJtb3ZlXCIsIHRoaXMuaGFuZGxlUG9pbnRlck1vdmUsIHsgcGFzc2l2ZTogITEgfSksIHRoaXMuc2Nyb2xsQ29tcG9uZW50UmVmLmN1cnJlbnQuYWRkRXZlbnRMaXN0ZW5lcihcInBvaW50ZXJ1cFwiLCB0aGlzLmhhbmRsZVBvaW50ZXJFbmQpLCB0aGlzLnNjcm9sbENvbXBvbmVudFJlZi5jdXJyZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJwb2ludGVybGVhdmVcIiwgdGhpcy5oYW5kbGVQb2ludGVyTGVhdmUpKTtcbiAgfVxuICBjb21wb25lbnRXaWxsVW5tb3VudCgpIHtcbiAgICB0aGlzLnNjcm9sbENvbXBvbmVudFJlZi5jdXJyZW50ICYmICh0aGlzLnNjcm9sbENvbXBvbmVudFJlZi5jdXJyZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJ3aGVlbFwiLCB0aGlzLmhhbmRsZVdoZWVsKSwgdGhpcy5zY3JvbGxDb21wb25lbnRSZWYuY3VycmVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwiaXRlbUludGVyYWN0aW9uXCIsIHRoaXMuaGFuZGxlSXRlbUludGVyYWN0KSwgdGhpcy5zY3JvbGxDb21wb25lbnRSZWYuY3VycmVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwicG9pbnRlcmRvd25cIiwgdGhpcy5oYW5kbGVQb2ludGVyU3RhcnQpLCB0aGlzLnNjcm9sbENvbXBvbmVudFJlZi5jdXJyZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJwb2ludGVybW92ZVwiLCB0aGlzLmhhbmRsZVBvaW50ZXJNb3ZlKSwgdGhpcy5zY3JvbGxDb21wb25lbnRSZWYuY3VycmVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwicG9pbnRlcnVwXCIsIHRoaXMuaGFuZGxlUG9pbnRlckVuZCksIHRoaXMuc2Nyb2xsQ29tcG9uZW50UmVmLmN1cnJlbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInBvaW50ZXJsZWF2ZVwiLCB0aGlzLmhhbmRsZVBvaW50ZXJMZWF2ZSkpO1xuICB9XG4gIHJlbmRlcigpIHtcbiAgICBjb25zdCB7IHdpZHRoOiBpLCBoZWlnaHQ6IHMsIGNoaWxkcmVuOiB1IH0gPSB0aGlzLnByb3BzLCB7IGlzRHJhZ2dpbmc6IHYgfSA9IHRoaXMuc3RhdGUsIGYgPSB7XG4gICAgICB3aWR0aDogYCR7aX1weGAsXG4gICAgICBoZWlnaHQ6IGAke3MgKyAyMH1weGAsXG4gICAgICAvLzIwcHggdG8gcHVzaCB0aGUgc2Nyb2xsIGVsZW1lbnQgZG93biBvZmYgc2NyZWVuLi4uP1xuICAgICAgY3Vyc29yOiB2ID8gXCJtb3ZlXCIgOiBcImRlZmF1bHRcIixcbiAgICAgIHBvc2l0aW9uOiBcInJlbGF0aXZlXCJcbiAgICB9O1xuICAgIHJldHVybiBqKFwiZGl2XCIsIHsgcmVmOiB0aGlzLnNjcm9sbENvbXBvbmVudFJlZiwgXCJkYXRhLXRlc3RpZFwiOiBcInNjcm9sbC1lbGVtZW50XCIsIGNsYXNzTmFtZTogXCJyY3Qtc2Nyb2xsXCIsIHN0eWxlOiBmLCBvblNjcm9sbDogdGhpcy5oYW5kbGVTY3JvbGwsIGNoaWxkcmVuOiB1IH0pO1xuICB9XG59XG5jb25zdCB4ZCA9IHtcbiAgc3Vic2NyaWJlVG9Nb3VzZU92ZXI6ICgpID0+IChjb25zb2xlLndhcm4oJ1wic3Vic2NyaWJlVG9Nb3VzZU92ZXJcIiBkZWZhdWx0IGZ1bmMgaXMgYmVpbmcgdXNlZCcpLCAoKSA9PiB7XG4gIH0pXG59LCB7IENvbnN1bWVyOiBTZCwgUHJvdmlkZXI6IE9kIH0gPSBaLmNyZWF0ZUNvbnRleHQoeGQpLCBDZCA9IE9kLCBFZCA9IFNkLCBfZCA9IHtcbiAgbWFya2VyczogW10sXG4gIHN1YnNjcmliZU1hcmtlcjogKCkgPT4gKGNvbnNvbGUud2FybihcImRlZmF1bHQgc3Vic2NyaWJlIG1hcmtlciB1c2VkXCIpLCB7XG4gICAgdW5zdWJzY3JpYmU6IHd0LFxuICAgIGdldE1hcmtlcjogd3RcbiAgfSksXG4gIHVwZGF0ZU1hcmtlcjogKCkgPT4gKGNvbnNvbGUud2FybihcImRlZmF1bHQgc3Vic2NyaWJlIG1hcmtlciB1c2VkXCIpLCB3dClcbn0sIHsgQ29uc3VtZXI6IFBkLCBQcm92aWRlcjogSWQgfSA9IFouY3JlYXRlQ29udGV4dChfZCk7XG5sZXQgdmkgPSAwO1xuY29uc3QgTWQgPSAoKSA9PiAodmkgKz0gMSwgdmkgKyAxKTtcbmNsYXNzIFJkIGV4dGVuZHMgWi5Db21wb25lbnQge1xuICBjb25zdHJ1Y3RvcihpKSB7XG4gICAgc3VwZXIoaSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImhhbmRsZVN1YnNjcmliZVRvTWFya2VyXCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiAocykgPT4gKHMgPSB7XG4gICAgICAgIC4uLnMsXG4gICAgICAgIC8vIFJFVklFVzogaW4gdGhlIGV2ZW50IHRoYXQgd2UgYWNjZXB0IGlkIHRvIGJlIHBhc3NlZCB0byB0aGUgTWFya2VyIGNvbXBvbmVudHMsIHRoaXMgbGluZSB3b3VsZCBvdmVycmlkZSB0aG9zZVxuICAgICAgICBpZDogTWQoKVxuICAgICAgfSwgdGhpcy5zZXRTdGF0ZSgodSkgPT4gKHtcbiAgICAgICAgbWFya2VyczogWy4uLnUubWFya2Vycywgc11cbiAgICAgIH0pKSwge1xuICAgICAgICB1bnN1YnNjcmliZTogKCkgPT4ge1xuICAgICAgICAgIHRoaXMuc2V0U3RhdGUoKHUpID0+ICh7XG4gICAgICAgICAgICBtYXJrZXJzOiB1Lm1hcmtlcnMuZmlsdGVyKCh2KSA9PiB2LmlkICE9PSBzLmlkKVxuICAgICAgICAgIH0pKTtcbiAgICAgICAgfSxcbiAgICAgICAgZ2V0TWFya2VyOiAoKSA9PiBzXG4gICAgICB9KVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJoYW5kbGVVcGRhdGVNYXJrZXJcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IChzKSA9PiB7XG4gICAgICAgIGNvbnN0IHUgPSB0aGlzLnN0YXRlLm1hcmtlcnMuZmluZEluZGV4KCh2KSA9PiB2LmlkID09PSBzLmlkKTtcbiAgICAgICAgdSA8IDAgfHwgdGhpcy5zZXRTdGF0ZSgodikgPT4gKHtcbiAgICAgICAgICBtYXJrZXJzOiBbXG4gICAgICAgICAgICAuLi52Lm1hcmtlcnMuc2xpY2UoMCwgdSksXG4gICAgICAgICAgICBzLFxuICAgICAgICAgICAgLi4udi5tYXJrZXJzLnNsaWNlKHUgKyAxKVxuICAgICAgICAgIF1cbiAgICAgICAgfSkpO1xuICAgICAgfVxuICAgIH0pLCB0aGlzLnN0YXRlID0ge1xuICAgICAgbWFya2VyczogW10sXG4gICAgICBzdWJzY3JpYmVNYXJrZXI6IHRoaXMuaGFuZGxlU3Vic2NyaWJlVG9NYXJrZXIsXG4gICAgICB1cGRhdGVNYXJrZXI6IHRoaXMuaGFuZGxlVXBkYXRlTWFya2VyXG4gICAgfTtcbiAgfVxuICByZW5kZXIoKSB7XG4gICAgcmV0dXJuIGooSWQsIHsgdmFsdWU6IHRoaXMuc3RhdGUsIGNoaWxkcmVuOiB0aGlzLnByb3BzLmNoaWxkcmVuIH0pO1xuICB9XG59XG5jb25zdCBIdCA9IFBkO1xudmFyIHhlO1xuKGZ1bmN0aW9uKGEpIHtcbiAgYS5Ub2RheSA9IFwiVG9kYXlcIiwgYS5DdXN0b20gPSBcIkN1c3RvbVwiLCBhLkN1cnNvciA9IFwiQ3Vyc29yXCI7XG59KSh4ZSB8fCAoeGUgPSB7fSkpO1xuY29uc3QgRGQgPSB7XG4gIHBvc2l0aW9uOiBcImFic29sdXRlXCIsXG4gIHRvcDogMCxcbiAgYm90dG9tOiAwLFxuICB3aWR0aDogXCIycHhcIixcbiAgYmFja2dyb3VuZENvbG9yOiBcImJsYWNrXCIsXG4gIC8vIGJ5IGRlZmF1bHQsIHBvaW50ZXIgZXZlbnRzIChzcGVjaWZpY2FsbHkgY2xpY2spIHdpbGxcbiAgLy8gXCJwYXNzIHRocm91Z2hcIi4gIFRoaXMgaXMgYWRkZWQgc28gdGhhdCBDdXJzb3JNYXJrZXJcbiAgLy8gd2lsbCBub3QgZ2V0IGluIHRoZSB3YXkgb2YgY2FudmFzIGNsaWNrXG4gIHBvaW50ZXJFdmVudHM6IFwibm9uZVwiXG59LCBMciA9IChhKSA9PiAoe1xuICAuLi5EZCxcbiAgbGVmdDogYVxufSksIEhyID0gKGEpID0+IGZ1bmN0aW9uKHsgc3R5bGVzOiBzIH0pIHtcbiAgcmV0dXJuIGooXCJkaXZcIiwgeyBzdHlsZTogcywgXCJkYXRhLXRlc3RpZFwiOiBhIH0pO1xufSwga2QgPSBIcihcImRlZmF1bHQtdG9kYXktbGluZVwiKTtcbmxldCBWaSA9IGNsYXNzIGV4dGVuZHMgWi5Db21wb25lbnQge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlciguLi5hcmd1bWVudHMpLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJzdGF0ZVwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZToge1xuICAgICAgICBkYXRlOiBEYXRlLm5vdygpXG4gICAgICB9XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImludGVydmFsVG9rZW5cIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IHZvaWQgMFxuICAgIH0pO1xuICB9XG4gIGNvbXBvbmVudERpZE1vdW50KCkge1xuICAgIHRoaXMuaW50ZXJ2YWxUb2tlbiA9IHRoaXMuY3JlYXRlSW50ZXJ2YWxVcGRhdGVyKHRoaXMucHJvcHMuaW50ZXJ2YWwpO1xuICB9XG4gIGNvbXBvbmVudERpZFVwZGF0ZShpKSB7XG4gICAgaS5pbnRlcnZhbCAhPT0gdGhpcy5wcm9wcy5pbnRlcnZhbCAmJiAoY2xlYXJJbnRlcnZhbCh0aGlzLmludGVydmFsVG9rZW4pLCB0aGlzLmludGVydmFsVG9rZW4gPSB0aGlzLmNyZWF0ZUludGVydmFsVXBkYXRlcih0aGlzLnByb3BzLmludGVydmFsKSk7XG4gIH1cbiAgY3JlYXRlSW50ZXJ2YWxVcGRhdGVyKGkpIHtcbiAgICByZXR1cm4gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgdGhpcy5zZXRTdGF0ZSh7XG4gICAgICAgIGRhdGU6IERhdGUubm93KClcbiAgICAgICAgLy8gRklYTUU6IHVzZSBkYXRlIHV0aWxzIHBhc3MgaW4gYXMgcHJvcHNcbiAgICAgIH0pO1xuICAgIH0sIGkpO1xuICB9XG4gIGNvbXBvbmVudFdpbGxVbm1vdW50KCkge1xuICAgIGNsZWFySW50ZXJ2YWwodGhpcy5pbnRlcnZhbFRva2VuKTtcbiAgfVxuICByZW5kZXIoKSB7XG4gICAgY29uc3QgeyBkYXRlOiBpIH0gPSB0aGlzLnN0YXRlLCBzID0gdGhpcy5wcm9wcy5nZXRMZWZ0T2Zmc2V0RnJvbURhdGUoaSksIHUgPSBMcihzKTtcbiAgICByZXR1cm4gdGhpcy5wcm9wcy5yZW5kZXJlcih7IHN0eWxlczogdSwgZGF0ZTogaSB9KTtcbiAgfVxufTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShWaSwgXCJkZWZhdWx0UHJvcHNcIiwge1xuICBlbnVtZXJhYmxlOiAhMCxcbiAgY29uZmlndXJhYmxlOiAhMCxcbiAgd3JpdGFibGU6ICEwLFxuICB2YWx1ZToge1xuICAgIHJlbmRlcmVyOiBrZFxuICB9XG59KTtcbmNvbnN0IHpkID0gSHIoXCJkZWZhdWx0LWN1c3RvbWVyLW1hcmtlci1pZFwiKTtcbmxldCBxaSA9IGNsYXNzIGV4dGVuZHMgWi5Db21wb25lbnQge1xuICByZW5kZXIoKSB7XG4gICAgY29uc3QgeyBkYXRlOiBpIH0gPSB0aGlzLnByb3BzLCBzID0gdGhpcy5wcm9wcy5nZXRMZWZ0T2Zmc2V0RnJvbURhdGUoaSksIHUgPSBMcihzKTtcbiAgICByZXR1cm4gdGhpcy5wcm9wcy5yZW5kZXJlcih7IHN0eWxlczogdSwgZGF0ZTogaSB9KTtcbiAgfVxufTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShxaSwgXCJkZWZhdWx0UHJvcHNcIiwge1xuICBlbnVtZXJhYmxlOiAhMCxcbiAgY29uZmlndXJhYmxlOiAhMCxcbiAgd3JpdGFibGU6ICEwLFxuICB2YWx1ZToge1xuICAgIHJlbmRlcmVyOiB6ZFxuICB9XG59KTtcbmNvbnN0ICRkID0gSHIoXCJkZWZhdWx0LWN1cnNvci1tYXJrZXJcIik7XG5sZXQgWmkgPSBjbGFzcyBleHRlbmRzIFouQ29tcG9uZW50IHtcbiAgY29uc3RydWN0b3IoaSkge1xuICAgIHN1cGVyKGkpLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJoYW5kbGVDYW52YXNNb3VzZU92ZXJcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6ICh7IGxlZnRPZmZzZXQ6IHMsIGRhdGU6IHUsIGlzQ3Vyc29yT3ZlckNhbnZhczogdiB9KSA9PiB7XG4gICAgICAgIHRoaXMuc2V0U3RhdGUoe1xuICAgICAgICAgIGxlZnRPZmZzZXQ6IHMsXG4gICAgICAgICAgZGF0ZTogdSxcbiAgICAgICAgICBpc1Nob3dpbmdDdXJzb3I6IHZcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcInVuc3Vic2NyaWJlXCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiB2b2lkIDBcbiAgICB9KSwgdGhpcy5zdGF0ZSA9IHtcbiAgICAgIGxlZnRPZmZzZXQ6IDAsXG4gICAgICBkYXRlOiAwLFxuICAgICAgaXNTaG93aW5nQ3Vyc29yOiAhMVxuICAgIH07XG4gIH1cbiAgY29tcG9uZW50RGlkTW91bnQoKSB7XG4gICAgdGhpcy51bnN1YnNjcmliZSA9IHRoaXMucHJvcHMuc3Vic2NyaWJlVG9DYW52YXNNb3VzZU92ZXIodGhpcy5oYW5kbGVDYW52YXNNb3VzZU92ZXIpO1xuICB9XG4gIGNvbXBvbmVudFdpbGxVbm1vdW50KCkge1xuICAgIHRoaXMudW5zdWJzY3JpYmUgJiYgKHRoaXMudW5zdWJzY3JpYmUoKSwgdGhpcy51bnN1YnNjcmliZSA9IHZvaWQgMCk7XG4gIH1cbiAgcmVuZGVyKCkge1xuICAgIGNvbnN0IHsgaXNTaG93aW5nQ3Vyc29yOiBpLCBsZWZ0T2Zmc2V0OiBzLCBkYXRlOiB1IH0gPSB0aGlzLnN0YXRlO1xuICAgIGlmICghaSlcbiAgICAgIHJldHVybiBudWxsO1xuICAgIGNvbnN0IHYgPSBMcihzKTtcbiAgICByZXR1cm4gdGhpcy5wcm9wcy5yZW5kZXJlciA/IHRoaXMucHJvcHMucmVuZGVyZXIoeyBzdHlsZXM6IHYsIGRhdGU6IHUgfSkgOiBudWxsO1xuICB9XG59O1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KFppLCBcImRlZmF1bHRQcm9wc1wiLCB7XG4gIGVudW1lcmFibGU6ICEwLFxuICBjb25maWd1cmFibGU6ICEwLFxuICB3cml0YWJsZTogITAsXG4gIHZhbHVlOiB7XG4gICAgcmVuZGVyZXI6ICRkXG4gIH1cbn0pO1xuY29uc3QgSmkgPSAoYSkgPT4gaihFZCwgeyBjaGlsZHJlbjogKHsgc3Vic2NyaWJlVG9Nb3VzZU92ZXI6IGkgfSkgPT4gaihaaSwgeyBzdWJzY3JpYmVUb0NhbnZhc01vdXNlT3ZlcjogaSwgLi4uYSB9KSB9KTtcbkppLmRpc3BsYXlOYW1lID0gXCJDdXJzb3JNYXJrZXJXcmFwcGVyXCI7XG5jb25zdCBqZCA9ICgpID0+IGooTHQsIHsgY2hpbGRyZW46ICh7IGdldExlZnRPZmZzZXRGcm9tRGF0ZTogYSwgZ2V0VGltZWxpbmVTdGF0ZTogaSB9KSA9PiBqKEh0LCB7IGNoaWxkcmVuOiAoeyBtYXJrZXJzOiBzIH0pID0+IHtcbiAgY29uc3QgdSA9IGkoKTtcbiAgcmV0dXJuIHMubWFwKCh2KSA9PiB7XG4gICAgc3dpdGNoICh2LnR5cGUpIHtcbiAgICAgIGNhc2UgeGUuVG9kYXk6XG4gICAgICAgIHJldHVybiAoLyogQF9fUFVSRV9fICovIG5ldyBEYXRlKCkpLnZhbHVlT2YoKSA+PSB1LmNhbnZhc1RpbWVTdGFydCAmJiAoLyogQF9fUFVSRV9fICovIG5ldyBEYXRlKCkpLnZhbHVlT2YoKSA8PSB1LmNhbnZhc1RpbWVFbmQgPyBqKFZpLCB7IGdldExlZnRPZmZzZXRGcm9tRGF0ZTogYSwgcmVuZGVyZXI6IHYucmVuZGVyZXIsIGludGVydmFsOiB2LmludGVydmFsIH0sIHYuaWQpIDogbnVsbDtcbiAgICAgIGNhc2UgeGUuQ3VzdG9tOlxuICAgICAgICByZXR1cm4gdi5kYXRlID49IHUuY2FudmFzVGltZVN0YXJ0ICYmIHYuZGF0ZSA8PSB1LmNhbnZhc1RpbWVFbmQgPyBqKHFpLCB7IHJlbmRlcmVyOiB2LnJlbmRlcmVyLCBkYXRlOiB2LmRhdGUsIGdldExlZnRPZmZzZXRGcm9tRGF0ZTogYSB9LCB2LmlkKSA6IG51bGw7XG4gICAgICBjYXNlIHhlLkN1cnNvcjpcbiAgICAgICAgcmV0dXJuIGooSmksIHsgcmVuZGVyZXI6IHYucmVuZGVyZXIsIGdldExlZnRPZmZzZXRGcm9tRGF0ZTogYSB9LCB2LmlkKTtcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgfSk7XG59IH0pIH0pLCBBZCA9IHtcbiAgcG9zaXRpb246IFwiYWJzb2x1dGVcIixcbiAgbGVmdDogMCxcbiAgcmlnaHQ6IDAsXG4gIHRvcDogMCxcbiAgYm90dG9tOiAwXG59O1xuY2xhc3MgTGQgZXh0ZW5kcyBaLkNvbXBvbmVudCB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKC4uLmFyZ3VtZW50cyksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImhhbmRsZU1vdXNlTW92ZVwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKGkpID0+IHtcbiAgICAgICAgdmFyIHM7XG4gICAgICAgIGlmICh0aGlzLnN1YnNjcmlwdGlvbiAhPT0gbnVsbCkge1xuICAgICAgICAgIGNvbnN0IHsgcGFnZVg6IHUgfSA9IGksIHsgbGVmdDogdiB9ID0gKChzID0gdGhpcy5jb250YWluZXJFbC5jdXJyZW50KSA9PSBudWxsID8gdm9pZCAwIDogcy5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSkgPz8ge1xuICAgICAgICAgICAgbGVmdDogMFxuICAgICAgICAgIH0sIGYgPSB1IC0gdiwgbSA9IHRoaXMucHJvcHMuZ2V0RGF0ZUZyb21MZWZ0T2Zmc2V0UG9zaXRpb24oZik7XG4gICAgICAgICAgdGhpcy5zdWJzY3JpcHRpb24oe1xuICAgICAgICAgICAgbGVmdE9mZnNldDogZixcbiAgICAgICAgICAgIGRhdGU6IG0sXG4gICAgICAgICAgICBpc0N1cnNvck92ZXJDYW52YXM6ICEwXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwiaGFuZGxlTW91c2VMZWF2ZVwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKCkgPT4ge1xuICAgICAgICB0aGlzLnN1YnNjcmlwdGlvbiAhPT0gbnVsbCAmJiB0aGlzLnN1YnNjcmlwdGlvbih7IGxlZnRPZmZzZXQ6IDAsIGRhdGU6IDAsIGlzQ3Vyc29yT3ZlckNhbnZhczogITEgfSk7XG4gICAgICB9XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImhhbmRsZU1vdXNlTW92ZVN1YnNjcmliZVwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKGkpID0+ICh0aGlzLnN1YnNjcmlwdGlvbiA9IGksICgpID0+IHtcbiAgICAgICAgdGhpcy5zdWJzY3JpcHRpb24gPSBudWxsO1xuICAgICAgfSlcbiAgICB9KSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwic3RhdGVcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IHtcbiAgICAgICAgc3Vic2NyaWJlVG9Nb3VzZU92ZXI6IHRoaXMuaGFuZGxlTW91c2VNb3ZlU3Vic2NyaWJlXG4gICAgICB9XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImNvbnRhaW5lckVsXCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiBaLmNyZWF0ZVJlZigpXG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcInN1YnNjcmlwdGlvblwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogbnVsbFxuICAgIH0pO1xuICB9XG4gIHJlbmRlcigpIHtcbiAgICByZXR1cm4gaihDZCwgeyB2YWx1ZTogdGhpcy5zdGF0ZSwgY2hpbGRyZW46IHplKFwiZGl2XCIsIHsgc3R5bGU6IEFkLCBvbk1vdXNlTW92ZTogdGhpcy5oYW5kbGVNb3VzZU1vdmUsIG9uTW91c2VMZWF2ZTogdGhpcy5oYW5kbGVNb3VzZUxlYXZlLCByZWY6IHRoaXMuY29udGFpbmVyRWwsIGNoaWxkcmVuOiBbaihqZCwge30pLCB0aGlzLnByb3BzLmNoaWxkcmVuXSB9KSB9KTtcbiAgfVxufVxuY29uc3QgSGQgPSAoYSkgPT4gaihMdCwgeyBjaGlsZHJlbjogKHsgZ2V0RGF0ZUZyb21MZWZ0T2Zmc2V0UG9zaXRpb246IGkgfSkgPT4gaihMZCwgeyBnZXREYXRlRnJvbUxlZnRPZmZzZXRQb3NpdGlvbjogaSwgLi4uYSB9KSB9KTtcbmZ1bmN0aW9uIFdkKGEpIHtcbiAgYS5fcmVzaXplRXZlbnRMaXN0ZW5lciA9ICgpID0+IGEucmVzaXplKCksIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwicmVzaXplXCIsIGEuX3Jlc2l6ZUV2ZW50TGlzdGVuZXIpO1xufVxuZnVuY3Rpb24gRmQoYSkge1xuICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInJlc2l6ZVwiLCBhLl9yZXNpemVFdmVudExpc3RlbmVyKTtcbn1cbmNvbnN0IGdpID0geyBhZGRMaXN0ZW5lcjogV2QsIHJlbW92ZUxpc3RlbmVyOiBGZCB9LCBVZCA9IHtcbiAgZ3JvdXBJZEtleTogXCJpZFwiLFxuICBncm91cFRpdGxlS2V5OiBcInRpdGxlXCIsXG4gIGdyb3VwUmlnaHRUaXRsZUtleTogXCJyaWdodFRpdGxlXCIsXG4gIGdyb3VwTGFiZWxLZXk6IFwidGl0bGVcIixcbiAgaXRlbUlkS2V5OiBcImlkXCIsXG4gIGl0ZW1UaXRsZUtleTogXCJ0aXRsZVwiLFxuICBpdGVtRGl2VGl0bGVLZXk6IFwidGl0bGVcIixcbiAgaXRlbUdyb3VwS2V5OiBcImdyb3VwXCIsXG4gIGl0ZW1UaW1lU3RhcnRLZXk6IFwic3RhcnRfdGltZVwiLFxuICBpdGVtVGltZUVuZEtleTogXCJlbmRfdGltZVwiXG59LCBOZCA9IHtcbiAgc2Vjb25kOiAxLFxuICBtaW51dGU6IDEsXG4gIGhvdXI6IDEsXG4gIGRheTogMSxcbiAgbW9udGg6IDEsXG4gIHllYXI6IDFcbn0sIEdkID0ge1xuICB5ZWFyOiB7XG4gICAgbG9uZzogXCJZWVlZXCIsXG4gICAgbWVkaXVtTG9uZzogXCJZWVlZXCIsXG4gICAgbWVkaXVtOiBcIllZWVlcIixcbiAgICBzaG9ydDogXCJZWVwiXG4gIH0sXG4gIG1vbnRoOiB7XG4gICAgbG9uZzogXCJNTU1NIFlZWVlcIixcbiAgICBtZWRpdW1Mb25nOiBcIk1NTU1cIixcbiAgICBtZWRpdW06IFwiTU1NTVwiLFxuICAgIHNob3J0OiBcIk1NL1lZXCJcbiAgfSxcbiAgd2Vlazoge1xuICAgIGxvbmc6IFwid1wiLFxuICAgIG1lZGl1bUxvbmc6IFwid1wiLFxuICAgIG1lZGl1bTogXCJ3XCIsXG4gICAgc2hvcnQ6IFwid1wiXG4gIH0sXG4gIGRheToge1xuICAgIGxvbmc6IFwiZGRkZCwgTExcIixcbiAgICBtZWRpdW1Mb25nOiBcImRkZGQsIExMXCIsXG4gICAgbWVkaXVtOiBcImRkIERcIixcbiAgICBzaG9ydDogXCJEXCJcbiAgfSxcbiAgaG91cjoge1xuICAgIGxvbmc6IFwiZGRkZCwgTEwsIEhIOjAwXCIsXG4gICAgbWVkaXVtTG9uZzogXCJMLCBISDowMFwiLFxuICAgIG1lZGl1bTogXCJISDowMFwiLFxuICAgIHNob3J0OiBcIkhIXCJcbiAgfSxcbiAgbWludXRlOiB7XG4gICAgbG9uZzogXCJISDptbVwiLFxuICAgIG1lZGl1bUxvbmc6IFwiSEg6bW1cIixcbiAgICBtZWRpdW06IFwiSEg6bW1cIixcbiAgICBzaG9ydDogXCJtbVwiXG4gIH0sXG4gIHNlY29uZDoge1xuICAgIGxvbmc6IFwibW06c3NcIixcbiAgICBtZWRpdW1Mb25nOiBcIm1tOnNzXCIsXG4gICAgbWVkaXVtOiBcIm1tOnNzXCIsXG4gICAgc2hvcnQ6IFwic3NcIlxuICB9XG59LCBZZCA9IHtcbiAgcmVnaXN0ZXJTY3JvbGw6ICgpID0+IChjb25zb2xlLndhcm4oXCJkZWZhdWx0IHJlZ2lzdGVyU2Nyb2xsIGhlYWRlciB1c2VkXCIpLCB3dCksXG4gIHJpZ2h0U2lkZWJhcldpZHRoOiAwLFxuICBsZWZ0U2lkZWJhcldpZHRoOiAxNTAsXG4gIHRpbWVTdGVwczoge31cbn0sIFFpID0gWi5jcmVhdGVDb250ZXh0KFlkKTtcbmNsYXNzIEtkIGV4dGVuZHMgWi5Db21wb25lbnQge1xuICByZW5kZXIoKSB7XG4gICAgY29uc3QgaSA9IHtcbiAgICAgIHJpZ2h0U2lkZWJhcldpZHRoOiB0aGlzLnByb3BzLnJpZ2h0U2lkZWJhcldpZHRoLFxuICAgICAgbGVmdFNpZGViYXJXaWR0aDogdGhpcy5wcm9wcy5sZWZ0U2lkZWJhcldpZHRoLFxuICAgICAgdGltZVN0ZXBzOiB0aGlzLnByb3BzLnRpbWVTdGVwcyxcbiAgICAgIHJlZ2lzdGVyU2Nyb2xsOiB0aGlzLnByb3BzLnJlZ2lzdGVyU2Nyb2xsXG4gICAgfTtcbiAgICByZXR1cm4gaihRaS5Qcm92aWRlciwgeyB2YWx1ZTogaSwgY2hpbGRyZW46IHRoaXMucHJvcHMuY2hpbGRyZW4gfSk7XG4gIH1cbn1cbmNvbnN0IFhkID0gUWksIFdyID0gKCkgPT4gd2koWGQpO1xudmFyIGVvID0geyBleHBvcnRzOiB7fSB9O1xuLyohXG5cdENvcHlyaWdodCAoYykgMjAxOCBKZWQgV2F0c29uLlxuXHRMaWNlbnNlZCB1bmRlciB0aGUgTUlUIExpY2Vuc2UgKE1JVCksIHNlZVxuXHRodHRwOi8vamVkd2F0c29uLmdpdGh1Yi5pby9jbGFzc25hbWVzXG4qL1xuKGZ1bmN0aW9uKGEpIHtcbiAgKGZ1bmN0aW9uKCkge1xuICAgIHZhciBpID0ge30uaGFzT3duUHJvcGVydHk7XG4gICAgZnVuY3Rpb24gcygpIHtcbiAgICAgIGZvciAodmFyIGYgPSBcIlwiLCBtID0gMDsgbSA8IGFyZ3VtZW50cy5sZW5ndGg7IG0rKykge1xuICAgICAgICB2YXIgeSA9IGFyZ3VtZW50c1ttXTtcbiAgICAgICAgeSAmJiAoZiA9IHYoZiwgdSh5KSkpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGY7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHUoZikge1xuICAgICAgaWYgKHR5cGVvZiBmID09IFwic3RyaW5nXCIgfHwgdHlwZW9mIGYgPT0gXCJudW1iZXJcIilcbiAgICAgICAgcmV0dXJuIGY7XG4gICAgICBpZiAodHlwZW9mIGYgIT0gXCJvYmplY3RcIilcbiAgICAgICAgcmV0dXJuIFwiXCI7XG4gICAgICBpZiAoQXJyYXkuaXNBcnJheShmKSlcbiAgICAgICAgcmV0dXJuIHMuYXBwbHkobnVsbCwgZik7XG4gICAgICBpZiAoZi50b1N0cmluZyAhPT0gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZyAmJiAhZi50b1N0cmluZy50b1N0cmluZygpLmluY2x1ZGVzKFwiW25hdGl2ZSBjb2RlXVwiKSlcbiAgICAgICAgcmV0dXJuIGYudG9TdHJpbmcoKTtcbiAgICAgIHZhciBtID0gXCJcIjtcbiAgICAgIGZvciAodmFyIHkgaW4gZilcbiAgICAgICAgaS5jYWxsKGYsIHkpICYmIGZbeV0gJiYgKG0gPSB2KG0sIHkpKTtcbiAgICAgIHJldHVybiBtO1xuICAgIH1cbiAgICBmdW5jdGlvbiB2KGYsIG0pIHtcbiAgICAgIHJldHVybiBtID8gZiA/IGYgKyBcIiBcIiArIG0gOiBmICsgbSA6IGY7XG4gICAgfVxuICAgIGEuZXhwb3J0cyA/IChzLmRlZmF1bHQgPSBzLCBhLmV4cG9ydHMgPSBzKSA6IHdpbmRvdy5jbGFzc05hbWVzID0gcztcbiAgfSkoKTtcbn0pKGVvKTtcbnZhciBCZCA9IGVvLmV4cG9ydHM7XG5jb25zdCBtaSA9IC8qIEBfX1BVUkVfXyAqLyBydChCZCksIFZkID0gXCJsZWZ0XCIsIHRvID0gXCJyaWdodFwiO1xuY2xhc3MgcWQgZXh0ZW5kcyBUcyB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKC4uLmFyZ3VtZW50cyksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImdldFJvb3RQcm9wc1wiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKGkgPSB7fSkgPT4ge1xuICAgICAgICBjb25zdCB7IHN0eWxlOiBzIH0gPSBpLCB1ID0gdGhpcy5wcm9wcy52YXJpYW50ID09PSB0byA/IHRoaXMucHJvcHMucmlnaHRTaWRlYmFyV2lkdGggOiB0aGlzLnByb3BzLmxlZnRTaWRlYmFyV2lkdGg7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgc3R5bGU6IHtcbiAgICAgICAgICAgIGNvbG9yOiAocyA9PSBudWxsID8gdm9pZCAwIDogcy5jb2xvcikgPz8gXCIjZmZmXCIsXG4gICAgICAgICAgICAuLi5zLFxuICAgICAgICAgICAgd2lkdGg6IHVcbiAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImdldFN0YXRlQW5kSGVscGVyc1wiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKCkgPT4gKHtcbiAgICAgICAgZ2V0Um9vdFByb3BzOiB0aGlzLmdldFJvb3RQcm9wcyxcbiAgICAgICAgZGF0YTogdGhpcy5wcm9wcy5oZWFkZXJEYXRhXG4gICAgICB9KVxuICAgIH0pO1xuICB9XG4gIHJlbmRlcigpIHtcbiAgICBjb25zdCBpID0gdGhpcy5nZXRTdGF0ZUFuZEhlbHBlcnMoKTtcbiAgICByZXR1cm4gdGhpcy5wcm9wcy5jaGlsZHJlbihpKTtcbiAgfVxufVxuY29uc3QgWmQgPSAoeyBnZXRSb290UHJvcHM6IGEgfSkgPT4gaihcImRpdlwiLCB7IFwiZGF0YS10ZXN0aWRcIjogXCJzaWRlYmFySGVhZGVyXCIsIC4uLmEoKSB9KSwgU3QgPSAoYSkgPT4ge1xuICBjb25zdCB7IGNoaWxkcmVuOiBpLCB2YXJpYW50OiBzID0gVmQsIGhlYWRlckRhdGE6IHUgfSA9IGEsIHsgbGVmdFNpZGViYXJXaWR0aDogdiwgcmlnaHRTaWRlYmFyV2lkdGg6IGYgfSA9IFdyKCk7XG4gIHJldHVybiBqKHFkLCB7IGxlZnRTaWRlYmFyV2lkdGg6IHYsIHJpZ2h0U2lkZWJhcldpZHRoOiBmLCB2YXJpYW50OiBzLCBoZWFkZXJEYXRhOiB1LCBjaGlsZHJlbjogaSB8fCBaZCB9KTtcbn07XG5TdC5zZWNyZXRLZXkgPSBcIlNpZGViYXJIZWFkZXJcIjtcbmNsYXNzIEpkIGV4dGVuZHMgWi5Db21wb25lbnQge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlciguLi5hcmd1bWVudHMpLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJnZXRSb290U3R5bGVcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6ICgpID0+ICh7XG4gICAgICAgIC4uLnRoaXMucHJvcHMuc3R5bGUsXG4gICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICB3aWR0aDogXCIxMDAlXCJcbiAgICAgIH0pXG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImdldENhbGVuZGFySGVhZGVyU3R5bGVcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6ICgpID0+IHtcbiAgICAgICAgY29uc3QgeyBsZWZ0U2lkZWJhcldpZHRoOiBpLCByaWdodFNpZGViYXJXaWR0aDogcywgY2FsZW5kYXJIZWFkZXJTdHlsZTogdSB9ID0gdGhpcy5wcm9wcztcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAuLi51LFxuICAgICAgICAgIG92ZXJmbG93OiBcImhpZGRlblwiLFxuICAgICAgICAgIHdpZHRoOiBgY2FsYygxMDAlIC0gJHtpICsgc31weClgXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImlzU2lkZWJhckhlYWRlclwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKGkpID0+IGkudHlwZSA9PT0gdm9pZCAwID8gITEgOiBpLnR5cGUuc2VjcmV0S2V5ID09PSBTdC5zZWNyZXRLZXlcbiAgICB9KTtcbiAgfVxuICByZW5kZXIoKSB7XG4gICAgbGV0IGksIHM7XG4gICAgY29uc3QgdSA9IFtdLCB2ID0gQXJyYXkuaXNBcnJheSh0aGlzLnByb3BzLmNoaWxkcmVuKSA/IHRoaXMucHJvcHMuY2hpbGRyZW4uZmlsdGVyKChmKSA9PiBmKSA6IFt0aGlzLnByb3BzLmNoaWxkcmVuXTtcbiAgICByZXR1cm4gWi5DaGlsZHJlbi5tYXAodiwgKGYpID0+IHtcbiAgICAgIHZhciBtO1xuICAgICAgdGhpcy5pc1NpZGViYXJIZWFkZXIoZikgPyAoKG0gPSBmID09IG51bGwgPyB2b2lkIDAgOiBmLnByb3BzKSA9PSBudWxsID8gdm9pZCAwIDogbS52YXJpYW50KSA9PT0gdG8gPyBpID0gZiA6IHMgPSBmIDogdS5wdXNoKGYpO1xuICAgIH0pLCBzIHx8IChzID0gaihTdCwge30pKSwgIWkgJiYgdGhpcy5wcm9wcy5yaWdodFNpZGViYXJXaWR0aCAmJiAoaSA9IGooU3QsIHsgdmFyaWFudDogXCJyaWdodFwiIH0pKSwgemUoXCJkaXZcIiwgeyBcImRhdGEtdGVzdGlkXCI6IFwiaGVhZGVyUm9vdERpdlwiLCBzdHlsZTogdGhpcy5nZXRSb290U3R5bGUoKSwgY2xhc3NOYW1lOiBtaShcInJjdC1oZWFkZXItcm9vdFwiLCB0aGlzLnByb3BzLmNsYXNzTmFtZSksIGNoaWxkcmVuOiBbcywgaihcImRpdlwiLCB7IHJlZjogdGhpcy5wcm9wcy5yZWdpc3RlclNjcm9sbCwgc3R5bGU6IHRoaXMuZ2V0Q2FsZW5kYXJIZWFkZXJTdHlsZSgpLCBjbGFzc05hbWU6IG1pKFwicmN0LWNhbGVuZGFyLWhlYWRlclwiLCB0aGlzLnByb3BzLmNhbGVuZGFySGVhZGVyQ2xhc3NOYW1lKSwgXCJkYXRhLXRlc3RpZFwiOiBcImhlYWRlckNvbnRhaW5lclwiLCBjaGlsZHJlbjogdSB9KSwgaV0gfSk7XG4gIH1cbn1cbmNvbnN0IEVyID0gKHsgY2hpbGRyZW46IGEsIHN0eWxlOiBpLCBjbGFzc05hbWU6IHMsIGNhbGVuZGFySGVhZGVyU3R5bGU6IHUsIGNhbGVuZGFySGVhZGVyQ2xhc3NOYW1lOiB2IH0pID0+IHtcbiAgY29uc3QgeyBsZWZ0U2lkZWJhcldpZHRoOiBmLCByaWdodFNpZGViYXJXaWR0aDogbSwgcmVnaXN0ZXJTY3JvbGw6IHkgfSA9IFdyKCk7XG4gIHJldHVybiBqKEpkLCB7IGxlZnRTaWRlYmFyV2lkdGg6IGYsIHJpZ2h0U2lkZWJhcldpZHRoOiBtLCByZWdpc3RlclNjcm9sbDogeSwgc3R5bGU6IGksIGNsYXNzTmFtZTogcywgY2FsZW5kYXJIZWFkZXJTdHlsZTogdSwgY2FsZW5kYXJIZWFkZXJDbGFzc05hbWU6IHYsIGNoaWxkcmVuOiBhIH0pO1xufTtcbkVyLnNlY3JldEtleSA9IFwiVGltZWxpbmVIZWFkZXJzXCI7XG5jbGFzcyBybyBleHRlbmRzIFouQ29tcG9uZW50IHtcbiAgY29uc3RydWN0b3IoaSkge1xuICAgIHN1cGVyKGkpLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJnZXRIZWFkZXJJbnRlcnZhbHNcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6ICh7IGNhbnZhc1RpbWVTdGFydDogUywgY2FudmFzVGltZUVuZDogQywgdW5pdDogRCwgdGltZVN0ZXBzOiBSLCBnZXRMZWZ0T2Zmc2V0RnJvbURhdGU6IFQgfSkgPT4ge1xuICAgICAgICBjb25zdCBQID0gW107XG4gICAgICAgIHJldHVybiBScihTLCBDLCBELCBSLCAoXywgTykgPT4ge1xuICAgICAgICAgIGNvbnN0IGsgPSBUKF8udmFsdWVPZigpKSwgSCA9IFQoTy52YWx1ZU9mKCkpIC0gaztcbiAgICAgICAgICBQLnB1c2goe1xuICAgICAgICAgICAgc3RhcnRUaW1lOiBfLFxuICAgICAgICAgICAgZW5kVGltZTogTyxcbiAgICAgICAgICAgIGxhYmVsV2lkdGg6IEgsXG4gICAgICAgICAgICBsZWZ0OiBrXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0pLCBQO1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJnZXRSb290UHJvcHNcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IChTID0ge30pID0+IHtcbiAgICAgICAgY29uc3QgeyBzdHlsZTogQyB9ID0gUztcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBzdHlsZTogT2JqZWN0LmFzc2lnbih7fSwgQyB8fCB7fSwge1xuICAgICAgICAgICAgcG9zaXRpb246IFwicmVsYXRpdmVcIixcbiAgICAgICAgICAgIHdpZHRoOiB0aGlzLnByb3BzLmNhbnZhc1dpZHRoLFxuICAgICAgICAgICAgaGVpZ2h0OiB0aGlzLnByb3BzLmhlaWdodFxuICAgICAgICAgIH0pXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImdldEludGVydmFsUHJvcHNcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IChTID0ge30pID0+IHtcbiAgICAgICAgY29uc3QgeyBpbnRlcnZhbDogQywgc3R5bGU6IEQgfSA9IFM7XG4gICAgICAgIGlmICghQylcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJ5b3Ugc2hvdWxkIHByb3ZpZGUgaW50ZXJ2YWwgdG8gdGhlIHByb3AgZ2V0dGVyXCIpO1xuICAgICAgICBjb25zdCB7IHN0YXJ0VGltZTogUiwgbGFiZWxXaWR0aDogVCwgbGVmdDogUCB9ID0gQztcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBzdHlsZToge1xuICAgICAgICAgICAgLi4uRCxcbiAgICAgICAgICAgIGxlZnQ6IFAsXG4gICAgICAgICAgICB3aWR0aDogVCxcbiAgICAgICAgICAgIHBvc2l0aW9uOiBcImFic29sdXRlXCJcbiAgICAgICAgICB9LFxuICAgICAgICAgIGtleTogYGxhYmVsLSR7Ui52YWx1ZU9mKCl9YFxuICAgICAgICB9O1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJnZXRTdGF0ZUFuZEhlbHBlcnNcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6ICgpID0+IHtcbiAgICAgICAgY29uc3Qge1xuICAgICAgICAgIC8qY2FudmFzVGltZVN0YXJ0LFxuICAgICAgICAgIGNhbnZhc1RpbWVFbmQsXG4gICAgICAgICAgdGltZWxpbmVXaWR0aCxcbiAgICAgICAgICB2aXNpYmxlVGltZVN0YXJ0LFxuICAgICAgICAgIHZpc2libGVUaW1lRW5kLCovXG4gICAgICAgICAgdW5pdDogUyxcbiAgICAgICAgICBzaG93UGVyaW9kOiBDLFxuICAgICAgICAgIGhlYWRlckRhdGE6IERcbiAgICAgICAgfSA9IHRoaXMucHJvcHM7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgLyp0aW1lbGluZUNvbnRleHQ6IHtcbiAgICAgICAgICAgIHRpbWVsaW5lV2lkdGgsXG4gICAgICAgICAgICB2aXNpYmxlVGltZVN0YXJ0LFxuICAgICAgICAgICAgdmlzaWJsZVRpbWVFbmQsXG4gICAgICAgICAgICBjYW52YXNUaW1lU3RhcnQsXG4gICAgICAgICAgICBjYW52YXNUaW1lRW5kLFxuICAgICAgICAgIH0sKi9cbiAgICAgICAgICBoZWFkZXJDb250ZXh0OiB7XG4gICAgICAgICAgICB1bml0OiBTLFxuICAgICAgICAgICAgaW50ZXJ2YWxzOiB0aGlzLnN0YXRlLmludGVydmFsc1xuICAgICAgICAgIH0sXG4gICAgICAgICAgZ2V0Um9vdFByb3BzOiB0aGlzLmdldFJvb3RQcm9wcyxcbiAgICAgICAgICBnZXRJbnRlcnZhbFByb3BzOiB0aGlzLmdldEludGVydmFsUHJvcHMsXG4gICAgICAgICAgc2hvd1BlcmlvZDogQyxcbiAgICAgICAgICBkYXRhOiBEXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfSk7XG4gICAgY29uc3QgeyBjYW52YXNUaW1lU3RhcnQ6IHMsIGNhbnZhc1RpbWVFbmQ6IHUsIHVuaXQ6IHYsIHRpbWVTdGVwczogZiwgZ2V0TGVmdE9mZnNldEZyb21EYXRlOiBtIH0gPSBpLCB5ID0gdGhpcy5nZXRIZWFkZXJJbnRlcnZhbHMoe1xuICAgICAgY2FudmFzVGltZVN0YXJ0OiBzLFxuICAgICAgY2FudmFzVGltZUVuZDogdSxcbiAgICAgIHVuaXQ6IHYsXG4gICAgICB0aW1lU3RlcHM6IGYsXG4gICAgICBnZXRMZWZ0T2Zmc2V0RnJvbURhdGU6IG1cbiAgICB9KTtcbiAgICB0aGlzLnN0YXRlID0ge1xuICAgICAgaW50ZXJ2YWxzOiB5XG4gICAgfTtcbiAgfVxuICAvKnNob3VsZENvbXBvbmVudFVwZGF0ZShuZXh0UHJvcHM6IEN1c3RvbUhlYWRlclByb3BzPERhdGE+KSB7XG4gICAgaWYgKFxuICAgICAgbmV4dFByb3BzLmNhbnZhc1RpbWVTdGFydCAhPT0gdGhpcy5wcm9wcy5jYW52YXNUaW1lU3RhcnQgfHxcbiAgICAgIG5leHRQcm9wcy5jYW52YXNUaW1lRW5kICE9PSB0aGlzLnByb3BzLmNhbnZhc1RpbWVFbmQgfHxcbiAgICAgIG5leHRQcm9wcy5jYW52YXNXaWR0aCAhPT0gdGhpcy5wcm9wcy5jYW52YXNXaWR0aCB8fFxuICAgICAgbmV4dFByb3BzLnVuaXQgIT09IHRoaXMucHJvcHMudW5pdCB8fFxuICAgICAgbmV4dFByb3BzLnRpbWVTdGVwcyAhPT0gdGhpcy5wcm9wcy50aW1lU3RlcHMgfHxcbiAgICAgIG5leHRQcm9wcy5zaG93UGVyaW9kICE9PSB0aGlzLnByb3BzLnNob3dQZXJpb2QgfHxcbiAgICAgIG5leHRQcm9wcy5jaGlsZHJlbiAhPT0gdGhpcy5wcm9wcy5jaGlsZHJlbiB8fFxuICAgICAgbmV4dFByb3BzLmhlYWRlckRhdGEgIT09IHRoaXMucHJvcHMuaGVhZGVyRGF0YVxuICAgICkge1xuICAgICAgcmV0dXJuIHRydWVcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlXG4gIH0qL1xuICBjb21wb25lbnREaWRVcGRhdGUoaSkge1xuICAgIGlmICgheHIoaSwgdGhpcy5wcm9wcykpIHtcbiAgICAgIGNvbnN0IHsgY2FudmFzVGltZVN0YXJ0OiBzLCBjYW52YXNUaW1lRW5kOiB1LCB1bml0OiB2LCB0aW1lU3RlcHM6IGYsIGdldExlZnRPZmZzZXRGcm9tRGF0ZTogbSB9ID0gdGhpcy5wcm9wcywgeSA9IHRoaXMuZ2V0SGVhZGVySW50ZXJ2YWxzKHtcbiAgICAgICAgY2FudmFzVGltZVN0YXJ0OiBzLFxuICAgICAgICBjYW52YXNUaW1lRW5kOiB1LFxuICAgICAgICB1bml0OiB2LFxuICAgICAgICB0aW1lU3RlcHM6IGYsXG4gICAgICAgIGdldExlZnRPZmZzZXRGcm9tRGF0ZTogbVxuICAgICAgfSk7XG4gICAgICB0aGlzLnNldFN0YXRlKHsgaW50ZXJ2YWxzOiB5IH0pO1xuICAgIH1cbiAgfVxuICByZW5kZXIoKSB7XG4gICAgY29uc3QgaSA9IHRoaXMuZ2V0U3RhdGVBbmRIZWxwZXJzKCk7XG4gICAgcmV0dXJuIHRoaXMucHJvcHMuY2hpbGRyZW4oaSk7XG4gIH1cbn1cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShybywgXCJkZWZhdWx0UHJvcHNcIiwge1xuICBlbnVtZXJhYmxlOiAhMCxcbiAgY29uZmlndXJhYmxlOiAhMCxcbiAgd3JpdGFibGU6ICEwLFxuICB2YWx1ZToge1xuICAgIGhlaWdodDogMzBcbiAgfVxufSk7XG5mdW5jdGlvbiBRZCh7IGNoaWxkcmVuOiBhLCB1bml0OiBpLCBoZWFkZXJEYXRhOiBzLCBoZWlnaHQ6IHUgfSkge1xuICBjb25zdCB7IGdldFRpbWVsaW5lU3RhdGU6IHYsIHNob3dQZXJpb2Q6IGYsIGdldExlZnRPZmZzZXRGcm9tRGF0ZTogbSB9ID0gaGQoKSwgeSA9IHYoKSwgeyB0aW1lU3RlcHM6IFMgfSA9IFdyKCk7XG4gIHJldHVybiBqKHJvLCB7IGNoaWxkcmVuOiBhLCB0aW1lU3RlcHM6IFMsIHNob3dQZXJpb2Q6IGYsIHVuaXQ6IGkgfHwgeS50aW1lbGluZVVuaXQsIC4uLnksIGhlYWRlckRhdGE6IHMsIGdldExlZnRPZmZzZXRGcm9tRGF0ZTogbSwgaGVpZ2h0OiB1IH0pO1xufVxudmFyIGJpID0gTnVtYmVyLmlzTmFOIHx8IGZ1bmN0aW9uKGkpIHtcbiAgcmV0dXJuIHR5cGVvZiBpID09IFwibnVtYmVyXCIgJiYgaSAhPT0gaTtcbn07XG5mdW5jdGlvbiBlZihhLCBpKSB7XG4gIHJldHVybiAhIShhID09PSBpIHx8IGJpKGEpICYmIGJpKGkpKTtcbn1cbmZ1bmN0aW9uIHRmKGEsIGkpIHtcbiAgaWYgKGEubGVuZ3RoICE9PSBpLmxlbmd0aClcbiAgICByZXR1cm4gITE7XG4gIGZvciAodmFyIHMgPSAwOyBzIDwgYS5sZW5ndGg7IHMrKylcbiAgICBpZiAoIWVmKGFbc10sIGlbc10pKVxuICAgICAgcmV0dXJuICExO1xuICByZXR1cm4gITA7XG59XG5mdW5jdGlvbiB5aShhLCBpKSB7XG4gIGkgPT09IHZvaWQgMCAmJiAoaSA9IHRmKTtcbiAgdmFyIHMgPSBudWxsO1xuICBmdW5jdGlvbiB1KCkge1xuICAgIGZvciAodmFyIHYgPSBbXSwgZiA9IDA7IGYgPCBhcmd1bWVudHMubGVuZ3RoOyBmKyspXG4gICAgICB2W2ZdID0gYXJndW1lbnRzW2ZdO1xuICAgIGlmIChzICYmIHMubGFzdFRoaXMgPT09IHRoaXMgJiYgaSh2LCBzLmxhc3RBcmdzKSlcbiAgICAgIHJldHVybiBzLmxhc3RSZXN1bHQ7XG4gICAgdmFyIG0gPSBhLmFwcGx5KHRoaXMsIHYpO1xuICAgIHJldHVybiBzID0ge1xuICAgICAgbGFzdFJlc3VsdDogbSxcbiAgICAgIGxhc3RBcmdzOiB2LFxuICAgICAgbGFzdFRoaXM6IHRoaXNcbiAgICB9LCBtO1xuICB9XG4gIHJldHVybiB1LmNsZWFyID0gZnVuY3Rpb24oKSB7XG4gICAgcyA9IG51bGw7XG4gIH0sIHU7XG59XG5jbGFzcyByZiBleHRlbmRzIFouUHVyZUNvbXBvbmVudCB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKC4uLmFyZ3VtZW50cyksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcIm9uSW50ZXJ2YWxDbGlja1wiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKCkgPT4ge1xuICAgICAgICBjb25zdCB7IHByaW1hcnlIZWFkZXI6IGksIGludGVydmFsOiBzLCB1bml0OiB1LCBzaG93UGVyaW9kOiB2IH0gPSB0aGlzLnByb3BzO1xuICAgICAgICBpZiAoaSkge1xuICAgICAgICAgIGNvbnN0IGYgPSBEcih1KSwgbSA9IHMuc3RhcnRUaW1lLmNsb25lKCkuc3RhcnRPZihmKSwgeSA9IHMuc3RhcnRUaW1lLmNsb25lKCkuZW5kT2YoZik7XG4gICAgICAgICAgdihtLCB5KTtcbiAgICAgICAgfSBlbHNlXG4gICAgICAgICAgdihzLnN0YXJ0VGltZSwgcy5lbmRUaW1lKTtcbiAgICAgIH1cbiAgICB9KSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwiZ2V0SW50ZXJ2YWxQcm9wc1wiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKGkgPSB7fSkgPT4gKHtcbiAgICAgICAgLi4udGhpcy5wcm9wcy5nZXRJbnRlcnZhbFByb3BzKHtcbiAgICAgICAgICBpbnRlcnZhbDogdGhpcy5wcm9wcy5pbnRlcnZhbCxcbiAgICAgICAgICAuLi5pXG4gICAgICAgIH0pLFxuICAgICAgICBvbkNsaWNrOiBQZSh0aGlzLm9uSW50ZXJ2YWxDbGljaywgaS5vbkNsaWNrKVxuICAgICAgfSlcbiAgICB9KTtcbiAgfVxuICByZW5kZXIoKSB7XG4gICAgY29uc3QgeyBpbnRlcnZhbFRleHQ6IGksIGludGVydmFsOiBzLCBpbnRlcnZhbFJlbmRlcmVyOiB1LCBoZWFkZXJEYXRhOiB2IH0gPSB0aGlzLnByb3BzLCBmID0gdTtcbiAgICBpZiAoZilcbiAgICAgIHJldHVybiBmKHtcbiAgICAgICAgZ2V0SW50ZXJ2YWxQcm9wczogdGhpcy5nZXRJbnRlcnZhbFByb3BzLFxuICAgICAgICBpbnRlcnZhbENvbnRleHQ6IHtcbiAgICAgICAgICBpbnRlcnZhbDogcyxcbiAgICAgICAgICBpbnRlcnZhbFRleHQ6IGlcbiAgICAgICAgfSxcbiAgICAgICAgZGF0YTogdlxuICAgICAgfSk7XG4gICAgY29uc3QgeyBrZXk6IG0sIC4uLnkgfSA9IHRoaXMuZ2V0SW50ZXJ2YWxQcm9wcygpO1xuICAgIHJldHVybiBUdChcbiAgICAgIFwiZGl2XCIsXG4gICAgICB7IFwiZGF0YS10ZXN0aWRcIjogXCJkYXRlSGVhZGVySW50ZXJ2YWxcIiwgLi4ueSwga2V5OiBtLCBjbGFzc05hbWU6IGByY3QtZGF0ZUhlYWRlciAke3RoaXMucHJvcHMucHJpbWFyeUhlYWRlciA/IFwicmN0LWRhdGVIZWFkZXItcHJpbWFyeVwiIDogXCJcIn1gIH0sXG4gICAgICBqKFwic3BhblwiLCB7IGNoaWxkcmVuOiBpIH0pXG4gICAgKTtcbiAgfVxufVxuZnVuY3Rpb24gbmYoeyBoZWFkZXJDb250ZXh0OiB7IGludGVydmFsczogYSwgdW5pdDogaSB9LCBnZXRSb290UHJvcHM6IHMsIGdldEludGVydmFsUHJvcHM6IHUsIHNob3dQZXJpb2Q6IHYsIGRhdGE6IHsgc3R5bGU6IGYsIGludGVydmFsUmVuZGVyZXI6IG0sIGNsYXNzTmFtZTogeSwgZ2V0TGFiZWxGb3JtYXQ6IFMsIHVuaXRQcm9wOiBDLCBoZWFkZXJEYXRhOiBEIH0gfSkge1xuICByZXR1cm4gaihcImRpdlwiLCB7IFwiZGF0YS10ZXN0aWRcIjogXCJkYXRlSGVhZGVyXCIsIGNsYXNzTmFtZTogeSwgLi4ucyh7IHN0eWxlOiBmIH0pLCBjaGlsZHJlbjogYS5tYXAoKFIpID0+IHtcbiAgICBjb25zdCBUID0gUyhbUi5zdGFydFRpbWUsIFIuZW5kVGltZV0sIGksIFIubGFiZWxXaWR0aCk7XG4gICAgcmV0dXJuIGoocmYsIHsgdW5pdDogaSwgaW50ZXJ2YWw6IFIsIHNob3dQZXJpb2Q6IHYsIGludGVydmFsVGV4dDogVCwgcHJpbWFyeUhlYWRlcjogQyA9PT0gXCJwcmltYXJ5SGVhZGVyXCIsIGdldEludGVydmFsUHJvcHM6IHUsIGludGVydmFsUmVuZGVyZXI6IG0sIGhlYWRlckRhdGE6IEQgfSwgYGxhYmVsLSR7Ui5zdGFydFRpbWUudmFsdWVPZigpfWApO1xuICB9KSB9KTtcbn1cbmNsYXNzIG9mIGV4dGVuZHMgWi5Db21wb25lbnQge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlciguLi5hcmd1bWVudHMpLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJnZXRIZWFkZXJVbml0XCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiAoKSA9PiB0aGlzLnByb3BzLnVuaXQgPT09IFwicHJpbWFyeUhlYWRlclwiID8gRHIodGhpcy5wcm9wcy50aW1lbGluZVVuaXQpIDogdGhpcy5wcm9wcy51bml0ID8gdGhpcy5wcm9wcy51bml0IDogdGhpcy5wcm9wcy50aW1lbGluZVVuaXRcbiAgICB9KSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwiZ2V0Um9vdFN0eWxlXCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiB5aSgoaSkgPT4gKHtcbiAgICAgICAgaGVpZ2h0OiAzMCxcbiAgICAgICAgLi4uaVxuICAgICAgfSkpXG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImdldExhYmVsRm9ybWF0XCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiAoaSwgcywgdSkgPT4ge1xuICAgICAgICBjb25zdCB7IGxhYmVsRm9ybWF0OiB2IH0gPSB0aGlzLnByb3BzO1xuICAgICAgICBpZiAodHlwZW9mIHYgPT0gXCJzdHJpbmdcIilcbiAgICAgICAgICByZXR1cm4gaVswXS5mb3JtYXQodik7XG4gICAgICAgIGlmICh0eXBlb2YgdiA9PSBcImZ1bmN0aW9uXCIpXG4gICAgICAgICAgcmV0dXJuIHYoaSwgcywgdSk7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcImxhYmVsRm9ybWF0IHNob3VsZCBiZSBmdW5jdGlvbiBvciBzdHJpbmdcIik7XG4gICAgICB9XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImdldEhlYWRlckRhdGFcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IHlpKChpLCBzLCB1LCB2LCBmLCBtKSA9PiAoe1xuICAgICAgICBpbnRlcnZhbFJlbmRlcmVyOiBpLFxuICAgICAgICBzdHlsZTogcyxcbiAgICAgICAgY2xhc3NOYW1lOiB1LFxuICAgICAgICBnZXRMYWJlbEZvcm1hdDogdixcbiAgICAgICAgdW5pdFByb3A6IGYsXG4gICAgICAgIGhlYWRlckRhdGE6IG1cbiAgICAgIH0pKVxuICAgIH0pO1xuICB9XG4gIHJlbmRlcigpIHtcbiAgICBjb25zdCBpID0gdGhpcy5nZXRIZWFkZXJVbml0KCksIHsgaGVpZ2h0OiBzIH0gPSB0aGlzLnByb3BzO1xuICAgIHJldHVybiBqKFFkLCB7IGNoaWxkcmVuOiBuZiwgdW5pdDogaSwgaGVpZ2h0OiBzLCBoZWFkZXJEYXRhOiB0aGlzLmdldEhlYWRlckRhdGEodGhpcy5wcm9wcy5pbnRlcnZhbFJlbmRlcmVyLCB0aGlzLmdldFJvb3RTdHlsZSh0aGlzLnByb3BzLnN0eWxlKSwgdGhpcy5wcm9wcy5jbGFzc05hbWUsIHRoaXMuZ2V0TGFiZWxGb3JtYXQsIHRoaXMucHJvcHMudW5pdCwgdGhpcy5wcm9wcy5oZWFkZXJEYXRhKSB9KTtcbiAgfVxufVxuZnVuY3Rpb24gVGkoeyBsYWJlbEZvcm1hdDogYSwgdW5pdDogaSwgc3R5bGU6IHMsIGNsYXNzTmFtZTogdSwgaW50ZXJ2YWxSZW5kZXJlcjogdiwgaGVhZGVyRGF0YTogZiwgaGVpZ2h0OiBtIH0pIHtcbiAgcmV0dXJuIGooTHQsIHsgY2hpbGRyZW46ICh7IGdldFRpbWVsaW5lU3RhdGU6IHkgfSkgPT4ge1xuICAgIGNvbnN0IFMgPSB5KCk7XG4gICAgcmV0dXJuIGoob2YsIHsgdGltZWxpbmVVbml0OiBTLnRpbWVsaW5lVW5pdCwgdW5pdDogaSwgbGFiZWxGb3JtYXQ6IGEgfHwgc2YsIHN0eWxlOiBzLCBjbGFzc05hbWU6IHUsIGludGVydmFsUmVuZGVyZXI6IHYsIGhlYWRlckRhdGE6IGYsIGhlaWdodDogbSB9KTtcbiAgfSB9KTtcbn1cbmNvbnN0IHNmID0gKFthXSwgaSwgcyA9IDE1MCwgdSA9IEdkKSA9PiB7XG4gIGxldCB2O1xuICByZXR1cm4gcyA+PSAxNTAgPyB2ID0gdVtpXS5sb25nIDogcyA+PSAxMDAgPyB2ID0gdVtpXS5tZWRpdW1Mb25nIDogcyA+PSA1MCA/IHYgPSB1W2ldLm1lZGl1bSA6IHYgPSB1W2ldLnNob3J0LCBhLmZvcm1hdCh2KTtcbn07XG52YXIgbm8gPSB7IGV4cG9ydHM6IHt9IH07XG4oZnVuY3Rpb24oYSwgaSkge1xuICAoZnVuY3Rpb24ocywgdSkge1xuICAgIGEuZXhwb3J0cyA9IHUoKTtcbiAgfSkoSWUsIGZ1bmN0aW9uKCkge1xuICAgIHZhciBzID0geyBMVFM6IFwiaDptbTpzcyBBXCIsIExUOiBcImg6bW0gQVwiLCBMOiBcIk1NL0REL1lZWVlcIiwgTEw6IFwiTU1NTSBELCBZWVlZXCIsIExMTDogXCJNTU1NIEQsIFlZWVkgaDptbSBBXCIsIExMTEw6IFwiZGRkZCwgTU1NTSBELCBZWVlZIGg6bW0gQVwiIH07XG4gICAgcmV0dXJuIGZ1bmN0aW9uKHUsIHYsIGYpIHtcbiAgICAgIHZhciBtID0gdi5wcm90b3R5cGUsIHkgPSBtLmZvcm1hdDtcbiAgICAgIGYuZW4uZm9ybWF0cyA9IHMsIG0uZm9ybWF0ID0gZnVuY3Rpb24oUykge1xuICAgICAgICBTID09PSB2b2lkIDAgJiYgKFMgPSBcIllZWVktTU0tRERUSEg6bW06c3NaXCIpO1xuICAgICAgICB2YXIgQyA9IHRoaXMuJGxvY2FsZSgpLmZvcm1hdHMsIEQgPSBmdW5jdGlvbihSLCBUKSB7XG4gICAgICAgICAgcmV0dXJuIFIucmVwbGFjZSgvKFxcW1teXFxdXStdKXwoTFRTP3xsezEsNH18THsxLDR9KS9nLCBmdW5jdGlvbihQLCBfLCBPKSB7XG4gICAgICAgICAgICB2YXIgayA9IE8gJiYgTy50b1VwcGVyQ2FzZSgpO1xuICAgICAgICAgICAgcmV0dXJuIF8gfHwgVFtPXSB8fCBzW09dIHx8IFRba10ucmVwbGFjZSgvKFxcW1teXFxdXStdKXwoTU1NTXxNTXxERHxkZGRkKS9nLCBmdW5jdGlvbihMLCBILCBYKSB7XG4gICAgICAgICAgICAgIHJldHVybiBIIHx8IFguc2xpY2UoMSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfShTLCBDID09PSB2b2lkIDAgPyB7fSA6IEMpO1xuICAgICAgICByZXR1cm4geS5jYWxsKHRoaXMsIEQpO1xuICAgICAgfTtcbiAgICB9O1xuICB9KTtcbn0pKG5vKTtcbnZhciBhZiA9IG5vLmV4cG9ydHM7XG5jb25zdCBsZiA9IC8qIEBfX1BVUkVfXyAqLyBydChhZik7XG51ZS5leHRlbmQobGYpO1xuY2xhc3MgaW8gZXh0ZW5kcyBhZSB7XG4gIGNvbnN0cnVjdG9yKGkpIHtcbiAgICBzdXBlcihpKSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwiZ2V0VGltZWxpbmVDb250ZXh0XCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiAoKSA9PiB7XG4gICAgICAgIGNvbnN0IHsgd2lkdGg6IFQsIHZpc2libGVUaW1lU3RhcnQ6IFAsIHZpc2libGVUaW1lRW5kOiBfLCBjYW52YXNUaW1lU3RhcnQ6IE8sIGNhbnZhc1RpbWVFbmQ6IGsgfSA9IHRoaXMuc3RhdGUsIEwgPSBfIC0gUCwgSCA9IHZlKFQsIHRoaXMucHJvcHMuYnVmZmVyKSwgWCA9IHh0KEwsIFQsIHRoaXMucHJvcHMudGltZVN0ZXBzKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBjYW52YXNXaWR0aDogSCxcbiAgICAgICAgICB0aW1lbGluZVVuaXQ6IFgsXG4gICAgICAgICAgdGltZWxpbmVXaWR0aDogVCxcbiAgICAgICAgICB2aXNpYmxlVGltZVN0YXJ0OiBQLFxuICAgICAgICAgIHZpc2libGVUaW1lRW5kOiBfLFxuICAgICAgICAgIGNhbnZhc1RpbWVTdGFydDogTyxcbiAgICAgICAgICBjYW52YXNUaW1lRW5kOiBrXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImdldFRpbWVsaW5lVW5pdFwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKCkgPT4ge1xuICAgICAgICBjb25zdCB7IHdpZHRoOiBULCB2aXNpYmxlVGltZVN0YXJ0OiBQLCB2aXNpYmxlVGltZUVuZDogXyB9ID0gdGhpcy5zdGF0ZSwgeyB0aW1lU3RlcHM6IE8gfSA9IHRoaXMucHJvcHMsIGsgPSBfIC0gUDtcbiAgICAgICAgcmV0dXJuIHh0KGssIFQsIE8pO1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJzdGF0ZVwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogdm9pZCAwXG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcInNjcm9sbENvbXBvbmVudFwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogbnVsbFxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJzY3JvbGxIZWFkZXJSZWZcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IG51bGxcbiAgICB9KSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwicmVzaXplXCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiAoVCA9IHRoaXMucHJvcHMpID0+IHtcbiAgICAgICAgdmFyIFY7XG4gICAgICAgIGNvbnN0IHsgd2lkdGg6IFAgfSA9ICgoViA9IHRoaXMuY29udGFpbmVyLmN1cnJlbnQpID09IG51bGwgPyB2b2lkIDAgOiBWLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpKSA/PyB7IHdpZHRoOiAwIH0sIF8gPSBQIC0gVC5zaWRlYmFyV2lkdGggLSBULnJpZ2h0U2lkZWJhcldpZHRoLCBPID0gdmUoXywgVC5idWZmZXIpLCB7IGRpbWVuc2lvbkl0ZW1zOiBrLCBoZWlnaHQ6IEwsIGdyb3VwSGVpZ2h0czogSCwgZ3JvdXBUb3BzOiBYIH0gPSAkZShULml0ZW1zLCBULmdyb3VwcywgTywgdGhpcy5zdGF0ZS5jYW52YXNUaW1lU3RhcnQsIHRoaXMuc3RhdGUuY2FudmFzVGltZUVuZCwgVC5rZXlzLCBULmxpbmVIZWlnaHQsIFQuaXRlbUhlaWdodFJhdGlvLCBULnN0YWNrSXRlbXMsIHRoaXMuc3RhdGUuZHJhZ2dpbmdJdGVtLCB0aGlzLnN0YXRlLnJlc2l6aW5nSXRlbSwgdGhpcy5zdGF0ZS5kcmFnVGltZSwgdGhpcy5zdGF0ZS5yZXNpemluZ0VkZ2UsIHRoaXMuc3RhdGUucmVzaXplVGltZSwgdGhpcy5zdGF0ZS5uZXdHcm91cE9yZGVyLCBULml0ZW1WZXJ0aWNhbEdhcCk7XG4gICAgICAgIHRoaXMuc2V0U3RhdGUoe1xuICAgICAgICAgIHdpZHRoOiBfLFxuICAgICAgICAgIGRpbWVuc2lvbkl0ZW1zOiBrLFxuICAgICAgICAgIGhlaWdodDogTCxcbiAgICAgICAgICBncm91cEhlaWdodHM6IEgsXG4gICAgICAgICAgZ3JvdXBUb3BzOiBYXG4gICAgICAgIH0pO1xuICAgICAgICBjb25zdCBCID0gXyAqICgoVC5idWZmZXIgLSAxKSAvIDIpO1xuICAgICAgICB0aGlzLnNjcm9sbENvbXBvbmVudCAmJiAodGhpcy5zY3JvbGxDb21wb25lbnQuc2Nyb2xsTGVmdCA9IEIpLCB0aGlzLnNjcm9sbEhlYWRlclJlZiAmJiAodGhpcy5zY3JvbGxIZWFkZXJSZWYuc2Nyb2xsTGVmdCA9IEIpO1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJvblNjcm9sbFwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKFQpID0+IHtcbiAgICAgICAgdmFyIEwsIEg7XG4gICAgICAgIGNvbnN0IFAgPSB0aGlzLnN0YXRlLndpZHRoLCBfID0gdGhpcy5zdGF0ZS5jYW52YXNUaW1lU3RhcnQsIE8gPSB0aGlzLnN0YXRlLnZpc2libGVUaW1lRW5kIC0gdGhpcy5zdGF0ZS52aXNpYmxlVGltZVN0YXJ0LCBrID0gXyArIE8gKiBUIC8gUDtcbiAgICAgICAgKHRoaXMuc3RhdGUudmlzaWJsZVRpbWVTdGFydCAhPT0gayB8fCB0aGlzLnN0YXRlLnZpc2libGVUaW1lRW5kICE9PSBrICsgTykgJiYgKChIID0gKEwgPSB0aGlzLnByb3BzKS5vblRpbWVDaGFuZ2UpID09IG51bGwgfHwgSC5jYWxsKEwsIGssIGsgKyBPLCB0aGlzLnVwZGF0ZVNjcm9sbENhbnZhcywgdGhpcy5nZXRUaW1lbGluZVVuaXQoKSkpO1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJ1cGRhdGVTY3JvbGxDYW52YXNcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IChULCBQLCBfID0gITEsIE8gPSB0aGlzLnByb3BzLml0ZW1zLCBrID0gdGhpcy5wcm9wcy5ncm91cHMpID0+IHtcbiAgICAgICAgdGhpcy5zZXRTdGF0ZShDcihULCBQLCBfLCBPLCBrLCB0aGlzLnByb3BzLCB0aGlzLnN0YXRlKSk7XG4gICAgICB9XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImhhbmRsZVdoZWVsWm9vbVwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKFQsIFAsIF8pID0+IHtcbiAgICAgICAgdGhpcy5jaGFuZ2Vab29tKDEgKyBUICogXyAvIDUwMCwgUCAvIHRoaXMuc3RhdGUud2lkdGgpO1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJjaGFuZ2Vab29tXCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiAoVCwgUCA9IDAuNSkgPT4ge1xuICAgICAgICBjb25zdCB7IG1pblpvb206IF8sIG1heFpvb206IE8gfSA9IHRoaXMucHJvcHMsIGsgPSB0aGlzLnN0YXRlLnZpc2libGVUaW1lRW5kIC0gdGhpcy5zdGF0ZS52aXNpYmxlVGltZVN0YXJ0LCBMID0gTWF0aC5taW4oTWF0aC5tYXgoTWF0aC5yb3VuZChrICogVCksIF8pLCBPKSwgSCA9IE1hdGgucm91bmQodGhpcy5zdGF0ZS52aXNpYmxlVGltZVN0YXJ0ICsgKGsgLSBMKSAqIFApO1xuICAgICAgICB0aGlzLnByb3BzLm9uVGltZUNoYW5nZSAmJiB0aGlzLnByb3BzLm9uVGltZUNoYW5nZShILCBIICsgTCwgdGhpcy51cGRhdGVTY3JvbGxDYW52YXMsIHRoaXMuZ2V0VGltZWxpbmVVbml0KCkpO1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJzaG93UGVyaW9kXCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiAoVCwgUCkgPT4ge1xuICAgICAgICB2YXIgTCwgSDtcbiAgICAgICAgY29uc3QgXyA9IFQudmFsdWVPZigpLCBrID0gUC52YWx1ZU9mKCkgLSBfO1xuICAgICAgICBrIDwgdGhpcy5wcm9wcy5taW5ab29tIHx8IChIID0gKEwgPSB0aGlzLnByb3BzKS5vblRpbWVDaGFuZ2UpID09IG51bGwgfHwgSC5jYWxsKEwsIF8sIF8gKyBrLCB0aGlzLnVwZGF0ZVNjcm9sbENhbnZhcywgdGhpcy5nZXRUaW1lbGluZVVuaXQoKSk7XG4gICAgICB9XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcInNlbGVjdEl0ZW1cIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IChULCBQLCBfKSA9PiB7XG4gICAgICAgIGlmICh0aGlzLmlzSXRlbVNlbGVjdGVkKFQpIHx8IHRoaXMucHJvcHMuaXRlbVRvdWNoU2VuZHNDbGljayAmJiBQID09PSBcInRvdWNoXCIpIHtcbiAgICAgICAgICBpZiAoVCAmJiB0aGlzLnByb3BzLm9uSXRlbUNsaWNrKSB7XG4gICAgICAgICAgICBjb25zdCBPID0gdGhpcy50aW1lRnJvbUl0ZW1FdmVudChfKTtcbiAgICAgICAgICAgIHRoaXMucHJvcHMub25JdGVtQ2xpY2soVCwgXywgTyk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKHRoaXMuc2V0U3RhdGUoeyBzZWxlY3RlZEl0ZW06IFQgfSksIFQgJiYgdGhpcy5wcm9wcy5vbkl0ZW1TZWxlY3QpIHtcbiAgICAgICAgICBjb25zdCBPID0gdGhpcy50aW1lRnJvbUl0ZW1FdmVudChfKTtcbiAgICAgICAgICB0aGlzLnByb3BzLm9uSXRlbVNlbGVjdChULCBfLCBPKTtcbiAgICAgICAgfSBlbHNlIFQgPT09IG51bGwgJiYgdGhpcy5wcm9wcy5vbkl0ZW1EZXNlbGVjdCAmJiB0aGlzLnByb3BzLm9uSXRlbURlc2VsZWN0KF8pO1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJkb3VibGVDbGlja0l0ZW1cIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IChULCBQKSA9PiB7XG4gICAgICAgIGlmICh0aGlzLnByb3BzLm9uSXRlbURvdWJsZUNsaWNrKSB7XG4gICAgICAgICAgY29uc3QgXyA9IHRoaXMudGltZUZyb21JdGVtRXZlbnQoUCk7XG4gICAgICAgICAgdGhpcy5wcm9wcy5vbkl0ZW1Eb3VibGVDbGljayhULCBQLCBfKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJjb250ZXh0TWVudUNsaWNrSXRlbVwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKFQsIFApID0+IHtcbiAgICAgICAgaWYgKHRoaXMucHJvcHMub25JdGVtQ29udGV4dE1lbnUpIHtcbiAgICAgICAgICBjb25zdCBfID0gdGhpcy50aW1lRnJvbUl0ZW1FdmVudChQKTtcbiAgICAgICAgICB0aGlzLnByb3BzLm9uSXRlbUNvbnRleHRNZW51KFQsIFAsIF8pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImdldFRpbWVGcm9tUm93Q2xpY2tFdmVudFwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKFQpID0+IHtcbiAgICAgICAgY29uc3QgeyBkcmFnU25hcDogUCwgYnVmZmVyOiBfIH0gPSB0aGlzLnByb3BzLCB7IHdpZHRoOiBPLCBjYW52YXNUaW1lU3RhcnQ6IGssIGNhbnZhc1RpbWVFbmQ6IEwgfSA9IHRoaXMuc3RhdGUsIHsgb2Zmc2V0WDogSCB9ID0gVC5uYXRpdmVFdmVudDtcbiAgICAgICAgbGV0IFggPSBNcihrLCBMLCB2ZShPLCBfKSwgSCk7XG4gICAgICAgIHJldHVybiBYID0gTWF0aC5mbG9vcihYIC8gUCkgKiBQLCBYO1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJ0aW1lRnJvbUl0ZW1FdmVudFwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKFQpID0+IHtcbiAgICAgICAgY29uc3QgeyB3aWR0aDogUCwgdmlzaWJsZVRpbWVTdGFydDogXywgdmlzaWJsZVRpbWVFbmQ6IE8gfSA9IHRoaXMuc3RhdGUsIGsgPSB0aGlzLnByb3BzLmRyYWdTbmFwLCBMID0gdGhpcy5zY3JvbGxDb21wb25lbnQsIHsgbGVmdDogSCB9ID0gTC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSwgQiA9IChULmNsaWVudFggLSBIKSAvIFAsIFYgPSBPIC0gXywgbGUgPSBCICogVjtcbiAgICAgICAgbGV0IHcgPSBNYXRoLnJvdW5kKF8gKyBsZSk7XG4gICAgICAgIHJldHVybiB3ID0gTWF0aC5mbG9vcih3IC8gaykgKiBrLCB3O1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJkcmFnSXRlbVwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKFQsIFAsIF8pID0+IHtcbiAgICAgICAgY29uc3QgTyA9IHRoaXMucHJvcHMuZ3JvdXBzW19dLCBrID0gdGhpcy5wcm9wcy5rZXlzO1xuICAgICAgICB0aGlzLnNldFN0YXRlKHtcbiAgICAgICAgICBkcmFnZ2luZ0l0ZW06IFQsXG4gICAgICAgICAgZHJhZ1RpbWU6IFAsXG4gICAgICAgICAgbmV3R3JvdXBPcmRlcjogXyxcbiAgICAgICAgICBkcmFnR3JvdXBUaXRsZTogTyA/IFkoTywgay5ncm91cExhYmVsS2V5KSA6IFwiXCJcbiAgICAgICAgfSksIHRoaXMudXBkYXRpbmdJdGVtKHtcbiAgICAgICAgICBldmVudFR5cGU6IFwibW92ZVwiLFxuICAgICAgICAgIGl0ZW1JZDogVCxcbiAgICAgICAgICB0aW1lOiBQLFxuICAgICAgICAgIG5ld0dyb3VwT3JkZXI6IF9cbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImRyb3BJdGVtXCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiAoVCwgUCwgXykgPT4ge1xuICAgICAgICB0aGlzLnNldFN0YXRlKHsgZHJhZ2dpbmdJdGVtOiBudWxsLCBkcmFnVGltZTogbnVsbCwgZHJhZ0dyb3VwVGl0bGU6IG51bGwgfSksIHRoaXMucHJvcHMub25JdGVtTW92ZSAmJiB0aGlzLnByb3BzLm9uSXRlbU1vdmUoVCwgUCwgXyk7XG4gICAgICB9XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcInJlc2l6aW5nSXRlbVwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKFQsIFAsIF8pID0+IHtcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7XG4gICAgICAgICAgcmVzaXppbmdJdGVtOiBULFxuICAgICAgICAgIHJlc2l6aW5nRWRnZTogXyxcbiAgICAgICAgICByZXNpemVUaW1lOiBQXG4gICAgICAgIH0pLCB0aGlzLnVwZGF0aW5nSXRlbSh7XG4gICAgICAgICAgZXZlbnRUeXBlOiBcInJlc2l6ZVwiLFxuICAgICAgICAgIGl0ZW1JZDogVCxcbiAgICAgICAgICB0aW1lOiBQLFxuICAgICAgICAgIGVkZ2U6IF8gfHwgdm9pZCAwXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJyZXNpemVkSXRlbVwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKFQsIFAsIF8sIE8pID0+IHtcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7IHJlc2l6aW5nSXRlbTogbnVsbCwgcmVzaXppbmdFZGdlOiBudWxsLCByZXNpemVUaW1lOiBudWxsIH0pLCB0aGlzLnByb3BzLm9uSXRlbVJlc2l6ZSAmJiBPICE9PSAwICYmIHRoaXMucHJvcHMub25JdGVtUmVzaXplKFQsIFAsIF8pO1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJ1cGRhdGluZ0l0ZW1cIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6ICh7IGV2ZW50VHlwZTogVCwgaXRlbUlkOiBQLCB0aW1lOiBfLCBlZGdlOiBPLCBuZXdHcm91cE9yZGVyOiBrIH0pID0+IHtcbiAgICAgICAgdGhpcy5wcm9wcy5vbkl0ZW1EcmFnICYmIChUID09PSBcIm1vdmVcIiA/IHRoaXMucHJvcHMub25JdGVtRHJhZyh7XG4gICAgICAgICAgZXZlbnRUeXBlOiBULFxuICAgICAgICAgIGl0ZW1JZDogUCxcbiAgICAgICAgICB0aW1lOiBfLFxuICAgICAgICAgIG5ld0dyb3VwT3JkZXI6IGtcbiAgICAgICAgfSkgOiB0aGlzLnByb3BzLm9uSXRlbURyYWcoe1xuICAgICAgICAgIGV2ZW50VHlwZTogVCxcbiAgICAgICAgICBpdGVtSWQ6IFAsXG4gICAgICAgICAgdGltZTogXyxcbiAgICAgICAgICBlZGdlOiBPXG4gICAgICAgIH0pKTtcbiAgICAgIH1cbiAgICB9KSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwiaGFuZGxlUm93Q2xpY2tcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IChULCBQKSA9PiB7XG4gICAgICAgIGlmICh0aGlzLmhhc1NlbGVjdGVkSXRlbSgpICYmIHRoaXMuc2VsZWN0SXRlbShudWxsLCBcImNsaWNrXCIsIFQpLCB0aGlzLnByb3BzLm9uQ2FudmFzQ2xpY2sgPT0gbnVsbClcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIGNvbnN0IF8gPSB0aGlzLmdldFRpbWVGcm9tUm93Q2xpY2tFdmVudChUKSwgTyA9IFkodGhpcy5wcm9wcy5ncm91cHNbUF0sIHRoaXMucHJvcHMua2V5cy5ncm91cElkS2V5KTtcbiAgICAgICAgdGhpcy5wcm9wcy5vbkNhbnZhc0NsaWNrKE8sIF8sIFQpO1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJoYW5kbGVSb3dEb3VibGVDbGlja1wiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKFQsIFApID0+IHtcbiAgICAgICAgaWYgKHRoaXMucHJvcHMub25DYW52YXNEb3VibGVDbGljayA9PSBudWxsKVxuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgY29uc3QgXyA9IHRoaXMuZ2V0VGltZUZyb21Sb3dDbGlja0V2ZW50KFQpLCBPID0gWSh0aGlzLnByb3BzLmdyb3Vwc1tQXSwgdGhpcy5wcm9wcy5rZXlzLmdyb3VwSWRLZXkpO1xuICAgICAgICB0aGlzLnByb3BzLm9uQ2FudmFzRG91YmxlQ2xpY2soTywgXywgVCk7XG4gICAgICB9XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImhhbmRsZVNjcm9sbENvbnRleHRNZW51XCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiAoVCwgUCkgPT4ge1xuICAgICAgICBpZiAodGhpcy5wcm9wcy5vbkNhbnZhc0NvbnRleHRNZW51ID09IG51bGwpXG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICBjb25zdCBfID0gdGhpcy5nZXRUaW1lRnJvbVJvd0NsaWNrRXZlbnQoVCksIE8gPSBZKHRoaXMucHJvcHMuZ3JvdXBzW1BdLCB0aGlzLnByb3BzLmtleXMuZ3JvdXBJZEtleSk7XG4gICAgICAgIHRoaXMucHJvcHMub25DYW52YXNDb250ZXh0TWVudSAmJiAoVC5wcmV2ZW50RGVmYXVsdCgpLCB0aGlzLnByb3BzLm9uQ2FudmFzQ29udGV4dE1lbnUoTywgXywgVCkpO1xuICAgICAgfVxuICAgIH0pLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJoYW5kbGVIZWFkZXJSZWZcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IChUKSA9PiB7XG4gICAgICAgIHRoaXMuc2Nyb2xsSGVhZGVyUmVmID0gVCwgdGhpcy5wcm9wcy5oZWFkZXJSZWYgJiYgdGhpcy5wcm9wcy5oZWFkZXJSZWYoVCk7XG4gICAgICB9XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImlzVGltZWxpbmVIZWFkZXJcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IChUKSA9PiBULnR5cGUgPT09IHZvaWQgMCA/ICExIDogVC50eXBlLnNlY3JldEtleSA9PT0gRXIuc2VjcmV0S2V5XG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcInJlbmRlckhlYWRlcnNcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6ICgpID0+IHtcbiAgICAgICAgaWYgKHRoaXMucHJvcHMuY2hpbGRyZW4pIHtcbiAgICAgICAgICBsZXQgVDtcbiAgICAgICAgICBpZiAoWi5DaGlsZHJlbi5tYXAodGhpcy5wcm9wcy5jaGlsZHJlbiwgKFApID0+IHtcbiAgICAgICAgICAgIHRoaXMuaXNUaW1lbGluZUhlYWRlcihQKSAmJiAoVCA9IFApO1xuICAgICAgICAgIH0pLCBUKVxuICAgICAgICAgICAgcmV0dXJuIFQ7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHplKEVyLCB7IGNoaWxkcmVuOiBbaihUaSwgeyB1bml0OiBcInByaW1hcnlIZWFkZXJcIiB9KSwgaihUaSwge30pXSB9KTtcbiAgICAgIH1cbiAgICB9KSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwiZ2V0U2Nyb2xsRWxlbWVudFJlZlwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKFQpID0+IHtcbiAgICAgICAgdGhpcy5wcm9wcy5zY3JvbGxSZWYgJiYgdGhpcy5wcm9wcy5zY3JvbGxSZWYoVCksIHRoaXMuc2Nyb2xsQ29tcG9uZW50ID0gVDtcbiAgICAgIH1cbiAgICB9KSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwiY29udGFpbmVyXCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiBaLmNyZWF0ZVJlZigpXG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImdldEJvdW5kaW5nQ2xpZW50UmVjdFwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogKCkgPT4gdGhpcy5zY3JvbGxDb21wb25lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KClcbiAgICB9KSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwiY2FsY3VsYXRlRHJvcENvb3JkaW5hdGVzVG9UaW1lQW5kR3JvdXBcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IChULCBQKSA9PiB7XG4gICAgICAgIGNvbnN0IF8gPSB2ZSh0aGlzLnN0YXRlLndpZHRoLCB0aGlzLnByb3BzLmJ1ZmZlciksIE8gPSBNdCh0aGlzLnN0YXRlLmNhbnZhc1RpbWVTdGFydCwgdGhpcy5zdGF0ZS5jYW52YXNUaW1lRW5kLCBfKSwgayA9IEN0KHRoaXMuc2Nyb2xsQ29tcG9uZW50KS5vZmZzZXRMZWZ0LCBMID0gT3QodGhpcy5zY3JvbGxDb21wb25lbnQpLCBIID0gKFQgLSBrICsgTC5zY3JvbGxMZWZ0KSAqIE8gKyB0aGlzLnN0YXRlLmNhbnZhc1RpbWVTdGFydDtcbiAgICAgICAgbGV0IFggPSAwO1xuICAgICAgICBmb3IgKGNvbnN0IFYgb2YgdGhpcy5zdGF0ZS5ncm91cFRvcHMpXG4gICAgICAgICAgaWYgKFAgPiBOdW1iZXIoVikpXG4gICAgICAgICAgICBYID0gdGhpcy5zdGF0ZS5ncm91cFRvcHMuaW5kZXhPZihWKTtcbiAgICAgICAgICBlbHNlXG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgaWYgKCF0aGlzLnByb3BzLmRyYWdTbmFwKVxuICAgICAgICAgIHJldHVybiB7IHRpbWU6IEgsIGdyb3VwSW5kZXg6IFggfTtcbiAgICAgICAgY29uc3QgQiA9IHVlKCkudXRjT2Zmc2V0KCkgKiA2MCAqIDFlMztcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICB0aW1lOiBNYXRoLnJvdW5kKEggLyB0aGlzLnByb3BzLmRyYWdTbmFwKSAqIHRoaXMucHJvcHMuZHJhZ1NuYXAgLSBCICUgdGhpcy5wcm9wcy5kcmFnU25hcCxcbiAgICAgICAgICBncm91cEluZGV4OiBYXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfSksIHRoaXMuZ2V0U2VsZWN0ZWQgPSB0aGlzLmdldFNlbGVjdGVkLmJpbmQodGhpcyksIHRoaXMuaGFzU2VsZWN0ZWRJdGVtID0gdGhpcy5oYXNTZWxlY3RlZEl0ZW0uYmluZCh0aGlzKSwgdGhpcy5pc0l0ZW1TZWxlY3RlZCA9IHRoaXMuaXNJdGVtU2VsZWN0ZWQuYmluZCh0aGlzKTtcbiAgICBsZXQgcyA9IG51bGwsIHUgPSBudWxsO1xuICAgIGlmICh0aGlzLnByb3BzLmRlZmF1bHRUaW1lU3RhcnQgJiYgdGhpcy5wcm9wcy5kZWZhdWx0VGltZUVuZClcbiAgICAgIHMgPSB0aGlzLnByb3BzLmRlZmF1bHRUaW1lU3RhcnQsIHUgPSB0aGlzLnByb3BzLmRlZmF1bHRUaW1lRW5kO1xuICAgIGVsc2UgaWYgKHRoaXMucHJvcHMudmlzaWJsZVRpbWVTdGFydCAmJiB0aGlzLnByb3BzLnZpc2libGVUaW1lRW5kKVxuICAgICAgcyA9IHRoaXMucHJvcHMudmlzaWJsZVRpbWVTdGFydCwgdSA9IHRoaXMucHJvcHMudmlzaWJsZVRpbWVFbmQ7XG4gICAgZWxzZVxuICAgICAgdGhyb3cgbmV3IEVycm9yKCdZb3UgbXVzdCBwcm92aWRlIGVpdGhlciBcImRlZmF1bHRUaW1lU3RhcnRcIiBhbmQgXCJkZWZhdWx0VGltZUVuZFwiIG9yIFwidmlzaWJsZVRpbWVTdGFydFwiIGFuZCBcInZpc2libGVUaW1lRW5kXCIgdG8gaW5pdGlhbGl6ZSB0aGUgVGltZWxpbmUnKTtcbiAgICBjb25zdCBbdiwgZl0gPSAkcihzLCB1LCBpLmJ1ZmZlciksIG0gPSB7XG4gICAgICB3aWR0aDogMWUzLFxuICAgICAgdmlzaWJsZVRpbWVTdGFydDogcyxcbiAgICAgIHZpc2libGVUaW1lRW5kOiB1LFxuICAgICAgY2FudmFzVGltZVN0YXJ0OiB2LFxuICAgICAgY2FudmFzVGltZUVuZDogZixcbiAgICAgIHNlbGVjdGVkSXRlbTogbnVsbCxcbiAgICAgIGRyYWdUaW1lOiBudWxsLFxuICAgICAgZHJhZ0dyb3VwVGl0bGU6IG51bGwsXG4gICAgICByZXNpemVUaW1lOiBudWxsLFxuICAgICAgcmVzaXppbmdJdGVtOiBudWxsLFxuICAgICAgcmVzaXppbmdFZGdlOiBudWxsLFxuICAgICAgbmV3R3JvdXBPcmRlcjogMFxuICAgICAgLy9DSEVDS1xuICAgIH0sIHkgPSB2ZShtLndpZHRoLCBpLmJ1ZmZlciksIHsgZGltZW5zaW9uSXRlbXM6IFMsIGhlaWdodDogQywgZ3JvdXBIZWlnaHRzOiBELCBncm91cFRvcHM6IFIgfSA9ICRlKGkuaXRlbXMsIGkuZ3JvdXBzLCB5LCBtLmNhbnZhc1RpbWVTdGFydCwgbS5jYW52YXNUaW1lRW5kLCBpLmtleXMsIGkubGluZUhlaWdodCwgaS5pdGVtSGVpZ2h0UmF0aW8sIGkuc3RhY2tJdGVtcywgbS5kcmFnZ2luZ0l0ZW0sIG0ucmVzaXppbmdJdGVtLCBtLmRyYWdUaW1lLCBtLnJlc2l6aW5nRWRnZSwgbS5yZXNpemVUaW1lLCBtLm5ld0dyb3VwT3JkZXIsIGkuaXRlbVZlcnRpY2FsR2FwKTtcbiAgICBtLmRpbWVuc2lvbkl0ZW1zID0gUywgbS5oZWlnaHQgPSBDLCBtLmdyb3VwSGVpZ2h0cyA9IEQsIG0uZ3JvdXBUb3BzID0gUiwgdGhpcy5zdGF0ZSA9IG07XG4gIH1cbiAgY29tcG9uZW50RGlkTW91bnQoKSB7XG4gICAgdGhpcy5yZXNpemUodGhpcy5wcm9wcyksIHRoaXMucHJvcHMucmVzaXplRGV0ZWN0b3IgJiYgdGhpcy5wcm9wcy5yZXNpemVEZXRlY3Rvci5hZGRMaXN0ZW5lciAmJiB0aGlzLnByb3BzLnJlc2l6ZURldGVjdG9yLmFkZExpc3RlbmVyKHRoaXMpLCBnaS5hZGRMaXN0ZW5lcih0aGlzKTtcbiAgfVxuICBjb21wb25lbnRXaWxsVW5tb3VudCgpIHtcbiAgICB0aGlzLnByb3BzLnJlc2l6ZURldGVjdG9yICYmIHRoaXMucHJvcHMucmVzaXplRGV0ZWN0b3IuYWRkTGlzdGVuZXIgJiYgdGhpcy5wcm9wcy5yZXNpemVEZXRlY3Rvci5yZW1vdmVMaXN0ZW5lcih0aGlzKSwgZ2kucmVtb3ZlTGlzdGVuZXIodGhpcyk7XG4gIH1cbiAgc3RhdGljIGdldERlcml2ZWRTdGF0ZUZyb21Qcm9wcyhpLCBzKSB7XG4gICAgY29uc3QgeyB2aXNpYmxlVGltZVN0YXJ0OiB1LCB2aXNpYmxlVGltZUVuZDogdiwgaXRlbXM6IGYsIGdyb3VwczogbSB9ID0gaSwgeSA9IHsgaXRlbXM6IGYsIGdyb3VwczogbSB9LCBTID0gZiAhPT0gcy5pdGVtcyB8fCBtICE9PSBzLmdyb3VwcztcbiAgICBpZiAodSAmJiB2KVxuICAgICAgT2JqZWN0LmFzc2lnbih5LCBDcih1LCB2LCBTLCBmLCBtLCBpLCBzKSk7XG4gICAgZWxzZSBpZiAoUykge1xuICAgICAgY29uc3QgQyA9IHZlKHMud2lkdGgsIGkuYnVmZmVyKTtcbiAgICAgIE9iamVjdC5hc3NpZ24oeSwgJGUoZiwgbSwgQywgcy5jYW52YXNUaW1lU3RhcnQsIHMuY2FudmFzVGltZUVuZCwgaS5rZXlzLCBpLmxpbmVIZWlnaHQsIGkuaXRlbUhlaWdodFJhdGlvLCBpLnN0YWNrSXRlbXMsIHMuZHJhZ2dpbmdJdGVtLCBzLnJlc2l6aW5nSXRlbSwgcy5kcmFnVGltZSwgcy5yZXNpemluZ0VkZ2UsIHMucmVzaXplVGltZSwgcy5uZXdHcm91cE9yZGVyLCBpLml0ZW1WZXJ0aWNhbEdhcCkpO1xuICAgIH1cbiAgICByZXR1cm4geTtcbiAgfVxuICBjb21wb25lbnREaWRVcGRhdGUoaSwgcykge1xuICAgIGNvbnN0IHUgPSB0aGlzLnN0YXRlLnZpc2libGVUaW1lRW5kIC0gdGhpcy5zdGF0ZS52aXNpYmxlVGltZVN0YXJ0LCB2ID0gcy52aXNpYmxlVGltZUVuZCAtIHMudmlzaWJsZVRpbWVTdGFydDtcbiAgICB0aGlzLnByb3BzLm9uWm9vbSAmJiB1ICE9PSB2ICYmIHRoaXMucHJvcHMub25ab29tKHRoaXMuZ2V0VGltZWxpbmVDb250ZXh0KCksIHRoaXMuZ2V0VGltZWxpbmVVbml0KCkpLCB0aGlzLnByb3BzLm9uQm91bmRzQ2hhbmdlICYmIHRoaXMuc3RhdGUuY2FudmFzVGltZVN0YXJ0ICE9PSBzLmNhbnZhc1RpbWVTdGFydCAmJiB0aGlzLnByb3BzLm9uQm91bmRzQ2hhbmdlKHRoaXMuc3RhdGUuY2FudmFzVGltZVN0YXJ0LCB0aGlzLnN0YXRlLmNhbnZhc1RpbWVTdGFydCArIHUgKiAzKTtcbiAgICBjb25zdCBmID0gTWF0aC5yb3VuZCh0aGlzLnN0YXRlLndpZHRoICogKHRoaXMuc3RhdGUudmlzaWJsZVRpbWVTdGFydCAtIHRoaXMuc3RhdGUuY2FudmFzVGltZVN0YXJ0KSAvIHUpO1xuICAgIChNYXRoLnJvdW5kKHMud2lkdGggKiAocy52aXNpYmxlVGltZVN0YXJ0IC0gcy5jYW52YXNUaW1lU3RhcnQpIC8gdikgIT09IGYgfHwgdGhpcy5zY3JvbGxDb21wb25lbnQuc2Nyb2xsTGVmdCAhPT0gZikgJiYgKHRoaXMuc2Nyb2xsQ29tcG9uZW50LnNjcm9sbExlZnQgPSBmLCB0aGlzLnNjcm9sbEhlYWRlclJlZi5zY3JvbGxMZWZ0ID0gZik7XG4gIH1cbiAgY29sdW1ucyhpLCBzLCB1LCB2LCBmLCBtKSB7XG4gICAgdmFyIHk7XG4gICAgcmV0dXJuIGoobWQsIHsgY2FudmFzVGltZVN0YXJ0OiBpLCBjYW52YXNUaW1lRW5kOiBzLCBjYW52YXNXaWR0aDogdSwgbGluZUNvdW50OiAoKHkgPSB0aGlzLnByb3BzLmdyb3VwcykgPT0gbnVsbCA/IHZvaWQgMCA6IHkubGVuZ3RoKSB8fCAwLCBtaW5Vbml0OiB2LCB0aW1lU3RlcHM6IGYsIGhlaWdodDogbSwgdmVydGljYWxMaW5lQ2xhc3NOYW1lc0ZvclRpbWU6IHRoaXMucHJvcHMudmVydGljYWxMaW5lQ2xhc3NOYW1lc0ZvclRpbWUgfSk7XG4gIH1cbiAgcm93cyhpLCBzLCB1KSB7XG4gICAgdmFyIHY7XG4gICAgcmV0dXJuIGooVGQsIHsgZ3JvdXBzOiB1LCBjYW52YXNXaWR0aDogaSwgbGluZUNvdW50OiAoKHYgPSB0aGlzLnByb3BzLmdyb3VwcykgPT0gbnVsbCA/IHZvaWQgMCA6IHYubGVuZ3RoKSB8fCAwLCBncm91cEhlaWdodHM6IHMsIGNsaWNrVG9sZXJhbmNlOiB0aGlzLnByb3BzLmNsaWNrVG9sZXJhbmNlLCBvblJvd0NsaWNrOiB0aGlzLmhhbmRsZVJvd0NsaWNrLCBvblJvd0RvdWJsZUNsaWNrOiB0aGlzLmhhbmRsZVJvd0RvdWJsZUNsaWNrLCBob3Jpem9udGFsTGluZUNsYXNzTmFtZXNGb3JHcm91cDogdGhpcy5wcm9wcy5ob3Jpem9udGFsTGluZUNsYXNzTmFtZXNGb3JHcm91cCwgb25Sb3dDb250ZXh0Q2xpY2s6IHRoaXMuaGFuZGxlU2Nyb2xsQ29udGV4dE1lbnUgfSk7XG4gIH1cbiAgaXRlbXMoeyBjYW52YXNUaW1lU3RhcnQ6IGksIGNhbnZhc1RpbWVFbmQ6IHMsIGNhbnZhc1dpZHRoOiB1LCBkaW1lbnNpb25JdGVtczogdiwgZ3JvdXBUb3BzOiBmIH0pIHtcbiAgICByZXR1cm4gaih2ZCwgeyBjYW52YXNUaW1lU3RhcnQ6IGksIGNhbnZhc1RpbWVFbmQ6IHMsIGNhbnZhc1dpZHRoOiB1LCBkaW1lbnNpb25JdGVtczogdiwgZ3JvdXBUb3BzOiBmLCBpdGVtczogdGhpcy5wcm9wcy5pdGVtcywgZ3JvdXBzOiB0aGlzLnByb3BzLmdyb3Vwcywga2V5czogdGhpcy5wcm9wcy5rZXlzLCBzZWxlY3RlZEl0ZW06IHRoaXMuc3RhdGUuc2VsZWN0ZWRJdGVtIHx8IHZvaWQgMCwgZHJhZ1NuYXA6IHRoaXMucHJvcHMuZHJhZ1NuYXAsIG1pblJlc2l6ZVdpZHRoOiB0aGlzLnByb3BzLm1pblJlc2l6ZVdpZHRoLCBjYW5DaGFuZ2VHcm91cDogdGhpcy5wcm9wcy5jYW5DaGFuZ2VHcm91cCwgY2FuTW92ZTogdGhpcy5wcm9wcy5jYW5Nb3ZlLCBjYW5SZXNpemU6IHRoaXMucHJvcHMuY2FuUmVzaXplLCB1c2VSZXNpemVIYW5kbGU6IHRoaXMucHJvcHMudXNlUmVzaXplSGFuZGxlLCBjYW5TZWxlY3Q6IHRoaXMucHJvcHMuY2FuU2VsZWN0LCBtb3ZlUmVzaXplVmFsaWRhdG9yOiB0aGlzLnByb3BzLm1vdmVSZXNpemVWYWxpZGF0b3IsIGl0ZW1TZWxlY3Q6IHRoaXMuc2VsZWN0SXRlbSwgaXRlbURyYWc6IHRoaXMuZHJhZ0l0ZW0sIGl0ZW1Ecm9wOiB0aGlzLmRyb3BJdGVtLCBvbkl0ZW1Eb3VibGVDbGljazogdGhpcy5kb3VibGVDbGlja0l0ZW0sIG9uSXRlbUNvbnRleHRNZW51OiB0aGlzLnByb3BzLm9uSXRlbUNvbnRleHRNZW51ID8gdGhpcy5jb250ZXh0TWVudUNsaWNrSXRlbSA6IHZvaWQgMCwgaXRlbVJlc2l6aW5nOiB0aGlzLnJlc2l6aW5nSXRlbSwgaXRlbVJlc2l6ZWQ6IHRoaXMucmVzaXplZEl0ZW0sIGl0ZW1SZW5kZXJlcjogdGhpcy5wcm9wcy5pdGVtUmVuZGVyZXIsIHNlbGVjdGVkOiB0aGlzLnByb3BzLnNlbGVjdGVkLCBzY3JvbGxSZWY6IHRoaXMuc2Nyb2xsQ29tcG9uZW50IH0pO1xuICB9XG4gIHNpZGViYXIoaSwgcykge1xuICAgIGNvbnN0IHsgc2lkZWJhcldpZHRoOiB1IH0gPSB0aGlzLnByb3BzO1xuICAgIHJldHVybiB1ICYmIGooZmksIHsgZ3JvdXBzOiB0aGlzLnByb3BzLmdyb3VwcywgZ3JvdXBSZW5kZXJlcjogdGhpcy5wcm9wcy5ncm91cFJlbmRlcmVyLCBrZXlzOiB0aGlzLnByb3BzLmtleXMsIHdpZHRoOiB1LCBncm91cEhlaWdodHM6IHMsIGhlaWdodDogaSB9KTtcbiAgfVxuICByaWdodFNpZGViYXIoaSwgcykge1xuICAgIGNvbnN0IHsgcmlnaHRTaWRlYmFyV2lkdGg6IHUgfSA9IHRoaXMucHJvcHM7XG4gICAgcmV0dXJuIHUgJiYgaihmaSwgeyBncm91cHM6IHRoaXMucHJvcHMuZ3JvdXBzLCBrZXlzOiB0aGlzLnByb3BzLmtleXMsIGdyb3VwUmVuZGVyZXI6IHRoaXMucHJvcHMuZ3JvdXBSZW5kZXJlciwgaXNSaWdodFNpZGViYXI6ICEwLCB3aWR0aDogdSwgZ3JvdXBIZWlnaHRzOiBzLCBoZWlnaHQ6IGkgfSk7XG4gIH1cbiAgY2hpbGRyZW5XaXRoUHJvcHMoaSwgcywgdSwgdiwgZiwgbSwgeSwgUywgQywgRCwgUikge1xuICAgIGlmICghdGhpcy5wcm9wcy5jaGlsZHJlbilcbiAgICAgIHJldHVybiBudWxsO1xuICAgIGNvbnN0IFQgPSBBcnJheS5pc0FycmF5KHRoaXMucHJvcHMuY2hpbGRyZW4pID8gdGhpcy5wcm9wcy5jaGlsZHJlbi5maWx0ZXIoKF8pID0+IF8pIDogW3RoaXMucHJvcHMuY2hpbGRyZW5dLCBQID0ge1xuICAgICAgY2FudmFzVGltZVN0YXJ0OiBpLFxuICAgICAgY2FudmFzVGltZUVuZDogcyxcbiAgICAgIGNhbnZhc1dpZHRoOiB1LFxuICAgICAgdmlzaWJsZVRpbWVTdGFydDogUyxcbiAgICAgIHZpc2libGVUaW1lRW5kOiBDLFxuICAgICAgZGltZW5zaW9uSXRlbXM6IHYsXG4gICAgICBpdGVtczogdGhpcy5wcm9wcy5pdGVtcyxcbiAgICAgIGdyb3VwczogdGhpcy5wcm9wcy5ncm91cHMsXG4gICAgICBrZXlzOiB0aGlzLnByb3BzLmtleXMsXG4gICAgICBncm91cEhlaWdodHM6IGYsXG4gICAgICBncm91cFRvcHM6IG0sXG4gICAgICBzZWxlY3RlZDogdGhpcy5nZXRTZWxlY3RlZCgpLFxuICAgICAgaGVpZ2h0OiB5LFxuICAgICAgbWluVW5pdDogRCxcbiAgICAgIHRpbWVTdGVwczogUlxuICAgIH07XG4gICAgcmV0dXJuIFouQ2hpbGRyZW4ubWFwKFQsIChfKSA9PiB0aGlzLmlzVGltZWxpbmVIZWFkZXIoXykgPyBudWxsIDogWi5jbG9uZUVsZW1lbnQoXywgUCkpO1xuICB9XG4gIGdldFNlbGVjdGVkKCkge1xuICAgIHJldHVybiB0aGlzLnN0YXRlLnNlbGVjdGVkSXRlbSAmJiAhdGhpcy5wcm9wcy5zZWxlY3RlZCA/IFt0aGlzLnN0YXRlLnNlbGVjdGVkSXRlbV0gOiB0aGlzLnByb3BzLnNlbGVjdGVkIHx8IFtdO1xuICB9XG4gIGhhc1NlbGVjdGVkSXRlbSgpIHtcbiAgICByZXR1cm4gQXJyYXkuaXNBcnJheSh0aGlzLnByb3BzLnNlbGVjdGVkKSA/IHRoaXMucHJvcHMuc2VsZWN0ZWQubGVuZ3RoID4gMCA6ICEhdGhpcy5zdGF0ZS5zZWxlY3RlZEl0ZW07XG4gIH1cbiAgaXNJdGVtU2VsZWN0ZWQoaSkge1xuICAgIHJldHVybiB0aGlzLmdldFNlbGVjdGVkKCkuc29tZSgodSkgPT4gdSA9PT0gaSk7XG4gIH1cbiAgcmVuZGVyKCkge1xuICAgIGNvbnN0IHsgaXRlbXM6IGksIGdyb3Vwczogcywgc2lkZWJhcldpZHRoOiB1LCByaWdodFNpZGViYXJXaWR0aDogdiwgdGltZVN0ZXBzOiBmLCB0cmFkaXRpb25hbFpvb206IG0sIGJ1ZmZlcjogeSB9ID0gdGhpcy5wcm9wcywgeyBkcmFnZ2luZ0l0ZW06IFMsIHJlc2l6aW5nSXRlbTogQywgd2lkdGg6IEQsIHZpc2libGVUaW1lU3RhcnQ6IFIsIHZpc2libGVUaW1lRW5kOiBULCBjYW52YXNUaW1lU3RhcnQ6IFAsIGNhbnZhc1RpbWVFbmQ6IF8gfSA9IHRoaXMuc3RhdGU7XG4gICAgbGV0IHsgZGltZW5zaW9uSXRlbXM6IE8sIGhlaWdodDogaywgZ3JvdXBIZWlnaHRzOiBMLCBncm91cFRvcHM6IEggfSA9IHRoaXMuc3RhdGU7XG4gICAgY29uc3QgWCA9IFQgLSBSLCBCID0gdmUoRCwgeSksIFYgPSB4dChYLCBELCBmKTtcbiAgICBpZiAoISFTIHx8ICEhQykge1xuICAgICAgY29uc3QgY2UgPSAkZShpLCBzLCBCLCB0aGlzLnN0YXRlLmNhbnZhc1RpbWVTdGFydCwgdGhpcy5zdGF0ZS5jYW52YXNUaW1lRW5kLCB0aGlzLnByb3BzLmtleXMsIHRoaXMucHJvcHMubGluZUhlaWdodCwgdGhpcy5wcm9wcy5pdGVtSGVpZ2h0UmF0aW8sIHRoaXMucHJvcHMuc3RhY2tJdGVtcywgdGhpcy5zdGF0ZS5kcmFnZ2luZ0l0ZW0sIHRoaXMuc3RhdGUucmVzaXppbmdJdGVtLCB0aGlzLnN0YXRlLmRyYWdUaW1lLCB0aGlzLnN0YXRlLnJlc2l6aW5nRWRnZSwgdGhpcy5zdGF0ZS5yZXNpemVUaW1lLCB0aGlzLnN0YXRlLm5ld0dyb3VwT3JkZXIsIHRoaXMucHJvcHMuaXRlbVZlcnRpY2FsR2FwKTtcbiAgICAgIE8gPSBjZS5kaW1lbnNpb25JdGVtcywgayA9IGNlLmhlaWdodCwgTCA9IGNlLmdyb3VwSGVpZ2h0cywgSCA9IGNlLmdyb3VwVG9wcztcbiAgICB9XG4gICAgY29uc3QgdyA9IHtcbiAgICAgIGhlaWdodDogYCR7a31weGBcbiAgICB9O1xuICAgIHJldHVybiBqKHBkLCB7IHZpc2libGVUaW1lU3RhcnQ6IFIsIHZpc2libGVUaW1lRW5kOiBULCBjYW52YXNUaW1lU3RhcnQ6IFAsIGNhbnZhc1RpbWVFbmQ6IF8sIGNhbnZhc1dpZHRoOiBCLCBzaG93UGVyaW9kOiB0aGlzLnNob3dQZXJpb2QsIHRpbWVsaW5lVW5pdDogViwgdGltZWxpbmVXaWR0aDogdGhpcy5zdGF0ZS53aWR0aCwgY2hpbGRyZW46IGooUmQsIHsgY2hpbGRyZW46IGooS2QsIHsgcmVnaXN0ZXJTY3JvbGw6IHRoaXMuaGFuZGxlSGVhZGVyUmVmLCB0aW1lU3RlcHM6IGYsIGxlZnRTaWRlYmFyV2lkdGg6IHRoaXMucHJvcHMuc2lkZWJhcldpZHRoLCByaWdodFNpZGViYXJXaWR0aDogdGhpcy5wcm9wcy5yaWdodFNpZGViYXJXaWR0aCwgY2hpbGRyZW46IHplKFwiZGl2XCIsIHsgc3R5bGU6IHRoaXMucHJvcHMuc3R5bGUsIHJlZjogdGhpcy5jb250YWluZXIsIGNsYXNzTmFtZTogYHJlYWN0LWNhbGVuZGFyLXRpbWVsaW5lICR7dGhpcy5wcm9wcy5jbGFzc05hbWV9YCwgY2hpbGRyZW46IFt0aGlzLnJlbmRlckhlYWRlcnMoKSwgemUoXCJkaXZcIiwgeyBzdHlsZTogdywgY2xhc3NOYW1lOiBcInJjdC1vdXRlclwiLCBjaGlsZHJlbjogW3UgPiAwID8gdGhpcy5zaWRlYmFyKGssIEwpIDogbnVsbCwgaih3ZCwgeyBzY3JvbGxSZWY6IHRoaXMuZ2V0U2Nyb2xsRWxlbWVudFJlZiwgd2lkdGg6IEQsIGhlaWdodDogaywgb25ab29tOiB0aGlzLmNoYW5nZVpvb20sIG9uV2hlZWxab29tOiB0aGlzLmhhbmRsZVdoZWVsWm9vbSwgdHJhZGl0aW9uYWxab29tOiAhIW0sIG9uU2Nyb2xsOiB0aGlzLm9uU2Nyb2xsLCBjaGlsZHJlbjogemUoSGQsIHsgY2hpbGRyZW46IFt0aGlzLmNvbHVtbnMoUCwgXywgQiwgViwgZiwgayksIHRoaXMucm93cyhCLCBMLCBzKSwgdGhpcy5pdGVtcyh7XG4gICAgICBjYW52YXNUaW1lU3RhcnQ6IFAsXG4gICAgICBjYW52YXNUaW1lRW5kOiBfLFxuICAgICAgY2FudmFzV2lkdGg6IEIsXG4gICAgICBkaW1lbnNpb25JdGVtczogTyxcbiAgICAgIGdyb3VwVG9wczogSFxuICAgIH0pLCB0aGlzLmNoaWxkcmVuV2l0aFByb3BzKFAsIF8sIEIsIE8sIEwsIEgsIGssIFIsIFQsIFYsIGYpXSB9KSB9KSwgdiA+IDAgPyB0aGlzLnJpZ2h0U2lkZWJhcihrLCBMKSA6IG51bGxdIH0pXSB9KSB9KSB9KSB9KTtcbiAgfVxufVxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGlvLCBcInNldERheWpzTG9jYWxlXCIsIHtcbiAgZW51bWVyYWJsZTogITAsXG4gIGNvbmZpZ3VyYWJsZTogITAsXG4gIHdyaXRhYmxlOiAhMCxcbiAgdmFsdWU6IHVlLmxvY2FsZVxufSk7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoaW8sIFwiZGVmYXVsdFByb3BzXCIsIHtcbiAgZW51bWVyYWJsZTogITAsXG4gIGNvbmZpZ3VyYWJsZTogITAsXG4gIHdyaXRhYmxlOiAhMCxcbiAgdmFsdWU6IHtcbiAgICBzaWRlYmFyV2lkdGg6IDE1MCxcbiAgICByaWdodFNpZGViYXJXaWR0aDogMCxcbiAgICBkcmFnU25hcDogMWUzICogNjAgKiAxNSxcbiAgICAvLyAxNW1pblxuICAgIG1pblJlc2l6ZVdpZHRoOiAyMCxcbiAgICBsaW5lSGVpZ2h0OiAzMCxcbiAgICBpdGVtSGVpZ2h0UmF0aW86IDAuNjUsXG4gICAgYnVmZmVyOiAzLFxuICAgIG1pblpvb206IDYwICogNjAgKiAxZTMsXG4gICAgLy8gMSBob3VyXG4gICAgbWF4Wm9vbTogNSAqIDM2NS4yNCAqIDg2NDAwICogMWUzLFxuICAgIC8vIDUgeWVhcnNcbiAgICBjbGlja1RvbGVyYW5jZTogMyxcbiAgICAvLyBob3cgbWFueSBwaXhlbHMgY2FuIHdlIGRyYWcgZm9yIGl0IHRvIGJlIHN0aWxsIGNvbnNpZGVyZWQgYSBjbGljaz9cbiAgICBjYW5DaGFuZ2VHcm91cDogITAsXG4gICAgY2FuTW92ZTogITAsXG4gICAgY2FuUmVzaXplOiBcInJpZ2h0XCIsXG4gICAgdXNlUmVzaXplSGFuZGxlOiAhMSxcbiAgICBjYW5TZWxlY3Q6ICEwLFxuICAgIHN0YWNrSXRlbXM6ICExLFxuICAgIHRyYWRpdGlvbmFsWm9vbTogITEsXG4gICAgaG9yaXpvbnRhbExpbmVDbGFzc05hbWVzRm9yR3JvdXA6IG51bGwsXG4gICAgb25JdGVtTW92ZTogbnVsbCxcbiAgICBvbkl0ZW1SZXNpemU6IG51bGwsXG4gICAgb25JdGVtQ2xpY2s6IG51bGwsXG4gICAgb25JdGVtU2VsZWN0OiBudWxsLFxuICAgIG9uSXRlbURlc2VsZWN0OiBudWxsLFxuICAgIG9uSXRlbURyYWc6IG51bGwsXG4gICAgb25DYW52YXNDbGljazogbnVsbCxcbiAgICBvbkl0ZW1Eb3VibGVDbGljazogbnVsbCxcbiAgICBvbkl0ZW1Db250ZXh0TWVudTogbnVsbCxcbiAgICBvblpvb206IG51bGwsXG4gICAgdmVydGljYWxMaW5lQ2xhc3NOYW1lc0ZvclRpbWU6IG51bGwsXG4gICAgbW92ZVJlc2l6ZVZhbGlkYXRvcjogbnVsbCxcbiAgICBkYXlCYWNrZ3JvdW5kOiBudWxsLFxuICAgIGRlZmF1bHRUaW1lU3RhcnQ6IG51bGwsXG4gICAgZGVmYXVsdFRpbWVFbmQ6IG51bGwsXG4gICAgaXRlbVRvdWNoU2VuZHNDbGljazogITEsXG4gICAgc3R5bGU6IHt9LFxuICAgIGNsYXNzTmFtZTogXCJcIixcbiAgICBrZXlzOiBVZCxcbiAgICB0aW1lU3RlcHM6IE5kLFxuICAgIGhlYWRlclJlZjogKCkgPT4ge1xuICAgIH0sXG4gICAgc2Nyb2xsUmVmOiAoKSA9PiB7XG4gICAgfSxcbiAgICAvLyBpZiB5b3UgcGFzcyBpbiB2aXNpYmxlVGltZVN0YXJ0IGFuZCB2aXNpYmxlVGltZUVuZCwgeW91IG11c3QgYWxzbyBwYXNzIG9uVGltZUNoYW5nZSh2aXNpYmxlVGltZVN0YXJ0LCB2aXNpYmxlVGltZUVuZCksXG4gICAgLy8gd2hpY2ggbmVlZHMgdG8gdXBkYXRlIHRoZSBwcm9wcyB2aXNpYmxlVGltZVN0YXJ0IGFuZCB2aXNpYmxlVGltZUVuZCB0byB0aGUgb25lcyBwYXNzZWRcbiAgICB2aXNpYmxlVGltZVN0YXJ0OiBudWxsLFxuICAgIHZpc2libGVUaW1lRW5kOiBudWxsLFxuICAgIG9uVGltZUNoYW5nZTogZnVuY3Rpb24oYSwgaSwgcykge1xuICAgICAgcyhhLCBpKTtcbiAgICB9LFxuICAgIC8vIGNhbGxlZCB3aGVuIHRoZSBjYW52YXMgYXJlYSBvZiB0aGUgY2FsZW5kYXIgY2hhbmdlc1xuICAgIG9uQm91bmRzQ2hhbmdlOiBudWxsLFxuICAgIGNoaWxkcmVuOiBudWxsLFxuICAgIHNlbGVjdGVkOiBudWxsXG4gIH1cbn0pO1xuY29uc3Qgd2YgPSAoYSkgPT4gYS5jaGlsZHJlbiB8fCBudWxsO1xuY2xhc3Mgb28gZXh0ZW5kcyBaLkNvbXBvbmVudCB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKC4uLmFyZ3VtZW50cyksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcInVuc3Vic2NyaWJlXCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiBudWxsXG4gICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImdldE1hcmtlclwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogbnVsbFxuICAgIH0pO1xuICB9XG4gIGNvbXBvbmVudERpZE1vdW50KCkge1xuICAgIGNvbnN0IHsgdW5zdWJzY3JpYmU6IGksIGdldE1hcmtlcjogcyB9ID0gdGhpcy5wcm9wcy5zdWJzY3JpYmVNYXJrZXIoe1xuICAgICAgdHlwZTogeGUuVG9kYXksXG4gICAgICByZW5kZXJlcjogdGhpcy5wcm9wcy5jaGlsZHJlbixcbiAgICAgIGludGVydmFsOiB0aGlzLnByb3BzLmludGVydmFsXG4gICAgfSk7XG4gICAgdGhpcy51bnN1YnNjcmliZSA9IGksIHRoaXMuZ2V0TWFya2VyID0gcztcbiAgfVxuICBjb21wb25lbnRXaWxsVW5tb3VudCgpIHtcbiAgICB0aGlzLnVuc3Vic2NyaWJlICE9IG51bGwgJiYgKHRoaXMudW5zdWJzY3JpYmUoKSwgdGhpcy51bnN1YnNjcmliZSA9IG51bGwpO1xuICB9XG4gIGNvbXBvbmVudERpZFVwZGF0ZShpKSB7XG4gICAgaWYgKGkuaW50ZXJ2YWwgIT09IHRoaXMucHJvcHMuaW50ZXJ2YWwgJiYgdGhpcy5nZXRNYXJrZXIpIHtcbiAgICAgIGNvbnN0IHMgPSB0aGlzLmdldE1hcmtlcigpO1xuICAgICAgdGhpcy5wcm9wcy51cGRhdGVNYXJrZXIoe1xuICAgICAgICAuLi5zLFxuICAgICAgICBpbnRlcnZhbDogdGhpcy5wcm9wcy5pbnRlcnZhbFxuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIHJlbmRlcigpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuT2JqZWN0LmRlZmluZVByb3BlcnR5KG9vLCBcImRlZmF1bHRQcm9wc1wiLCB7XG4gIGVudW1lcmFibGU6ICEwLFxuICBjb25maWd1cmFibGU6ICEwLFxuICB3cml0YWJsZTogITAsXG4gIHZhbHVlOiB7XG4gICAgaW50ZXJ2YWw6IDFlMyAqIDEwXG4gICAgLy8gZGVmYXVsdCB0byB0ZW4gc2Vjb25kc1xuICB9XG59KTtcbmNvbnN0IGNmID0gKGEpID0+IGooSHQsIHsgY2hpbGRyZW46ICh7IHN1YnNjcmliZU1hcmtlcjogaSwgdXBkYXRlTWFya2VyOiBzIH0pID0+IGoob28sIHsgc3Vic2NyaWJlTWFya2VyOiBpLCB1cGRhdGVNYXJrZXI6IHMsIC4uLmEgfSkgfSk7XG5jZi5kaXNwbGF5TmFtZSA9IFwiVG9kYXlNYXJrZXJXcmFwcGVyXCI7XG5jbGFzcyB1ZiBleHRlbmRzIGFlIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoLi4uYXJndW1lbnRzKSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwidW5zdWJzY3JpYmVcIiwge1xuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwLFxuICAgICAgdmFsdWU6IG51bGxcbiAgICB9KSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwiZ2V0TWFya2VyXCIsIHtcbiAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgY29uZmlndXJhYmxlOiAhMCxcbiAgICAgIHdyaXRhYmxlOiAhMCxcbiAgICAgIHZhbHVlOiBudWxsXG4gICAgfSk7XG4gIH1cbiAgY29tcG9uZW50RGlkVXBkYXRlKGkpIHtcbiAgICBpZiAoaS5kYXRlICE9PSB0aGlzLnByb3BzLmRhdGUgJiYgdGhpcy5nZXRNYXJrZXIpIHtcbiAgICAgIGNvbnN0IHMgPSB0aGlzLmdldE1hcmtlcigpO1xuICAgICAgdGhpcy5wcm9wcy51cGRhdGVNYXJrZXIoeyAuLi5zLCBkYXRlOiB0aGlzLnByb3BzLmRhdGUgfSk7XG4gICAgfVxuICB9XG4gIGNvbXBvbmVudERpZE1vdW50KCkge1xuICAgIGNvbnN0IHsgdW5zdWJzY3JpYmU6IGksIGdldE1hcmtlcjogcyB9ID0gdGhpcy5wcm9wcy5zdWJzY3JpYmVNYXJrZXIoe1xuICAgICAgdHlwZTogeGUuQ3VzdG9tLFxuICAgICAgcmVuZGVyZXI6IHRoaXMucHJvcHMuY2hpbGRyZW4sXG4gICAgICBkYXRlOiB0aGlzLnByb3BzLmRhdGVcbiAgICB9KTtcbiAgICB0aGlzLnVuc3Vic2NyaWJlID0gaSwgdGhpcy5nZXRNYXJrZXIgPSBzO1xuICB9XG4gIGNvbXBvbmVudFdpbGxVbm1vdW50KCkge1xuICAgIHRoaXMudW5zdWJzY3JpYmUgIT0gbnVsbCAmJiAodGhpcy51bnN1YnNjcmliZSgpLCB0aGlzLnVuc3Vic2NyaWJlID0gbnVsbCk7XG4gIH1cbiAgcmVuZGVyKCkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG59XG5jb25zdCBwZiA9IChhKSA9PiBqKEh0LCB7IGNoaWxkcmVuOiAoeyBzdWJzY3JpYmVNYXJrZXI6IGksIHVwZGF0ZU1hcmtlcjogcyB9KSA9PiBqKHVmLCB7IHN1YnNjcmliZU1hcmtlcjogaSwgdXBkYXRlTWFya2VyOiBzLCAuLi5hIH0pIH0pO1xucGYuZGlzcGxheU5hbWUgPSBcIkN1c3RvbU1hcmtlcldyYXBwZXJcIjtcbmNsYXNzIGhmIGV4dGVuZHMgYWUge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlciguLi5hcmd1bWVudHMpLCBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJ1bnN1YnNjcmliZVwiLCB7XG4gICAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgICB3cml0YWJsZTogITAsXG4gICAgICB2YWx1ZTogbnVsbFxuICAgIH0pO1xuICB9XG4gIGNvbXBvbmVudERpZE1vdW50KCkge1xuICAgIGNvbnN0IHsgdW5zdWJzY3JpYmU6IGkgfSA9IHRoaXMucHJvcHMuc3Vic2NyaWJlTWFya2VyKHtcbiAgICAgIHR5cGU6IHhlLkN1cnNvcixcbiAgICAgIHJlbmRlcmVyOiB0aGlzLnByb3BzLmNoaWxkcmVuXG4gICAgfSk7XG4gICAgdGhpcy51bnN1YnNjcmliZSA9IGk7XG4gIH1cbiAgY29tcG9uZW50V2lsbFVubW91bnQoKSB7XG4gICAgdGhpcy51bnN1YnNjcmliZSAhPSBudWxsICYmICh0aGlzLnVuc3Vic2NyaWJlKCksIHRoaXMudW5zdWJzY3JpYmUgPSBudWxsKTtcbiAgfVxuICByZW5kZXIoKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cbmNvbnN0IGRmID0gKGEpID0+IGooSHQsIHsgY2hpbGRyZW46ICh7IHN1YnNjcmliZU1hcmtlcjogaSB9KSA9PiBqKGhmLCB7IHN1YnNjcmliZU1hcmtlcjogaSwgLi4uYSB9KSB9KTtcbmRmLmRpc3BsYXlOYW1lID0gXCJDdXJzb3JNYXJrZXJXcmFwcGVyXCI7XG5leHBvcnQge1xuICBkZiBhcyBDdXJzb3JNYXJrZXIsXG4gIFFkIGFzIEN1c3RvbUhlYWRlcixcbiAgcGYgYXMgQ3VzdG9tTWFya2VyLFxuICBUaSBhcyBEYXRlSGVhZGVyLFxuICB5ZCBhcyBHcm91cFJvdyxcbiAgdmQgYXMgUm93SXRlbXMsXG4gIFN0IGFzIFNpZGViYXJIZWFkZXIsXG4gIGlvIGFzIFRpbWVsaW5lLFxuICBFciBhcyBUaW1lbGluZUhlYWRlcnMsXG4gIHdmIGFzIFRpbWVsaW5lTWFya2VycyxcbiAgY2YgYXMgVG9kYXlNYXJrZXIsXG4gIG1mIGFzIGNhbGVuZGFyVXRpbHMsXG4gIGlvIGFzIGRlZmF1bHRcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1yZWFjdC1jYWxlbmRhci10aW1lbGluZS5lcy5qcy5tYXBcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Q0FBQSxDQUFDLFNBQVMsR0FBRSxHQUFFO0VBQUMsWUFBVSxPQUFPLFdBQVMsZUFBYSxPQUFPLFNBQU8sT0FBTyxVQUFRLEVBQUUsSUFBRSxjQUFZLE9BQU8sVUFBUSxPQUFPLE1BQUksT0FBTyxDQUFDLElBQUUsQ0FBQyxJQUFFLGVBQWEsT0FBTyxhQUFXLGFBQVcsS0FBRyxLQUFBLENBQU0sUUFBTSxFQUFFO0NBQUMsRUFBQSxDQUFDLFNBQU8sV0FBVTtFQUFDO0VBQWEsSUFBSSxJQUFFLEtBQUksSUFBRSxLQUFJLElBQUUsTUFBSyxJQUFFLGVBQWMsSUFBRSxVQUFTLElBQUUsVUFBUyxJQUFFLFFBQU8sSUFBRSxPQUFNLElBQUUsUUFBTyxJQUFFLFNBQVEsSUFBRSxXQUFVLElBQUUsUUFBTyxJQUFFLFFBQU8sSUFBRSxnQkFBZSxJQUFFLDhGQUE2RixJQUFFLHVGQUFzRixJQUFFO0dBQUMsTUFBSztHQUFLLFVBQVMsMkRBQTJELE1BQU0sR0FBRztHQUFFLFFBQU8sd0ZBQXdGLE1BQU0sR0FBRztHQUFFLFNBQVEsU0FBUyxHQUFFO0lBQUMsSUFBSSxJQUFFO0tBQUM7S0FBSztLQUFLO0tBQUs7SUFBSSxHQUFFLElBQUUsSUFBRTtJQUFJLE9BQU0sTUFBSSxLQUFHLEdBQUcsSUFBRSxNQUFJLE9BQUssRUFBRSxNQUFJLEVBQUUsTUFBSTtHQUFHO0VBQUMsR0FBRSxJQUFFLFNBQVMsR0FBRSxHQUFFLEdBQUU7R0FBQyxJQUFJLElBQUUsT0FBTyxDQUFDO0dBQUUsT0FBTSxDQUFDLEtBQUcsRUFBRSxVQUFRLElBQUUsSUFBRSxLQUFHLE1BQU0sSUFBRSxJQUFFLEVBQUUsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUU7RUFBQyxHQUFFLElBQUU7R0FBQyxHQUFFO0dBQUUsR0FBRSxTQUFTLEdBQUU7SUFBQyxJQUFJLElBQUUsQ0FBQyxFQUFFLFVBQVUsR0FBRSxJQUFFLEtBQUssSUFBSSxDQUFDLEdBQUUsSUFBRSxLQUFLLE1BQU0sSUFBRSxFQUFFLEdBQUUsSUFBRSxJQUFFO0lBQUcsUUFBTyxLQUFHLElBQUUsTUFBSSxPQUFLLEVBQUUsR0FBRSxHQUFFLEdBQUcsSUFBRSxNQUFJLEVBQUUsR0FBRSxHQUFFLEdBQUc7R0FBQztHQUFFLEdBQUUsU0FBUyxFQUFFLEdBQUUsR0FBRTtJQUFDLElBQUcsRUFBRSxLQUFLLElBQUUsRUFBRSxLQUFLLEdBQUUsT0FBTSxDQUFDLEVBQUUsR0FBRSxDQUFDO0lBQUUsSUFBSSxJQUFFLE1BQUksRUFBRSxLQUFLLElBQUUsRUFBRSxLQUFLLE1BQUksRUFBRSxNQUFNLElBQUUsRUFBRSxNQUFNLElBQUcsSUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDLElBQUksR0FBRSxDQUFDLEdBQUUsSUFBRSxJQUFFLElBQUUsR0FBRSxJQUFFLEVBQUUsTUFBTSxDQUFDLENBQUMsSUFBSSxLQUFHLElBQUUsS0FBRyxJQUFHLENBQUM7SUFBRSxPQUFNLEVBQUUsRUFBRSxLQUFHLElBQUUsTUFBSSxJQUFFLElBQUUsSUFBRSxJQUFFLE9BQUs7R0FBRTtHQUFFLEdBQUUsU0FBUyxHQUFFO0lBQUMsT0FBTyxJQUFFLElBQUUsS0FBSyxLQUFLLENBQUMsS0FBRyxJQUFFLEtBQUssTUFBTSxDQUFDO0dBQUM7R0FBRSxHQUFFLFNBQVMsR0FBRTtJQUFDLE9BQU07S0FBQyxHQUFFO0tBQUUsR0FBRTtLQUFFLEdBQUU7S0FBRSxHQUFFO0tBQUUsR0FBRTtLQUFFLEdBQUU7S0FBRSxHQUFFO0tBQUUsR0FBRTtLQUFFLElBQUc7S0FBRSxHQUFFO0lBQUMsRUFBRSxNQUFJLE9BQU8sS0FBRyxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxRQUFRLE1BQUssRUFBRTtHQUFDO0dBQUUsR0FBRSxTQUFTLEdBQUU7SUFBQyxPQUFPLEtBQUssTUFBSTtHQUFDO0VBQUMsR0FBRSxJQUFFLE1BQUssSUFBRSxDQUFDO0VBQUUsRUFBRSxLQUFHO0VBQUUsSUFBSSxJQUFFLGtCQUFpQixJQUFFLFNBQVMsR0FBRTtHQUFDLE9BQU8sYUFBYSxLQUFHLEVBQUUsQ0FBQyxLQUFHLENBQUMsRUFBRTtFQUFHLEdBQUUsSUFBRSxTQUFTLEVBQUUsR0FBRSxHQUFFLEdBQUU7R0FBQyxJQUFJO0dBQUUsSUFBRyxDQUFDLEdBQUUsT0FBTztHQUFFLElBQUcsWUFBVSxPQUFPLEdBQUU7SUFBQyxJQUFJLElBQUUsRUFBRSxZQUFZO0lBQUUsRUFBRSxPQUFLLElBQUUsSUFBRyxNQUFJLEVBQUUsS0FBRyxHQUFFLElBQUU7SUFBRyxJQUFJLElBQUUsRUFBRSxNQUFNLEdBQUc7SUFBRSxJQUFHLENBQUMsS0FBRyxFQUFFLFNBQU8sR0FBRSxPQUFPLEVBQUUsRUFBRSxFQUFFO0dBQUMsT0FBSztJQUFDLElBQUksSUFBRSxFQUFFO0lBQUssRUFBRSxLQUFHLEdBQUUsSUFBRTtHQUFDO0dBQUMsT0FBTSxDQUFDLEtBQUcsTUFBSSxJQUFFLElBQUcsS0FBRyxDQUFDLEtBQUc7RUFBQyxHQUFFLElBQUUsU0FBUyxHQUFFLEdBQUU7R0FBQyxJQUFHLEVBQUUsQ0FBQyxHQUFFLE9BQU8sRUFBRSxNQUFNO0dBQUUsSUFBSSxJQUFFLFlBQVUsT0FBTyxJQUFFLElBQUUsQ0FBQztHQUFFLE9BQU8sRUFBRSxPQUFLLEdBQUUsRUFBRSxPQUFLLFdBQVUsSUFBSSxFQUFFLENBQUM7RUFBQyxHQUFFLElBQUU7RUFBRSxFQUFFLElBQUUsR0FBRSxFQUFFLElBQUUsR0FBRSxFQUFFLElBQUUsU0FBUyxHQUFFLEdBQUU7R0FBQyxPQUFPLEVBQUUsR0FBRTtJQUFDLFFBQU8sRUFBRTtJQUFHLEtBQUksRUFBRTtJQUFHLEdBQUUsRUFBRTtJQUFHLFNBQVEsRUFBRTtHQUFPLENBQUM7RUFBQztFQUFFLElBQUksSUFBRSxXQUFVO0dBQUMsU0FBUyxFQUFFLEdBQUU7SUFBQyxLQUFLLEtBQUcsRUFBRSxFQUFFLFFBQU8sTUFBSyxDQUFDLENBQUMsR0FBRSxLQUFLLE1BQU0sQ0FBQyxHQUFFLEtBQUssS0FBRyxLQUFLLE1BQUksRUFBRSxLQUFHLENBQUMsR0FBRSxLQUFLLEtBQUcsQ0FBQztHQUFDO0dBQUMsSUFBSSxJQUFFLEVBQUU7R0FBVSxPQUFPLEVBQUUsUUFBTSxTQUFTLEdBQUU7SUFBQyxLQUFLLEtBQUcsU0FBUyxHQUFFO0tBQUMsSUFBSSxJQUFFLEVBQUUsTUFBSyxJQUFFLEVBQUU7S0FBSSxJQUFHLFNBQU8sR0FBRSx1QkFBTyxJQUFJLEtBQUssR0FBRztLQUFFLElBQUcsRUFBRSxFQUFFLENBQUMsR0FBRSx1QkFBTyxJQUFJLEtBQUc7S0FBRSxJQUFHLGFBQWEsTUFBSyxPQUFPLElBQUksS0FBSyxDQUFDO0tBQUUsSUFBRyxZQUFVLE9BQU8sS0FBRyxDQUFDLE1BQU0sS0FBSyxDQUFDLEdBQUU7TUFBQyxJQUFJLElBQUUsRUFBRSxNQUFNLENBQUM7TUFBRSxJQUFHLEdBQUU7T0FBQyxJQUFJLElBQUUsRUFBRSxLQUFHLEtBQUcsR0FBRSxLQUFHLEVBQUUsTUFBSSxJQUFBLENBQUssVUFBVSxHQUFFLENBQUM7T0FBRSxPQUFPLElBQUUsSUFBSSxLQUFLLEtBQUssSUFBSSxFQUFFLElBQUcsR0FBRSxFQUFFLE1BQUksR0FBRSxFQUFFLE1BQUksR0FBRSxFQUFFLE1BQUksR0FBRSxFQUFFLE1BQUksR0FBRSxDQUFDLENBQUMsSUFBRSxJQUFJLEtBQUssRUFBRSxJQUFHLEdBQUUsRUFBRSxNQUFJLEdBQUUsRUFBRSxNQUFJLEdBQUUsRUFBRSxNQUFJLEdBQUUsRUFBRSxNQUFJLEdBQUUsQ0FBQztNQUFDO0tBQUM7S0FBQyxPQUFPLElBQUksS0FBSyxDQUFDO0lBQUMsRUFBRSxDQUFDLEdBQUUsS0FBSyxLQUFLO0dBQUMsR0FBRSxFQUFFLE9BQUssV0FBVTtJQUFDLElBQUksSUFBRSxLQUFLO0lBQUcsS0FBSyxLQUFHLEVBQUUsWUFBWSxHQUFFLEtBQUssS0FBRyxFQUFFLFNBQVMsR0FBRSxLQUFLLEtBQUcsRUFBRSxRQUFRLEdBQUUsS0FBSyxLQUFHLEVBQUUsT0FBTyxHQUFFLEtBQUssS0FBRyxFQUFFLFNBQVMsR0FBRSxLQUFLLEtBQUcsRUFBRSxXQUFXLEdBQUUsS0FBSyxLQUFHLEVBQUUsV0FBVyxHQUFFLEtBQUssTUFBSSxFQUFFLGdCQUFnQjtHQUFDLEdBQUUsRUFBRSxTQUFPLFdBQVU7SUFBQyxPQUFPO0dBQUMsR0FBRSxFQUFFLFVBQVEsV0FBVTtJQUFDLE9BQU0sRUFBRSxLQUFLLEdBQUcsU0FBUyxNQUFJO0dBQUUsR0FBRSxFQUFFLFNBQU8sU0FBUyxHQUFFLEdBQUU7SUFBQyxJQUFJLElBQUUsRUFBRSxDQUFDO0lBQUUsT0FBTyxLQUFLLFFBQVEsQ0FBQyxLQUFHLEtBQUcsS0FBRyxLQUFLLE1BQU0sQ0FBQztHQUFDLEdBQUUsRUFBRSxVQUFRLFNBQVMsR0FBRSxHQUFFO0lBQUMsT0FBTyxFQUFFLENBQUMsSUFBRSxLQUFLLFFBQVEsQ0FBQztHQUFDLEdBQUUsRUFBRSxXQUFTLFNBQVMsR0FBRSxHQUFFO0lBQUMsT0FBTyxLQUFLLE1BQU0sQ0FBQyxJQUFFLEVBQUUsQ0FBQztHQUFDLEdBQUUsRUFBRSxLQUFHLFNBQVMsR0FBRSxHQUFFLEdBQUU7SUFBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLElBQUUsS0FBSyxLQUFHLEtBQUssSUFBSSxHQUFFLENBQUM7R0FBQyxHQUFFLEVBQUUsT0FBSyxXQUFVO0lBQUMsT0FBTyxLQUFLLE1BQU0sS0FBSyxRQUFRLElBQUUsR0FBRztHQUFDLEdBQUUsRUFBRSxVQUFRLFdBQVU7SUFBQyxPQUFPLEtBQUssR0FBRyxRQUFRO0dBQUMsR0FBRSxFQUFFLFVBQVEsU0FBUyxHQUFFLEdBQUU7SUFBQyxJQUFJLElBQUUsTUFBSyxJQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxLQUFHLEdBQUUsSUFBRSxFQUFFLEVBQUUsQ0FBQyxHQUFFLElBQUUsU0FBUyxHQUFFLEdBQUU7S0FBQyxJQUFJLElBQUUsRUFBRSxFQUFFLEVBQUUsS0FBRyxLQUFLLElBQUksRUFBRSxJQUFHLEdBQUUsQ0FBQyxJQUFFLElBQUksS0FBSyxFQUFFLElBQUcsR0FBRSxDQUFDLEdBQUUsQ0FBQztLQUFFLE9BQU8sSUFBRSxJQUFFLEVBQUUsTUFBTSxDQUFDO0lBQUMsR0FBRSxJQUFFLFNBQVMsR0FBRSxHQUFFO0tBQUMsT0FBTyxFQUFFLEVBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsTUFBTSxFQUFFLE9BQU8sR0FBRyxJQUFHLElBQUU7TUFBQztNQUFFO01BQUU7TUFBRTtLQUFDLElBQUU7TUFBQztNQUFHO01BQUc7TUFBRztLQUFHLEVBQUEsQ0FBRyxNQUFNLENBQUMsQ0FBQyxHQUFFLENBQUM7SUFBQyxHQUFFLElBQUUsS0FBSyxJQUFHLElBQUUsS0FBSyxJQUFHLElBQUUsS0FBSyxJQUFHLElBQUUsU0FBTyxLQUFLLEtBQUcsUUFBTTtJQUFJLFFBQU8sR0FBUDtLQUFVLEtBQUssR0FBRSxPQUFPLElBQUUsRUFBRSxHQUFFLENBQUMsSUFBRSxFQUFFLElBQUcsRUFBRTtLQUFFLEtBQUssR0FBRSxPQUFPLElBQUUsRUFBRSxHQUFFLENBQUMsSUFBRSxFQUFFLEdBQUUsSUFBRSxDQUFDO0tBQUUsS0FBSztNQUFFLElBQUksSUFBRSxLQUFLLFFBQVEsQ0FBQyxDQUFDLGFBQVcsR0FBRSxLQUFHLElBQUUsSUFBRSxJQUFFLElBQUUsS0FBRztNQUFFLE9BQU8sRUFBRSxJQUFFLElBQUUsSUFBRSxLQUFHLElBQUUsSUFBRyxDQUFDO0tBQUUsS0FBSztLQUFFLEtBQUssR0FBRSxPQUFPLEVBQUUsSUFBRSxTQUFRLENBQUM7S0FBRSxLQUFLLEdBQUUsT0FBTyxFQUFFLElBQUUsV0FBVSxDQUFDO0tBQUUsS0FBSyxHQUFFLE9BQU8sRUFBRSxJQUFFLFdBQVUsQ0FBQztLQUFFLEtBQUssR0FBRSxPQUFPLEVBQUUsSUFBRSxnQkFBZSxDQUFDO0tBQUUsU0FBUSxPQUFPLEtBQUssTUFBTTtJQUFDO0dBQUMsR0FBRSxFQUFFLFFBQU0sU0FBUyxHQUFFO0lBQUMsT0FBTyxLQUFLLFFBQVEsR0FBRSxDQUFDLENBQUM7R0FBQyxHQUFFLEVBQUUsT0FBSyxTQUFTLEdBQUUsR0FBRTtJQUFDLElBQUksR0FBRSxJQUFFLEVBQUUsRUFBRSxDQUFDLEdBQUUsSUFBRSxTQUFPLEtBQUssS0FBRyxRQUFNLEtBQUksS0FBRyxJQUFFLENBQUMsR0FBRSxFQUFFLEtBQUcsSUFBRSxRQUFPLEVBQUUsS0FBRyxJQUFFLFFBQU8sRUFBRSxLQUFHLElBQUUsU0FBUSxFQUFFLEtBQUcsSUFBRSxZQUFXLEVBQUUsS0FBRyxJQUFFLFNBQVEsRUFBRSxLQUFHLElBQUUsV0FBVSxFQUFFLEtBQUcsSUFBRSxXQUFVLEVBQUUsS0FBRyxJQUFFLGdCQUFlLEVBQUEsQ0FBRyxJQUFHLElBQUUsTUFBSSxJQUFFLEtBQUssTUFBSSxJQUFFLEtBQUssTUFBSTtJQUFFLElBQUcsTUFBSSxLQUFHLE1BQUksR0FBRTtLQUFDLElBQUksSUFBRSxLQUFLLE1BQU0sQ0FBQyxDQUFDLElBQUksR0FBRSxDQUFDO0tBQUUsRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDLEdBQUUsRUFBRSxLQUFLLEdBQUUsS0FBSyxLQUFHLEVBQUUsSUFBSSxHQUFFLEtBQUssSUFBSSxLQUFLLElBQUcsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFBRSxPQUFNLEtBQUcsS0FBSyxHQUFHLEVBQUUsQ0FBQyxDQUFDO0lBQUUsT0FBTyxLQUFLLEtBQUssR0FBRTtHQUFJLEdBQUUsRUFBRSxNQUFJLFNBQVMsR0FBRSxHQUFFO0lBQUMsT0FBTyxLQUFLLE1BQU0sQ0FBQyxDQUFDLEtBQUssR0FBRSxDQUFDO0dBQUMsR0FBRSxFQUFFLE1BQUksU0FBUyxHQUFFO0lBQUMsT0FBTyxLQUFLLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQztHQUFDLEdBQUUsRUFBRSxNQUFJLFNBQVMsR0FBRSxHQUFFO0lBQUMsSUFBSSxHQUFFLElBQUU7SUFBSyxJQUFFLE9BQU8sQ0FBQztJQUFFLElBQUksSUFBRSxFQUFFLEVBQUUsQ0FBQyxHQUFFLElBQUUsU0FBUyxHQUFFO0tBQUMsSUFBSSxJQUFFLEVBQUUsQ0FBQztLQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEtBQUssSUFBRSxLQUFLLE1BQU0sSUFBRSxDQUFDLENBQUMsR0FBRSxDQUFDO0lBQUM7SUFBRSxJQUFHLE1BQUksR0FBRSxPQUFPLEtBQUssSUFBSSxHQUFFLEtBQUssS0FBRyxDQUFDO0lBQUUsSUFBRyxNQUFJLEdBQUUsT0FBTyxLQUFLLElBQUksR0FBRSxLQUFLLEtBQUcsQ0FBQztJQUFFLElBQUcsTUFBSSxHQUFFLE9BQU8sRUFBRSxDQUFDO0lBQUUsSUFBRyxNQUFJLEdBQUUsT0FBTyxFQUFFLENBQUM7SUFBRSxJQUFJLEtBQUcsSUFBRSxDQUFDLEdBQUUsRUFBRSxLQUFHLEdBQUUsRUFBRSxLQUFHLEdBQUUsRUFBRSxLQUFHLEdBQUUsRUFBQSxDQUFHLE1BQUksR0FBRSxJQUFFLEtBQUssR0FBRyxRQUFRLElBQUUsSUFBRTtJQUFFLE9BQU8sRUFBRSxFQUFFLEdBQUUsSUFBSTtHQUFDLEdBQUUsRUFBRSxXQUFTLFNBQVMsR0FBRSxHQUFFO0lBQUMsT0FBTyxLQUFLLElBQUksS0FBRyxHQUFFLENBQUM7R0FBQyxHQUFFLEVBQUUsU0FBTyxTQUFTLEdBQUU7SUFBQyxJQUFJLElBQUUsTUFBSyxJQUFFLEtBQUssUUFBUTtJQUFFLElBQUcsQ0FBQyxLQUFLLFFBQVEsR0FBRSxPQUFPLEVBQUUsZUFBYTtJQUFFLElBQUksSUFBRSxLQUFHLHdCQUF1QixJQUFFLEVBQUUsRUFBRSxJQUFJLEdBQUUsSUFBRSxLQUFLLElBQUcsSUFBRSxLQUFLLElBQUcsSUFBRSxLQUFLLElBQUcsSUFBRSxFQUFFLFVBQVMsSUFBRSxFQUFFLFFBQU8sSUFBRSxFQUFFLFVBQVMsSUFBRSxTQUFTLEdBQUUsR0FBRSxHQUFFLEdBQUU7S0FBQyxPQUFPLE1BQUksRUFBRSxNQUFJLEVBQUUsR0FBRSxDQUFDLE1BQUksRUFBRSxFQUFFLENBQUMsTUFBTSxHQUFFLENBQUM7SUFBQyxHQUFFLElBQUUsU0FBUyxHQUFFO0tBQUMsT0FBTyxFQUFFLEVBQUUsSUFBRSxNQUFJLElBQUcsR0FBRSxHQUFHO0lBQUMsR0FBRSxJQUFFLEtBQUcsU0FBUyxHQUFFLEdBQUUsR0FBRTtLQUFDLElBQUksSUFBRSxJQUFFLEtBQUcsT0FBSztLQUFLLE9BQU8sSUFBRSxFQUFFLFlBQVksSUFBRTtJQUFDO0lBQUUsT0FBTyxFQUFFLFFBQVEsSUFBRyxTQUFTLEdBQUUsR0FBRTtLQUFDLE9BQU8sS0FBRyxTQUFTLEdBQUU7TUFBQyxRQUFPLEdBQVA7T0FBVSxLQUFJLE1BQUssT0FBTyxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUMsTUFBTSxFQUFFO09BQUUsS0FBSSxRQUFPLE9BQU8sRUFBRSxFQUFFLEVBQUUsSUFBRyxHQUFFLEdBQUc7T0FBRSxLQUFJLEtBQUksT0FBTyxJQUFFO09BQUUsS0FBSSxNQUFLLE9BQU8sRUFBRSxFQUFFLElBQUUsR0FBRSxHQUFFLEdBQUc7T0FBRSxLQUFJLE9BQU0sT0FBTyxFQUFFLEVBQUUsYUFBWSxHQUFFLEdBQUUsQ0FBQztPQUFFLEtBQUksUUFBTyxPQUFPLEVBQUUsR0FBRSxDQUFDO09BQUUsS0FBSSxLQUFJLE9BQU8sRUFBRTtPQUFHLEtBQUksTUFBSyxPQUFPLEVBQUUsRUFBRSxFQUFFLElBQUcsR0FBRSxHQUFHO09BQUUsS0FBSSxLQUFJLE9BQU8sT0FBTyxFQUFFLEVBQUU7T0FBRSxLQUFJLE1BQUssT0FBTyxFQUFFLEVBQUUsYUFBWSxFQUFFLElBQUcsR0FBRSxDQUFDO09BQUUsS0FBSSxPQUFNLE9BQU8sRUFBRSxFQUFFLGVBQWMsRUFBRSxJQUFHLEdBQUUsQ0FBQztPQUFFLEtBQUksUUFBTyxPQUFPLEVBQUUsRUFBRTtPQUFJLEtBQUksS0FBSSxPQUFPLE9BQU8sQ0FBQztPQUFFLEtBQUksTUFBSyxPQUFPLEVBQUUsRUFBRSxHQUFFLEdBQUUsR0FBRztPQUFFLEtBQUksS0FBSSxPQUFPLEVBQUUsQ0FBQztPQUFFLEtBQUksTUFBSyxPQUFPLEVBQUUsQ0FBQztPQUFFLEtBQUksS0FBSSxPQUFPLEVBQUUsR0FBRSxHQUFFLENBQUMsQ0FBQztPQUFFLEtBQUksS0FBSSxPQUFPLEVBQUUsR0FBRSxHQUFFLENBQUMsQ0FBQztPQUFFLEtBQUksS0FBSSxPQUFPLE9BQU8sQ0FBQztPQUFFLEtBQUksTUFBSyxPQUFPLEVBQUUsRUFBRSxHQUFFLEdBQUUsR0FBRztPQUFFLEtBQUksS0FBSSxPQUFPLE9BQU8sRUFBRSxFQUFFO09BQUUsS0FBSSxNQUFLLE9BQU8sRUFBRSxFQUFFLEVBQUUsSUFBRyxHQUFFLEdBQUc7T0FBRSxLQUFJLE9BQU0sT0FBTyxFQUFFLEVBQUUsRUFBRSxLQUFJLEdBQUUsR0FBRztPQUFFLEtBQUksS0FBSSxPQUFPO01BQUM7TUFBQyxPQUFPO0tBQUksRUFBRSxDQUFDLEtBQUcsRUFBRSxRQUFRLEtBQUksRUFBRTtJQUFDLEVBQUU7R0FBQyxHQUFFLEVBQUUsWUFBVSxXQUFVO0lBQUMsT0FBTyxLQUFHLENBQUMsS0FBSyxNQUFNLEtBQUssR0FBRyxrQkFBa0IsSUFBRSxFQUFFO0dBQUMsR0FBRSxFQUFFLE9BQUssU0FBUyxHQUFFLEdBQUUsR0FBRTtJQUFDLElBQUksR0FBRSxJQUFFLE1BQUssSUFBRSxFQUFFLEVBQUUsQ0FBQyxHQUFFLElBQUUsRUFBRSxDQUFDLEdBQUUsS0FBRyxFQUFFLFVBQVUsSUFBRSxLQUFLLFVBQVUsS0FBRyxHQUFFLElBQUUsT0FBSyxHQUFFLElBQUUsV0FBVTtLQUFDLE9BQU8sRUFBRSxFQUFFLEdBQUUsQ0FBQztJQUFDO0lBQUUsUUFBTyxHQUFQO0tBQVUsS0FBSztNQUFFLElBQUUsRUFBRSxJQUFFO01BQUc7S0FBTSxLQUFLO01BQUUsSUFBRSxFQUFFO01BQUU7S0FBTSxLQUFLO01BQUUsSUFBRSxFQUFFLElBQUU7TUFBRTtLQUFNLEtBQUs7TUFBRSxLQUFHLElBQUUsS0FBRztNQUFPO0tBQU0sS0FBSztNQUFFLEtBQUcsSUFBRSxLQUFHO01BQU07S0FBTSxLQUFLO01BQUUsSUFBRSxJQUFFO01BQUU7S0FBTSxLQUFLO01BQUUsSUFBRSxJQUFFO01BQUU7S0FBTSxLQUFLO01BQUUsSUFBRSxJQUFFO01BQUU7S0FBTSxTQUFRLElBQUU7SUFBQztJQUFDLE9BQU8sSUFBRSxJQUFFLEVBQUUsRUFBRSxDQUFDO0dBQUMsR0FBRSxFQUFFLGNBQVksV0FBVTtJQUFDLE9BQU8sS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDO0dBQUUsR0FBRSxFQUFFLFVBQVEsV0FBVTtJQUFDLE9BQU8sRUFBRSxLQUFLO0dBQUcsR0FBRSxFQUFFLFNBQU8sU0FBUyxHQUFFLEdBQUU7SUFBQyxJQUFHLENBQUMsR0FBRSxPQUFPLEtBQUs7SUFBRyxJQUFJLElBQUUsS0FBSyxNQUFNLEdBQUUsSUFBRSxFQUFFLEdBQUUsR0FBRSxDQUFDLENBQUM7SUFBRSxPQUFPLE1BQUksRUFBRSxLQUFHLElBQUc7R0FBQyxHQUFFLEVBQUUsUUFBTSxXQUFVO0lBQUMsT0FBTyxFQUFFLEVBQUUsS0FBSyxJQUFHLElBQUk7R0FBQyxHQUFFLEVBQUUsU0FBTyxXQUFVO0lBQUMsT0FBTyxJQUFJLEtBQUssS0FBSyxRQUFRLENBQUM7R0FBQyxHQUFFLEVBQUUsU0FBTyxXQUFVO0lBQUMsT0FBTyxLQUFLLFFBQVEsSUFBRSxLQUFLLFlBQVksSUFBRTtHQUFJLEdBQUUsRUFBRSxjQUFZLFdBQVU7SUFBQyxPQUFPLEtBQUssR0FBRyxZQUFZO0dBQUMsR0FBRSxFQUFFLFdBQVMsV0FBVTtJQUFDLE9BQU8sS0FBSyxHQUFHLFlBQVk7R0FBQyxHQUFFO0VBQUMsRUFBRSxHQUFFLElBQUUsRUFBRTtFQUFVLE9BQU8sRUFBRSxZQUFVLEdBQUU7R0FBQyxDQUFDLE9BQU0sQ0FBQztHQUFFLENBQUMsTUFBSyxDQUFDO0dBQUUsQ0FBQyxNQUFLLENBQUM7R0FBRSxDQUFDLE1BQUssQ0FBQztHQUFFLENBQUMsTUFBSyxDQUFDO0dBQUUsQ0FBQyxNQUFLLENBQUM7R0FBRSxDQUFDLE1BQUssQ0FBQztHQUFFLENBQUMsTUFBSyxDQUFDO0VBQUMsQ0FBQyxDQUFDLFNBQVMsU0FBUyxHQUFFO0dBQUMsRUFBRSxFQUFFLE1BQUksU0FBUyxHQUFFO0lBQUMsT0FBTyxLQUFLLEdBQUcsR0FBRSxFQUFFLElBQUcsRUFBRSxFQUFFO0dBQUM7RUFBQyxFQUFFLEdBQUUsRUFBRSxTQUFPLFNBQVMsR0FBRSxHQUFFO0dBQUMsT0FBTyxFQUFFLE9BQUssRUFBRSxHQUFFLEdBQUUsQ0FBQyxHQUFFLEVBQUUsS0FBRyxDQUFDLElBQUc7RUFBQyxHQUFFLEVBQUUsU0FBTyxHQUFFLEVBQUUsVUFBUSxHQUFFLEVBQUUsT0FBSyxTQUFTLEdBQUU7R0FBQyxPQUFPLEVBQUUsTUFBSSxDQUFDO0VBQUMsR0FBRSxFQUFFLEtBQUcsRUFBRSxJQUFHLEVBQUUsS0FBRyxHQUFFLEVBQUUsSUFBRSxDQUFDLEdBQUU7Q0FBQyxFQUFFOzs7Ozs7QUNHdC9OLFNBQVMsR0FBRyxHQUFHO0NBQ2IsSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQztDQUN2QixPQUFPLElBQ0wsQ0FBQyxFQUFFLGdCQUFnQixFQUFFLFlBQVksVUFBVSxFQUFFLGVBQWUsS0FBSyxFQUFFLGNBQWMsTUFBTSxJQUFJLFNBQVMsb0JBQW9CLElBQUksS0FBSyxFQUFFLGNBQWMsSUFBSSxJQUFJLEVBQUUsY0FBYyxFQUFFLFlBQVksS0FBSyxFQUFFLGFBQWEsSUFBSSxJQUFJLEVBQUUsYUFBYSxFQUFFLFdBQVcsSUFBSSxFQUFFLGNBQWMsSUFBSSxDQUFDO0NBQzFRLE9BQU87RUFBRSxHQUFHO0VBQUcsR0FBRztDQUFFO0FBQ3RCO0FBQ0EsU0FBUyxHQUFHLEdBQUc7Q0FDYixJQUFJLE1BQU0sU0FBUyxNQUNqQixPQUFPO0VBQUUsWUFBWTtFQUFHLFdBQVc7Q0FBRTtDQUN2QztFQUNFLE1BQU0sSUFBSSxHQUFHLEVBQUUsVUFBVTtFQUN6QixPQUFPO0dBQ0wsWUFBWSxFQUFFLGFBQWEsRUFBRTtHQUM3QixXQUFXLEVBQUUsWUFBWSxFQUFFO0VBQzdCO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsR0FBRyxHQUFHO0NBQ2IsSUFBSSxNQUFNLFNBQVMsUUFBUSxDQUFDLEVBQUUsY0FDNUIsT0FBTztFQUFFLFlBQVk7RUFBRyxXQUFXO0NBQUU7Q0FDdkM7RUFDRSxNQUFNLElBQUksR0FBRyxFQUFFLFlBQVk7RUFDM0IsT0FBTztHQUNMLFlBQVksRUFBRSxhQUFhLEVBQUU7R0FDN0IsV0FBVyxFQUFFLFlBQVksRUFBRTtFQUM3QjtDQUNGO0FBQ0Y7QUFDQSxJQUFJLEtBQUssT0FBTyxhQUFhLE1BQU0sYUFBYSxPQUFPLFNBQVMsTUFBTSxTQUFTLE9BQU8sU0FBUyxNQUFNLFNBQVMsT0FBTyxPQUFPLE1BQU0sT0FBTyxDQUFDO0FBQzFJLFNBQVMsR0FBRyxHQUFHO0NBQ2IsT0FBTyxLQUFLLEVBQUUsY0FBYyxPQUFPLFVBQVUsZUFBZSxLQUFLLEdBQUcsU0FBUyxJQUFJLEVBQUUsVUFBVTtBQUMvRjtBQUNBLElBQUksS0FBSyxFQUFFLFNBQVMsQ0FBQyxFQUFFO0FBQ3ZCLEdBQUc7Q0FDRixTQUFTLEdBQUcsR0FBRztDQUNkLENBQUMsU0FBUyxHQUFHLEdBQUc7RUFDZCxFQUFFLFVBQVUsRUFBRTtDQUNoQixFQUFBLENBQUcsSUFBSSxXQUFXO0VBQ2hCLFNBQVMsRUFBRSxHQUFHLEdBQUc7R0FDZixJQUFJLElBQUksT0FBTyxLQUFLLENBQUM7R0FDckIsSUFBSSxPQUFPLHVCQUF1QjtJQUNoQyxJQUFJLElBQUksT0FBTyxzQkFBc0IsQ0FBQztJQUN0QyxNQUFNLElBQUksRUFBRSxPQUFPLFNBQVMsR0FBRztLQUM3QixPQUFPLE9BQU8seUJBQXlCLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDL0MsQ0FBQyxJQUFJLEVBQUUsS0FBSyxNQUFNLEdBQUcsQ0FBQztHQUN4QjtHQUNBLE9BQU87RUFDVDtFQUNBLFNBQVMsRUFBRSxHQUFHO0dBQ1osS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFVBQVUsUUFBUSxLQUFLO0lBQ3pDLElBQUksSUFBSSxVQUFVLE1BQU0sT0FBTyxVQUFVLEtBQUssQ0FBQztJQUMvQyxJQUFJLElBQUksRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsU0FBUyxHQUFHO0tBQzNDLEVBQUUsR0FBRyxHQUFHLEVBQUUsRUFBRTtJQUNkLENBQUMsSUFBSSxPQUFPLDRCQUE0QixPQUFPLGlCQUFpQixHQUFHLE9BQU8sMEJBQTBCLENBQUMsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsU0FBUyxHQUFHO0tBQ3pJLE9BQU8sZUFBZSxHQUFHLEdBQUcsT0FBTyx5QkFBeUIsR0FBRyxDQUFDLENBQUM7SUFDbkUsQ0FBQztHQUNIO0dBQ0EsT0FBTztFQUNUO0VBQ0EsU0FBUyxFQUFFLEdBQUc7R0FDWixPQUFPLElBQUksT0FBTyxVQUFVLGNBQWMsT0FBTyxPQUFPLFlBQVksV0FBVyxTQUFTLEdBQUc7SUFDekYsT0FBTyxPQUFPO0dBQ2hCLElBQUksU0FBUyxHQUFHO0lBQ2QsT0FBTyxLQUFLLE9BQU8sVUFBVSxjQUFjLEVBQUUsZ0JBQWdCLFVBQVUsTUFBTSxPQUFPLFlBQVksV0FBVyxPQUFPO0dBQ3BILEdBQUcsRUFBRSxDQUFDO0VBQ1I7RUFDQSxTQUFTLEVBQUUsR0FBRyxHQUFHO0dBQ2YsSUFBSSxFQUFFLGFBQWEsSUFBSSxNQUFNLElBQUksVUFBVSxtQ0FBbUM7RUFDaEY7RUFDQSxTQUFTLEVBQUUsR0FBRyxHQUFHO0dBQ2YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLO0lBQ2pDLElBQUksSUFBSSxFQUFFO0lBQ1YsRUFBRSxhQUFhLEVBQUUsY0FBYyxDQUFDLEdBQUcsRUFBRSxlQUFlLENBQUMsR0FBRyxXQUFXLE1BQU0sRUFBRSxXQUFXLENBQUMsSUFBSSxPQUFPLGVBQWUsR0FBRyxFQUFFLEVBQUUsR0FBRyxHQUFHLENBQUM7R0FDakk7RUFDRjtFQUNBLFNBQVMsRUFBRSxHQUFHLEdBQUcsR0FBRztHQUNsQixPQUFPLEtBQUssRUFBRSxFQUFFLFdBQVcsQ0FBQyxHQUFHLE9BQU8sZUFBZSxHQUFHLGFBQWEsRUFBRSxVQUFVLENBQUMsRUFBRSxDQUFDLEdBQUc7RUFDMUY7RUFDQSxTQUFTLEVBQUUsR0FBRyxHQUFHLEdBQUc7R0FDbEIsUUFBUSxJQUFJLEVBQUUsQ0FBQyxNQUFNLElBQUksT0FBTyxlQUFlLEdBQUcsR0FBRztJQUFFLE9BQU87SUFBRyxZQUFZLENBQUM7SUFBRyxjQUFjLENBQUM7SUFBRyxVQUFVLENBQUM7R0FBRSxDQUFDLElBQUksRUFBRSxLQUFLLEdBQUc7RUFDakk7RUFDQSxTQUFTLEVBQUUsR0FBRyxHQUFHO0dBQ2YsSUFBSSxPQUFPLEtBQUssY0FBYyxNQUFNLE1BQU0sTUFBTSxJQUFJLFVBQVUsb0RBQW9EO0dBQ2xILEVBQUUsWUFBWSxPQUFPLE9BQU8sS0FBSyxFQUFFLFdBQVcsRUFBRSxhQUFhO0lBQUUsT0FBTztJQUFHLFVBQVUsQ0FBQztJQUFHLGNBQWMsQ0FBQztHQUFFLEVBQUUsQ0FBQyxHQUFHLE9BQU8sZUFBZSxHQUFHLGFBQWEsRUFBRSxVQUFVLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxFQUFFLEdBQUcsQ0FBQztFQUNwTDtFQUNBLFNBQVMsRUFBRSxHQUFHO0dBQ1osT0FBTyxJQUFJLE9BQU8saUJBQWlCLE9BQU8sZUFBZSxLQUFLLElBQUksU0FBUyxHQUFHO0lBQzVFLE9BQU8sRUFBRSxhQUFhLE9BQU8sZUFBZSxDQUFDO0dBQy9DLEdBQUcsRUFBRSxDQUFDO0VBQ1I7RUFDQSxTQUFTLEVBQUUsR0FBRyxHQUFHO0dBQ2YsT0FBTyxJQUFJLE9BQU8saUJBQWlCLE9BQU8sZUFBZSxLQUFLLElBQUksU0FBUyxHQUFHLEdBQUc7SUFDL0UsT0FBTyxFQUFFLFlBQVksR0FBRztHQUMxQixHQUFHLEVBQUUsR0FBRyxDQUFDO0VBQ1g7RUFDQSxTQUFTLEVBQUUsR0FBRztHQUNaLElBQUksTUFBTSxLQUFLLEdBQUcsTUFBTSxJQUFJLGVBQWUsMkRBQTJEO0dBQ3RHLE9BQU87RUFDVDtFQUNBLFNBQVMsRUFBRSxHQUFHO0dBQ1osSUFBSSxJQUFJLFdBQVc7SUFDakIsSUFBSSxPQUFPLFVBQVUsT0FBTyxDQUFDLFFBQVEsYUFBYSxRQUFRLFVBQVUsTUFBTSxPQUFPLENBQUM7SUFDbEYsSUFBSSxPQUFPLFNBQVMsWUFBWSxPQUFPLENBQUM7SUFDeEMsSUFBSTtLQUNGLE9BQU8sUUFBUSxVQUFVLFFBQVEsS0FBSyxRQUFRLFVBQVUsU0FBUyxDQUFDLEdBQUcsV0FBVyxDQUNoRixDQUFDLENBQUMsR0FBRyxDQUFDO0lBQ1IsUUFBUTtLQUNOLE9BQU8sQ0FBQztJQUNWO0dBQ0YsRUFBRTtHQUNGLE9BQU8sV0FBVztJQUNoQixJQUFJLEdBQUcsSUFBSSxFQUFFLENBQUM7SUFDZCxJQUFJLEdBQUc7S0FDTCxJQUFJLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztLQUNoQixJQUFJLFFBQVEsVUFBVSxHQUFHLFdBQVcsQ0FBQztJQUN2QyxPQUFPLElBQUksRUFBRSxNQUFNLE1BQU0sU0FBUztJQUNsQyxPQUFPLFNBQVMsR0FBRyxHQUFHO0tBQ3BCLElBQUksTUFBTSxPQUFPLEtBQUssWUFBWSxPQUFPLEtBQUssYUFBYSxPQUFPO0tBQ2xFLElBQUksTUFBTSxLQUFLLEdBQUcsTUFBTSxJQUFJLFVBQVUsMERBQTBEO0tBQ2hHLE9BQU8sRUFBRSxDQUFDO0lBQ1osRUFBRSxNQUFNLENBQUM7R0FDWDtFQUNGO0VBQ0EsU0FBUyxJQUFJO0dBQ1gsT0FBTyxJQUFJLE9BQU8sVUFBVSxPQUFPLFFBQVEsTUFBTSxRQUFRLElBQUksS0FBSyxJQUFJLFNBQVMsR0FBRyxHQUFHLEdBQUc7SUFDdEYsSUFBSSxJQUFJLFNBQVMsR0FBRyxHQUFHO0tBQ3JCLE9BQU8sQ0FBQyxPQUFPLFVBQVUsZUFBZSxLQUFLLEdBQUcsQ0FBQyxNQUFNLElBQUksRUFBRSxDQUFDLE9BQU87S0FDckUsT0FBTztJQUNULEVBQUUsR0FBRyxDQUFDO0lBQ04sSUFBSSxHQUFHO0tBQ0wsSUFBSSxJQUFJLE9BQU8seUJBQXlCLEdBQUcsQ0FBQztLQUM1QyxPQUFPLEVBQUUsTUFBTSxFQUFFLElBQUksS0FBSyxVQUFVLFNBQVMsSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFO0lBQzlEO0dBQ0YsR0FBRyxFQUFFLE1BQU0sTUFBTSxTQUFTO0VBQzVCO0VBQ0EsU0FBUyxFQUFFLEdBQUc7R0FDWixJQUFJLElBQUksU0FBUyxHQUFHLEdBQUc7SUFDckIsSUFBSSxPQUFPLEtBQUssWUFBWSxNQUFNLE1BQU0sT0FBTztJQUMvQyxJQUFJLElBQUksRUFBRSxPQUFPO0lBQ2pCLElBQUksTUFBTSxLQUFLLEdBQUc7S0FDaEIsSUFBSSxJQUFJLEVBQUUsS0FBSyxHQUFHLENBQUM7S0FDbkIsSUFBSSxPQUFPLEtBQUssVUFBVSxPQUFPO0tBQ2pDLE1BQU0sSUFBSSxVQUFVLDhDQUE4QztJQUNwRTtJQUNBLE9BQU8sT0FBTyxDQUFDO0dBQ2pCLEVBQUUsR0FBRyxRQUFRO0dBQ2IsT0FBTyxPQUFPLEtBQUssV0FBVyxJQUFJLElBQUk7RUFDeEM7RUFDQSxJQUFJLElBQUksU0FBUyxHQUFHO0dBQ2xCLE9BQU8sRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFFLFdBQVcsYUFBYSxFQUFFO0VBQzlDLEdBQUcsSUFBSSxLQUFLLEdBQUcsSUFBSSxLQUFLO0VBQ3hCLFNBQVMsRUFBRSxHQUFHO0dBQ1osSUFBSTtHQUNKLElBQUksSUFBSSxFQUFFLFNBQVMsZUFBZSxFQUFFO0dBQ3BDLEVBQUUsa0JBQWtCLEVBQUUsWUFBWSxPQUFPLEVBQUUsUUFBUSxjQUFjLEVBQUUsS0FBSyxDQUFDLE1BQU0sTUFBTSxJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUksSUFBSTtFQUMzRztFQUNBLFNBQVMsRUFBRSxHQUFHO0dBQ1osT0FBTyxFQUFFLENBQUMsSUFBSSxLQUFLLEVBQUUsaUJBQWlCLEVBQUEsQ0FBRyxlQUFlLEVBQUU7RUFDNUQ7RUFDQSxPQUFPLFNBQVMsT0FBTyxVQUFVLEVBQUUsTUFBTTtFQUN6QyxJQUFJLElBQUksU0FBUyxHQUFHO0dBQ2xCLE9BQU8sQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDLE1BQU07RUFDekIsR0FBRyxLQUFLLFNBQVMsR0FBRztHQUNsQixPQUFPLE9BQU8sS0FBSztFQUNyQixHQUFHLElBQUk7R0FBRSxRQUFRLFNBQVMsR0FBRztJQUMzQixPQUFPLE1BQU0sS0FBSyxFQUFFLENBQUM7R0FDdkI7R0FBRyxTQUFTLFNBQVMsR0FBRztJQUN0QixPQUFPLEVBQUUsQ0FBQyxLQUFLLEVBQUUsYUFBYTtHQUNoQztHQUFHLFFBQVE7R0FBRyxNQUFNO0dBQUksUUFBUSxTQUFTLEdBQUc7SUFDMUMsT0FBTyxPQUFPLEtBQUs7R0FDckI7R0FBRyxNQUFNLFNBQVMsR0FBRztJQUNuQixPQUFPLE9BQU8sS0FBSztHQUNyQjtHQUFHLFFBQVEsU0FBUyxHQUFHO0lBQ3JCLE9BQU8sT0FBTyxLQUFLO0dBQ3JCO0dBQUcsU0FBUyxTQUFTLEdBQUc7SUFDdEIsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDLE1BQU0sVUFBVSxPQUFPLENBQUM7SUFDckMsSUFBSSxJQUFJLEVBQUUsQ0FBQyxLQUFLO0lBQ2hCLE9BQU8sa0JBQWtCLEtBQUssT0FBTyxVQUFVLE1BQU0sY0FBYyxFQUFFLE9BQU8sQ0FBQyxJQUFJLGFBQWEsV0FBVyxhQUFhLEVBQUUsVUFBVSxFQUFFLGFBQWEsS0FBSyxPQUFPLEVBQUUsWUFBWTtHQUM3SztHQUFHLGFBQWEsU0FBUyxHQUFHO0lBQzFCLE9BQU8sRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsZUFBZSxvQkFBb0IsS0FBSyxFQUFFLFlBQVksU0FBUyxDQUFDO0dBQ3JGO0dBQUcsT0FBTyxTQUFTLEdBQUc7SUFDcEIsT0FBTyxFQUFFLENBQUMsS0FBSyxFQUFFLFdBQVcsS0FBSyxLQUFLLEdBQUcsRUFBRSxNQUFNO0dBQ25EO0VBQUU7RUFDRixTQUFTLEdBQUcsR0FBRztHQUNiLElBQUksSUFBSSxFQUFFO0dBQ1YsSUFBSSxFQUFFLFNBQVMsU0FBUyxRQUFRO0lBQzlCLElBQUksSUFBSSxFQUFFLFNBQVM7SUFDbkIsTUFBTSxPQUFPLEVBQUUsT0FBTyxJQUFJLEtBQUssSUFBSSxFQUFFLE9BQU8sTUFBTSxLQUFLLEdBQUcsRUFBRSxPQUFPLElBQUksT0FBTyxJQUFJLEVBQUUsT0FBTyxNQUFNLE9BQU8sR0FBRyxFQUFFLE9BQU8sU0FBUyxPQUFPLElBQUksR0FBRyxFQUFFLE9BQU8sU0FBUyxLQUFLLElBQUksS0FBSyxNQUFNLFFBQVEsRUFBRSxPQUFPLElBQUksS0FBSyxJQUFJLEVBQUUsT0FBTyxNQUFNLEtBQUssR0FBRyxFQUFFLE9BQU8sSUFBSSxPQUFPLElBQUksRUFBRSxPQUFPLE1BQU0sT0FBTyxHQUFHLEVBQUUsT0FBTyxTQUFTLE9BQU8sSUFBSSxHQUFHLEVBQUUsT0FBTyxTQUFTLEtBQUssSUFBSTtHQUNwVjtFQUNGO0VBQ0EsU0FBUyxHQUFHLEdBQUc7R0FDYixJQUFJLElBQUksRUFBRSxRQUFRLElBQUksRUFBRTtHQUN4QixJQUFJLEVBQUUsU0FBUyxTQUFTLFFBQVE7SUFDOUIsSUFBSSxJQUFJLEVBQUUsU0FBUztJQUNuQixJQUFJLE1BQU0sT0FBTyxNQUFNLEtBQUs7S0FDMUIsSUFBSSxJQUFJLE1BQU0sTUFBTSxNQUFNO0tBQzFCLEVBQUUsS0FBSyxLQUFLLEVBQUUsT0FBTyxNQUFNLEtBQUssSUFBSSxFQUFFLE9BQU8sS0FBSyxFQUFFLE9BQU8sTUFBTSxPQUFPLElBQUksRUFBRSxNQUFNLEtBQUs7SUFDM0Y7R0FDRjtFQUNGO0VBQ0EsSUFBSSxLQUFLO0dBQUUsSUFBSTtHQUFnQixTQUFTLFNBQVMsR0FBRztJQUNsRCxJQUFJLElBQUksRUFBRSxTQUFTLElBQUksRUFBRSxjQUFjLElBQUksRUFBRTtJQUM3QyxFQUFFLFVBQVUsWUFBWSxHQUFHLFdBQVcsRUFBRSxJQUFJLE9BQU8sSUFBSSxFQUFFLFdBQVcsT0FBTyxhQUFhLEVBQUUsUUFBUSxPQUFPLEdBQUc7R0FDOUc7R0FBRyxXQUFXO0lBQUUsbUNBQW1DO0lBQUksOEJBQThCO0lBQUksNEJBQTRCO0lBQUksb0JBQW9CLFNBQVMsR0FBRztLQUN2SixJQUFJLElBQUksRUFBRSxhQUFhLElBQUksRUFBRSxjQUFjLElBQUksRUFBRSxTQUFTLElBQUksRUFBRSxRQUFRO0tBQ3hFLElBQUksS0FBSyxFQUFFLFlBQVksQ0FBQyxFQUFFLGlCQUFpQixDQUFDLGdCQUFnQixLQUFLLEVBQUUsV0FBVyxLQUFLLElBQUksRUFBRSxRQUFRLEtBQUssZUFBZSxPQUFPLEVBQUUsU0FBUztNQUFFLE1BQU07TUFBUSxNQUFNLEVBQUUsYUFBYSxVQUFVLEVBQUUsWUFBWSxFQUFFO0tBQVMsR0FBRyxDQUFDO0lBQ3JOO0dBQUU7R0FBRyxXQUFXLFNBQVMsR0FBRztJQUMxQixPQUFPLEVBQUUsT0FBTyxDQUFDLEtBQUssS0FBSyxRQUFRLEtBQUssVUFBVSxFQUFFLFlBQVksQ0FBQyxHQUFHLEtBQUssYUFBYSxRQUFRLENBQUMsR0FBRyxLQUFLLFlBQVksUUFBUSxDQUFDLEdBQUcsbUJBQW1CLEtBQUssRUFBRSxRQUFRLE1BQU0sS0FBSyxRQUFRLEtBQUssV0FBVyxFQUFFLFdBQVcsYUFBYSxLQUFLLEVBQUUsU0FBUyxNQUFNLEtBQUssUUFBUSxLQUFLLFlBQVksRUFBRSxZQUFZLFFBQVEsRUFBRSxLQUFLLENBQUMsS0FBSyxLQUFLLFFBQVEsS0FBSyxVQUFVLEdBQUcsUUFBUSxLQUFLLFFBQVE7R0FDM1c7R0FBRyxZQUFZO0dBQUksTUFBTTtHQUFJLFVBQVU7SUFBRSxXQUFXO0lBQU0sVUFBVTtHQUFLO0dBQUcsV0FBVyxXQUFXO0lBQ2hHLE9BQU87R0FDVDtHQUFHLGlCQUFpQixTQUFTLEdBQUc7SUFDOUIsT0FBTyxFQUFFLE9BQU8sTUFBTSxNQUFNO0dBQzlCO0VBQUUsR0FBRyxLQUFLLElBQUksS0FBSztHQUFFLE1BQU0sU0FBUyxHQUFHO0lBQ3JDLElBQUksSUFBSTtJQUNSLEdBQUcsV0FBVyxFQUFFLFVBQVUsR0FBRyxtQkFBbUIsRUFBRSxvQkFBb0IsSUFBSSxHQUFHLGFBQWEsRUFBRSxjQUFjLElBQUksR0FBRyxnQkFBZ0IsRUFBRSxpQkFBaUIsSUFBSSxHQUFHLHFCQUFxQixFQUFFLHNCQUFzQixJQUFJLEdBQUcsVUFBVSxFQUFFLFdBQVcsSUFBSSxHQUFHLGNBQWMsRUFBRSxlQUFlLEdBQUcsU0FBUyxHQUFHLFFBQVEsRUFBRSxPQUFPLEdBQUcsUUFBUSxFQUFFLFNBQVMsSUFBSSxHQUFHLGVBQWUsRUFBRSxnQkFBZ0IsRUFBRTtHQUM5VztHQUFHLFVBQVU7R0FBTSxrQkFBa0I7R0FBTSxZQUFZO0dBQU0sZUFBZTtHQUFNLG9CQUFvQjtHQUFNLFNBQVM7R0FBTSxhQUFhO0dBQU0sT0FBTztHQUFNLE9BQU87R0FBTSxjQUFjO0VBQUs7RUFDM0wsU0FBUyxLQUFLLENBQ2Q7RUFDQSxJQUFJLElBQUksSUFBSSxLQUFLO0dBQUUsTUFBTSxTQUFTLEdBQUc7SUFDbkMsSUFBSSxJQUFJLEVBQUUsU0FBUyxJQUFJLEVBQUUsYUFBYSxDQUFDO0lBQ3ZDLEdBQUcsZ0JBQWdCLGtCQUFrQixLQUFLLEVBQUUsS0FBSyxFQUFFLGFBQWEsS0FBSyxFQUFFLG9CQUFvQixFQUFFLGVBQWUsR0FBRyx1QkFBdUIsRUFBRSxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLGNBQWMsR0FBRyxRQUFRLGlCQUFpQixLQUFLLEVBQUUsUUFBUSxHQUFHLEdBQUcsU0FBUyxpQkFBaUIsS0FBSyxFQUFFLFFBQVEsS0FBSyxZQUFZLEtBQUssRUFBRSxVQUFVLEdBQUcsR0FBRyxRQUFRLFNBQVMsS0FBSyxFQUFFLFNBQVMsR0FBRyxHQUFHLGdCQUFnQixFQUFFLFlBQVksV0FBVyxHQUFHLGlCQUFpQixTQUFTLEtBQUssRUFBRSxTQUFTLEdBQUcsR0FBRywwQkFBMEIsYUFBYSxFQUFFLFlBQVksWUFBWSwyQkFBMkIsRUFBRSxZQUFZLDBCQUEwQix3QkFBd0IsRUFBRSxZQUFZLHVCQUF1QixzQkFBc0IsRUFBRSxZQUFZLHFCQUFxQixxQkFBcUIsR0FBRyxjQUFjLEdBQUcsdUJBQXVCLEVBQUUsaUJBQWlCLEVBQUUsaUJBQWlCO0tBQUUsSUFBSTtLQUFlLE1BQU07S0FBaUIsTUFBTTtLQUFhLEtBQUs7S0FBWSxNQUFNO0tBQWlCLFFBQVE7SUFBa0IsSUFBSTtLQUFFLElBQUk7S0FBYSxNQUFNO0tBQWUsTUFBTTtLQUFlLEtBQUs7S0FBYyxNQUFNO0tBQWUsUUFBUTtJQUFnQixJQUFJLE1BQU0sR0FBRyxhQUFhLEVBQUUsWUFBWSxrQkFBa0IsRUFBRSxXQUFXLGVBQWU7R0FDbG5DO0dBQUcsZUFBZTtHQUFNLHNCQUFzQjtHQUFNLFFBQVE7R0FBTSxPQUFPO0dBQU0sT0FBTztHQUFNLGVBQWU7R0FBTSx5QkFBeUI7R0FBTSxhQUFhO0dBQU0sWUFBWTtFQUFLLEdBQUcsS0FBSztFQUM1TCxTQUFTLEdBQUcsR0FBRyxHQUFHO0dBQ2hCLElBQUksRUFBRSxVQUFVLE9BQU8sRUFBRSxTQUFTLENBQUM7R0FDbkMsT0FBTyxJQUFLO0lBQ1YsSUFBSSxNQUFNLEdBQUcsT0FBTyxDQUFDO0lBQ3JCLElBQUksRUFBRTtHQUNSO0dBQ0EsT0FBTyxDQUFDO0VBQ1Y7RUFDQSxTQUFTLEdBQUcsR0FBRyxHQUFHO0dBQ2hCLE9BQU8sRUFBRSxRQUFRLENBQUMsSUFBSztJQUNyQixJQUFJLEdBQUcsR0FBRyxDQUFDLEdBQUcsT0FBTztJQUNyQixJQUFJLEdBQUcsQ0FBQztHQUNWO0dBQ0EsT0FBTztFQUNUO0VBQ0EsU0FBUyxHQUFHLEdBQUc7R0FDYixJQUFJLElBQUksRUFBRTtHQUNWLElBQUksRUFBRSxRQUFRLENBQUMsR0FBRztJQUNoQixRQUFRLElBQUksRUFBRSxTQUFTLEVBQUUsUUFBUSxDQUFDO0lBQ2xDLE9BQU87R0FDVDtHQUNBLE9BQU87RUFDVDtFQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUc7R0FDaEIsT0FBTyxNQUFNLE1BQU0sSUFBSSxFQUFFLFFBQVEsYUFBYSxHQUFHLElBQUksRUFBRSxHQUFHLHdCQUF3QixDQUFDLENBQUM7RUFDdEY7RUFDQSxJQUFJLEtBQUssU0FBUyxHQUFHO0dBQ25CLE9BQU8sRUFBRSxjQUFjLEVBQUU7RUFDM0I7RUFDQSxTQUFTLEdBQUcsR0FBRyxHQUFHO0dBQ2hCLEtBQUssSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLElBQUksSUFBSSxJQUFJLEdBQUcsQ0FBQyxNQUFNLE1BQU0sS0FBSyxNQUFNLEVBQUUsZ0JBQWlCLEVBQUUsUUFBUSxDQUFDLEdBQUcsSUFBSTtHQUNoRyxPQUFPO0VBQ1Q7RUFDQSxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUc7R0FDbkIsT0FBTyxFQUFFLFFBQVEsQ0FBQyxJQUFLO0lBQ3JCLElBQUksR0FBRyxHQUFHLENBQUMsR0FBRyxPQUFPLENBQUM7SUFDdEIsS0FBSyxJQUFJLEdBQUcsQ0FBQyxPQUFPLEdBQUcsT0FBTyxHQUFHLEdBQUcsQ0FBQztHQUN2QztHQUNBLE9BQU8sQ0FBQztFQUNWO0VBQ0EsU0FBUyxHQUFHLEdBQUc7R0FDYixPQUFPLEVBQUUsMkJBQTJCO0VBQ3RDO0VBQ0EsU0FBUyxHQUFHLEdBQUc7R0FDYixJQUFJLElBQUksYUFBYSxFQUFFLGFBQWEsRUFBRSxzQkFBc0IsSUFBSSxFQUFFLGVBQWUsQ0FBQyxDQUFDO0dBQ25GLE9BQU8sS0FBSztJQUFFLE1BQU0sRUFBRTtJQUFNLE9BQU8sRUFBRTtJQUFPLEtBQUssRUFBRTtJQUFLLFFBQVEsRUFBRTtJQUFRLE9BQU8sRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFO0lBQU0sUUFBUSxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUU7R0FBSTtFQUNySjtFQUNBLFNBQVMsR0FBRyxHQUFHO0dBQ2IsSUFBSSxHQUFHLElBQUksR0FBRyxDQUFDO0dBQ2YsSUFBSSxDQUFDLEdBQUcsVUFBVSxHQUFHO0lBQ25CLElBQUksSUFBSTtLQUFFLElBQUksS0FBSyxJQUFJLEVBQUUsQ0FBQyxNQUFNLEVBQUEsQ0FBRyxXQUFXLEVBQUUsU0FBUyxnQkFBZ0I7S0FBWSxHQUFHLEVBQUUsV0FBVyxFQUFFLFNBQVMsZ0JBQWdCO0lBQVU7SUFDMUksRUFBRSxRQUFRLEVBQUUsR0FBRyxFQUFFLFNBQVMsRUFBRSxHQUFHLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxVQUFVLEVBQUU7R0FDN0Q7R0FDQSxPQUFPO0VBQ1Q7RUFDQSxTQUFTLEdBQUcsR0FBRztHQUNiLEtBQUssSUFBSSxJQUFJLENBQUMsR0FBRyxJQUFLLEVBQUUsS0FBSyxDQUFDLEdBQUcsSUFBSSxHQUFHLENBQUM7R0FDekMsT0FBTztFQUNUO0VBQ0EsU0FBUyxHQUFHLEdBQUc7R0FDYixPQUFPLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsU0FBUyxjQUFjLENBQUMsR0FBRyxDQUFDO0VBQ3pEO0VBQ0EsU0FBUyxFQUFFLEdBQUcsR0FBRztHQUNmLEtBQUssSUFBSSxLQUFLLEdBQUcsRUFBRSxLQUFLLEVBQUU7R0FDMUIsT0FBTztFQUNUO0VBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHO0dBQ25CLE9BQU8sTUFBTSxXQUFXLEdBQUcsQ0FBQyxJQUFJLE1BQU0sU0FBUyxFQUFFLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO0VBQ3ZFO0VBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUc7R0FDdEIsSUFBSSxJQUFJO0dBQ1IsT0FBTyxFQUFFLE9BQU8sQ0FBQyxJQUFJLElBQUksR0FBRyxHQUFHLEdBQUcsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLE1BQU0sSUFBSSxFQUFFLE1BQU0sS0FBSyxHQUFHLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxNQUFNLElBQUksR0FBRyxDQUFDLElBQUk7RUFDN0c7RUFDQSxTQUFTLEdBQUcsR0FBRztHQUNiLE9BQU8sS0FBSztJQUFFLEdBQUcsT0FBTyxJQUFJLEVBQUUsSUFBSSxFQUFFO0lBQU0sR0FBRyxPQUFPLElBQUksRUFBRSxJQUFJLEVBQUU7R0FBSTtFQUN0RTtFQUNBLFNBQVMsR0FBRyxHQUFHO0dBQ2IsT0FBTyxDQUFDLEtBQUssT0FBTyxLQUFLLE9BQU8sTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFBLENBQUcsSUFBSSxFQUFFLFFBQVEsR0FBRyxFQUFFLElBQUksRUFBRSxPQUFPLEdBQUcsRUFBRSxRQUFRLEVBQUUsVUFBVSxFQUFFLFNBQVMsS0FBSyxFQUFFLEdBQUcsRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLFVBQVUsS0FBSyxFQUFFLElBQUk7RUFDcEw7RUFDQSxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUc7R0FDbkIsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsVUFBVSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFO0VBQ3RLO0VBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHO0dBQ25CLElBQUksSUFBSSxLQUFLLEVBQUUsUUFBUTtHQUN2QixPQUFPLEdBQUcsR0FBRyxLQUFLLEVBQUUsVUFBVSxFQUFFLFFBQVEsUUFBUSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUs7SUFBRSxHQUFHO0lBQUcsR0FBRztHQUFFO0VBQ25GO0VBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRztHQUNoQixJQUFJLElBQUksVUFBVSxTQUFTLEtBQUssVUFBVSxPQUFPLEtBQUssSUFBSSxVQUFVLEtBQUssU0FBUyxHQUFHO0lBQ25GLE9BQU8sQ0FBQztHQUNWLEdBQUcsSUFBSSxVQUFVLFNBQVMsSUFBSSxVQUFVLEtBQUssS0FBSztHQUNsRCxJQUFJLElBQUksS0FBSyxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUMsS0FBSyxFQUFFLE9BQU8sR0FBRyxNQUFNLE9BQU8sSUFBSSxHQUFHLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxHQUFHLE9BQU8sRUFBRSxRQUFRLFNBQVMsR0FBRztJQUM1RyxPQUFPLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQztHQUN0QixDQUFDLEdBQUc7R0FDSixJQUFJLEVBQUUsT0FBTyxDQUFDLE1BQU0sSUFBSSxHQUFHLElBQUksS0FBSyxFQUFFLEtBQUssQ0FBQyxLQUFLLEVBQUUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLEtBQUssQ0FBQztRQUNoRixJQUFJLEVBQUUsTUFBTSxDQUFDLEdBQUcsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FBSztJQUM3RCxJQUFJLElBQUksRUFBRTtJQUNWLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQztHQUNmO1FBQ0ssSUFBSSxFQUFFLE9BQU8sQ0FBQyxHQUFHLEtBQUssSUFBSSxLQUFLLEdBQ2xDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLFNBQVMsR0FBRztJQUN2QixPQUFPLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7R0FDOUIsQ0FBQyxHQUFHLEVBQUUsSUFBSSxHQUFHLENBQUM7R0FDaEIsT0FBTztFQUNUO0VBQ0EsU0FBUyxHQUFHLEdBQUc7R0FDYixPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUMsTUFBTSxJQUFJO0VBQzVCO0VBQ0EsSUFBSSxLQUFLLFNBQVMsR0FBRyxHQUFHO0dBQ3RCLE9BQU8sS0FBSyxLQUFLLElBQUksSUFBSSxJQUFJLENBQUM7RUFDaEMsR0FBRyxLQUFLLENBQUMsVUFBVSxLQUFLO0VBQ3hCLFNBQVMsR0FBRyxHQUFHLEdBQUc7R0FDaEIsRUFBRSxVQUFVLEVBQUUsUUFBUSxDQUFDO0dBQ3ZCLElBQUksSUFBSSxTQUFTLEdBQUc7SUFDbEIsSUFBSSxHQUFHLEtBQUssU0FBUyxHQUFHO0tBQ3RCLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtJQUMxQixDQUFDLEdBQUcsT0FBTztJQUNYLE9BQU8sRUFBRSxNQUFNLGNBQWMsTUFBTSxXQUFXLE9BQU8sZUFBZSxHQUFHLEdBQUc7S0FBRSxLQUFLLFdBQVc7TUFDMUYsT0FBTyxLQUFLLEVBQUUsUUFBUSxFQUFFLE1BQU0sS0FBSyxFQUFFLE1BQU0sS0FBSyxFQUFFO0tBQ3BEO0tBQUcsS0FBSyxTQUFTLEdBQUc7TUFDbEIsRUFBRSxNQUFNLEtBQUs7S0FDZjtLQUFHLGNBQWMsQ0FBQztJQUFFLENBQUM7R0FDdkI7R0FDQSxLQUFLLElBQUksS0FBSyxHQUFHLEVBQUUsQ0FBQztHQUNwQixPQUFPO0VBQ1Q7RUFDQSxTQUFTLEdBQUcsR0FBRyxHQUFHO0dBQ2hCLEVBQUUsT0FBTyxFQUFFLFFBQVEsQ0FBQyxHQUFHLEVBQUUsS0FBSyxJQUFJLEVBQUUsS0FBSyxHQUFHLEVBQUUsS0FBSyxJQUFJLEVBQUUsS0FBSyxHQUFHLEVBQUUsU0FBUyxFQUFFLFVBQVUsQ0FBQyxHQUFHLEVBQUUsT0FBTyxJQUFJLEVBQUUsT0FBTyxHQUFHLEVBQUUsT0FBTyxJQUFJLEVBQUUsT0FBTyxHQUFHLEVBQUUsWUFBWSxFQUFFO0VBQ2hLO0VBQ0EsU0FBUyxHQUFHLEdBQUc7R0FDYixFQUFFLEtBQUssSUFBSSxHQUFHLEVBQUUsS0FBSyxJQUFJLEdBQUcsRUFBRSxPQUFPLElBQUksR0FBRyxFQUFFLE9BQU8sSUFBSTtFQUMzRDtFQUNBLFNBQVMsR0FBRyxHQUFHO0dBQ2IsT0FBTyxhQUFhLEVBQUUsU0FBUyxhQUFhLEVBQUU7RUFDaEQ7RUFDQSxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUc7R0FDbkIsT0FBTyxJQUFJLEtBQUssUUFBUSxDQUFDLElBQUksS0FBSyxDQUFDLEVBQUEsQ0FBRyxJQUFJLEVBQUUsSUFBSSxNQUFNLEVBQUUsSUFBSSxFQUFFLElBQUksTUFBTTtFQUMxRTtFQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUc7R0FDaEIsT0FBTyxJQUFJLEtBQUs7SUFBRSxHQUFHO0lBQUcsR0FBRztHQUFFLEdBQUcsR0FBRyxpQkFBaUIsR0FBRyxDQUFDLEtBQUssR0FBRyxVQUFVLEdBQUcsQ0FBQyxHQUFHLEVBQUUsS0FBSyxPQUFPLFNBQVMsRUFBRSxLQUFLLE9BQU8sV0FBVyxHQUFHLFFBQVEsR0FBRyxDQUFDLEdBQUc7RUFDcko7RUFDQSxTQUFTLEdBQUcsR0FBRztHQUNiLE9BQU8sRUFBRSxPQUFPLEVBQUUsU0FBUyxJQUFJLEVBQUUsWUFBWSxFQUFFO0VBQ2pEO0VBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHO0dBQ25CLElBQUksSUFBSSxFQUFFLFNBQVMsSUFBSSxHQUFHLENBQUMsSUFBSSxFQUFFO0dBQ2pDLEdBQUcsR0FBRyxFQUFFLElBQUksR0FBRyxTQUFTLEdBQUcsR0FBRztJQUM1QixJQUFJLEtBQUssQ0FBQyxHQUFHLEdBQUcsaUJBQWlCLEdBQUcsQ0FBQyxJQUFJLEdBQUcsVUFBVSxHQUFHLENBQUMsSUFBSSxHQUFHLFVBQVUsR0FBRyxDQUFDO0dBQ2pGLEVBQUUsR0FBRyxFQUFFLE1BQU0sR0FBRyxFQUFFLFlBQVk7RUFDaEM7RUFDQSxTQUFTLEdBQUcsR0FBRztHQUNiLElBQUksSUFBSSxDQUFDO0dBQ1QsT0FBTyxFQUFFLE1BQU0sQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLFNBQVMsYUFBYSxFQUFFLFFBQVEsV0FBVyxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVEsSUFBSSxFQUFFLEtBQUssRUFBRSxlQUFlLE1BQU0sRUFBRSxRQUFRLFdBQVcsTUFBTSxFQUFFLEtBQUssRUFBRSxlQUFlLElBQUksRUFBRSxLQUFLLEVBQUUsZUFBZSxPQUFPLEVBQUUsS0FBSyxFQUFFLFFBQVEsSUFBSSxFQUFFLEtBQUssRUFBRSxRQUFRLEtBQUs7RUFDelI7RUFDQSxTQUFTLEdBQUcsR0FBRztHQUNiLEtBQUssSUFBSSxJQUFJO0lBQUUsT0FBTztJQUFHLE9BQU87SUFBRyxTQUFTO0lBQUcsU0FBUztJQUFHLFNBQVM7SUFBRyxTQUFTO0dBQUUsR0FBRyxJQUFJLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FBSztJQUM3RyxJQUFJLElBQUksRUFBRTtJQUNWLEtBQUssSUFBSSxLQUFLLEdBQUcsRUFBRSxNQUFNLEVBQUU7R0FDN0I7R0FDQSxLQUFLLElBQUksS0FBSyxHQUFHLEVBQUUsTUFBTSxFQUFFO0dBQzNCLE9BQU87RUFDVDtFQUNBLFNBQVMsR0FBRyxHQUFHO0dBQ2IsSUFBSSxDQUFDLEVBQUUsUUFBUSxPQUFPO0dBQ3RCLElBQUksSUFBSSxHQUFHLENBQUMsR0FBRyxJQUFJLEtBQUssSUFBSSxFQUFFLEVBQUUsQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLEtBQUssR0FBRyxJQUFJLEtBQUssSUFBSSxFQUFFLEVBQUUsQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLEtBQUssR0FBRyxJQUFJLEtBQUssSUFBSSxFQUFFLEVBQUUsQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLEtBQUssR0FBRyxJQUFJLEtBQUssSUFBSSxFQUFFLEVBQUUsQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLEtBQUs7R0FDcEssT0FBTztJQUFFLEdBQUc7SUFBRyxHQUFHO0lBQUcsTUFBTTtJQUFHLEtBQUs7SUFBRyxPQUFPO0lBQUcsUUFBUTtJQUFHLE9BQU8sSUFBSTtJQUFHLFFBQVEsSUFBSTtHQUFFO0VBQ3pGO0VBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRztHQUNoQixJQUFJLElBQUksSUFBSSxLQUFLLElBQUksSUFBSSxLQUFLLElBQUksR0FBRyxDQUFDO0dBQ3RDLE9BQU8sR0FEc0MsRUFBRSxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxJQUFRLEVBQUUsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsRUFDckU7RUFDaEI7RUFDQSxTQUFTLEdBQUcsR0FBRyxHQUFHO0dBQ2hCLElBQUksSUFBSSxJQUFJLEtBQUssSUFBSSxJQUFJLEtBQUssSUFBSSxHQUFHLENBQUMsR0FBRyxJQUFJLEVBQUUsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsSUFBSSxJQUFJLEVBQUUsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUM7R0FDbkYsT0FBTyxNQUFNLEtBQUssTUFBTSxHQUFHLENBQUMsSUFBSSxLQUFLO0VBQ3ZDO0VBQ0EsU0FBUyxHQUFHLEdBQUc7R0FDYixPQUFPLEVBQUUsT0FBTyxFQUFFLFdBQVcsSUFBSSxFQUFFLGNBQWMsRUFBRSxPQUFPLEVBQUUsV0FBVyxJQUFJO0lBQUMsS0FBSztJQUFHLEtBQUs7SUFBRztJQUFTO0lBQU87R0FBTyxDQUFDLENBQUMsRUFBRSxlQUFlLFFBQVEsS0FBSyxFQUFFLFFBQVEsRUFBRSxLQUFLLGFBQWEsRUFBRSxRQUFRLFVBQVU7RUFDdk07RUFDQSxTQUFTLEdBQUcsR0FBRztHQUNiLElBQUksSUFBSSxFQUFFLEtBQUssRUFBRSxZQUFZLElBQUksRUFBRSxhQUFhLElBQUksRUFBRTtHQUN0RCxPQUFPLENBQUMsR0FBRyxJQUFJLEVBQUUsS0FBSyxFQUFFLE1BQU0sR0FBRyxHQUFHLEVBQUUsYUFBYSxDQUFDO0VBQ3REO0VBQ0EsSUFBSSxLQUFLLFdBQVc7R0FDbEIsU0FBUyxFQUFFLEdBQUc7SUFDWixFQUFFLE1BQU0sQ0FBQyxHQUFHLEtBQUssOEJBQThCLENBQUMsR0FBRyxLQUFLLHFCQUFxQixDQUFDLEdBQUcsS0FBSyxlQUFlO0dBQ3ZHO0dBQ0EsT0FBTyxFQUFFLEdBQUc7SUFBQztLQUFFLEtBQUs7S0FBa0IsT0FBTyxXQUFXLENBQ3hEO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBbUIsT0FBTyxXQUFXO01BQy9DLEtBQUsscUJBQXFCLENBQUM7S0FDN0I7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUE0QixPQUFPLFdBQVc7TUFDeEQsS0FBSyw4QkFBOEIsS0FBSyxxQkFBcUIsQ0FBQztLQUNoRTtJQUFFO0dBQUMsQ0FBQyxHQUFHO0VBQ1QsRUFBRTtFQUNGLE9BQU8sZUFBZSxHQUFHLFdBQVcsZUFBZTtHQUFFLEtBQUssV0FBVztJQUNuRSxPQUFPLEtBQUssYUFBYTtHQUMzQjtHQUFHLEtBQUssV0FBVyxDQUNuQjtFQUFFLENBQUM7RUFDSCxJQUFJLEtBQUssU0FBUyxHQUFHLEdBQUc7R0FDdEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLO0lBQ2pDLElBQUksSUFBSSxFQUFFO0lBQ1YsRUFBRSxLQUFLLENBQUM7R0FDVjtHQUNBLE9BQU87RUFDVCxHQUFHLEtBQUssU0FBUyxHQUFHO0dBQ2xCLE9BQU8sR0FBRyxDQUFDLEdBQUcsQ0FBQztFQUNqQixHQUFHLEtBQUssU0FBUyxHQUFHLEdBQUc7R0FDckIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLLElBQUksRUFBRSxFQUFFLElBQUksR0FBRyxDQUFDLEdBQUcsT0FBTztHQUM3RCxPQUFPO0VBQ1QsR0FBRyxLQUFLLFNBQVMsR0FBRyxHQUFHO0dBQ3JCLE9BQU8sRUFBRSxHQUFHLEdBQUcsQ0FBQztFQUNsQixHQUFHLEtBQUssU0FBUyxHQUFHO0dBQ2xCLEVBQUUsR0FBRyxDQUFDO0dBQ04sSUFBSSxJQUFJLEVBQUUsQ0FBQztHQUNYLFNBQVMsRUFBRSxHQUFHLEdBQUcsR0FBRztJQUNsQixJQUFJO0lBQ0osRUFBRSxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxLQUFLLE1BQU0sRUFBRSxZQUFZLEVBQUEsQ0FBRyxXQUFXLEtBQUssR0FBRyxFQUFFLFlBQVksS0FBSyxHQUFHLEVBQUUsZ0JBQWdCLEtBQUssR0FBRyxFQUFFLFlBQVksS0FBSyxHQUFHLEVBQUUscUJBQXFCLENBQUMsR0FBRyxFQUFFLDhCQUE4QixDQUFDO0lBQ3BNLElBQUksSUFBSSxNQUFNLGNBQWMsRUFBRSxPQUFPLEVBQUUsS0FBSyxJQUFJLEVBQUUsU0FBUyxJQUFJLEVBQUU7SUFDakUsT0FBTyxFQUFFLE9BQU8sR0FBRyxFQUFFLFNBQVMsR0FBRyxFQUFFLGdCQUFnQixHQUFHLEVBQUUsV0FBVyxHQUFHLEVBQUUsWUFBWSxHQUFHLEVBQUUsZ0JBQWdCLEVBQUUsUUFBUSxFQUFFLFlBQVksRUFBRSxjQUFjLEVBQUUsWUFBWSxFQUFFLFdBQVc7R0FDOUs7R0FDQSxPQUFPLEVBQUUsR0FBRztJQUFDO0tBQUUsS0FBSztLQUFVLE9BQU8sV0FBVztNQUM5QyxJQUFJLElBQUksTUFBTSxJQUFJLEtBQUssYUFBYTtNQUNwQyxJQUFJLEtBQUssU0FBUyxrQkFBa0IsS0FBSyxZQUFZLEVBQUUsSUFBSSxhQUFhLEtBQUssWUFBWSxFQUFFLElBQUksWUFBWSxLQUFLLFFBQVEsSUFBSSxFQUFFLEtBQUssV0FBVyxLQUFLLFVBQVUsRUFBRSxLQUFLLFVBQVUsS0FBSyxRQUFRLEVBQUUsV0FBVyxDQUFDLEdBQUcsRUFBRSxPQUFPLFFBQVEsTUFBTSxLQUFLLHlCQUF5QixHQUFHLEtBQUssU0FBUyxnQkFBZ0I7T0FDaFMsSUFBSSxJQUFJLEVBQUUsYUFBYSxJQUFJLEdBQUcsR0FBRyxTQUFTLEdBQUc7UUFDM0MsSUFBSSxJQUFJLEVBQUUsVUFBVSxJQUFJLEVBQUU7UUFDMUIsT0FBTyxNQUFNLEVBQUUsWUFBWSxNQUFNLEVBQUU7T0FDckMsQ0FBQztPQUNELEVBQUUsWUFBWSxPQUFPLEdBQUcsQ0FBQztPQUN6QixJQUFJLElBQUksSUFBSSxFQUFFLEdBQUcsS0FBSyxXQUFXLGdCQUFnQjtPQUNqRCxFQUFFLFdBQVcsS0FBSyxVQUFVLEVBQUUsU0FBUyxLQUFLLFFBQVEsS0FBSyxTQUFTLEtBQUssQ0FBQztNQUMxRSxPQUFPLEtBQUssU0FBUyxLQUFLLElBQUksRUFBRSxHQUFHLEtBQUssV0FBVyxXQUFXLENBQUM7S0FDakU7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFrQixPQUFPLFdBQVcsQ0FDaEQ7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFtQixPQUFPLFdBQVc7TUFDL0MsS0FBSyxxQkFBcUIsQ0FBQztLQUM3QjtJQUFFO0lBQUc7S0FBRSxLQUFLO0tBQTRCLE9BQU8sV0FBVztNQUN4RCxLQUFLLDhCQUE4QixLQUFLLHFCQUFxQixDQUFDO0tBQ2hFO0lBQUU7R0FBQyxDQUFDLEdBQUc7RUFDVCxFQUFFLEVBQUU7RUFDSixTQUFTLEdBQUcsR0FBRyxHQUFHO0dBQ2hCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLE1BQU0sR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLO0lBQ2hELElBQUksSUFBSSxFQUFFLElBQUksSUFBSSxFQUFFLFVBQVUsSUFBSSxFQUFFO0lBQ3BDLEVBQUUsV0FBVyxHQUFHLEVBQUUsU0FBUyxHQUFHLEVBQUUsS0FBSyxDQUFDLEdBQUcsRUFBRSxxQkFBcUIsRUFBRSw4QkFBOEIsQ0FBQztHQUNuRztFQUNGO0VBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRztHQUNoQixLQUFLLElBQUksSUFBSSxTQUFTLEdBQUcsR0FBRztJQUMxQixLQUFLLElBQUksSUFBSSxDQUFDLEdBQUcsSUFBSSxHQUFHLElBQUksRUFBRSxjQUFjLE1BQU0sSUFBSSxFQUFFLFFBQVEsS0FBSztLQUNuRSxJQUFJLElBQUksRUFBRTtLQUNWLElBQUksRUFBRSxRQUFRLEtBQUssU0FBUztNQUMxQixJQUFJLElBQUksRUFBRSxRQUFRLEtBQUs7TUFDdkIsSUFBSSxFQUFFLEVBQUUsUUFBUSxDQUFDLEtBQUssTUFBTSxLQUFLLEVBQUUsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO09BQUUsVUFBVTtPQUFHLGtCQUFrQjtNQUFFLENBQUMsSUFBSSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxlQUFlLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FBSztPQUM5SyxJQUFJLElBQUksRUFBRTtPQUNWLE1BQU0sS0FBSyxFQUFFLEtBQUs7UUFBRSxVQUFVO1FBQUcsU0FBUztRQUFHLE1BQU0sRUFBRSxRQUFRLENBQUM7T0FBRSxDQUFDO01BQ25FO0tBQ0Y7SUFDRjtJQUNBLE9BQU87R0FDVCxFQUFFLEdBQUcsQ0FBQyxHQUFHLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLO0lBQ2pDLElBQUksSUFBSSxFQUFFO0lBQ1YsRUFBRSxPQUFPLEVBQUUsU0FBUyxRQUFRLEVBQUUsT0FBTztHQUN2QztHQUNBLE9BQU87RUFDVDtFQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUcsR0FBRztHQUNuQixLQUFLLElBQUksSUFBSSxFQUFFLFdBQVcsSUFBSSxFQUFFLGNBQWMsSUFBSSxFQUFFLFNBQVMsSUFBSSxDQUFDLEdBQUcsSUFBSSxHQUFHLElBQUksRUFBRSxhQUFhLElBQUksRUFBRSxRQUFRLEtBQUs7SUFDaEgsSUFBSSxJQUFJLEVBQUUsSUFBSSxJQUFJLEVBQUUsVUFBVSxJQUFJLEVBQUUsU0FBUyxJQUFJLEVBQUUsTUFBTSxJQUFJLEVBQUUsVUFBVSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQztJQUN6RixFQUFFLEtBQUssSUFBSSxJQUFJLElBQUk7R0FDckI7R0FDQSxJQUFJLElBQUksU0FBUyxHQUFHO0lBQ2xCLEtBQUssSUFBSSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxJQUFJLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FBSztLQUNsRCxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksRUFBRTtLQUNwQixJQUFJLEtBQUssTUFBTSxHQUFHLElBQUksR0FBRztNQUN2QixJQUFJLEtBQUssR0FBRyxDQUFDLEdBQUcsSUFBSSxHQUFHLENBQUM7TUFDeEIsSUFBSSxPQUFPLEVBQUUsZUFBZSxJQUFJLE1BQU0sRUFBRSxlQUFlLElBQUksT0FBTyxHQUFHO09BQ25FLElBQUksRUFBRSxTQUFTLElBQUksR0FBRyxDQUFDO09BQ3ZCLElBQUksS0FBSyxLQUFLO09BQ2QsSUFBSSxhQUFhLEVBQUUsZUFBZSxhQUFhLEVBQUUsY0FBYyxFQUFFLGFBQWEsRUFBRSxnQkFBZ0I7UUFDOUYsSUFBSSxNQUFNLEdBQUc7UUFDYixLQUFLLEVBQUU7T0FDVCxPQUFPLEtBQUs7T0FDWixLQUFLLElBQUksS0FBSyxHQUFHLElBQUksRUFBRSxhQUFhLEdBQUcsS0FBSyxHQUFHLEdBQUcsT0FBTyxHQUFHLFFBQVEsRUFBRSxNQUFPO09BQzdFLElBQUksS0FBSztRQUFDLEdBQUcsS0FBSztRQUFJLEdBQUc7UUFBSyxFQUFFO09BQUc7T0FDbkMsSUFBSSxHQUFHLElBQUksS0FBSyxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUMsV0FBVyxLQUFNO1FBQzlDLElBQUksT0FBTyxHQUFHLElBQUk7U0FDaEIsSUFBSSxHQUFHLElBQUk7U0FDWDtRQUNGO1FBQ0EsSUFBSSxPQUFPLEdBQUcsSUFBSTtRQUNsQixLQUFLLEdBQUc7T0FDVjtNQUNGLE9BQU8sSUFBSSxJQUFJLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsS0FBSyxPQUFPLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEtBQUssT0FBTyxJQUFJO1dBQ2xJLElBQUk7S0FDWCxPQUFPLElBQUk7SUFDYjtJQUNBLE9BQU87R0FDVCxFQUFFLENBQUM7R0FDSCxPQUFPLEVBQUUsWUFBWSxNQUFNO0VBQzdCO0VBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHO0dBQ25CLElBQUksSUFBSSxFQUFFLFdBQVcsSUFBSTtJQUFFLE9BQU87SUFBTSxPQUFPO0lBQU0sVUFBVTtJQUFNLFlBQVk7SUFBTSxNQUFNO0lBQU0sTUFBTTtHQUFLO0dBQzlHLE9BQU8sRUFBRSxTQUFTLGdCQUFnQixFQUFFLFdBQVcsSUFBSSxHQUFHLEdBQUcsR0FBRyxjQUFjLEdBQUcsRUFBRSxTQUFTLFNBQVMsTUFBTSxFQUFFLFNBQVMsV0FBVyxPQUFPLEVBQUUsU0FBUyxjQUFjLEVBQUUsYUFBYSxJQUFJLEdBQUcsR0FBRyxHQUFHLGdCQUFnQixHQUFHLEVBQUUsV0FBVyxTQUFTLE1BQU0sRUFBRSxXQUFXLFdBQVcsT0FBTyxFQUFFLGFBQWEsRUFBRSxJQUFJLFlBQVksRUFBRSxLQUFLLFlBQVksRUFBRSxLQUFLLGFBQWEsRUFBRSxRQUFRLElBQUksR0FBRyxHQUFHLEdBQUcsV0FBVyxHQUFHLEVBQUUsWUFBWSxFQUFFLE1BQU0sU0FBUyxFQUFFLEtBQUssU0FBUyxFQUFFLGVBQWUsRUFBRSxNQUFNLFdBQVcsRUFBRSxLQUFLLFdBQVcsRUFBRSxJQUFJLGFBQWEsRUFBRSxRQUFRLElBQUksR0FBRyxHQUFHLEdBQUcsV0FBVyxHQUFHLEVBQUUsWUFBWSxFQUFFLElBQUksU0FBUyxFQUFFLFdBQVcsRUFBRSxJQUFJLFlBQVksRUFBRSxTQUFTLGFBQWEsRUFBRSxJQUFJLGFBQWEsRUFBRSxPQUFPLElBQUksR0FBRyxHQUFHLEdBQUcsTUFBTSxHQUFHLEVBQUUsV0FBVyxFQUFFLElBQUksVUFBVSxFQUFFLGdCQUFnQixFQUFFLElBQUksVUFBVSxFQUFFLFNBQVMsY0FBYyxFQUFFLElBQUksYUFBYSxFQUFFLE9BQU8sSUFBSSxHQUFHLEdBQUcsR0FBRyxVQUFVLEdBQUcsRUFBRSxXQUFXLEVBQUUsSUFBSSxZQUFZO0VBQ3QwQjtFQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUc7R0FDaEIsSUFBSSxJQUFJLEVBQUUsV0FBVyxJQUFJLEVBQUUsYUFBYSxJQUFJLEVBQUUsS0FBSyxJQUFJLEVBQUU7R0FDekQsRUFBRSxTQUFTLEVBQUUsU0FBUyxLQUFLLEVBQUUsS0FBSyxHQUFHLEVBQUUsU0FBUyxFQUFFLFNBQVMsS0FBSyxFQUFFLEtBQUssR0FBRyxFQUFFLFFBQVEsRUFBRSxTQUFTLEtBQUssRUFBRSxJQUFJLEdBQUcsRUFBRSxRQUFRLEVBQUUsU0FBUyxLQUFLLEVBQUUsSUFBSSxHQUFHLEVBQUUsY0FBYyxHQUFHLEdBQUcsRUFBRSxVQUFVLEdBQUcsRUFBRSxLQUFLLFdBQVcsRUFBRSxVQUFVLEVBQUUsS0FBSyxVQUFVLEVBQUU7RUFDeE87RUFDQSxTQUFTLEdBQUcsR0FBRyxHQUFHO0dBQ2hCLElBQUksSUFBSSxFQUFFLGFBQWEsSUFBSSxFQUFFLFFBQVEsSUFBSSxFQUFFO0dBQzNDLElBQUksRUFBRSxTQUFTLGNBQWMsRUFBRSxTQUFTLFdBQVc7SUFDakQsSUFBSSxJQUFJLEVBQUU7SUFDVixFQUFFLGdCQUFnQixFQUFFLGNBQWMsR0FBRyxHQUFHLEVBQUUsT0FBTztJQUNqRCxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsR0FBRyxHQUFHLENBQUM7SUFDekIsRUFBRSxXQUFXLEVBQUUsWUFBWSxDQUFDLENBQUMsS0FBSyxFQUFFLGFBQWEsRUFBRSxJQUFJLFlBQVksRUFBRSxZQUFZLEVBQUUsSUFBSSxTQUFTLEVBQUUsSUFBSSxXQUFXLEtBQUssRUFBRSxVQUFVLEVBQUUsSUFBSSxVQUFVLEtBQUssRUFBRSxTQUFTLEVBQUUsU0FBUyxHQUFHLEdBQUcsR0FBRyxDQUFDO0dBQ3pMO0VBQ0Y7RUFDQSxJQUFJLEtBQUs7R0FBRSxJQUFJO0dBQWdCLFNBQVMsU0FBUyxHQUFHO0lBQ2xELElBQUksSUFBSSxFQUFFLFNBQVMsSUFBSSxFQUFFLGdCQUFnQixJQUFJLEVBQUUsY0FBYyxJQUFJLEVBQUU7SUFDbkUsRUFBRSxVQUFVLEVBQUUsR0FBRyxFQUFFLFVBQVUsV0FBVyxTQUFTLEdBQUc7S0FDbEQsT0FBTyxTQUFTLEdBQUcsR0FBRztNQUNwQixJQUFJLEVBQUUsT0FBTyxDQUFDLEdBQUc7T0FDZixJQUFJLEVBQUUsUUFBUSxLQUFLLFVBQVUsRUFBRSxZQUFZLENBQUMsR0FBRyxFQUFFLFdBQVc7UUFDMUQsSUFBSSxJQUFJLEdBQUcsRUFBRSxTQUFTLEdBQUcsSUFBSSxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxTQUFTLEdBQUcsR0FBRztTQUNoRSxPQUFPLEVBQUUsaUJBQWlCLEtBQUssQ0FBQyxJQUFJLE9BQU8sT0FBTyxDQUFDLElBQUksOEJBQThCLEtBQUssQ0FBQyxJQUFJLE9BQU8sT0FBTyxDQUFDLElBQUksS0FBSyxFQUFFLElBQUk7UUFDL0gsR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLO1FBQzNCLEtBQUssRUFBRSxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsUUFBUSxLQUFLLFlBQVk7T0FDckQ7T0FDQSxPQUFPLEVBQUUsS0FBSyxFQUFFLE1BQU0sS0FBSyxFQUFFLEdBQUcsUUFBUSxFQUFFLE1BQU0sR0FBRyxFQUFFLEtBQUssRUFBRSxjQUFjLEtBQUssRUFBRSxHQUFHLGdCQUFnQixFQUFFLGNBQWMsR0FBRyxFQUFFLEtBQUssRUFBRSxnQkFBZ0IsS0FBSyxFQUFFLEdBQUcsa0JBQWtCLEVBQUUsZ0JBQWdCLEdBQUcsRUFBRSxLQUFLLEVBQUUsV0FBVyxLQUFLLEVBQUUsR0FBRyxhQUFhLEVBQUUsV0FBVyxHQUFHLEVBQUUsS0FBSyxFQUFFLFdBQVcsS0FBSyxFQUFFLEdBQUcsYUFBYSxFQUFFLFdBQVcsR0FBRyxFQUFFLEtBQUssRUFBRSxVQUFVLEtBQUssRUFBRSxHQUFHLFlBQVksRUFBRSxVQUFVLEdBQUcscUJBQXFCLEtBQUssRUFBRSxPQUFPLElBQUksRUFBRSxRQUFRLEtBQUssVUFBVSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsT0FBTyxNQUFNLEVBQUUsUUFBUSxLQUFLLFVBQVUsS0FBSyxJQUFJLEtBQUssSUFBSSxHQUFHLEVBQUUsT0FBTyxHQUFHLENBQUMsSUFBSSxZQUFZLE1BQU0sRUFBRSxRQUFRLEtBQUssU0FBUyxFQUFFLFNBQVMsYUFBYSxNQUFNLEVBQUUsUUFBUSxLQUFLLFVBQVUsRUFBRSxVQUFVO01BQ2pvQjtNQUNBLE9BQU8sRUFBRSxLQUFLLENBQUMsS0FBSyxFQUFFLFFBQVEsS0FBSyxVQUFVLEdBQUcsS0FBSyxFQUFFLFFBQVE7S0FDakUsRUFBRSxNQUFNLENBQUM7SUFDWCxHQUFHLEVBQUUsVUFBVSxZQUFZLFNBQVMsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUc7S0FDcEQsT0FBTyxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUc7TUFDbkMsSUFBSSxJQUFJLENBQUM7TUFDVCxJQUFJLEVBQUUsSUFBSSxLQUFLLEVBQUUsUUFBUSxDQUFDLElBQUksT0FBTyxDQUFDLENBQUMsRUFBRSxRQUFRLEtBQUssV0FBVyxFQUFFLFFBQVEsS0FBSyxRQUFRLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUM7TUFDM0csSUFBSSxJQUFJLEVBQUUsUUFBUSxLQUFLO01BQ3ZCLElBQUksTUFBTSxXQUFXO09BQ25CLElBQUksSUFBSSxHQUFHLEdBQUcsR0FBRyxNQUFNLEdBQUcsSUFBSSxHQUFHLENBQUM7T0FDbEMsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRTtPQUNyQixJQUFJLElBQUksRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxPQUFPLEtBQUssRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRTtPQUNuRSxJQUFJLEtBQUs7TUFDWDtNQUNBLElBQUksSUFBSSxFQUFFLFFBQVEsQ0FBQztNQUNuQixJQUFJLEtBQUssTUFBTSxVQUFVO09BQ3ZCLElBQUksS0FBSyxFQUFFLE9BQU8sRUFBRSxRQUFRLEdBQUcsS0FBSyxFQUFFLE1BQU0sRUFBRSxTQUFTO09BQ3ZELElBQUksTUFBTSxFQUFFLFFBQVEsTUFBTSxFQUFFLFNBQVMsTUFBTSxFQUFFLE9BQU8sTUFBTSxFQUFFO01BQzlEO01BQ0EsT0FBTyxLQUFLLEVBQUUsT0FBTyxDQUFDLE1BQU0sSUFBSSxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksRUFBRSxPQUFPLEVBQUUsS0FBSyxJQUFJLEtBQUssSUFBSSxFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsSUFBSSxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksRUFBRSxRQUFRLEVBQUUsTUFBTSxJQUFJLEtBQUssSUFBSSxFQUFFLEtBQUssRUFBRSxHQUFHLENBQUMsS0FBSyxFQUFFLFFBQVEsRUFBRSxXQUFXLElBQUksRUFBRSxRQUFRLEtBQUssWUFBWSxJQUFJLEVBQUUsUUFBUSxLQUFLLFFBQVEsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxJQUFJO0tBQ3JSLEVBQUUsTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQztJQUMxQixHQUFHLEVBQUUsY0FBYyxTQUFTLEdBQUc7S0FDN0IsT0FBTyxFQUFFLEtBQUssQ0FBQyxLQUFLLEVBQUUsY0FBYyxHQUFHLEtBQUssRUFBRTtJQUNoRCxHQUFHLEVBQUUsRUFBRSxnQkFBZ0I7S0FBRSxXQUFXLENBQUM7S0FBRyxXQUFXLENBQUM7S0FBRyxjQUFjLENBQUM7S0FBRyxnQkFBZ0IsQ0FBQztLQUFHLFVBQVUsQ0FBQztLQUFHLE1BQU0sQ0FBQztJQUFFLENBQUMsR0FBRyxFQUFFLFdBQVcsT0FBTyxZQUFZLEVBQUUsY0FBYyxDQUFDLEdBQUcsRUFBRSxRQUFRLE9BQU8sR0FBRztHQUNsTTtHQUFHLFdBQVc7SUFBRSxvQ0FBb0MsU0FBUyxHQUFHO0tBQzlELElBQUksSUFBSSxFQUFFO0tBQ1YsRUFBRSxTQUFTLFNBQVMsV0FBVyxFQUFFLFlBQVk7TUFBRSxLQUFLO09BQUUsVUFBVTtPQUFNLFNBQVM7TUFBSztNQUFHLE1BQU07T0FBRSxVQUFVO09BQU0sU0FBUztNQUFLO01BQUcsVUFBVTtNQUFNLFFBQVE7TUFBTSxhQUFhLENBQUM7S0FBRTtJQUNoTDtJQUFHLG1DQUFtQyxTQUFTLEdBQUcsR0FBRztLQUNuRCxJQUFJLElBQUksRUFBRSxhQUFhLEtBQUssRUFBRSxPQUFPLEVBQUU7S0FDdkMsSUFBSSxFQUFFLFNBQVMsU0FBUyxRQUFRO01BQzlCLElBQUksSUFBSSxFQUFFO01BQ1YsRUFBRSxjQUFjLENBQUMsR0FBRyxFQUFFLFNBQVMsQ0FBQyxHQUFHLEVBQUUsY0FBYyxHQUFHLEdBQUcsRUFBRSxPQUFPLEdBQUcsRUFBRSxTQUFTLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FBRyxFQUFFLE9BQU8sYUFBYSxHQUFHLEVBQUUsYUFBYSxFQUFFLE9BQU8sUUFBUSxHQUFHLEVBQUUsS0FBSyxzQkFBc0I7T0FBRSxhQUFhO09BQUcsV0FBVztNQUFFLENBQUM7S0FDeE47SUFDRjtJQUFHLDRCQUE0QjtJQUFJLGtDQUFrQyxTQUFTLEdBQUcsR0FBRztLQUNsRixJQUFJLElBQUksRUFBRSxhQUFhLElBQUksRUFBRTtLQUM3QixJQUFJLEVBQUUsU0FBUyxTQUFTLFFBQVE7TUFDOUIsSUFBSSxJQUFJLEVBQUU7TUFDVixHQUFHLEdBQUcsRUFBRSxNQUFNLEdBQUcsRUFBRSxLQUFLLHFCQUFxQjtPQUFFLGFBQWE7T0FBRyxXQUFXO01BQUUsQ0FBQyxHQUFHLEVBQUUsU0FBUyxDQUFDO0tBQzlGO0lBQ0Y7SUFBRywyQkFBMkIsU0FBUyxHQUFHLEdBQUc7S0FDM0MsSUFBSSxFQUFFLFlBQVksU0FBUyxTQUFTLFFBQVE7TUFDMUMsSUFBSSxJQUFJLEVBQUUsYUFBYSxJQUFJLEVBQUU7TUFDN0IsR0FBRyxHQUFHLENBQUMsR0FBRyxHQUFHLEdBQUcsRUFBRSxVQUFVLE1BQU0sR0FBRyxFQUFFLEtBQUssb0JBQW9CO09BQUUsYUFBYTtPQUFHLFdBQVc7TUFBRSxDQUFDO0tBQ2xHO0lBQ0Y7SUFBRyxxQkFBcUIsU0FBUyxHQUFHO0tBQ2xDLElBQUksSUFBSSxFQUFFO0tBQ1YsSUFBSSxFQUFFLFNBQVMsU0FBUyxRQUFRO01BQzlCLElBQUksSUFBSSxFQUFFO01BQ1YsTUFBTSxFQUFFLGNBQWMsTUFBTSxFQUFFLFNBQVMsTUFBTSxFQUFFLElBQUksV0FBVyxNQUFNLEVBQUUsSUFBSSxVQUFVLE1BQU0sRUFBRSxLQUFLLFdBQVcsTUFBTSxFQUFFLEtBQUssVUFBVSxNQUFNLEVBQUUsV0FBVyxDQUFDO0tBQ3pKO0lBQ0Y7R0FBRTtHQUFHLGdCQUFnQjtHQUFJLFNBQVM7R0FBSSxlQUFlO0dBQUksZ0JBQWdCO0dBQUksaUJBQWlCLFNBQVMsR0FBRztJQUN4RyxPQUFPLEVBQUUsT0FBTyxNQUFNLE1BQU0sS0FBSyxFQUFFLE9BQU8sTUFBTSxNQUFNO0dBQ3hEO0dBQUcsVUFBVTtJQUFFLFNBQVMsQ0FBQztJQUFHLFFBQVE7SUFBTSxTQUFTO0dBQVU7RUFBRSxHQUFHLEtBQUs7RUFDdkUsU0FBUyxHQUFHLEdBQUc7R0FDYixJQUFJLElBQUksRUFBRSxhQUFhLElBQUksRUFBRSxRQUFRLElBQUksRUFBRTtHQUMzQyxJQUFJLEVBQUUsU0FBUyxTQUFTLFdBQVc7SUFDakMsSUFBSSxJQUFJLEVBQUUsU0FBUyxJQUFJLFNBQVMsR0FBRztLQUNqQyxPQUFPLEVBQUU7SUFDWCxDQUFDLEdBQUcsSUFBSSxNQUFNLFNBQVMsSUFBSSxNQUFNLE9BQU8sSUFBSSxFQUFFLGFBQWEsUUFBUTtJQUNuRSxJQUFJLEVBQUUsVUFBVSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsR0FBRyxHQUFHLEVBQUUsV0FBVyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEVBQUUsTUFBTSxHQUFHLENBQUMsR0FBRyxFQUFFLFFBQVEsR0FBRyxFQUFFLEtBQUssR0FBRyxFQUFFLFFBQVEsR0FBRyxHQUFHLENBQUMsR0FBRyxFQUFFLEtBQUssR0FBRyxFQUFFLFFBQVEsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLFFBQVEsYUFBYSxFQUFFO1NBQ3RMLElBQUksS0FBSyxFQUFFLFNBQVMsU0FBUyxHQUFHO0tBQ25DLElBQUksSUFBSSxFQUFFO0tBQ1YsRUFBRSxXQUFXLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLE9BQU8sRUFBRSxLQUFLLEdBQUcsRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLEtBQUs7SUFDakcsT0FBTyxFQUFFLFdBQVcsR0FBRyxHQUFHLENBQUMsR0FBRyxFQUFFLE1BQU0sR0FBRyxDQUFDLEdBQUcsRUFBRSxRQUFRLEVBQUUsV0FBVyxFQUFFLFFBQVEsZUFBZSxFQUFFLFFBQVEsR0FBRyxHQUFHLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsUUFBUSxPQUFPLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxRQUFRO0lBQzlLLEVBQUUsUUFBUSxXQUFXLEVBQUUsVUFBVSxFQUFFLFFBQVEsUUFBUSxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsS0FBSyxLQUFLLEVBQUUsVUFBVSxJQUFJLEtBQUssQ0FBQyxNQUFNLEVBQUUsS0FBSyxNQUFNLEVBQUUsUUFBUSxRQUFRLEVBQUU7R0FDaEo7RUFDRjtFQUNBLElBQUksS0FBSztHQUFFLElBQUk7R0FBbUIsUUFBUSxDQUFDLGdCQUFnQixnQkFBZ0I7R0FBRyxTQUFTLFNBQVMsR0FBRztJQUNqRyxJQUFJLElBQUksRUFBRSxTQUFTLElBQUksRUFBRSxjQUFjLElBQUksRUFBRTtJQUM3QyxFQUFFLFVBQVUsYUFBYSxTQUFTLEdBQUc7S0FDbkMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxLQUFLLEtBQUssUUFBUSxRQUFRLFVBQVUsRUFBRSxZQUFZLENBQUMsR0FBRyxLQUFLLGFBQWEsV0FBVyxDQUFDLEdBQUcsS0FBSyxZQUFZLFdBQVcsQ0FBQyxHQUFHLFFBQVEsRUFBRSxLQUFLLENBQUMsS0FBSyxLQUFLLFFBQVEsUUFBUSxVQUFVLEdBQUcsUUFBUSxLQUFLLFFBQVE7SUFDdE4sR0FBRyxFQUFFLElBQUksVUFBVSxJQUFJLEVBQUUsV0FBVyxVQUFVLGNBQWMsRUFBRSxRQUFRLFVBQVUsR0FBRztHQUNyRjtHQUFHLFdBQVc7SUFBRSw2QkFBNkI7SUFBSSw0QkFBNEI7SUFBSSwyQkFBMkI7SUFBSSxvQkFBb0IsU0FBUyxHQUFHO0tBQzlJLEVBQUUsWUFBWSxVQUFVO01BQUUsT0FBTztNQUFHLFVBQVU7TUFBRyxPQUFPO01BQUcsWUFBWTtNQUFHLGVBQWU7S0FBRTtJQUM3RjtJQUFHLG9CQUFvQixTQUFTLEdBQUc7S0FDakMsSUFBSSxFQUFFLEVBQUUsWUFBWSxTQUFTLFNBQVMsSUFBSTtNQUN4QyxJQUFJLElBQUksRUFBRSxhQUFhLFFBQVE7TUFDL0IsSUFBSSxLQUFLLEVBQUUsU0FBUyxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sVUFBVSxHQUFHLENBQUM7S0FDOUQ7SUFDRjtHQUFFO0dBQUcsVUFBVSxDQUFDO0dBQUcsV0FBVyxXQUFXO0lBQ3ZDLE9BQU87R0FDVDtHQUFHLGlCQUFpQixTQUFTLEdBQUc7SUFDOUIsT0FBTyxFQUFFLE9BQU8sU0FBUyxNQUFNO0dBQ2pDO0VBQUUsR0FBRyxLQUFLO0VBQ1YsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUc7R0FDL0IsSUFBSSxDQUFDLEdBQUcsT0FBTyxDQUFDO0dBQ2hCLElBQUksTUFBTSxDQUFDLEdBQUc7SUFDWixJQUFJLElBQUksRUFBRSxPQUFPLEVBQUUsS0FBSyxJQUFJLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxNQUFNLElBQUksRUFBRSxPQUFPLEVBQUUsTUFBTSxJQUFJLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRTtJQUN6RyxJQUFJLElBQUksS0FBSyxJQUFJLEdBQUcsS0FBSyxLQUFLLE1BQU0sVUFBVSxNQUFNLFVBQVUsSUFBSSxLQUFLLENBQUMsQ0FBQyxHQUFHLElBQUksTUFBTSxNQUFNLFNBQVMsSUFBSSxVQUFVLE1BQU0sWUFBWSxJQUFJLFVBQVUsSUFBSSxNQUFNLE1BQU0sUUFBUSxJQUFJLFdBQVcsTUFBTSxhQUFhLElBQUksU0FBUyxNQUFNLFFBQVE7S0FDdE8sSUFBSSxJQUFJLEtBQUssSUFBSSxFQUFFLE9BQU8sRUFBRTtLQUM1QixPQUFPLEVBQUUsSUFBSSxJQUFJO0lBQ25CO0lBQ0EsSUFBSSxNQUFNLE9BQU87S0FDZixJQUFJLElBQUksS0FBSyxJQUFJLEVBQUUsTUFBTSxFQUFFO0tBQzNCLE9BQU8sRUFBRSxJQUFJLElBQUk7SUFDbkI7SUFDQSxJQUFJLE1BQU0sU0FBUyxPQUFPLEVBQUUsS0FBSyxLQUFLLElBQUksRUFBRSxRQUFRLEVBQUUsUUFBUTtJQUM5RCxJQUFJLE1BQU0sVUFBVSxPQUFPLEVBQUUsS0FBSyxLQUFLLElBQUksRUFBRSxTQUFTLEVBQUUsT0FBTztHQUNqRTtHQUNBLE9BQU8sQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUMsSUFBSSxNQUFNLElBQUksR0FBRyxHQUFHLEdBQUcsQ0FBQztFQUMvRDtFQUNBLFNBQVMsR0FBRyxHQUFHO0dBQ2IsSUFBSSxJQUFJLEVBQUUsUUFBUSxJQUFJLEVBQUU7R0FDeEIsSUFBSSxFQUFFLFNBQVMsU0FBUyxZQUFZLEVBQUUsWUFBWTtJQUNoRCxJQUFJLElBQUk7SUFDUixFQUFFLGFBQWEsUUFBUSxPQUFPLFVBQVUsRUFBRSxlQUFlLE1BQU0sRUFBRSxNQUFNLElBQUksRUFBRSxNQUFNLElBQUksRUFBRSxNQUFNLElBQUksRUFBRSxNQUFNLEdBQUcsRUFBRSxPQUFPLFNBQVMsRUFBRSxPQUFPLEVBQUUsWUFBWSxFQUFFLGVBQWUsTUFBTSxFQUFFLE1BQU0sSUFBSSxJQUFJLEVBQUUsZUFBZSxRQUFRLEVBQUUsTUFBTSxJQUFJO0dBQ3JPO0VBQ0Y7RUFDQSxJQUFJLElBQUksSUFBSSxLQUFLO0dBQUUsSUFBSTtHQUFrQixRQUFRLENBQUMsY0FBYztHQUFHLFNBQVMsU0FBUyxHQUFHO0lBQ3RGLElBQUksSUFBSSxFQUFFLFNBQVMsSUFBSSxFQUFFLFNBQVMsSUFBSSxFQUFFLGNBQWMsSUFBSSxFQUFFO0lBQzVELEdBQUcsVUFBVSxTQUFTLEdBQUc7S0FDdkIsT0FBTyxFQUFFLFFBQVE7TUFBRSxHQUFHO01BQVksR0FBRztNQUFZLElBQUk7TUFBYSxLQUFLO01BQVksTUFBTTtNQUFZLFFBQVE7TUFBWSxPQUFPO01BQVksU0FBUztNQUFhLGFBQWE7TUFBYSxVQUFVO01BQWEsWUFBWTtLQUFZLElBQUk7TUFBRSxHQUFHO01BQWEsR0FBRztNQUFhLElBQUk7TUFBZSxLQUFLO01BQWEsTUFBTTtNQUFhLFFBQVE7TUFBYSxPQUFPO01BQWEsU0FBUztNQUFlLGFBQWE7TUFBZSxVQUFVO01BQWUsWUFBWTtLQUFjO0lBQzNkLEVBQUUsQ0FBQyxHQUFHLEdBQUcsZ0JBQWdCLEVBQUUsaUJBQWlCLEVBQUUsdUJBQXVCLEtBQUssSUFBSSxFQUFFLFVBQVUsWUFBWSxTQUFTLEdBQUc7S0FDaEgsT0FBTyxTQUFTLEdBQUcsR0FBRyxHQUFHO01BQ3ZCLE9BQU8sRUFBRSxPQUFPLENBQUMsS0FBSyxFQUFFLFFBQVEsT0FBTyxVQUFVLEVBQUUsWUFBWSxDQUFDLEdBQUcsRUFBRSxhQUFhLFVBQVUsQ0FBQyxHQUFHLEVBQUUsWUFBWSxVQUFVLENBQUMsR0FBRyxFQUFFLE9BQU8sRUFBRSxJQUFJLEtBQUssZUFBZSxLQUFLLEVBQUUsSUFBSSxJQUFJLEVBQUUsUUFBUSxPQUFPLE9BQU8sRUFBRSxPQUFPLEVBQUUsU0FBUyxTQUFTLEVBQUUsUUFBUSxPQUFPLE9BQU8sRUFBRSxTQUFTLFFBQVEsT0FBTyxPQUFPLEVBQUUsS0FBSyxFQUFFLG1CQUFtQixJQUFJLEVBQUUsUUFBUSxPQUFPLHNCQUFzQixFQUFFLHNCQUFzQixFQUFFLEtBQUssRUFBRSxNQUFNLE1BQU0sRUFBRSxRQUFRLE9BQU8sU0FBUyxFQUFFLFNBQVMsS0FBSyxFQUFFLEtBQUssQ0FBQyxLQUFLLEVBQUUsUUFBUSxPQUFPLFVBQVUsR0FBRyxLQUFLLEVBQUUsUUFBUTtLQUN0ZixFQUFFLE1BQU0sR0FBRyxDQUFDO0lBQ2QsR0FBRyxFQUFFLElBQUksU0FBUyxJQUFJLEVBQUUsV0FBVyxTQUFTLGFBQWEsRUFBRSxRQUFRLFNBQVMsR0FBRztHQUNqRjtHQUFHLFdBQVc7SUFBRSxvQkFBb0IsU0FBUyxHQUFHO0tBQzlDLEVBQUUsWUFBWSxhQUFhO0lBQzdCO0lBQUcsNkJBQTZCLFNBQVMsR0FBRztLQUMxQyxDQUFDLFNBQVMsR0FBRztNQUNYLElBQUksSUFBSSxFQUFFLFFBQVEsSUFBSSxFQUFFO01BQ3hCLElBQUksRUFBRSxTQUFTLFNBQVMsWUFBWSxFQUFFLFNBQVMsT0FBTztPQUNwRCxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUU7T0FDakIsRUFBRSxTQUFTO1FBQUUsT0FBTyxFQUFFLENBQUMsR0FBRyxDQUFDO1FBQUcsV0FBVyxFQUFFLENBQUMsR0FBRyxDQUFDO1FBQUcsVUFBVSxFQUFFLENBQUMsR0FBRyxDQUFDO1FBQUcsT0FBTztTQUFFLE1BQU07U0FBRyxPQUFPO1NBQUcsT0FBTztTQUFHLEtBQUs7U0FBRyxRQUFRO1NBQUcsUUFBUTtRQUFFO09BQUUsR0FBRyxFQUFFLFFBQVEsRUFBRSxTQUFTLE9BQU8sRUFBRSxPQUFPLEVBQUUsT0FBTyxXQUFXLEVBQUUsWUFBWSxFQUFFLE9BQU87TUFDak87S0FDRixFQUFBLENBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQztJQUNiO0lBQUcsNEJBQTRCLFNBQVMsR0FBRztLQUN6QyxDQUFDLFNBQVMsR0FBRztNQUNYLElBQUksSUFBSSxFQUFFLFFBQVEsSUFBSSxFQUFFO01BQ3hCLElBQUksRUFBRSxTQUFTLFNBQVMsWUFBWSxFQUFFLFNBQVMsT0FBTztPQUNwRCxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsYUFBYSxRQUFRLE9BQU8sUUFBUSxJQUFJLE1BQU0sZ0JBQWdCLE1BQU0sVUFBVSxJQUFJLEVBQUUsTUFBTSxJQUFJLEVBQUUsUUFBUSxJQUFJLEVBQUUsT0FBTyxJQUFJLEVBQUUsV0FBVyxJQUFJLEVBQUUsT0FBTyxJQUFJLEVBQUU7T0FDMUssSUFBSSxFQUFFLEdBQUcsQ0FBQyxHQUFHLEdBQ1A7WUFBQSxFQUFFLEdBQUcsQ0FBQyxHQUFHLE1BQU0sY0FBYztTQUMvQixJQUFJLEVBQUUsTUFBTSxFQUFFLFFBQVE7VUFDcEIsSUFBSSxJQUFJLEVBQUU7VUFDVixFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUUsU0FBUztTQUMvQjtTQUNBLElBQUksRUFBRSxPQUFPLEVBQUUsT0FBTztVQUNwQixJQUFJLElBQUksRUFBRTtVQUNWLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxRQUFRO1NBQzlCO1FBQ0Y7Y0FDSyxFQUFFLE1BQU0sS0FBSyxJQUFJLEVBQUUsS0FBSyxFQUFFLE1BQU0sR0FBRyxFQUFFLFNBQVMsS0FBSyxJQUFJLEVBQUUsUUFBUSxFQUFFLEdBQUcsR0FBRyxFQUFFLE9BQU8sS0FBSyxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssR0FBRyxFQUFFLFFBQVEsS0FBSyxJQUFJLEVBQUUsT0FBTyxFQUFFLElBQUk7T0FDdEosS0FBSyxJQUFJLEtBQUssRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLEtBQUssR0FBRyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUU7T0FDMUYsRUFBRSxRQUFRLEVBQUUsU0FBUyxPQUFPLEVBQUUsT0FBTyxHQUFHLEVBQUUsWUFBWTtNQUN4RDtLQUNGLEVBQUEsQ0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFDO0lBQ2I7SUFBRywyQkFBMkIsU0FBUyxHQUFHO0tBQ3hDLElBQUksSUFBSSxFQUFFLFFBQVEsSUFBSSxFQUFFO0tBQ3hCLElBQUksRUFBRSxTQUFTLFNBQVMsWUFBWSxFQUFFLFNBQVMsT0FBTztNQUNwRCxJQUFJLElBQUk7TUFDUixFQUFFLFFBQVEsRUFBRSxTQUFTLE9BQU8sRUFBRSxPQUFPLEVBQUUsT0FBTyxXQUFXLEVBQUUsWUFBWSxFQUFFLE9BQU87S0FDbEY7SUFDRjtJQUFHLG9CQUFvQixTQUFTLEdBQUc7S0FDakMsSUFBSSxJQUFJLEVBQUUsYUFBYSxJQUFJLEVBQUUsY0FBYyxJQUFJLEVBQUUsU0FBUyxJQUFJLEVBQUUsTUFBTSxJQUFJLEVBQUU7S0FDNUUsSUFBSSxHQUFHO01BQ0wsSUFBSSxJQUFJLEVBQUUsQ0FBQyxHQUFHLEVBQUUsT0FBTyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUTtNQUNoRCxJQUFJLEtBQUssRUFBRSxZQUFZLENBQUMsRUFBRSxpQkFBaUIsQ0FBQyxnQkFBZ0IsS0FBSyxFQUFFLFdBQVcsS0FBSyxJQUFJLEVBQUUsZUFBZTtPQUN0RyxJQUFJLEVBQUUsT0FBTyxFQUFFLEtBQUssR0FBRztRQUNyQixJQUFJLElBQUk7U0FBRSxNQUFNLENBQUM7U0FBRyxPQUFPLENBQUM7U0FBRyxLQUFLLENBQUM7U0FBRyxRQUFRLENBQUM7UUFBRTtRQUNuRCxLQUFLLElBQUksS0FBSyxHQUFHLEVBQUUsS0FBSyxHQUFHLEdBQUcsRUFBRSxNQUFNLElBQUksR0FBRyxFQUFFLGVBQWUsYUFBYSxHQUFHLEdBQUcsRUFBRSxVQUFVLEdBQUcsYUFBYTtRQUM3RyxFQUFFLE9BQU8sRUFBRSxRQUFRLENBQUMsRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLE9BQU8sQ0FBQyxFQUFFLFNBQVMsRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxZQUFZLEVBQUUsU0FBUztTQUFFLE1BQU07U0FBVSxPQUFPO1FBQUU7T0FDOUksT0FBTztRQUNMLElBQUksSUFBSSxFQUFFLFNBQVMsT0FBTyxFQUFFLElBQUksRUFBRSxRQUFRLEdBQUcsZUFBZSxJQUFJLEVBQUUsU0FBUyxPQUFPLEVBQUUsSUFBSSxFQUFFLFNBQVMsR0FBRztRQUN0RyxDQUFDLEtBQUssT0FBTyxFQUFFLFNBQVM7U0FBRSxNQUFNO1NBQVUsT0FBTyxJQUFJLE1BQU0sT0FBTyxJQUFJLE1BQU07UUFBSTtPQUNsRjtPQUNBLE9BQU8sQ0FBQyxFQUFFLFVBQVUsS0FBSztNQUMzQjtLQUNGO0lBQ0Y7R0FBRTtHQUFHLFVBQVU7SUFBRSxRQUFRLENBQUM7SUFBRyxxQkFBcUIsQ0FBQztJQUFHLE1BQU07SUFBTSxRQUFRO0lBQUssT0FBTztJQUFNLFFBQVE7R0FBTztHQUFHLFNBQVM7R0FBTSxXQUFXLFNBQVMsR0FBRztJQUNsSixJQUFJLElBQUksRUFBRSxPQUFPLElBQUksRUFBRSxNQUFNLElBQUksRUFBRSxNQUFNLElBQUksR0FBRyxTQUFTLElBQUk7SUFDN0QsSUFBSSxHQUFHLElBQUksRUFBRSxJQUFJO1NBQ1osSUFBSSxHQUFHO0tBQ1YsS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJLEdBQUcsSUFBSTtNQUFDO01BQU87TUFBVTtNQUFRO0tBQU8sR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLO01BQ2pGLElBQUksSUFBSSxFQUFFO01BQ1YsRUFBRSxPQUFPLEtBQUs7S0FDaEI7S0FDQSxJQUFJLEVBQUU7SUFDUjtJQUNBLE9BQU87R0FDVDtHQUFHLGlCQUFpQixTQUFTLEdBQUc7SUFDOUIsT0FBTyxFQUFFLE9BQU8sUUFBUSxNQUFNO0dBQ2hDO0dBQUcsZUFBZTtFQUFLLEdBQUcsS0FBSyxJQUFJLEtBQUs7R0FBRSxJQUFJO0dBQVcsU0FBUyxTQUFTLEdBQUc7SUFDNUUsRUFBRSxVQUFVLEVBQUUsR0FBRyxFQUFFLFVBQVUsRUFBRSxHQUFHLEVBQUUsVUFBVSxFQUFFLEdBQUcsRUFBRSxVQUFVLEVBQUU7R0FDbkU7RUFBRSxHQUFHLEtBQUssR0FBRyxLQUFLO0dBQUUsU0FBUyxTQUFTLEdBQUc7SUFDdkMsT0FBTyxHQUFHLENBQUM7R0FDYjtHQUFHLFFBQVEsU0FBUyxHQUFHO0lBQ3JCLE9BQU8sR0FBRyxDQUFDO0dBQ2I7R0FBRyxNQUFNLFNBQVMsR0FBRztJQUNuQixJQUFJLEtBQUssRUFBRSx1QkFBdUIsS0FBSyxFQUFFLHNCQUFzQixDQUFDLElBQUksS0FBSyxJQUFJLElBQUk7S0FBQztLQUFNO0tBQU87S0FBVTtJQUFHLEdBQUcsSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLEtBQUs7S0FDdkksSUFBSSxJQUFJLEVBQUU7S0FDVixLQUFLLEVBQUUsR0FBRyxPQUFPLEdBQUcsdUJBQXVCLElBQUksS0FBSyxFQUFFLEdBQUcsT0FBTyxHQUFHLHNCQUFzQixNQUFNLEVBQUUsR0FBRyxPQUFPLEdBQUcsNkJBQTZCO0lBQzdJO0lBQ0EsS0FBSyxNQUFNLEdBQUcsS0FBSyxDQUFDLEdBQUcsS0FBSyxNQUFNLEdBQUcsS0FBSyxDQUFDLEdBQUcsT0FBTyxLQUFLLFNBQVMsR0FBRztLQUNwRSxJQUFJLElBQUksS0FBSyxJQUFJLEdBQUcsSUFBSSxLQUFLLElBQUksR0FBRyxNQUFNLElBQUksR0FBRyxHQUFHLElBQUksRUFBRSxXQUFXLFdBQVc7TUFDOUUsRUFBRSxJQUFJLENBQUM7S0FDVCxHQUFHLENBQUM7S0FDSixPQUFPLEtBQUssSUFBSSxHQUFHO0lBQ3JCLEdBQUcsS0FBSyxTQUFTLEdBQUc7S0FDbEIsT0FBTyxhQUFhLENBQUM7SUFDdkI7R0FDRjtFQUFFLEdBQUcsSUFBSTtHQUFFLFVBQVU7SUFBRSxTQUFTLENBQUM7SUFBRyxRQUFRO0lBQUksV0FBVztJQUFNLE9BQU87R0FBSTtHQUFHLEtBQUssS0FBSztHQUFLLGFBQWE7R0FBTSxHQUFHO0dBQUcsR0FBRztHQUFHLEdBQUc7R0FBRyxhQUFhLENBQUM7R0FBRyxVQUFVO0dBQUcsUUFBUTtHQUFHLE9BQU87R0FBRyxPQUFPLFNBQVMsR0FBRztJQUN2TSxFQUFFLGNBQWMsQ0FBQyxHQUFHLEdBQUcsT0FBTyxFQUFFLENBQUMsR0FBRyxFQUFFLGFBQWEsR0FBRyxFQUFFLGNBQWMsR0FBRyxFQUFFLFdBQVcsRUFBRSxJQUFJLEdBQUcsRUFBRSxJQUFJLEdBQUcsUUFBUSxFQUFFLE1BQU07R0FDMUg7R0FBRyxNQUFNLFdBQVc7SUFDbEIsRUFBRSxjQUFjLENBQUMsR0FBRyxFQUFFLGdCQUFnQixFQUFFLFlBQVksYUFBYSxPQUFPLEdBQUcsT0FBTyxFQUFFLENBQUM7R0FDdkY7R0FBRyxRQUFRLFdBQVc7SUFDcEIsSUFBSSxJQUFJLEVBQUUsYUFBYSxJQUFJLEVBQUUsY0FBYyxJQUFJLEVBQUUsU0FBUyxJQUFJLEVBQUUsU0FBUyxNQUFNLElBQUksRUFBRSxRQUFRLEVBQUUsQ0FBQyxZQUFZLElBQUksR0FBRyxFQUFFLFdBQVcsR0FBRyxDQUFDLEdBQUcsSUFBSSxFQUFFLElBQUksR0FBRyxLQUFLLElBQUksRUFBRSxZQUFZLEtBQUssSUFBSSxFQUFFLFFBQVE7SUFDOUwsSUFBSSxLQUFLLEdBQUc7S0FDVixJQUFJLElBQUk7TUFBRSxHQUFHLEVBQUUsSUFBSTtNQUFHLEdBQUcsRUFBRSxJQUFJO0tBQUU7S0FDakMsSUFBSSxFQUFFLEtBQUssRUFBRSxHQUFHO01BQ2QsSUFBSSxJQUFJLEdBQUcsQ0FBQztNQUNaLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxTQUFTLEVBQUUsR0FBRyxFQUFFLENBQUMsSUFBSSxNQUFNLEVBQUUsY0FBYyxFQUFFLEdBQUcsRUFBRSxhQUFhLEVBQUU7TUFDakYsSUFBSSxJQUFJLEdBQUcsQ0FBQyxHQUFHLElBQUk7T0FBRSxHQUFHLEVBQUUsSUFBSSxFQUFFO09BQUcsR0FBRyxFQUFFLElBQUksRUFBRTtNQUFFO01BQ2hELENBQUMsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLEtBQUs7T0FBRSxNQUFNO09BQWMsUUFBUTtPQUFHLGNBQWM7T0FBRyxPQUFPO09BQUcsYUFBYTtPQUFHLFdBQVc7TUFBRSxDQUFDO0tBQ25IO0tBQ0EsRUFBRSxXQUFXO0lBQ2Y7SUFDQSxFQUFFLGdCQUFnQixHQUFHLE9BQU8sRUFBRSxDQUFDLEdBQUcsRUFBRSxJQUFJLEdBQUcsUUFBUSxFQUFFLE1BQU07R0FDN0Q7R0FBRyxPQUFPLFNBQVMsR0FBRyxHQUFHO0lBQ3ZCLElBQUk7SUFDSixRQUFRLElBQUksRUFBRSxRQUFRLEVBQUUsQ0FBQyxlQUFlLE9BQU8sS0FBSyxJQUFJLEVBQUU7R0FDNUQ7R0FBRyxtQkFBbUIsU0FBUyxHQUFHO0lBQ2hDLElBQUksSUFBSSxFQUFFLGFBQWEsSUFBSSxFQUFFO0lBQzdCLElBQUksRUFBRSxZQUFZLEtBQUssRUFBRSxNQUFNLEVBQUUsY0FBYyxFQUFFLFNBQVMsSUFBSSxHQUFHLElBQUksRUFBRSxZQUFZLEVBQUUsSUFBSSxFQUFFLElBQUk7U0FDMUY7S0FDSCxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxFQUFFLGNBQWMsSUFBSSxFQUFFLFNBQVMsSUFBSSxFQUFFLFNBQVMsTUFBTSxJQUFJLEVBQUUsUUFBUSxFQUFFLENBQUMsWUFBWSxJQUFJLEdBQUcsRUFBRSxXQUFXLEdBQUcsQ0FBQztLQUM3SCxJQUFJLEVBQUUsT0FBTyxDQUFDLEdBQUcsSUFBSSxFQUFFLFVBQVUsRUFBRSxRQUFRLElBQUksRUFBRSxVQUFVLEVBQUUsUUFBUSxJQUFJLEVBQUUsVUFBVSxFQUFFLGFBQWEsRUFBRSxRQUFRLElBQUksRUFBRSxVQUFVLEVBQUUsY0FBYyxFQUFFO1VBQzNJO01BQ0gsSUFBSSxJQUFJLEdBQUcsQ0FBQztNQUNaLElBQUksRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLFFBQVEsSUFBSSxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUsUUFBUSxJQUFJLEVBQUUsVUFBVSxFQUFFLFFBQVEsRUFBRSxRQUFRLElBQUksRUFBRSxVQUFVLEVBQUUsU0FBUyxFQUFFO0tBQ3hJO0tBQ0EsRUFBRSxJQUFJLElBQUksSUFBSSxJQUFJLEtBQUssR0FBRyxFQUFFLElBQUksSUFBSSxJQUFJLElBQUksS0FBSyxHQUFHLEVBQUUsZ0JBQWdCLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLE1BQU0sQ0FBQztJQUN6SDtHQUNGO0VBQUU7RUFDRixTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUc7R0FDbkIsUUFBUSxFQUFFLE9BQU8sQ0FBQyxJQUFJLEdBQUcsR0FBRyxHQUFHLENBQUMsSUFBSSxNQUFNLEVBQUUsQ0FBQztFQUMvQztFQUNBLFNBQVMsR0FBRyxHQUFHO0dBQ2IsT0FBTyxFQUFFLE9BQU8sQ0FBQyxNQUFNLElBQUksT0FBTyxTQUFTLE9BQU87SUFBRSxHQUFHLEVBQUU7SUFBWSxHQUFHLEVBQUU7R0FBVTtFQUN0RjtFQUNBLElBV08sS0FBSztHQVhELElBQUk7R0FBZSxTQUFTLFNBQVMsR0FBRztJQUNqRCxJQUFJLElBQUksRUFBRSxVQUFVLElBQUksRUFBRTtJQUMxQixFQUFFLGFBQWEsR0FBRyxFQUFFLE1BQU0sV0FBVztLQUNuQyxPQUFPLEVBQUUsSUFBSTtJQUNmLEdBQUcsRUFBRSxlQUFlLGFBQWEsQ0FBQyxHQUFHLEVBQUUsVUFBVSxhQUFhLEVBQUU7R0FDbEU7R0FBRyxXQUFXO0lBQUUsb0JBQW9CLFNBQVMsR0FBRztLQUM5QyxFQUFFLFlBQVksYUFBYTtJQUM3QjtJQUFHLHdCQUF3QixTQUFTLEdBQUc7S0FDckMsRUFBRSxZQUFZLGFBQWEsTUFBTSxFQUFFLEtBQUssR0FBRyxFQUFFLGdCQUFnQixFQUFFLGNBQWM7SUFDL0U7SUFBRyxxQkFBcUIsRUFBRTtJQUFNLDRCQUE0QixTQUFTLEdBQUc7S0FDdEUsT0FBTyxFQUFFLGtCQUFrQixDQUFDO0lBQzlCO0dBQUU7RUFBVztFQUNiLFNBQVMsR0FBRyxHQUFHLEdBQUc7R0FDaEIsSUFBSSxJQUFJLENBQUM7R0FDVCxPQUFPLFdBQVc7SUFDaEIsT0FBTyxNQUFNLEVBQUUsUUFBUSxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxFQUFFLE1BQU0sTUFBTSxTQUFTO0dBQ2xFO0VBQ0Y7RUFDQSxTQUFTLEdBQUcsR0FBRyxHQUFHO0dBQ2hCLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLE9BQU87RUFDOUQ7RUFDQSxTQUFTLEdBQUcsR0FBRztHQUNiLE9BQU8sRUFBRSxLQUFLLENBQUMsS0FBSyxLQUFLLFFBQVEsY0FBYyxHQUFHLFFBQVEsTUFBTSxRQUFRLE9BQU8sS0FBSyxRQUFRLGFBQWEsUUFBUSxLQUFLLFFBQVE7RUFDaEk7RUFDQSxTQUFTLEdBQUcsR0FBRztHQUNiLE9BQU8sRUFBRSxLQUFLLENBQUMsS0FBSyxLQUFLLFFBQVEsZ0JBQWdCLEdBQUcsUUFBUSxNQUFNLFFBQVEsT0FBTyxLQUFLLFFBQVEsZUFBZSxRQUFRLEtBQUssUUFBUTtFQUNwSTtFQUNBLElBQUksS0FBSztHQUFFLElBQUk7R0FBa0MsU0FBUyxTQUFTLEdBQUc7SUFDcEUsSUFBSSxJQUFJLEVBQUU7SUFDVixFQUFFLFVBQVUsWUFBWSxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUc7S0FDM0MsSUFBSSxJQUFJLFNBQVMsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO01BQzlCLElBQThFLElBQUk7T0FBRSxRQUFRO09BQU0sY0FBYztPQUFHLGFBQWE7T0FBRyxTQUFTO09BQUcsTUFBdkksRUFBRSxRQUFRLENBQW1JO09BQUcsU0FBOUgsRUFBRSxXQUFXO1FBQUUsR0FBRztRQUFHLEdBQUc7UUFBRyxHQUFHO1FBQUcsR0FBRztPQUFHLEVBQUUsRUFBRTtNQUE4RjtNQUNuSyxPQUFPLEVBQUUsS0FBSyxvQkFBb0IsQ0FBQyxHQUFHLEVBQUU7S0FDMUMsRUFBRSxNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUM7S0FDbEIsT0FBTyxLQUFLLFFBQVEsZ0JBQWdCLEtBQUssUUFBUSxjQUFjLEdBQUcsR0FBRyxHQUFHLE1BQU0sR0FBRyxDQUFDLElBQUk7SUFDeEYsR0FBRyxFQUFFLFVBQVUsYUFBYSxHQUFHLFNBQVMsR0FBRztLQUN6QyxPQUFPLEtBQUssa0JBQWtCLGNBQWMsQ0FBQztJQUMvQyxHQUFHLG1HQUFtRyxHQUFHLEVBQUUsVUFBVSxZQUFZLEdBQUcsU0FBUyxHQUFHO0tBQzlJLE9BQU8sS0FBSyxrQkFBa0IsYUFBYSxDQUFDO0lBQzlDLEdBQUcsaUdBQWlHLEdBQUcsRUFBRSxVQUFVLGdCQUFnQixJQUFJLEVBQUUsVUFBVSxjQUFjO0dBQ25LO0VBQUU7RUFDRixTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0dBQ3pCLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxRQUFRLEVBQUUsT0FBTyxHQUFHLENBQUMsS0FBSyxFQUFFLFFBQVEsRUFBRSxLQUFLLENBQUMsV0FBVyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsSUFBSSxJQUFJO0VBQ3pHO0VBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUc7R0FDL0IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxJQUFJLEdBQUcsS0FBSztJQUN4QyxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxVQUFVLEdBQUcsR0FBRyxHQUFHLENBQUM7SUFDbEQsSUFBSSxHQUFHO0tBQ0wsSUFBSSxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDO0tBQ3hCLElBQUksR0FBRyxPQUFPO01BQUUsUUFBUTtNQUFHLGNBQWM7TUFBRyxTQUFTO0tBQUU7SUFDekQ7R0FDRjtHQUNBLE9BQU87SUFBRSxRQUFRO0lBQU0sY0FBYztJQUFNLFNBQVM7R0FBSztFQUMzRDtFQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUc7R0FDekIsSUFBSSxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxJQUFJO0dBQ3hCLFNBQVMsRUFBRSxHQUFHO0lBQ1osRUFBRSxLQUFLLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQztHQUNyQjtHQUNBLE9BQU8sRUFBRSxRQUFRLENBQUMsSUFBSztJQUNyQixJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLGNBQWMsYUFBYSxHQUFHLENBQUM7SUFDakQsSUFBSSxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQztJQUM5QixJQUFJLEVBQUUsVUFBVSxDQUFDLEVBQUUsYUFBYSxRQUFRLEVBQUUsT0FBTyxLQUFLLENBQUMsYUFBYSxPQUFPO0lBQzNFLElBQUksR0FBRyxDQUFDO0dBQ1Y7R0FDQSxPQUFPO0lBQUUsUUFBUTtJQUFNLGNBQWM7SUFBTSxTQUFTO0dBQUs7RUFDM0Q7RUFDQSxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUc7R0FDbkIsSUFBSSxJQUFJLEVBQUUsUUFBUSxJQUFJLEVBQUUsY0FBYyxJQUFJLEVBQUU7R0FDNUMsSUFBSSxLQUFLLEVBQUUsTUFBTSxLQUFLLEdBQUcsRUFBRSxlQUFlLEdBQUcsRUFBRSxVQUFVLEdBQUcsR0FBRyxFQUFFLFVBQVUsQ0FBQyxHQUFHLEVBQUUsT0FBTyxLQUFLLEVBQUUsT0FBTyxFQUFFLFFBQVEsQ0FBQyxJQUFJLE1BQU0sR0FBRyxHQUFHLENBQUMsR0FBRyxFQUFFLEtBQUssc0JBQXNCLEVBQUUsYUFBYSxFQUFFLENBQUM7RUFDdEw7RUFDQSxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRztHQUN0QixJQUFJLElBQUksRUFBRSxTQUFTLElBQUksRUFBRSxFQUFFLEtBQUssQ0FBQyxLQUFLLElBQUksRUFBRSxFQUFFLEtBQUssQ0FBQyxlQUFlLElBQUksRUFBRSxVQUFVLGlCQUFpQixJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUk7R0FDdEgsSUFBSSxFQUFFLEtBQUssS0FBSyxJQUFJLE9BQU8sQ0FBQztHQUM1QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxhQUFhLE1BQU0sSUFBSSxFQUFFLFFBQVEsS0FBSztJQUMxRCxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxTQUFTO0lBQzdCLElBQUksRUFBRSxZQUFZLE1BQU0sRUFBRSxLQUFLLEtBQUssRUFBRSxpQkFBaUIsT0FBTyxLQUFLLE1BQU0sRUFBRSxPQUFPLElBQUksTUFBTSxLQUFLLEVBQUUsWUFBWSxNQUFNLEtBQUssTUFBTSxFQUFFLFFBQVEsS0FBSyxNQUM3SSxPQUFPLENBQUM7R0FDWjtHQUNBLE9BQU8sSUFBSTtFQUNiO0VBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRztHQUNoQixPQUFPLEVBQUUsT0FBTyxDQUFDLEtBQUssRUFBRSxVQUFVLGtCQUFrQixHQUFHLFFBQVEsRUFBRSxVQUFVO0VBQzdFO0VBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHO0dBQ25CLElBQUksSUFBSSxFQUFFLFVBQVU7R0FDcEIsS0FBSyxNQUFNLE1BQU0sRUFBRSxNQUFNLFNBQVMsS0FBSyxFQUFFLGNBQWMsZ0JBQWdCLE1BQU0sU0FBUyxHQUFHLEVBQUUsTUFBTSxTQUFTLEdBQUcsRUFBRSxVQUFVLGdCQUFnQixJQUFJLElBQUk7RUFDbko7RUFDQSxTQUFTLEdBQUcsR0FBRyxHQUFHO0dBQ2hCLElBQUksSUFBSSxFQUFFLGNBQWMsSUFBSSxFQUFFLFNBQVMsSUFBSSxFQUFFO0dBQzdDLElBQUksRUFBRSxnQkFBZ0IsV0FBVyxLQUFLLEVBQUUsUUFBUSxhQUFhO0lBQzNELElBQUksSUFBSTtJQUNSLElBQUksRUFBRSxNQUFNO0tBQ1YsSUFBSSxJQUFJLEVBQUUsUUFBUSxFQUFFLEtBQUssQ0FBQztLQUMxQixJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUksRUFBRSxHQUFHLEdBQUcsR0FBRyxFQUFFLFlBQVksSUFBSSxFQUFFLFFBQVEsSUFBSSxFQUFFLEtBQUssQ0FBQyxVQUFVLENBQUM7SUFDaEY7SUFDQSxHQUFHLEVBQUUsU0FBUyxLQUFLLElBQUksQ0FBQztHQUMxQixPQUFPLEVBQUUsVUFBVSxpQkFBaUIsR0FBRyxFQUFFLFVBQVUsZUFBZSxJQUFJLENBQUM7RUFDekU7RUFDQSxJQXVCNEUsS0FBSztHQXZCdEUsSUFBSTtHQUFtQixRQUFRLENBQUMsU0FBUztHQUFHLFNBQVMsU0FBUyxHQUFHO0lBQzFFLElBQUksSUFBSSxFQUFFLGdCQUFnQixJQUFJLEVBQUU7SUFDaEMsRUFBRSxVQUFVLEVBQUUsR0FBRyxFQUFFLEtBQUssZ0JBQWdCLE1BQU0sRUFBRSxLQUFLLGNBQWMsQ0FBQyxHQUFHLEVBQUUsRUFBRSxXQUFXO0tBQUUsYUFBYSxDQUFDO0tBQUcsS0FBSyxJQUFJO0tBQUcsZUFBZTtLQUFHLFdBQVc7S0FBTSxZQUFZO0tBQU0sY0FBYztJQUFFLENBQUMsR0FBRyxFQUFFLGtCQUFrQixTQUFTLEdBQUc7S0FDNU4sT0FBTyxHQUFHLEdBQUcsQ0FBQztJQUNoQixHQUFHLEVBQUUsWUFBWTtLQUFFLGlCQUFpQixJQUFJO0tBQUcsd0JBQXdCO0tBQUksZUFBZTtJQUFLO0dBQzdGO0dBQUcsV0FBVztJQUFFLHFCQUFxQixTQUFTLEdBQUcsR0FBRztLQUNsRCxJQUFJLElBQUksRUFBRSxhQUFhLElBQUksRUFBRSxTQUFTLElBQUksRUFBRSxPQUFPLElBQUksRUFBRTtLQUN6RCxFQUFFLFlBQVksS0FBSyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQy9DO0lBQUcscUJBQXFCLFNBQVMsR0FBRyxHQUFHO0tBQ3JDLENBQUMsU0FBUyxHQUFHLEdBQUc7TUFDZCxJQUFJLElBQUksRUFBRSxhQUFhLElBQUksRUFBRSxTQUFTLElBQUksRUFBRSxPQUFPLElBQUksRUFBRTtNQUN6RCxFQUFFLGdCQUFnQixXQUFXLEVBQUUsaUJBQWlCLEVBQUUsWUFBWSxLQUFLLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxHQUFHLENBQUM7S0FDL0YsRUFBQSxDQUFHLEdBQUcsQ0FBQyxHQUFHLFNBQVMsR0FBRyxHQUFHO01BQ3ZCLElBQUksSUFBSSxFQUFFO01BQ1YsSUFBSSxFQUFFLGlCQUFpQixDQUFDLEVBQUUsWUFBWSxLQUFLLEVBQUUsbUJBQW1CLEVBQUUsU0FBUyxNQUFNO09BQy9FLEVBQUUsS0FBSywwQkFBMEIsQ0FBQztPQUNsQyxJQUFJLElBQUksRUFBRSxjQUFjLElBQUksRUFBRSxTQUFTO09BQ3ZDLEtBQUssTUFBTSxFQUFFLFFBQVEsRUFBRSxDQUFDLGVBQWUsQ0FBQyxHQUFHLEdBQUcsRUFBRSxTQUFTLEVBQUUsVUFBVSxDQUFDLElBQUksRUFBRSxLQUFLLEtBQUssRUFBRSxNQUFNLEVBQUUsVUFBVSxHQUFHLEVBQUUsT0FBTyxHQUFHLEdBQUcsR0FBRyxDQUFDO01BQ2xJO0tBQ0YsRUFBRSxHQUFHLENBQUM7SUFDUjtJQUFHLHFCQUFxQixTQUFTLEdBQUcsR0FBRztLQUNyQyxJQUFJLElBQUksRUFBRSxhQUFhLElBQUksRUFBRTtLQUM3QixLQUFLLEVBQUUsUUFBUSxlQUFlLEdBQUcsRUFBRSxTQUFTLElBQUksQ0FBQztJQUNuRDtHQUFFO0dBQUcsaUJBQWlCO0dBQUksd0JBQXdCO0dBQUksZ0JBQWdCO0VBQVksR0FBRyxLQUFLO0dBQUUsSUFBSTtHQUF1QixXQUFXLEVBQUUsMEJBQTBCLFNBQVMsR0FBRyxHQUFHO0lBQzNLLElBQUksSUFBSSxFQUFFLGFBQWEsSUFBSSxFQUFFLGFBQWEsSUFBSSxFQUFFLElBQUksSUFBSSxFQUFFO0lBQzFELElBQUksRUFBRSxTQUFTLFNBQVMsUUFBUTtLQUM5QixJQUFJLElBQUksS0FBSyxJQUFJLENBQUMsR0FBRyxJQUFJLEtBQUssSUFBSSxDQUFDLEdBQUcsSUFBSSxFQUFFLGFBQWEsUUFBUSxNQUFNLElBQUksRUFBRSxXQUFXLElBQUksSUFBSSxJQUFJLE1BQU0sSUFBSSxJQUFJLE1BQU07S0FDeEgsSUFBSSxFQUFFLFNBQVMsT0FBTyxFQUFFLGFBQWEsVUFBVSxFQUFFLEtBQUssRUFBRSxVQUFVLE1BQU0sUUFBUSxNQUFNLFFBQVEsTUFBTSxHQUFHO01BQ3JHLEVBQUUsU0FBUyxPQUFPO01BQ2xCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLEdBQUc7T0FDOUIsSUFBSSxNQUFNLEVBQUUsY0FBYztRQUN4QixJQUFJLElBQUksRUFBRSxhQUFhLFFBQVE7UUFDL0IsSUFBSSxDQUFDLEVBQUUsZUFBZSxFQUFFLGdCQUFnQixHQUFHLEdBQUcsQ0FBQyxHQUFHO1NBQ2hELElBQUksSUFBSSxFQUFFLFVBQVUsRUFBRSxhQUFhLEVBQUUsV0FBVyxHQUFHLENBQUM7U0FDcEQsSUFBSSxLQUFLLEVBQUUsU0FBUyxVQUFVLFNBQVMsR0FBRyxHQUFHO1VBQzNDLElBQUksQ0FBQyxHQUFHLE9BQU8sQ0FBQztVQUNoQixJQUFJLElBQUksRUFBRSxRQUFRLEtBQUs7VUFDdkIsT0FBTyxNQUFNLFFBQVEsTUFBTSxRQUFRLE1BQU07U0FDM0MsRUFBRSxHQUFHLENBQUMsS0FBSyxHQUFHLGVBQWUsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQUcsT0FBTztRQUN0RDtPQUNGO01BQ0YsR0FBRyxFQUFFLFFBQVEsQ0FBQyxJQUFLO09BQ2pCLElBQUksSUFBSSxFQUFFLGNBQWMsYUFBYSxHQUFHLENBQUM7T0FDekMsSUFBSSxHQUFHO1FBQ0wsRUFBRSxTQUFTLE9BQU8sUUFBUSxFQUFFLGVBQWUsR0FBRyxFQUFFLFVBQVU7UUFDMUQ7T0FDRjtPQUNBLElBQUksR0FBRyxDQUFDO01BQ1Y7S0FDRjtJQUNGO0dBQ0YsRUFBRTtFQUFFO0VBQ0osU0FBUyxHQUFHLEdBQUc7R0FDYixJQUFJLElBQUksRUFBRSxZQUFZLEVBQUUsU0FBUztHQUNqQyxJQUFJLENBQUMsR0FBRyxPQUFPO0dBQ2YsSUFBSSxJQUFJLEVBQUUsYUFBYTtHQUN2QixPQUFPLEVBQUUsRUFBRSxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUM7RUFDM0I7RUFDQSxJQWdCNEIsS0FBSztHQWhCdEIsSUFBSTtHQUFtQixTQUFTLFNBQVMsR0FBRztJQUNyRCxJQUFJLElBQUksRUFBRTtJQUNWLEVBQUUsVUFBVSxFQUFFLEdBQUcsRUFBRSxVQUFVLE9BQU8sR0FBRyxFQUFFLFVBQVUsUUFBUTtHQUM3RDtHQUFHLFdBQVc7SUFBRSxvQkFBb0IsU0FBUyxHQUFHO0tBQzlDLEVBQUUsWUFBWSxxQkFBcUI7SUFDckM7SUFBRyxzQkFBc0IsU0FBUyxHQUFHO0tBQ25DLElBQUksSUFBSSxFQUFFLGFBQWEsSUFBSSxHQUFHLENBQUM7S0FDL0IsSUFBSSxNQUFNLEVBQUUscUJBQXFCLFdBQVcsV0FBVztNQUNyRCxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsY0FBYyxFQUFFLE9BQU87S0FDL0MsR0FBRyxDQUFDO0lBQ047SUFBRyxxQkFBcUIsU0FBUyxHQUFHO0tBQ2xDLElBQUksSUFBSSxFQUFFLGFBQWEsSUFBSSxFQUFFO0tBQzdCLEVBQUUsc0JBQXNCLEVBQUUsbUJBQW1CLENBQUMsTUFBTSxhQUFhLEVBQUUsa0JBQWtCLEdBQUcsRUFBRSxxQkFBcUI7SUFDakg7SUFBRywwQkFBMEIsU0FBUyxHQUFHO0tBQ3ZDLElBQUksSUFBSSxFQUFFO0tBQ1YsR0FBRyxDQUFDLElBQUksTUFBTSxFQUFFLFNBQVMsT0FBTztJQUNsQztHQUFFO0dBQUcsaUJBQWlCO0VBQVksR0FBRyxLQUFLO0dBQUUsSUFBSTtHQUFjLFNBQVMsU0FBUyxHQUFHO0lBQ2pGLEVBQUUsVUFBVSxFQUFFLEdBQUcsRUFBRSxVQUFVLEVBQUUsR0FBRyxFQUFFLFVBQVUsRUFBRTtHQUNsRDtFQUFFLEdBQUcsS0FBSyxTQUFTLEdBQUc7R0FDcEIsT0FBTyx3QkFBd0IsS0FBSyxDQUFDLEtBQUssS0FBSyxRQUFRLGlCQUFpQixHQUFHLFFBQVEsRUFBRSxLQUFLLENBQUMsS0FBSyxLQUFLLFFBQVEsaUJBQWlCLElBQUksV0FBVyxTQUFTLFFBQVEsS0FBSyxRQUFRO0VBQzdLO0VBQ0EsU0FBUyxHQUFHLEdBQUc7R0FDYixJQUFJLElBQUksRUFBRSxhQUFhLElBQUksRUFBRTtHQUM3QixFQUFFLGdCQUFnQixFQUFFLGFBQWEsdUJBQXVCLENBQUM7RUFDM0Q7RUFDQSxJQUFJLEtBQUs7R0FBRSxJQUFJO0dBQW1DLFNBQVMsU0FBUyxHQUFHO0lBQ3JFLElBQUksSUFBSSxFQUFFO0lBQ1YsRUFBRSxVQUFVLGlCQUFpQixJQUFJLEVBQUUsVUFBVSx5QkFBeUIsU0FBUyxHQUFHO0tBQ2hGLE9BQU8sU0FBUyxHQUFHLEdBQUcsR0FBRztNQUN2QixJQUFJLElBQUksRUFBRSxRQUFRO01BQ2xCLElBQUksTUFBTSxTQUFTLElBQUksTUFBTSxVQUFVO09BQ3JDLElBQUksRUFBRSxPQUFPLG1CQUFtQixzQkFBc0IsS0FBSyxFQUFFLElBQUksR0FBRztRQUNsRSxJQUFJLElBQUksRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDLFVBQVUsSUFBSSxFQUFFLGNBQWMsQ0FBQztRQUNuRCxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsVUFBVSxFQUFFLE9BQU8sWUFBWSxDQUFDLEdBQUc7T0FDbEQ7T0FDQSx1Q0FBdUMsS0FBSyxFQUFFLElBQUksS0FBSyxFQUFFLFFBQVEsRUFBRSxNQUFNLEtBQUssR0FBRyxFQUFFLFFBQVEsdUVBQXVFLEtBQUssRUFBRSxlQUFlO01BQzFMLE9BQU8sRUFBRSxlQUFlO0tBQzFCLEVBQUUsTUFBTSxHQUFHLENBQUM7SUFDZCxHQUFHLEVBQUUsYUFBYSxVQUFVLEtBQUs7S0FBRSxNQUFNO0tBQWEsVUFBVSxTQUFTLEdBQUc7TUFDMUUsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsYUFBYSxNQUFNLElBQUksRUFBRSxRQUFRLEtBQUs7T0FDMUQsSUFBSSxJQUFJLEVBQUU7T0FDVixJQUFJLEVBQUUsWUFBWSxFQUFFLFlBQVksRUFBRSxVQUFVLEdBQUcsRUFBRSxTQUFTLEVBQUUsTUFBTSxJQUFJLE9BQU8sS0FBSyxFQUFFLGFBQWEsdUJBQXVCLENBQUM7TUFDM0g7S0FDRjtJQUFFLENBQUM7R0FDTDtHQUFHLFdBQVc7SUFBQztJQUFRO0lBQVE7SUFBTTtHQUFRLENBQUMsQ0FBQyxPQUFPLFNBQVMsR0FBRyxHQUFHO0lBQ25FLE9BQU8sRUFBRSxnQkFBZ0IsT0FBTyxDQUFDLEtBQUssSUFBSTtHQUM1QyxHQUFHLENBQUMsQ0FBQztFQUFFO0VBQ1AsU0FBUyxHQUFHLEdBQUcsR0FBRztHQUNoQixJQUFJLEVBQUUsZUFBZSxJQUFJLE9BQU8sQ0FBQztHQUNqQyxLQUFLLElBQUksS0FBSyxFQUFFLEtBQUssSUFBSSxFQUFFLFFBQVEsQ0FBQyxNQUFNLEtBQUssRUFBRSxPQUFPLEVBQUUsTUFBTSxLQUFLLEVBQUUsUUFBUSxPQUFPLENBQUM7R0FDdkYsT0FBTyxDQUFDO0VBQ1Y7RUFDQSxTQUFTLEdBQUcsR0FBRztHQUNiLElBQUksSUFBSSxDQUFDO0dBQ1QsS0FBSyxJQUFJLEtBQUssR0FBRztJQUNmLElBQUksSUFBSSxFQUFFO0lBQ1YsRUFBRSxZQUFZLENBQUMsSUFBSSxFQUFFLEtBQUssR0FBRyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsSUFBSSxFQUFFLEtBQUssR0FBRyxDQUFDLElBQUksRUFBRSxLQUFLO0dBQ3ZFO0dBQ0EsT0FBTztFQUNUO0VBQ0EsSUFBSSxLQUFLLFdBQVc7R0FDbEIsU0FBUyxFQUFFLEdBQUc7SUFDWixFQUFFLE1BQU0sQ0FBQyxHQUFHLEtBQUssU0FBUyxDQUFDLEdBQUcsS0FBSyxjQUFjO0tBQUUsTUFBTTtLQUFHLE9BQU87S0FBRyxLQUFLO0tBQUcsUUFBUTtJQUFFLEdBQUcsS0FBSyxhQUFhLEtBQUssR0FBRyxLQUFLLFNBQVMsS0FBSyxHQUFHLEtBQUssWUFBWSxLQUFLLEdBQUcsS0FBSyxhQUFhLEtBQUssR0FBRyxLQUFLLFFBQVEsS0FBSyxHQUFHLEtBQUssY0FBYyxLQUFLLEdBQUcsS0FBSyxjQUFjLEdBQUcsS0FBSyxTQUFTLEdBQUcsR0FBRyxLQUFLLFFBQVE7S0FBRSxNQUFNLENBQUM7S0FBRyxPQUFPLENBQUM7S0FBRyxLQUFLLENBQUM7S0FBRyxRQUFRLENBQUM7SUFBRTtHQUNsVjtHQUNBLE9BQU8sRUFBRSxHQUFHO0lBQUM7S0FBRSxLQUFLO0tBQVMsT0FBTyxTQUFTLEdBQUcsR0FBRztNQUNqRCxJQUFJLEdBQUcsR0FBRyxJQUFJLEVBQUUsT0FBTyxJQUFJLEtBQUssYUFBYSxJQUFJLFNBQVMsR0FBRztPQUMzRCxJQUFJLElBQUksRUFBRSxhQUFhLFFBQVEsRUFBRSxTQUFTLE9BQU8sSUFBSSxFQUFFO09BQ3ZELE9BQU8sS0FBSyxFQUFFLFNBQVMsSUFBSTtRQUFDO1FBQVE7UUFBWTtRQUFhO1FBQVk7UUFBaUI7T0FBYyxDQUFDLENBQUMsSUFBSSxTQUFTLEdBQUc7UUFDeEgsSUFBSSxJQUFJLEVBQUU7UUFDVixPQUFPLEtBQUssRUFBRSxXQUFXO1NBQUUsU0FBUztTQUFHLFNBQVMsRUFBRTtRQUFTO09BQzdELENBQUMsQ0FBQyxDQUFDLE9BQU8sU0FBUyxHQUFHO1FBQ3BCLE9BQU8sQ0FBQyxDQUFDO09BQ1gsQ0FBQztNQUNILEVBQUUsQ0FBQztNQUNILEtBQUssY0FBYyxDQUFDLEdBQUcsS0FBSyxhQUFhLEVBQUUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxHQUFHLEtBQUssUUFBUSxFQUFFLENBQUMsR0FBRyxLQUFLLFVBQVUsR0FBRyxLQUFLLGVBQWUsSUFBSSxFQUFFLE1BQU0sSUFBSSxHQUFHLElBQUk7T0FBRSxNQUFNLEVBQUUsSUFBSSxFQUFFO09BQU0sS0FBSyxFQUFFLElBQUksRUFBRTtPQUFLLE9BQU8sRUFBRSxRQUFRLEVBQUU7T0FBRyxRQUFRLEVBQUUsU0FBUyxFQUFFO01BQUUsSUFBSTtPQUFFLE1BQU07T0FBRyxLQUFLO09BQUcsT0FBTztPQUFHLFFBQVE7TUFBRSxJQUFJLEtBQUssYUFBYTtPQUFFLEdBQUc7T0FBRyxHQUFHO01BQUU7TUFDNVMsSUFBSSxJQUFJLEtBQUssUUFBUTtPQUFFLE9BQU87T0FBRyxZQUFZO09BQUcsUUFBUSxDQUFDO01BQUUsQ0FBQztNQUM1RCxPQUFPLEtBQUssU0FBUyxHQUFHLEdBQUcsS0FBSyxTQUFTLENBQUMsR0FBRyxLQUFLLFNBQVMsS0FBSyxPQUFPLENBQUM7S0FDMUU7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFXLE9BQU8sU0FBUyxHQUFHO01BQ3hDLElBQUksSUFBSSxLQUFLO01BQ2IsT0FBTyxFQUFFLGNBQWMsR0FBRyxFQUFFLGVBQWUsRUFBRSxjQUFjLEVBQUUsVUFBVSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxVQUFVLEVBQUUsUUFBUSxLQUFLLGFBQWEsRUFBRSxjQUFjLEtBQUssYUFBYTtLQUMzTDtJQUFFO0lBQUc7S0FBRSxLQUFLO0tBQVksT0FBTyxTQUFTLEdBQUc7TUFDekMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxJQUFJLEVBQUUsUUFBUSxLQUFLO09BQ2xELElBQUksSUFBSSxFQUFFO09BQ1YsRUFBRSxRQUFRLFVBQVUsRUFBRSxRQUFRLEdBQUcsRUFBRSxRQUFRLE1BQU0sQ0FBQztNQUNwRDtLQUNGO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBVSxPQUFPLFNBQVMsR0FBRztNQUN2QyxJQUFJLElBQUksRUFBRSxPQUFPLElBQUksRUFBRSxRQUFRLElBQUksRUFBRSxlQUFlLElBQUksRUFBRSxNQUFNLElBQUksRUFBRTtNQUN0RSxFQUFFLFNBQVMsRUFBRSxDQUFDLEdBQUcsRUFBRSxVQUFVLEdBQUcsRUFBRSxPQUFPLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLFFBQVEsRUFBRSxDQUFDLEdBQUcsQ0FBQztNQUNwRSxLQUFLLElBQUksSUFBSSxJQUFJLEtBQUssT0FBTyxNQUFNLENBQUMsSUFBSSxLQUFLLFFBQVEsSUFBSSxHQUFHLEVBQUUsUUFBUSxFQUFFLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FBSztPQUN2RyxJQUFJLEdBQUcsSUFBSSxFQUFFLElBQUksSUFBSSxFQUFFLFNBQVMsSUFBSSxFQUFFLENBQUMsR0FBRyxFQUFFLE1BQU0sR0FBRyxJQUFJO09BQ3pELENBQUMsSUFBSSxFQUFFLFlBQVksUUFBUSxFQUFFLE9BQU8sS0FBSyxTQUFTLEdBQUcsR0FBRyxDQUFDLE1BQU0sRUFBRSxRQUFRLEdBQUcsSUFBSSxFQUFFLFFBQVEsSUFBSSxDQUFDLEdBQUcsR0FBRyxFQUFFLE9BQU8sRUFBRSxNQUFNO1FBQUUsR0FBRyxFQUFFLE9BQU8sSUFBSSxFQUFFO1FBQUcsR0FBRyxFQUFFLE9BQU8sSUFBSSxFQUFFO09BQUUsQ0FBQyxJQUFJLEVBQUUsV0FBVyxLQUFLLENBQUM7TUFDM0w7TUFDQSxFQUFFLEtBQUssT0FBTyxFQUFFLEtBQUssR0FBRyxFQUFFLE1BQU0sSUFBSSxFQUFFLE9BQU8sSUFBSSxFQUFFLFdBQVcsR0FBRyxFQUFFLE1BQU0sSUFBSSxFQUFFLE9BQU8sSUFBSSxFQUFFLFdBQVcsR0FBRyxFQUFFLFVBQVUsT0FBTyxFQUFFLEtBQUssT0FBTyxFQUFFLE1BQU0sRUFBRSxVQUFVLFFBQVEsRUFBRSxLQUFLLFFBQVEsRUFBRSxPQUFPLEVBQUUsVUFBVSxNQUFNLEVBQUUsS0FBSyxNQUFNLEVBQUUsS0FBSyxFQUFFLFVBQVUsU0FBUyxFQUFFLEtBQUssU0FBUyxFQUFFO01BQzVRLElBQUksSUFBSSxLQUFLLE9BQU8sUUFBUSxJQUFJLEtBQUssT0FBTztNQUM1QyxJQUFJLEtBQUssR0FFUCxFQUFFLFVBRE0sRUFBRSxLQUFLLFNBQVMsRUFBRSxRQUFRLEVBQUUsS0FBSyxVQUFVLEVBQUUsU0FBUyxFQUFFLEtBQUssUUFBUSxFQUFFLE9BQU8sRUFBRSxLQUFLLFdBQVcsRUFBRSxVQUN6RixFQUFFLE1BQU0sRUFBRSxPQUFPLEtBQUssRUFBRSxNQUFNLEVBQUUsT0FBTztNQUUxRCxPQUFPO0tBQ1Q7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFzQixPQUFPLFNBQVMsR0FBRztNQUNuRCxJQUFJLElBQUksS0FBSyxhQUFhLElBQUksRUFBRSxPQUFPLElBQUksRUFBRSxPQUFPLEtBQUssSUFBSSxFQUFFLE9BQU8sT0FBTyxJQUFJLEtBQUssUUFBUSxJQUFJLEtBQUssWUFBWSxJQUFJLEVBQUU7TUFDekgsTUFBTSxXQUFXLEVBQUUsS0FBSyxZQUFZLEVBQUUsS0FBSztNQUMzQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLO09BQ3ZELElBQUksSUFBSSxFQUFFLElBQUksSUFBSSxFQUFFLElBQUksSUFBSSxFQUFFO09BQzlCLEVBQUUsS0FBSyxLQUFLLEVBQUUsR0FBRyxFQUFFLEtBQUssS0FBSyxFQUFFLEdBQUcsRUFBRSxPQUFPLEtBQUssRUFBRSxHQUFHLEVBQUUsT0FBTyxLQUFLLEVBQUU7TUFDdkU7TUFDQSxJQUFJLElBQUksS0FBSyxPQUFPLFdBQVcsSUFBSSxFQUFFLFFBQVEsRUFBRTtNQUMvQyxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRTtLQUNsSTtJQUFFO0lBQUc7S0FBRSxLQUFLO0tBQWUsT0FBTyxTQUFTLEdBQUc7TUFDNUMsSUFBSSxJQUFJLEtBQUssYUFBYSxJQUFJLEVBQUUsT0FBTyxJQUFJLEVBQUUsUUFBUSxJQUFJLEVBQUUsZUFBZSxJQUFJLEtBQUssT0FBTyxLQUFLLFFBQVE7T0FBRSxRQUFRO09BQUcsT0FBTztPQUFHLFlBQVksRUFBRSxrQkFBa0IsRUFBRSxPQUFPLElBQUk7TUFBSyxDQUFDLENBQUM7TUFDbEwsSUFBSSxLQUFLLFNBQVMsR0FBRyxDQUFDLEVBQUUsWUFBWSxDQUFDLEtBQUssSUFBSSxLQUFLLE9BQU8sV0FBVyxFQUFFLFlBQVksR0FBRyxPQUFPLENBQUM7TUFDOUYsSUFBSSxFQUFFLGdCQUFnQjtPQUNwQixJQUFJLElBQUksRUFBRSxPQUFPLElBQUksTUFBTSxJQUFJO1FBQUUsR0FBRyxFQUFFLGVBQWUsSUFBSSxFQUFFO1FBQUcsR0FBRyxFQUFFLGVBQWUsSUFBSSxFQUFFO09BQUU7T0FDMUYsRUFBRSxPQUFPLEtBQUssRUFBRSxHQUFHLEVBQUUsT0FBTyxLQUFLLEVBQUUsR0FBRyxFQUFFLE1BQU0sS0FBSyxFQUFFLEdBQUcsRUFBRSxNQUFNLEtBQUssRUFBRTtNQUN6RTtNQUNBLEtBQUssbUJBQW1CLENBQUM7S0FDM0I7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFhLE9BQU8sU0FBUyxHQUFHO01BQzFDLElBQUksSUFBSSxFQUFFLGFBQWEsSUFBSSxFQUFFLE9BQU8sSUFBSSxLQUFLO01BQzdDLElBQUksS0FBSyxFQUFFLFFBQVE7T0FDakIsS0FBSyxJQUFJLElBQUksQ0FBQyxHQUFHLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLO1FBQ3pDLElBQUksSUFBSSxFQUFFO1FBQ1YsRUFBRSxRQUFRO1FBQ1YsSUFBSSxJQUFJLEVBQUUsU0FBUyxJQUFJLEVBQUUsU0FBUyxJQUFJLEVBQUUsYUFBYSxFQUFFLFVBQVUsQ0FBQztRQUNsRSxJQUFJLEdBQUcsT0FBTyxLQUFLLFlBQVksR0FBRyxDQUFDO1FBQ25DLElBQUksS0FBSyxDQUFDLEtBQUssS0FBSyxTQUFTLEdBQUcsQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLENBQUM7T0FDakQ7T0FDQSxLQUFLLEVBQUUsS0FBSztRQUFFLE9BQU87UUFBRyxRQUFRLENBQUM7T0FBRSxDQUFDO01BQ3RDO0tBQ0Y7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFRLE9BQU8sU0FBUyxHQUFHO01BQ3JDLElBQUksSUFBSSxFQUFFO01BQ1YsSUFBSSxLQUFLLFVBQVUsS0FBSyxPQUFPLFFBQVE7T0FDckMsSUFBSSxJQUFJLEVBQUU7UUFBRSxRQUFRLEtBQUs7UUFBUSxjQUFjLEVBQUU7UUFBYyxTQUFTLEVBQUU7UUFBUyxNQUFNO09BQUssR0FBRyxDQUFDO09BQ2xHLEtBQUssUUFBUSxDQUFDO09BQ2QsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxJQUFJLEVBQUUsUUFBUSxLQUFLO1FBQ2xELElBQUksSUFBSSxFQUFFO1FBQ1YsRUFBRSxRQUFRLEdBQUcsRUFBRSxRQUFRLFFBQVEsRUFBRSxRQUFRLEtBQUssQ0FBQztPQUNqRDtPQUNBLEtBQUssU0FBUyxNQUFNLEtBQUssWUFBWTtNQUN2QztLQUNGO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBaUIsT0FBTyxTQUFTLEdBQUc7TUFDOUMsS0FBSyxTQUFTLENBQUM7TUFDZixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLEtBQUs7T0FDakMsSUFBSSxJQUFJLEVBQUUsSUFBSSxJQUFJLEVBQUUsU0FBUyxJQUFJLEVBQUUsU0FBUyxJQUFJLEVBQUU7T0FDbEQsS0FBSyxPQUFPLEtBQUs7UUFBRSxTQUFTO1FBQUcsU0FBUztRQUFHLE9BQU87UUFBRyxNQUFNO09BQUUsQ0FBQztNQUNoRTtNQUNBLE9BQU8sS0FBSztLQUNkO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBNEIsT0FBTyxTQUFTLEdBQUc7TUFDekQsSUFBSSxJQUFJLEVBQUUsYUFBYSxJQUFJLEVBQUUsUUFBUSxJQUFJLEVBQUUsTUFBTSxJQUFJLEVBQUU7TUFDdkQsSUFBSSxFQUFFLFFBQVE7T0FDWixLQUFLLElBQUksSUFBSSxFQUFFLFlBQVksSUFBSSxFQUFFLFFBQVEsSUFBSSxFQUFFLE9BQU8sSUFBSSxFQUFFLFdBQVcsSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FBSztRQUMvSCxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksRUFBRTtRQUM5QixFQUFFLEtBQUssS0FBSyxFQUFFLEdBQUcsRUFBRSxLQUFLLEtBQUssRUFBRSxHQUFHLEVBQUUsT0FBTyxLQUFLLEVBQUUsR0FBRyxFQUFFLE9BQU8sS0FBSyxFQUFFO09BQ3ZFO09BQ0EsRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUU7TUFDdEU7S0FDRjtJQUFFO0lBQUc7S0FBRSxLQUFLO0tBQVksT0FBTyxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUc7TUFDbEQsT0FBTyxFQUFFLENBQUMsS0FBSyxFQUFFLFlBQVksQ0FBQyxLQUFLLEtBQUssQ0FBQyxFQUFFLFdBQVcsRUFBRSxXQUFXLENBQUMsS0FBSyxNQUFNLFdBQVcsQ0FBQyxFQUFFO0tBQy9GO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBWSxPQUFPLFNBQVMsR0FBRztNQUN6QyxLQUFLLGNBQWMsRUFBRSxhQUFhLEtBQUssYUFBYSxFQUFFLFlBQVksS0FBSyxhQUFhLEVBQUUsWUFBWSxLQUFLLFFBQVEsRUFBRSxPQUFPLEtBQUssU0FBUyxFQUFFLE9BQU8sSUFBSSxTQUFTLEdBQUc7T0FDN0osT0FBTyxHQUFHLENBQUM7TUFDYixDQUFDLEdBQUcsS0FBSyxTQUFTLEdBQUcsRUFBRSxDQUFDLEdBQUcsRUFBRSxPQUFPLE1BQU0sR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFLE9BQU8sSUFBSSxDQUFDO0tBQ25FO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBVyxPQUFPLFdBQVc7TUFDdkMsS0FBSyxJQUFJLEtBQUssTUFBTSxLQUFLLEtBQUs7S0FDaEM7SUFBRTtHQUFDLENBQUMsR0FBRztFQUNULEVBQUU7RUFDRixTQUFTLEdBQUcsR0FBRyxHQUFHO0dBQ2hCLE9BQU87SUFBRSxNQUFNO0lBQUcsUUFBUTtJQUFHLE9BQU87S0FBRSxHQUFHO0tBQUcsR0FBRztJQUFFO0lBQUcsV0FBVztLQUFFLE1BQU07S0FBRyxPQUFPO0tBQUcsS0FBSztLQUFHLFFBQVE7SUFBRTtJQUFHLFlBQVksQ0FBQztJQUFHLFNBQVMsQ0FBQztHQUFFO0VBQ3ZJO0VBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRztHQUNoQixJQUFJLElBQUksRUFBRSxVQUFVLElBQUk7SUFBRSxPQUFPLEVBQUU7SUFBTyxLQUFLLEVBQUU7SUFBSyxXQUFXLEVBQUU7SUFBVyxNQUFNLEVBQUU7R0FBSyxHQUFHLElBQUksU0FBUyxHQUFHO0lBQzVHLElBQUksSUFBSSxLQUFLLENBQUM7SUFDZCxLQUFLLElBQUksS0FBSyxFQUFFLFVBQVUsRUFBRSxZQUFZLENBQUMsR0FBRyxHQUFHLEtBQUssTUFBTSxFQUFFLEtBQUssRUFBRTtJQUNuRSxJQUFJLElBQUk7S0FBRSxTQUFTO0tBQUcsU0FBUztLQUFHLE1BQU07S0FBRyxRQUFRLFdBQVc7TUFDNUQsT0FBTyxFQUFFLFVBQVUsQ0FBQyxHQUFHO0tBQ3pCO0tBQUcsU0FBUyxXQUFXO01BQ3JCLE9BQU8sRUFBRSxVQUFVLENBQUMsR0FBRztLQUN6QjtJQUFFO0lBQ0YsT0FBTztHQUNUO0dBQ0EsT0FBTyxLQUFLLE9BQU8sS0FBSyxhQUFhLEVBQUUsWUFBWSxHQUFHLEVBQUUsV0FBVyxJQUFJO0VBQ3pFO0VBQ0EsU0FBUyxHQUFHLEdBQUc7R0FDYixJQUFJLElBQUksRUFBRSxRQUFRLElBQUksRUFBRSxZQUFZLGFBQWE7R0FDakQsTUFBTSxFQUFFLFlBQVksRUFBRTtFQUN4QjtFQUNBLElBb0JPLEtBQUs7R0FwQkQsSUFBSTtHQUFrQixRQUFRLENBQUMsU0FBUztHQUFHLFNBQVMsU0FBUyxHQUFHO0lBQ3pFLEVBQUUsU0FBUyxVQUFVLFlBQVksQ0FBQztHQUNwQztHQUFHLFdBQVc7SUFBRSxvQkFBb0IsU0FBUyxHQUFHO0tBQzlDLElBQUksSUFBSSxFQUFFO0tBQ1YsRUFBRSxlQUFlLElBQUksR0FBRyxDQUFDO0lBQzNCO0lBQUcsb0NBQW9DLFNBQVMsR0FBRztLQUNqRCxJQUFJLElBQUksRUFBRSxhQUFhLElBQUksRUFBRSxZQUFZO0tBQ3pDLEVBQUUsTUFBTSxHQUFHLEVBQUUsT0FBTyxNQUFNLElBQUksR0FBRyxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUUsbUJBQW1CLENBQUM7SUFDNUU7SUFBRyxtQ0FBbUMsU0FBUyxHQUFHO0tBQ2hELElBQUksSUFBSSxFQUFFLGFBQWEsSUFBSSxFQUFFLGNBQWMsSUFBSSxFQUFFLFlBQVksQ0FBQztLQUM5RCxPQUFPLEVBQUUsUUFBUSxFQUFFLE9BQU87SUFDNUI7SUFBRyxrQ0FBa0MsU0FBUyxHQUFHO0tBQy9DLElBQUksSUFBSSxFQUFFLGFBQWEsSUFBSSxFQUFFLGNBQWMsSUFBSSxFQUFFLFVBQVUsQ0FBQztLQUM1RCxPQUFPLEVBQUUsUUFBUSxFQUFFLFlBQVk7SUFDakM7SUFBRyw2QkFBNkI7SUFBSSw0QkFBNEI7SUFBSSwyQkFBMkI7SUFBSSxtQ0FBbUMsU0FBUyxHQUFHO0tBQ2hKLE9BQU8sRUFBRSxZQUFZLGFBQWEseUJBQXlCLENBQUM7SUFDOUQ7SUFBRyxrQ0FBa0MsU0FBUyxHQUFHO0tBQy9DLE9BQU8sRUFBRSxZQUFZLGFBQWEseUJBQXlCLENBQUM7SUFDOUQ7SUFBRyxxQkFBcUIsU0FBUyxHQUFHO0tBQ2xDLE9BQU8sRUFBRSxZQUFZLGFBQWEsS0FBSyxDQUFDO0lBQzFDO0dBQUU7RUFBVyxHQUFHLEtBQUs7R0FBRSxNQUFNO0lBQUUsZ0JBQWdCO0lBQVEsYUFBYTtHQUFPO0dBQUcsV0FBVztJQUFFLFNBQVMsQ0FBQztJQUFHLFFBQVE7S0FBRSxHQUFHO0tBQUcsR0FBRztJQUFFO0dBQUU7R0FBRyxTQUFTLENBQUM7RUFBRSxHQUFHLEtBQUssU0FBUyxHQUFHO0dBQ2hLLEVBQUUsR0FBRyxDQUFDO0dBQ04sSUFBSSxJQUFJLEVBQUUsQ0FBQztHQUNYLFNBQVMsRUFBRSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0lBQzlCLElBQUk7SUFDSixFQUFFLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLEtBQUssTUFBTSxDQUFDLEVBQUEsQ0FBRyxnQkFBZ0IsTUFBTSxFQUFFLFVBQVUsS0FBSyxHQUFHLEVBQUUsVUFBVSxLQUFLLEdBQUcsRUFBRSxTQUFTLEtBQUssR0FBRyxFQUFFLFVBQVUsS0FBSyxHQUFHLEVBQUUsVUFBVSxLQUFLLEdBQUcsRUFBRSxXQUFXLEtBQUssR0FBRyxFQUFFLFNBQVMsS0FBSyxHQUFHLEVBQUUsVUFBVSxLQUFLLEdBQUcsRUFBRSxPQUFPLEtBQUssR0FBRyxFQUFFLFNBQVMsS0FBSyxHQUFHLEVBQUUsUUFBUSxLQUFLLEdBQUcsRUFBRSxPQUFPLEtBQUssR0FBRyxFQUFFLEtBQUssS0FBSyxHQUFHLEVBQUUsS0FBSyxLQUFLLEdBQUcsRUFBRSxLQUFLLEtBQUssR0FBRyxFQUFFLEtBQUssS0FBSyxHQUFHLEVBQUUsV0FBVyxLQUFLLEdBQUcsRUFBRSxXQUFXLEtBQUssR0FBRyxFQUFFLFdBQVcsS0FBSyxHQUFHLEVBQUUsV0FBVyxLQUFLLEdBQUcsRUFBRSxRQUFRLEtBQUssR0FBRyxFQUFFLFFBQVEsS0FBSyxHQUFHLEVBQUUsT0FBTyxLQUFLLEdBQUcsRUFBRSxTQUFTLEtBQUssR0FBRyxJQUFJLEtBQUssRUFBRTtJQUNqZ0IsSUFBSSxJQUFJLEVBQUUsY0FBYyxLQUFLLEtBQUssRUFBRSxXQUFXLEdBQUEsQ0FBSSxhQUFhLElBQUksR0FBRyxHQUFHLEdBQUcsQ0FBQyxHQUFHLElBQUksTUFBTSxTQUFTLElBQUksTUFBTSxPQUFPLElBQUksSUFBSSxFQUFFLENBQUMsSUFBSSxFQUFFLFdBQVcsSUFBSSxJQUFJLEVBQUUsT0FBTyxRQUFRLElBQUk7S0FBRSxNQUFNLEVBQUU7S0FBTSxRQUFRLEVBQUU7S0FBUSxXQUFXLEVBQUUsT0FBTyxJQUFJO0lBQVUsSUFBSSxFQUFFLE9BQU87SUFDL1AsT0FBTyxFQUFFLE9BQU8sRUFBRSxDQUFDLEdBQUcsRUFBRSxJQUFJLEdBQUcsRUFBRSxTQUFTLEVBQUUsQ0FBQyxHQUFHLEVBQUUsTUFBTSxHQUFHLEVBQUUsT0FBTyxFQUFFLENBQUMsR0FBRyxFQUFFLElBQUksR0FBRyxFQUFFLFlBQVksRUFBRSxXQUFXLE1BQU0sRUFBRSxLQUFLLEtBQUssRUFBRSxHQUFHLEVBQUUsS0FBSyxLQUFLLEVBQUUsR0FBRyxFQUFFLE9BQU8sS0FBSyxFQUFFLEdBQUcsRUFBRSxPQUFPLEtBQUssRUFBRSxJQUFJLEVBQUUsVUFBVSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLFdBQVcsRUFBRSxVQUFVLEVBQUUsVUFBVSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUUsU0FBUyxHQUFHLEVBQUUsZ0JBQWdCLEdBQUcsRUFBRSxTQUFTLEdBQUcsRUFBRSxPQUFPLEtBQUssS0FBSyxLQUFLLEtBQUssRUFBRSxlQUFlLEdBQUcsRUFBRSxLQUFLLElBQUksRUFBRSxTQUFTLEVBQUUsU0FBUyxTQUFTLEVBQUUsQ0FBQyxXQUFXLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxPQUFPLE1BQU0sS0FBSyxJQUFJLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxPQUFPLE1BQU0sS0FBSyxJQUFJLEVBQUUsR0FBRyxFQUFFLFdBQVcsRUFBRSxPQUFPLE1BQU0sT0FBTyxJQUFJLEVBQUUsR0FBRyxFQUFFLFdBQVcsRUFBRSxPQUFPLE1BQU0sT0FBTyxJQUFJLEVBQUUsR0FBRyxFQUFFLFFBQVEsS0FBSyxJQUFJO0tBQUUsR0FBRztLQUFHLEdBQUc7SUFBRSxJQUFJO0tBQUUsR0FBRyxFQUFFLEVBQUUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDO0tBQUcsR0FBRyxFQUFFLEVBQUUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDO0lBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxPQUFPLE1BQU0sV0FBVyxFQUFFLFdBQVcsRUFBRSxZQUFZLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxDQUFDLEdBQUcsRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLEVBQUUsUUFBUSxHQUFHLEVBQUUsU0FBUyxHQUFHLEVBQUUsU0FBUyxDQUFDLEdBQUcsRUFBRSxRQUFRLEtBQUssTUFBTSxpQkFBaUIsRUFBRSxTQUFTLElBQUksTUFBTTtHQUN4NkI7R0FDQSxPQUFPLEVBQUUsR0FBRztJQUFDO0tBQUUsS0FBSztLQUFZLE9BQU8sV0FBVztNQUNoRCxJQUFJLElBQUksS0FBSztNQUNiLElBQUksRUFBRSxVQUFVLFFBQVEsT0FBTyxLQUFLLFlBQVksRUFBRSxVQUFVLFlBQVksS0FBSyxPQUFPO01BQ3BGLElBQUksSUFBSSxNQUFNLEtBQUssTUFBTSxFQUFFLFVBQVUsV0FBVyxFQUFFLFVBQVUsU0FBUyxJQUFJLEtBQUs7TUFDOUUsSUFBSSxNQUFNLEtBQUs7TUFDZixJQUFJLElBQUksU0FBUyxLQUFLLElBQUksT0FBTyxJQUFJLFNBQVMsS0FBSyxJQUFJO01BQ3ZELE9BQU87T0FBRSxJQUFJO09BQUcsTUFBTSxDQUFDLEtBQUssUUFBUSxLQUFLLElBQUk7T0FBTyxNQUFNO09BQUcsT0FBTyxDQUFDLE1BQU0sU0FBUyxLQUFLLElBQUk7T0FBTyxPQUFPO09BQUcsT0FBTyxFQUFFLFVBQVU7T0FBTyxVQUFVO1FBQUUsR0FBRyxFQUFFLFVBQVU7UUFBVyxHQUFHLEVBQUUsVUFBVTtPQUFVO01BQUU7S0FDM007SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFrQixPQUFPLFdBQVcsQ0FDaEQ7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUE0QixPQUFPLFdBQVc7TUFDeEQsS0FBSyw4QkFBOEIsS0FBSyxxQkFBcUIsQ0FBQztLQUNoRTtJQUFFO0lBQUc7S0FBRSxLQUFLO0tBQW1CLE9BQU8sV0FBVztNQUMvQyxLQUFLLHFCQUFxQixDQUFDO0tBQzdCO0lBQUU7R0FBQyxDQUFDLEdBQUc7RUFDVCxFQUFFLEVBQUU7RUFDSixPQUFPLGlCQUFpQixHQUFHLFdBQVc7R0FBRSxPQUFPO0lBQUUsS0FBSyxXQUFXO0tBQy9ELE9BQU8sS0FBSyxLQUFLO0lBQ25CO0lBQUcsS0FBSyxTQUFTLEdBQUc7S0FDbEIsS0FBSyxLQUFLLElBQUk7SUFDaEI7R0FBRTtHQUFHLE9BQU87SUFBRSxLQUFLLFdBQVc7S0FDNUIsT0FBTyxLQUFLLEtBQUs7SUFDbkI7SUFBRyxLQUFLLFNBQVMsR0FBRztLQUNsQixLQUFLLEtBQUssSUFBSTtJQUNoQjtHQUFFO0dBQUcsU0FBUztJQUFFLEtBQUssV0FBVztLQUM5QixPQUFPLEtBQUssT0FBTztJQUNyQjtJQUFHLEtBQUssU0FBUyxHQUFHO0tBQ2xCLEtBQUssT0FBTyxJQUFJO0lBQ2xCO0dBQUU7R0FBRyxTQUFTO0lBQUUsS0FBSyxXQUFXO0tBQzlCLE9BQU8sS0FBSyxPQUFPO0lBQ3JCO0lBQUcsS0FBSyxTQUFTLEdBQUc7S0FDbEIsS0FBSyxPQUFPLElBQUk7SUFDbEI7R0FBRTtHQUFHLElBQUk7SUFBRSxLQUFLLFdBQVc7S0FDekIsT0FBTyxLQUFLLE1BQU07SUFDcEI7SUFBRyxLQUFLLFNBQVMsR0FBRztLQUNsQixLQUFLLE1BQU0sSUFBSTtJQUNqQjtHQUFFO0dBQUcsSUFBSTtJQUFFLEtBQUssV0FBVztLQUN6QixPQUFPLEtBQUssTUFBTTtJQUNwQjtJQUFHLEtBQUssU0FBUyxHQUFHO0tBQ2xCLEtBQUssTUFBTSxJQUFJO0lBQ2pCO0dBQUU7R0FBRyxXQUFXO0lBQUUsS0FBSyxXQUFXO0tBQ2hDLE9BQU8sS0FBSyxTQUFTO0lBQ3ZCO0lBQUcsS0FBSyxTQUFTLEdBQUc7S0FDbEIsS0FBSyxTQUFTLElBQUk7SUFDcEI7R0FBRTtHQUFHLFdBQVc7SUFBRSxLQUFLLFdBQVc7S0FDaEMsT0FBTyxLQUFLLFNBQVM7SUFDdkI7SUFBRyxLQUFLLFNBQVMsR0FBRztLQUNsQixLQUFLLFNBQVMsSUFBSTtJQUNwQjtHQUFFO0VBQUUsQ0FBQztFQUNMLElBQUksS0FBSyxFQUFFLFNBQVMsRUFBRSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUc7R0FDbkMsRUFBRSxNQUFNLENBQUMsR0FBRyxLQUFLLEtBQUssS0FBSyxHQUFHLEtBQUssVUFBVSxLQUFLLEdBQUcsS0FBSyxRQUFRLEtBQUssR0FBRyxLQUFLLFdBQVcsS0FBSyxHQUFHLEtBQUssYUFBYSxLQUFLLEdBQUcsS0FBSyxLQUFLLEdBQUcsS0FBSyxVQUFVLEdBQUcsS0FBSyxRQUFRLEdBQUcsS0FBSyxXQUFXLEdBQUcsS0FBSyxhQUFhO0VBQ2xOLENBQUMsR0FBRyxLQUFLLFNBQVMsR0FBRztHQUNuQixPQUFPLEVBQUUsZUFBZSxJQUFJLEVBQUUsVUFBVSxJQUFJLEVBQUUsV0FBVyxJQUFJLEVBQUUsZ0JBQWdCLElBQUksRUFBRSxrQkFBa0IsSUFBSSxFQUFFLFNBQVMsSUFBSTtFQUM1SCxFQUFFLENBQUMsQ0FBQyxHQUFHLEtBQUssU0FBUyxHQUFHO0dBQ3RCLE9BQU8sRUFBRSxRQUFRLElBQUksRUFBRSxPQUFPLElBQUksRUFBRSxNQUFNLElBQUksRUFBRSxPQUFPLElBQUksRUFBRSxjQUFjLElBQUk7RUFDakYsRUFBRSxDQUFDLENBQUMsR0FBRyxLQUFLLEdBQUcsS0FBSyxXQUFXO0dBQzdCLFNBQVMsRUFBRSxHQUFHO0lBQ1osSUFBSSxJQUFJLE1BQU0sSUFBSSxFQUFFLGFBQWEsSUFBSSxFQUFFO0lBQ3ZDLEVBQUUsTUFBTSxDQUFDLEdBQUcsS0FBSyxlQUFlLE1BQU0sS0FBSyxVQUFVLE1BQU0sS0FBSyxPQUFPLE1BQU0sS0FBSyxTQUFTLEtBQUssR0FBRyxLQUFLLFFBQVEsTUFBTSxLQUFLLGFBQWEsS0FBSyxHQUFHLEtBQUssV0FBVztLQUFFLE1BQU07S0FBTSxNQUFNO0tBQU0sT0FBTztJQUFLLEdBQUcsS0FBSyxjQUFjLEtBQUssR0FBRyxLQUFLLFdBQVcsQ0FBQyxHQUFHLEtBQUssWUFBWSxNQUFNLEtBQUssY0FBYyxDQUFDLEdBQUcsS0FBSyxpQkFBaUI7S0FBRSxTQUFTO0tBQU0sT0FBTztLQUFNLGFBQWE7SUFBSyxHQUFHLEtBQUssWUFBWSxNQUFNLEtBQUssZ0JBQWdCLENBQUMsR0FBRyxLQUFLLGtCQUFrQixDQUFDLEdBQUcsS0FBSyxlQUFlLENBQUMsR0FBRyxLQUFLLFVBQVUsQ0FBQyxHQUFHLEtBQUssV0FBVyxDQUFDLEdBQUcsS0FBSyxTQUFTLEtBQUssR0FBRyxLQUFLLGFBQWEsTUFBTSxLQUFLLFNBQVMsR0FBRyxTQUFTLEdBQUc7S0FDbGtCLEtBQUssS0FBSyxDQUFDO0lBQ2IsR0FBRyx3RUFBd0UsR0FBRyxLQUFLLFNBQVM7S0FBRSxPQUFPO01BQUUsTUFBTTtPQUFFLEdBQUc7T0FBRyxHQUFHO01BQUU7TUFBRyxRQUFRO09BQUUsR0FBRztPQUFHLEdBQUc7TUFBRTtNQUFHLFdBQVc7S0FBRTtLQUFHLE1BQU07TUFBRSxNQUFNO09BQUUsR0FBRztPQUFHLEdBQUc7TUFBRTtNQUFHLFFBQVE7T0FBRSxHQUFHO09BQUcsR0FBRztNQUFFO01BQUcsV0FBVztLQUFFO0tBQUcsS0FBSztNQUFFLE1BQU07T0FBRSxHQUFHO09BQUcsR0FBRztNQUFFO01BQUcsUUFBUTtPQUFFLEdBQUc7T0FBRyxHQUFHO01BQUU7TUFBRyxXQUFXO0tBQUU7S0FBRyxPQUFPO01BQUUsTUFBTTtPQUFFLEdBQUc7T0FBRyxHQUFHO01BQUU7TUFBRyxRQUFRO09BQUUsR0FBRztPQUFHLEdBQUc7TUFBRTtNQUFHLFdBQVc7S0FBRTtLQUFHLFVBQVU7TUFBRSxNQUFNO09BQUUsR0FBRztPQUFHLEdBQUc7TUFBRTtNQUFHLFFBQVE7T0FBRSxHQUFHO09BQUcsR0FBRztNQUFFO01BQUcsV0FBVztLQUFFO0lBQUUsR0FBRyxLQUFLLE1BQU0sTUFBTSxLQUFLLGFBQWEsR0FBRyxLQUFLLGNBQWM7SUFDNWYsSUFBSSxJQUFJO0lBQ1IsS0FBSyxTQUFTLENBQUM7SUFDZixJQUFJLElBQUksU0FBUyxHQUFHO0tBQ2xCLE9BQU8sZUFBZSxFQUFFLFFBQVEsR0FBRyxFQUFFLEtBQUssV0FBVztNQUNuRCxPQUFPLEVBQUU7S0FDWCxFQUFFLENBQUM7SUFDTDtJQUNBLEtBQUssSUFBSSxLQUFLLElBQUksRUFBRSxDQUFDO0lBQ3JCLElBQUksSUFBSSxTQUFTLEdBQUc7S0FDbEIsT0FBTyxlQUFlLEVBQUUsUUFBUSxHQUFHLEVBQUUsT0FBTyxXQUFXO01BQ3JELE9BQU8sRUFBRSxFQUFFLENBQUMsTUFBTSxHQUFHLFNBQVM7S0FDaEMsRUFBRSxDQUFDO0lBQ0w7SUFDQSxLQUFLLElBQUksS0FBSyxJQUFJLEVBQUUsQ0FBQztJQUNyQixLQUFLLFdBQVcsb0JBQW9CLEVBQUUsYUFBYSxLQUFLLENBQUM7R0FDM0Q7R0FDQSxPQUFPLEVBQUUsR0FBRztJQUFDO0tBQUUsS0FBSztLQUF3QixLQUFLLFdBQVc7TUFDMUQsT0FBTztLQUNUO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBZSxPQUFPLFNBQVMsR0FBRyxHQUFHLEdBQUc7TUFDbEQsSUFBSSxJQUFJLEtBQUssY0FBYyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLEtBQUssU0FBUztNQUMzRCxLQUFLLFdBQVcscUJBQXFCO09BQUUsU0FBUztPQUFHLE9BQU87T0FBRyxhQUFhO09BQUcsY0FBYztPQUFHLGFBQWE7T0FBRyxNQUFNO09BQVEsYUFBYTtNQUFLLENBQUM7S0FDako7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFTLE9BQU8sU0FBUyxHQUFHLEdBQUcsR0FBRztNQUM1QyxPQUFPLEVBQUUsS0FBSyxZQUFZLEtBQUssQ0FBQyxLQUFLLGlCQUFpQixLQUFLLFNBQVMsVUFBVSxFQUFFLFNBQVMsWUFBWSxJQUFJLE1BQU0sQ0FBQyxFQUFFLFFBQVEsRUFBRSxLQUFLLENBQUMsYUFBYSxHQUFHLEtBQUssVUFBVSxDQUFDLEdBQUcsS0FBSyxlQUFlLEdBQUcsS0FBSyxVQUFVLEdBQUcsS0FBSyxPQUFPLEVBQUUsUUFBUSxDQUFDLEdBQUcsS0FBSyxRQUFRLEtBQUssU0FBUyxRQUFRLEVBQUUsQ0FBQyxHQUFHLEtBQUssU0FBUyxLQUFLLElBQUk7T0FBRSxNQUFNLENBQUM7T0FBRyxPQUFPLENBQUM7T0FBRyxLQUFLLENBQUM7T0FBRyxRQUFRLENBQUM7TUFBRSxHQUFHLEtBQUssV0FBVyxDQUFDLEdBQUcsS0FBSyxlQUFlLEtBQUssU0FBUztPQUFFLGFBQWE7T0FBTSxPQUFPLEtBQUs7T0FBVyxPQUFPO01BQVEsQ0FBQyxLQUFLLENBQUMsS0FBSyxVQUFVLEtBQUs7S0FDcGU7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFlLE9BQU8sU0FBUyxHQUFHLEdBQUcsR0FBRztNQUNsRCxLQUFLLGNBQWMsS0FBSyxnQkFBZ0IsS0FBSyxhQUFhLGFBQWEsS0FBSyxjQUFjLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQztNQUNyRyxJQUFJLEdBQUcsR0FBRyxJQUFJLEtBQUssT0FBTyxJQUFJLEtBQUssTUFBTSxLQUFLLE9BQU8sS0FBSyxLQUFLLEtBQUssS0FBSyxPQUFPLElBQUksS0FBSyxNQUFNLEtBQUssT0FBTyxLQUFLLEtBQUssS0FBSyxLQUFLLE9BQU8sSUFBSSxPQUFPLE1BQU0sS0FBSyxPQUFPLEtBQUssT0FBTyxLQUFLLEtBQUssT0FBTyxJQUFJLE9BQU8sTUFBTSxLQUFLLE9BQU8sS0FBSyxPQUFPO01BQ3pPLEtBQUssaUJBQWlCLENBQUMsS0FBSyxvQkFBb0IsSUFBSSxLQUFLLE9BQU8sSUFBSSxPQUFPLElBQUksS0FBSyxPQUFPLE1BQU0sT0FBTyxHQUFHLElBQUksS0FBSyxPQUFPLElBQUksT0FBTyxJQUFJLEtBQUssT0FBTyxNQUFNLE9BQU8sR0FBRyxLQUFLLGtCQUFrQixHQUFHLEdBQUcsQ0FBQyxJQUFJLEtBQUs7TUFDN00sSUFBSSxHQUFHLEdBQUcsR0FBRyxJQUFJLEtBQUssZ0JBQWdCLENBQUMsR0FBRyxJQUFJO09BQUUsU0FBUztPQUFHLGNBQWM7T0FBRyxhQUFhLEtBQUssU0FBUztPQUFJLE9BQU87T0FBRyxNQUFNO09BQVEsYUFBYTtPQUFHLElBQUk7T0FBRyxJQUFJO09BQUcsV0FBVztPQUFHLGFBQWE7TUFBSztNQUNsTSxNQUFNLElBQUksS0FBSyxPQUFPLFVBQVUsSUFBSSxLQUFLLE9BQU8sT0FBTyxJQUFJLEtBQUssSUFBSSxFQUFFLFlBQVksS0FBSyxJQUFJLEdBQUcsRUFBRSxLQUFLLElBQUksRUFBRSxLQUFLLElBQUksR0FBRyxFQUFFLEtBQUssSUFBSSxFQUFFLEtBQUssSUFBSSxHQUFHLEVBQUUsT0FBTyxJQUFJLEVBQUUsT0FBTyxJQUFJLEdBQUcsRUFBRSxPQUFPLElBQUksRUFBRSxPQUFPLElBQUksR0FBRyxFQUFFLFlBQVksSUFBSSxLQUFLLFdBQVcscUJBQXFCLENBQUMsR0FBRyxLQUFLLEtBQUssZUFBZSxLQUFLLFlBQVksTUFBTSxFQUFFLE9BQU8sTUFBTSxLQUFLLEtBQUssQ0FBQyxJQUFJLEtBQUssbUJBQW1CLEdBQUcsS0FBSyxPQUFPLE1BQU0sS0FBSyxPQUFPLEdBQUc7S0FDalo7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFRLE9BQU8sU0FBUyxHQUFHO01BQ3JDLEtBQUssRUFBRSxTQUFTLEdBQUcsS0FBSyxPQUFPLEtBQUssR0FBRyxDQUFDLElBQUksRUFBRTtPQUFFLFNBQVMsS0FBSyxlQUFlO09BQVMsT0FBTyxLQUFLLGVBQWU7T0FBTyxhQUFhLEtBQUssZUFBZTtPQUFhLGFBQWE7TUFBSyxHQUFHLEtBQUssQ0FBQyxDQUFDLEVBQUEsQ0FBRyxRQUFRLFFBQVEsS0FBSyxTQUFTLENBQUM7S0FDdE87SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFhLE9BQU8sU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHO01BQ25ELElBQUksSUFBSSxLQUFLLGdCQUFnQixDQUFDO01BQzlCLE1BQU0sT0FBTyxJQUFJLEtBQUssY0FBYyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUM7TUFDL0MsSUFBSSxJQUFJLFdBQVcsS0FBSyxFQUFFLElBQUksSUFBSSxXQUFXO01BQzdDLEtBQUssV0FBVyxnQkFBZ0IsT0FBTyxDQUFDLEdBQUc7T0FBRSxTQUFTO09BQUcsY0FBYztPQUFHLGFBQWEsS0FBSyxTQUFTO09BQUksT0FBTztPQUFHLGFBQWE7T0FBRyxNQUFNO09BQUcsZ0JBQWdCO09BQUcsYUFBYTtNQUFLLENBQUMsR0FBRyxLQUFLLGNBQWMsS0FBSyxJQUFJLENBQUMsR0FBRyxLQUFLLGNBQWMsR0FBRyxDQUFDO0tBQzlPO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBZ0IsT0FBTyxTQUFTLEdBQUc7TUFDN0MsS0FBSyxJQUFJLENBQUMsR0FBRyxLQUFLLFdBQVcscUJBQXFCO09BQUUsT0FBTztPQUFHLE1BQU07T0FBUSxhQUFhO01BQUssQ0FBQztLQUNqRztJQUFFO0lBQUc7S0FBRSxLQUFLO0tBQU8sT0FBTyxTQUFTLEdBQUc7TUFDcEMsSUFBSTtNQUNKLEtBQUssVUFBVSxDQUFDLEdBQUcsSUFBSSxLQUFLLEtBQUssZUFBZSxPQUFPLEtBQUssWUFBWSxNQUFNLElBQUksS0FBSyxTQUFTO09BQUUsT0FBTztPQUFHLGFBQWE7T0FBTSxPQUFPO01BQU0sQ0FBQyxJQUFJLEtBQUssVUFBVSxDQUFDLEdBQUcsTUFBTSxDQUFDLEtBQUssS0FBSyxLQUFLO0tBQzVMO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBaUIsT0FBTyxXQUFXO01BQzdDLE9BQU8sS0FBSyxlQUFlLEtBQUssU0FBUyxPQUFPO0tBQ2xEO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBZSxPQUFPLFdBQVc7TUFDM0MsT0FBTyxLQUFLO0tBQ2Q7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFRLE9BQU8sV0FBVztNQUNwQyxLQUFLLFdBQVcscUJBQXFCLEVBQUUsYUFBYSxLQUFLLENBQUMsR0FBRyxLQUFLLGVBQWUsS0FBSyxVQUFVLE1BQU0sS0FBSyxlQUFlLENBQUMsR0FBRyxLQUFLLFdBQVcsQ0FBQyxHQUFHLEtBQUssU0FBUyxPQUFPLEtBQUssWUFBWTtLQUMxTDtJQUFFO0lBQUc7S0FBRSxLQUFLO0tBQW1CLE9BQU8sU0FBUyxHQUFHO01BQ2hELElBQUksSUFBSSxHQUFHLENBQUM7TUFDWixPQUFPLEtBQUssZ0JBQWdCLFdBQVcsS0FBSyxnQkFBZ0IsUUFBUSxLQUFLLFNBQVMsU0FBUyxJQUFJLEdBQUcsS0FBSyxVQUFVLFNBQVMsR0FBRztPQUMzSCxPQUFPLEVBQUUsT0FBTztNQUNsQixDQUFDO0tBQ0g7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFrQixPQUFPLFNBQVMsR0FBRztNQUMvQyxPQUFPLEtBQUssU0FBUyxLQUFLLGdCQUFnQixDQUFDO0tBQzdDO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBaUIsT0FBTyxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUc7TUFDdkQsSUFBSSxHQUFHLEdBQUcsR0FBRyxJQUFJLEdBQUcsQ0FBQyxHQUFHLElBQUksS0FBSyxnQkFBZ0IsQ0FBQyxHQUFHLElBQUksS0FBSyxTQUFTO01BQ3ZFLE9BQU8sSUFBSSxNQUFNLENBQUMsTUFBTSxLQUFLLGlCQUFpQixLQUFLLEVBQUUsSUFBSSxJQUFJLElBQUksRUFBRSxVQUFVLEtBQUssSUFBSSxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsTUFBTSxJQUFJLEdBQUcsSUFBSSxLQUFLLFNBQVMsUUFBUSxLQUFLLFNBQVMsS0FBSyxDQUFDLElBQUksR0FBRyxLQUFLLE9BQU8sS0FBSyxLQUFLLFNBQVMsSUFBSSxTQUFTLEdBQUc7T0FDck4sT0FBTyxFQUFFO01BQ1gsQ0FBQyxHQUFHLEtBQUssS0FBSyxDQUFDLEdBQUcsSUFBSSxLQUFLLE9BQU8sT0FBTyxJQUFJLEtBQUssT0FBTyxNQUFNLElBQUksS0FBSyxPQUFPLEtBQUssRUFBRSxLQUFLLElBQUksRUFBRSxLQUFLLElBQUksRUFBRSxLQUFLLEdBQUcsRUFBRSxLQUFLLElBQUksRUFBRSxLQUFLLElBQUksRUFBRSxLQUFLLEdBQUcsRUFBRSxPQUFPLElBQUksRUFBRSxPQUFPLElBQUksRUFBRSxPQUFPLEdBQUcsRUFBRSxPQUFPLElBQUksRUFBRSxPQUFPLElBQUksRUFBRSxPQUFPLEdBQUcsRUFBRSxZQUFZLEVBQUUsWUFBWSxFQUFFLFdBQVcsTUFBTSxLQUFLLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxXQUFXLEtBQUssT0FBTyxJQUFJLFdBQVcsRUFBRSxhQUFhLEdBQUcsR0FBRyxLQUFLLGFBQWEsQ0FBQyxHQUFHLEtBQUssWUFBWSxNQUFNLEdBQUcsS0FBSyxPQUFPLE9BQU8sS0FBSyxPQUFPLEdBQUcsR0FBRyxHQUFHLEtBQUssT0FBTyxNQUFNLEtBQUssT0FBTyxHQUFHLEdBQUcsS0FBSyxZQUFZLEdBQUcsS0FBSyxrQkFBa0IsQ0FBQyxLQUFLLEtBQUsscUJBQXFCLEdBQUcsR0FBRyxDQUFDLEdBQUcsS0FBSyxXQUFXLCtCQUErQjtPQUFFLFNBQVM7T0FBRyxPQUFPO09BQUcsYUFBYTtPQUFHLE1BQU07T0FBRyxhQUFhO09BQUcsY0FBYztPQUFHLGFBQWE7TUFBSyxDQUFDLEdBQUc7S0FDL3NCO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBaUIsT0FBTyxTQUFTLEdBQUcsR0FBRztNQUNqRCxJQUFJLElBQUksS0FBSyxnQkFBZ0IsQ0FBQztNQUM5QixJQUFJLE1BQU0sSUFBSTtPQUNaLElBQUksSUFBSSxLQUFLLFNBQVM7T0FDdEIsS0FBSyxXQUFXLCtCQUErQjtRQUFFLFNBQVM7UUFBRyxPQUFPO1FBQUcsYUFBYTtRQUFNLGNBQWM7UUFBRyxhQUFhO1FBQUcsYUFBYTtPQUFLLENBQUMsR0FBRyxLQUFLLFNBQVMsT0FBTyxHQUFHLENBQUMsR0FBRyxLQUFLLGdCQUFnQixDQUFDO01BQ3JNO0tBQ0Y7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUF3QixPQUFPLFNBQVMsR0FBRyxHQUFHLEdBQUc7TUFDM0QsS0FBSyxlQUFlLFVBQVUsR0FBRyxLQUFLLGVBQWUsUUFBUSxHQUFHLEtBQUssZUFBZSxjQUFjO0tBQ3BHO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBVyxPQUFPLFdBQVc7TUFDdkMsS0FBSyxlQUFlLFVBQVUsTUFBTSxLQUFLLGVBQWUsUUFBUSxNQUFNLEtBQUssZUFBZSxjQUFjO0tBQzFHO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBd0IsT0FBTyxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUc7TUFDOUQsT0FBTyxJQUFJLEdBQUcsTUFBTSxHQUFHLEtBQUssU0FBUyxNQUFNLEdBQUcsS0FBSyxTQUFTLEdBQUcsQ0FBQztLQUNsRTtJQUFFO0lBQUc7S0FBRSxLQUFLO0tBQWMsT0FBTyxTQUFTLEdBQUc7TUFDM0MsSUFBSTtNQUNKLENBQUMsSUFBSSxLQUFLLGlCQUFpQixRQUFRLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLGFBQWEsRUFBRSxhQUFhLEtBQUssVUFBVSxlQUFlLEtBQUssWUFBWTtLQUNsSTtJQUFFO0lBQUc7S0FBRSxLQUFLO0tBQVksT0FBTyxTQUFTLEdBQUc7TUFDekMsSUFBSSxJQUFJLEVBQUUsT0FBTyxJQUFJLEVBQUUsT0FBTyxJQUFJLEVBQUUsUUFBUSxJQUFJLEVBQUUsTUFBTSxJQUFJLEtBQUs7TUFDakUsSUFBSSxLQUFLLE1BQU0sV0FBVyxHQUFHLEtBQUssT0FBTyxHQUFHLEtBQUssT0FBTyxNQUFNLEtBQUssYUFBYSxRQUFRLFlBQVksR0FBRyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsTUFBTSxLQUFLLFdBQVcsOEJBQThCLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDO01BQzdPLElBQUksSUFBSSxFQUFFLFNBQVMsS0FBSyxxQkFBcUIsR0FBRyxHQUFHLEdBQUcsQ0FBQztNQUN2RCxPQUFPLEtBQUssV0FBVyx1QkFBdUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQU0sWUFBWSxLQUFLLFlBQVksSUFBSSxLQUFLLFdBQVcsQ0FBQyxHQUFHLEtBQUssV0FBVyw2QkFBNkIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7S0FDdkw7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFRLE9BQU8sV0FBVztNQUNwQyxPQUFPLEtBQUssSUFBSTtLQUNsQjtJQUFFO0dBQUMsQ0FBQyxHQUFHO0VBQ1QsRUFBRTtFQUNGLFNBQVMsR0FBRyxHQUFHO0dBQ2IsR0FBRyxFQUFFLFdBQVc7RUFDbEI7RUFDQSxTQUFTLEdBQUcsR0FBRztHQUNiLElBQUksQ0FBQyxTQUFTLEdBQUc7SUFDZixPQUFPLEVBQUUsQ0FBQyxFQUFFLE9BQU8sUUFBUSxLQUFLLENBQUMsRUFBRSxPQUFPLFFBQVE7R0FDcEQsRUFBRSxDQUFDLEdBQUcsT0FBTyxDQUFDO0dBQ2QsSUFBSSxJQUFJLEVBQUUsT0FBTztHQUNqQixPQUFPLEdBQUcsRUFBRSxPQUFPLEtBQUssQ0FBQyxHQUFHLEdBQUcsRUFBRSxPQUFPLE9BQU8sQ0FBQyxHQUFHLEdBQUcsRUFBRSxPQUFPLEVBQUUsTUFBTSxDQUFDLEdBQUcsRUFBRSxJQUFJLEdBQUcsRUFBRSxJQUFJLEdBQUcsQ0FBQztFQUNoRztFQUNBLFNBQVMsR0FBRyxHQUFHO0dBQ2IsSUFBSSxJQUFJLEVBQUUsR0FBRyxJQUFJLEVBQUU7R0FDbkIsS0FBSyxPQUFPLFFBQVEsS0FBSyxHQUFHLEtBQUssT0FBTyxRQUFRLEtBQUssR0FBRyxLQUFLLE9BQU8sTUFBTSxLQUFLLEdBQUcsS0FBSyxPQUFPLE1BQU0sS0FBSztFQUMzRztFQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUc7R0FDaEIsSUFBSSxJQUFJLEVBQUUsTUFBTSxJQUFJLEVBQUUsUUFBUSxJQUFJLEVBQUUsR0FBRyxJQUFJLEVBQUU7R0FDN0MsRUFBRSxLQUFLLEdBQUcsRUFBRSxLQUFLLEdBQUcsRUFBRSxLQUFLLEdBQUcsRUFBRSxLQUFLO0VBQ3ZDO0VBQ0EsR0FBRyxXQUFXO0VBQ2QsSUFjTyxLQUFLO0dBZEQsSUFBSTtHQUFVLFFBQVE7SUFBQztJQUFhO0lBQWtCO0lBQVc7R0FBUztHQUFHLFNBQVMsU0FBUyxHQUFHO0lBQzNHLEVBQUUsWUFBWSxVQUFVLFdBQVc7R0FDckM7R0FBRyxXQUFXO0lBQUUsb0JBQW9CLFNBQVMsR0FBRztLQUM5QyxFQUFFLFlBQVksU0FBUztNQUFFLE9BQU87T0FBRSxHQUFHO09BQUcsR0FBRztNQUFFO01BQUcsU0FBUztPQUFFLEdBQUc7T0FBRyxHQUFHO01BQUU7S0FBRTtJQUMxRTtJQUFHLCtCQUErQixTQUFTLEdBQUc7S0FDNUMsT0FBTyxTQUFTLEdBQUc7TUFDakIsRUFBRSxrQkFBa0IsR0FBRyxFQUFFLE9BQU8sS0FBSyxFQUFFLE9BQU8sS0FBSyxHQUFHLEVBQUUsT0FBTyxRQUFRLElBQUksR0FBRyxFQUFFLE9BQU8sUUFBUSxJQUFJO0tBQ3JHLEVBQUUsRUFBRSxXQUFXO0lBQ2pCO0lBQUcsb0NBQW9DO0lBQUksbUNBQW1DO0lBQUksa0NBQWtDLFNBQVMsR0FBRztLQUM5SCxJQUFJLElBQUksRUFBRTtLQUNWLElBQUksR0FBRyxDQUFDLEdBQUcsT0FBTyxFQUFFLEtBQUssRUFBRSxRQUFRLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxJQUFJLEdBQUcsQ0FBQztJQUN0RDtJQUFHLHFCQUFxQixTQUFTLEdBQUc7S0FDbEMsSUFBSSxJQUFJLEVBQUU7S0FDVixFQUFFLE9BQU8sTUFBTSxJQUFJLEdBQUcsRUFBRSxPQUFPLE1BQU0sSUFBSSxHQUFHLEVBQUUsT0FBTyxRQUFRLElBQUksR0FBRyxFQUFFLE9BQU8sUUFBUSxJQUFJO0lBQzNGO0dBQUU7RUFBVyxHQUFHLEtBQUssV0FBVztHQUM5QixTQUFTLEVBQUUsR0FBRztJQUNaLEVBQUUsTUFBTSxDQUFDLEdBQUcsS0FBSyxTQUFTLENBQUMsR0FBRyxLQUFLLGFBQWEsQ0FBQyxHQUFHLEtBQUssWUFBWSxDQUFDLEdBQUcsS0FBSyxjQUFjLENBQUMsR0FBRyxLQUFLLGVBQWUsS0FBSyxHQUFHLEtBQUssZ0JBQWdCLEdBQUcsS0FBSyxjQUFjLEtBQUssR0FBRyxLQUFLLGNBQWMsS0FBSyxHQUFHLEtBQUssS0FBSyxHQUFHLEtBQUssS0FBSyxHQUFHLEtBQUssS0FBSyxHQUFHLEtBQUssZUFBZSxLQUFLLEdBQUcsS0FBSyxpQkFBaUIsS0FBSyxHQUFHLEtBQUssZ0JBQWdCLEtBQUssR0FBRyxLQUFLLFlBQVksR0FBRyxLQUFLLFlBQVksR0FBRyxLQUFLLFVBQVUsS0FBSyxHQUFHLEtBQUssY0FBYyxLQUFLLEdBQUcsS0FBSyxjQUFjO0dBQ3ZiO0dBQ0EsT0FBTyxFQUFFLEdBQUc7SUFBQztLQUFFLEtBQUs7S0FBUyxPQUFPLFNBQVMsR0FBRztNQUM5QyxJQUFJLElBQUksS0FBSyxhQUFhLElBQUksR0FBRyxDQUFDO01BQ2xDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxTQUFTLE9BQU8sQ0FBQztNQUM5QixJQUFJLElBQUksRUFBRSxPQUFPLFNBQVMsUUFBUSxJQUFJLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQyxHQUFHLElBQUksS0FBSyxpQkFBaUIsS0FBSyxlQUFlLElBQUksR0FBRyxDQUFDO01BQzFHLElBQUksRUFBRSxTQUFTLEVBQUUsWUFBWSxHQUFHLEtBQUssS0FBSyxFQUFFLEtBQUssR0FBRyxLQUFLLGNBQWMsRUFBRSxhQUFhLEtBQUssS0FBSyxHQUFHLEtBQUssZ0JBQWdCO09BQUUsR0FBRztPQUFHLEdBQUc7TUFBRSxHQUFHLEtBQUssY0FBYyxFQUFFLE9BQU8sSUFBSSxNQUFNLEtBQUssY0FBYyxFQUFFLFFBQVE7T0FBRSxZQUFZLEtBQUs7T0FBYSxRQUFRLENBQUM7T0FBRyxPQUFPO01BQWUsQ0FBQyxHQUFHLEtBQUssS0FBSyxFQUFFLE9BQU8sSUFBSSxZQUFZLE1BQU0sSUFBSSxFQUFFLFlBQVksSUFBSSxFQUFFLFVBQVUsS0FBSyxhQUFhO1dBQ3pXO09BQ0gsSUFBSSxFQUFFLFNBQVMsRUFBRSxPQUFPLEtBQUssV0FBVyxHQUFHLENBQUMsRUFBRSxPQUFPLFNBQVMsT0FBTyxDQUFDO09BQ3RFLEtBQUssZUFBZTtNQUN0QjtNQUNBLE9BQU8sRUFBRSxhQUFhLE9BQU8sT0FBTyxNQUFNLEVBQUUsU0FBUyxLQUFLLFlBQVksR0FBRyxFQUFFLFNBQVM7T0FBRSxhQUFhO09BQUcsT0FBTztPQUFHLE9BQU87TUFBZSxDQUFDLEdBQUcsRUFBRSxTQUFTO09BQUUsR0FBRyxDQUFDLEtBQUssYUFBYTtPQUFHLEdBQUcsQ0FBQyxLQUFLLGFBQWE7TUFBRSxDQUFDLEdBQUcsRUFBRSxhQUFhLE9BQU8sT0FBTyxNQUFNLEtBQUssU0FBUyxDQUFDLEdBQUcsRUFBRSxhQUFhLE1BQU0sQ0FBQztLQUN6UjtJQUFFO0lBQUc7S0FBRSxLQUFLO0tBQWdCLE9BQU8sV0FBVztNQUM1QyxJQUFJLElBQUksTUFBTSxJQUFJLEtBQUssWUFBWSxPQUFPLFNBQVMsUUFBUSxJQUFJLEdBQUcsS0FBSyxXQUFXLEdBQUcsSUFBSSxFQUFFLFlBQVksSUFBSSxDQUFDLEtBQUssSUFBSSxFQUFFLFdBQVcsS0FBSyxFQUFFLElBQUk7TUFDN0ksS0FBSyxlQUFlO09BQUUsSUFBSSxFQUFFLElBQUksS0FBSztPQUFHLElBQUksRUFBRSxJQUFJLEtBQUs7TUFBRSxHQUFHLEtBQUssS0FBSyxHQUFHLEtBQUssWUFBWSxJQUFJLEtBQUssSUFBSSxLQUFLLFlBQVksSUFBSSxFQUFFLFdBQVcsS0FBSztNQUM5SSxJQUFJLElBQUksS0FBSyxjQUFjLElBQUksS0FBSztNQUNwQyxFQUFFLGFBQWE7T0FBRSxHQUFHLEtBQUssWUFBWSxJQUFJLEtBQUssYUFBYTtPQUFHLEdBQUcsS0FBSyxZQUFZLElBQUksS0FBSyxhQUFhO01BQUUsR0FBRyxFQUFFLFNBQVMsRUFBRSxPQUFPLENBQUMsR0FBRyxFQUFFLE9BQU8sWUFBWSxLQUFLLGFBQWEsQ0FBQyxHQUFHLEtBQUssaUJBQWlCO09BQUUsR0FBRyxLQUFLLGFBQWEsSUFBSSxFQUFFLE9BQU8sTUFBTTtPQUFHLEdBQUcsS0FBSyxhQUFhLElBQUksRUFBRSxPQUFPLE1BQU07TUFBRSxJQUFJLEtBQUssWUFBWSxXQUFXO09BQzNULE9BQU8sRUFBRSxZQUFZO01BQ3ZCLENBQUM7S0FDSDtJQUFFO0lBQUc7S0FBRSxLQUFLO0tBQWtCLE9BQU8sV0FBVztNQUM5QyxJQUFJLElBQUk7TUFDUixLQUFLLFlBQVksQ0FBQyxHQUFHLEtBQUssYUFBYSxDQUFDLEdBQUcsS0FBSyxlQUFlO09BQUUsR0FBRyxLQUFLLGFBQWEsT0FBTyxNQUFNO09BQUcsR0FBRyxLQUFLLGFBQWEsT0FBTyxNQUFNO01BQUUsR0FBRyxLQUFLLFlBQVksV0FBVztPQUN2SyxPQUFPLEVBQUUsY0FBYztNQUN6QixDQUFDO0tBQ0g7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFlLE9BQU8sU0FBUyxHQUFHO01BQzVDLElBQUksSUFBSTtNQUNSLEtBQUssVUFBVSxHQUFHLFFBQVEsV0FBVztPQUNuQyxFQUFFLFVBQVUsRUFBRTtNQUNoQixDQUFDO0tBQ0g7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFlLE9BQU8sV0FBVztNQUMzQyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxNQUFNLElBQUksS0FBSyxhQUFhLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQyxZQUFZLEtBQUssRUFBRSxLQUFLLElBQUksS0FBSyxNQUFNO01BQzFHLElBQUksSUFBSSxLQUFLLElBQUk7T0FDZixJQUFJLEdBQUcsSUFBSSxLQUFLLEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEtBQUssYUFBYSxLQUFLO09BQzFELEtBQUssY0FBYyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksS0FBSyxhQUFhLEdBQUcsSUFBSSxLQUFLLGFBQWEsR0FBRyxJQUFJLEtBQUssZUFBZSxHQUFHLElBQUksS0FBSyxlQUFlLEdBQUcsSUFBSTtRQUFFLEdBQUcsR0FBRyxJQUFJLEdBQUcsR0FBRyxHQUFHLENBQUM7UUFBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQztPQUFFLEtBQUssSUFBSTtRQUFFLEdBQUcsS0FBSyxhQUFhLElBQUk7UUFBRyxHQUFHLEtBQUssYUFBYSxJQUFJO09BQUU7T0FDMVAsSUFBSSxJQUFJO1FBQUUsR0FBRyxFQUFFLElBQUksS0FBSyxjQUFjO1FBQUcsR0FBRyxFQUFFLElBQUksS0FBSyxjQUFjO09BQUU7T0FDdkUsS0FBSyxjQUFjLEtBQUssRUFBRSxHQUFHLEtBQUssY0FBYyxLQUFLLEVBQUUsR0FBRyxFQUFFLFNBQVMsQ0FBQyxHQUFHLEVBQUUsS0FBSyxHQUFHLEtBQUssWUFBWSxXQUFXO1FBQzdHLE9BQU8sRUFBRSxZQUFZO09BQ3ZCLENBQUM7TUFDSCxPQUFPLEVBQUUsU0FBUztPQUFFLEdBQUcsS0FBSyxlQUFlLElBQUksS0FBSyxjQUFjO09BQUcsR0FBRyxLQUFLLGVBQWUsSUFBSSxLQUFLLGNBQWM7TUFBRSxDQUFDLEdBQUcsS0FBSyxJQUFJO0tBQ3BJO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBaUIsT0FBTyxXQUFXO01BQzdDLElBQUksSUFBSSxNQUFNLElBQUksS0FBSyxhQUFhLElBQUksRUFBRSxLQUFLLElBQUksS0FBSyxJQUFJLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQztNQUN0RSxJQUFJLElBQUksR0FBRztPQUNULElBQUksSUFBSTtRQUFFLEdBQUcsR0FBRyxHQUFHLEdBQUcsS0FBSyxhQUFhLEdBQUcsQ0FBQztRQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsS0FBSyxhQUFhLEdBQUcsQ0FBQztPQUFFLEdBQUcsSUFBSTtRQUFFLEdBQUcsRUFBRSxJQUFJLEtBQUssY0FBYztRQUFHLEdBQUcsRUFBRSxJQUFJLEtBQUssY0FBYztPQUFFO09BQ3pKLEtBQUssY0FBYyxLQUFLLEVBQUUsR0FBRyxLQUFLLGNBQWMsS0FBSyxFQUFFLEdBQUcsRUFBRSxTQUFTLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxlQUFlLEtBQUssY0FBYyxDQUFDLEdBQUcsS0FBSyxZQUFZLFdBQVc7UUFDbEosT0FBTyxFQUFFLGNBQWM7T0FDekIsQ0FBQztNQUNILE9BQU8sRUFBRSxTQUFTO09BQUUsR0FBRyxLQUFLLGFBQWEsSUFBSSxLQUFLLGNBQWM7T0FBRyxHQUFHLEtBQUssYUFBYSxJQUFJLEtBQUssY0FBYztNQUFFLENBQUMsR0FBRyxLQUFLLElBQUk7S0FDaEk7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFVLE9BQU8sU0FBUyxHQUFHO01BQ3ZDLElBQUksSUFBSSxFQUFFLFNBQVMsSUFBSSxFQUFFLE9BQU8sSUFBSSxFQUFFLGFBQWEsSUFBSSxLQUFLO01BQzVELEVBQUUsU0FBUztPQUFFLEdBQUcsQ0FBQyxLQUFLLGNBQWM7T0FBRyxHQUFHLENBQUMsS0FBSyxjQUFjO01BQUUsQ0FBQyxHQUFHLEVBQUUsY0FBYyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLFNBQVM7T0FBRSxhQUFhO09BQUcsT0FBTztPQUFHLE9BQU87TUFBUyxDQUFDLEdBQUcsR0FBRyxFQUFFLE9BQU8sTUFBTSxFQUFFLE9BQU8sR0FBRyxHQUFHLEtBQUssS0FBSztLQUMxTTtJQUFFO0lBQUc7S0FBRSxLQUFLO0tBQU8sT0FBTyxXQUFXO01BQ25DLEtBQUssWUFBWSxLQUFLLEdBQUcsS0FBSyxZQUFZLElBQUksR0FBRyxLQUFLLEtBQUs7S0FDN0Q7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFRLE9BQU8sV0FBVztNQUNwQyxLQUFLLFNBQVMsS0FBSyxZQUFZLENBQUMsR0FBRyxLQUFLLFlBQVksYUFBYSxNQUFNLEdBQUcsT0FBTyxLQUFLLE9BQU87S0FDL0Y7SUFBRTtHQUFDLENBQUMsR0FBRztFQUNULEVBQUU7RUFDRixTQUFTLEdBQUcsR0FBRztHQUNiLElBQUksSUFBSSxFQUFFLGNBQWMsSUFBSSxFQUFFO0dBQzlCLE9BQU8sS0FBSyxFQUFFLFdBQVcsRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLEtBQUssQ0FBQztFQUN2RDtFQUNBLElBQUksS0FBSztHQUFFLElBQUk7R0FBVyxRQUFRLENBQUMsYUFBYSxTQUFTO0dBQUcsU0FBUyxTQUFTLEdBQUc7SUFDL0UsSUFBSSxJQUFJLEVBQUU7SUFDVixFQUFFLFVBQVUsRUFBRSxHQUFHLEVBQUUsVUFBVSxFQUFFLEdBQUcsRUFBRSxRQUFRLE9BQU8sZUFBZSxDQUFDLEdBQUcsRUFBRSxRQUFRLE9BQU8sU0FBUyxDQUFDLEdBQUcsRUFBRSxVQUFVLFVBQVU7S0FBRSxTQUFTLENBQUM7S0FBRyxZQUFZO0tBQUksVUFBVTtLQUFLLFVBQVU7S0FBSSxhQUFhLENBQUM7S0FBRyxtQkFBbUI7SUFBSTtHQUNoTztHQUFHLFdBQVc7SUFBRSxvQkFBb0IsU0FBUyxHQUFHO0tBQzlDLElBQUksSUFBSSxFQUFFO0tBQ1YsRUFBRSxVQUFVLElBQUksR0FBRyxDQUFDO0lBQ3RCO0lBQUcsa0NBQWtDLFNBQVMsR0FBRztLQUMvQyxJQUFJLElBQUksRUFBRSxhQUFhLElBQUksRUFBRTtLQUM3QixRQUFRLENBQUMsRUFBRSxnQkFBZ0IsRUFBRSxjQUFjLENBQUMsRUFBRSxRQUFRLE1BQU0sQ0FBQyxNQUFNO0lBQ3JFO0lBQUcscUJBQXFCLFNBQVMsR0FBRztLQUNsQyxJQUFJLElBQUksRUFBRSxhQUFhLElBQUksRUFBRSxhQUFhLElBQUksRUFBRTtLQUNoRCxJQUFJLEVBQUUsUUFBUSxLQUFLLElBQUksSUFBSSxHQUFHLEVBQUUsUUFBUSxDQUFDLElBQUs7TUFDNUMsSUFBSSxNQUFNLEVBQUUsU0FBUztPQUNuQixFQUFFLE9BQU8sQ0FBQztPQUNWO01BQ0Y7TUFDQSxJQUFJLEdBQUcsQ0FBQztLQUNWO0lBQ0Y7SUFBRyxxQkFBcUIsU0FBUyxHQUFHO0tBQ2xDLElBQUksSUFBSSxFQUFFLFlBQVk7S0FDdEIsRUFBRSxVQUFVLEVBQUUsS0FBSztJQUNyQjtJQUFHLHFDQUFxQyxTQUFTLEdBQUc7S0FDbEQsSUFBSSxJQUFJLEVBQUUsWUFBWTtLQUN0QixFQUFFLEtBQUssQ0FBQyxHQUFHLEVBQUUsTUFBTSxHQUFHLEVBQUUsWUFBWSxPQUFPLElBQUksSUFBSSxHQUFHLEVBQUUsbUJBQW1CLENBQUM7SUFDOUU7SUFBRywyQ0FBMkMsU0FBUyxHQUFHO0tBQ3hELE9BQU8sRUFBRSxZQUFZLGFBQWEsWUFBWSxDQUFDO0lBQ2pEO0lBQUcsOEJBQThCO0lBQUksb0NBQW9DO0lBQUksMENBQTBDLFNBQVMsR0FBRztLQUNqSSxPQUFPLEVBQUUsWUFBWSxhQUFhLHlCQUF5QixDQUFDO0lBQzlEO0lBQUcsb0NBQW9DLFNBQVMsR0FBRztLQUNqRCxPQUFPLEVBQUUsWUFBWSxhQUFhLHlCQUF5QixDQUFDO0lBQzlEO0dBQUU7RUFBRTtFQUNKLFNBQVMsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0dBQ3RCLElBQUksSUFBSSxJQUFJO0dBQ1osT0FBTyxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSTtFQUM3QztFQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0dBQ3RCLE9BQU8sQ0FBQyxLQUFLLEtBQUssTUFBTSxJQUFJLEtBQUs7RUFDbkM7RUFDQSxJQUFJLEtBQUs7RUFDVCxTQUFTLEdBQUcsR0FBRyxHQUFHO0dBQ2hCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FBSztJQUNqQyxJQUFJLElBQUksRUFBRTtJQUNWLElBQUksRUFBRSw2QkFBNkI7SUFDbkMsRUFBRSxDQUFDO0dBQ0w7RUFDRjtFQUNBLElBQUksS0FBSyxXQUFXO0dBQ2xCLFNBQVMsRUFBRSxHQUFHO0lBQ1osRUFBRSxNQUFNLENBQUMsR0FBRyxLQUFLLFVBQVUsS0FBSyxHQUFHLEtBQUssUUFBUSxDQUFDLEdBQUcsS0FBSyxxQkFBcUIsQ0FBQyxHQUFHLEtBQUssOEJBQThCLENBQUMsR0FBRyxLQUFLLFNBQVMsS0FBSyxHQUFHLEtBQUssVUFBVSxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQztHQUM3SztHQUNBLE9BQU8sRUFBRSxHQUFHO0lBQUM7S0FBRSxLQUFLO0tBQVEsT0FBTyxTQUFTLEdBQUc7TUFDN0MsSUFBSSxHQUFHLElBQUksS0FBSztNQUNoQixDQUFDLElBQUksS0FBSyxNQUFNLEVBQUUsVUFBVSxHQUFHLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRSxzQkFBc0IsTUFBTSxJQUFJLEVBQUUsRUFBRSxVQUFVLEdBQUcsR0FBRyxDQUFDO0tBQ2hHO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBTSxPQUFPLFNBQVMsR0FBRyxHQUFHO01BQ3RDLElBQUksSUFBSSxHQUFHLEdBQUcsQ0FBQztNQUNmLEtBQUssS0FBSyxHQUFHLEtBQUssTUFBTSxLQUFLLEdBQUcsS0FBSyxNQUFNLE1BQU0sQ0FBQyxHQUFHLEVBQUUsRUFBRTtLQUMzRDtJQUFFO0lBQUc7S0FBRSxLQUFLO0tBQU8sT0FBTyxTQUFTLEdBQUcsR0FBRztNQUN2QyxJQUFJLElBQUksR0FBRyxHQUFHLENBQUM7TUFDZixLQUFLLEtBQUssR0FBRztPQUNYLElBQUksSUFBSSxLQUFLLE1BQU07T0FDbkIsSUFBSSxLQUFLLEVBQUUsUUFBUSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxRQUFRLEtBQUs7UUFDOUQsSUFBSSxJQUFJLEVBQUUsSUFBSSxJQUFJLEVBQUUsUUFBUSxDQUFDO1FBQzdCLE1BQU0sTUFBTSxFQUFFLE9BQU8sR0FBRyxDQUFDO09BQzNCO01BQ0Y7S0FDRjtJQUFFO0lBQUc7S0FBRSxLQUFLO0tBQVcsT0FBTyxTQUFTLEdBQUc7TUFDeEMsT0FBTztLQUNUO0lBQUU7R0FBQyxDQUFDLEdBQUc7RUFDVCxFQUFFLEdBQUcsS0FBSyxXQUFXO0dBQ25CLFNBQVMsRUFBRSxHQUFHO0lBQ1osRUFBRSxNQUFNLENBQUMsR0FBRyxLQUFLLGdCQUFnQixLQUFLLEdBQUcsS0FBSyxnQkFBZ0IsS0FBSyxHQUFHLEtBQUssT0FBTyxLQUFLLEdBQUcsS0FBSyxnQkFBZ0IsR0FBRyxHQUFHLE1BQU0sQ0FBQztHQUM5SDtHQUNBLE9BQU8sRUFBRSxHQUFHO0lBQUM7S0FBRSxLQUFLO0tBQTBCLE9BQU8sV0FBVztNQUM5RCxLQUFLLGNBQWMsZUFBZTtLQUNwQztJQUFFO0lBQUc7S0FBRSxLQUFLO0tBQW1CLE9BQU8sV0FBVztNQUMvQyxLQUFLLGNBQWMsZ0JBQWdCO0tBQ3JDO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBNEIsT0FBTyxXQUFXO01BQ3hELEtBQUssY0FBYyx5QkFBeUI7S0FDOUM7SUFBRTtHQUFDLENBQUMsR0FBRztFQUNULEVBQUU7RUFDRixTQUFTLEdBQUcsR0FBRztHQUNiLE9BQU8sRUFBRSxPQUFPLENBQUMsSUFBSTtJQUFFLFNBQVMsQ0FBQyxDQUFDLEVBQUU7SUFBUyxTQUFTLENBQUMsQ0FBQyxFQUFFO0dBQVEsSUFBSTtJQUFFLFNBQVMsQ0FBQyxDQUFDO0lBQUcsU0FBUyxDQUFDO0dBQUU7RUFDcEc7RUFDQSxTQUFTLEdBQUcsR0FBRyxHQUFHO0dBQ2hCLE9BQU8sTUFBTSxNQUFNLE9BQU8sS0FBSyxZQUFZLENBQUMsQ0FBQyxFQUFFLFlBQVksS0FBSyxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUMsRUFBRSxXQUFXLENBQUMsQ0FBQyxFQUFFLFdBQVcsQ0FBQyxDQUFDLEVBQUUsV0FBVyxDQUFDLENBQUMsRUFBRTtFQUNoSTtFQUNBLElBQUksS0FBSztHQUFFLElBQUk7R0FBVSxTQUFTLFNBQVMsR0FBRztJQUM1QyxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsSUFBSTtLQUFFLEtBQUs7S0FBRyxRQUFRO0tBQUcsYUFBYSxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRztNQUMzRixJQUFJLElBQUksR0FBRyxDQUFDO01BQ1osSUFBSSxDQUFDLEVBQUUsSUFBSTtPQUNULEVBQUUsS0FBSyxDQUFDO09BQ1IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLO1FBQ2pDLElBQUksSUFBSSxFQUFFO1FBQ1YsRUFBRSxHQUFHLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDO09BQzNCO01BQ0Y7TUFDQSxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksR0FBRyxHQUFHLFNBQVMsR0FBRztPQUNsQyxPQUFPLEVBQUUsYUFBYSxLQUFLLEVBQUUsWUFBWTtNQUMzQyxDQUFDO01BQ0QsTUFBTSxJQUFJO09BQUUsVUFBVTtPQUFHLFNBQVM7T0FBRyxXQUFXLENBQUM7TUFBRSxHQUFHLEVBQUUsS0FBSyxDQUFDLElBQUksRUFBRSxVQUFVLEtBQUs7T0FBRSxNQUFNO09BQUcsU0FBUztNQUFFLENBQUM7S0FDNUc7S0FBRyxnQkFBZ0IsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUc7TUFDekMsSUFBSSxHQUFHLElBQUksR0FBRyxDQUFDLEdBQUcsSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDO01BQ2pDLElBQUksR0FDRixLQUFLLElBQUksRUFBRSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7T0FDbEMsSUFBSSxJQUFJLEVBQUU7T0FDVixJQUFJLEVBQUUsYUFBYSxLQUFLLEVBQUUsWUFBWSxHQUFHO1FBQ3ZDLEtBQUssSUFBSSxJQUFJLEVBQUUsV0FBVyxJQUFJLEVBQUUsU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO1NBQ3ZELElBQUksSUFBSSxFQUFFO1NBQ1YsSUFBSSxFQUFFLFNBQVMsS0FBSyxHQUFHLEVBQUUsU0FBUyxDQUFDLEdBQUc7VUFDcEMsRUFBRSxPQUFPLEdBQUcsQ0FBQyxHQUFHLEVBQUUsV0FBVyxFQUFFLE9BQU8sR0FBRyxDQUFDLEdBQUcsRUFBRSxHQUFHLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDO1VBQy9FO1NBQ0Y7UUFDRjtRQUNBLElBQUksR0FBRztPQUNUO01BQ0Y7S0FDSjtLQUFHLGtCQUFrQjtLQUFHLG9CQUFvQjtLQUFHLGlCQUFpQjtLQUFHLFdBQVc7S0FBRyxTQUFTO0tBQUcsaUJBQWlCLENBQUM7S0FBRyxpQkFBaUIsQ0FBQztJQUFFO0lBQ3RJLFNBQVMsRUFBRSxHQUFHLEdBQUcsR0FBRyxHQUFHO0tBQ3JCLElBQUksRUFBRSxrQkFBa0I7TUFDdEIsSUFBSSxJQUFJLEdBQUcsQ0FBQyxHQUFHLElBQUksR0FBRyxHQUFHLFNBQVMsR0FBRztPQUNuQyxPQUFPLEVBQUUsZ0JBQWdCO01BQzNCLENBQUM7TUFDRCxNQUFNLElBQUk7T0FBRSxhQUFhO09BQUcsUUFBUSxDQUFDO01BQUUsR0FBRyxFQUFFLEtBQUssQ0FBQyxJQUFJLEVBQUUsT0FBTyxPQUFPLEVBQUUsT0FBTyxLQUFLLENBQUMsSUFBSSxHQUFHLEVBQUUsT0FBTyxJQUFJLFNBQVMsR0FBRztPQUNuSCxPQUFPLEVBQUUsU0FBUyxLQUFLLEdBQUcsRUFBRSxTQUFTLENBQUM7TUFDeEMsQ0FBQyxNQUFNLEVBQUUsaUJBQWlCLEdBQUcsR0FBRyxFQUFFLGtCQUFrQixJQUFJLEVBQUUsT0FBTyxHQUFHLEVBQUUsT0FBTyxFQUFFLENBQUMsS0FBSztPQUFFLE1BQU07T0FBRyxTQUFTO01BQUUsQ0FBQztLQUM5RztJQUNGO0lBQ0EsU0FBUyxFQUFFLEdBQUcsR0FBRyxHQUFHLEdBQUc7S0FDckIsSUFBSSxFQUFFLG9CQUFvQixFQUFFLHFCQUFxQjtNQUMvQyxJQUFJLElBQUksR0FBRyxHQUFHLFNBQVMsSUFBSTtPQUN6QixPQUFPLEdBQUcsZ0JBQWdCO01BQzVCLENBQUMsR0FBRyxJQUFJLEVBQUU7TUFDVixJQUFJLEtBQUssRUFBRSxRQUFRLElBQUksTUFBTSxPQUFPO09BQ2xDLElBQUksSUFBSSxDQUFDLEdBQUcsSUFBSSxFQUFFLE9BQU87T0FDekIsSUFBSSxHQUFHO1FBQ0wsSUFBSSxNQUFNLE9BQU87U0FDZixLQUFLLElBQUksSUFBSSxFQUFFLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztVQUN0QyxJQUFJLElBQUksRUFBRTtVQUNWLEVBQUUsR0FBRyxHQUFHLEVBQUUsTUFBTSxFQUFFLE9BQU87U0FDM0I7U0FDQTtRQUNGO1FBQ0EsS0FBSyxJQUFJLElBQUksR0FBRyxDQUFDLEdBQUcsSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLEtBQUs7U0FDNUMsSUFBSSxJQUFJLEVBQUU7U0FDVixJQUFJLEVBQUUsU0FBUyxLQUFLLEdBQUcsRUFBRSxTQUFTLENBQUMsR0FBRztVQUNwQyxFQUFFLG9CQUFvQixHQUFHLEdBQUcsRUFBRSxrQkFBa0IsSUFBSSxFQUFFLE9BQU8sR0FBRyxFQUFFLE9BQU8sR0FBRyxDQUFDLEdBQUcsRUFBRSxXQUFXLE1BQU0sT0FBTyxFQUFFLE9BQU8sSUFBSSxJQUFJLENBQUM7VUFDNUg7U0FDRjtRQUNGO09BQ0Y7T0FDQSxLQUFLLENBQUMsT0FBTyxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUMsVUFBVSxFQUFFLE9BQU8sR0FBRyxDQUFDO01BQ3JELE9BQU8sS0FBSyxLQUFLLEVBQUUsUUFBUSxFQUFFLE9BQU8sZUFBZSxDQUFDLEtBQUssRUFBRSxHQUFHLEdBQUcsS0FBSztLQUN4RTtJQUNGO0lBQ0EsU0FBUyxFQUFFLEdBQUcsR0FBRztLQUNmLEtBQUssSUFBSSxJQUFJLEdBQUcsQ0FBQyxHQUFHLElBQUksSUFBSSxHQUFHLENBQUMsR0FBRyxJQUFJLEVBQUUsRUFBRSxPQUFPLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksR0FBRyxFQUFFLFFBQVEsQ0FBQyxJQUFLO01BQ3JGLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FBSztPQUNqQyxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxVQUFVLElBQUksRUFBRTtPQUNwQyxJQUFJLEdBQUcsR0FBRyxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQyxHQUFHO1FBQ3BDLElBQUksSUFBSSxFQUFFO1FBQ1YsRUFBRSxnQkFBZ0I7UUFDbEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLO1NBQ2pDLElBQUksS0FBSyxFQUFFO1NBQ1gsR0FBRyxHQUFHLFNBQVMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO1FBQ2hDO09BQ0Y7TUFDRjtNQUNBLElBQUksR0FBRyxDQUFDO0tBQ1Y7SUFDRjtJQUNBLFNBQVMsRUFBRSxHQUFHO0tBQ1osT0FBTyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ2hCO0lBQ0EsUUFBUSxJQUFJLEVBQUUsYUFBYSxRQUFRLEVBQUUsY0FBYyxLQUFLLENBQUMsQ0FBQyxpQkFBaUIsUUFBUSxNQUFNO0tBQUUsSUFBSSxVQUFVO01BQ3ZHLE9BQU8sRUFBRSxrQkFBa0IsQ0FBQztLQUM5QjtLQUFHLElBQUksVUFBVTtNQUNmLE9BQU8sRUFBRSxrQkFBa0IsQ0FBQztLQUM5QjtJQUFFLENBQUMsR0FBRyxFQUFFLFNBQVMsR0FBRztHQUN0QjtFQUFFLEdBQUcsS0FBSztHQUFFLGFBQWE7SUFBQztJQUFvQjtJQUFjO0lBQWM7R0FBTTtHQUFHLFFBQVEsU0FBUyxHQUFHO0lBQ3JHLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLGFBQWEsSUFBSSxFQUFFLFFBQVEsS0FBSztLQUNyRCxJQUFjLElBQUksR0FBVixFQUFFLEdBQWEsQ0FBQyxDQUFDO0tBQ3pCLElBQUksR0FBRyxPQUFPO0lBQ2hCO0lBQ0EsT0FBTztHQUNUO0dBQUcsa0JBQWtCLFNBQVMsR0FBRztJQUMvQixJQUFJLElBQUksRUFBRSxhQUFhLElBQUksRUFBRSxXQUFXLElBQUksRUFBRSxhQUFhLElBQUksRUFBRTtJQUNqRSxJQUFJLENBQUMsY0FBYyxLQUFLLENBQUMsR0FBRyxPQUFPO0lBQ25DLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLGFBQWEsTUFBTSxJQUFJLEVBQUUsUUFBUSxLQUFLO0tBQzFELElBQUksSUFBSSxFQUFFLElBQUksSUFBSTtLQUNsQixJQUFJLEVBQUUsY0FBYyxFQUFFLFdBQVcsZUFBZSxFQUFFLGdCQUFnQixHQUFHLE9BQU8sSUFBSztNQUMvRSxJQUFJLE1BQU0sRUFBRSxTQUFTLE9BQU87TUFDNUIsSUFBSSxHQUFHLENBQUM7S0FDVjtJQUNGO0lBQ0EsT0FBTztHQUNUO0dBQUcsWUFBWSxTQUFTLEdBQUc7SUFDekIsSUFBSSxHQUFHLElBQUksRUFBRSxXQUFXLElBQUksRUFBRSxhQUFhLElBQUksRUFBRSxXQUFXLElBQUksRUFBRTtJQUNsRSxJQUFJLE1BQU0sV0FBVyxNQUFNLE9BQU8sT0FBTztJQUN6QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxhQUFhLE1BQU0sSUFBSSxFQUFFLFFBQVEsS0FBSztLQUMxRCxJQUFJLElBQUksRUFBRTtLQUNWLElBQUksRUFBRSxnQkFBZ0IsR0FBRztNQUN2QixJQUFJLEVBQUUsY0FBYyxDQUFDLEdBQUcsR0FBRyxDQUFDLEdBQUc7TUFDL0IsSUFBSSxFQUFFLFlBQVksR0FBRyxPQUFPO01BQzVCLE1BQU0sSUFBSTtLQUNaO0lBQ0Y7SUFDQSxJQUFJLEdBQUcsT0FBTztJQUNkLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLGFBQWEsTUFBTSxJQUFJLEVBQUUsUUFBUSxLQUFLO0tBQzFELElBQUksSUFBSSxFQUFFO0tBQ1YsSUFBSSxFQUFFLEVBQUUsZ0JBQWdCLEtBQUssUUFBUSxLQUFLLENBQUMsS0FBSyxFQUFFLGFBQWEsT0FBTztJQUN4RTtJQUNBLE9BQU87R0FDVDtHQUFHLFlBQVksU0FBUyxHQUFHO0lBQ3pCLEtBQUssSUFBSSxJQUFJLEVBQUUsV0FBVyxJQUFJLEdBQUcsSUFBSSxFQUFFLE1BQU0sYUFBYSxNQUFNLElBQUksRUFBRSxRQUFRLEtBQUs7S0FDakYsSUFBSSxJQUFJLEVBQUU7S0FDVixJQUFJLEdBQUcsR0FBRyxDQUFDLEdBQUcsT0FBTztJQUN2QjtJQUNBLE9BQU87R0FDVDtHQUFHLE1BQU0sU0FBUyxHQUFHO0lBQ25CLEtBQUssSUFBSSxJQUFJLEVBQUUsYUFBYSxJQUFJLEdBQUcsSUFBSSxFQUFFLE1BQU0sYUFBYSxNQUFNLElBQUksRUFBRSxRQUFRLEtBQUs7S0FDbkYsSUFBSSxJQUFJLEVBQUU7S0FDVixJQUFJLEVBQUUsU0FBUyxXQUFXLEdBQUc7TUFDM0IsSUFBSSxJQUFJLEVBQUU7TUFDVixJQUFJLE1BQU0sQ0FBQyxFQUFFLFFBQVEsV0FBVyxDQUFDLEVBQUUsUUFBUSxRQUFRLFVBQVU7S0FDL0QsT0FBTyxJQUFJLEVBQUUsU0FBUyxVQUFVLEdBQUc7S0FDbkMsSUFBSSxDQUFDLEVBQUUsWUFBWSxLQUFLLE1BQU0sRUFBRSxhQUFhLE9BQU87SUFDdEQ7SUFDQSxPQUFPO0dBQ1Q7RUFBRTtFQUNGLFNBQVMsR0FBRyxHQUFHLEdBQUc7R0FDaEIsT0FBTyxFQUFFLFNBQVMsS0FBSyxTQUFTLEdBQUc7SUFDakMsT0FBTyxFQUFFLE9BQU87R0FDbEIsQ0FBQztFQUNIO0VBQ0EsSUFBSSxLQUFLLElBQUksS0FBSztHQUFDO0dBQWU7R0FBZTtHQUFhO0dBQWlCO0dBQWlCO0VBQVk7RUFDNUcsU0FBUyxHQUFHLEdBQUcsR0FBRztHQUNoQixPQUFPLFNBQVMsR0FBRztJQUNqQixJQUFJLElBQUksRUFBRSxhQUFhLE1BQU0sSUFBSSxHQUFHLENBQUMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxHQUFHLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQztJQUM1RSxJQUFJLFNBQVMsS0FBSyxFQUFFLElBQUksR0FBRztLQUN6QixFQUFFLGdCQUFnQixFQUFFLElBQUk7S0FDeEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsZ0JBQWdCLElBQUksRUFBRSxRQUFRLEtBQUs7TUFDdkQsSUFBSSxJQUFJLEVBQUUsSUFBSSxJQUFJO09BQUUsU0FBUztPQUFHLFdBQVcsR0FBRyxDQUFDO09BQUcsYUFBYTtPQUFHLFdBQVcsRUFBRTtPQUFNLGFBQWE7T0FBRyxnQkFBZ0I7T0FBRyxPQUFPO01BQUUsR0FBRyxJQUFJLEdBQUcsQ0FBQztNQUM1SSxFQUFFLEtBQUs7T0FBQyxFQUFFO09BQVMsRUFBRTtPQUFhLEVBQUU7T0FBZ0I7TUFBQyxDQUFDO0tBQ3hEO0lBQ0YsT0FBTztLQUNMLElBQUksSUFBSSxDQUFDO0tBQ1QsSUFBSSxDQUFDLEdBQUcsd0JBQXdCLFFBQVEsS0FBSyxFQUFFLElBQUksR0FBRztNQUNwRCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxVQUFVLENBQUMsR0FBRyxLQUFLLElBQUksRUFBRSxFQUFFLENBQUMsZ0JBQWdCLFdBQVcsRUFBRSxFQUFFLENBQUM7TUFDbEYsSUFBSSxLQUFLLEVBQUUsSUFBSSxJQUFJLEVBQUUsZ0JBQWdCLE9BQU8sRUFBRSxjQUFjO0tBQzlEO0tBQ0EsSUFBSSxDQUFDLEdBQUc7TUFDTixJQUFJLElBQUk7T0FBRSxTQUFTO09BQUcsV0FBVyxHQUFHLENBQUM7T0FBRyxhQUFhO09BQUcsV0FBVyxFQUFFO09BQU0sZ0JBQWdCO09BQUcsYUFBYTtPQUFHLE9BQU87TUFBRSxHQUFHLElBQUksR0FBRyxDQUFDO01BQ2xJLEVBQUUsS0FBSztPQUFDLEVBQUU7T0FBUyxFQUFFO09BQWEsRUFBRTtPQUFnQjtNQUFDLENBQUM7S0FDeEQ7SUFDRjtJQUNBLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FBSztLQUNqQyxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksRUFBRTtLQUN4QyxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQztJQUNwQjtHQUNGO0VBQ0Y7RUFDQSxTQUFTLEdBQUcsR0FBRztHQUNiLElBQUksSUFBSSxFQUFFLGFBQWEsSUFBSSxFQUFFLE9BQU8sSUFBSTtJQUFFLGFBQWEsR0FBRyxPQUFPLENBQUM7SUFBRyxlQUFlO0dBQUU7R0FDdEYsT0FBTyxFQUFFLEtBQUsscUJBQXFCLENBQUMsR0FBRyxFQUFFLGVBQWUsRUFBRSxhQUFhLElBQUksRUFBRSxhQUFhLEVBQUUsQ0FBQztFQUMvRjtFQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUc7R0FDaEIsSUFBSSxJQUFJLEVBQUUsS0FBSyxJQUFJLEVBQUUsT0FBTyxJQUFJLEVBQUUsU0FBUyxJQUFJLEVBQUUsYUFBYSxXQUFXLElBQUksRUFBRSxRQUFRLElBQUksRUFBRTtHQUM3RixLQUFLLElBQUksS0FBSyxFQUFFLFFBQVEsU0FBUyxDQUFDLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSxTQUFTLENBQUMsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUUsR0FBRyxHQUFHLEVBQUUsZ0JBQWdCLEdBQUcsRUFBRSxHQUFHLEdBQUcsRUFBRSxvQkFBb0IsQ0FBQyxDQUFDO0dBQzVKLEtBQUssSUFBSSxJQUFJLEtBQUssRUFBRSxRQUFRLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLO0lBQ3BELElBQUksSUFBSSxFQUFFO0lBQ1YsRUFBRSxHQUFHLEVBQUUsTUFBTSxFQUFFLFVBQVUsQ0FBQztHQUM1QjtFQUNGO0VBQ0EsSUFpRCtELEtBQUs7R0FqRHpELElBQUk7R0FBcUIsU0FBUyxTQUFTLEdBQUc7SUFDdkQsS0FBSyxJQUFJLElBQUksQ0FBQyxHQUFHLElBQUksR0FBRyxJQUFJLEdBQUcsUUFBUSxLQUFLO0tBQzFDLElBQUksSUFBSSxHQUFHO0tBQ1gsRUFBRSxLQUFLLEdBQUcsR0FBRyxDQUFDO0lBQ2hCO0lBQ0EsSUFBSSxHQUFHLElBQUksR0FBRztJQUNkLFNBQVMsSUFBSTtLQUNYLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLGFBQWEsTUFBTSxJQUFJLEVBQUUsUUFBUSxLQUFLO01BQzFELElBQUksSUFBSSxFQUFFO01BQ1YsSUFBSSxFQUFFLGlCQUFpQixFQUFFLGdCQUFnQixXQUFXLENBQUMsRUFBRSxjQUFjLEtBQUssSUFBSSxJQUFJLFdBQVc7T0FDM0YsSUFBSSxJQUFJLEVBQUU7T0FDVixFQUFFLFVBQVUsS0FBSyxTQUFTLEdBQUc7UUFDM0IsT0FBTyxHQUFHLEVBQUUsS0FBSyxFQUFFLFVBQVU7T0FDL0IsQ0FBQyxLQUFLLEVBQUUsY0FBYyxFQUFFLFNBQVMsRUFBRSxLQUFLO01BQzFDLEdBQUcsSUFBSSxHQUFHLElBQUksRUFBRSxVQUFVLElBQUksRUFBRSxRQUFRLEtBQUssRUFBRTtLQUNqRDtJQUNGO0lBQ0EsQ0FBQyxJQUFJLEVBQUUsZUFBZTtLQUFDO01BQUUsTUFBTSxFQUFFO01BQU0sVUFBVTtLQUFFO0tBQUc7TUFBRSxNQUFNLEVBQUU7TUFBTSxVQUFVLEVBQUU7S0FBWTtLQUFHO01BQUUsTUFBTSxFQUFFO01BQU0sVUFBVSxFQUFFO0tBQVk7S0FBRztNQUFFLE1BQU0sRUFBRTtNQUFJLFVBQVUsRUFBRTtLQUFVO0tBQUc7TUFBRSxNQUFNLEVBQUU7TUFBUSxVQUFVLEVBQUU7S0FBVTtJQUFDLElBQUk7S0FBQztNQUFFLE1BQU07TUFBYSxVQUFVLEVBQUU7S0FBWTtLQUFHO01BQUUsTUFBTTtNQUFhLFVBQVUsRUFBRTtLQUFZO0tBQUc7TUFBRSxNQUFNO01BQVcsVUFBVSxFQUFFO0tBQVU7S0FBRztNQUFFLE1BQU07TUFBYyxVQUFVO0tBQUU7S0FBRztNQUFFLE1BQU07TUFBYyxVQUFVLEVBQUU7S0FBWTtLQUFHO01BQUUsTUFBTTtNQUFhLFVBQVUsRUFBRTtLQUFZO0tBQUc7TUFBRSxNQUFNO01BQVksVUFBVSxFQUFFO0tBQVU7S0FBRztNQUFFLE1BQU07TUFBZSxVQUFVLEVBQUU7S0FBVTtJQUFDLEVBQUEsQ0FBRyxLQUFLO0tBQUUsTUFBTTtLQUFRLFVBQVUsU0FBUyxHQUFHO01BQzFuQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxhQUFhLE1BQU0sSUFBSSxFQUFFLFFBQVEsS0FDckQsRUFBRSxFQUFFLENBQUMsYUFBYSxDQUFDO0tBQ3ZCO0lBQUUsQ0FBQyxHQUFHLEVBQUUsZ0JBQWdCLEdBQUcsRUFBRSxjQUFjLFNBQVMsR0FBRztLQUNyRCxFQUFFLEdBQUcsQ0FBQztLQUNOLElBQUksSUFBSSxFQUFFLENBQUM7S0FDWCxTQUFTLElBQUk7TUFDWCxPQUFPLEVBQUUsTUFBTSxDQUFDLEdBQUcsRUFBRSxNQUFNLE1BQU0sU0FBUztLQUM1QztLQUNBLE9BQU8sRUFBRSxHQUFHLENBQUM7TUFBRSxLQUFLO01BQXdCLEtBQUssV0FBVztPQUMxRCxPQUFPLEVBQUUsYUFBYTtNQUN4QjtNQUFHLEtBQUssU0FBUyxHQUFHO09BQ2xCLEVBQUUsYUFBYSx1QkFBdUI7TUFDeEM7S0FBRSxHQUFHO01BQUUsS0FBSztNQUFRLE9BQU8sV0FBVztPQUNwQyxPQUFPLEVBQUUsSUFBSTtNQUNmO0tBQUUsQ0FBQyxDQUFDLEdBQUc7SUFDVCxFQUFFLEVBQUUsR0FBRyxFQUFFLGVBQWU7S0FBRSxNQUFNLENBQUM7S0FBRyxLQUFLLFNBQVMsR0FBRztNQUNuRCxFQUFFLFlBQVksU0FBUyxHQUFHLEdBQUc7T0FDM0IsT0FBTyxFQUFFLEtBQUssR0FBRyxDQUFDO01BQ3BCO01BQ0EsSUFBSSxJQUFJLElBQUksRUFBRSxZQUFZLENBQUM7TUFDM0IsT0FBTyxFQUFFLGFBQWEsS0FBSyxLQUFLLENBQUMsR0FBRztLQUN0QztLQUFHLFdBQVc7S0FBRyxXQUFXO0tBQUcsc0JBQXNCO0lBQUUsR0FBRyxFQUFFLFVBQVUsRUFBRTtHQUMxRTtHQUFHLFdBQVc7SUFBRSxzQkFBc0IsU0FBUyxHQUFHO0tBQ2hELE9BQU8sR0FBRyxHQUFHLEtBQUs7SUFDcEI7SUFBRyx5QkFBeUIsU0FBUyxHQUFHO0tBQ3RDLE9BQU8sR0FBRyxHQUFHLFFBQVE7SUFDdkI7SUFBRyxzQkFBc0IsU0FBUyxHQUFHLEdBQUc7S0FDdEMsS0FBSyxJQUFJLElBQUksRUFBRSxjQUFjLElBQUksRUFBRSxhQUFhLEtBQUssU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO01BQzVFLElBQUksSUFBSSxFQUFFLGFBQWEsS0FBSztNQUM1QixFQUFFLGlCQUFpQixNQUFNLEVBQUUsS0FBSyxHQUFHLEVBQUUsS0FBSyx3QkFBd0IsRUFBRSxhQUFhLEVBQUUsQ0FBQyxHQUFHLEVBQUUsUUFBUSxHQUFHLEVBQUUsYUFBYSxLQUFLLFNBQVMsS0FBSyxFQUFFLGFBQWEsS0FBSyxPQUFPLEdBQUcsQ0FBQztLQUN2SztJQUNGO0dBQUU7R0FBRyxhQUFhO0dBQUksa0JBQWtCO0dBQUksYUFBYTtFQUFZLEdBQUcsS0FBSyxTQUFTLEdBQUc7R0FDdkYsT0FBTyxFQUFFLEVBQUUsS0FBSyxLQUFLLE1BQU0sRUFBRSxFQUFFLE1BQU0sS0FBSyxPQUFPO0VBQ25ELEVBQUUsTUFBTSxDQUFDLENBQUMsR0FBRyxLQUFLLFdBQVc7R0FDM0IsU0FBUyxFQUFFLEdBQUcsR0FBRyxHQUFHLEdBQUc7SUFDckIsRUFBRSxNQUFNLENBQUMsR0FBRyxLQUFLLFNBQVMsS0FBSyxHQUFHLEtBQUssVUFBVSxLQUFLLEdBQUcsS0FBSyxXQUFXLEtBQUssR0FBRyxLQUFLLFNBQVMsSUFBSSxHQUFHLEdBQUcsS0FBSyxXQUFXLEtBQUssR0FBRyxLQUFLLE9BQU8sS0FBSyxHQUFHLEtBQUssT0FBTyxLQUFLLEdBQUcsS0FBSyxlQUFlLEtBQUssR0FBRyxLQUFLLFdBQVcsRUFBRSxTQUFTLEtBQUssU0FBUyxHQUFHLEtBQUssV0FBVyxFQUFFLFdBQVcsR0FBRyxLQUFLLE9BQU8sRUFBRSxHQUFHLENBQUMsSUFBSSxLQUFLLFdBQVcsQ0FBQyxHQUFHLEtBQUssT0FBTyxLQUFLLEtBQUssVUFBVSxLQUFLLGVBQWUsR0FBRyxLQUFLLElBQUksQ0FBQztHQUM5WDtHQUNBLE9BQU8sRUFBRSxHQUFHO0lBQUM7S0FBRSxLQUFLO0tBQWEsS0FBSyxXQUFXO01BQy9DLE9BQU87T0FBRSxNQUFNLENBQUM7T0FBRyxXQUFXLENBQUM7T0FBRyxTQUFTLENBQUM7TUFBRTtLQUNoRDtJQUFFO0lBQUc7S0FBRSxLQUFLO0tBQWUsT0FBTyxTQUFTLEdBQUcsR0FBRztNQUMvQyxPQUFPLEVBQUUsS0FBSyxFQUFFLE9BQU8sS0FBSyxLQUFLLEdBQUcsR0FBRyxPQUFPLEdBQUcsT0FBTyxHQUFHLEVBQUUsT0FBTyxHQUFHLEVBQUUsS0FBSyxFQUFFLE1BQU0sS0FBSyxLQUFLLEdBQUcsR0FBRyxPQUFPLEdBQUcsTUFBTSxHQUFHLEVBQUUsTUFBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLEtBQUssS0FBSyxLQUFLLEdBQUcsR0FBRyxPQUFPLEdBQUcsS0FBSyxHQUFHLEVBQUUsS0FBSyxHQUFHLEVBQUUsS0FBSyxFQUFFLGNBQWMsS0FBSyxLQUFLLEdBQUcsR0FBRyxPQUFPLEdBQUcsY0FBYyxHQUFHLEVBQUUsY0FBYyxHQUFHO0tBQ3JSO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBNEIsT0FBTyxTQUFTLEdBQUcsR0FBRyxHQUFHO01BQy9ELElBQUksR0FBRyxJQUFJLE1BQU0sS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLE9BQU8sT0FBTyxLQUFLLElBQUksRUFBRSxpQkFBaUIsSUFBSSxTQUFTLEdBQUc7T0FDcEcsUUFBUSxLQUFLLFFBQVEsRUFBRSxDQUFDLE1BQU0sR0FBRyxHQUFHLEVBQUUsUUFBUTtNQUNoRDtNQUNBLENBQUMsRUFBRSxNQUFNLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxNQUFNLEtBQUssT0FBTyxHQUFHLEtBQUssR0FBRyxHQUFHLEtBQUssR0FBRyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxNQUFNLEtBQUssT0FBTyxHQUFHLElBQUksR0FBRyxHQUFHLEtBQUssR0FBRyxDQUFDO0tBQ3hJO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBZ0IsT0FBTyxTQUFTLEdBQUcsR0FBRztNQUNoRCxJQUFJLElBQUksS0FBSztNQUNiLEtBQUssSUFBSSxLQUFLLEdBQUc7T0FDZixJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxJQUFJLElBQUksRUFBRTtPQUN0QyxNQUFNLGVBQWUsS0FBSyx5QkFBeUIsR0FBRyxFQUFFLFdBQVcsQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDLElBQUksRUFBRSxLQUFLLEdBQUcsQ0FBQyxJQUFJLEVBQUUsWUFBWSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsRUFBRSxNQUFNLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsT0FBTyxFQUFFLFVBQVUsRUFBRSxLQUFLLGFBQWEsRUFBRSxVQUFVLE9BQU8sRUFBRSxFQUFFLENBQUMsVUFBVSxFQUFFLFlBQVksQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsVUFBVSxFQUFFLElBQUksRUFBRSxFQUFFLENBQUMsVUFBVSxJQUFJLEVBQUUsS0FBSztNQUN4VDtLQUNGO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBVyxPQUFPLFNBQVMsR0FBRztNQUN4QyxPQUFPLElBQUksTUFBTSxFQUFFLFFBQVEsS0FBSyxNQUFNLElBQUksS0FBSyxTQUFTLE9BQU8sRUFBRSxPQUFPLEtBQUssTUFBTSxNQUFNLElBQUksS0FBSyxLQUFLLFNBQVMsY0FBYyxLQUFLLE1BQU0sSUFBSSxHQUFHLENBQUM7S0FDbko7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFlLE9BQU8sU0FBUyxHQUFHO01BQzVDLElBQUksSUFBSTtNQUNSLE9BQU8sRUFBRSxLQUFLLENBQUMsS0FBSyxLQUFLLFVBQVUsU0FBUyxHQUFHO09BQzdDLElBQUksSUFBSSxFQUFFLENBQUMsR0FBRyxFQUFFLE1BQU0sR0FBRyxDQUFDLENBQUM7T0FDM0IsT0FBTyxXQUFXLE1BQU0sRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLE1BQU07TUFDcEYsR0FBRyxRQUFRLE1BQU0sUUFBUSxPQUFPLEtBQUssU0FBUyxRQUFRLEtBQUs7S0FDN0Q7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFxQixPQUFPLFNBQVMsR0FBRyxHQUFHO01BQ3JELElBQUksR0FBRyxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsR0FBRztPQUN4QixLQUFLLElBQUksS0FBSyxLQUFLLFFBQVEsS0FBSyxHQUFHLEtBQUssU0FBUyxLQUFLLEtBQUssUUFBUSxFQUFFLENBQUMsS0FBSztPQUMzRSxPQUFPO01BQ1Q7TUFDQSxPQUFPLEtBQUssUUFBUTtLQUN0QjtJQUFFO0lBQUc7S0FBRSxLQUFLO0tBQVUsT0FBTyxTQUFTLEdBQUc7TUFDdkMsT0FBTyxLQUFLLGtCQUFrQixVQUFVLENBQUM7S0FDM0M7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFlLE9BQU8sU0FBUyxHQUFHO01BQzVDLE9BQU8sTUFBTSxVQUFVLE1BQU0sWUFBWSxLQUFLLFFBQVEsY0FBYyxHQUFHLFFBQVEsS0FBSyxRQUFRO0tBQzlGO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBa0IsT0FBTyxXQUFXO01BQzlDLElBQUksSUFBSSxLQUFLO01BQ2IsT0FBTyxFQUFFLE9BQU8sQ0FBQyxJQUFJLE1BQU0sS0FBSyxLQUFLLFNBQVMsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLEtBQUssRUFBRSxpQkFBaUIsRUFBRSxlQUFlLElBQUksRUFBRSxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDO0tBQ2xKO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBVyxPQUFPLFdBQVc7TUFDdkMsT0FBTyxLQUFLO0tBQ2Q7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFhLE9BQU8sU0FBUyxHQUFHO01BQzFDLE9BQU8sS0FBSyxhQUFhLEVBQUUsaUJBQWlCLEdBQUcsS0FBSyxVQUFVLENBQUM7S0FDakU7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFtQixPQUFPLFNBQVMsR0FBRyxHQUFHLEdBQUc7TUFDdEQsT0FBTyxDQUFDLEtBQUssV0FBVyxFQUFFLFlBQVksR0FBRyxDQUFDLEtBQUssS0FBSyxVQUFVLEVBQUUsV0FBVyxHQUFHLENBQUM7S0FDakY7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFhLE9BQU8sU0FBUyxHQUFHLEdBQUcsR0FBRztNQUNoRCxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxJQUFJLEdBQUcsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQztLQUN2RjtJQUFFO0lBQUc7S0FBRSxLQUFLO0tBQWMsT0FBTyxTQUFTLEdBQUcsR0FBRyxHQUFHO01BQ2pELE9BQU8sRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFFLFFBQVEsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLElBQUksR0FBRyxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxLQUFLLEdBQUcsR0FBRyxDQUFDO0tBQ3pGO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBUSxPQUFPLFNBQVMsR0FBRztNQUNyQyxPQUFPLEtBQUssT0FBTyxLQUFLLENBQUMsR0FBRztLQUM5QjtJQUFFO0lBQUc7S0FBRSxLQUFLO0tBQVUsT0FBTyxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRztNQUNuRCxFQUFFLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRSxNQUFNLENBQUMsTUFBTSxJQUFJLEdBQUcsSUFBSTtNQUMxQyxJQUFJLElBQUksR0FBRyxHQUFHLEdBQUcsQ0FBQztNQUNsQixLQUFLLElBQUksS0FBSyxHQUFHO09BQ2YsTUFBTSxZQUFZLElBQUksR0FBRztPQUN6QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxRQUFRLEtBQUs7UUFDM0MsSUFBSSxJQUFJLEVBQUU7UUFDVixHQUFHLEdBQUcsS0FBSyxRQUFRLElBQUksS0FBSyxPQUFPLE1BQU0sR0FBRyxLQUFLLE9BQU8sTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsT0FBTyxLQUFLLE1BQU0sSUFBSSxLQUFLLGFBQWEsTUFBTSxHQUFHLEtBQUssZ0JBQWdCLGlCQUFpQixDQUFDLEtBQUssUUFBUSxLQUFLLFVBQVUsR0FBRyxHQUFHLENBQUMsSUFBSSxLQUFLLGFBQWEsTUFBTSxHQUFHLEtBQUssUUFBUSxTQUFTLENBQUMsS0FBSyxRQUFRLEdBQUcsR0FBRyxDQUFDO09BQ2hSO01BQ0Y7TUFDQSxPQUFPO0tBQ1Q7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFNLE9BQU8sU0FBUyxHQUFHLEdBQUcsR0FBRztNQUN6QyxPQUFPLEtBQUssT0FBTyxHQUFHLElBQUksR0FBRyxHQUFHLENBQUM7S0FDbkM7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFPLE9BQU8sU0FBUyxHQUFHLEdBQUcsR0FBRztNQUMxQyxPQUFPLEtBQUssT0FBTyxHQUFHLEtBQUssR0FBRyxHQUFHLENBQUM7S0FDcEM7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFPLE9BQU8sU0FBUyxHQUFHO01BQ3BDLElBQUksSUFBSSxLQUFLO01BQ2IsS0FBSyxJQUFJLEtBQUssRUFBRSxPQUFPLENBQUMsTUFBTSxJQUFJLENBQUMsSUFBSSxLQUFLLFVBQVUsR0FBRyxFQUFFLElBQUksR0FBRyxLQUFLLFNBQVMsWUFBWTtPQUMxRixJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssU0FBUyxXQUFXO09BQ3hDLEtBQUssUUFBUSxLQUFLLENBQUMsR0FBRyxLQUFLLGFBQWEsR0FBRyxFQUFFLEVBQUUsQ0FBQyxHQUFHLEVBQUUsU0FBUyxHQUFHLEVBQUUsUUFBUSxFQUFFLENBQUMsR0FBRyxLQUFLLEVBQUUsQ0FBQyxFQUFFLEVBQUU7TUFDL0Y7TUFDQSxLQUFLLElBQUksS0FBSyxHQUFHLE1BQU0sWUFBWSxFQUFFLEtBQUssS0FBSyxFQUFFLEtBQUssS0FBSyxFQUFFLENBQUMsRUFBRSxFQUFFLElBQUksS0FBSyxZQUFZLEVBQUUsT0FBTztNQUNoRyxPQUFPO0tBQ1Q7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFTLE9BQU8sV0FBVztNQUNyQyxJQUFJLEVBQUUsT0FBTyxLQUFLLE1BQU0sR0FBRyxLQUFLLElBQUksS0FBSyxLQUFLLGFBQWEsaUJBQWlCLEtBQUssSUFBSSxJQUFJLEtBQUssYUFBYSxnQkFBZ0IsSUFBSSxJQUFJLEVBQUUsU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO09BQzVKLElBQUksSUFBSSxFQUFFLElBQUksSUFBSSxFQUFFLFVBQVUsSUFBSSxFQUFFLFNBQVMsSUFBSSxFQUFFO09BQ25ELE1BQU0sS0FBSyxVQUFVLE1BQU0sS0FBSyxZQUFZLEVBQUUsT0FBTyxHQUFHLENBQUM7T0FDekQsS0FBSyxJQUFJLElBQUksRUFBRSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUssS0FBSyxhQUFhLGVBQWUsS0FBSyxRQUFRLEtBQUssVUFBVSxHQUFHLEVBQUUsRUFBRSxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsRUFBRTtNQUMxSDtXQUNLLEtBQUssYUFBYSxPQUFPLEtBQUssUUFBUSxLQUFLO0tBQ2xEO0lBQUU7R0FBQyxDQUFDLEdBQUc7RUFDVCxFQUFFLEdBQUcsS0FBSyxXQUFXO0dBQ25CLFNBQVMsRUFBRSxHQUFHO0lBQ1osSUFBSSxJQUFJO0lBQ1IsRUFBRSxNQUFNLENBQUMsR0FBRyxLQUFLLE9BQU8sQ0FBQyxHQUFHLEtBQUssY0FBYyxDQUFDLEdBQUcsS0FBSyxRQUFRLEtBQUssR0FBRyxLQUFLLFFBQVEsR0FBRyxFQUFFLGFBQWEsRUFBRSxzQkFBc0IsU0FBUyxHQUFHO0tBQ3pJLElBQUksSUFBSSxFQUFFLGNBQWMsSUFBSSxFQUFFLFFBQVEsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUUsWUFBWSxLQUFLLEVBQUUsRUFBRSxNQUFNLEtBQUssSUFBSSxHQUFHLEdBQUcsU0FBUyxHQUFHO01BQzlHLE9BQU8sTUFBTTtLQUNmLENBQUM7S0FDRCxFQUFFLE9BQU8sR0FBRyxDQUFDO0lBQ2YsRUFBRSxDQUFDO0dBQ0w7R0FDQSxPQUFPLEVBQUUsR0FBRztJQUFDO0tBQUUsS0FBSztLQUFPLE9BQU8sU0FBUyxHQUFHLEdBQUc7TUFDL0MsSUFBSSxFQUFFLEtBQUssQ0FBQyxHQUFHLEVBQUUsU0FBUyxLQUFLLE1BQU0sUUFBUSxDQUFDO01BQzlDLElBQUksSUFBSSxJQUFJLEtBQUssTUFBTSxhQUFhLEdBQUcsR0FBRyxLQUFLLE1BQU0sVUFBVSxLQUFLLE1BQU0sTUFBTTtNQUNoRixPQUFPLEtBQUssTUFBTSxZQUFZLEVBQUUsSUFBSSxHQUFHLEtBQUssS0FBSyxLQUFLLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQyxLQUFLLEtBQUssWUFBWSxPQUFPLEtBQUssWUFBWSxLQUFLLENBQUMsSUFBSSxLQUFLLFlBQVksRUFBRSxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxLQUFLLE1BQU0sT0FBTyxPQUFPLGVBQWUsR0FBRyxLQUFLLE1BQU0sSUFBSTtPQUFFLE9BQU8sQ0FBQztPQUFHLGNBQWMsQ0FBQztNQUFFLENBQUMsR0FBRyxFQUFFLEtBQUssTUFBTSxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxNQUFNLEtBQUssb0JBQW9CO09BQUUsUUFBUTtPQUFHLFNBQVM7T0FBRyxjQUFjO09BQUcsS0FBSyxLQUFLLE1BQU07TUFBSyxDQUFDLEdBQUc7S0FDclk7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFlLE9BQU8sU0FBUyxHQUFHLEdBQUc7TUFDL0MsSUFBSSxJQUFJLEtBQUssRUFBRSxXQUFXLEtBQUssTUFBTSxVQUFVLElBQUksRUFBRSxPQUFPLENBQUMsR0FBRyxJQUFJLElBQUksS0FBSyxZQUFZLEtBQUssRUFBRSxLQUFLLE1BQU07TUFDM0csSUFBSSxHQUFHLE9BQU8sR0FBRyxHQUFHLFNBQVMsR0FBRztPQUM5QixPQUFPLEVBQUUsYUFBYSxNQUFNLEtBQUssRUFBRSxVQUFVLENBQUM7TUFDaEQsQ0FBQztLQUNIO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBZ0IsT0FBTyxTQUFTLEdBQUcsR0FBRztNQUNoRCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxNQUFNLElBQUksRUFBRSxRQUFRLEtBQUs7T0FDaEQsSUFBSSxJQUFJLEVBQUUsSUFBSSxJQUFJLEtBQUs7T0FDdkIsS0FBSyxFQUFFLE9BQU8sRUFBRSxNQUFNLElBQUksRUFBRSxRQUFRLENBQUMsS0FBSyxHQUFHLEdBQUcsRUFBRSxNQUFNLElBQUksTUFBTSxFQUFFLFdBQVcsRUFBRSxVQUFVLENBQUMsTUFBTSxJQUFJLEVBQUUsQ0FBQyxJQUFJLE1BQU0sS0FBSyxHQUFHLE9BQU87TUFDcEk7S0FDRjtJQUFFO0dBQUMsQ0FBQyxHQUFHO0VBQ1QsRUFBRSxHQUFHLEtBQUssV0FBVztHQUNuQixTQUFTLElBQUk7SUFDWCxJQUFJLElBQUk7SUFDUixFQUFFLE1BQU0sQ0FBQyxHQUFHLEtBQUssS0FBSyxvQkFBb0IsT0FBTyxLQUFLLE1BQU0sTUFBTSxLQUFLLE9BQU8sQ0FBQyxDQUFDLEdBQUcsS0FBSyxnQkFBZ0IsQ0FBQyxHQUFHLEtBQUssZUFBZSxDQUFDLEdBQUcsS0FBSyxVQUFVLElBQUksS0FBSyxXQUFXLEdBQUcsRUFBRSxHQUFHLEtBQUssWUFBWSxJQUFJLEtBQUssVUFBVTtLQUFFLEtBQUssQ0FBQztLQUFHLFFBQVE7TUFBRSxPQUFPLENBQUM7TUFBRyxNQUFNLENBQUM7TUFBRyxLQUFLLENBQUM7S0FBRTtLQUFHLFlBQVksQ0FBQztLQUFHLGdCQUFnQixDQUFDO0lBQUUsR0FBRyxLQUFLLGlCQUFpQixTQUFTLEdBQUc7S0FDOVUsSUFBSSxJQUFJLFNBQVMsRUFBRSxHQUFHLEdBQUc7TUFDdkIsSUFBSSxJQUFJLEVBQUUsY0FBYyxZQUFZLEdBQUcsQ0FBQztNQUN4QyxPQUFPLE1BQU0sQ0FBQyxJQUFJLEVBQUUsY0FBYyxJQUFJLEdBQUcsQ0FBQyxFQUFBLENBQUcsT0FBTyxTQUFTLEVBQUUsZUFBZTtLQUNoRjtLQUNBLE9BQU8sRUFBRSxvQkFBb0IsSUFBSSxFQUFFLGVBQWUsSUFBSSxFQUFFLG1CQUFtQixJQUFJLEVBQUUsZ0JBQWdCLElBQUksRUFBRSxpQkFBaUIsSUFBSSxFQUFFLHVCQUF1QixJQUFJLEVBQUUsa0JBQWtCLElBQUksRUFBRSxVQUFVLElBQUksRUFBRSxlQUFlLENBQUMsR0FBRyxFQUFFLFVBQVUsV0FBVyxFQUFFLFFBQVEsR0FBRyxFQUFFLE1BQU0sU0FBUyxHQUFHLEdBQUc7TUFDL1EsT0FBTyxLQUFLLE1BQU0sVUFBVSxHQUFHLENBQUMsR0FBRztLQUNyQyxHQUFHLEVBQUUsUUFBUSxTQUFTLEdBQUcsR0FBRztNQUMxQixPQUFPLENBQUMsQ0FBQyxLQUFLLE1BQU0sY0FBYyxJQUFJLEdBQUcsS0FBSyxFQUFFLE9BQU87S0FDekQsR0FBRyxFQUFFLEtBQUssR0FBRyxTQUFTLEdBQUcsR0FBRyxHQUFHO01BQzdCLElBQUksRUFBRSxPQUFPLENBQUMsS0FBSyxFQUFFLE9BQU8sR0FBRyxNQUFNLE9BQU8sSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDLE1BQU0sSUFBSSxJQUFJLEVBQUUsTUFBTSxDQUFDLEdBQUc7T0FDakYsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FBSztRQUN4QyxJQUFJLElBQUksRUFBRTtRQUNWLEtBQUssR0FBRyxHQUFHLEdBQUcsQ0FBQztPQUNqQjtPQUNBLE9BQU87TUFDVDtNQUNBLElBQUksRUFBRSxPQUFPLENBQUMsR0FBRztPQUNmLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxHQUFHLEdBQUcsRUFBRSxJQUFJLENBQUM7T0FDbkMsT0FBTztNQUNUO01BQ0EsT0FBTyxHQUFHLEdBQUcsS0FBSyxNQUFNLE9BQU8sSUFBSSxLQUFLLGFBQWEsS0FBSyxLQUFLLGFBQWEsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssYUFBYSxLQUFLLENBQUMsQ0FBQyxJQUFJLEtBQUssTUFBTSxPQUFPLElBQUksS0FBSyxNQUFNLFVBQVUsR0FBRyxHQUFHLEVBQUUsU0FBUyxFQUFFLENBQUMsR0FBRztLQUMxTCxHQUFHLDhDQUE4QyxHQUFHLEVBQUUsTUFBTSxHQUFHLFNBQVMsR0FBRyxHQUFHLEdBQUc7TUFDL0UsSUFBSSxFQUFFLE9BQU8sQ0FBQyxLQUFLLEVBQUUsT0FBTyxHQUFHLE1BQU0sT0FBTyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUMsTUFBTSxJQUFJLElBQUksRUFBRSxNQUFNLENBQUMsR0FBRztPQUNqRixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLO1FBQ3hDLElBQUksSUFBSSxFQUFFO1FBQ1YsS0FBSyxJQUFJLEdBQUcsR0FBRyxDQUFDO09BQ2xCO09BQ0EsT0FBTztNQUNUO01BQ0EsSUFBSSxFQUFFLE9BQU8sQ0FBQyxHQUFHO09BQ2YsS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLElBQUksR0FBRyxFQUFFLElBQUksQ0FBQztPQUNwQyxPQUFPO01BQ1Q7TUFDQSxJQUFJO01BQ0osT0FBTyxHQUFHLEdBQUcsS0FBSyxNQUFNLE9BQU8sSUFBSSxLQUFLLEtBQUssaUJBQWlCLElBQUksS0FBSyxhQUFhLEVBQUUsQ0FBQyxRQUFRLENBQUMsT0FBTyxNQUFNLEtBQUssYUFBYSxFQUFFLENBQUMsT0FBTyxHQUFHLENBQUMsSUFBSSxLQUFLLE1BQU0sT0FBTyxPQUFPLEtBQUssTUFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDLEdBQUc7S0FDM00sR0FBRywrQ0FBK0MsR0FBRyxFQUFFLFFBQVEsV0FBVztNQUN4RSxPQUFPLEtBQUs7S0FDZCxHQUFHLEVBQUUsZ0JBQWdCLFdBQVc7TUFDOUIsT0FBTyxHQUFHO0tBQ1osR0FBRyxFQUFFLHVCQUF1QixXQUFXO01BQ3JDLE9BQU8sR0FBRztLQUNaLEdBQUcsRUFBRSxPQUFPLFdBQVc7TUFDckIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssTUFBTSxhQUFhLE1BQU0sSUFBSSxFQUFFLFFBQVEsS0FBSyxFQUFFLEVBQUUsQ0FBQyxLQUFLO01BQy9FLE9BQU87S0FDVCxHQUFHLEVBQUUsdUJBQXVCLFNBQVMsR0FBRztNQUN0QyxPQUFPLEVBQUUsT0FBTyxDQUFDLEtBQUssS0FBSyxNQUFNLGFBQWEsdUJBQXVCLEdBQUcsUUFBUSxLQUFLLE1BQU0sYUFBYTtLQUMxRyxHQUFHLEVBQUUsY0FBYyxTQUFTLEdBQUcsR0FBRztNQUNoQyxLQUFLLE1BQU0sWUFBWSxHQUFHLENBQUM7S0FDN0IsR0FBRyxFQUFFLGlCQUFpQixTQUFTLEdBQUc7TUFDaEMsS0FBSyxNQUFNLGVBQWUsQ0FBQztLQUM3QixHQUFHO0lBQ0wsRUFBRSxJQUFJLEdBQUcsS0FBSyxnQkFBZ0IsSUFBSSxLQUFLLGVBQWUsS0FBSyxHQUFHLEtBQUssZ0JBQWdCLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSyxPQUFPLEtBQUssR0FBRyxLQUFLLFdBQVcsS0FBSyxHQUFHLEtBQUssU0FBUyxLQUFLLEdBQUcsS0FBSyxZQUFZLENBQUMsR0FBRyxLQUFLLFdBQVc7S0FBRSxNQUFNLENBQUM7S0FBRyxLQUFLLENBQUM7SUFBRSxHQUFHLEtBQUssaUJBQWlCLFNBQVMsR0FBRztLQUMvUCxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU07SUFDbEM7SUFDQSxJQUFJLElBQUk7SUFDUixLQUFLLGVBQWUsU0FBUyxHQUFHO0tBQzlCLEVBQUUsR0FBRyxDQUFDO0tBQ04sSUFBSSxJQUFJLEVBQUUsQ0FBQztLQUNYLFNBQVMsSUFBSTtNQUNYLE9BQU8sRUFBRSxNQUFNLENBQUMsR0FBRyxFQUFFLE1BQU0sTUFBTSxTQUFTO0tBQzVDO0tBQ0EsT0FBTyxFQUFFLEdBQUc7TUFBQztPQUFFLEtBQUs7T0FBYSxLQUFLLFdBQVc7UUFDL0MsT0FBTyxFQUFFO09BQ1g7TUFBRTtNQUFHO09BQUUsS0FBSztPQUFPLE9BQU8sU0FBUyxHQUFHO1FBQ3BDLE9BQU8sRUFBRSxFQUFFLEVBQUUsU0FBUyxHQUFHLE9BQU8sSUFBSSxDQUFDLENBQUMsS0FBSyxNQUFNLENBQUMsR0FBRyxFQUFFLEtBQUssb0JBQW9CO1NBQUUsU0FBUztTQUFHLGNBQWM7UUFBSyxDQUFDLEdBQUc7T0FDdkg7TUFBRTtNQUFHO09BQUUsS0FBSztPQUFTLE9BQU8sV0FBVztRQUNyQyxFQUFFLEVBQUUsRUFBRSxTQUFTLEdBQUcsU0FBUyxJQUFJLENBQUMsQ0FBQyxLQUFLLElBQUk7UUFDMUMsSUFBSSxJQUFJLEVBQUUsY0FBYyxLQUFLLFFBQVEsSUFBSTtRQUN6QyxJQUFJLE1BQU0sRUFBRSxjQUFjLEtBQUssT0FBTyxHQUFHLENBQUMsR0FBRyxFQUFFLEtBQUssc0JBQXNCLEVBQUUsY0FBYyxLQUFLLENBQUM7T0FDbEc7TUFBRTtLQUFDLENBQUMsR0FBRztJQUNULEVBQUUsRUFBRTtHQUNOO0dBQ0EsT0FBTyxFQUFFLEdBQUc7SUFBQztLQUFFLEtBQUs7S0FBZ0IsT0FBTyxTQUFTLEdBQUcsR0FBRztNQUN4RCxLQUFLLGFBQWEsS0FBSztPQUFFLElBQUk7T0FBRyxLQUFLO01BQUUsQ0FBQztLQUMxQztJQUFFO0lBQUc7S0FBRSxLQUFLO0tBQVEsT0FBTyxTQUFTLEdBQUcsR0FBRztNQUN4QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxjQUFjLElBQUksRUFBRSxRQUFRLEtBQUs7T0FDeEQsSUFBSSxJQUFJLEVBQUUsRUFBRSxDQUFDLElBQUk7T0FDakIsSUFBSSxLQUFLLEVBQUUsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDO01BQ3pDO0tBQ0Y7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFRLE9BQU8sU0FBUyxHQUFHO01BQ3JDLE9BQU8sS0FBSyxnQkFBZ0IsT0FBTyxTQUFTLEdBQUcsR0FBRztPQUNoRCxPQUFPLEVBQUUsZ0JBQWdCLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLEdBQUcsR0FBRyxLQUFLLENBQUMsR0FBRyxHQUFHLEtBQUssQ0FBQyxHQUFHLEVBQUUsU0FBUyxHQUFHLEVBQUUsV0FBVyxFQUFFLFVBQVUsRUFBRSxVQUFVLEVBQUUsR0FBRyxFQUFFLFVBQVUsRUFBRSxHQUFHO01BQ2hLLEVBQUUsTUFBTSxDQUFDO0tBQ1g7SUFBRTtJQUFHO0tBQUUsS0FBSztLQUFxQixPQUFPLFNBQVMsR0FBRztNQUNsRCxJQUFJLElBQUksRUFBRTtNQUNWLE9BQU8sSUFBSSxDQUFDLENBQUMsS0FBSyxTQUFTLElBQUksS0FBSyxLQUFLLFNBQVMsS0FBSyxRQUFRLENBQUMsTUFBTTtLQUN4RTtJQUFFO0lBQUc7S0FBRSxLQUFLO0tBQWEsT0FBTyxTQUFTLEdBQUcsR0FBRztNQUM3QyxJQUFJLENBQUMsS0FBSyxlQUFlLE9BQU87TUFDaEMsSUFBSSxLQUFLLGtCQUFrQixDQUFDLEdBQUcsT0FBTztNQUN0QyxJQUFJLEVBQUUsT0FBTyxLQUFLLFNBQVMsSUFBSSxFQUFFLE1BQU0sSUFBSSxLQUFLLFNBQVMsS0FBSyxLQUFLLENBQUMsR0FBRyxFQUFFLFdBQVcsRUFBRSxRQUFRLE1BQU0sQ0FBQyxHQUFHLEVBQUUsYUFBYSxFQUFFLFFBQVE7T0FDL0gsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssYUFBYSxRQUFRLElBQUksRUFBRSxPQUFPLE9BQU8sU0FBUyxHQUFHLEdBQUc7UUFDL0UsT0FBTyxFQUFFLEtBQUssQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHO09BQ25DLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxHQUFHLEtBQUs7UUFDbEIsSUFBSSxJQUFJLEtBQUssYUFBYSxFQUFFLENBQUM7UUFDN0IsSUFBSSxNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUcsQ0FBQyxLQUFLO09BQy9CO09BQ0EsS0FBSyxhQUFhLE9BQU8sR0FBRyxHQUFHO1FBQUUsSUFBSSxFQUFFO1FBQUksS0FBSyxFQUFFO09BQVUsQ0FBQztNQUMvRCxPQUFPLEVBQUUsYUFBYSxLQUFLLGFBQWEsS0FBSztPQUFFLElBQUksRUFBRTtPQUFJLEtBQUssRUFBRTtNQUFVLENBQUM7TUFDM0UsT0FBTztLQUNUO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBZSxPQUFPLFNBQVMsR0FBRyxHQUFHO01BQy9DLElBQUksS0FBSyxZQUFZLENBQUMsTUFBTSxJQUFJLE9BQU8sQ0FBQztNQUN4QyxJQUFJLElBQUksRUFBRSxDQUFDO01BQ1gsSUFBSSxJQUFJLEVBQUUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsS0FBSyxVQUFVLEtBQUs7T0FBRSxLQUFLO09BQUcsU0FBUztNQUFFLENBQUMsR0FBRyxLQUFLLE9BQU8sVUFBVSxLQUFLLENBQUMsR0FBRyxNQUFNLEtBQUssWUFBWSxLQUFLLE9BQU8sSUFBSSxHQUFHLFVBQVUsS0FBSyxjQUFjLEdBQUcsS0FBSyxLQUFLLHNCQUFzQjtPQUFFLEtBQUs7T0FBRyxRQUFRO09BQUcsT0FBTztPQUFNLFNBQVM7TUFBRSxDQUFDO0tBQzdQO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBa0IsT0FBTyxTQUFTLEdBQUc7TUFDL0MsSUFBSSxJQUFJLEtBQUssWUFBWSxDQUFDLEdBQUcsSUFBSSxFQUFFLENBQUMsR0FBRyxJQUFJLEtBQUssVUFBVSxFQUFFLENBQUM7TUFDN0QsS0FBSyxPQUFPLE9BQU8sR0FBRyxVQUFVLEtBQUssY0FBYyxHQUFHLEtBQUssVUFBVSxPQUFPLEdBQUcsQ0FBQyxHQUFHLEtBQUssT0FBTyxVQUFVLE9BQU8sR0FBRyxDQUFDLEdBQUcsS0FBSyxLQUFLLHlCQUF5QjtPQUFFLEtBQUs7T0FBRyxRQUFRO09BQUcsT0FBTztPQUFNLFNBQVM7TUFBRSxDQUFDO0tBQzFNO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBZSxPQUFPLFNBQVMsR0FBRztNQUM1QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxVQUFVLFFBQVEsS0FBSyxJQUFJLEtBQUssVUFBVSxFQUFFLENBQUMsUUFBUSxHQUFHLE9BQU87TUFDeEYsT0FBTztLQUNUO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBaUIsT0FBTyxTQUFTLEdBQUc7TUFDOUMsSUFBSSxJQUFJLEtBQUssWUFBWSxDQUFDO01BQzFCLE9BQU8sTUFBTSxLQUFLLE9BQU8sS0FBSyxVQUFVLEVBQUUsQ0FBQztLQUM3QztJQUFFO0lBQUc7S0FBRSxLQUFLO0tBQU8sT0FBTyxXQUFXO01BQ25DLFFBQVEsS0FBSyxPQUFPLFFBQVEsS0FBQSxDQUFNLElBQUk7S0FDeEM7SUFBRTtHQUFDLENBQUMsR0FBRztFQUNULEVBQUU7RUFDRixTQUFTLEdBQUcsR0FBRztHQUNiLE9BQU8sS0FBSyxFQUFFLFFBQVEsU0FBUyxFQUFFO0VBQ25DO0VBQ0EsSUFBSSxLQUFLLElBQUksR0FBRyxHQUFHLEtBQUssR0FBRyxnQkFBZ0IsS0FBSyxPQUFPLGFBQWEsTUFBTSxhQUFhO0VBQ3ZGLEdBQUcsS0FBSyxFQUFFO0VBQ1YsSUFBSSxLQUFLLE9BQU8sT0FBTztHQUFFLFdBQVc7R0FBTSxZQUFZLFdBQVcsQ0FDakU7R0FBRyxVQUFVLFdBQVcsQ0FDeEI7R0FBRyxNQUFNLFNBQVMsR0FBRztJQUNuQixJQUFJLElBQUk7S0FBQyxDQUFDLEtBQUssR0FBRztLQUFHLENBQUMsUUFBUSxLQUFLO0tBQUcsQ0FBQyxTQUFTLFFBQVE7S0FBRyxDQUFDLFNBQVMsUUFBUTtJQUFDLENBQUMsQ0FBQyxPQUFPLFNBQVMsR0FBRztLQUNqRyxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksRUFBRTtLQUNwQixPQUFPLEtBQUssS0FBSyxLQUFLO0lBQ3hCLENBQUMsR0FBRyxJQUFJLFNBQVMsR0FBRyxHQUFHO0tBQ3JCLEtBQUssSUFBSSxJQUFJLEVBQUUsT0FBTyxJQUFJLEVBQUUsUUFBUSxJQUFJLE1BQU0sS0FBSyxJQUFJO01BQUUsTUFBTSxLQUFLO01BQUcsT0FBTyxJQUFJO01BQUcsS0FBSyxLQUFLO01BQUcsUUFBUSxJQUFJO0tBQUUsSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLElBQUksTUFBTSxLQUFLLElBQUk7TUFBRSxHQUFHO01BQUcsR0FBRztLQUFFLElBQUksR0FBRyxJQUFJO01BQUUsT0FBTztNQUFHLE1BQU07TUFBRyxHQUFHO01BQU0sR0FBRztLQUFLLEdBQUcsSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLEtBQUs7TUFDalAsSUFBSSxJQUFJLEVBQUUsSUFBSSxJQUFJLEVBQUUsSUFBSSxJQUFJLEVBQUUsSUFBSSxJQUFJLEtBQUssT0FBTyxJQUFJLEVBQUUsS0FBSyxFQUFFLEVBQUUsR0FBRyxJQUFJLEtBQUssT0FBTyxJQUFJLEVBQUUsS0FBSyxFQUFFLEVBQUU7TUFDbkcsRUFBRSxLQUFLLEtBQUssSUFBSSxFQUFFLE1BQU0sS0FBSyxJQUFJLEVBQUUsT0FBTyxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQyxHQUFHLEVBQUUsS0FBSyxLQUFLLElBQUksRUFBRSxLQUFLLEtBQUssSUFBSSxFQUFFLFFBQVEsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7S0FDdkg7S0FDQSxPQUFPO0lBQ1Q7SUFDQSxPQUFPLEVBQUUsT0FBTyxHQUFHLEVBQUUsY0FBYyxHQUFHO0dBQ3hDO0VBQUUsQ0FBQyxHQUdFLEtBQUs7R0FIRyxJQUFJO0dBQVksU0FBUyxTQUFTLEdBQUc7SUFDaEQsSUFBSSxJQUFJLEVBQUU7SUFDVixFQUFFLFdBQVcsRUFBRSxFQUFFLFlBQVksQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLGlCQUFpQixFQUFFLFNBQVM7R0FDdEU7RUFBVyxHQUFHLEtBQUs7R0FBRSxPQUFPLFNBQVMsR0FBRztJQUN0QyxJQUFJLElBQUksRUFBRSxPQUFPLElBQUksRUFBRSxNQUFNLElBQUksRUFBRSxPQUFPLElBQUksRUFBRSxZQUFZLElBQUksRUFBRSxTQUFTLElBQUksRUFBRSxPQUFPLElBQUksRUFBRSxTQUFTLElBQUksRUFBRSxTQUFTLElBQUksRUFBRSxZQUFZLElBQUksRUFBRTtJQUM5SSxNQUFNLGVBQWUsSUFBSSxFQUFFLFFBQVEsRUFBRSxTQUFTLEVBQUUsY0FBYyxFQUFFLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxZQUFZLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLFFBQVEsR0FBRyxFQUFFLGFBQWE7SUFDNUgsSUFBSSxJQUFJLEVBQUUsY0FBYztLQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsUUFBUSxDQUFDLEVBQUU7S0FBUSxNQUFNLEVBQUUsUUFBUSxFQUFFLE9BQU8sQ0FBQyxFQUFFO0tBQU8sUUFBUSxFQUFFLFVBQVUsRUFBRSxTQUFTLENBQUMsRUFBRTtLQUFLLE9BQU8sRUFBRSxTQUFTLEVBQUUsVUFBVSxDQUFDLEVBQUU7SUFBSztJQUM3SyxJQUFJLEVBQUUsaUJBQWlCLEVBQUUsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxFQUFFLFFBQVEsRUFBRSxZQUFZO0tBQzNELElBQUksS0FBSyxFQUFFLE9BQU8sSUFBSSxPQUFPLEVBQUUsTUFBTSxJQUFJO0tBQ3pDLEVBQUUsV0FBVztNQUFFO01BQUcsR0FBRztLQUFFO0lBQ3pCLE9BQU8sRUFBRSxXQUFXO0tBQUUsR0FBRyxFQUFFLE9BQU8sS0FBSztLQUFHLEdBQUcsRUFBRSxNQUFNLEtBQUs7SUFBRTtJQUM1RCxJQUFJLE1BQU0sQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUcsS0FBSyxRQUFRLEVBQUUsUUFBUTtLQUM5QyxJQUFJLElBQUksSUFBSSxHQUFHLEVBQUUsV0FBVztLQUM1QixFQUFFLFNBQVMsRUFBRSxZQUFZLFlBQVksR0FBRyxFQUFFLGNBQWMsQ0FBQyxHQUFHLEVBQUUsa0JBQWtCLEdBQUcsRUFBRSxTQUFTLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUN4RztHQUNGO0dBQUcsS0FBSyxTQUFTLEdBQUc7SUFDbEIsSUFBSSxJQUFJLEVBQUUsT0FBTyxJQUFJLEVBQUUsTUFBTSxJQUFJLEVBQUUsUUFBUSxJQUFJLEVBQUUsYUFBYSxJQUFJLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLEVBQUUsYUFBYSxLQUFLO0lBQ3BHLElBQUksRUFBRSxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLGdCQUFnQixHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUUsaUJBQWlCLE9BQU87SUFDNUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxHQUFHLENBQUM7SUFDZixHQUFHLEdBQUcsR0FBRztLQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUU7S0FBRyxHQUFHLEVBQUUsSUFBSSxFQUFFO0lBQUUsQ0FBQztJQUN2QyxJQUFJLElBQUksRUFBRSxnQkFBZ0IsT0FBTyxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUc7S0FBRSxNQUFNO0tBQUcsT0FBTztLQUFHLFlBQVk7S0FBRyxZQUFZO0tBQUcsVUFBVTtJQUFFLENBQUMsQ0FBQyxHQUFHLElBQUksRUFBRTtJQUMzSCxPQUFPLEVBQUUsWUFBWSxFQUFFLEdBQUcsS0FBSyxJQUFJLEVBQUUsQ0FBQyxJQUFJLEtBQUssSUFBSSxFQUFFLENBQUMsR0FBRyxFQUFFLFFBQVEsRUFBRSxJQUFJLEdBQUcsRUFBRSxHQUFHLEVBQUUsTUFBTSxJQUFJLEVBQUU7R0FDakc7R0FBRyxVQUFVO0lBQUUsT0FBTztJQUFZLFlBQVksQ0FBQztJQUFHLFdBQVcsQ0FBQztJQUFHLFNBQVMsQ0FBQztHQUFFO0VBQUU7RUFDL0UsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHO0dBQ25CLElBQUksSUFBSSxFQUFFLGFBQWEsSUFBSSxFQUFFO0dBQzdCLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRTtFQUNsRTtFQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0dBQ3RCLElBQUksSUFBSSxFQUFFLFdBQVcsSUFBSSxFQUFFLGFBQWEsSUFBSSxFQUFFLE9BQU8sSUFBSSxFQUFFO0dBQzNELElBQUksR0FBRztJQUNMLElBQUksSUFBSSxFQUFFLFFBQVE7SUFDbEIsRUFBRSxJQUFJLEVBQUUsS0FBSyxJQUFJLEVBQUUsVUFBVSxFQUFFO0dBQ2pDLE9BQU87SUFDTCxJQUFJLElBQUksRUFBRSxTQUFTO0lBQ25CLEVBQUUsSUFBSSxFQUFFLEtBQUssSUFBSSxFQUFFLFNBQVMsRUFBRTtHQUNoQztFQUNGO0VBQ0EsSUFBSSxLQUFLLEdBQUcsSUFBSSxhQUFhLEdBQUcsS0FBSyxXQUFXLENBQ2hEO0VBQ0EsR0FBRyxZQUFZLENBQUM7RUFDaEIsSUFBSSxLQUFLO0VBQ1QsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHO0dBQ25CLE9BQU8sRUFBRSxLQUFLLENBQUMsSUFBSSxHQUFHLEdBQUcsRUFBRSxjQUFjLEVBQUUsU0FBUztJQUFDLEVBQUU7SUFBRyxFQUFFO0lBQUc7R0FBQyxDQUFDLElBQUksR0FBRyxHQUFHLEVBQUUsY0FBYyxFQUFFLE9BQU87RUFDdEc7RUFDQSxJQUFJLEtBQUs7R0FBRSxPQUFPLFNBQVMsR0FBRztJQUM1QixJQUFJLElBQUksRUFBRSxNQUFNLElBQUksRUFBRSxhQUFhLElBQUksRUFBRSxPQUFPLElBQUksRUFBRSxhQUFhLElBQUksRUFBRSxZQUFZLElBQUksRUFBRSxTQUFTLElBQUksRUFBRSxhQUFhLElBQUksRUFBRTtLQUFFLE1BQU07S0FBRyxLQUFLO0tBQUcsT0FBTztLQUFHLFFBQVE7SUFBRSxHQUFHLEVBQUUsVUFBVSxDQUFDLENBQUM7SUFDckwsSUFBSSxLQUFLLEdBQUc7S0FDVixJQUFJLElBQUksR0FBRyxFQUFFLGFBQWEsR0FBRyxDQUFDO0tBQzlCLElBQUksR0FBRztNQUNMLElBQUksSUFBSSxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUUsT0FBTyxJQUFJLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRTtNQUM3RCxJQUFJLE1BQU0sRUFBRSxRQUFRLEdBQUcsRUFBRSxTQUFTLElBQUksSUFBSSxNQUFNLEVBQUUsT0FBTyxHQUFHLEVBQUUsVUFBVTtLQUMxRTtLQUNBLEVBQUUsUUFBUSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLFNBQVMsSUFBSSxFQUFFLFFBQVEsRUFBRSxVQUFVLEVBQUUsU0FBUyxFQUFFLFVBQVUsSUFBSSxFQUFFO0lBQ2pLO0lBQ0EsRUFBRSxTQUFTO0dBQ2I7R0FBRyxLQUFLLFNBQVMsR0FBRztJQUNsQixJQUFJLElBQUksRUFBRSxRQUFRLElBQUksRUFBRSxhQUFhLElBQUksRUFBRSxPQUFPLElBQUksRUFBRSxTQUFTLElBQUksRUFBRSxRQUFRLElBQUksR0FBRyxFQUFFLGFBQWEsR0FBRyxDQUFDO0lBQ3pHLElBQUksR0FBRztLQUNMLElBQUksSUFBSSxTQUFTLEdBQUc7TUFDbEIsT0FBTyxDQUFDLEtBQUssVUFBVSxLQUFLLFNBQVMsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFBLENBQUcsT0FBTyxFQUFFLEtBQUssR0FBRyxFQUFFLE1BQU0sRUFBRSxLQUFLLEdBQUcsRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUsU0FBUztLQUNoTCxFQUFFLENBQUM7S0FDSCxFQUFFLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUUsQ0FBQyxHQUFHLEVBQUUsT0FBTyxFQUFFLElBQUksR0FBRyxFQUFFLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxFQUFFLFNBQVMsRUFBRSxRQUFRLEVBQUUsQ0FBQyxHQUFHLEVBQUUsTUFBTSxFQUFFLEdBQUc7SUFDckk7R0FDRjtHQUFHLFVBQVU7SUFBRSxhQUFhO0lBQU0sYUFBYTtJQUFNLFFBQVE7SUFBTSxTQUFTLENBQUM7SUFBRyxTQUFTLENBQUM7R0FBRTtFQUFFLEdBQUcsS0FBSyxHQUFHLElBQUksVUFBVSxHQUFHLEtBQUs7R0FBRSxLQUFLLElBQUk7R0FBRyxNQUFNLElBQUk7R0FBRyxRQUFRLEtBQUs7R0FBRyxPQUFPLEtBQUs7RUFBRSxHQUFHLEtBQUs7R0FBRSxLQUFLLEtBQUs7R0FBRyxNQUFNLEtBQUs7R0FBRyxRQUFRLElBQUk7R0FBRyxPQUFPLElBQUk7RUFBRTtFQUN6UCxTQUFTLEdBQUcsR0FBRyxHQUFHO0dBQ2hCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSTtJQUFDO0lBQU87SUFBUTtJQUFVO0dBQU8sR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLO0lBQ3pFLElBQUksSUFBSSxFQUFFO0lBQ1YsS0FBSyxNQUFNLEVBQUUsS0FBSyxFQUFFO0dBQ3RCO0dBQ0EsT0FBTztFQUNUO0VBQ0EsSUFBSSxLQUFLO0dBQUUsU0FBUztHQUFJLFNBQVM7R0FBSSxPQUFPLFNBQVMsR0FBRztJQUN0RCxJQUFJLEdBQUcsSUFBSSxFQUFFLGFBQWEsSUFBSSxFQUFFLGFBQWEsSUFBSSxFQUFFLE9BQU8sSUFBSSxFQUFFO0lBQ2hFLE1BQU0sSUFBSSxHQUFHLEdBQUcsRUFBRSxRQUFRLEdBQUcsRUFBRSxPQUFPLE1BQU0sSUFBSSxDQUFDLElBQUksSUFBSSxLQUFLO0tBQUUsR0FBRztLQUFHLEdBQUc7SUFBRSxHQUFHLEVBQUUsU0FBUztLQUFFLEtBQUssRUFBRSxJQUFJLEVBQUU7S0FBSyxNQUFNLEVBQUUsSUFBSSxFQUFFO0tBQU0sUUFBUSxFQUFFLElBQUksRUFBRTtLQUFRLE9BQU8sRUFBRSxJQUFJLEVBQUU7SUFBTTtHQUNoTDtHQUFHLEtBQUssU0FBUyxHQUFHO0lBQ2xCLElBQUksSUFBSSxFQUFFLFFBQVEsSUFBSSxFQUFFLE9BQU8sSUFBSSxFQUFFLGFBQWEsSUFBSSxFQUFFLE9BQU8sSUFBSSxFQUFFLFFBQVEsSUFBSSxFQUFFO0lBQ25GLElBQUksR0FBRztLQUNMLElBQUksSUFBSSxFQUFFLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxHQUFHLEVBQUUsT0FBTyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxHQUFHLEVBQUUsT0FBTyxHQUFHLENBQUMsS0FBSyxDQUFDO0tBQ3pFLEdBQUcsR0FBRyxFQUFFLEdBQUcsR0FBRyxHQUFHLEVBQUUsR0FBRyxFQUFFLE1BQU0sRUFBRSxJQUFJLEtBQUssSUFBSSxLQUFLLElBQUksRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLENBQUMsR0FBRyxFQUFFLE1BQU0sRUFBRSxHQUFHLElBQUksRUFBRSxXQUFXLEVBQUUsSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUUsTUFBTSxJQUFJLEVBQUUsT0FBTyxFQUFFLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsQ0FBQyxHQUFHLEVBQUUsT0FBTyxFQUFFLElBQUksSUFBSSxFQUFFLFVBQVUsRUFBRSxJQUFJLEtBQUssSUFBSSxLQUFLLElBQUksRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLENBQUMsR0FBRyxFQUFFLFFBQVEsRUFBRSxLQUFLO0lBQzlVO0dBQ0Y7R0FBRyxVQUFVO0lBQUUsT0FBTztJQUFNLE9BQU87SUFBTSxRQUFRO0lBQU0sU0FBUyxDQUFDO0lBQUcsU0FBUyxDQUFDO0dBQUU7RUFBRSxHQUFHLEtBQUssR0FBRyxJQUFJLGVBQWUsR0FBRyxLQUFLLEVBQUU7R0FBRSxJQUFJLGNBQWM7SUFDNUksT0FBTztLQUFFLEtBQUs7S0FBRyxNQUFNO0tBQUcsUUFBUTtLQUFHLE9BQU87SUFBRTtHQUNoRDtHQUFHLElBQUksWUFBWSxHQUFHLENBQ3RCO0VBQUUsR0FBRyxHQUFHLFFBQVEsR0FBRyxLQUFLLEdBQUc7R0FBRSxPQUFPLEdBQUc7R0FBTyxLQUFLLEdBQUc7R0FBSyxVQUFVO0VBQUcsR0FBRyxjQUFjLEdBQUcsS0FBSztHQUFFLE9BQU8sS0FBSztHQUFHLFFBQVEsS0FBSztFQUFFLEdBQUcsS0FBSztHQUFFLE9BQU8sSUFBSTtHQUFHLFFBQVEsSUFBSTtFQUFFLEdBQUcsS0FBSyxHQUFHO0dBQUUsT0FBTyxTQUFTLEdBQUc7SUFDck0sT0FBTyxHQUFHLE1BQU0sQ0FBQztHQUNuQjtHQUFHLEtBQUssU0FBUyxHQUFHO0lBQ2xCLElBQUksSUFBSSxFQUFFLGFBQWEsSUFBSSxFQUFFLE9BQU8sSUFBSSxFQUFFLE1BQU0sSUFBSSxFQUFFLE9BQU8sSUFBSSxFQUFFO0lBQ25FLElBQUksR0FBRztLQUNMLElBQUksSUFBSSxHQUFHLEdBQUcsRUFBRSxLQUFLLEdBQUcsRUFBRSxNQUFNLENBQUMsS0FBSyxJQUFJLElBQUksR0FBRyxHQUFHLEVBQUUsS0FBSyxHQUFHLEVBQUUsTUFBTSxDQUFDLEtBQUs7S0FDNUUsRUFBRSxVQUFVO01BQUUsU0FBUyxFQUFFO01BQVMsT0FBTyxFQUFFLENBQUMsR0FBRyxHQUFHLE9BQU87TUFBRyxPQUFPLEVBQUUsQ0FBQyxHQUFHLEdBQUcsT0FBTztLQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsUUFBUSxNQUFNLE1BQU0sRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLFFBQVEsTUFBTSxNQUFNLEVBQUUsU0FBUyxFQUFFLFVBQVUsRUFBRSxXQUFXLEVBQUUsUUFBUSxNQUFNLFNBQVMsRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLFFBQVEsTUFBTSxTQUFTLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxRQUFRLEVBQUUsUUFBUSxNQUFNLE9BQU8sRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLFFBQVEsTUFBTSxPQUFPLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxVQUFVLEVBQUUsUUFBUSxNQUFNLFFBQVEsRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLFFBQVEsTUFBTSxRQUFRLEVBQUUsT0FBTyxFQUFFLFFBQVEsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLFVBQVU7SUFDdmY7R0FDRjtHQUFHLFVBQVU7SUFBRSxLQUFLO0lBQU0sS0FBSztJQUFNLFNBQVMsQ0FBQztJQUFHLFNBQVMsQ0FBQztHQUFFO0VBQUUsR0FBRyxjQUFjLEdBQUcsS0FBSztHQUFFLE9BQU8sU0FBUyxHQUFHO0lBQzVHLElBQUksR0FBRyxJQUFJLEVBQUUsYUFBYSxJQUFJLEVBQUUsY0FBYyxJQUFJLEVBQUUsU0FBUyxJQUFJLEVBQUUsTUFBTSxJQUFJLEVBQUUsT0FBTyxJQUFJLEVBQUUsYUFBYSxJQUFJLEVBQUUsU0FBUyxJQUFJLEVBQUUsbUJBQW1CLFNBQVMsR0FBRztLQUMzSixJQUFJLElBQUksRUFBRSxZQUFZO0tBQ3RCLE9BRG1DLEdBQUcsR0FBRyxFQUFFLE1BQU0sUUFBUSxRQUFRLE1BQU0sTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFRLEtBQUssR0FBRyxFQUFFLGNBQWMsR0FBRyxFQUFFLFlBQVksU0FBUyxJQUFJO0lBRWhKLEVBQUUsQ0FBQyxJQUFJO0tBQUUsR0FBRztLQUFHLEdBQUc7SUFBRTtJQUNwQixJQUFJLEVBQUUsV0FBVyxlQUFlLElBQUk7S0FBRSxHQUFHLEVBQUUsT0FBTyxNQUFNLEtBQUs7S0FBRyxHQUFHLEVBQUUsT0FBTyxNQUFNLEtBQUs7SUFBRTtTQUNwRjtLQUNILElBQUksSUFBSSxHQUFHLEVBQUUsUUFBUSxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUM7S0FDOUIsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxLQUFLO01BQUUsR0FBRztNQUFHLEdBQUc7S0FBRSxFQUFBLENBQUcsS0FBSyxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUU7SUFDbkQ7SUFDQSxJQUFJLElBQUksRUFBRTtJQUNWLEVBQUUsVUFBVSxLQUFLLEtBQUssRUFBRSxTQUFTLEVBQUUsSUFBSSxTQUFTLEdBQUcsR0FBRztLQUNwRCxPQUFPO01BQUUsT0FBTztNQUFHLGVBQWU7TUFBRyxHQUFHLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUU7TUFBRyxHQUFHLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUU7S0FBRTtJQUN4RyxDQUFDLElBQUksQ0FBQztLQUFFLE9BQU87S0FBRyxlQUFlO0tBQU0sR0FBRyxFQUFFO0tBQUcsR0FBRyxFQUFFO0lBQUUsQ0FBQztHQUN6RDtHQUFHLEtBQUssU0FBUyxHQUFHO0lBQ2xCLElBQUksSUFBSSxFQUFFLGFBQWEsSUFBSSxFQUFFLFFBQVEsSUFBSSxFQUFFLE9BQU8sSUFBSSxFQUFFLFNBQVMsSUFBSSxFQUFFLFNBQVMsSUFBSSxHQUFHLEVBQUUsY0FBYyxFQUFFLFNBQVMsRUFBRSxTQUFTLElBQUksR0FBRyxJQUFJLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUM7SUFDdkosRUFBRSxxQkFBcUIsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRTtJQUM1QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLLEtBQUssSUFBSSxJQUFJLEVBQUUsSUFBSSxJQUFJLEVBQUUsSUFBSSxFQUFFLEdBQUcsSUFBSSxFQUFFLElBQUksRUFBRSxHQUFHLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxRQUFRLElBQUksR0FBRyxLQUFLO0tBQ2xJLElBQUksSUFBSSxFQUFFLFFBQVEsSUFBSSxJQUFJLEtBQUs7S0FDL0IsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUksRUFBRSxHQUFHLEdBQUcsRUFBRSxRQUFRLEdBQUcsQ0FBQyxJQUFJLE1BQU0sRUFBRSxLQUFLO01BQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxDQUFDLElBQUksRUFBRSxJQUFJLEtBQUssRUFBRTtNQUFHLElBQUksRUFBRSxPQUFPLEVBQUUsQ0FBQyxJQUFJLEVBQUUsSUFBSSxLQUFLLEVBQUU7TUFBRyxPQUFPLEVBQUUsT0FBTyxFQUFFLEtBQUssSUFBSSxFQUFFLFFBQVEsRUFBRTtNQUFPLFFBQVE7TUFBRyxPQUFPO01BQUcsUUFBUTtLQUFFLENBQUM7SUFDbE47SUFDQSxLQUFLLElBQUksSUFBSTtLQUFFLFFBQVE7S0FBTSxTQUFTLENBQUM7S0FBRyxVQUFVO0tBQUcsT0FBTztLQUFHLE9BQU87TUFBRSxHQUFHO01BQUcsR0FBRztLQUFFO0lBQUUsR0FBRyxJQUFJLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FBSztLQUNsSCxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxPQUFPLElBQUksRUFBRSxJQUFJLEVBQUUsR0FBRyxLQUFLLEVBQUUsSUFBSSxFQUFFLEdBQUcsSUFBSSxHQUFHLEdBQUcsRUFBRSxHQUFHLEtBQUssS0FBSztLQUNuRixNQUFNLElBQUksS0FBSyxFQUFFLFdBQVcsRUFBRSxVQUFVLElBQUksTUFBTSxLQUFLLENBQUMsSUFBSSxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsV0FBVyxNQUFNLElBQUksSUFBSSxJQUFJLElBQUksRUFBRSxXQUFXLEVBQUUsUUFBUSxNQUFNLElBQUksS0FBSyxFQUFFLFVBQVUsSUFBSSxLQUFLLElBQUksRUFBRSxXQUFXLENBQUMsRUFBRSxXQUFXLElBQUksRUFBRSxjQUFjLEVBQUUsU0FBUyxHQUFHLEVBQUUsV0FBVyxHQUFHLEVBQUUsUUFBUSxHQUFHLEVBQUUsVUFBVSxJQUFJLEVBQUUsTUFBTSxJQUFJLEdBQUcsRUFBRSxNQUFNLElBQUk7SUFDeFQ7SUFDQSxPQUFPLEVBQUUsWUFBWSxFQUFFLElBQUksRUFBRSxPQUFPLEdBQUcsRUFBRSxJQUFJLEVBQUUsT0FBTyxJQUFJLEVBQUUsVUFBVSxHQUFHO0dBQzNFO0dBQUcsVUFBVTtJQUFFLE9BQU8sSUFBSTtJQUFHLFNBQVM7SUFBTSxRQUFRO0lBQU0sa0JBQWtCLENBQUM7SUFBRyxRQUFRO0lBQU0sZ0JBQWdCO0lBQU0sU0FBUyxDQUFDO0lBQUcsU0FBUyxDQUFDO0dBQUU7RUFBRSxHQUFHLEtBQUssR0FBRyxJQUFJLE1BQU0sR0FBRyxLQUFLO0dBQUUsT0FBTyxTQUFTLEdBQUc7SUFDL0wsSUFBSSxJQUFJLEVBQUUsT0FBTyxJQUFJLEVBQUUsT0FBTyxJQUFJLEVBQUU7SUFDcEMsSUFBSSxDQUFDLEdBQUcsT0FBTztJQUNmLEVBQUUsUUFBUSxFQUFFLFNBQVM7S0FBRSxTQUFTO0tBQU0sZ0JBQWdCLENBQUM7TUFBRSxHQUFHLEVBQUUsT0FBTyxJQUFJO01BQUcsR0FBRyxFQUFFLE1BQU0sSUFBSTtLQUFFLENBQUM7S0FBRyxRQUFRLEVBQUUsVUFBVTtLQUFRLFFBQVE7TUFBRSxHQUFHO01BQUcsR0FBRztLQUFFO0tBQUcsT0FBTyxFQUFFO0lBQU0sRUFBRSxHQUFHLEVBQUUsZUFBZSxFQUFFLGdCQUFnQixDQUFDLENBQUMsU0FBUyxRQUFRLEdBQUcsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDLEdBQUcsRUFBRSxVQUFVLEVBQUUsTUFBTSxTQUFTLEVBQUUsUUFBUTtHQUNyUztHQUFHLEtBQUssU0FBUyxHQUFHO0lBQ2xCLElBQUksSUFBSSxFQUFFLGFBQWEsSUFBSSxFQUFFLE9BQU8sSUFBSSxFQUFFLFFBQVEsSUFBSSxFQUFFLFNBQVMsSUFBSSxFQUFFLFNBQVMsSUFBSTtLQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDO0tBQUcsR0FBRyxFQUFFLElBQUksRUFBRSxFQUFFLENBQUM7SUFBRTtJQUN2SCxFQUFFLFVBQVUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsUUFBUSxVQUFVLENBQUM7SUFDM0MsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsV0FBVyxDQUFDLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FBSztLQUN0RCxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksS0FBSztLQUN2QixJQUFJLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSSxFQUFFLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxJQUFJLEdBQUc7TUFDdEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsY0FBYyxJQUFJLEVBQUUsUUFBUSxLQUFLO09BQ3JELElBQUksSUFBSSxFQUFFLElBQUksSUFBSSxFQUFFLElBQUksSUFBSSxFQUFFO09BQzlCLElBQUksS0FBSyxLQUFLLEtBQUssR0FBRztRQUNwQixFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFO1FBQ3BCO09BQ0Y7TUFDRjtNQUNBLEVBQUUsUUFBUSxRQUFRLEtBQUssQ0FBQztLQUMxQjtJQUNGO0lBQ0EsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDO0lBQ2hCLE9BQU8sRUFBRSxVQUFVLEdBQUc7R0FDeEI7R0FBRyxVQUFVO0lBQUUsT0FBTyxJQUFJO0lBQUcsU0FBUztJQUFNLFFBQVE7SUFBTSxTQUFTLENBQUM7SUFBRyxTQUFTLENBQUM7R0FBRTtFQUFFLEdBQUcsS0FBSyxHQUFHLElBQUksVUFBVSxHQUFHLEtBQUs7R0FBRSxhQUFhO0dBQUksZUFBZTtHQUFJLFVBQVU7R0FBSSxjQUFjO0dBQUksY0FBYztHQUFJLFdBQVcsR0FBRztJQUFFLE9BQU8sU0FBUyxHQUFHO0tBQy9PLElBQUksSUFBSSxFQUFFO0tBQ1YsT0FBTyxLQUFLLEVBQUUsTUFBTSxlQUFlLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQyxDQUFDLEVBQUUsT0FBTyxTQUFTLFNBQVMsRUFBRSxNQUFNLFFBQVEsUUFBUSxDQUFDLEdBQUcsR0FBRyxNQUFNLENBQUMsS0FBSztJQUNySTtJQUFHLEtBQUssR0FBRztJQUFLLFVBQVUsRUFBRSxHQUFHLEdBQUcsUUFBUSxHQUFHO0tBQUUsU0FBUyxLQUFLO0tBQUcsT0FBTyxLQUFLO0tBQUcsUUFBUTtNQUFFLEdBQUc7TUFBRyxHQUFHO0tBQUU7SUFBRSxDQUFDO0dBQUUsR0FBRyxXQUFXO0dBQUcsTUFBTTtHQUFJLFVBQVU7R0FBSSxRQUFRO0dBQUksT0FBTztHQUFJLFdBQVc7R0FBSSxZQUFZO0VBQUcsR0FNbE0sS0FBSztHQU51TSxJQUFJO0dBQWEsU0FBUyxTQUFTLEdBQUc7SUFDclAsSUFBSSxJQUFJLEVBQUU7SUFDVixLQUFLLElBQUksS0FBSyxFQUFFLFVBQVUsRUFBRSxHQUFHLEVBQUUsVUFBVSxFQUFFLEdBQUcsRUFBRSxZQUFZLElBQUksSUFBSTtLQUNwRSxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksRUFBRTtLQUNyQixFQUFFLFdBRGtDLEVBQUUsVUFDdEIsRUFBRSxTQUFTLFVBQVUsS0FBSztJQUM1QztHQUNGO0VBQVcsR0FBRyxLQUFLLFNBQVMsR0FBRztHQUM3QixFQUFFLEdBQUcsQ0FBQztHQUNOLElBQUksSUFBSSxFQUFFLENBQUM7R0FDWCxTQUFTLEVBQUUsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUc7SUFDM0IsSUFBSTtJQUNKLElBQUksRUFBRSxNQUFNLENBQUMsR0FBRyxHQUFHLEVBQUUsSUFBSSxFQUFFLEtBQUssTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxLQUFLLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsWUFBWSxHQUFHLEVBQUUsZ0JBQWdCLEdBQUcsRUFBRSxPQUFPLEdBQUcsRUFBRSxZQUFZLEdBQUcsQ0FBQyxHQUFHLEVBQUUsY0FBYyxHQUFHLENBQUMsR0FBRyxFQUFFLFNBQVMsR0FBRyxFQUFFLGdCQUFnQixNQUFNLE1BQU0sT0FBTztLQUN0TixJQUFJLElBQUksRUFBRSxnQkFBZ0IsQ0FBQztLQUMzQixFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUUsU0FBUyxFQUFFLENBQUM7S0FDbkMsSUFBSSxJQUFJLEVBQUUsWUFBWSxFQUFFO0tBQ3hCLEVBQUUsU0FBUyxDQUFDLENBQUMsRUFBRSxXQUFXLEVBQUUsUUFBUSxTQUFTLGVBQWUsRUFBRSxRQUFRLFdBQVcsRUFBRSxVQUFVLElBQUk7SUFDbkcsT0FBTyxNQUFNLGdCQUFnQixFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUUsU0FBUyxFQUFFLFNBQVMsQ0FBQztJQUN6RSxPQUFPO0dBQ1Q7R0FDQSxPQUFPLEVBQUUsR0FBRztJQUFDO0tBQUUsS0FBSztLQUFtQixPQUFPLFNBQVMsR0FBRztNQUN4RCxJQUFJLElBQUksRUFBRSxHQUFHLElBQUksRUFBRTtNQUNuQixPQUFPLEtBQUssU0FBUyxHQUFHLEtBQUssU0FBUyxHQUFHLEtBQUssV0FBVyxHQUFHLEtBQUssV0FBVyxHQUFHO0tBQ2pGO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBYyxPQUFPLFNBQVMsR0FBRztNQUMzQyxJQUFJLElBQUksRUFBRSxHQUFHLElBQUksRUFBRTtNQUNuQixPQUFPLEtBQUssU0FBUyxHQUFHLEtBQUssU0FBUyxHQUFHLEtBQUssV0FBVyxHQUFHLEtBQUssV0FBVyxHQUFHO0tBQ2pGO0lBQUU7SUFBRztLQUFFLEtBQUs7S0FBa0IsT0FBTyxXQUFXO01BQzlDLEtBQUssY0FBYyxlQUFlO0tBQ3BDO0lBQUU7R0FBQyxDQUFDLEdBQUc7RUFDVCxFQUFFLEVBQUUsR0FBRyxLQUFLO0dBQUUsSUFBSTtHQUF1QixRQUFRO0lBQUM7SUFBVztJQUFhO0lBQWM7R0FBUztHQUFHLFNBQVMsU0FBUyxHQUFHO0lBQ3ZILEVBQUUsZ0JBQWdCLElBQUksRUFBRSxTQUFTLFFBQVEsZ0JBQWdCLEdBQUcsVUFBVSxFQUFFLEVBQUUsUUFBUSxnQkFBZ0IsR0FBRyxLQUFLO0dBQzVHO0dBQUcsV0FBVztJQUFFLG9CQUFvQixTQUFTLEdBQUc7S0FDOUMsSUFBSSxJQUFJLEVBQUU7S0FDVixFQUFFLFVBQVUsTUFBTSxFQUFFLFVBQVU7SUFDaEM7SUFBRywrQkFBK0IsU0FBUyxHQUFHO0tBQzVDLElBQUksSUFBSSxFQUFFLE1BQU0sSUFBSSxFQUFFO0tBQ3RCLENBQUMsS0FBSyxFQUFFLFNBQVMsRUFBRSxPQUFPO01BQUUsVUFBVSxJQUFJO01BQUcsU0FBUztLQUFLO0lBQzdEO0lBQUcscUJBQXFCLFNBQVMsR0FBRyxHQUFHO0tBQ3JDLElBQUksSUFBSSxFQUFFLGFBQWEsSUFBSSxFQUFFLFNBQVMsSUFBSSxFQUFFLE9BQU8sSUFBSSxFQUFFO0tBQ3pELEVBQUUsYUFBYSxFQUFFLGlCQUFpQixDQUFDLEVBQUUsb0JBQW9CLEVBQUUsaUJBQWlCLEdBQUcsQ0FBQyxHQUFHLEdBQUc7TUFBRSxhQUFhO01BQUcsU0FBUztNQUFHLE9BQU87TUFBRyxhQUFhO01BQUcsTUFBTTtLQUFPLEdBQUcsQ0FBQztJQUNqSztJQUFHLHFCQUFxQixTQUFTLEdBQUcsR0FBRztLQUNyQyxDQUFDLFNBQVMsR0FBRyxHQUFHO01BQ2QsS0FBSyxJQUFJLElBQUksRUFBRSxhQUFhLElBQUksRUFBRSxTQUFTLElBQUksRUFBRSxPQUFPLElBQUksRUFBRSxhQUFhLElBQUksRUFBRSxjQUFjLElBQUksRUFBRSxTQUFTLEVBQUUsQ0FBQyxNQUFNLElBQUksR0FBRyxDQUFDLEdBQUcsSUFBSTtPQUFFLGFBQWE7T0FBRyxTQUFTO09BQUcsT0FBTztPQUFHLGFBQWE7T0FBRyxNQUFNO09BQVEsU0FBUyxDQUFDO09BQUcsTUFBTTtPQUFHLE1BQU07TUFBSyxHQUFHLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUVuUSxFQUFFLE9BRE0sRUFBRSxJQUNFLEVBQUUsS0FBSyxpQ0FBaUMsQ0FBQztNQUV2RCxJQUFJLEVBQUUsUUFBUSxRQUFRO09BQ3BCLEtBQUssSUFBSSxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxFQUFFLFNBQVMsSUFBSSxFQUFFLFFBQVEsS0FBSztRQUMzRCxJQUFJLElBQUksRUFBRSxFQUFFLENBQUMsVUFBVSxRQUFRO1FBQy9CLElBQUksTUFBTSxJQUFJO09BQ2hCO09BQ0EsRUFBRSxXQUFXLEdBQUcsRUFBRSxVQUFVLFdBQVcsV0FBVztRQUNoRCxHQUFHO1NBQUUsYUFBYTtTQUFHLGFBQWE7U0FBRyxTQUFTO1NBQUcsT0FBTztTQUFHLE1BQU07UUFBTyxHQUFHLENBQUM7T0FDOUUsR0FBRyxDQUFDO01BQ047S0FDRixFQUFBLENBQUcsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUM7SUFDbkI7SUFBRyxtQkFBbUIsU0FBUyxHQUFHLEdBQUc7S0FDbkMsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FBRyxTQUFTLEdBQUcsR0FBRztNQUM5QixJQUFJLElBQUksRUFBRSxhQUFhLElBQUksRUFBRSxTQUFTLElBQUksRUFBRSxPQUFPLElBQUksRUFBRTtNQUN6RCxFQUFFLG1CQUFtQixHQUFHO09BQUUsYUFBYTtPQUFHLGFBQWE7T0FBRyxTQUFTO09BQUcsT0FBTztPQUFHLE1BQU07TUFBTSxHQUFHLENBQUM7S0FDbEcsRUFBRSxHQUFHLENBQUM7SUFDUjtJQUFHLHVCQUF1QixTQUFTLEdBQUcsR0FBRztLQUN2QyxHQUFHLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQztJQUNoQjtHQUFFO0dBQUcsY0FBYztHQUFJLE1BQU07R0FBSSxxQkFBcUI7R0FBSSxVQUFVO0lBQUUsY0FBYztJQUFLLFlBQVk7SUFBTSxXQUFXO0lBQU0sUUFBUTtLQUFFLEdBQUc7S0FBRyxHQUFHO0lBQUU7R0FBRTtHQUFHLE9BQU87SUFBRSxNQUFNLENBQUM7SUFBRyxNQUFNLENBQUM7SUFBRyxJQUFJLENBQUM7SUFBRyxRQUFRLENBQUM7SUFBRyxLQUFLLENBQUM7SUFBRyxXQUFXLENBQUM7SUFBRyxNQUFNLENBQUM7R0FBRTtFQUFFO0VBQzFPLFNBQVMsR0FBRyxHQUFHLEdBQUc7R0FDaEIsSUFBSSxJQUFJLEVBQUUsYUFBYSxJQUFJLEVBQUUsU0FBUyxJQUFJLEVBQUUsT0FBTyxJQUFJLEVBQUUsYUFBYSxJQUFJLEVBQUUsTUFBTSxJQUFJLEVBQUUsU0FBUyxJQUFJLE1BQU0sS0FBSyxJQUFJLEdBQUcsR0FBRyxDQUFDLElBQUksR0FBRyxJQUFJLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLENBQUM7R0FDbkssRUFBRSxLQUFLLHFCQUFxQixFQUFFLGNBQWMsRUFBRSxDQUFDO0dBQy9DLEtBQUssSUFBSSxJQUFJO0lBQUUsYUFBYTtJQUFHLFNBQVM7SUFBRyxPQUFPO0lBQUcsYUFBYTtJQUFHLFNBQVM7SUFBRyxNQUFNO0lBQUcsY0FBYztHQUFFLEdBQUcsSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLEtBQUs7SUFDckksSUFBSSxJQUFJLEVBQUU7SUFDVixLQUFLLElBQUksS0FBSyxFQUFFLFNBQVMsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLE1BQU07SUFDNUMsSUFBSSxJQUFJLEdBQUcsRUFBRSxXQUFXLEVBQUUsSUFBSTtJQUM5QixJQUFJLEVBQUUsZ0JBQWdCLENBQUMsR0FBRyxFQUFFLFlBQVksRUFBRSxXQUFXLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxFQUFFLFVBQVUsS0FBSyxDQUFDLEdBQUcsRUFBRSxXQUFXLENBQUMsR0FBRyxFQUFFLCtCQUErQixFQUFFLHNCQUFzQixJQUFJLElBQUksRUFBRSxVQUFVLEVBQUUsSUFBSSxFQUFFLENBQUMsU0FBUyxFQUFFLGVBQWU7R0FDdk87R0FDQSxJQUFJLEVBQUUsS0FBSyx1QkFBdUIsQ0FBQyxHQUFHLE1BQU0sT0FBTztJQUNqRCxJQUFJLElBQUksRUFBRSxTQUFTLEdBQUc7S0FBRSxhQUFhO0tBQUcsU0FBUztLQUFHLE9BQU87S0FBRyxhQUFhO0tBQUcsTUFBTTtJQUFZLEdBQUcsQ0FBQyxJQUFJO0lBQ3hHLEVBQUUsVUFBVSxHQUFHLEVBQUUsVUFBVSxFQUFFO0dBQy9CO0dBQ0EsT0FBTztFQUNUO0VBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRztHQUNoQixJQUFJLElBQUksRUFBRSxhQUFhLElBQUksRUFBRSxTQUFTLElBQUksRUFBRSxPQUFPLElBQUksRUFBRSxhQUFhLElBQUksRUFBRSxNQUFNLElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxHQUFHLElBQUksRUFBRSxTQUFTO0dBQzNILElBQUksTUFBTSxVQUFVLEVBQUUsbUJBQW1CLENBQUMsS0FBSyxFQUFFLGVBQWUsSUFBSSxPQUFPLENBQUM7R0FDNUUsS0FBSyxJQUFJLElBQUksR0FBRyxDQUFDLEdBQUcsSUFBSTtJQUFFLGFBQWE7SUFBRyxTQUFTO0lBQUcsT0FBTztJQUFHLGFBQWE7SUFBRyxNQUFNO0lBQUcsTUFBTTtJQUFHLFNBQVMsQ0FBQztJQUFHLE1BQU07R0FBSyxHQUFHLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUVoSixFQUFFLE9BRE0sRUFBRSxJQUNFLEVBQUUsS0FBSyxpQ0FBaUMsQ0FBQztHQUV2RCxPQUFPLE1BQU0sV0FBVyxFQUFFLFVBQVUsRUFBRSxRQUFRLE9BQU8sU0FBUyxHQUFHO0lBQy9ELElBQUksR0FBRztJQUNQLE9BQU8sRUFBRSxVQUFVLFFBQVEsbUJBQW1CLElBQUksRUFBRSxTQUFTLE9BQU8sU0FBUyxJQUFJLEVBQUUsU0FBUyxPQUFPLEtBQUssSUFBSSxFQUFFO0dBQ2hILENBQUMsSUFBSSxFQUFFO0VBQ1Q7RUFDQSxTQUFTLEdBQUcsR0FBRztHQUNiLElBQUksSUFBSSxFQUFFLGFBQWEsSUFBSSxFQUFFLGNBQWMsSUFBSSxFQUFFLFNBQVMsRUFBRSxDQUFDO0dBQzdELEtBQUssRUFBRSxZQUFZLGFBQWEsRUFBRSxPQUFPLEdBQUcsRUFBRSxVQUFVO0VBQzFEO0VBQ0EsSUFBSSxLQUFLLE9BQU8sT0FBTztHQUFFLFdBQVc7R0FBTSxTQUFTO0VBQUcsQ0FBQztFQUN2RCxTQUFTLEdBQUcsR0FBRztHQUNiLElBQUksSUFBSSxFQUFFO0dBQ1YsRUFBRSx1QkFBdUIsY0FBYyxFQUFFLGtCQUFrQixHQUFHLEVBQUUscUJBQXFCO0VBQ3ZGO0VBQ0EsSUFpQlEsS0FBSztHQWpCRixJQUFJO0dBQTZCLFNBQVMsU0FBUyxHQUFHO0lBQy9ELEVBQUUsVUFBVSxFQUFFO0lBQ2QsSUFBSSxJQUFJLEVBQUU7SUFDVixFQUFFLFNBQVMscUJBQXFCLEdBQUcsRUFBRSxNQUFNLGFBQWEsRUFBRSxRQUFRLGVBQWUsYUFBYSxDQUFDO0dBQ2pHO0dBQUcsV0FBVztJQUFDO0lBQVE7SUFBTTtJQUFVO0dBQVEsQ0FBQyxDQUFDLE9BQU8sU0FBUyxHQUFHLEdBQUc7SUFDckUsT0FBTyxFQUFFLGlCQUFpQixPQUFPLENBQUMsS0FBSyxJQUFJO0dBQzdDLEdBQUc7SUFBRSxxQkFBcUIsU0FBUyxHQUFHO0tBQ3BDLElBQUksSUFBSSxFQUFFO0tBQ1YsRUFBRSxTQUFTLFdBQVcsRUFBRSxTQUFTLEVBQUUsU0FBUyxLQUFLO0lBQ25EO0lBQUcsdUJBQXVCLFNBQVMsR0FBRyxHQUFHO0tBQ3ZDLElBQUksSUFBSSxFQUFFLGFBQWEsSUFBSSxFQUFFLGNBQWMsSUFBSSxFQUFFLGFBQWEsSUFBSSxFQUFFO0tBQ3BFLElBQUksRUFBRSxTQUFTLFVBQVUsRUFBRSxRQUFRO01BQ2pDLElBQUksSUFBSSxFQUFFLEVBQUUsQ0FBQyxVQUFVLFFBQVE7TUFDL0IsS0FBSyxNQUFNLEVBQUUscUJBQXFCLFdBQVcsV0FBVztPQUN0RCxFQUFFLGNBQWMsS0FBSztRQUFFLGFBQWE7UUFBRyxhQUFhO1FBQUcsTUFBTTtRQUFRLFNBQVM7UUFBRyxPQUFPO09BQUUsR0FBRyxDQUFDO01BQ2hHLEdBQUcsQ0FBQztLQUNOO0lBQ0Y7R0FBRSxDQUFDO0VBQVcsR0F3QlAsS0FBSztHQXhCWSxJQUFJO0dBQXNDLFNBQVMsU0FBUyxHQUFHO0lBQ3JGLElBQUksSUFBSSxFQUFFO0lBQ1YsRUFBRSxVQUFVLGdCQUFnQixTQUFTLEdBQUc7S0FDdEMsT0FBTyxFQUFFLEtBQUssT0FBTyxTQUFTLENBQUMsR0FBRztJQUNwQztJQUNBLElBQUksSUFBSSxFQUFFLFVBQVU7SUFDcEIsRUFBRSxVQUFVLG9CQUFvQixTQUFTLEdBQUcsR0FBRztLQUM3QyxJQUFJLElBQUksRUFBRSxLQUFLLE1BQU0sR0FBRyxDQUFDO0tBQ3pCLE9BQU8sTUFBTSxTQUFTLEtBQUssT0FBTyxRQUFRLEtBQUssSUFBSTtJQUNyRDtHQUNGO0dBQUcsV0FBVztJQUFFLGlDQUFpQyxTQUFTLEdBQUcsR0FBRztLQUM5RCxJQUFJLElBQUksRUFBRSxTQUFTLElBQUksRUFBRSxNQUFNLElBQUksRUFBRSxNQUFNLElBQUksRUFBRTtLQUNqRCxFQUFFLGNBQWMsYUFBYSxHQUFHLFNBQVMsR0FBRztNQUMxQyxJQUFJLElBQUksRUFBRSxRQUFRLElBQUksRUFBRTtNQUN4QixFQUFFLE1BQU0sTUFBTSxFQUFFLE1BQU0sRUFBRSxDQUFDLFVBQVUsRUFBRSxnQkFBZ0IsR0FBRyxHQUFHLENBQUMsS0FBSyxFQUFFLEtBQUs7T0FBRSxNQUFNO09BQUcsV0FBVztPQUFHLE9BQU8sRUFBRSxjQUFjLEVBQUU7TUFBRSxDQUFDO0tBQy9ILENBQUM7SUFDSDtJQUFHLG9CQUFvQixTQUFTLEdBQUc7S0FDakMsSUFBSSxJQUFJLEVBQUU7S0FDVixFQUFFLE9BQU8sVUFBVSxTQUFTLEdBQUc7TUFDN0IsT0FBTyxFQUFFLFFBQVEsQ0FBQztLQUNwQjtJQUNGO0lBQUcsb0JBQW9CLFNBQVMsR0FBRyxHQUFHO0tBQ3BDLElBQUksSUFBSSxFQUFFLGNBQWMsSUFBSSxFQUFFO0tBQzlCLEVBQUUsRUFBRSxPQUFPLFNBQVMsRUFBRSxjQUFjLFFBQVEsR0FBRyxFQUFFLEVBQUUsT0FBTyxTQUFTLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztJQUMxRjtHQUFFO0VBQVc7RUFrRWIsSUFBSSxHQUFHLElBQUksRUFBRSxHQUFHLEdBQUcsSUFBSSxFQUFFLEdBQUcsR0FBRyxJQUFJO0dBbEVaLElBQUk7R0FBa0IsU0FBUyxTQUFTLEdBQUc7SUFDaEUsRUFBRSxVQUFVLEVBQUUsR0FBRyxFQUFFLFVBQVUsRUFBRSxHQUFHLEVBQUUsVUFBVSxFQUFFO0dBQ2xEO0VBZ0VvQyxDQUFDLEdBQUcsR0FBRyxJQUFJLEVBQUUsR0FBRyxHQUFHLElBQUksRUFBRSxHQUFHLEdBQUcsSUFBSSxFQUFFLEdBQUcsR0FBRyxJQUFJLEVBQUUsR0FBRyxHQUFHLElBQUksRUFBRSxHQUFHLEdBQUcsSUFBSTtHQWhFdEYsSUFBSTtHQUFVLFNBQVMsU0FBUyxHQUFHO0lBQ3RELElBQUksSUFBSSxFQUFFO0lBQ1YsRUFBRSxRQUFRLE9BQU8sU0FBUyxDQUFDLEdBQUcsRUFBRSxVQUFVLFNBQVMsU0FBUyxHQUFHO0tBQzdELE9BQU8sU0FBUyxHQUFHLEdBQUcsR0FBRztNQUN2QixLQUFLLElBQUksSUFBSSxFQUFFLGVBQWUsR0FBRyxJQUFJLEVBQUUsT0FBTyxTQUFTLElBQUksSUFBSSxDQUFDLElBQUksTUFBTSxJQUFJLFdBQVc7T0FDdkYsSUFBSSxJQUFJLEVBQUUsSUFBSSxJQUFJLEVBQUUsUUFBUSxDQUFDO09BQzdCLElBQUksQ0FBQyxHQUFHLE9BQU87T0FDZixJQUFJLEdBQUcsSUFBSSxHQUFHLEVBQUUsYUFBYSxNQUFNLFNBQVMsR0FBRztRQUM3QyxPQUFPLEVBQUUsWUFBWSxLQUFLLEVBQUUsaUJBQWlCLEtBQUssRUFBRSxZQUFZLEtBQUssRUFBRSxTQUFTLFNBQVMsRUFBRTtPQUM3RixDQUFDO09BQ0QsSUFBSSxHQUFHLEVBQUUsS0FBSyxHQUFHLE1BQU0sSUFBSSxFQUFFLGtCQUFrQixJQUFJLEVBQUUsU0FBUyxHQUFHO1FBQy9ELEVBQUUsaUJBQWlCO09BQ3JCLENBQUM7WUFDSTtRQUNILElBQUksSUFBSSxHQUFHLENBQUM7UUE0QlosSUFBSSxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRztTQUMxQixJQUFJLElBQUksRUFBRSxhQUFhLElBQUksRUFBRSxhQUFhLFNBQVMsQ0FBQyxHQUFHLEtBQUs7VUFBRSxhQUFhO1VBQUcsT0FBTztVQUFHLFNBQVM7VUFBRyxhQUFhO1VBQUcsT0FBTztTQUFTO1NBQ3BJLEVBQUUsZUFBZSxHQUFHLEVBQUUsVUFBVSxHQUFHLEVBQUUsWUFBWSxHQUFHLEVBQUUsY0FBYyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLEVBQUUsT0FBTyxLQUFLLEdBQUcsR0FBRyxFQUFFLFVBQVUsQ0FBQyxHQUFHLEVBQUUsU0FBUyxFQUFFO1NBQ3RJLElBQWtCLEtBQVYsRUFBRSxPQUFlLFNBQVMsS0FBSyxLQUFLLElBQUksR0FBRyxTQUFTLElBQUk7VUFDOUQsRUFBRSxpQkFBaUI7U0FDckIsQ0FBQyxJQUFJLEtBQUs7U0FDVixPQUFPLEVBQUUsaUJBQWlCLElBQUksRUFBRSxNQUFNLEdBQUcsR0FBRyxDQUFDLEdBQUcsRUFBRSxnQkFBZ0IsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsS0FBSyxHQUFHLEVBQUUsZUFBZSxJQUFJLEVBQUUsY0FBYyxHQUFHLENBQUMsR0FBRztRQUNuSixFQUFFLEdBQUcsR0FBRyxHQUFHLEdBbkN3Qix5QkFBUyxHQUFHO1NBQzdDLE9BQU87VUFBRSxRQUFRO1VBQUcsSUFBSSxPQUFPO1dBQzdCLE9BQU8sS0FBSyxPQUFPO1VBQ3JCO1VBQUcsSUFBSSxTQUFTO1dBQ2QsT0FBTyxLQUFLLE9BQU87VUFDckI7VUFBRyxJQUFJLFlBQVk7V0FDakIsT0FBTyxLQUFLLE9BQU87VUFDckI7VUFBRyxJQUFJLFFBQVE7V0FDYixPQUFPLEtBQUssT0FBTyxLQUFLO1VBQzFCO1VBQUcsSUFBSSxRQUFRO1dBQ2IsT0FBTyxLQUFLLE9BQU8sS0FBSztVQUMxQjtVQUFHLElBQUksVUFBVTtXQUNmLE9BQU8sS0FBSyxPQUFPLE9BQU87VUFDNUI7VUFBRyxJQUFJLFVBQVU7V0FDZixPQUFPLEtBQUssT0FBTyxPQUFPO1VBQzVCO1VBQUcsSUFBSSxZQUFZO1dBQ2pCLE9BQU8sS0FBSyxPQUFPO1VBQ3JCO1VBQUcsSUFBSSxTQUFTO1dBQ2QsT0FBTyxLQUFLLE9BQU87VUFDckI7VUFBRyxJQUFJLE9BQU87V0FDWixPQUFPLEtBQUssT0FBTztVQUNyQjtVQUFHLElBQUksY0FBYztXQUNuQixPQUFPLEtBQUssT0FBTztVQUNyQjtVQUFHLElBQUksVUFBVTtXQUNmLE9BQU8sS0FBSyxPQUFPO1VBQ3JCO1VBQUcsZ0JBQWdCLFdBQVcsQ0FDOUI7U0FBRTtRQUNKLEVBQUU7U0FBRSxNQUFNO1VBQUUsR0FBRyxFQUFFO1VBQUcsR0FBRyxFQUFFO1NBQUU7U0FBRyxRQUFRO1VBQUUsR0FBRyxFQUFFO1VBQUcsR0FBRyxFQUFFO1NBQUU7U0FBRyxXQUFXLEVBQUUsSUFBSTtRQUFFLENBUS9ELENBQUM7T0FDakI7T0FDQSxLQUFLLEVBQUUsS0FBSyxDQUFDO01BQ2YsR0FBRyxJQUFJLEdBQUcsSUFBSSxFQUFFLFVBQVUsQ0FBQyxFQUFFLEdBQUc7TUFDaEMsT0FBTyxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQVc7T0FDbkMsT0FBTztNQUNULENBQUM7S0FDSCxFQUFFLE1BQU0sR0FBRyxDQUFDO0lBQ2Q7R0FDRjtHQUFHLFdBQVcsRUFBRSxxQkFBcUIsU0FBUyxHQUFHLEdBQUc7SUFDbEQsSUFBSSxJQUFJLEVBQUU7SUFDVixFQUFFLGdCQUFnQixhQUFhLEVBQUUsa0JBQWtCLEVBQUUsZUFBZSxHQUFHLFNBQVMsR0FBRyxHQUFHO0tBQ3BGLEVBQUUsT0FBTyxFQUFFLFFBQVEsQ0FBQyxHQUFHLENBQUM7SUFDMUIsRUFBRSxFQUFFLGFBQWEsTUFBTSxDQUFDO0dBQzFCLEVBQUU7RUFDMEcsQ0FBQyxHQUFHLEdBQUcsVUFBVSxJQUFJLEVBQUUsQ0FBQyxNQUFNLFlBQVksR0FBRyxJQUFJO0dBQzNKLEVBQUUsVUFBVTtFQUNkLFFBQVEsQ0FDUjtFQUNBLE9BQU8sR0FBRyxVQUFVLElBQUk7Q0FDMUIsQ0FBQztBQUNILEVBQUEsQ0FBRyxJQUFJLEdBQUcsT0FBTztBQUNqQixJQUFJLEtBQUssR0FBRztBQUNaLElBQU0sS0FBcUIsbUJBQUcsRUFBRTtBQUNoQyxJQUFJLEtBQUssRUFBRSxTQUFTLENBQUMsRUFBRTtDQUN0QixTQUFTLEdBQUcsR0FBRztDQUNkLENBQUMsU0FBUyxHQUFHLEdBQUc7RUFDZCxFQUFFLFVBQVUsRUFBRTtDQUNoQixFQUFBLENBQUcsSUFBSSxXQUFXO0VBQ2hCLElBQUksSUFBSSxVQUFVLElBQUksd0JBQXdCLElBQUk7RUFDbEQsT0FBTyxTQUFTLEdBQUcsR0FBRyxHQUFHO0dBQ3ZCLElBQUksSUFBSSxFQUFFO0dBQ1YsRUFBRSxNQUFNLFNBQVMsR0FBRztJQUVsQixPQUFPLElBQUksRUFBRTtLQURILE1BQU07S0FBRyxLQUFLLENBQUM7S0FBRyxNQUFNO0lBQ3JCLENBQUM7R0FDaEIsR0FBRyxFQUFFLE1BQU0sU0FBUyxHQUFHO0lBQ3JCLElBQUksSUFBSSxFQUFFLEtBQUssT0FBTyxHQUFHO0tBQUUsUUFBUSxLQUFLO0tBQUksS0FBSyxDQUFDO0lBQUUsQ0FBQztJQUNyRCxPQUFPLElBQUksRUFBRSxJQUFJLEtBQUssVUFBVSxHQUFHLENBQUMsSUFBSTtHQUMxQyxHQUFHLEVBQUUsUUFBUSxXQUFXO0lBQ3RCLE9BQU8sRUFBRSxLQUFLLE9BQU8sR0FBRztLQUFFLFFBQVEsS0FBSztLQUFJLEtBQUssQ0FBQztJQUFFLENBQUM7R0FDdEQ7R0FDQSxJQUFJLElBQUksRUFBRTtHQUNWLEVBQUUsUUFBUSxTQUFTLEdBQUc7SUFDcEIsRUFBRSxRQUFRLEtBQUssS0FBSyxDQUFDLElBQUksS0FBSyxPQUFPLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxNQUFNLEtBQUssVUFBVSxFQUFFLFVBQVUsRUFBRSxLQUFLLE1BQU0sQ0FBQztHQUNuRztHQUNBLElBQUksSUFBSSxFQUFFO0dBQ1YsRUFBRSxPQUFPLFdBQVc7SUFDbEIsSUFBSSxLQUFLLElBQUk7S0FDWCxJQUFJLElBQUksS0FBSztLQUNiLEtBQUssS0FBSyxFQUFFLGVBQWUsR0FBRyxLQUFLLEtBQUssRUFBRSxZQUFZLEdBQUcsS0FBSyxLQUFLLEVBQUUsV0FBVyxHQUFHLEtBQUssS0FBSyxFQUFFLFVBQVUsR0FBRyxLQUFLLEtBQUssRUFBRSxZQUFZLEdBQUcsS0FBSyxLQUFLLEVBQUUsY0FBYyxHQUFHLEtBQUssS0FBSyxFQUFFLGNBQWMsR0FBRyxLQUFLLE1BQU0sRUFBRSxtQkFBbUI7SUFDbk8sT0FBTyxFQUFFLEtBQUssSUFBSTtHQUNwQjtHQUNBLElBQUksSUFBSSxFQUFFO0dBQ1YsRUFBRSxZQUFZLFNBQVMsR0FBRyxHQUFHO0lBQzNCLElBQUksSUFBSSxLQUFLLE9BQU8sQ0FBQyxDQUFDO0lBQ3RCLElBQUksRUFBRSxDQUFDLEdBQUcsT0FBTyxLQUFLLEtBQUssSUFBSSxFQUFFLEtBQUssT0FBTyxJQUFJLEVBQUUsS0FBSyxJQUFJLElBQUksS0FBSztJQUNyRSxJQUFJLE9BQU8sS0FBSyxhQUFhLElBQUksU0FBUyxHQUFHO0tBQzNDLE1BQU0sS0FBSyxNQUFNLElBQUk7S0FDckIsSUFBSSxLQUFLLEVBQUUsTUFBTSxDQUFDO0tBQ2xCLElBQUksQ0FBQyxJQUFJLE9BQU87S0FDaEIsSUFBSSxLQUFLLEtBQUssR0FBRyxHQUFBLENBQUksTUFBTSxDQUFDLEtBQUs7TUFBQztNQUFLO01BQUc7S0FBQyxHQUFHLEtBQUssRUFBRSxJQUFJLEtBQUssS0FBSyxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUU7S0FDOUUsT0FBTyxPQUFPLElBQUksSUFBSSxPQUFPLE1BQU0sS0FBSyxDQUFDO0lBQzNDLEVBQUUsQ0FBQyxHQUFHLE1BQU0sT0FBTyxPQUFPO0lBQzFCLElBQUksSUFBSSxLQUFLLElBQUksQ0FBQyxLQUFLLEtBQUssS0FBSyxJQUFJO0lBQ3JDLElBQUksTUFBTSxHQUFHLE9BQU8sS0FBSyxJQUFJLENBQUM7SUFDOUIsSUFBSSxJQUFJLEtBQUssTUFBTTtJQUNuQixJQUFJLEdBQUcsT0FBTyxFQUFFLFVBQVUsR0FBRyxFQUFFLEtBQUssQ0FBQyxHQUFHO0lBQ3hDLElBQUksSUFBSSxLQUFLLEtBQUssS0FBSyxPQUFPLENBQUMsQ0FBQyxrQkFBa0IsSUFBSSxLQUFLLEtBQUssVUFBVTtJQUMxRSxPQUFPLENBQUMsSUFBSSxLQUFLLE1BQU0sQ0FBQyxDQUFDLElBQUksSUFBSSxHQUFHLENBQUMsRUFBQSxDQUFHLFVBQVUsR0FBRyxFQUFFLEdBQUcsZUFBZSxHQUFHO0dBQzlFO0dBQ0EsSUFBSSxJQUFJLEVBQUU7R0FDVixFQUFFLFNBQVMsU0FBUyxHQUFHO0lBQ3JCLElBQUksSUFBSSxNQUFNLEtBQUssS0FBSywyQkFBMkI7SUFDbkQsT0FBTyxFQUFFLEtBQUssTUFBTSxDQUFDO0dBQ3ZCLEdBQUcsRUFBRSxVQUFVLFdBQVc7SUFDeEIsSUFBSSxJQUFJLEtBQUssT0FBTyxDQUFDLENBQUMsRUFBRSxLQUFLLE9BQU8sSUFBSSxJQUFJLEtBQUssV0FBVyxLQUFLLEdBQUcsZ0JBQWdCLEtBQUssR0FBRyxrQkFBa0I7SUFDOUcsT0FBTyxLQUFLLEdBQUcsUUFBUSxJQUFJLE1BQU07R0FDbkMsR0FBRyxFQUFFLFFBQVEsV0FBVztJQUN0QixPQUFPLENBQUMsQ0FBQyxLQUFLO0dBQ2hCLEdBQUcsRUFBRSxjQUFjLFdBQVc7SUFDNUIsT0FBTyxLQUFLLE9BQU8sQ0FBQyxDQUFDLFlBQVk7R0FDbkMsR0FBRyxFQUFFLFdBQVcsV0FBVztJQUN6QixPQUFPLEtBQUssT0FBTyxDQUFDLENBQUMsWUFBWTtHQUNuQztHQUNBLElBQUksSUFBSSxFQUFFO0dBQ1YsRUFBRSxTQUFTLFNBQVMsR0FBRztJQUNyQixPQUFPLE1BQU0sT0FBTyxLQUFLLFVBQVUsRUFBRSxLQUFLLE9BQU8seUJBQXlCLENBQUMsQ0FBQyxDQUFDLE9BQU8sSUFBSSxFQUFFLEtBQUssSUFBSTtHQUNyRztHQUNBLElBQUksSUFBSSxFQUFFO0dBQ1YsRUFBRSxPQUFPLFNBQVMsR0FBRyxHQUFHLEdBQUc7SUFDekIsSUFBSSxLQUFLLEtBQUssT0FBTyxFQUFFLElBQUksT0FBTyxFQUFFLEtBQUssTUFBTSxHQUFHLEdBQUcsQ0FBQztJQUN0RCxJQUFJLElBQUksS0FBSyxNQUFNLEdBQUcsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU07SUFDckMsT0FBTyxFQUFFLEtBQUssR0FBRyxHQUFHLEdBQUcsQ0FBQztHQUMxQjtFQUNGO0NBQ0YsQ0FBQztBQUNILEVBQUEsQ0FBRyxFQUFFO0FBQ0wsSUFBSSxLQUFLLEdBQUc7QUFDWixJQUFNLEtBQXFCLG1CQUFHLEVBQUU7QUFDaEMsU0FBUyxLQUFLO0NBQ1osS0FBSyxXQUFXLENBQUMsR0FBRyxLQUFLLE9BQU87QUFDbEM7QUFDQSxJQUFJLEtBQUs7QUFDVCxTQUFTLEdBQUcsR0FBRyxHQUFHO0NBQ2hCLE9BQU8sTUFBTSxLQUFLLE1BQU0sS0FBSyxNQUFNO0FBQ3JDO0FBQ0EsSUFBSSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQ2xCLFNBQVMsR0FBRyxHQUFHLEdBQUc7Q0FDaEIsS0FBSyxJQUFJLElBQUksRUFBRSxRQUFRLE1BQ3JCLElBQUksR0FBRyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FDZixPQUFPO0NBQ1gsT0FBTztBQUNUO0FBQ0EsSUFBSSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQTBCLElBQUEsS0FBakIsTUFBTSxVQUFtQjtBQUNwRCxTQUFTLEdBQUcsR0FBRztDQUNiLElBQUksSUFBSSxLQUFLLFVBQVUsSUFBSSxHQUFHLEdBQUcsQ0FBQztDQUNsQyxJQUFJLElBQUksR0FDTixPQUFPLENBQUM7Q0FFVixPQUFPLEtBREMsRUFBRSxTQUFTLElBQ0gsRUFBRSxJQUFJLElBQUksR0FBRyxLQUFLLEdBQUcsR0FBRyxDQUFDLEdBQUcsRUFBRSxLQUFLLE1BQU0sQ0FBQztBQUM1RDtBQUNBLElBQUksS0FBSztBQUFJLElBQUEsS0FBSztBQUNsQixTQUFTLEdBQUcsR0FBRztDQUNiLElBQUksSUFBSSxLQUFLLFVBQVUsSUFBSSxHQUFHLEdBQUcsQ0FBQztDQUNsQyxPQUFPLElBQUksSUFBSSxLQUFLLElBQUksRUFBRSxFQUFFLENBQUM7QUFDL0I7QUFDQSxJQUFJLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFDbEIsU0FBUyxHQUFHLEdBQUc7Q0FDYixPQUFPLEdBQUcsS0FBSyxVQUFVLENBQUMsSUFBSTtBQUNoQztBQUNBLElBQUksS0FBSztBQUFJLElBQUEsS0FBSztBQUNsQixTQUFTLEdBQUcsR0FBRyxHQUFHO0NBQ2hCLElBQUksSUFBSSxLQUFLLFVBQVUsSUFBSSxHQUFHLEdBQUcsQ0FBQztDQUNsQyxPQUFPLElBQUksS0FBSyxFQUFFLEtBQUssTUFBTSxFQUFFLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLEtBQUssR0FBRztBQUM5RDtBQUNBLElBQUksS0FBSztBQUFJLElBQUEsS0FBSztBQUFJLElBQUEsS0FBSztBQUFJLElBQUEsS0FBSztBQUFJLElBQUEsS0FBSztBQUFJLElBQUEsS0FBSztBQUN0RCxTQUFTLEdBQUcsR0FBRztDQUNiLElBQUksSUFBSSxJQUFJLElBQUksS0FBSyxPQUFPLElBQUksRUFBRTtDQUNsQyxLQUFLLEtBQUssTUFBTSxHQUFHLEVBQUUsSUFBSSxJQUFLO0VBQzVCLElBQUksSUFBSSxFQUFFO0VBQ1YsS0FBSyxJQUFJLEVBQUUsSUFBSSxFQUFFLEVBQUU7Q0FDckI7QUFDRjtBQUNBLEdBQUcsVUFBVSxRQUFRO0FBQ3JCLEdBQUcsVUFBVSxTQUFTO0FBQ3RCLEdBQUcsVUFBVSxNQUFNO0FBQ25CLEdBQUcsVUFBVSxNQUFNO0FBQ25CLEdBQUcsVUFBVSxNQUFNO0FBQ25CLElBQUksS0FBSztBQUFJLElBQUEsS0FBSztBQUNsQixTQUFTLEtBQUs7Q0FDWixLQUFLLFdBQVcsSUFBSSxHQUFHLEdBQUcsS0FBSyxPQUFPO0FBQ3hDO0FBQ0EsSUFBSSxLQUFLO0FBQ1QsU0FBUyxHQUFHLEdBQUc7Q0FDYixJQUFJLElBQUksS0FBSyxVQUFVLElBQUksRUFBRSxPQUFPLENBQUM7Q0FDckMsT0FBTyxLQUFLLE9BQU8sRUFBRSxNQUFNO0FBQzdCO0FBQ0EsSUFBSSxLQUFLO0FBQ1QsU0FBUyxHQUFHLEdBQUc7Q0FDYixPQUFPLEtBQUssU0FBUyxJQUFJLENBQUM7QUFDNUI7QUFDQSxJQUFJLEtBQUs7QUFDVCxTQUFTLEdBQUcsR0FBRztDQUNiLE9BQU8sS0FBSyxTQUFTLElBQUksQ0FBQztBQUM1QjtBQUNBLElBQUksS0FBSztBQUFvRSxJQUFBLEtBQTNELE9BQU8sTUFBTSxZQUFZLE1BQU0sR0FBRyxXQUFXLFVBQVU7QUFBYSxJQUFBLEtBQUs7QUFBSSxJQUFBLEtBQUssT0FBTyxRQUFRLFlBQVksUUFBUSxLQUFLLFdBQVcsVUFBVTtBQUFrRCxJQUFBLEtBQXZDLE1BQU0sTUFBTSxTQUFTLGFBQWEsQ0FBQyxDQUFDO0FBQXFDLElBQUEsS0FBWEEsR0FBRztBQUFpQixJQUFBLEtBQUs7QUFBSSxJQUFBLEtBQUssT0FBTztBQUFXLElBQUEsS0FBSyxHQUFHO0FBQWdCLElBQUEsS0FBSyxHQUFHO0FBQVUsSUFBQSxLQUFLLEtBQUssR0FBRyxjQUFjLEtBQUs7QUFDeFcsU0FBUyxHQUFHLEdBQUc7Q0FDYixJQUFJLElBQUksR0FBRyxLQUFLLEdBQUcsRUFBRSxHQUFHLElBQUksRUFBRTtDQUM5QixJQUFJO0VBQ0YsRUFBRSxNQUFNLEtBQUs7RUFDYixJQUFJLElBQUksQ0FBQztDQUNYLFFBQVEsQ0FDUjtDQUNBLElBQUksSUFBSSxHQUFHLEtBQUssQ0FBQztDQUNqQixPQUFPLE1BQU0sSUFBSSxFQUFFLE1BQU0sSUFBSSxPQUFPLEVBQUUsTUFBTTtBQUM5QztBQUNBLElBQUksS0FBSztBQUEyQixJQUFBLEtBQWxCLE9BQU8sVUFBbUI7QUFDNUMsU0FBUyxHQUFHLEdBQUc7Q0FDYixPQUFPLEdBQUcsS0FBSyxDQUFDO0FBQ2xCO0FBQ0EsSUFBSSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQWlCLElBQUEsS0FBSztBQUFzQixJQUFBLEtBQUssS0FBSyxHQUFHLGNBQWMsS0FBSztBQUN6SCxTQUFTLEdBQUcsR0FBRztDQUNiLE9BQU8sS0FBSyxPQUFPLE1BQU0sS0FBSyxJQUFJLEtBQUssS0FBSyxNQUFNLE1BQU0sT0FBTyxDQUFDLElBQUksR0FBRyxDQUFDLElBQUksR0FBRyxDQUFDO0FBQ2xGO0FBQ0EsSUFBSSxLQUFLO0FBQ1QsU0FBUyxHQUFHLEdBQUc7Q0FDYixJQUFJLElBQUksT0FBTztDQUNmLE9BQU8sS0FBSyxTQUFTLEtBQUssWUFBWSxLQUFLO0FBQzdDO0FBQ0EsSUFBSSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQTBCLElBQUEsS0FBSztBQUFxQixJQUFBLEtBQUs7QUFBOEIsSUFBQSxLQUFLO0FBQ2hJLFNBQVMsR0FBRyxHQUFHO0NBQ2IsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUNQLE9BQU8sQ0FBQztDQUNWLElBQUksSUFBSSxHQUFHLENBQUM7Q0FDWixPQUFPLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSyxNQUFNLEtBQUs7QUFDL0M7QUFDQSxJQUFJLEtBQUs7QUFBcUQsSUFBQSxLQUFuQ0MsR0FBRztBQUF5QyxJQUFBLEtBQUssV0FBVztDQUNyRixJQUFJLElBQUksU0FBUyxLQUFLLE1BQU0sR0FBRyxRQUFRLEdBQUcsS0FBSyxZQUFZLEVBQUU7Q0FDN0QsT0FBTyxJQUFJLG1CQUFtQixJQUFJO0FBQ3BDLEVBQUU7QUFDRixTQUFTLEdBQUcsR0FBRztDQUNiLE9BQU8sQ0FBQyxDQUFDLE1BQU0sTUFBTTtBQUN2QjtBQUNBLElBQUksS0FBSztBQUE2QixJQUFBLEtBQXBCLFNBQVMsVUFBbUI7QUFDOUMsU0FBUyxHQUFHLEdBQUc7Q0FDYixJQUFJLEtBQUssTUFBTTtFQUNiLElBQUk7R0FDRixPQUFPLEdBQUcsS0FBSyxDQUFDO0VBQ2xCLFFBQVEsQ0FDUjtFQUNBLElBQUk7R0FDRixPQUFPLElBQUk7RUFDYixRQUFRLENBQ1I7Q0FDRjtDQUNBLE9BQU87QUFDVDtBQUNBLElBQUksS0FBSztBQUFJLElBQUEsS0FBSztBQUFJLElBQUEsS0FBSztBQUFJLElBQUEsS0FBSztBQUFJLElBQUEsS0FBSztBQUFJLElBQUEsS0FBSztBQUF1QixJQUFBLEtBQUs7QUFBK0IsSUFBQSxLQUFLLFNBQVM7QUFBVyxJQUFBLEtBQUssT0FBTztBQUFXLElBQUEsS0FBSyxHQUFHO0FBQVUsSUFBQSxLQUFLLEdBQUc7QUFBZ0IsSUFBQSxLQUFLLE9BQzlNLE1BQU0sR0FBRyxLQUFLLEVBQUUsQ0FBQyxDQUFDLFFBQVEsSUFBSSxNQUFNLENBQUMsQ0FBQyxRQUFRLDBEQUEwRCxPQUFPLElBQUksR0FDckg7QUFDQSxTQUFTLEdBQUcsR0FBRztDQUNiLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxHQUFHLENBQUMsR0FDaEIsT0FBTyxDQUFDO0NBRVYsUUFEUSxHQUFHLENBQUMsSUFBSSxLQUFLLEdBQUEsQ0FDWixLQUFLLEdBQUcsQ0FBQyxDQUFDO0FBQ3JCO0FBQ0EsSUFBSSxLQUFLO0FBQ1QsU0FBUyxHQUFHLEdBQUcsR0FBRztDQUNoQixPQUFPLEtBQUssT0FBTyxLQUFLLElBQUksRUFBRTtBQUNoQztBQUNBLElBQUksS0FBSztBQUFJLElBQUEsS0FBSztBQUFJLElBQUEsS0FBSztBQUMzQixTQUFTLEdBQUcsR0FBRyxHQUFHO0NBQ2hCLElBQUksSUFBSSxHQUFHLEdBQUcsQ0FBQztDQUNmLE9BQU8sR0FBRyxDQUFDLElBQUksSUFBSSxLQUFLO0FBQzFCO0FBQ0EsSUFBSSxLQUFLO0FBQTBDLElBQUEsS0FBZkMsR0FBR0MsSUFBSSxLQUFjO0FBQXVDLElBQUEsS0FBdEJDLEdBQUcsUUFBUSxRQUFpQjtBQUFHLElBQUEsS0FBSztBQUM5RyxTQUFTLEtBQUs7Q0FDWixLQUFLLFdBQVcsS0FBSyxHQUFHLElBQUksSUFBSSxDQUFDLEdBQUcsS0FBSyxPQUFPO0FBQ2xEO0FBQ0EsSUFBSSxLQUFLO0FBQ1QsU0FBUyxHQUFHLEdBQUc7Q0FDYixJQUFJLElBQUksS0FBSyxJQUFJLENBQUMsS0FBSyxPQUFPLEtBQUssU0FBUztDQUM1QyxPQUFPLEtBQUssUUFBUSxJQUFJLElBQUksR0FBRztBQUNqQztBQUNBLElBQUksS0FBSztBQUFJLElBQUEsS0FBSztBQUFJLElBQUEsS0FBSztBQUFvRCxJQUFBLEtBQWxCLE9BQU8sVUFBbUI7QUFDdkYsU0FBUyxHQUFHLEdBQUc7Q0FDYixJQUFJLElBQUksS0FBSztDQUNiLElBQUksSUFBSTtFQUNOLElBQUksSUFBSSxFQUFFO0VBQ1YsT0FBTyxNQUFNLEtBQUssS0FBSyxJQUFJO0NBQzdCO0NBQ0EsT0FBTyxHQUFHLEtBQUssR0FBRyxDQUFDLElBQUksRUFBRSxLQUFLLEtBQUs7QUFDckM7QUFDQSxJQUFJLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFBMkIsSUFBQSxLQUFsQixPQUFPLFVBQW1CO0FBQ3JELFNBQVMsR0FBRyxHQUFHO0NBQ2IsSUFBSSxJQUFJLEtBQUs7Q0FDYixPQUFPLEtBQUssRUFBRSxPQUFPLEtBQUssSUFBSSxHQUFHLEtBQUssR0FBRyxDQUFDO0FBQzVDO0FBQ0EsSUFBSSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQzNCLFNBQVMsR0FBRyxHQUFHLEdBQUc7Q0FDaEIsSUFBSSxJQUFJLEtBQUs7Q0FDYixPQUFPLEtBQUssUUFBUSxLQUFLLElBQUksQ0FBQyxJQUFJLElBQUksR0FBRyxFQUFFLEtBQUssTUFBTSxNQUFNLEtBQUssSUFBSSxLQUFLLEdBQUc7QUFDL0U7QUFDQSxJQUFJLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFDdEQsU0FBUyxHQUFHLEdBQUc7Q0FDYixJQUFJLElBQUksSUFBSSxJQUFJLEtBQUssT0FBTyxJQUFJLEVBQUU7Q0FDbEMsS0FBSyxLQUFLLE1BQU0sR0FBRyxFQUFFLElBQUksSUFBSztFQUM1QixJQUFJLElBQUksRUFBRTtFQUNWLEtBQUssSUFBSSxFQUFFLElBQUksRUFBRSxFQUFFO0NBQ3JCO0FBQ0Y7QUFDQSxHQUFHLFVBQVUsUUFBUTtBQUNyQixHQUFHLFVBQVUsU0FBUztBQUN0QixHQUFHLFVBQVUsTUFBTTtBQUNuQixHQUFHLFVBQVUsTUFBTTtBQUNuQixHQUFHLFVBQVUsTUFBTTtBQUNuQixJQUFhLEtBQUtDO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQ3BDLFNBQVMsS0FBSztDQUNaLEtBQUssT0FBTyxHQUFHLEtBQUssV0FBVztFQUM3QixNQUFNLElBQUksR0FBRztFQUNiLEtBQUssS0FBSyxNQUFNLElBQUk7RUFDcEIsUUFBUSxJQUFJLEdBQUc7Q0FDakI7QUFDRjtBQUNBLElBQUksS0FBSztBQUNULFNBQVMsR0FBRyxHQUFHO0NBQ2IsSUFBSSxJQUFJLE9BQU87Q0FDZixPQUFPLEtBQUssWUFBWSxLQUFLLFlBQVksS0FBSyxZQUFZLEtBQUssWUFBWSxNQUFNLGNBQWMsTUFBTTtBQUN2RztBQUNBLElBQWEsS0FBS0M7QUFDbEIsU0FBUyxHQUFHLEdBQUcsR0FBRztDQUNoQixJQUFJLElBQUksRUFBRTtDQUNWLE9BQU8sR0FBRyxDQUFDLElBQUksRUFBRSxPQUFPLEtBQUssV0FBVyxXQUFXLFVBQVUsRUFBRTtBQUNqRTtBQUNBLElBQUksS0FBSztBQUFJLElBQUEsS0FBSztBQUNsQixTQUFTLEdBQUcsR0FBRztDQUNiLElBQUksSUFBSSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0NBQzVCLE9BQU8sS0FBSyxRQUFRLElBQUksSUFBSSxHQUFHO0FBQ2pDO0FBQ0EsSUFBSSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQ2xCLFNBQVMsR0FBRyxHQUFHO0NBQ2IsT0FBTyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzFCO0FBQ0EsSUFBSSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQ2xCLFNBQVMsR0FBRyxHQUFHO0NBQ2IsT0FBTyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzFCO0FBQ0EsSUFBSSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQ2xCLFNBQVMsR0FBRyxHQUFHLEdBQUc7Q0FDaEIsSUFBSSxJQUFJLEdBQUcsTUFBTSxDQUFDLEdBQUcsSUFBSSxFQUFFO0NBQzNCLE9BQU8sRUFBRSxJQUFJLEdBQUcsQ0FBQyxHQUFHLEtBQUssUUFBUSxFQUFFLFFBQVEsSUFBSSxJQUFJLEdBQUc7QUFDeEQ7QUFDQSxJQUFJLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFDdEQsU0FBUyxHQUFHLEdBQUc7Q0FDYixJQUFJLElBQUksSUFBSSxJQUFJLEtBQUssT0FBTyxJQUFJLEVBQUU7Q0FDbEMsS0FBSyxLQUFLLE1BQU0sR0FBRyxFQUFFLElBQUksSUFBSztFQUM1QixJQUFJLElBQUksRUFBRTtFQUNWLEtBQUssSUFBSSxFQUFFLElBQUksRUFBRSxFQUFFO0NBQ3JCO0FBQ0Y7QUFDQSxHQUFHLFVBQVUsUUFBUTtBQUNyQixHQUFHLFVBQVUsU0FBUztBQUN0QixHQUFHLFVBQVUsTUFBTTtBQUNuQixHQUFHLFVBQVUsTUFBTTtBQUNuQixHQUFHLFVBQVUsTUFBTTtBQUNuQixJQUFJLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFDN0MsU0FBUyxHQUFHLEdBQUcsR0FBRztDQUNoQixJQUFJLElBQUksS0FBSztDQUNiLElBQUksYUFBYSxJQUFJO0VBQ25CLElBQUksSUFBSSxFQUFFO0VBQ1YsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLEtBQUssR0FDekIsT0FBTyxFQUFFLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEtBQUssT0FBTyxFQUFFLEVBQUUsTUFBTTtFQUMvQyxJQUFJLEtBQUssV0FBVyxJQUFJLEdBQUcsQ0FBQztDQUM5QjtDQUNBLE9BQU8sRUFBRSxJQUFJLEdBQUcsQ0FBQyxHQUFHLEtBQUssT0FBTyxFQUFFLE1BQU07QUFDMUM7QUFDQSxJQUFJLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFDL0QsU0FBUyxHQUFHLEdBQUc7Q0FDYixJQUFJLElBQUksS0FBSyxXQUFXLElBQUksR0FBRyxDQUFDO0NBQ2hDLEtBQUssT0FBTyxFQUFFO0FBQ2hCO0FBQ0EsR0FBRyxVQUFVLFFBQVE7QUFDckIsR0FBRyxVQUFVLFNBQVM7QUFDdEIsR0FBRyxVQUFVLE1BQU07QUFDbkIsR0FBRyxVQUFVLE1BQU07QUFDbkIsR0FBRyxVQUFVLE1BQU07QUFDbkIsSUFBSSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQ2xCLFNBQVMsR0FBRyxHQUFHO0NBQ2IsT0FBTyxLQUFLLFNBQVMsSUFBSSxHQUFHLEVBQUUsR0FBRztBQUNuQztBQUNBLElBQUksS0FBSztBQUNULFNBQVMsR0FBRyxHQUFHO0NBQ2IsT0FBTyxLQUFLLFNBQVMsSUFBSSxDQUFDO0FBQzVCO0FBQ0EsSUFBSSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQ3BDLFNBQVMsR0FBRyxHQUFHO0NBQ2IsSUFBSSxJQUFJLElBQUksSUFBSSxLQUFLLE9BQU8sSUFBSSxFQUFFO0NBQ2xDLEtBQUssS0FBSyxXQUFXLElBQUksR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUNuQyxLQUFLLElBQUksRUFBRSxFQUFFO0FBQ2pCO0FBQ0EsR0FBRyxVQUFVLE1BQU0sR0FBRyxVQUFVLE9BQU87QUFDdkMsR0FBRyxVQUFVLE1BQU07QUFDbkIsSUFBSSxLQUFLO0FBQ1QsU0FBUyxHQUFHLEdBQUcsR0FBRztDQUNoQixLQUFLLElBQUksSUFBSSxJQUFJLElBQUksS0FBSyxPQUFPLElBQUksRUFBRSxRQUFRLEVBQUUsSUFBSSxJQUNuRCxJQUFJLEVBQUUsRUFBRSxJQUFJLEdBQUcsQ0FBQyxHQUNkLE9BQU8sQ0FBQztDQUNaLE9BQU8sQ0FBQztBQUNWO0FBQ0EsSUFBSSxLQUFLO0FBQ1QsU0FBUyxHQUFHLEdBQUcsR0FBRztDQUNoQixPQUFPLEVBQUUsSUFBSSxDQUFDO0FBQ2hCO0FBQ0EsSUFBSSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUcsSUFBQSxLQUFLO0FBQ3JELFNBQVMsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRztDQUM1QixJQUFJLElBQUksSUFBSSxJQUFJLElBQUksRUFBRSxRQUFRLElBQUksRUFBRTtDQUNwQyxJQUFJLEtBQUssS0FBSyxFQUFFLEtBQUssSUFBSSxJQUN2QixPQUFPLENBQUM7Q0FDVixJQUFJLElBQUksRUFBRSxJQUFJLENBQUMsR0FBRyxJQUFJLEVBQUUsSUFBSSxDQUFDO0NBQzdCLElBQUksS0FBSyxHQUNQLE9BQU8sS0FBSyxLQUFLLEtBQUs7Q0FDeEIsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLEdBQUcsSUFBSSxJQUFJLEtBQUssSUFBSSxHQUFHLElBQUksS0FBSztDQUNqRCxLQUFLLEVBQUUsSUFBSSxHQUFHLENBQUMsR0FBRyxFQUFFLElBQUksR0FBRyxDQUFDLEdBQUcsRUFBRSxJQUFJLElBQUs7RUFDeEMsSUFBSSxJQUFJLEVBQUUsSUFBSSxJQUFJLEVBQUU7RUFDcEIsSUFBSSxHQUNGLElBQUksSUFBSSxJQUFJLEVBQUUsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsSUFBSSxFQUFFLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDO0VBQ3RELElBQUksTUFBTSxLQUFLLEdBQUc7R0FDaEIsSUFBSSxHQUNGO0dBQ0YsSUFBSSxDQUFDO0dBQ0w7RUFDRjtFQUNBLElBQUksR0FDRTtPQUFBLENBQUMsR0FBRyxHQUFHLFNBQVMsR0FBRyxHQUFHO0lBQ3hCLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQyxNQUFNLE1BQU0sS0FBSyxFQUFFLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxJQUMxQyxPQUFPLEVBQUUsS0FBSyxDQUFDO0dBQ25CLENBQUMsR0FBRztJQUNGLElBQUksQ0FBQztJQUNMO0dBQ0Y7U0FDSyxJQUFJLEVBQUUsTUFBTSxLQUFLLEVBQUUsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLElBQUk7R0FDekMsSUFBSSxDQUFDO0dBQ0w7RUFDRjtDQUNGO0NBQ0EsT0FBTyxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLEdBQUc7QUFDbkM7QUFDQSxJQUFJLEtBQUs7QUFBaUMsSUFBQSxLQUFmQyxHQUFHO0FBQzlCLFNBQVMsR0FBRyxHQUFHO0NBQ2IsSUFBSSxJQUFJLElBQUksSUFBSSxNQUFNLEVBQUUsSUFBSTtDQUM1QixPQUFPLEVBQUUsUUFBUSxTQUFTLEdBQUcsR0FBRztFQUM5QixFQUFFLEVBQUUsS0FBSyxDQUFDLEdBQUcsQ0FBQztDQUNoQixDQUFDLEdBQUc7QUFDTjtBQUNBLElBQUksS0FBSztBQUNULFNBQVMsR0FBRyxHQUFHO0NBQ2IsSUFBSSxJQUFJLElBQUksSUFBSSxNQUFNLEVBQUUsSUFBSTtDQUM1QixPQUFPLEVBQUUsUUFBUSxTQUFTLEdBQUc7RUFDM0IsRUFBRSxFQUFFLEtBQUs7Q0FDWCxDQUFDLEdBQUc7QUFDTjtBQUNBLElBQUksS0FBSztBQUFJLElBQUEsS0FBSztBQUFJLElBQUEsS0FBSztBQUFJLElBQUEsS0FBSztBQUFJLElBQUEsS0FBSztBQUFJLElBQUEsS0FBSztBQUFJLElBQUEsS0FBSztBQUFJLElBQUEsS0FBSztBQUFHLElBQUEsS0FBSztBQUFHLElBQUEsS0FBSztBQUFvQixJQUFBLEtBQUs7QUFBaUIsSUFBQSxLQUFLO0FBQWtCLElBQUEsS0FBSztBQUFnQixJQUFBLEtBQUs7QUFBbUIsSUFBQSxLQUFLO0FBQW1CLElBQUEsS0FBSztBQUFnQixJQUFBLEtBQUs7QUFBbUIsSUFBQSxLQUFLO0FBQW1CLElBQUEsS0FBSztBQUF3QixJQUFBLEtBQUs7QUFBcUIsSUFBQSxLQUFLLEtBQUssR0FBRyxZQUFZLEtBQUs7QUFBRyxJQUFBLEtBQUssS0FBSyxHQUFHLFVBQVUsS0FBSztBQUN2WixTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRztDQUMvQixRQUFRLEdBQVI7RUFDRSxLQUFLO0dBQ0gsSUFBSSxFQUFFLGNBQWMsRUFBRSxjQUFjLEVBQUUsY0FBYyxFQUFFLFlBQ3BELE9BQU8sQ0FBQztHQUNWLElBQUksRUFBRSxRQUFRLElBQUksRUFBRTtFQUN0QixLQUFLLElBQ0gsT0FBTyxFQUFFLEVBQUUsY0FBYyxFQUFFLGNBQWMsQ0FBQyxFQUFFLElBQUksR0FBRyxDQUFDLEdBQUcsSUFBSSxHQUFHLENBQUMsQ0FBQztFQUNsRSxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUssSUFDSCxPQUFPLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztFQUNsQixLQUFLLElBQ0gsT0FBTyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsV0FBVyxFQUFFO0VBQzVDLEtBQUs7RUFDTCxLQUFLLElBQ0gsT0FBTyxLQUFLLElBQUk7RUFDbEIsS0FBSyxJQUNILElBQUksSUFBSTtFQUNWLEtBQUs7R0FDSCxJQUFJLElBQUksSUFBSTtHQUNaLElBQUksTUFBTSxJQUFJLEtBQUssRUFBRSxRQUFRLEVBQUUsUUFBUSxDQUFDLEdBQ3RDLE9BQU8sQ0FBQztHQUNWLElBQUksSUFBSSxFQUFFLElBQUksQ0FBQztHQUNmLElBQUksR0FDRixPQUFPLEtBQUs7R0FDZCxLQUFLLElBQUksRUFBRSxJQUFJLEdBQUcsQ0FBQztHQUNuQixJQUFJLElBQUksR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDO0dBQ2pDLE9BQU8sRUFBRSxPQUFPLENBQUMsR0FBRztFQUN0QixLQUFLLElBQ0gsSUFBSSxJQUNGLE9BQU8sR0FBRyxLQUFLLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztDQUNwQztDQUNBLE9BQU8sQ0FBQztBQUNWO0FBQ0EsSUFBSSxLQUFLO0FBQ1QsU0FBUyxHQUFHLEdBQUcsR0FBRztDQUNoQixLQUFLLElBQUksSUFBSSxJQUFJLElBQUksRUFBRSxRQUFRLElBQUksRUFBRSxRQUFRLEVBQUUsSUFBSSxJQUNqRCxFQUFFLElBQUksS0FBSyxFQUFFO0NBQ2YsT0FBTztBQUNUO0FBQ0EsSUFBSSxLQUFLO0FBQXdCLElBQUEsS0FBZixNQUFNO0FBQWtCLElBQUEsS0FBSztBQUFJLElBQUEsS0FBSztBQUN4RCxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUc7Q0FDbkIsSUFBSSxJQUFJLEVBQUUsQ0FBQztDQUNYLE9BQU8sR0FBRyxDQUFDLElBQUksSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDL0I7QUFDQSxJQUFJLEtBQUs7QUFDVCxTQUFTLEdBQUcsR0FBRyxHQUFHO0NBQ2hCLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSSxLQUFLLE9BQU8sSUFBSSxFQUFFLFFBQVEsSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxJQUFLO0VBQ3ZFLElBQUksSUFBSSxFQUFFO0VBQ1YsRUFBRSxHQUFHLEdBQUcsQ0FBQyxNQUFNLEVBQUUsT0FBTztDQUMxQjtDQUNBLE9BQU87QUFDVDtBQUNBLElBQUksS0FBSztBQUNULFNBQVMsS0FBSztDQUNaLE9BQU8sQ0FBQztBQUNWO0FBQ0EsSUFBSSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQTJCLElBQUEsS0FBbEIsT0FBTyxVQUFtQjtBQUFzQixJQUFBLEtBQUssT0FBTztBQUl4RixJQUFBLEtBSm9ILEtBQUssU0FBUyxHQUFHO0NBQzNJLE9BQU8sS0FBSyxPQUFPLENBQUMsS0FBSyxJQUFJLE9BQU8sQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQUcsU0FBUyxHQUFHO0VBQzVELE9BQU8sR0FBRyxLQUFLLEdBQUcsQ0FBQztDQUNyQixDQUFDO0FBQ0gsSUFBSTtBQUNKLFNBQVMsR0FBRyxHQUFHLEdBQUc7Q0FDaEIsS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJLE1BQU0sQ0FBQyxHQUFHLEVBQUUsSUFBSSxJQUNuQyxFQUFFLEtBQUssRUFBRSxDQUFDO0NBQ1osT0FBTztBQUNUO0FBQ0EsSUFBSSxLQUFLO0FBQ1QsU0FBUyxHQUFHLEdBQUc7Q0FDYixPQUFPLEtBQUssUUFBUSxPQUFPLEtBQUs7QUFDbEM7QUFDQSxJQUFJLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFDcEMsU0FBUyxHQUFHLEdBQUc7Q0FDYixPQUFPLEdBQUcsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxLQUFLO0FBQzNCO0FBQ0EsSUFBYSxLQUFLQztBQUFJLElBQUEsS0FBSztBQUFJLElBQUEsS0FBSyxPQUFPO0FBQVcsSUFBQSxLQUFLLEdBQUc7QUFBZ0IsSUFBQSxLQUFLLEdBQUc7QUFJbkYsSUFBQSxLQUo4RyxHQUFtQiwyQkFBVztDQUM3SSxPQUFPO0FBQ1QsRUFBRSxDQUFDLElBQUksS0FBSyxTQUFTLEdBQUc7Q0FDdEIsT0FBTyxHQUFHLENBQUMsS0FBSyxHQUFHLEtBQUssR0FBRyxRQUFRLEtBQUssQ0FBQyxHQUFHLEtBQUssR0FBRyxRQUFRO0FBQzlEO0FBQVksSUFBQSxLQUFLLEVBQUUsU0FBUyxDQUFDLEVBQUU7QUFDL0IsU0FBUyxLQUFLO0NBQ1osT0FBTyxDQUFDO0FBQ1Y7QUFDQSxJQUFJLEtBQUs7QUFDVCxHQUFHO0NBQ0YsU0FBUyxHQUFHLEdBQUc7Q0FDZCxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxLQUFLLENBQUMsRUFBRSxZQUFZLEdBQUcsSUFBSSxLQUFXLEtBQUssQ0FBQyxFQUFFLFlBQVksR0FBNkIsSUFBdEIsS0FBSyxFQUFFLFlBQVksSUFBVyxFQUFFLFNBQVMsS0FBSztDQUN2SSxFQUFFLFdBRDRJLElBQUksRUFBRSxXQUFXLEtBQUssTUFBWTtBQUVsTCxFQUFBLENBQUcsSUFBSSxHQUFHLE9BQU87QUFDakIsSUFBSSxLQUFLLEdBQUc7QUFBUyxJQUFBLEtBQUs7QUFBa0IsSUFBQSxLQUFLO0FBQ2pELFNBQVMsR0FBRyxHQUFHLEdBQUc7Q0FDaEIsSUFBSSxJQUFJLE9BQU87Q0FDZixPQUFPLElBQUksS0FBSyxJQUFJLENBQUMsQ0FBQyxNQUFNLEtBQUssWUFBWSxLQUFLLFlBQVksR0FBRyxLQUFLLENBQUMsTUFBTSxJQUFJLE1BQU0sSUFBSSxLQUFLLEtBQUssSUFBSTtBQUMzRztBQUNBLElBQUksS0FBSztBQUFJLElBQUEsS0FBSztBQUNsQixTQUFTLEdBQUcsR0FBRztDQUNiLE9BQU8sT0FBTyxLQUFLLFlBQVksSUFBSSxNQUFNLElBQUksS0FBSyxLQUFLLEtBQUs7QUFDOUQ7QUFDQSxJQUFJLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFBSSxJQUFBLEtBQUs7QUFBc0IsSUFBQSxLQUFLO0FBQWtCLElBQUEsS0FBSztBQUFvQixJQUFBLEtBQUs7QUFBaUIsSUFBQSxLQUFLO0FBQWtCLElBQUEsS0FBSztBQUFxQixJQUFBLEtBQUs7QUFBZ0IsSUFBQSxLQUFLO0FBQW1CLElBQUEsS0FBSztBQUFtQixJQUFBLEtBQUs7QUFBbUIsSUFBQSxLQUFLO0FBQWdCLElBQUEsS0FBSztBQUFtQixJQUFBLEtBQUs7QUFBb0IsSUFBQSxLQUFLO0FBQXdCLElBQUEsS0FBSztBQUFxQixJQUFBLEtBQUs7QUFBeUIsSUFBQSxLQUFLO0FBQXlCLElBQUEsS0FBSztBQUFzQixJQUFBLEtBQUs7QUFBdUIsSUFBQSxLQUFLO0FBQXVCLElBQUEsS0FBSztBQUF1QixJQUFBLEtBQUs7QUFBOEIsSUFBQSxLQUFLO0FBQXdCLElBQUEsS0FBSztBQUF3QixJQUFBLElBQUksQ0FBQztBQUNqcUIsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQztBQUN6RSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxDQUFDO0FBQ3pILFNBQVMsR0FBRyxHQUFHO0NBQ2IsT0FBTyxHQUFHLENBQUMsS0FBSyxHQUFHLEVBQUUsTUFBTSxLQUFLLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQztBQUMxQztBQUNBLElBQUksS0FBSztBQUNULFNBQVMsR0FBRyxHQUFHO0NBQ2IsT0FBTyxTQUFTLEdBQUc7RUFDakIsT0FBTyxFQUFFLENBQUM7Q0FDWjtBQUNGO0FBQ0EsSUFBSSxLQUFLO0FBQUksSUFBQSxLQUFLLEVBQUUsU0FBUyxDQUFDLEVBQUU7QUFDaEMsR0FBRztDQUNGLFNBQVMsR0FBRyxHQUFHO0NBQ2QsSUFBSSxJQUFJLElBQUksSUFBSSxLQUFLLENBQUMsRUFBRSxZQUFZLEdBQUcsSUFBSSxLQUFXLEtBQUssQ0FBQyxFQUFFLFlBQVksR0FBNkIsSUFBdEIsS0FBSyxFQUFFLFlBQVksS0FBWSxFQUFFO0NBT2xILEVBQUUsVUFQNkgsV0FBVztFQUN4SSxJQUFJO0dBRUYsT0FEUSxLQUFLLEVBQUUsV0FBVyxFQUFFLFFBQVEsTUFBTSxDQUFDLENBQUMsU0FDaEMsS0FBSyxFQUFFLFdBQVcsRUFBRSxRQUFRLE1BQU07RUFDaEQsUUFBUSxDQUNSO0NBQ0YsRUFDWTtBQUNkLEVBQUEsQ0FBRyxJQUFJLEdBQUcsT0FBTztBQUNqQixJQUFJLEtBQUssR0FBRztBQUFTLElBQUEsS0FBSztBQUFJLElBQUEsS0FBSztBQUFJLElBQUEsS0FBSztBQUFJLElBQUEsS0FBSyxNQUFNLEdBQUc7QUFBcUMsSUFBQSxLQUFsQixLQUFLLEdBQUcsRUFBRSxJQUFJO0FBQWEsSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQTJCLElBQUEsS0FBbEIsT0FBTyxVQUFtQjtBQUNqTSxTQUFTLEdBQUcsR0FBRyxHQUFHO0NBQ2hCLElBQUksSUFBSSxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFHLENBQUMsR0FBRyxJQUFJLEtBQUssS0FBSyxLQUFLLEdBQUcsSUFBSSxJQUFJLEdBQUcsRUFBRSxRQUFRLE1BQU0sSUFBSSxDQUFDLEdBQUcsSUFBSSxFQUFFO0NBQ25KLEtBQUssSUFBSSxLQUFLLEdBQ1osQ0FBQyxLQUFLLEdBQUcsS0FBSyxHQUFHLENBQUMsTUFBTSxFQUFFLE1BQ3pCLEtBQUssWUFDTixNQUFNLEtBQUssWUFBWSxLQUFLLGFBQzVCLE1BQU0sS0FBSyxZQUFZLEtBQUssZ0JBQWdCLEtBQUssaUJBQ2pELEdBQUcsR0FBRyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUM7Q0FDeEIsT0FBTztBQUNUO0FBQ0EsSUFBSSxLQUFLO0FBQUksSUFBQSxLQUFLLE9BQU87QUFDekIsU0FBUyxHQUFHLEdBQUc7Q0FDYixJQUFJLElBQUksS0FBSyxFQUFFO0NBQ2YsT0FBTyxPQUR5QixPQUFPLEtBQUssY0FBYyxFQUFFLGFBQWE7QUFFM0U7QUFDQSxJQUFJLEtBQUs7QUFDVCxTQUFTLEdBQUcsR0FBRyxHQUFHO0NBQ2hCLE9BQU8sU0FBUyxHQUFHO0VBQ2pCLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQztDQUNmO0FBQ0Y7QUFDQSxJQUFvRCxLQUF6QkMsR0FBRyxPQUFPLE1BQU0sTUFBZTtBQUFHLElBQUEsS0FBSztBQUFJLElBQUEsS0FBSztBQUEyQixJQUFBLEtBQWxCLE9BQU8sVUFBbUI7QUFDOUcsU0FBUyxHQUFHLEdBQUc7Q0FDYixJQUFJLENBQUMsR0FBRyxDQUFDLEdBQ1AsT0FBTyxHQUFHLENBQUM7Q0FDYixJQUFJLElBQUksQ0FBQztDQUNULEtBQUssSUFBSSxLQUFLLE9BQU8sQ0FBQyxHQUNwQixHQUFHLEtBQUssR0FBRyxDQUFDLEtBQUssS0FBSyxpQkFBaUIsRUFBRSxLQUFLLENBQUM7Q0FDakQsT0FBTztBQUNUO0FBQ0EsSUFBSSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQzNCLFNBQVMsR0FBRyxHQUFHO0NBQ2IsT0FBTyxLQUFLLFFBQVEsR0FBRyxFQUFFLE1BQU0sS0FBSyxDQUFDLEdBQUcsQ0FBQztBQUMzQztBQUNBLElBQUksS0FBSztBQUFJLElBQUEsS0FBSztBQUFJLElBQUEsS0FBSztBQUFJLElBQUEsS0FBSztBQUNwQyxTQUFTLEdBQUcsR0FBRztDQUNiLE9BQU8sR0FBRyxDQUFDLElBQUksR0FBRyxDQUFDLElBQUksR0FBRyxDQUFDO0FBQzdCO0FBQ0EsSUFBSSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQ3BDLFNBQVMsR0FBRyxHQUFHO0NBQ2IsT0FBTyxHQUFHLEdBQUcsSUFBSSxFQUFFO0FBQ3JCO0FBQ0EsSUFBYSxLQUFLQztBQUFJLElBQUEsS0FBSztBQUEwQixJQUFBLEtBQWxCLE9BQU8sVUFBbUI7QUFDN0QsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0NBQzVCLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxHQUFHLENBQUMsR0FBRyxJQUFJLEVBQUU7Q0FDakMsSUFBSSxLQUR5QyxHQUFHLENBQVEsQ0FBQyxDQUFDLFVBQzVDLENBQUMsR0FDYixPQUFPLENBQUM7Q0FDVixLQUFLLElBQUksSUFBSSxHQUFHLE1BQU87RUFDckIsSUFBSSxJQUFJLEVBQUU7RUFDVixJQUFJLEVBQUUsSUFBSSxLQUFLLElBQUksR0FBRyxLQUFLLEdBQUcsQ0FBQyxJQUM3QixPQUFPLENBQUM7Q0FDWjtDQUNBLElBQUksSUFBSSxFQUFFLElBQUksQ0FBQyxHQUFHLElBQUksRUFBRSxJQUFJLENBQUM7Q0FDN0IsSUFBSSxLQUFLLEdBQ1AsT0FBTyxLQUFLLEtBQUssS0FBSztDQUN4QixJQUFJLElBQUksQ0FBQztDQUNULEVBQUUsSUFBSSxHQUFHLENBQUMsR0FBRyxFQUFFLElBQUksR0FBRyxDQUFDO0NBQ3ZCLEtBQUssSUFBSSxJQUFJLEdBQUcsRUFBRSxJQUFJLElBQUs7RUFDekIsSUFBSSxFQUFFO0VBQ04sSUFBSSxJQUFJLEVBQUUsSUFBSSxJQUFJLEVBQUU7RUFDcEIsSUFBSSxHQUNGLElBQUksSUFBSSxJQUFJLEVBQUUsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsSUFBSSxFQUFFLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDO0VBQ3RELElBQUksRUFBRSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssRUFBRSxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsSUFBSSxJQUFJO0dBQ3JELElBQUksQ0FBQztHQUNMO0VBQ0Y7RUFDQSxNQUFNLElBQUksS0FBSztDQUNqQjtDQUNBLElBQUksS0FBSyxDQUFDLEdBQUc7RUFDWCxJQUFJLElBQUksRUFBRSxhQUFhLElBQUksRUFBRTtFQUM3QixLQUFLLEtBQUssaUJBQWlCLEtBQUssaUJBQWlCLEtBQUssRUFBRSxPQUFPLEtBQUssY0FBYyxhQUFhLEtBQUssT0FBTyxLQUFLLGNBQWMsYUFBYSxPQUFPLElBQUksQ0FBQztDQUN6SjtDQUNBLE9BQU8sRUFBRSxPQUFPLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQyxHQUFHO0FBQ25DO0FBQ0EsSUFBSSxLQUFLO0FBQStDLElBQUEsS0FBcEJDLEdBQUdDLElBQUksVUFBbUI7QUFBNkMsSUFBQSxLQUFuQkMsR0FBR0MsSUFBSSxTQUFrQjtBQUF5QyxJQUFBLEtBQWZDLEdBQUdDLElBQUksS0FBYztBQUE2QyxJQUFBLEtBQW5CQyxHQUFHQyxJQUFJLFNBQWtCO0FBQUcsSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQWdCLElBQUEsS0FBSztBQUFtQixJQUFBLEtBQUs7QUFBb0IsSUFBQSxLQUFLO0FBQWdCLElBQUEsS0FBSztBQUFvQixJQUFBLEtBQUs7QUFBcUIsSUFBQSxLQUFLLEdBQUcsRUFBRTtBQUFHLElBQUEsS0FBSyxHQUFHLEVBQUU7QUFBRyxJQUFBLEtBQUssR0FBRyxFQUFFO0FBQUcsSUFBQSxLQUFLLEdBQUcsRUFBRTtBQUFHLElBQUEsS0FBSyxHQUFHLEVBQUU7QUFBRyxJQUFBLEtBQUs7Q0FDeGUsTUFBTSxHQUFHLElBQUksbUJBQUcsSUFBSSxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxNQUFNLEdBQUcsSUFBSSxHQUFHLENBQUMsS0FBSyxNQUFNLE1BQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQyxLQUFLLE1BQU0sTUFBTSxHQUFHLElBQUksR0FBRyxDQUFDLEtBQUssTUFBTSxNQUFNLEdBQUcsSUFBSSxHQUFHLENBQUMsS0FBSyxRQUFRLEtBQUssU0FBUyxHQUFHO0NBQ3BMLElBQUksSUFBSSxHQUFHLENBQUMsR0FBRyxJQUFJLEtBQUssS0FBSyxFQUFFLGNBQWMsS0FBSyxHQUFHLElBQUksSUFBSSxHQUFHLENBQUMsSUFBSTtDQUNyRSxJQUFJLEdBQ0YsUUFBUSxHQUFSO0VBQ0UsS0FBSyxJQUNILE9BQU87RUFDVCxLQUFLLElBQ0gsT0FBTztFQUNULEtBQUssSUFDSCxPQUFPO0VBQ1QsS0FBSyxJQUNILE9BQU87RUFDVCxLQUFLLElBQ0gsT0FBTztDQUNYO0NBQ0YsT0FBTztBQUNUO0FBQ0EsSUFBSSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUksSUFBQSxLQUFLO0FBQUcsSUFBQSxLQUFLO0FBQXNCLElBQUEsS0FBSztBQUFrQixJQUFBLEtBQUs7QUFBMEMsSUFBQSxLQUFsQixPQUFPLFVBQW1CO0FBQ3RNLFNBQVMsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRztDQUM1QixJQUFJLElBQUksR0FBRyxDQUFDLEdBQUcsSUFBSSxHQUFHLENBQUMsR0FBRyxJQUFJLElBQUksS0FBSyxHQUFHLENBQUMsR0FBRyxJQUFJLElBQUksS0FBSyxHQUFHLENBQUM7Q0FDL0QsSUFBSSxLQUFLLEtBQUssS0FBSyxHQUFHLElBQUksS0FBSyxLQUFLLEtBQUs7Q0FDekMsSUFBSSxJQUFJLEtBQUssSUFBSSxJQUFJLEtBQUssSUFBSSxJQUFJLEtBQUs7Q0FDdkMsSUFBSSxLQUFLLEdBQUcsQ0FBQyxHQUFHO0VBQ2QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUNQLE9BQU8sQ0FBQztFQUNWLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQztDQUNmO0NBQ0EsSUFBSSxLQUFLLENBQUMsR0FDUixPQUFPLE1BQU0sSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLEdBQUcsQ0FBQyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUM7Q0FDeEYsSUFBSSxFQUFFLElBQUksS0FBSztFQUNiLElBQUksSUFBSSxLQUFLLEdBQUcsS0FBSyxHQUFHLGFBQWEsR0FBRyxJQUFJLEtBQUssR0FBRyxLQUFLLEdBQUcsYUFBYTtFQUN6RSxJQUFJLEtBQUssR0FBRztHQUNWLElBQUksSUFBSSxJQUFJLEVBQUUsTUFBTSxJQUFJLEdBQUcsSUFBSSxJQUFJLEVBQUUsTUFBTSxJQUFJO0dBQy9DLE9BQU8sTUFBTSxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDO0VBQzdDO0NBQ0Y7Q0FDQSxPQUFPLEtBQUssTUFBTSxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDO0FBQzVEO0FBQ0EsSUFBYSxLQUFLQztBQUFJLElBQUEsS0FBSztBQUMzQixTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0NBQ3pCLE9BQU8sTUFBTSxJQUFJLENBQUMsSUFBSSxLQUFLLFFBQVEsS0FBSyxRQUFRLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxNQUFNLEtBQUssTUFBTSxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUM7QUFDOUc7QUFDQSxJQUFhLEtBQUtDO0FBQ2xCLFNBQVMsR0FBRyxHQUFHLEdBQUc7Q0FDaEIsT0FBTyxHQUFHLEdBQUcsQ0FBQztBQUNoQjtBQUVBLElBQU0sS0FBcUIsbUJBQUdDLEVBQUU7QUFDaEMsU0FBUyxFQUFFLEdBQUcsR0FBRztDQUNmLE9BQU8sT0FBTyxFQUFFLE9BQU8sYUFBYSxFQUFFLElBQUksQ0FBQyxJQUFJLEVBQUU7QUFDbkQ7QUFDQSxTQUFTLEdBQUcsR0FBRztDQUNiLE9BQU8sT0FBTyxFQUFFLFNBQVMsYUFBYSxFQUFFLE1BQU0sSUFBSSxFQUFFO0FBQ3REO0FBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRztDQUNoQixPQUFPLEdBQUcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxLQUFLLEVBQUUsT0FBTyxHQUFHLE1BQU0sTUFBTSxFQUFFLEdBQUcsRUFBRSxTQUFTLENBQUMsQ0FBQztBQUN0RTtBQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUc7Q0FDaEIsTUFBTSxJQUFJLENBQUM7Q0FDWCxPQUFPLEVBQUUsU0FBUyxNQUFNO0VBQ3RCLEVBQUUsRUFBRSxNQUFNO0NBQ1osQ0FBQyxHQUFHO0FBQ047QUFDQSxTQUFTLEtBQUssQ0FDZDtBQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUc7Q0FDaEIsUUFBUSxHQUFHLEdBQUcsTUFBTTtFQUNsQixFQUFFLGVBQWUsR0FBRyxFQUFFLFNBQVMsTUFBTSxLQUFLLEVBQUUsR0FBRyxHQUFHLENBQUMsQ0FBQztDQUN0RDtBQUNGO0FBQ0EsU0FBUyxHQUFHLEVBQUUsTUFBTSxHQUFHLGFBQWEsR0FBRyxjQUFjLEdBQUcsZ0JBQWdCLEtBQUs7Q0FDM0UsTUFBTSxFQUFFLE1BQU0sR0FBRyxPQUFPLE1BQU0sRUFBRSxHQUFHLEVBQUUsS0FBSyxHQUFHLEtBQUssR0FBRyxHQUFHLE1BQU0sRUFBRSxFQUFFLGFBQWEsQ0FBQyxDQUFDLEdBQUcsRUFBRSxpQkFBaUIsTUFBTTtDQUM3RyxRQUFBLEdBQU9DLGFBQUFBLGNBQUFBLENBQ0wsT0FDQTtFQUFFLEdBQUc7RUFBRyxLQUFLO0VBQUcsS0FBSyxHQUFHLEVBQUU7Q0FBUSxHQUNsQyxLQUFBLEdBQUlBLGFBQUFBLGNBQUFBLENBQUcsT0FBTztFQUFFLEdBQUc7RUFBRyxLQUFLLEdBQUcsRUFBRTtDQUFLLENBQUMsSUFBSSxPQUFBLEdBQzFDQyxtQkFBQUEsSUFBQUEsQ0FBRSxPQUFPO0VBQUUsV0FBVztFQUFvQixPQUFPLEVBQUUsV0FBVyxHQUFHLEVBQUUsV0FBVyxTQUFTO0VBQUcsVUFBVSxFQUFFO0NBQU0sR0FBRyxHQUFHLEVBQUUsU0FBUyxHQUM3SCxLQUFBLEdBQUlELGFBQUFBLGNBQUFBLENBQUcsT0FBTztFQUFFLEdBQUc7RUFBRyxLQUFLLEdBQUcsRUFBRTtDQUFLLENBQUMsSUFBSSxJQUM1QztBQUNGO0FBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHO0NBQ25CLFFBQVEsSUFBSSxLQUFLO0FBQ25CO0FBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUc7Q0FDdEIsTUFBTSxJQUFJLEtBQUssSUFBSTtDQUNuQixRQUFRLElBQUksS0FBSztBQUNuQjtBQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0NBQ3RCLFFBQVEsSUFBSSxLQUFLLElBQUksSUFBSTtBQUMzQjtBQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUc7Q0FDekIsSUFBSSxLQUFBLEdBQUlFLGlCQUFBQSxRQUFBQSxDQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztDQUN2QixJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssR0FBRztFQUNwQixNQUFNLElBQUksRUFBRSxJQUFJLENBQUM7RUFDakIsSUFBSSxFQUFFLElBQUksR0FBRyxJQUFJLElBQUksRUFBRSxFQUFFO0NBQzNCO0NBQ0EsT0FBTyxFQUFFLFFBQVEsSUFBSSxJQUFLO0VBQ3hCLElBQUksS0FBQSxHQUFJQSxpQkFBQUEsUUFBQUEsQ0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztFQUN6QyxFQUFFLFFBQVEsS0FBSyxFQUFFLFFBQVEsTUFBTSxJQUFJLEVBQUUsSUFBSSxFQUFFLE1BQU0sR0FBRyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsR0FBRyxJQUFJO0NBQ3hFO0FBQ0Y7QUFDQSxJQUFNLEtBQUs7QUFDWCxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUc7Q0FDbkIsTUFBTSxJQUFJO0VBQ1IsUUFBUTtFQUNSLFFBQVE7RUFDUixNQUFNO0VBQ04sS0FBSztFQUNMLE9BQU87RUFDUCxNQUFNO0NBQ1I7Q0FDQSxJQUFJLElBQUksUUFBUSxJQUFJO0NBQ3BCLE9BQU8sT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sTUFBTTtFQUNoQyxNQUFNLElBQUk7RUFDVixJQUFJLElBQUksRUFBRTtFQUVWLElBRFUsSUFBSSxFQUFFLEtBQTRDLEtBQXBDLEVBQUUsTUFBTSxFQUFFLEtBQUssSUFBSSxLQUFTLEtBRWxELE9BQU8sSUFBSSxHQUFHLENBQUM7Q0FDbkIsQ0FBQyxHQUFHO0FBQ047QUFDQSxJQUFNLEtBQUs7Q0FDVCxRQUFRO0NBQ1IsUUFBUTtDQUNSLE1BQU07Q0FDTixLQUFLO0NBQ0wsT0FBTztDQUNQLE1BQU07QUFDUjtBQUNBLFNBQVMsR0FBRyxHQUFHO0NBQ2IsSUFBSSxDQUFDLEdBQUcsSUFDTixNQUFNLElBQUksTUFBTSxRQUFRLEVBQUUsbUJBQW1CO0NBQy9DLE9BQU8sR0FBRztBQUNaO0FBQ0EsU0FBUyxHQUFHLEVBQUUsZUFBZSxHQUFHLGFBQWEsR0FBRyxVQUFVLEdBQUcsWUFBWSxHQUFHLFlBQVksR0FBRyxjQUFjLEdBQUcsWUFBWSxLQUFLO0NBQzNILE1BQU0sSUFBSSxJQUFJO0NBQ2QsT0FBTyxDQUNMLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxVQUFVLElBQUksSUFBSSxHQUMxQyxLQUFLLElBQUksSUFBSSxJQUFJLEtBQUssTUFBTSxXQUFXLElBQUksSUFBSSxDQUNqRDtBQUNGO0FBQ0EsU0FBUyxHQUFHLEVBQUUsZUFBZSxHQUFHLGFBQWEsR0FBRyxpQkFBaUIsR0FBRyxlQUFlLEdBQUcsYUFBYSxLQUFLO0NBQ3RHLE1BQU0sSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLElBQUksR0FBRyxDQUFDLEdBQUcsSUFBSSxLQUFLLElBQUksR0FBRyxDQUFDLEdBQUcsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FBRyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxJQUFJO0NBQ2xHLE9BQU87RUFDTCxNQUFNO0VBQ04sT0FBTyxLQUFLLElBQUksR0FBRyxDQUFDO0VBQ3BCLGVBQWU7RUFDZixnQkFBZ0I7Q0FDbEI7QUFDRjtBQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUc7Q0FDaEIsTUFBTSxFQUFFLFlBQVksTUFBTSxHQUFHLElBQUksQ0FBQztDQUNsQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLEtBQzVCLEVBQUUsRUFBRSxFQUFFLElBQUksQ0FBQyxLQUFLO0VBQ2QsT0FBTztFQUNQLE9BQU8sRUFBRTtDQUNYO0NBQ0YsT0FBTztBQUNUO0FBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRztDQUNoQixJQUFJLEdBQUc7Q0FDUCxNQUFNLElBQUksQ0FBQyxHQUFHLElBQUksT0FBTyxLQUFLLENBQUM7Q0FDL0IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLO0VBQ2pDLE1BQU0sSUFBSSxFQUFFLEVBQUU7RUFDZCxFQUFFLEtBQUs7R0FDTCxPQUFPLEVBQUU7R0FDVCxPQUFPLEVBQUU7R0FDVCxPQUFPLENBQUM7RUFDVjtDQUNGO0NBQ0EsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUM1QixJQUFJLEVBQUUsRUFBRSxDQUFDLGVBQWUsS0FBSyxPQUFPLElBQUksRUFBRSxFQUFFLENBQUMsZUFBZSxPQUFPLEtBQUssSUFBSSxFQUFFLFdBQVcsS0FBSyxHQUFHO0VBQy9GLE1BQU0sSUFBSSxJQUFJLElBQUksRUFBRSxFQUFFLENBQUMsZUFBZSxPQUFPLEtBQUssSUFBSSxFQUFFLE1BQU0sVUFBVTtFQUN4RSxLQUFLLEVBQUUsTUFBTSxLQUFLLEVBQUUsRUFBRTtDQUN4QjtDQUNGLE9BQU87QUFDVDtBQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0NBQ3RCLE1BQU0sRUFBRSxrQkFBa0IsR0FBRyxnQkFBZ0IsTUFBTTtDQUNuRCxPQUFPLEVBQUUsUUFBUSxNQUFNO0VBQ3JCLE1BQU0sS0FBQSxHQUFJQSxpQkFBQUEsUUFBQUEsQ0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEtBQUssR0FBRyxLQUFBLEdBQUlBLGlCQUFBQSxRQUFBQSxDQUFHLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsS0FBSztFQUNuRSxPQUFPLEtBQUs7Q0FDZCxDQUFDO0FBQ0g7QUFDQSxJQUFNLEtBQUs7QUFDWCxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxJQUFJO0NBQzNCLE9BQU8sRUFBRSxnQkFBZ0IsSUFBSSxFQUFFLGdCQUFnQixFQUFFLGtCQUFrQixFQUFFLGdCQUFnQixFQUFFLGlCQUFpQixJQUFJLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxJQUFJLElBQUksRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRSxTQUFTLElBQUksSUFBSSxFQUFFO0FBQ2xNO0FBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUc7Q0FDL0IsSUFBSSxJQUFJO0NBQ1IsTUFBTSxJQUFJLE1BQU0sSUFBSSxFQUFFLFdBQVcsVUFBVTtDQUMzQyxJQUFJLEVBQUUsV0FBVyxTQUFTLEVBQUUsV0FBVyxRQUFRLE1BQU07RUFDbkQsRUFBRSxXQUFXLE1BQU0sSUFBSSxHQUFHLElBQUksS0FBSyxJQUFJLEdBQUcsR0FBRyxFQUFFLFdBQVcsU0FBUyxJQUFJLENBQUM7RUFDeEUsR0FBRztHQUNELElBQUksSUFBSTtHQUNSLEtBQUssSUFBSSxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSyxHQUFHLEtBQUs7SUFDdEMsTUFBTSxJQUFJLEVBQUU7SUFDWixJQUFJLEVBQUUsV0FBVyxRQUFRLFFBQVEsRUFBRSxXQUFXLFNBQVMsR0FBRyxFQUFFLFlBQVksRUFBRSxZQUFZLENBQUMsR0FBRztLQUN4RixJQUFJO0tBQ0o7SUFDRjtHQUNGO0dBQ0EsS0FBSyxTQUFTLEVBQUUsV0FBVyxNQUFNLEVBQUUsV0FBVyxNQUFNLEVBQUUsV0FBVyxTQUNqRSxLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJLEtBQUssSUFBSSxHQUFHLEVBQUUsV0FBVyxNQUFNLEVBQUUsV0FBVyxTQUFTLElBQUksQ0FBQztFQUM1RixTQUFTO0NBQ1g7Q0FDQSxPQUFPO0VBQ0wsYUFBYTtFQUNiLGdCQUFnQjtFQUNoQixTQUFTLEVBQUUsV0FBVztDQUN4QjtBQUNGO0FBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRztDQUN6QixJQUFJLEdBQUc7Q0FDUCxNQUFNLElBQUksTUFBTSxPQUFPLElBQUksRUFBRSxlQUFlLE9BQU8sS0FBSyxJQUFJLEVBQUUsV0FBVyxNQUFNO0NBQy9FLE9BQU8sRUFBRSxjQUFjLEVBQUUsV0FBVyxRQUFRLFNBQVMsRUFBRSxXQUFXLE1BQU0sSUFBSSxHQUFHLElBQUksS0FBSyxJQUFJLEdBQUcsR0FBRyxFQUFFLFdBQVcsU0FBUyxDQUFDLElBQUk7RUFBRSxhQUFhO0VBQUcsZ0JBQWdCO0VBQUcsV0FBVyxJQUFJLEVBQUUsZUFBZSxPQUFPLEtBQUssSUFBSSxFQUFFLFFBQVE7Q0FBRTtBQUNoTztBQUNBLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRztDQUNsQixPQUFPLEVBQUUsUUFBUSxHQUFHLE1BQU0sSUFBSSxHQUFHLENBQUM7QUFDcEM7QUFDQSxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0NBQ3pCLE1BQU0sSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsSUFBSSxHQUFHLEdBQUcsQ0FBQztDQUNqQyxLQUFLLE1BQU0sS0FBSyxHQUFHO0VBQ2pCLE1BQWdCLEVBQUUsT0FBTyxHQUFHLE9BQU8sTUFBekIsRUFBRSxJQUFnQyxJQUFJLEdBQUcsQ0FBQyxHQUFtRCxFQUFFLGFBQWEsTUFBTSxHQUFHLEdBQXBFLEVBQUUsZUFBZSxLQUFLLElBQUksRUFBRSxhQUFhLEdBQWlDLEdBQUcsR0FBRyxDQUFDO0VBQzVJLEVBQUUsS0FBSyxDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sSUFBSSxFQUFFLEtBQUssS0FBSyxJQUFJLEdBQUcsQ0FBQyxDQUFDO0NBQ2hFO0NBQ0EsT0FBTztFQUNMLFFBQVEsR0FBRyxDQUFDO0VBQ1osY0FBYztFQUNkLFdBQVc7Q0FDYjtBQUNGO0FBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRztDQUN6QixJQUFJLElBQUksR0FBRyxJQUFJO0NBQ2YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLO0VBQ2pDLE1BQU0sSUFBSSxJQUFJLEdBQUcsR0FBRyxFQUFFLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLElBQUksR0FBRyxHQUFHLEVBQUUsSUFBSSxHQUFHLEdBQUcsQ0FBQztFQUM5RCxJQUFJLEVBQUUsYUFBYSxJQUFJLEVBQUU7Q0FDM0I7Q0FDQSxPQUFPO0VBQUUsYUFBYTtFQUFHLGdCQUFnQjtDQUFFO0FBQzdDO0FBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUc7Q0FDMUQsTUFBTSxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLEdBQUc7RUFDckMsTUFBTTtFQUNOLE1BQU07RUFDTixjQUFjO0VBQ2QsY0FBYztFQUNkLFVBQVU7RUFDVixjQUFjO0VBQ2QsWUFBWTtFQUNaLFFBQVE7RUFDUixlQUFlO0NBQ2pCLENBQUMsQ0FBQztDQUNGLElBQUksRUFBRSxXQUFXLEdBQ2YsT0FBTztFQUNMLGdCQUFnQixDQUFDO0VBQ2pCLFFBQVE7RUFDUixjQUFjLENBQUM7RUFDZixXQUFXLENBQUM7Q0FDZDtDQUNGLE1BQU0sSUFBSSxHQUFHLEdBQUcsQ0FBQyxHQUFHLElBQUksRUFBRSxLQUFLLE1BQU0sR0FBRztFQUN0QyxNQUFNO0VBQ04sTUFBTTtFQUNOLGlCQUFpQjtFQUNqQixlQUFlO0VBQ2YsYUFBYTtFQUNiLGFBQWE7RUFDYixZQUFZO0VBQ1osaUJBQWlCO0VBQ2pCLGlCQUFpQjtDQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsUUFBUSxHQUFHLGNBQWMsR0FBRyxXQUFXLE9BQU8sR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUM7Q0FDeEYsT0FBTztFQUFFLGdCQUFnQjtFQUFHLFFBQVE7RUFBRyxjQUFjO0VBQUcsV0FBVztDQUFHO0FBQ3hFO0FBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRztDQUNoQixPQUFPLElBQUk7QUFDYjtBQUNBLFNBQVMsR0FBRyxFQUFFLE1BQU0sR0FBRyxNQUFNLEdBQUcsaUJBQWlCLEdBQUcsZUFBZSxHQUFHLGFBQWEsR0FBRyxhQUFhLEdBQUcsWUFBWSxHQUFHLGlCQUFpQixHQUFHLGlCQUFpQixLQUFLO0NBQzdKLE1BQU0sSUFBSSxFQUFFLEdBQUcsRUFBRSxTQUFTLEdBQUcsSUFBSSxHQUFHO0VBQ2xDLGVBQWUsRUFBRSxHQUFHLEVBQUUsZ0JBQWdCO0VBQ3RDLGFBQWEsRUFBRSxHQUFHLEVBQUUsY0FBYztFQUNsQyxpQkFBaUI7RUFDakIsZUFBZTtFQUNmLGFBQWE7Q0FDZixDQUFDO0NBQ0QsSUFBSSxHQUNGLE9BQU8sRUFBRSxNQUFNLE1BQU0sRUFBRSxRQUFRLEVBQUUsRUFBRSxHQUFHLEVBQUUsWUFBWSxJQUFJLEVBQUUsUUFBUSxDQUFDLEVBQUUsV0FBVyxFQUFFLFVBQVUsRUFBRSxVQUFVLE1BQU0sT0FBTyxJQUFJLE1BQU0sSUFBSSxJQUFJO0VBQ3JJLElBQUk7RUFDSixZQUFZO0NBQ2Q7QUFDSjtBQUNBLFNBQVMsR0FBRyxFQUFFLE1BQU0sR0FBRyxNQUFNLEdBQUcsY0FBYyxHQUFHLGNBQWMsR0FBRyxVQUFVLEdBQUcsY0FBYyxHQUFHLFlBQVksR0FBRyxRQUFRLEdBQUcsZUFBZSxLQUFLO0NBQzVJLElBQUksQ0FBQyxLQUFLLENBQUMsR0FDVCxPQUFPO0NBQ1QsTUFBTSxJQUFJLEVBQUUsR0FBRyxFQUFFLFNBQVMsR0FBRyxJQUFJLE1BQU0sR0FBRyxJQUFJLE1BQU0sR0FBRyxDQUFDLEdBQUcsS0FBSyxHQUFHO0VBQ2pFLGVBQWUsRUFBRSxHQUFHLEVBQUUsZ0JBQWdCO0VBQ3RDLGFBQWEsRUFBRSxHQUFHLEVBQUUsY0FBYztFQUNsQyxZQUFZO0VBQ1osWUFBWTtFQUNaLFVBQVU7RUFDVixjQUFjO0VBQ2QsWUFBWTtDQUNkLENBQUM7Q0FDRCxPQUFPO0VBQ0wsR0FBRztHQUNGLEVBQUUsbUJBQW1CO0dBQ3JCLEVBQUUsaUJBQWlCO0dBQ25CLEVBQUUsZUFBZSxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsVUFBVSxJQUFJLEVBQUUsR0FBRyxFQUFFLFlBQVk7Q0FDbkU7QUFDRjtBQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUcsR0FBRztDQUNuQixNQUFNLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxLQUFLLElBQUksS0FBSztDQUN2QyxPQUFPLENBQUMsR0FEc0MsSUFBSSxJQUFJLENBQzFDO0FBQ2Q7QUFDQSxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRztDQUMvQixNQUFNLElBQUksRUFBRSxRQUFRLElBQUksRUFBRSxpQkFBaUIsSUFBSSxFQUFFLGVBQWUsSUFBSSxFQUFFLGlCQUFpQixFQUFFLGtCQUFrQixJQUFJLElBQUksR0FBRyxJQUFJO0VBQ3hILEdBQUc7RUFDSCxrQkFBa0I7RUFDbEIsZ0JBQWdCO0NBQ2xCLEdBQUcsSUFBSSxLQUFLLElBQUksS0FBSztDQUNyQixJQUFJLE1BQU0sS0FBSyxLQUFLLElBQUksS0FBSyxLQUFLLElBQUksS0FBSyxHQUFHO0VBQzVDLE1BQU0sQ0FBQyxHQUFHLEtBQUssR0FBRyxHQUFHLEdBQUcsQ0FBQztFQUN6QixFQUFFLGtCQUFrQixHQUFHLEVBQUUsZ0JBQWdCO0VBQ3pDLE1BQU0sSUFBSTtHQUNSLEdBQUc7R0FDSCxHQUFHO0VBQ0wsR0FBRyxJQUFJLEdBQUcsRUFBRSxPQUFPLEVBQUUsTUFBTTtFQUMzQixPQUFPLE9BQU8sR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsaUJBQWlCLEVBQUUsZUFBZSxFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsaUJBQWlCLEVBQUUsWUFBWSxFQUFFLGNBQWMsRUFBRSxjQUFjLEVBQUUsVUFBVSxFQUFFLGNBQWMsRUFBRSxZQUFZLEVBQUUsZUFBZSxFQUFFLGVBQWUsQ0FBQztDQUN2TztDQUNBLE9BQU87QUFDVDtBQUNBLElBQU0sS0FBcUIsdUJBQU8sT0FBdUIsdUJBQU8sZUFBZTtDQUM3RSxXQUFXO0NBQ1gsWUFBWTtDQUNaLHFCQUFxQjtDQUNyQiw4QkFBOEI7Q0FDOUIsdUJBQXVCO0NBQ3ZCLDJCQUEyQjtDQUMzQiwyQkFBMkI7Q0FDM0IsV0FBVztDQUNYLHVCQUF1QjtDQUN2QixvQ0FBb0M7Q0FDcEMsZ0JBQWdCO0NBQ2hCLGdCQUFnQjtDQUNoQixpQkFBaUI7Q0FDakIsbUJBQW1CO0NBQ25CLHlCQUF5QjtDQUN6QixZQUFZO0NBQ1osYUFBYTtDQUNiLGlCQUFpQjtDQUNqQixjQUFjO0NBQ2QsWUFBWTtDQUNaLGNBQWM7Q0FDZCxjQUFjO0NBQ2QsVUFBVTtDQUNWLFlBQVk7Q0FDWixvQkFBb0I7QUFDdEIsR0FBRyxPQUFPLGFBQWEsRUFBRSxPQUFPLFNBQVMsQ0FBQyxDQUFDLEdBQUcsS0FBSztDQUNqRCxVQUFVO0NBQ1YsT0FBTztDQUNQLFFBQVE7Q0FDUixZQUFZO0NBQ1osZ0JBQWdCO0NBQ2hCLG1CQUFtQjtDQUNuQixpQkFBaUI7Q0FDakIsa0JBQWtCO0NBQ2xCLGFBQWE7Q0FDYixhQUFhO0NBQ2IsUUFBUTtBQUNWLEdBQUcsS0FBSztDQUNOLFlBQVk7Q0FDWixnQkFBZ0I7Q0FDaEIsaUJBQWlCO0NBQ2pCLGtCQUFrQjtDQUNsQixtQkFBbUI7Q0FDbkIsYUFBYTtDQUNiLGFBQWE7Q0FDYixRQUFRO0FBQ1YsR0FBRyxLQUFLO0NBQ04sWUFBWTtDQUNaLFFBQVE7QUFDVixHQUFHLEtBQUssRUFDTixpQkFBaUIsRUFDbkIsR0FBRyxLQUFLLEVBQ04sUUFBUSxXQUNWLEdBQUcsS0FBSyxFQUNOLGtCQUFrQixNQUNwQixHQUFHLEtBQUssRUFDTixRQUFRLFdBQ1YsR0FBRyxLQUFLO0NBQ04sVUFBVTtDQUNWLE9BQU87Q0FDUCxVQUFVO0NBQ1YsVUFBVTtDQUNWLFFBQVE7Q0FDUixLQUFLO0NBQ0wsTUFBTTtDQUNOLFFBQVE7Q0FDUixRQUFRO0FBQ1YsR0FBRyxLQUFLO0NBQ04sVUFBVTtDQUNWLE9BQU87Q0FDUCxVQUFVO0NBQ1YsVUFBVTtDQUNWLFFBQVE7Q0FDUixLQUFLO0NBQ0wsT0FBTztDQUNQLFFBQVE7Q0FDUixRQUFRO0FBQ1YsR0FPRyxLQUFBLGFBQU8sY0FBYztDQU50Qix5QkFBeUIsUUFBUSxLQUFLLGlEQUErQyxHQUFHLENBQUM7Q0FDekYsOEJBQThCLFFBQVEsS0FBSyxzREFBb0QsR0FBRztDQUNsRyxzQ0FBc0MsUUFBUSxLQUFLLDhEQUE0RCxHQUFHO0NBQ2xILGtCQUFrQjtFQUNoQixRQUFRLEtBQUssMkNBQXlDO0NBQ3hEO0FBQ3VCLENBQUMsR0FBRyxFQUFFLFVBQVUsSUFBSSxVQUFVLE9BQU87QUFDOUQsSUFBTSxLQUFOLGNBQUEsYUFBbUIsVUFBVTtDQUMzQixZQUFZLEdBQUc7RUFDYixNQUFNLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxvQkFBb0I7R0FDeEQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsYUFBYTtJQUNYLE1BQU0sRUFBRSxrQkFBa0IsR0FBRyxnQkFBZ0IsR0FBRyxpQkFBaUIsR0FBRyxlQUFlLEdBQUcsYUFBYSxHQUFHLGNBQWMsR0FBRyxlQUFlLE1BQU0sS0FBSztJQUNqSixPQUFPO0tBQ0wsa0JBQWtCO0tBQ2xCLGdCQUFnQjtLQUNoQixpQkFBaUI7S0FDakIsZUFBZTtLQUNmLGFBQWE7S0FDYixjQUFjO0tBQ2QsZUFBZTtJQUNqQjtHQUNGO0VBQ0YsQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLHlCQUF5QjtHQUN2RCxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxRQUFRLE1BQU07SUFDWixNQUFNLEVBQUUsaUJBQWlCLEdBQUcsZUFBZSxHQUFHLGFBQWEsTUFBTSxLQUFLO0lBQ3RFLE9BQU8sR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDO0dBQ3RCO0VBQ0YsQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLGlDQUFpQztHQUMvRCxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxRQUFRLE1BQU07SUFDWixNQUFNLEVBQUUsaUJBQWlCLEdBQUcsZUFBZSxHQUFHLGFBQWEsTUFBTSxLQUFLO0lBQ3RFLE9BQU8sR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDO0dBQ3RCO0VBQ0YsQ0FBQyxHQUFHLEtBQUssUUFBUSxFQUNmLGlCQUFpQjtHQUNmLGtCQUFrQixLQUFLO0dBQ3ZCLHVCQUF1QixLQUFLO0dBQzVCLCtCQUErQixLQUFLO0dBQ3BDLFlBQVksS0FBSyxNQUFNO0VBQ3pCLEVBQ0Y7Q0FDRjtDQUNBLFNBQVM7RUFDUCxRQUFBLEdBQU9ELG1CQUFBQSxJQUFBQSxDQUFFLElBQUk7R0FBRSxPQUFPLEtBQUssTUFBTTtHQUFpQixVQUFVLEtBQUssTUFBTTtFQUFTLENBQUM7Q0FDbkY7QUFDRjtBQUNBLElBQU0sS0FBSztBQUFJLElBQUEsWUFBQSxHQUFXRSxhQUFBQSxXQUFBQSxDQUFHLEVBQUU7QUFDL0JELGlCQUFBQSxRQUFHLE9BQU8sRUFBRTtBQUNaLElBQU0sS0FBTixjQUFpQkUsYUFBQUEsVUFBRztDQUNsQixZQUFZLEdBQUc7RUFDYixNQUFNLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxTQUFTO0dBQzdDLFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLE9BQU87SUFDTCxpQkFBaUIsQ0FBQztJQUNsQixVQUFVLENBQUM7SUFDWCxXQUFXO0lBQ1gsaUJBQWlCO0lBQ2pCLFVBQVU7SUFDVixnQkFBZ0I7SUFDaEIsVUFBVSxDQUFDO0lBQ1gsWUFBWTtJQUNaLGFBQWE7SUFDYixZQUFZO0dBQ2Q7RUFDRixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sVUFBVTtHQUN4QyxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxPQUFPO0VBQ1QsQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLGFBQWE7R0FDM0MsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsT0FBTztFQUNULENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxnQkFBZ0I7R0FDOUMsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsT0FBTyxLQUFLO0VBQ2QsQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLGlCQUFpQjtHQUMvQyxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxPQUFPLEtBQUs7RUFDZCxDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sZUFBZTtHQUM3QyxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxPQUFPLEtBQUs7RUFDZCxDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sV0FBVztHQUN6QyxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxRQUFBLEdBQU9DLGFBQUFBLFVBQUFBLENBQUc7RUFDWixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sWUFBWTtHQUMxQyxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxPQUFPLEtBQUs7RUFDZCxDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sYUFBYTtHQUMzQyxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxPQUFPLEtBQUs7RUFDZCxDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sbUJBQW1CO0dBQ2pELFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLE9BQU8sQ0FBQztFQUNWLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxtQkFBbUI7R0FDakQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsT0FBTyxDQUFDO0VBQ1YsQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLGtCQUFrQjtHQUNoRCxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxPQUFPLENBQUM7RUFDVixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0scUJBQXFCO0dBQ25ELFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsTUFBTTtJQUNaLElBQUk7SUFDSixJQUFJLEtBQUssV0FBVyxLQUFLLFFBQVEsU0FBUztLQUN4QyxNQUFNLElBQUksSUFBSSxZQUFZLG1CQUFtQjtNQUMzQyxTQUFTLENBQUM7TUFDVixRQUFRLEVBQ04saUJBQWlCLEVBQ25CO0tBQ0YsQ0FBQztLQUNELENBQUMsSUFBSSxLQUFLLFFBQVEsWUFBWSxRQUFRLEVBQUUsY0FBYyxDQUFDO0lBQ3pEO0dBQ0Y7RUFDRixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sZUFBZTtHQUM3QyxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxRQUFRLE1BQU07SUFDWixLQUFLLE1BQU0sb0JBQW9CLEVBQUUsZUFBZSxHQUFHLEtBQUssa0JBQWtCLENBQUM7R0FDN0U7RUFDRixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sYUFBYTtHQUMzQyxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxRQUFRLE1BQU07SUFDWixDQUFDLEtBQUssTUFBTSxtQkFBbUIsS0FBSyxvQkFBb0IsS0FBSyxrQkFBa0IsQ0FBQyxHQUFHLEtBQUssWUFBWSxHQUFHLE9BQU87R0FDaEg7RUFDRixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sZ0JBQWdCO0dBQzlDLFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsTUFBTTtJQUNaLEtBQUssTUFBTSxvQkFBb0IsRUFBRSxlQUFlLEdBQUcsS0FBSyxrQkFBa0IsQ0FBQztHQUM3RTtFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxjQUFjO0dBQzVDLFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsTUFBTTtJQUNaLENBQUMsS0FBSyxNQUFNLG1CQUFtQixLQUFLLG9CQUFvQixLQUFLLGtCQUFrQixDQUFDLEdBQUcsS0FBSyxZQUFZLEdBQUcsT0FBTztHQUNoSDtFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxxQkFBcUI7R0FDbkQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsUUFBUSxNQUFNO0lBQ1osRUFBRSxnQkFBZ0IsR0FBRyxLQUFLLE1BQU0scUJBQXFCLEtBQUssTUFBTSxrQkFBa0IsS0FBSyxRQUFRLENBQUM7R0FDbEc7RUFDRixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0scUJBQXFCO0dBQ25ELFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsTUFBTTtJQUNaLEtBQUssTUFBTSxrQkFBa0IsRUFBRSxlQUFlLEdBQUcsRUFBRSxnQkFBZ0IsR0FBRyxLQUFLLE1BQU0sY0FBYyxLQUFLLFFBQVEsQ0FBQztHQUMvRztFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxrQkFBa0I7R0FDaEQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsUUFBUSxNQUFNLEtBQUssV0FBVztFQUNoQyxDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sbUJBQW1CO0dBQ2pELFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsTUFBTSxLQUFLLFlBQVk7RUFDakMsQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLGdCQUFnQjtHQUM5QyxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxRQUFRLElBQUksQ0FBQyxNQUFNO0lBQ2pCLE1BQU0sSUFBSSxjQUFjLEtBQUssTUFBTSxLQUFLLFlBQVksSUFBSSxLQUFLLE1BQU0sS0FBSyxjQUFjO0lBQ3RGLE9BQU87S0FDTCxLQUFLLEtBQUs7S0FDVixLQUFLLEtBQUs7S0FDVixPQUFPLEtBQUs7S0FDWixXQUFXLElBQUksSUFBSSxFQUFFLFlBQVksRUFBRSxZQUFZO0tBQy9DLGFBQWEsR0FBRyxLQUFLLGFBQWEsRUFBRSxXQUFXO0tBQy9DLFdBQVcsR0FBRyxLQUFLLFdBQVcsRUFBRSxTQUFTO0tBQ3pDLGNBQWMsR0FBRyxLQUFLLGNBQWMsRUFBRSxZQUFZO0tBQ2xELFlBQVksR0FBRyxLQUFLLFlBQVksRUFBRSxVQUFVO0tBQzVDLGVBQWUsR0FBRyxLQUFLLG1CQUFtQixFQUFFLGFBQWE7S0FDekQsZUFBZSxHQUFHLEtBQUssbUJBQW1CLEVBQUUsYUFBYTtLQUN6RCxPQUFPLE9BQU8sT0FBTyxDQUFDLEdBQUcsS0FBSyxhQUFhLENBQUMsQ0FBQztJQUMvQztHQUNGO0VBQ0YsQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLGtCQUFrQjtHQUNoRCxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxRQUFRLElBQUksQ0FBQyxNQUFNO0lBQ2pCLElBQUksSUFBSTtJQUNSLEVBQUUsa0JBQWtCLEtBQUssSUFBSSxFQUFFO0lBQy9CLElBQUksSUFBSTtJQUNSLE9BQU8sRUFBRSxtQkFBbUIsS0FBSyxJQUFJLEVBQUUsbUJBQW1CO0tBQ3hELE1BQU07TUFDSixLQUFLLEtBQUs7TUFDVixXQUFXO01BQ1gsT0FBTyxPQUFPLE9BQU8sQ0FBQyxHQUFHLElBQUksRUFBRSxTQUFTO0tBQzFDO0tBQ0EsT0FBTztNQUNMLEtBQUssS0FBSztNQUNWLFdBQVc7TUFDWCxPQUFPLE9BQU8sT0FBTyxDQUFDLEdBQUcsSUFBSSxFQUFFLFVBQVU7S0FDM0M7SUFDRjtHQUNGO0VBQ0YsQ0FBQyxHQUFHLEtBQUssbUJBQW1CLENBQUM7Q0FDL0I7Q0FDQSxzQkFBc0IsR0FBRyxHQUFHO0VBQzFCLE9BQU8sQ0FBQyxHQUFHLEtBQUssT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLEtBQUssT0FBTyxDQUFDO0NBQ2hEO0NBQ0EsbUJBQW1CLEdBQUc7RUFDcEIsS0FBSyxTQUFTLEVBQUUsRUFBRSxNQUFNLEVBQUUsS0FBSyxTQUFTLEdBQUcsS0FBSyxZQUFZLEVBQUUsRUFBRSxNQUFNLEVBQUUsS0FBSyxZQUFZLEdBQUcsS0FBSyxlQUFlLEVBQUUsS0FBSyxrQkFBa0IsRUFBRSxFQUFFLE1BQU0sRUFBRSxLQUFLLGVBQWUsSUFBSSxLQUFLLFdBQVcsS0FBSyxnQkFBZ0IsRUFBRSxFQUFFLE1BQU0sRUFBRSxLQUFLLGdCQUFnQixHQUFHLEtBQUssY0FBYyxFQUFFLEVBQUUsTUFBTSxFQUFFLEtBQUssY0FBYztDQUMxUztDQUNBLGVBQWU7RUFDYixNQUFNLEVBQUUsaUJBQWlCLEdBQUcsZUFBZSxHQUFHLGFBQWEsTUFBTSxLQUFLO0VBQ3RFLE9BQU8sR0FBRyxHQUFHLEdBQUcsQ0FBQztDQUNuQjtDQUNBLGFBQWEsR0FBRyxHQUFHO0VBQ2pCLE1BQU0sRUFBRSxVQUFVLE1BQU0sS0FBSztFQUM3QixJQUFJLEdBQUc7R0FDTCxNQUFNLElBQUksS0FBQSxHQUFJSCxpQkFBQUEsUUFBQUEsQ0FBRyxDQUFDLENBQUMsVUFBVSxJQUFJLEtBQUssTUFBTTtHQUM1QyxPQUFPLEtBQUssTUFBTSxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUk7RUFDckMsT0FDRSxPQUFPO0NBQ1g7Q0FDQSxlQUFlLEdBQUc7RUFDaEIsTUFBTSxFQUFFLFVBQVUsTUFBTSxLQUFLO0VBQzdCLElBQUksR0FBRztHQUNMLE1BQU0sSUFBSSxLQUFLLGNBQWM7R0FDN0IsT0FBTyxLQUFLLE9BQU8sSUFBSSxLQUFLLENBQUMsSUFBSSxJQUFJO0VBQ3ZDLE9BQ0UsT0FBTztDQUNYO0NBQ0EsU0FBUyxHQUFHO0VBQ1YsTUFBTSxLQUFBLEdBQUlBLGlCQUFBQSxRQUFBQSxDQUFHLEtBQUssYUFBYTtFQUMvQixPQUFPLEtBQUssTUFBTSxXQUFXLEtBQUssYUFBYSxLQUFLLFFBQVEsQ0FBQyxJQUFJLEtBQUssTUFBTSxVQUFVLFFBQVEsQ0FBQyxDQUFDLElBQUksRUFBRSxRQUFRO0NBQ2hIO0NBQ0EsUUFBUSxHQUFHO0VBQ1QsTUFBTSxJQUFJLEdBQUcsS0FBSyxNQUFNLGlCQUFpQixLQUFLLE1BQU0sZUFBZSxLQUFLLE1BQU0sV0FBVyxHQUFHLElBQUksR0FBRyxLQUFLLE1BQU0sU0FBUyxDQUFDLENBQUMsWUFBWSxJQUFJLEdBQUcsS0FBSyxNQUFNLFNBQVM7RUFDaEssUUFBUSxFQUFFLFFBQVEsSUFBSSxFQUFFLGNBQWMsSUFBSSxLQUFLLE1BQU07Q0FDdkQ7Q0FDQSxlQUFlLEdBQUc7RUFDaEIsTUFBTSxFQUFFLFdBQVcsR0FBRyxPQUFPLE1BQU0sS0FBSztFQUN4QyxJQUFJLEtBQUssTUFBTSxVQUFVO0dBQ3ZCLElBQUksQ0FBQyxLQUFLLE1BQU0sZ0JBQ2QsT0FBTztHQUNULElBQUksSUFBSTtHQUNSLE1BQU0sSUFBSSxHQUFHLEtBQUssTUFBTSxTQUFTLENBQUMsQ0FBQyxXQUFXLElBQUksR0FBRyxLQUFLLE1BQU0sU0FBUztHQUN6RSxLQUFLLE1BQU0sS0FBSyxPQUFPLEtBQUssQ0FBQyxHQUFHO0lBQzlCLE1BQU0sSUFBSSxFQUFFO0lBQ1osSUFBSSxFQUFFLFFBQVEsSUFBSSxFQUFFLFlBQVksR0FDOUIsSUFBSSxTQUFTLEdBQUcsRUFBRSxJQUFJLEVBQUU7U0FFeEI7R0FDSjtHQUNBLE9BQU8sS0FBSyxNQUFNLE1BQU0sUUFBUSxJQUFJLElBQUksSUFBSSxLQUFLLE1BQU0sTUFBTSxRQUFRO0VBQ3ZFLE9BQ0UsT0FBTztDQUNYO0NBQ0EsZ0JBQWdCLEdBQUcsR0FBRztFQUNwQixNQUFNLElBQUksS0FBSyxjQUFjLEtBQUssZUFBZSxJQUFJLEtBQUssY0FBYyxFQUFFLFFBQVEsS0FBSyxNQUFNLGVBQWUsS0FBSyxhQUFhLENBQUM7RUFDL0gsT0FBTyxLQUFLLE1BQU0sU0FBUyxDQUFDLElBQUksTUFBTSxLQUFLLE1BQU0sWUFBWSxPQUFPLE1BQU0sU0FBUyxLQUFLLEtBQUssTUFBTSxZQUFZLFFBQVEsS0FBSyxNQUFNLFlBQVksT0FBTyxJQUFJO0NBQzNKO0NBQ0EsZ0JBQWdCO0VBQ2QsTUFBTSxJQUFJLEtBQUssTUFBTSxrQkFBa0Isa0NBQWtDLENBQUMsR0FBRyxJQUFJLEtBQUssTUFBTSxrQkFBa0IsbUNBQW1DLENBQUM7RUFDbEosR0FBRyxLQUFLLFFBQVEsT0FBTyxDQUFDLENBQUMsVUFBVTtHQUNqQyxPQUFPO0lBQ0wsTUFBTSxLQUFLLGNBQWMsS0FBSztJQUM5QixPQUFPLEtBQUssZUFBZSxLQUFLO0lBQ2hDLEtBQUssQ0FBQztJQUNOLFFBQVEsQ0FBQztHQUNYO0dBQ0EsU0FBUyxLQUFLLE1BQU0sYUFBYSxLQUFLLGNBQWMsS0FBSyxLQUFLLGVBQWU7RUFDL0UsQ0FBQyxDQUFDLENBQUMsVUFBVSxFQUNYLFNBQVMsS0FBSyxNQUFNLFlBQVksS0FBSyxRQUFRLEVBQy9DLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLGNBQWMsTUFBTTtHQUN4QyxJQUFJLEtBQUssTUFBTSxVQUFVO0lBQ3ZCLEtBQUssaUJBQWlCLENBQUMsR0FBRyxLQUFLLGtCQUFrQixDQUFDLENBQUM7SUFDbkQsTUFBTSxJQUFJLEtBQUssUUFBUSxDQUFDO0lBQ3hCLEtBQUssU0FBUztLQUNaLFVBQVUsQ0FBQztLQUNYLFdBQVc7TUFDVCxHQUFHLEVBQUU7TUFDTCxHQUFHLEVBQUU7TUFDTCxRQUFRLEtBQUssZ0JBQWdCO0tBQy9CO0tBQ0EsaUJBQWlCO01BQUUsR0FBRyxFQUFFLE9BQU87TUFBWSxHQUFHLEVBQUUsT0FBTztLQUFVO0tBQ2pFLFVBQVUsS0FBSztLQUNmLGdCQUFnQjtJQUNsQixDQUFDO0dBQ0gsT0FDRSxPQUFPLENBQUM7RUFDWixDQUFDLENBQUMsQ0FBQyxHQUFHLGFBQWEsTUFBTTtHQUN2QixLQUFLLE1BQU0sWUFBWSxLQUFLLFVBQVUsTUFBTTtJQUMxQyxJQUFJLENBQUMsS0FBSyxnQkFDUixPQUFPLEVBQUUsR0FBRyxFQUFFO0lBQ2hCLElBQUksSUFBSSxLQUFLLFNBQVMsQ0FBQztJQUN2QixNQUFNLElBQUksS0FBSyxlQUFlLENBQUM7SUFDL0IsT0FBTyxLQUFLLE1BQU0sd0JBQXdCLElBQUksS0FBSyxNQUFNLG9CQUFvQixRQUFRLEtBQUssTUFBTSxNQUFNLENBQUMsSUFBSSxLQUFLLE1BQU0sVUFBVSxLQUFLLE1BQU0sT0FBTyxLQUFLLFFBQVEsR0FBRyxLQUFLLE1BQU0sTUFBTSxRQUFRLENBQUMsR0FBRztLQUM3TCxVQUFVO0tBQ1YsZ0JBQWdCO0lBQ2xCO0dBQ0YsQ0FBQztFQUNILENBQUMsQ0FBQyxDQUFDLEdBQUcsWUFBWSxNQUFNO0dBQ3RCLElBQUksS0FBSyxNQUFNLFVBQVU7SUFDdkIsSUFBSSxLQUFLLE1BQU0sUUFBUTtLQUNyQixLQUFLLGlCQUFpQixDQUFDLEdBQUcsS0FBSyxrQkFBa0IsQ0FBQyxDQUFDO0tBQ25ELElBQUksSUFBSSxLQUFLLFNBQVMsQ0FBQztLQUN2QixLQUFLLE1BQU0sd0JBQXdCLElBQUksS0FBSyxNQUFNLG9CQUFvQixRQUFRLEtBQUssTUFBTSxNQUFNLENBQUMsSUFBSSxLQUFLLE1BQU0sT0FBTyxLQUFLLFFBQVEsR0FBRyxLQUFLLE1BQU0sTUFBTSxRQUFRLEtBQUssZUFBZSxDQUFDLENBQUM7SUFDdkw7SUFDQSxLQUFLLFNBQVM7S0FDWixVQUFVLENBQUM7S0FDWCxXQUFXO0tBQ1gsaUJBQWlCO0tBQ2pCLFVBQVU7S0FDVixnQkFBZ0I7SUFDbEIsQ0FBQztHQUNIO0VBQ0YsQ0FBQyxDQUFDLENBQUMsR0FBRyxnQkFBZ0IsTUFBTTtHQUMxQixJQUFJLEtBQUssTUFBTSxVQUNiLEtBQUssa0JBQWtCLENBQUMsQ0FBQyxHQUFHLEtBQUssU0FBUztJQUN4QyxVQUFVLENBQUM7SUFDWCxZQUFZO0lBRVosYUFBYSxFQUFFO0lBQ2YsWUFBWTtHQUNkLENBQUM7UUFFRCxPQUFPLENBQUM7RUFDWixDQUFDLENBQUMsQ0FBQyxHQUFHLGVBQWUsTUFBTTtHQUN6QixJQUFJLEtBQUssTUFBTSxVQUFVO0lBQ3ZCLElBQUksSUFBSSxLQUFLLE1BQU07SUFDbkIsTUFBTSxJQUFJLEVBQUUsVUFBVSxTQUFTLElBQUksU0FBUyxTQUFTLEtBQUssU0FBUyxFQUFFLFlBQVksRUFBRSxDQUFDO0lBQ3BGLElBQUksSUFBSSxLQUFLLGVBQWUsS0FBSyxRQUFRLENBQUMsQ0FBQztJQUMzQyxLQUFLLE1BQU0sd0JBQXdCLElBQUksS0FBSyxNQUFNLG9CQUFvQixVQUFVLEtBQUssTUFBTSxNQUFNLEdBQUcsQ0FBQyxJQUFJLEtBQUssTUFBTSxjQUFjLEtBQUssTUFBTSxXQUFXLEtBQUssUUFBUSxHQUFHLENBQUMsR0FBRyxLQUFLLFNBQVMsRUFDeEwsWUFBWSxFQUNkLENBQUM7R0FDSDtFQUNGLENBQUMsQ0FBQyxDQUFDLEdBQUcsY0FBYyxNQUFNO0dBQ3hCLElBQUksS0FBSyxNQUFNLFVBQVU7SUFDdkIsS0FBSyxrQkFBa0IsQ0FBQyxDQUFDO0lBQ3pCLE1BQU0sRUFBRSxZQUFZLE1BQU0sS0FBSztJQUMvQixJQUFJLElBQUksS0FBSyxlQUFlLEtBQUssUUFBUSxDQUFDLENBQUM7SUFDM0MsS0FBSyxNQUFNLHdCQUF3QixJQUFJLEtBQUssTUFBTSxvQkFBb0IsVUFBVSxLQUFLLE1BQU0sTUFBTSxHQUFHLENBQUMsSUFBSSxLQUFLLE1BQU0sYUFBYSxLQUFLLE1BQU0sVUFBVSxLQUFLLFFBQVEsR0FBRyxHQUFHLEtBQUssZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDLEdBQUcsS0FBSyxTQUFTO0tBQ2xOLFVBQVUsQ0FBQztLQUNYLGFBQWE7S0FDYixZQUFZO0tBQ1osWUFBWTtJQUNkLENBQUM7R0FDSDtFQUNGLENBQUMsQ0FBQyxDQUFDLEdBQUcsUUFBUSxNQUFNO0dBQ2xCLEtBQUssWUFBWSxHQUFHLEVBQUUsZ0JBQWdCLFVBQVUsVUFBVSxPQUFPO0VBQ25FLENBQUMsR0FBRyxLQUFLLFNBQVMsRUFDaEIsaUJBQWlCLENBQUMsRUFDcEIsQ0FBQztDQUNIO0NBQ0EsY0FBYyxJQUFJLEtBQUssT0FBTztFQUM1QixJQUFJO0VBQ0osT0FBTyxDQUFDLEVBQUUsaUJBQWlCLEVBQUUsbUJBQW1CLEtBQUssSUFBSSxDQUFDLElBQUksVUFBVSxJQUFJLEVBQUUsV0FBVyxVQUFVLE9BQU8sS0FBSyxJQUFJLEVBQUUsU0FBUyxHQUFHLEVBQUUsS0FBSyxFQUFFO0NBQzVJO0NBQ0EsZUFBZSxJQUFJLEtBQUssT0FBTztFQUM3QixJQUFJO0VBQ0osT0FBTyxDQUFDLEVBQUUsa0JBQWtCLEVBQUUsbUJBQW1CLEtBQUssSUFBSSxDQUFDLElBQUksVUFBVSxJQUFJLEVBQUUsV0FBVyxVQUFVLE9BQU8sS0FBSyxJQUFJLEVBQUUsU0FBUyxHQUFHLEVBQUUsS0FBSyxFQUFFO0NBQzdJO0NBQ0EsUUFBUSxJQUFJLEtBQUssT0FBTztFQUN0QixPQUFPLENBQUMsQ0FBQyxFQUFFO0NBQ2I7Q0FDQSxtQkFBbUIsR0FBRztFQUNwQixLQUFLLG1CQUFtQixLQUFLLEtBQUs7RUFDbEMsSUFBSSxFQUFFLGlCQUFpQixNQUFNLEtBQUs7RUFDbEMsTUFBTSxJQUFJLEVBQUUsWUFBWSxLQUFLLFFBQVEsQ0FBQyxHQUFHLElBQUksRUFBRSxZQUFZLEtBQUssY0FBYyxDQUFDLEdBQUcsSUFBSSxFQUFFLFlBQVksS0FBSyxlQUFlLENBQUMsR0FBRyxJQUFJLEtBQUssTUFBTSxZQUFZLEtBQUssUUFBUSxLQUFLLEtBQUssR0FBRyxJQUFJLEtBQUssTUFBTSxZQUFZLEtBQUssY0FBYyxLQUFLLEtBQUssR0FBRyxJQUFJLEtBQUssTUFBTSxZQUFZLEtBQUssZUFBZSxLQUFLLEtBQUs7RUFDclMsSUFBSSxLQUFLLFdBQVcsS0FBSyxRQUFRLFNBQVM7R0FDeEMsSUFBSSxLQUFLLE1BQU0sWUFBWSxDQUFDLE1BQU0sS0FBSyxjQUFjLEdBQUcsSUFBSSxDQUFDLElBQUksTUFBTSxNQUFNLEtBQUssTUFBTSxJQUFJO0lBQzFGLE1BQU0sSUFBSSxLQUFLLE1BQU0sa0JBQWtCLEtBQUssV0FBVyxDQUFDLEdBQUcsSUFBSSxLQUFLLE1BQU0sa0JBQWtCLEtBQUssWUFBWSxDQUFDO0lBQzlHLEdBQUcsS0FBSyxRQUFRLE9BQU8sQ0FBQyxDQUFDLFVBQVU7S0FDakMsU0FBUyxLQUFLO0tBQ2QsT0FBTztNQUNMLEtBQUssQ0FBQztNQUNOLFFBQVEsQ0FBQztNQUNULE1BQU0sS0FBSztNQUNYLE9BQU8sS0FBSztLQUNkO0lBQ0YsQ0FBQztHQUNIO0dBQ0EsS0FBSyxNQUFNLEtBQUssR0FBRyxLQUFLLFFBQVEsT0FBTyxDQUFDLENBQUMsVUFBVSxFQUFFLFNBQVMsRUFBRSxDQUFDO0VBQ25FLE9BQ0UsSUFBSSxDQUFDO0VBQ1AsTUFBTSxLQUFLLE1BQU0sbUJBQW1CLEtBQUssU0FBUyxFQUNoRCxpQkFBaUIsRUFDbkIsQ0FBQztDQUNIO0NBQ0EsWUFBWSxHQUFHLEdBQUc7RUFDaEIsS0FBSyxNQUFNLGFBQWEsS0FBSyxNQUFNLFlBQVksS0FBSyxNQUFNLFNBQVMsS0FBSyxRQUFRLEdBQUcsQ0FBQztDQUN0RjtDQUNBLGFBQWEsR0FBRztFQUNkLE1BQU0sSUFBSSxLQUFLLE1BQU0sWUFBWSxJQUFJO0dBQ25DLFVBQVU7R0FDVixXQUFXO0dBQ1gsTUFBTSxHQUFHLEVBQUUsS0FBSztHQUNoQixLQUFLLEdBQUcsRUFBRSxJQUFJO0dBQ2QsT0FBTyxHQUFHLEVBQUUsTUFBTTtHQUNsQixRQUFRLEdBQUcsRUFBRSxPQUFPO0dBQ3BCLFlBQVksR0FBRyxFQUFFLE9BQU87RUFDMUI7RUFDQSxPQUFPLE9BQU8sT0FBTyxDQUFDLEdBQUcsSUFBSSxLQUFLLE1BQU0sV0FBVyxLQUFLLENBQUMsR0FBRyxLQUFLLE1BQU0sWUFBWSxLQUFLLFFBQVEsS0FBSyxLQUFLLElBQUksS0FBSyxDQUFDLEdBQUcsS0FBSyxNQUFNLFlBQVksS0FBSyxjQUFjLEtBQUssS0FBSyxJQUFJLEtBQUssQ0FBQyxHQUFHLEtBQUssTUFBTSxZQUFZLEtBQUssY0FBYyxLQUFLLEtBQUssS0FBSyxLQUFLLE1BQU0sV0FBVyxLQUFLLENBQUMsR0FBRyxLQUFLLE1BQU0sWUFBWSxLQUFLLGVBQWUsS0FBSyxLQUFLLElBQUksS0FBSyxDQUFDLEdBQUcsS0FBSyxNQUFNLFlBQVksS0FBSyxlQUFlLEtBQUssS0FBSyxLQUFLLEtBQUssTUFBTSxXQUFXLEtBQUssQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDO0NBQ3ZiO0NBQ0EsU0FBUztFQUNQLElBQUksT0FBTyxLQUFLLE1BQU0sUUFBUSxPQUFPLEtBQUssTUFBTSxVQUFVLE1BQ3hELE9BQU87RUFDVCxNQUFNLElBQUksS0FBSyxTQUFTLElBQUk7R0FDMUIsWUFBWSxLQUFLLE1BQU07R0FDdkIsaUJBQWlCLENBQUMsQ0FBQyxLQUFLLE1BQU07R0FDOUIsT0FBTyxLQUFLO0dBQ1osU0FBUyxLQUFLLFFBQVEsS0FBSyxLQUFLO0dBQ2hDLGVBQWUsS0FBSyxjQUFjLEtBQUssS0FBSztHQUM1QyxnQkFBZ0IsS0FBSyxlQUFlLEtBQUssS0FBSztHQUM5QyxVQUFVLEtBQUssTUFBTTtHQUNyQixVQUFVLEtBQUssTUFBTTtHQUNyQixXQUFXLEtBQUssTUFBTTtHQUN0QixVQUFVLEtBQUssTUFBTTtHQUNyQixnQkFBZ0IsS0FBSyxNQUFNO0dBQzNCLFVBQVUsS0FBSyxNQUFNO0dBQ3JCLFlBQVksS0FBSyxNQUFNO0dBQ3ZCLGFBQWEsS0FBSyxNQUFNO0dBQ3hCLFlBQVksS0FBSyxNQUFNO0VBQ3pCO0VBQ0EsT0FBTyxLQUFLLE1BQU0sZUFBZSxLQUFLLE1BQU0sYUFBYTtHQUN2RCxNQUFNLEtBQUssTUFBTTtHQUNqQixpQkFBaUI7R0FDakIsYUFBYTtHQUNiLGNBQWMsS0FBSztHQUNuQixnQkFBZ0IsS0FBSztFQUN2QixDQUFDLElBQUksR0FBRztHQUNOLE1BQU0sS0FBSyxNQUFNO0dBQ2pCLGFBQWE7R0FDYixjQUFjLEtBQUs7R0FDbkIsZ0JBQWdCLEtBQUs7RUFDdkIsQ0FBQztDQUNIO0FBQ0Y7QUFDQSxPQUFPLGVBQWUsSUFBSSxnQkFBZ0I7Q0FDeEMsWUFBWSxDQUFDO0NBQ2IsY0FBYyxDQUFDO0NBQ2YsVUFBVSxDQUFDO0NBQ1gsT0FBTztFQUNMLFVBQVUsQ0FBQztFQUNYLGNBQWM7Q0FDaEI7QUFDRixDQUFDO0FBQ0QsT0FBTyxlQUFlLElBQUksZUFBZTtDQUN2QyxZQUFZLENBQUM7Q0FDYixjQUFjLENBQUM7Q0FDZixVQUFVLENBQUM7Q0FDWCxPQUFPO0FBQ1QsQ0FBQztBQUNELFNBQVMsR0FBRyxHQUFHLEdBQUc7Q0FDaEIsTUFBTSxJQUFJLEVBQUUsR0FBRyxXQUFXLE1BQU0sS0FBSyxJQUFJLEVBQUUsR0FBRyxXQUFXLElBQUk7Q0FDN0QsT0FBTyxNQUFNLFVBQVUsTUFBTTtBQUMvQjtBQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUc7Q0FDaEIsTUFBTSxJQUFJLEVBQUUsR0FBRyxXQUFXLE1BQU0sS0FBSyxJQUFJLEVBQUUsR0FBRyxXQUFXLElBQUk7Q0FDN0QsT0FBTyxNQUFNLFdBQVcsTUFBTSxVQUFVLE1BQU0sQ0FBQztBQUNqRDtBQUNBLElBQU0sS0FBTixjQUFpQkUsYUFBQUEsVUFBRztDQUNsQixzQkFBc0IsR0FBRztFQUN2QixPQUFPLEVBQUUsR0FBRyxFQUFFLFFBQVEsS0FBSyxNQUFNLE1BQU0sS0FBSyxHQUFHLEVBQUUsT0FBTyxLQUFLLE1BQU0sS0FBSyxLQUFLLEdBQUcsRUFBRSxnQkFBZ0IsS0FBSyxNQUFNLGNBQWMsS0FBSyxFQUFFLFNBQVMsS0FBSyxNQUFNLFFBQVEsRUFBRSxvQkFBb0IsS0FBSyxNQUFNLG1CQUFtQixFQUFFLGtCQUFrQixLQUFLLE1BQU0saUJBQWlCLEVBQUUsZ0JBQWdCLEtBQUssTUFBTSxlQUFlLEVBQUUsaUJBQWlCLEtBQUssTUFBTSxnQkFBZ0IsRUFBRSxhQUFhLEtBQUssTUFBTSxZQUFZLEVBQUUsYUFBYSxLQUFLLE1BQU0sWUFBWSxFQUFFLG1CQUFtQixLQUFLLE1BQU0sa0JBQWtCLEVBQUUsbUJBQW1CLEtBQUssTUFBTSxrQkFBa0IsRUFBRSxZQUFZLEtBQUssTUFBTSxXQUFXLEVBQUUsY0FBYyxLQUFLLE1BQU0sYUFBYSxFQUFFLGNBQWMsS0FBSyxNQUFNO0NBQ3JuQjtDQUNBLFdBQVcsR0FBRyxHQUFHO0VBQ2YsSUFBSSxLQUFLLE1BQU0sVUFBVTtHQUN2QixNQUFNLElBQUksRUFBRSxHQUFHLENBQUM7R0FDaEIsT0FBTyxLQUFLLE1BQU0sU0FBUyxTQUFTLENBQUM7RUFDdkMsT0FDRSxPQUFPLEtBQUssTUFBTSxpQkFBaUIsRUFBRSxHQUFHLENBQUM7Q0FDN0M7Q0FDQSxnQkFBZ0IsR0FBRyxHQUFHO0VBQ3BCLE1BQU0sRUFBRSxNQUFNLEdBQUcsT0FBTyxNQUFNLEtBQUs7RUFDbkMsT0FBTyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUM7Q0FDdEI7Q0FDQSxTQUFTO0VBQ1AsTUFBTSxFQUFFLGlCQUFpQixHQUFHLGVBQWUsR0FBRyxnQkFBZ0IsR0FBRyxNQUFNLEdBQUcsUUFBUSxNQUFNLEtBQUssT0FBTyxFQUFFLFdBQVcsR0FBRyxjQUFjLE1BQU0sR0FBRyxJQUFJLEdBQUcsR0FBRyxDQUFDLEdBQUcsSUFBSSxLQUFLLGdCQUFnQixHQUFHLENBQUMsR0FBRyxJQUFJLEdBQUcsR0FBRyxJQUFJO0VBQ3ZNLFFBQUEsR0FBT0gsbUJBQUFBLElBQUFBLENBQUUsT0FBTztHQUFFLFdBQVc7R0FBYSxVQUFVLEVBQUUsUUFBUSxNQUFNLEVBQUUsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxPQUFBLEdBQU1BLG1CQUFBQSxJQUFBQSxDQUFFLElBQUk7SUFBRSxXQUFXLEVBQUU7SUFBVyxNQUFNO0lBQUcsTUFBTSxLQUFLLE1BQU07SUFBTSxPQUFPLEVBQUUsRUFBRSxHQUFHLENBQUM7SUFBSSxZQUFZLEVBQUUsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDO0lBQVksVUFBVSxLQUFLLFdBQVcsR0FBRyxDQUFDO0lBQUcsZ0JBQWdCLEVBQUUsR0FBRyxnQkFBZ0IsTUFBTSxLQUFLLElBQUksRUFBRSxHQUFHLGdCQUFnQixJQUFJLEtBQUssTUFBTTtJQUFnQixTQUFTLEVBQUUsR0FBRyxTQUFTLE1BQU0sS0FBSyxJQUFJLEVBQUUsR0FBRyxTQUFTLElBQUksS0FBSyxNQUFNO0lBQVMsZUFBZSxHQUFHLEdBQUcsS0FBSyxNQUFNLFNBQVM7SUFBRyxnQkFBZ0IsR0FBRyxHQUFHLEtBQUssTUFBTSxTQUFTO0lBQUcsV0FBVyxFQUFFLEdBQUcsV0FBVyxNQUFNLEtBQUssSUFBSSxFQUFFLEdBQUcsV0FBVyxJQUFJLEtBQUssTUFBTTtJQUFXLGlCQUFpQixLQUFLLE1BQU07SUFBaUIsV0FBVyxLQUFLLE1BQU07SUFBVyxpQkFBaUIsS0FBSyxNQUFNO0lBQWlCLGVBQWUsS0FBSyxNQUFNO0lBQWUsYUFBYSxLQUFLLE1BQU07SUFBYSxVQUFVLEtBQUssTUFBTTtJQUFVLGdCQUFnQixLQUFLLE1BQU07SUFBZ0IsWUFBWSxLQUFLLE1BQU07SUFBYyxXQUFXLEtBQUssTUFBTTtJQUFhLHFCQUFxQixLQUFLLE1BQU07SUFBcUIsUUFBUSxLQUFLLE1BQU07SUFBVSxRQUFRLEtBQUssTUFBTTtJQUFVLG1CQUFtQixLQUFLLE1BQU07SUFBbUIsZUFBZSxLQUFLLE1BQU07SUFBbUIsVUFBVSxLQUFLLE1BQU07SUFBWSxjQUFjLEtBQUssTUFBTTtJQUFjLFdBQVcsS0FBSyxNQUFNO0dBQVUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7RUFBRSxDQUFDO0NBQ252QztBQUNGO0FBQ0EsSUFBTSxLQUFOLGNBQWlCRyxhQUFBQSxVQUFHO0NBQ2xCLHNCQUFzQixHQUFHO0VBQ3ZCLE9BQU8sRUFBRSxFQUFFLFNBQVMsS0FBSyxNQUFNLFFBQVEsRUFBRSxVQUFVLEtBQUssTUFBTSxTQUFTLEVBQUUsV0FBVyxLQUFLLE1BQU0sVUFBVSxHQUFHLEVBQUUsUUFBUSxLQUFLLE1BQU0sTUFBTSxLQUFLLEdBQUcsRUFBRSxjQUFjLEtBQUssTUFBTSxZQUFZO0NBQ3hMO0NBQ0EsbUJBQW1CLEdBQUcsSUFBSSxDQUFDLEdBQUcsR0FBRyxHQUFHO0VBQ2xDLE9BQU8sS0FBSyxNQUFNLGdCQUFBLGFBQWtCLGNBQWMsS0FBSyxNQUFNLGVBQWU7R0FDMUUsT0FBTztHQUNQLGdCQUFnQjtFQUNsQixDQUFDLElBQUksRUFBRSxHQUFHLElBQUksSUFBSSxDQUFDO0NBQ3JCO0NBQ0EsU0FBUztFQUNQLE1BQU0sRUFBRSxPQUFPLEdBQUcsY0FBYyxHQUFHLFFBQVEsR0FBRyxnQkFBZ0IsTUFBTSxLQUFLLE9BQU8sRUFBRSxZQUFZLEdBQUcsZUFBZSxHQUFHLG9CQUFvQixNQUFNLEtBQUssTUFBTSxNQUFNLElBQUk7R0FDaEssT0FBTyxHQUFHLEVBQUU7R0FDWixRQUFRLEdBQUcsRUFBRTtFQUNmLEdBQUcsSUFBSSxFQUNMLE9BQU8sR0FBRyxFQUFFLElBQ2QsR0FBRyxJQUFJLEtBQUssTUFBTSxPQUFPLEtBQUssR0FBRyxNQUFNO0dBQ3JDLE1BQU0sSUFBSTtJQUNSLFFBQVEsR0FBRyxFQUFFLEdBQUc7SUFDaEIsWUFBWSxHQUFHLEVBQUUsR0FBRztHQUN0QjtHQUNBLFFBQUEsR0FBT0gsbUJBQUFBLElBQUFBLENBQUUsT0FBTztJQUFFLFdBQVcsc0NBQXNDLElBQUksTUFBTSxJQUFJLFNBQVM7SUFBUSxPQUFPO0lBQUcsVUFBVSxLQUFLLG1CQUFtQixHQUFHLEdBQUcsR0FBRyxDQUFDO0dBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0VBQ3RLLENBQUM7RUFDRCxRQUFBLEdBQU9BLG1CQUFBQSxJQUFBQSxDQUFFLE9BQU87R0FBRSxXQUFXLGlCQUFpQixJQUFJLHVCQUF1QjtHQUFLLE9BQU87R0FBRyxXQUFBLEdBQVVBLG1CQUFBQSxJQUFBQSxDQUFFLE9BQU87SUFBRSxPQUFPO0lBQUcsVUFBVTtHQUFFLENBQUM7RUFBRSxDQUFDO0NBQ3pJO0FBQ0Y7QUFDQSxJQUFNLEtBQU4sY0FBaUJHLGFBQUFBLFVBQUc7Q0FDbEIsc0JBQXNCLEdBQUc7RUFDdkIsT0FBTyxFQUFFLEVBQUUsb0JBQW9CLEtBQUssTUFBTSxtQkFBbUIsRUFBRSxrQkFBa0IsS0FBSyxNQUFNLGlCQUFpQixFQUFFLGdCQUFnQixLQUFLLE1BQU0sZUFBZSxFQUFFLGNBQWMsS0FBSyxNQUFNLGFBQWEsRUFBRSxZQUFZLEtBQUssTUFBTSxXQUFXLEVBQUUsY0FBYyxLQUFLLE1BQU0sYUFBYSxFQUFFLFdBQVcsS0FBSyxNQUFNLFVBQVUsRUFBRSxrQ0FBa0MsS0FBSyxNQUFNO0NBQ2hXO0NBQ0EsU0FBUztFQUNQLE1BQU0sRUFDSixpQkFBaUIsR0FDakIsZUFBZSxHQUVmLFNBQVMsR0FDVCxXQUFXLEdBQ1gsUUFBUSxHQUNSLCtCQUErQixHQUMvQix1QkFBdUIsTUFDckIsS0FBSyxPQUFPLElBQUksQ0FBQztFQUNyQixPQUFPLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxHQUFHLE1BQU07R0FDOUIsTUFBTSxJQUFJLEVBQUUsSUFBSSxNQUFNLFFBQVEsU0FBUyxDQUFDLE9BQU8sTUFBTSxRQUFRLElBQUk7R0FDakUsSUFBSSxJQUFJLENBQUM7R0FDVCxNQUFNLElBQUksRUFDUixFQUFFLEtBQUssSUFBSSxLQUVYLEVBQUUsS0FBSyxJQUFJLE1BQU0sQ0FDbkI7R0FDQSxNQUFNLElBQUksWUFBWSxJQUFJLGtCQUFrQixPQUFPLE1BQU0sU0FBUyxNQUFNLFVBQVUsTUFBTSxXQUFXLFlBQVksRUFBRSxJQUFJLEVBQUUsS0FBSyxPQUFPLEVBQUUsS0FBSyxHQUFHLEdBQUcsSUFBSSxFQUFFLEVBQUUsUUFBUSxDQUFDLEdBQUcsSUFBSSxFQUFFLEVBQUUsUUFBUSxDQUFDO0dBQ3JMLEVBQUUsTUFBQSxHQUFLSCxtQkFBQUEsSUFBQUEsQ0FBRSxPQUFPO0lBQUUsV0FBVztJQUFHLE9BQU87S0FDckMsZUFBZTtLQUNmLEtBQUs7S0FDTCxNQUFNLEdBQUcsRUFBRTtLQUNYLE9BQU8sR0FBRyxJQUFJLEVBQUU7S0FDaEIsUUFBUSxHQUFHLEVBQUU7SUFDZjtHQUFFLEdBQUcsUUFBUSxFQUFFLFFBQVEsR0FBRyxDQUFDO0VBQzdCLENBQUMsSUFBQSxHQUFHQSxtQkFBQUEsSUFBQUEsQ0FBRSxPQUFPO0dBQUUsV0FBVztHQUFzQixVQUFVO0VBQUUsQ0FBQztDQUMvRDtBQUNGO0FBQ0EsSUFBTSxNQUFNLEVBQUUsR0FBRyxTQUFBLEdBQVFBLG1CQUFBQSxJQUFBQSxDQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsdUJBQXVCLFNBQUEsR0FBUUEsbUJBQUFBLElBQUFBLENBQUUsSUFBSTtDQUFFLHVCQUF1QjtDQUFHLEdBQUc7QUFBRSxDQUFDLEVBQUUsQ0FBQztBQUN4SCxJQUFNLEtBQU4sY0FBaUJHLGFBQUFBLFVBQUc7Q0FDbEIsY0FBYztFQUNaLE1BQU0sR0FBRyxTQUFTLEdBQUcsT0FBTyxlQUFlLE1BQU0sbUJBQW1CO0dBQ2xFLFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsTUFBTTtJQUNaLEtBQUssZUFBZSxFQUFFO0dBQ3hCO0VBQ0YsQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLGlCQUFpQjtHQUMvQyxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxRQUFRLE1BQU07SUFDWixLQUFLLE1BQU0sbUJBQW1CLEtBQUssS0FBSyxLQUFLLElBQUksS0FBSyxlQUFlLEVBQUUsT0FBTyxJQUFJLEtBQUssTUFBTSxtQkFBbUIsS0FBSyxjQUFjLENBQUM7R0FDdEk7RUFDRixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sZUFBZTtHQUM3QyxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxRQUFRLE1BQU07SUFDWixLQUFLLGVBQWUsS0FBSyxNQUFNLFFBQVEsQ0FBQyxHQUFHLEtBQUssY0FBYyxDQUFDLEdBQUcsS0FBSyxlQUFlO0dBQ3hGO0VBQ0YsQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLGdCQUFnQjtHQUM5QyxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxPQUFPLEtBQUs7RUFDZCxDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sZUFBZTtHQUM3QyxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxPQUFPLENBQUM7RUFDVixDQUFDO0NBQ0g7Q0FDQSxTQUFTO0VBQ1AsTUFBTSxJQUFBLGFBQU0sU0FBUyxLQUFLLEtBQUssTUFBTSxRQUFRO0VBQzdDLE9BQUEsYUFBUyxhQUFhLEdBQUc7R0FDdkIsYUFBYSxLQUFLO0dBQ2xCLFdBQVcsS0FBSztHQUNoQixTQUFTLEtBQUs7RUFDaEIsQ0FBQztDQUNIO0FBQ0Y7QUFDQSxJQUFNLEtBQU4sY0FBaUJBLGFBQUFBLFVBQUc7Q0FDbEIsU0FBUztFQUNQLE1BQU0sRUFBRSxlQUFlLEdBQUcsZUFBZSxHQUFHLFdBQVcsR0FBRyxPQUFPLEdBQUcsU0FBUyxHQUFHLGdCQUFnQixHQUFHLGtDQUFrQyxHQUFHLE9BQU8sTUFBTSxLQUFLO0VBQzFKLElBQUksSUFBSSxDQUFDO0VBQ1QsT0FBTyxNQUFNLElBQUksRUFBRSxDQUFDLEtBQUEsR0FBSUgsbUJBQUFBLElBQUFBLENBQUUsSUFBSTtHQUFFLGdCQUFnQjtHQUFHLFNBQVM7R0FBRyxXQUFBLEdBQVVBLG1CQUFBQSxJQUFBQSxDQUFFLE9BQU87SUFBRSxlQUFlO0lBQUcsZUFBZTtJQUFHLFlBQVksSUFBSSxpQkFBaUIsa0JBQWtCLElBQUksRUFBRSxLQUFLLEdBQUcsSUFBSTtJQUFLLE9BQU87R0FBRSxDQUFDO0VBQUUsQ0FBQztDQUNqTjtBQUNGO0FBQ0EsSUFBTSxLQUFOLGNBQWlCRyxhQUFBQSxVQUFHO0NBQ2xCLHNCQUFzQixHQUFHO0VBQ3ZCLE9BQU8sRUFBRSxFQUFFLGdCQUFnQixLQUFLLE1BQU0sZUFBZSxFQUFFLGNBQWMsS0FBSyxNQUFNLGFBQWEsRUFBRSxpQkFBaUIsS0FBSyxNQUFNLGdCQUFnQixFQUFFLFdBQVcsS0FBSyxNQUFNO0NBQ3JLO0NBQ0EsU0FBUztFQUNQLE1BQU0sRUFBRSxhQUFhLEdBQUcsV0FBVyxHQUFHLGNBQWMsR0FBRyxZQUFZLEdBQUcsa0JBQWtCLEdBQUcsZ0JBQWdCLEdBQUcsUUFBUSxHQUFHLGtDQUFrQyxHQUFHLG1CQUFtQixNQUFNLEtBQUssT0FBTyxJQUFJLENBQUM7RUFDeE0sS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsS0FDckIsRUFBRSxNQUFBLEdBQUtILG1CQUFBQSxJQUFBQSxDQUFFLElBQUk7R0FBRSxnQkFBZ0I7R0FBRyxnQkFBZ0IsTUFBTSxFQUFFLEdBQUcsQ0FBQztHQUFHLFVBQVUsTUFBTSxFQUFFLEdBQUcsQ0FBQztHQUFHLGdCQUFnQixNQUFNLEVBQUUsR0FBRyxDQUFDO0dBQUcsV0FBVyxJQUFJLE1BQU07R0FBRyxPQUFPLEVBQUU7R0FBSSxrQ0FBa0M7R0FBRyxPQUFPO0lBQ3hNLE9BQU8sR0FBRyxFQUFFO0lBQ1osUUFBUSxHQUFHLEVBQUUsR0FBRztHQUNsQjtFQUFFLEdBQUcsbUJBQW1CLEdBQUcsQ0FBQztFQUM5QixRQUFBLEdBQU9BLG1CQUFBQSxJQUFBQSxDQUFFLE9BQU87R0FBRSxXQUFXO0dBQXdCLFVBQVU7RUFBRSxDQUFDO0NBQ3BFO0FBQ0Y7QUFDQSxJQUFNLEtBQU4sY0FBaUJHLGFBQUFBLFVBQUc7Q0FDbEIsWUFBWSxHQUFHO0VBQ2IsTUFBTSxDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sc0JBQXNCO0dBQzFELFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQUEsR0FBT0MsYUFBQUEsVUFBQUEsQ0FBRztFQUNaLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxvQkFBb0I7R0FDbEQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsT0FBTztFQUNULENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxxQkFBcUI7R0FDbkQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsT0FBTztFQUNULENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxvQkFBb0I7R0FDbEQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsT0FBTztFQUNULENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxtQkFBbUI7R0FDakQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsT0FBTztFQUNULENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxxQkFBcUI7R0FDbkQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsT0FBTyxDQUFDO0VBQ1YsQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLHNCQUFzQjtHQUNwRCxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxRQUFRLE1BQU07SUFDWixFQUFFLGdCQUFnQixVQUFVLEtBQUssaUJBQWlCLENBQUMsSUFBSSxFQUFFLGdCQUFnQixXQUFXLEtBQUssZ0JBQWdCLENBQUM7R0FDNUc7RUFDRixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0scUJBQXFCO0dBQ25ELFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsTUFBTTtJQUNaLEVBQUUsZ0JBQWdCLFVBQVUsS0FBSyxnQkFBZ0IsQ0FBQyxJQUFJLEVBQUUsZ0JBQWdCLFdBQVcsS0FBSyxnQkFBZ0IsQ0FBQztHQUMzRztFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxvQkFBb0I7R0FDbEQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsUUFBUSxNQUFNO0lBQ1osRUFBRSxnQkFBZ0IsVUFBVSxLQUFLLGVBQWUsSUFBSSxFQUFFLGdCQUFnQixXQUFXLEtBQUssY0FBYztHQUN0RztFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxnQkFBZ0I7R0FDOUMsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsYUFBYTtJQUNYLE1BQU0sSUFBSSxLQUFLLG1CQUFtQixRQUFRO0lBQzFDLEtBQUssTUFBTSxTQUFTLENBQUM7R0FDdkI7RUFDRixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sZUFBZTtHQUM3QyxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxRQUFRLE1BQU07SUFDWixJQUFJLEVBQUUsV0FBVyxFQUFFLFdBQVcsRUFBRSxRQUFRO0tBQ3RDLEVBQUUsZUFBZTtLQUNqQixNQUFNLElBQUksR0FBRyxFQUFFLGFBQWEsR0FBRyxJQUFJLEVBQUUsVUFBVSxFQUFFLEdBQUcsSUFBSSxFQUFFLFVBQVUsS0FBSyxFQUFFLFVBQVUsSUFBSTtLQUN6RixLQUFLLE1BQU0sWUFBWSxHQUFHLEdBQUcsRUFBRSxNQUFNO0lBQ3ZDLE9BQU8sRUFBRSxhQUFhLEVBQUUsZUFBZSxHQUFHLEtBQUssTUFBTSxTQUFTLEtBQUssbUJBQW1CLFFBQVEsY0FBYyxFQUFFLFVBQVUsRUFBRSxPQUFPO0dBQ25JO0VBQ0YsQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLG1CQUFtQjtHQUNqRCxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxRQUFRLE1BQU07SUFDWixFQUFFLFdBQVcsTUFBTSxLQUFLLG1CQUFtQixFQUFFLE9BQU8sS0FBSyxTQUFTLEVBQ2hFLFlBQVksQ0FBQyxFQUNmLENBQUM7R0FDSDtFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxtQkFBbUI7R0FDakQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsUUFBUSxNQUFNO0lBQ1osS0FBSyxNQUFNLGNBQWMsQ0FBQyxLQUFLLHNCQUFzQixLQUFLLE1BQU0sU0FBUyxLQUFLLG1CQUFtQixRQUFRLGFBQWEsS0FBSyxtQkFBbUIsRUFBRSxLQUFLLEdBQUcsS0FBSyxtQkFBbUIsRUFBRTtHQUNwTDtFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxpQkFBaUI7R0FDL0MsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsYUFBYTtJQUNYLEtBQUssbUJBQW1CLE1BQU0sS0FBSyxTQUFTLEVBQzFDLFlBQVksQ0FBQyxFQUNmLENBQUM7R0FDSDtFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxzQkFBc0I7R0FDcEQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsUUFBUSxNQUFNO0lBQ1osRUFBRSxnQkFBZ0IsWUFBWSxLQUFLLG1CQUFtQixNQUFNLEtBQUssU0FBUyxFQUN4RSxZQUFZLENBQUMsRUFDZixDQUFDO0dBQ0g7RUFDRixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sb0JBQW9CO0dBQ2xELFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsTUFBTTtJQUNaLEVBQUUsYUFBYSxFQUFFLGVBQWUsR0FBRyxLQUFLLG9CQUFvQixNQUFNLEtBQUssbUJBQW1CO0tBQUUsR0FBRyxFQUFFO0tBQVMsR0FBRyxFQUFFO0tBQVMsU0FBUyxPQUFPO0lBQVEsR0FBRyxLQUFLLGtCQUFrQjtLQUFFLEdBQUcsRUFBRTtLQUFTLEdBQUcsRUFBRTtLQUFTLFNBQVMsT0FBTztJQUFRLE1BQU0sRUFBRSxlQUFlLEdBQUcsS0FBSyxvQkFBb0IsS0FBSyxJQUFJLEVBQUUsVUFBVSxLQUFLLGlCQUFpQixDQUFDLEdBQUcsS0FBSyxtQkFBbUIsTUFBTSxLQUFLLGtCQUFrQjtHQUN6WDtFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxtQkFBbUI7R0FDakQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsUUFBUSxNQUFNO0lBQ1osTUFBTSxFQUFFLE9BQU8sR0FBRyxRQUFRLE1BQU0sS0FBSztJQUNyQyxJQUFJLEtBQUssbUJBQW1CO0tBQzFCLEVBQUUsZUFBZTtLQUNqQjtJQUNGO0lBQ0EsSUFBSSxLQUFLLHFCQUFxQixDQUFDLEVBQUUsV0FBVztLQUMxQyxFQUFFLGVBQWU7S0FDakIsTUFBTSxJQUFJLEtBQUssSUFBSSxFQUFFLFVBQVUsS0FBSyxpQkFBaUIsQ0FBQyxHQUFHLElBQUksR0FBRyxFQUFFLGFBQWEsR0FBRyxLQUFLLEVBQUUsVUFBVSxLQUFLLGlCQUFpQixLQUFLLElBQUksRUFBRTtLQUNwSSxNQUFNLEtBQUssS0FBSyxzQkFBc0IsTUFBTSxFQUFFLEtBQUssb0JBQW9CLEdBQUcsSUFBSSxDQUFDLEdBQUcsS0FBSyxvQkFBb0I7SUFDN0csT0FBTyxJQUFJLEtBQUssbUJBQW1CLEVBQUUsV0FBVztLQUM5QyxFQUFFLGVBQWU7S0FDakIsTUFBTSxJQUFJLEVBQUUsU0FBUyxJQUFJLEVBQUUsU0FBUyxJQUFJLElBQUksS0FBSyxnQkFBZ0IsR0FBRyxJQUFJLElBQUksS0FBSyxpQkFBaUIsR0FBRyxJQUFJLElBQUksS0FBSyxpQkFBaUI7S0FDbkksS0FBSyxrQkFBa0I7TUFBRSxHQUFHO01BQUcsR0FBRztNQUFHLFNBQVMsT0FBTztLQUFZO0tBQ2pFLE1BQU0sSUFBSSxLQUFLLElBQUksQ0FBQyxJQUFJLElBQUksS0FBSyxJQUFJLENBQUMsR0FBRyxJQUFJLEtBQUssSUFBSSxDQUFDLElBQUksSUFBSSxLQUFLLElBQUksQ0FBQztLQUN6RSxNQUFNLEtBQUssS0FBSyxLQUFLLE1BQU0sU0FBUyxLQUFLLG1CQUFtQixRQUFRLGFBQWEsQ0FBQyxHQUFHLEtBQUssT0FBTyxTQUFTLE9BQU8sU0FBUyxLQUFLLGlCQUFpQixVQUFVLENBQUM7SUFDN0o7R0FDRjtFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxrQkFBa0I7R0FDaEQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsYUFBYTtJQUNYLEtBQUssc0JBQXNCLEtBQUssb0JBQW9CLE9BQU8sS0FBSyxvQkFBb0IsS0FBSyxrQkFBa0IsTUFBTSxLQUFLLG1CQUFtQjtHQUMzSTtFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxzQkFBc0I7R0FDcEQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsUUFBUSxNQUFNO0lBQ1osS0FBSyxvQkFBb0IsRUFBRSxPQUFPO0dBQ3BDO0VBQ0YsQ0FBQyxHQUFHLEtBQUssUUFBUSxFQUNmLFlBQVksQ0FBQyxFQUNmO0NBQ0Y7Q0FDQSxvQkFBb0I7RUFDbEIsS0FBSyxtQkFBbUIsWUFBWSxLQUFLLE1BQU0sVUFBVSxLQUFLLG1CQUFtQixPQUFPLEdBQUcsS0FBSyxtQkFBbUIsUUFBUSxpQkFBaUIsU0FBUyxLQUFLLGFBQWEsRUFBRSxTQUFTLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxtQkFBbUIsUUFBUSxpQkFBaUIsbUJBQW1CLEtBQUssa0JBQWtCLEdBQUcsS0FBSyxtQkFBbUIsUUFBUSxpQkFBaUIsZUFBZSxLQUFLLG9CQUFvQixFQUFFLFNBQVMsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLG1CQUFtQixRQUFRLGlCQUFpQixlQUFlLEtBQUssbUJBQW1CLEVBQUUsU0FBUyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssbUJBQW1CLFFBQVEsaUJBQWlCLGFBQWEsS0FBSyxnQkFBZ0IsR0FBRyxLQUFLLG1CQUFtQixRQUFRLGlCQUFpQixnQkFBZ0IsS0FBSyxrQkFBa0I7Q0FDNXBCO0NBQ0EsdUJBQXVCO0VBQ3JCLEtBQUssbUJBQW1CLFlBQVksS0FBSyxtQkFBbUIsUUFBUSxvQkFBb0IsU0FBUyxLQUFLLFdBQVcsR0FBRyxLQUFLLG1CQUFtQixRQUFRLG9CQUFvQixtQkFBbUIsS0FBSyxrQkFBa0IsR0FBRyxLQUFLLG1CQUFtQixRQUFRLG9CQUFvQixlQUFlLEtBQUssa0JBQWtCLEdBQUcsS0FBSyxtQkFBbUIsUUFBUSxvQkFBb0IsZUFBZSxLQUFLLGlCQUFpQixHQUFHLEtBQUssbUJBQW1CLFFBQVEsb0JBQW9CLGFBQWEsS0FBSyxnQkFBZ0IsR0FBRyxLQUFLLG1CQUFtQixRQUFRLG9CQUFvQixnQkFBZ0IsS0FBSyxrQkFBa0I7Q0FDcGtCO0NBQ0EsU0FBUztFQUNQLE1BQU0sRUFBRSxPQUFPLEdBQUcsUUFBUSxHQUFHLFVBQVUsTUFBTSxLQUFLLE9BQU8sRUFBRSxZQUFZLE1BQU0sS0FBSyxPQUFPLElBQUk7R0FDM0YsT0FBTyxHQUFHLEVBQUU7R0FDWixRQUFRLEdBQUcsSUFBSSxHQUFHO0dBRWxCLFFBQVEsSUFBSSxTQUFTO0dBQ3JCLFVBQVU7RUFDWjtFQUNBLFFBQUEsR0FBT0osbUJBQUFBLElBQUFBLENBQUUsT0FBTztHQUFFLEtBQUssS0FBSztHQUFvQixlQUFlO0dBQWtCLFdBQVc7R0FBYyxPQUFPO0dBQUcsVUFBVSxLQUFLO0dBQWMsVUFBVTtFQUFFLENBQUM7Q0FDaEs7QUFDRjtBQUNBLElBR0csRUFBRSxVQUFVLElBQUksVUFBVSxPQUFBLGFBQVMsY0FBYyxFQUZsRCw2QkFBNkIsUUFBUSxLQUFLLHFEQUFtRCxTQUFTLENBQ3RHLEdBQ21ELENBQUMsR0FBRyxLQUFLLElBQUksS0FBSyxJQU9wRSxFQUFFLFVBQVUsSUFBSSxVQUFVLE9BQUEsYUFBUyxjQUFjO0NBTmxELFNBQVMsQ0FBQztDQUNWLHdCQUF3QixRQUFRLEtBQUssK0JBQStCLEdBQUc7RUFDckUsYUFBYTtFQUNiLFdBQVc7Q0FDYjtDQUNBLHFCQUFxQixRQUFRLEtBQUssK0JBQStCLEdBQUc7QUFDakIsQ0FBQztBQUN0RCxJQUFJLEtBQUs7QUFDVCxJQUFNLFlBQVksTUFBTSxHQUFHLEtBQUs7QUFDaEMsSUFBTSxLQUFOLGNBQUEsYUFBbUIsVUFBVTtDQUMzQixZQUFZLEdBQUc7RUFDYixNQUFNLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSwyQkFBMkI7R0FDL0QsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsUUFBUSxPQUFPLElBQUk7SUFDakIsR0FBRztJQUVILElBQUksR0FBRztHQUNULEdBQUcsS0FBSyxVQUFVLE9BQU8sRUFDdkIsU0FBUyxDQUFDLEdBQUcsRUFBRSxTQUFTLENBQUMsRUFDM0IsRUFBRSxHQUFHO0lBQ0gsbUJBQW1CO0tBQ2pCLEtBQUssVUFBVSxPQUFPLEVBQ3BCLFNBQVMsRUFBRSxRQUFRLFFBQVEsTUFBTSxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQ2hELEVBQUU7SUFDSjtJQUNBLGlCQUFpQjtHQUNuQjtFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxzQkFBc0I7R0FDcEQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsUUFBUSxNQUFNO0lBQ1osTUFBTSxJQUFJLEtBQUssTUFBTSxRQUFRLFdBQVcsTUFBTSxFQUFFLE9BQU8sRUFBRSxFQUFFO0lBQzNELElBQUksS0FBSyxLQUFLLFVBQVUsT0FBTyxFQUM3QixTQUFTO0tBQ1AsR0FBRyxFQUFFLFFBQVEsTUFBTSxHQUFHLENBQUM7S0FDdkI7S0FDQSxHQUFHLEVBQUUsUUFBUSxNQUFNLElBQUksQ0FBQztJQUMxQixFQUNGLEVBQUU7R0FDSjtFQUNGLENBQUMsR0FBRyxLQUFLLFFBQVE7R0FDZixTQUFTLENBQUM7R0FDVixpQkFBaUIsS0FBSztHQUN0QixjQUFjLEtBQUs7RUFDckI7Q0FDRjtDQUNBLFNBQVM7RUFDUCxRQUFBLEdBQU9BLG1CQUFBQSxJQUFBQSxDQUFFLElBQUk7R0FBRSxPQUFPLEtBQUs7R0FBTyxVQUFVLEtBQUssTUFBTTtFQUFTLENBQUM7Q0FDbkU7QUFDRjtBQUNBLElBQU0sS0FBSztBQUNYLElBQUk7Q0FDSCxTQUFTLEdBQUc7Q0FDWCxFQUFFLFFBQVEsU0FBUyxFQUFFLFNBQVMsVUFBVSxFQUFFLFNBQVM7QUFDckQsRUFBQSxDQUFHLE9BQU8sS0FBSyxDQUFDLEVBQUU7QUFDbEIsSUFBTSxLQUFLO0NBQ1QsVUFBVTtDQUNWLEtBQUs7Q0FDTCxRQUFRO0NBQ1IsT0FBTztDQUNQLGlCQUFpQjtDQUlqQixlQUFlO0FBQ2pCO0FBQUcsSUFBQSxNQUFNLE9BQU87Q0FDZCxHQUFHO0NBQ0gsTUFBTTtBQUNSO0FBQUksSUFBQSxNQUFNLE1BQU0sU0FBUyxFQUFFLFFBQVEsS0FBSztDQUN0QyxRQUFBLEdBQU9BLG1CQUFBQSxJQUFBQSxDQUFFLE9BQU87RUFBRSxPQUFPO0VBQUcsZUFBZTtDQUFFLENBQUM7QUFDaEQ7QUFBRyxJQUFBLEtBQUssR0FBRyxvQkFBb0I7QUFDL0IsSUFBSSxLQUFLLGNBQUEsYUFBZ0IsVUFBVTtDQUNqQyxjQUFjO0VBQ1osTUFBTSxHQUFHLFNBQVMsR0FBRyxPQUFPLGVBQWUsTUFBTSxTQUFTO0dBQ3hELFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLE9BQU8sRUFDTCxNQUFNLEtBQUssSUFBSSxFQUNqQjtFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxpQkFBaUI7R0FDL0MsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsT0FBTyxLQUFLO0VBQ2QsQ0FBQztDQUNIO0NBQ0Esb0JBQW9CO0VBQ2xCLEtBQUssZ0JBQWdCLEtBQUssc0JBQXNCLEtBQUssTUFBTSxRQUFRO0NBQ3JFO0NBQ0EsbUJBQW1CLEdBQUc7RUFDcEIsRUFBRSxhQUFhLEtBQUssTUFBTSxhQUFhLGNBQWMsS0FBSyxhQUFhLEdBQUcsS0FBSyxnQkFBZ0IsS0FBSyxzQkFBc0IsS0FBSyxNQUFNLFFBQVE7Q0FDL0k7Q0FDQSxzQkFBc0IsR0FBRztFQUN2QixPQUFPLGtCQUFrQjtHQUN2QixLQUFLLFNBQVMsRUFDWixNQUFNLEtBQUssSUFBSSxFQUVqQixDQUFDO0VBQ0gsR0FBRyxDQUFDO0NBQ047Q0FDQSx1QkFBdUI7RUFDckIsY0FBYyxLQUFLLGFBQWE7Q0FDbEM7Q0FDQSxTQUFTO0VBQ1AsTUFBTSxFQUFFLE1BQU0sTUFBTSxLQUFLLE9BQWdELElBQUksR0FBekMsS0FBSyxNQUFNLHNCQUFzQixDQUFXLENBQUM7RUFDakYsT0FBTyxLQUFLLE1BQU0sU0FBUztHQUFFLFFBQVE7R0FBRyxNQUFNO0VBQUUsQ0FBQztDQUNuRDtBQUNGO0FBQ0EsT0FBTyxlQUFlLElBQUksZ0JBQWdCO0NBQ3hDLFlBQVksQ0FBQztDQUNiLGNBQWMsQ0FBQztDQUNmLFVBQVUsQ0FBQztDQUNYLE9BQU8sRUFDTCxVQUFVLEdBQ1o7QUFDRixDQUFDO0FBQ0QsSUFBTSxLQUFLLEdBQUcsNEJBQTRCO0FBQzFDLElBQUksS0FBSyxjQUFBLGFBQWdCLFVBQVU7Q0FDakMsU0FBUztFQUNQLE1BQU0sRUFBRSxNQUFNLE1BQU0sS0FBSyxPQUFnRCxJQUFJLEdBQXpDLEtBQUssTUFBTSxzQkFBc0IsQ0FBVyxDQUFDO0VBQ2pGLE9BQU8sS0FBSyxNQUFNLFNBQVM7R0FBRSxRQUFRO0dBQUcsTUFBTTtFQUFFLENBQUM7Q0FDbkQ7QUFDRjtBQUNBLE9BQU8sZUFBZSxJQUFJLGdCQUFnQjtDQUN4QyxZQUFZLENBQUM7Q0FDYixjQUFjLENBQUM7Q0FDZixVQUFVLENBQUM7Q0FDWCxPQUFPLEVBQ0wsVUFBVSxHQUNaO0FBQ0YsQ0FBQztBQUNELElBQU0sS0FBSyxHQUFHLHVCQUF1QjtBQUNyQyxJQUFJLEtBQUssY0FBQSxhQUFnQixVQUFVO0NBQ2pDLFlBQVksR0FBRztFQUNiLE1BQU0sQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLHlCQUF5QjtHQUM3RCxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxRQUFRLEVBQUUsWUFBWSxHQUFHLE1BQU0sR0FBRyxvQkFBb0IsUUFBUTtJQUM1RCxLQUFLLFNBQVM7S0FDWixZQUFZO0tBQ1osTUFBTTtLQUNOLGlCQUFpQjtJQUNuQixDQUFDO0dBQ0g7RUFDRixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sZUFBZTtHQUM3QyxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxPQUFPLEtBQUs7RUFDZCxDQUFDLEdBQUcsS0FBSyxRQUFRO0dBQ2YsWUFBWTtHQUNaLE1BQU07R0FDTixpQkFBaUIsQ0FBQztFQUNwQjtDQUNGO0NBQ0Esb0JBQW9CO0VBQ2xCLEtBQUssY0FBYyxLQUFLLE1BQU0sMkJBQTJCLEtBQUsscUJBQXFCO0NBQ3JGO0NBQ0EsdUJBQXVCO0VBQ3JCLEtBQUssZ0JBQWdCLEtBQUssWUFBWSxHQUFHLEtBQUssY0FBYyxLQUFLO0NBQ25FO0NBQ0EsU0FBUztFQUNQLE1BQU0sRUFBRSxpQkFBaUIsR0FBRyxZQUFZLEdBQUcsTUFBTSxNQUFNLEtBQUs7RUFDNUQsSUFBSSxDQUFDLEdBQ0gsT0FBTztFQUNULE1BQU0sSUFBSSxHQUFHLENBQUM7RUFDZCxPQUFPLEtBQUssTUFBTSxXQUFXLEtBQUssTUFBTSxTQUFTO0dBQUUsUUFBUTtHQUFHLE1BQU07RUFBRSxDQUFDLElBQUk7Q0FDN0U7QUFDRjtBQUNBLE9BQU8sZUFBZSxJQUFJLGdCQUFnQjtDQUN4QyxZQUFZLENBQUM7Q0FDYixjQUFjLENBQUM7Q0FDZixVQUFVLENBQUM7Q0FDWCxPQUFPLEVBQ0wsVUFBVSxHQUNaO0FBQ0YsQ0FBQztBQUNELElBQU0sTUFBTSxPQUFBLEdBQU1BLG1CQUFBQSxJQUFBQSxDQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsc0JBQXNCLFNBQUEsR0FBUUEsbUJBQUFBLElBQUFBLENBQUUsSUFBSTtDQUFFLDRCQUE0QjtDQUFHLEdBQUc7QUFBRSxDQUFDLEVBQUUsQ0FBQztBQUNySCxHQUFHLGNBQWM7QUFDakIsSUFBTSxZQUFBLEdBQVdBLG1CQUFBQSxJQUFBQSxDQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsdUJBQXVCLEdBQUcsa0JBQWtCLFNBQUEsR0FBUUEsbUJBQUFBLElBQUFBLENBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxTQUFTLFFBQVE7Q0FDOUgsTUFBTSxJQUFJLEVBQUU7Q0FDWixPQUFPLEVBQUUsS0FBSyxNQUFNO0VBQ2xCLFFBQVEsRUFBRSxNQUFWO0dBQ0UsS0FBSyxHQUFHLE9BQ04sd0JBQXdCLElBQUksS0FBSyxFQUFBLENBQUcsUUFBUSxLQUFLLEVBQUUsb0NBQW9DLElBQUksS0FBSyxFQUFBLENBQUcsUUFBUSxLQUFLLEVBQUUsaUJBQUEsR0FBZ0JBLG1CQUFBQSxJQUFBQSxDQUFFLElBQUk7SUFBRSx1QkFBdUI7SUFBRyxVQUFVLEVBQUU7SUFBVSxVQUFVLEVBQUU7R0FBUyxHQUFHLEVBQUUsRUFBRSxJQUFJO0dBQzVOLEtBQUssR0FBRyxRQUNOLE9BQU8sRUFBRSxRQUFRLEVBQUUsbUJBQW1CLEVBQUUsUUFBUSxFQUFFLGlCQUFBLEdBQWdCQSxtQkFBQUEsSUFBQUEsQ0FBRSxJQUFJO0lBQUUsVUFBVSxFQUFFO0lBQVUsTUFBTSxFQUFFO0lBQU0sdUJBQXVCO0dBQUUsR0FBRyxFQUFFLEVBQUUsSUFBSTtHQUNwSixLQUFLLEdBQUcsUUFDTixRQUFBLEdBQU9BLG1CQUFBQSxJQUFBQSxDQUFFLElBQUk7SUFBRSxVQUFVLEVBQUU7SUFBVSx1QkFBdUI7R0FBRSxHQUFHLEVBQUUsRUFBRTtHQUN2RSxTQUNFLE9BQU87RUFDWDtDQUNGLENBQUM7QUFDSCxFQUFFLENBQUMsRUFBRSxDQUFDO0FBQUcsSUFBQSxLQUFLO0NBQ1osVUFBVTtDQUNWLE1BQU07Q0FDTixPQUFPO0NBQ1AsS0FBSztDQUNMLFFBQVE7QUFDVjtBQUNBLElBQU0sS0FBTixjQUFBLGFBQW1CLFVBQVU7Q0FDM0IsY0FBYztFQUNaLE1BQU0sR0FBRyxTQUFTLEdBQUcsT0FBTyxlQUFlLE1BQU0sbUJBQW1CO0dBQ2xFLFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsTUFBTTtJQUNaLElBQUk7SUFDSixJQUFJLEtBQUssaUJBQWlCLE1BQU07S0FDOUIsTUFBTSxFQUFFLE9BQU8sTUFBTSxHQUFHLEVBQUUsTUFBTSxRQUFRLElBQUksS0FBSyxZQUFZLFlBQVksT0FBTyxLQUFLLElBQUksRUFBRSxzQkFBc0IsTUFBTSxFQUNySCxNQUFNLEVBQ1IsR0FBRyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssTUFBTSw4QkFBOEIsQ0FBQztLQUM1RCxLQUFLLGFBQWE7TUFDaEIsWUFBWTtNQUNaLE1BQU07TUFDTixvQkFBb0IsQ0FBQztLQUN2QixDQUFDO0lBQ0g7R0FDRjtFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxvQkFBb0I7R0FDbEQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsYUFBYTtJQUNYLEtBQUssaUJBQWlCLFFBQVEsS0FBSyxhQUFhO0tBQUUsWUFBWTtLQUFHLE1BQU07S0FBRyxvQkFBb0IsQ0FBQztJQUFFLENBQUM7R0FDcEc7RUFDRixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sNEJBQTRCO0dBQzFELFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsT0FBTyxLQUFLLGVBQWUsU0FBUztJQUMxQyxLQUFLLGVBQWU7R0FDdEI7RUFDRixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sU0FBUztHQUN2QyxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxPQUFPLEVBQ0wsc0JBQXNCLEtBQUsseUJBQzdCO0VBQ0YsQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLGVBQWU7R0FDN0MsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsT0FBQSxhQUFTLFVBQVU7RUFDckIsQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLGdCQUFnQjtHQUM5QyxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxPQUFPO0VBQ1QsQ0FBQztDQUNIO0NBQ0EsU0FBUztFQUNQLFFBQUEsR0FBT0EsbUJBQUFBLElBQUFBLENBQUUsSUFBSTtHQUFFLE9BQU8sS0FBSztHQUFPLFdBQUEsR0FBVUssbUJBQUFBLEtBQUFBLENBQUcsT0FBTztJQUFFLE9BQU87SUFBSSxhQUFhLEtBQUs7SUFBaUIsY0FBYyxLQUFLO0lBQWtCLEtBQUssS0FBSztJQUFhLFVBQVUsRUFBQSxHQUFDTCxtQkFBQUEsSUFBQUEsQ0FBRSxJQUFJLENBQUMsQ0FBQyxHQUFHLEtBQUssTUFBTSxRQUFRO0dBQUUsQ0FBQztFQUFFLENBQUM7Q0FDbk47QUFDRjtBQUNBLElBQU0sTUFBTSxPQUFBLEdBQU1BLG1CQUFBQSxJQUFBQSxDQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsK0JBQStCLFNBQUEsR0FBUUEsbUJBQUFBLElBQUFBLENBQUUsSUFBSTtDQUFFLCtCQUErQjtDQUFHLEdBQUc7QUFBRSxDQUFDLEVBQUUsQ0FBQztBQUNqSSxTQUFTLEdBQUcsR0FBRztDQUNiLEVBQUUsNkJBQTZCLEVBQUUsT0FBTyxHQUFHLE9BQU8saUJBQWlCLFVBQVUsRUFBRSxvQkFBb0I7QUFDckc7QUFDQSxTQUFTLEdBQUcsR0FBRztDQUNiLE9BQU8sb0JBQW9CLFVBQVUsRUFBRSxvQkFBb0I7QUFDN0Q7QUFDQSxJQUFNLEtBQUs7Q0FBRSxhQUFhO0NBQUksZ0JBQWdCO0FBQUc7QUFBRyxJQUFBLEtBQUs7Q0FDdkQsWUFBWTtDQUNaLGVBQWU7Q0FDZixvQkFBb0I7Q0FDcEIsZUFBZTtDQUNmLFdBQVc7Q0FDWCxjQUFjO0NBQ2QsaUJBQWlCO0NBQ2pCLGNBQWM7Q0FDZCxrQkFBa0I7Q0FDbEIsZ0JBQWdCO0FBQ2xCO0FBQUcsSUFBQSxLQUFLO0NBQ04sUUFBUTtDQUNSLFFBQVE7Q0FDUixNQUFNO0NBQ04sS0FBSztDQUNMLE9BQU87Q0FDUCxNQUFNO0FBQ1I7QUFBRyxJQUFBLEtBQUs7Q0FDTixNQUFNO0VBQ0osTUFBTTtFQUNOLFlBQVk7RUFDWixRQUFRO0VBQ1IsT0FBTztDQUNUO0NBQ0EsT0FBTztFQUNMLE1BQU07RUFDTixZQUFZO0VBQ1osUUFBUTtFQUNSLE9BQU87Q0FDVDtDQUNBLE1BQU07RUFDSixNQUFNO0VBQ04sWUFBWTtFQUNaLFFBQVE7RUFDUixPQUFPO0NBQ1Q7Q0FDQSxLQUFLO0VBQ0gsTUFBTTtFQUNOLFlBQVk7RUFDWixRQUFRO0VBQ1IsT0FBTztDQUNUO0NBQ0EsTUFBTTtFQUNKLE1BQU07RUFDTixZQUFZO0VBQ1osUUFBUTtFQUNSLE9BQU87Q0FDVDtDQUNBLFFBQVE7RUFDTixNQUFNO0VBQ04sWUFBWTtFQUNaLFFBQVE7RUFDUixPQUFPO0NBQ1Q7Q0FDQSxRQUFRO0VBQ04sTUFBTTtFQUNOLFlBQVk7RUFDWixRQUFRO0VBQ1IsT0FBTztDQUNUO0FBQ0Y7QUFLRyxJQUFBLEtBQUEsYUFBTyxjQUFjO0NBSnRCLHVCQUF1QixRQUFRLEtBQUssb0NBQW9DLEdBQUc7Q0FDM0UsbUJBQW1CO0NBQ25CLGtCQUFrQjtDQUNsQixXQUFXLENBQUM7QUFDVyxDQUFDO0FBQzFCLElBQU0sS0FBTixjQUFBLGFBQW1CLFVBQVU7Q0FDM0IsU0FBUztFQUNQLE1BQU0sSUFBSTtHQUNSLG1CQUFtQixLQUFLLE1BQU07R0FDOUIsa0JBQWtCLEtBQUssTUFBTTtHQUM3QixXQUFXLEtBQUssTUFBTTtHQUN0QixnQkFBZ0IsS0FBSyxNQUFNO0VBQzdCO0VBQ0EsUUFBQSxHQUFPQSxtQkFBQUEsSUFBQUEsQ0FBRSxHQUFHLFVBQVU7R0FBRSxPQUFPO0dBQUcsVUFBVSxLQUFLLE1BQU07RUFBUyxDQUFDO0NBQ25FO0FBQ0Y7QUFDQSxJQUFNLEtBQUs7QUFBSSxJQUFBLFlBQUEsR0FBV0UsYUFBQUEsV0FBQUEsQ0FBRyxFQUFFO0FBQy9CLElBQUksS0FBSyxFQUFFLFNBQVMsQ0FBQyxFQUFFOzs7Ozs7Q0FNdEIsU0FBUyxHQUFHO0NBQ1gsQ0FBQyxXQUFXO0VBQ1YsSUFBSSxJQUFJLENBQUMsRUFBRTtFQUNYLFNBQVMsSUFBSTtHQUNYLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSSxHQUFHLElBQUksVUFBVSxRQUFRLEtBQUs7SUFDakQsSUFBSSxJQUFJLFVBQVU7SUFDbEIsTUFBTSxJQUFJLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQztHQUNyQjtHQUNBLE9BQU87RUFDVDtFQUNBLFNBQVMsRUFBRSxHQUFHO0dBQ1osSUFBSSxPQUFPLEtBQUssWUFBWSxPQUFPLEtBQUssVUFDdEMsT0FBTztHQUNULElBQUksT0FBTyxLQUFLLFVBQ2QsT0FBTztHQUNULElBQUksTUFBTSxRQUFRLENBQUMsR0FDakIsT0FBTyxFQUFFLE1BQU0sTUFBTSxDQUFDO0dBQ3hCLElBQUksRUFBRSxhQUFhLE9BQU8sVUFBVSxZQUFZLENBQUMsRUFBRSxTQUFTLFNBQVMsQ0FBQyxDQUFDLFNBQVMsZUFBZSxHQUM3RixPQUFPLEVBQUUsU0FBUztHQUNwQixJQUFJLElBQUk7R0FDUixLQUFLLElBQUksS0FBSyxHQUNaLEVBQUUsS0FBSyxHQUFHLENBQUMsS0FBSyxFQUFFLE9BQU8sSUFBSSxFQUFFLEdBQUcsQ0FBQztHQUNyQyxPQUFPO0VBQ1Q7RUFDQSxTQUFTLEVBQUUsR0FBRyxHQUFHO0dBQ2YsT0FBTyxJQUFJLElBQUksSUFBSSxNQUFNLElBQUksSUFBSSxJQUFJO0VBQ3ZDO0VBQ0EsRUFBRSxXQUFXLEVBQUUsVUFBVSxHQUFHLEVBQUUsVUFBVSxLQUFLLE9BQU8sYUFBYTtDQUNuRSxFQUFBLENBQUc7QUFDTCxFQUFBLENBQUcsRUFBRTtBQUNMLElBQUksS0FBSyxHQUFHO0FBQ1osSUFBTSxLQUFxQixtQkFBRyxFQUFFO0FBQUcsSUFBQSxLQUFLO0FBQVEsSUFBQSxLQUFLO0FBQ3JELElBQU0sS0FBTixjQUFpQkksYUFBQUEsY0FBRztDQUNsQixjQUFjO0VBQ1osTUFBTSxHQUFHLFNBQVMsR0FBRyxPQUFPLGVBQWUsTUFBTSxnQkFBZ0I7R0FDL0QsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsUUFBUSxJQUFJLENBQUMsTUFBTTtJQUNqQixNQUFNLEVBQUUsT0FBTyxNQUFNLEdBQUcsSUFBSSxLQUFLLE1BQU0sWUFBWSxLQUFLLEtBQUssTUFBTSxvQkFBb0IsS0FBSyxNQUFNO0lBQ2xHLE9BQU8sRUFDTCxPQUFPO0tBQ0wsUUFBUSxLQUFLLE9BQU8sS0FBSyxJQUFJLEVBQUUsVUFBVTtLQUN6QyxHQUFHO0tBQ0gsT0FBTztJQUNULEVBQ0Y7R0FDRjtFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxzQkFBc0I7R0FDcEQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsY0FBYztJQUNaLGNBQWMsS0FBSztJQUNuQixNQUFNLEtBQUssTUFBTTtHQUNuQjtFQUNGLENBQUM7Q0FDSDtDQUNBLFNBQVM7RUFDUCxNQUFNLElBQUksS0FBSyxtQkFBbUI7RUFDbEMsT0FBTyxLQUFLLE1BQU0sU0FBUyxDQUFDO0NBQzlCO0FBQ0Y7QUFDQSxJQUFNLE1BQU0sRUFBRSxjQUFjLFNBQUEsR0FBUU4sbUJBQUFBLElBQUFBLENBQUUsT0FBTztDQUFFLGVBQWU7Q0FBaUIsR0FBRyxFQUFFO0FBQUUsQ0FBQztBQUFHLElBQUEsTUFBTSxNQUFNO0NBQ3BHLE1BQU0sRUFBRSxVQUFVLEdBQUcsU0FBUyxJQUFJLElBQUksWUFBWSxNQUFNLEdBQUcsRUFBRSxrQkFBa0IsR0FBRyxtQkFBbUIsTUFBTSxHQUFHO0NBQzlHLFFBQUEsR0FBT0EsbUJBQUFBLElBQUFBLENBQUUsSUFBSTtFQUFFLGtCQUFrQjtFQUFHLG1CQUFtQjtFQUFHLFNBQVM7RUFBRyxZQUFZO0VBQUcsVUFBVSxLQUFLO0NBQUcsQ0FBQztBQUMxRztBQUNBLEdBQUcsWUFBWTtBQUNmLElBQU0sS0FBTixjQUFBLGFBQW1CLFVBQVU7Q0FDM0IsY0FBYztFQUNaLE1BQU0sR0FBRyxTQUFTLEdBQUcsT0FBTyxlQUFlLE1BQU0sZ0JBQWdCO0dBQy9ELFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLGNBQWM7SUFDWixHQUFHLEtBQUssTUFBTTtJQUNkLFNBQVM7SUFDVCxPQUFPO0dBQ1Q7RUFDRixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sMEJBQTBCO0dBQ3hELFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLGFBQWE7SUFDWCxNQUFNLEVBQUUsa0JBQWtCLEdBQUcsbUJBQW1CLEdBQUcscUJBQXFCLE1BQU0sS0FBSztJQUNuRixPQUFPO0tBQ0wsR0FBRztLQUNILFVBQVU7S0FDVixPQUFPLGVBQWUsSUFBSSxFQUFFO0lBQzlCO0dBQ0Y7RUFDRixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sbUJBQW1CO0dBQ2pELFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsTUFBTSxFQUFFLFNBQVMsS0FBSyxJQUFJLENBQUMsSUFBSSxFQUFFLEtBQUssY0FBYyxHQUFHO0VBQ2pFLENBQUM7Q0FDSDtDQUNBLFNBQVM7RUFDUCxJQUFJLEdBQUc7RUFDUCxNQUFNLElBQUksQ0FBQyxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUssTUFBTSxRQUFRLElBQUksS0FBSyxNQUFNLFNBQVMsUUFBUSxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssTUFBTSxRQUFRO0VBQ2xILE9BQUEsYUFBUyxTQUFTLElBQUksSUFBSSxNQUFNO0dBQzlCLElBQUk7R0FDSixLQUFLLGdCQUFnQixDQUFDLE1BQU0sSUFBSSxLQUFLLE9BQU8sS0FBSyxJQUFJLEVBQUUsVUFBVSxPQUFPLEtBQUssSUFBSSxFQUFFLGFBQWEsS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJLEVBQUUsS0FBSyxDQUFDO0VBQy9ILENBQUMsR0FBRyxNQUFNLEtBQUEsR0FBSUEsbUJBQUFBLElBQUFBLENBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssS0FBSyxNQUFNLHNCQUFzQixLQUFBLEdBQUlBLG1CQUFBQSxJQUFBQSxDQUFFLElBQUksRUFBRSxTQUFTLFFBQVEsQ0FBQyxLQUFBLEdBQUlLLG1CQUFBQSxLQUFBQSxDQUFHLE9BQU87R0FBRSxlQUFlO0dBQWlCLE9BQU8sS0FBSyxhQUFhO0dBQUcsV0FBVyxHQUFHLG1CQUFtQixLQUFLLE1BQU0sU0FBUztHQUFHLFVBQVU7SUFBQztLQUFHTCxHQUFBQSxtQkFBQUEsSUFBQUEsQ0FBRSxPQUFPO0tBQUUsS0FBSyxLQUFLLE1BQU07S0FBZ0IsT0FBTyxLQUFLLHVCQUF1QjtLQUFHLFdBQVcsR0FBRyx1QkFBdUIsS0FBSyxNQUFNLHVCQUF1QjtLQUFHLGVBQWU7S0FBbUIsVUFBVTtJQUFFLENBQUM7SUFBRztHQUFDO0VBQUUsQ0FBQztDQUNwYztBQUNGO0FBQ0EsSUFBTSxNQUFNLEVBQUUsVUFBVSxHQUFHLE9BQU8sR0FBRyxXQUFXLEdBQUcscUJBQXFCLEdBQUcseUJBQXlCLFFBQVE7Q0FDMUcsTUFBTSxFQUFFLGtCQUFrQixHQUFHLG1CQUFtQixHQUFHLGdCQUFnQixNQUFNLEdBQUc7Q0FDNUUsUUFBQSxHQUFPQSxtQkFBQUEsSUFBQUEsQ0FBRSxJQUFJO0VBQUUsa0JBQWtCO0VBQUcsbUJBQW1CO0VBQUcsZ0JBQWdCO0VBQUcsT0FBTztFQUFHLFdBQVc7RUFBRyxxQkFBcUI7RUFBRyx5QkFBeUI7RUFBRyxVQUFVO0NBQUUsQ0FBQztBQUN4SztBQUNBLEdBQUcsWUFBWTtBQUNmLElBQU0sS0FBTixjQUFBLGFBQW1CLFVBQVU7Q0FDM0IsWUFBWSxHQUFHO0VBQ2IsTUFBTSxDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sc0JBQXNCO0dBQzFELFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsRUFBRSxpQkFBaUIsR0FBRyxlQUFlLEdBQUcsTUFBTSxHQUFHLFdBQVcsR0FBRyx1QkFBdUIsUUFBUTtJQUNwRyxNQUFNLElBQUksQ0FBQztJQUNYLE9BQU8sR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLEdBQUcsTUFBTTtLQUM5QixNQUFNLElBQUksRUFBRSxFQUFFLFFBQVEsQ0FBQyxHQUFHLElBQUksRUFBRSxFQUFFLFFBQVEsQ0FBQyxJQUFJO0tBQy9DLEVBQUUsS0FBSztNQUNMLFdBQVc7TUFDWCxTQUFTO01BQ1QsWUFBWTtNQUNaLE1BQU07S0FDUixDQUFDO0lBQ0gsQ0FBQyxHQUFHO0dBQ047RUFDRixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sZ0JBQWdCO0dBQzlDLFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsSUFBSSxDQUFDLE1BQU07SUFDakIsTUFBTSxFQUFFLE9BQU8sTUFBTTtJQUNyQixPQUFPLEVBQ0wsT0FBTyxPQUFPLE9BQU8sQ0FBQyxHQUFHLEtBQUssQ0FBQyxHQUFHO0tBQ2hDLFVBQVU7S0FDVixPQUFPLEtBQUssTUFBTTtLQUNsQixRQUFRLEtBQUssTUFBTTtJQUNyQixDQUFDLEVBQ0g7R0FDRjtFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxvQkFBb0I7R0FDbEQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsUUFBUSxJQUFJLENBQUMsTUFBTTtJQUNqQixNQUFNLEVBQUUsVUFBVSxHQUFHLE9BQU8sTUFBTTtJQUNsQyxJQUFJLENBQUMsR0FDSCxNQUFNLElBQUksTUFBTSxnREFBZ0Q7SUFDbEUsTUFBTSxFQUFFLFdBQVcsR0FBRyxZQUFZLEdBQUcsTUFBTSxNQUFNO0lBQ2pELE9BQU87S0FDTCxPQUFPO01BQ0wsR0FBRztNQUNILE1BQU07TUFDTixPQUFPO01BQ1AsVUFBVTtLQUNaO0tBQ0EsS0FBSyxTQUFTLEVBQUUsUUFBUTtJQUMxQjtHQUNGO0VBQ0YsQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLHNCQUFzQjtHQUNwRCxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxhQUFhO0lBQ1gsTUFBTSxFQU1KLE1BQU0sR0FDTixZQUFZLEdBQ1osWUFBWSxNQUNWLEtBQUs7SUFDVCxPQUFPO0tBUUwsZUFBZTtNQUNiLE1BQU07TUFDTixXQUFXLEtBQUssTUFBTTtLQUN4QjtLQUNBLGNBQWMsS0FBSztLQUNuQixrQkFBa0IsS0FBSztLQUN2QixZQUFZO0tBQ1osTUFBTTtJQUNSO0dBQ0Y7RUFDRixDQUFDO0VBQ0QsTUFBTSxFQUFFLGlCQUFpQixHQUFHLGVBQWUsR0FBRyxNQUFNLEdBQUcsV0FBVyxHQUFHLHVCQUF1QixNQUFNLEdBQUcsSUFBSSxLQUFLLG1CQUFtQjtHQUMvSCxpQkFBaUI7R0FDakIsZUFBZTtHQUNmLE1BQU07R0FDTixXQUFXO0dBQ1gsdUJBQXVCO0VBQ3pCLENBQUM7RUFDRCxLQUFLLFFBQVEsRUFDWCxXQUFXLEVBQ2I7Q0FDRjtDQWdCQSxtQkFBbUIsR0FBRztFQUNwQixJQUFJLENBQUMsR0FBRyxHQUFHLEtBQUssS0FBSyxHQUFHO0dBQ3RCLE1BQU0sRUFBRSxpQkFBaUIsR0FBRyxlQUFlLEdBQUcsTUFBTSxHQUFHLFdBQVcsR0FBRyx1QkFBdUIsTUFBTSxLQUFLLE9BQU8sSUFBSSxLQUFLLG1CQUFtQjtJQUN4SSxpQkFBaUI7SUFDakIsZUFBZTtJQUNmLE1BQU07SUFDTixXQUFXO0lBQ1gsdUJBQXVCO0dBQ3pCLENBQUM7R0FDRCxLQUFLLFNBQVMsRUFBRSxXQUFXLEVBQUUsQ0FBQztFQUNoQztDQUNGO0NBQ0EsU0FBUztFQUNQLE1BQU0sSUFBSSxLQUFLLG1CQUFtQjtFQUNsQyxPQUFPLEtBQUssTUFBTSxTQUFTLENBQUM7Q0FDOUI7QUFDRjtBQUNBLE9BQU8sZUFBZSxJQUFJLGdCQUFnQjtDQUN4QyxZQUFZLENBQUM7Q0FDYixjQUFjLENBQUM7Q0FDZixVQUFVLENBQUM7Q0FDWCxPQUFPLEVBQ0wsUUFBUSxHQUNWO0FBQ0YsQ0FBQztBQUNELFNBQVMsR0FBRyxFQUFFLFVBQVUsR0FBRyxNQUFNLEdBQUcsWUFBWSxHQUFHLFFBQVEsS0FBSztDQUM5RCxNQUFNLEVBQUUsa0JBQWtCLEdBQUcsWUFBWSxHQUFHLHVCQUF1QixNQUFNLEdBQUcsR0FBRyxJQUFJLEVBQUUsR0FBRyxFQUFFLFdBQVcsTUFBTSxHQUFHO0NBQzlHLFFBQUEsR0FBT0EsbUJBQUFBLElBQUFBLENBQUUsSUFBSTtFQUFFLFVBQVU7RUFBRyxXQUFXO0VBQUcsWUFBWTtFQUFHLE1BQU0sS0FBSyxFQUFFO0VBQWMsR0FBRztFQUFHLFlBQVk7RUFBRyx1QkFBdUI7RUFBRyxRQUFRO0NBQUUsQ0FBQztBQUNoSjtBQUNBLElBQUksS0FBSyxPQUFPLFNBQVMsU0FBUyxHQUFHO0NBQ25DLE9BQU8sT0FBTyxLQUFLLFlBQVksTUFBTTtBQUN2QztBQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUc7Q0FDaEIsT0FBTyxDQUFDLEVBQUUsTUFBTSxLQUFLLEdBQUcsQ0FBQyxLQUFLLEdBQUcsQ0FBQztBQUNwQztBQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUc7Q0FDaEIsSUFBSSxFQUFFLFdBQVcsRUFBRSxRQUNqQixPQUFPLENBQUM7Q0FDVixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLEtBQzVCLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLEVBQUUsR0FDaEIsT0FBTyxDQUFDO0NBQ1osT0FBTyxDQUFDO0FBQ1Y7QUFDQSxTQUFTLEdBQUcsR0FBRyxHQUFHO0NBQ2hCLE1BQU0sS0FBSyxNQUFNLElBQUk7Q0FDckIsSUFBSSxJQUFJO0NBQ1IsU0FBUyxJQUFJO0VBQ1gsS0FBSyxJQUFJLElBQUksQ0FBQyxHQUFHLElBQUksR0FBRyxJQUFJLFVBQVUsUUFBUSxLQUM1QyxFQUFFLEtBQUssVUFBVTtFQUNuQixJQUFJLEtBQUssRUFBRSxhQUFhLFFBQVEsRUFBRSxHQUFHLEVBQUUsUUFBUSxHQUM3QyxPQUFPLEVBQUU7RUFDWCxJQUFJLElBQUksRUFBRSxNQUFNLE1BQU0sQ0FBQztFQUN2QixPQUFPLElBQUk7R0FDVCxZQUFZO0dBQ1osVUFBVTtHQUNWLFVBQVU7RUFDWixHQUFHO0NBQ0w7Q0FDQSxPQUFPLEVBQUUsUUFBUSxXQUFXO0VBQzFCLElBQUk7Q0FDTixHQUFHO0FBQ0w7QUFDQSxJQUFNLEtBQU4sY0FBQSxhQUFtQixjQUFjO0NBQy9CLGNBQWM7RUFDWixNQUFNLEdBQUcsU0FBUyxHQUFHLE9BQU8sZUFBZSxNQUFNLG1CQUFtQjtHQUNsRSxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxhQUFhO0lBQ1gsTUFBTSxFQUFFLGVBQWUsR0FBRyxVQUFVLEdBQUcsTUFBTSxHQUFHLFlBQVksTUFBTSxLQUFLO0lBQ3ZFLElBQUksR0FBRztLQUNMLE1BQU0sSUFBSSxHQUFHLENBQUM7S0FDZCxFQURxQixFQUFFLFVBQVUsTUFBTSxDQUFDLENBQUMsUUFBUSxDQUMvQyxHQUR1RCxFQUFFLFVBQVUsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUM5RSxDQUFDO0lBQ1IsT0FDRSxFQUFFLEVBQUUsV0FBVyxFQUFFLE9BQU87R0FDNUI7RUFDRixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sb0JBQW9CO0dBQ2xELFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsSUFBSSxDQUFDLE9BQU87SUFDbEIsR0FBRyxLQUFLLE1BQU0saUJBQWlCO0tBQzdCLFVBQVUsS0FBSyxNQUFNO0tBQ3JCLEdBQUc7SUFDTCxDQUFDO0lBQ0QsU0FBUyxHQUFHLEtBQUssaUJBQWlCLEVBQUUsT0FBTztHQUM3QztFQUNGLENBQUM7Q0FDSDtDQUNBLFNBQVM7RUFDUCxNQUFNLEVBQUUsY0FBYyxHQUFHLFVBQVUsR0FBRyxrQkFBa0IsR0FBRyxZQUFZLE1BQU0sS0FBSyxPQUFPLElBQUk7RUFDN0YsSUFBSSxHQUNGLE9BQU8sRUFBRTtHQUNQLGtCQUFrQixLQUFLO0dBQ3ZCLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixjQUFjO0dBQ2hCO0dBQ0EsTUFBTTtFQUNSLENBQUM7RUFDSCxNQUFNLEVBQUUsS0FBSyxHQUFHLEdBQUcsTUFBTSxLQUFLLGlCQUFpQjtFQUMvQyxRQUFBLEdBQU9ELGFBQUFBLGNBQUFBLENBQ0wsT0FDQTtHQUFFLGVBQWU7R0FBc0IsR0FBRztHQUFHLEtBQUs7R0FBRyxXQUFXLGtCQUFrQixLQUFLLE1BQU0sZ0JBQWdCLDJCQUEyQjtFQUFLLElBQUEsR0FDN0lDLG1CQUFBQSxJQUFBQSxDQUFFLFFBQVEsRUFBRSxVQUFVLEVBQUUsQ0FBQyxDQUMzQjtDQUNGO0FBQ0Y7QUFDQSxTQUFTLEdBQUcsRUFBRSxlQUFlLEVBQUUsV0FBVyxHQUFHLE1BQU0sS0FBSyxjQUFjLEdBQUcsa0JBQWtCLEdBQUcsWUFBWSxHQUFHLE1BQU0sRUFBRSxPQUFPLEdBQUcsa0JBQWtCLEdBQUcsV0FBVyxHQUFHLGdCQUFnQixHQUFHLFVBQVUsR0FBRyxZQUFZLE9BQU87Q0FDbk4sUUFBQSxHQUFPQSxtQkFBQUEsSUFBQUEsQ0FBRSxPQUFPO0VBQUUsZUFBZTtFQUFjLFdBQVc7RUFBRyxHQUFHLEVBQUUsRUFBRSxPQUFPLEVBQUUsQ0FBQztFQUFHLFVBQVUsRUFBRSxLQUFLLE1BQU07R0FDdEcsTUFBTSxJQUFJLEVBQUUsQ0FBQyxFQUFFLFdBQVcsRUFBRSxPQUFPLEdBQUcsR0FBRyxFQUFFLFVBQVU7R0FDckQsUUFBQSxHQUFPQSxtQkFBQUEsSUFBQUEsQ0FBRSxJQUFJO0lBQUUsTUFBTTtJQUFHLFVBQVU7SUFBRyxZQUFZO0lBQUcsY0FBYztJQUFHLGVBQWUsTUFBTTtJQUFpQixrQkFBa0I7SUFBRyxrQkFBa0I7SUFBRyxZQUFZO0dBQUUsR0FBRyxTQUFTLEVBQUUsVUFBVSxRQUFRLEdBQUc7RUFDeE0sQ0FBQztDQUFFLENBQUM7QUFDTjtBQUNBLElBQU0sS0FBTixjQUFBLGFBQW1CLFVBQVU7Q0FDM0IsY0FBYztFQUNaLE1BQU0sR0FBRyxTQUFTLEdBQUcsT0FBTyxlQUFlLE1BQU0saUJBQWlCO0dBQ2hFLFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLGFBQWEsS0FBSyxNQUFNLFNBQVMsa0JBQWtCLEdBQUcsS0FBSyxNQUFNLFlBQVksSUFBSSxLQUFLLE1BQU0sT0FBTyxLQUFLLE1BQU0sT0FBTyxLQUFLLE1BQU07RUFDbEksQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLGdCQUFnQjtHQUM5QyxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxPQUFPLElBQUksT0FBTztJQUNoQixRQUFRO0lBQ1IsR0FBRztHQUNMLEVBQUU7RUFDSixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sa0JBQWtCO0dBQ2hELFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsR0FBRyxHQUFHLE1BQU07SUFDbEIsTUFBTSxFQUFFLGFBQWEsTUFBTSxLQUFLO0lBQ2hDLElBQUksT0FBTyxLQUFLLFVBQ2QsT0FBTyxFQUFFLEVBQUUsQ0FBQyxPQUFPLENBQUM7SUFDdEIsSUFBSSxPQUFPLEtBQUssWUFDZCxPQUFPLEVBQUUsR0FBRyxHQUFHLENBQUM7SUFDbEIsTUFBTSxJQUFJLE1BQU0sMENBQTBDO0dBQzVEO0VBQ0YsQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLGlCQUFpQjtHQUMvQyxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxPQUFPLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLE9BQU87SUFDL0Isa0JBQWtCO0lBQ2xCLE9BQU87SUFDUCxXQUFXO0lBQ1gsZ0JBQWdCO0lBQ2hCLFVBQVU7SUFDVixZQUFZO0dBQ2QsRUFBRTtFQUNKLENBQUM7Q0FDSDtDQUNBLFNBQVM7RUFDUCxNQUFNLElBQUksS0FBSyxjQUFjLEdBQUcsRUFBRSxRQUFRLE1BQU0sS0FBSztFQUNyRCxRQUFBLEdBQU9BLG1CQUFBQSxJQUFBQSxDQUFFLElBQUk7R0FBRSxVQUFVO0dBQUksTUFBTTtHQUFHLFFBQVE7R0FBRyxZQUFZLEtBQUssY0FBYyxLQUFLLE1BQU0sa0JBQWtCLEtBQUssYUFBYSxLQUFLLE1BQU0sS0FBSyxHQUFHLEtBQUssTUFBTSxXQUFXLEtBQUssZ0JBQWdCLEtBQUssTUFBTSxNQUFNLEtBQUssTUFBTSxVQUFVO0VBQUUsQ0FBQztDQUN4TztBQUNGO0FBQ0EsU0FBUyxHQUFHLEVBQUUsYUFBYSxHQUFHLE1BQU0sR0FBRyxPQUFPLEdBQUcsV0FBVyxHQUFHLGtCQUFrQixHQUFHLFlBQVksR0FBRyxRQUFRLEtBQUs7Q0FDOUcsUUFBQSxHQUFPQSxtQkFBQUEsSUFBQUEsQ0FBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLGtCQUFrQixRQUFRO0VBQ3BELE1BQU0sSUFBSSxFQUFFO0VBQ1osUUFBQSxHQUFPQSxtQkFBQUEsSUFBQUEsQ0FBRSxJQUFJO0dBQUUsY0FBYyxFQUFFO0dBQWMsTUFBTTtHQUFHLGFBQWEsS0FBSztHQUFJLE9BQU87R0FBRyxXQUFXO0dBQUcsa0JBQWtCO0dBQUcsWUFBWTtHQUFHLFFBQVE7RUFBRSxDQUFDO0NBQ3JKLEVBQUUsQ0FBQztBQUNMO0FBQ0EsSUFBTSxNQUFNLENBQUMsSUFBSSxHQUFHLElBQUksS0FBSyxJQUFJLE9BQU87Q0FDdEMsSUFBSTtDQUNKLE9BQU8sS0FBSyxNQUFNLElBQUksRUFBRSxFQUFFLENBQUMsT0FBTyxLQUFLLE1BQU0sSUFBSSxFQUFFLEVBQUUsQ0FBQyxhQUFhLEtBQUssS0FBSyxJQUFJLEVBQUUsRUFBRSxDQUFDLFNBQVMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDO0FBQzNIO0FBQ0EsSUFBSSxLQUFLLEVBQUUsU0FBUyxDQUFDLEVBQUU7Q0FDdEIsU0FBUyxHQUFHLEdBQUc7Q0FDZCxDQUFDLFNBQVMsR0FBRyxHQUFHO0VBQ2QsRUFBRSxVQUFVLEVBQUU7Q0FDaEIsRUFBQSxDQUFHLElBQUksV0FBVztFQUNoQixJQUFJLElBQUk7R0FBRSxLQUFLO0dBQWEsSUFBSTtHQUFVLEdBQUc7R0FBYyxJQUFJO0dBQWdCLEtBQUs7R0FBdUIsTUFBTTtFQUE0QjtFQUM3SSxPQUFPLFNBQVMsR0FBRyxHQUFHLEdBQUc7R0FDdkIsSUFBSSxJQUFJLEVBQUUsV0FBVyxJQUFJLEVBQUU7R0FDM0IsRUFBRSxHQUFHLFVBQVUsR0FBRyxFQUFFLFNBQVMsU0FBUyxHQUFHO0lBQ3ZDLE1BQU0sS0FBSyxNQUFNLElBQUk7SUFDckIsSUFBSSxJQUFJLEtBQUssUUFBUSxDQUFDLENBQUMsU0FBUyxJQUFJLFNBQVMsR0FBRyxHQUFHO0tBQ2pELE9BQU8sRUFBRSxRQUFRLHFDQUFxQyxTQUFTLEdBQUcsR0FBRyxHQUFHO01BQ3RFLElBQUksSUFBSSxLQUFLLEVBQUUsWUFBWTtNQUMzQixPQUFPLEtBQUssRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLEVBQUUsQ0FBQyxRQUFRLGtDQUFrQyxTQUFTLEdBQUcsR0FBRyxHQUFHO09BQzNGLE9BQU8sS0FBSyxFQUFFLE1BQU0sQ0FBQztNQUN2QixDQUFDO0tBQ0gsQ0FBQztJQUNILEVBQUUsR0FBRyxNQUFNLEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQztJQUMxQixPQUFPLEVBQUUsS0FBSyxNQUFNLENBQUM7R0FDdkI7RUFDRjtDQUNGLENBQUM7QUFDSCxFQUFBLENBQUcsRUFBRTtBQUNMLElBQUksS0FBSyxHQUFHO0FBQ1osSUFBTSxLQUFxQixtQkFBRyxFQUFFO0FBQ2hDQyxpQkFBQUEsUUFBRyxPQUFPLEVBQUU7QUFDWixJQUFNLEtBQU4sY0FBaUJFLGFBQUFBLFVBQUc7Q0FDbEIsWUFBWSxHQUFHO0VBQ2IsTUFBTSxDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sc0JBQXNCO0dBQzFELFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLGFBQWE7SUFDWCxNQUFNLEVBQUUsT0FBTyxHQUFHLGtCQUFrQixHQUFHLGdCQUFnQixHQUFHLGlCQUFpQixHQUFHLGVBQWUsTUFBTSxLQUFLLE9BQU8sSUFBSSxJQUFJO0lBQ3ZILE9BQU87S0FDTCxhQUY0SCxHQUFHLEdBQUcsS0FBSyxNQUFNLE1BRWhJO0tBQ2IsY0FIMEosR0FBRyxHQUFHLEdBQUcsS0FBSyxNQUFNLFNBR2hLO0tBQ2QsZUFBZTtLQUNmLGtCQUFrQjtLQUNsQixnQkFBZ0I7S0FDaEIsaUJBQWlCO0tBQ2pCLGVBQWU7SUFDakI7R0FDRjtFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxtQkFBbUI7R0FDakQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsYUFBYTtJQUNYLE1BQU0sRUFBRSxPQUFPLEdBQUcsa0JBQWtCLEdBQUcsZ0JBQWdCLE1BQU0sS0FBSyxPQUFPLEVBQUUsV0FBVyxNQUFNLEtBQUs7SUFDakcsT0FBTyxHQURxRyxJQUFJLEdBQ25HLEdBQUcsQ0FBQztHQUNuQjtFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxTQUFTO0dBQ3ZDLFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLE9BQU8sS0FBSztFQUNkLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxtQkFBbUI7R0FDakQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsT0FBTztFQUNULENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxtQkFBbUI7R0FDakQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsT0FBTztFQUNULENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxVQUFVO0dBQ3hDLFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsSUFBSSxLQUFLLFVBQVU7SUFDekIsSUFBSTtJQUNKLE1BQU0sRUFBRSxPQUFPLFFBQVEsSUFBSSxLQUFLLFVBQVUsWUFBWSxPQUFPLEtBQUssSUFBSSxFQUFFLHNCQUFzQixNQUFNLEVBQUUsT0FBTyxFQUFFLEdBQUcsSUFBSSxJQUFJLEVBQUUsZUFBZSxFQUFFLG1CQUFtQixJQUFJLEdBQUcsR0FBRyxFQUFFLE1BQU0sR0FBRyxFQUFFLGdCQUFnQixHQUFHLFFBQVEsR0FBRyxjQUFjLEdBQUcsV0FBVyxNQUFNLEdBQUcsRUFBRSxPQUFPLEVBQUUsUUFBUSxHQUFHLEtBQUssTUFBTSxpQkFBaUIsS0FBSyxNQUFNLGVBQWUsRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFFLGlCQUFpQixFQUFFLFlBQVksS0FBSyxNQUFNLGNBQWMsS0FBSyxNQUFNLGNBQWMsS0FBSyxNQUFNLFVBQVUsS0FBSyxNQUFNLGNBQWMsS0FBSyxNQUFNLFlBQVksS0FBSyxNQUFNLGVBQWUsRUFBRSxlQUFlO0lBQy9oQixLQUFLLFNBQVM7S0FDWixPQUFPO0tBQ1AsZ0JBQWdCO0tBQ2hCLFFBQVE7S0FDUixjQUFjO0tBQ2QsV0FBVztJQUNiLENBQUM7SUFDRCxNQUFNLElBQUksTUFBTSxFQUFFLFNBQVMsS0FBSztJQUNoQyxLQUFLLG9CQUFvQixLQUFLLGdCQUFnQixhQUFhLElBQUksS0FBSyxvQkFBb0IsS0FBSyxnQkFBZ0IsYUFBYTtHQUM1SDtFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxZQUFZO0dBQzFDLFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsTUFBTTtJQUNaLElBQUksR0FBRztJQUNQLE1BQU0sSUFBSSxLQUFLLE1BQU0sT0FBTyxJQUFJLEtBQUssTUFBTSxpQkFBaUIsSUFBSSxLQUFLLE1BQU0saUJBQWlCLEtBQUssTUFBTSxrQkFBa0IsSUFBSSxJQUFJLElBQUksSUFBSTtJQUN6SSxDQUFDLEtBQUssTUFBTSxxQkFBcUIsS0FBSyxLQUFLLE1BQU0sbUJBQW1CLElBQUksUUFBUSxLQUFLLElBQUksS0FBSyxNQUFBLENBQU8saUJBQWlCLFFBQVEsRUFBRSxLQUFLLEdBQUcsR0FBRyxJQUFJLEdBQUcsS0FBSyxvQkFBb0IsS0FBSyxnQkFBZ0IsQ0FBQztHQUNuTTtFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxzQkFBc0I7R0FDcEQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsUUFBUSxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsSUFBSSxLQUFLLE1BQU0sT0FBTyxJQUFJLEtBQUssTUFBTSxXQUFXO0lBQ3BFLEtBQUssU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxLQUFLLE9BQU8sS0FBSyxLQUFLLENBQUM7R0FDekQ7RUFDRixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sbUJBQW1CO0dBQ2pELFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsR0FBRyxHQUFHLE1BQU07SUFDbEIsS0FBSyxXQUFXLElBQUksSUFBSSxJQUFJLEtBQUssSUFBSSxLQUFLLE1BQU0sS0FBSztHQUN2RDtFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxjQUFjO0dBQzVDLFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsR0FBRyxJQUFJLE9BQVE7SUFDckIsTUFBTSxFQUFFLFNBQVMsR0FBRyxTQUFTLE1BQU0sS0FBSyxPQUFPLElBQUksS0FBSyxNQUFNLGlCQUFpQixLQUFLLE1BQU0sa0JBQWtCLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLE1BQU0sSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLEtBQUssTUFBTSxLQUFLLE1BQU0sb0JBQW9CLElBQUksS0FBSyxDQUFDO0lBQ3JOLEtBQUssTUFBTSxnQkFBZ0IsS0FBSyxNQUFNLGFBQWEsR0FBRyxJQUFJLEdBQUcsS0FBSyxvQkFBb0IsS0FBSyxnQkFBZ0IsQ0FBQztHQUM5RztFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxjQUFjO0dBQzVDLFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsR0FBRyxNQUFNO0lBQ2YsSUFBSSxHQUFHO0lBQ1AsTUFBTSxJQUFJLEVBQUUsUUFBUSxHQUFHLElBQUksRUFBRSxRQUFRLElBQUk7SUFDekMsSUFBSSxLQUFLLE1BQU0sWUFBWSxLQUFLLElBQUksS0FBSyxNQUFBLENBQU8saUJBQWlCLFFBQVEsRUFBRSxLQUFLLEdBQUcsR0FBRyxJQUFJLEdBQUcsS0FBSyxvQkFBb0IsS0FBSyxnQkFBZ0IsQ0FBQztHQUM5STtFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxjQUFjO0dBQzVDLFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsR0FBRyxHQUFHLE1BQU07SUFDbEIsSUFBSSxLQUFLLGVBQWUsQ0FBQyxLQUFLLEtBQUssTUFBTSx1QkFBdUIsTUFBTSxTQUNoRTtTQUFBLEtBQUssS0FBSyxNQUFNLGFBQWE7TUFDL0IsTUFBTSxJQUFJLEtBQUssa0JBQWtCLENBQUM7TUFDbEMsS0FBSyxNQUFNLFlBQVksR0FBRyxHQUFHLENBQUM7S0FDaEM7V0FDSyxJQUFJLEtBQUssU0FBUyxFQUFFLGNBQWMsRUFBRSxDQUFDLEdBQUcsS0FBSyxLQUFLLE1BQU0sY0FBYztLQUMzRSxNQUFNLElBQUksS0FBSyxrQkFBa0IsQ0FBQztLQUNsQyxLQUFLLE1BQU0sYUFBYSxHQUFHLEdBQUcsQ0FBQztJQUNqQyxPQUFPLE1BQU0sUUFBUSxLQUFLLE1BQU0sa0JBQWtCLEtBQUssTUFBTSxlQUFlLENBQUM7R0FDL0U7RUFDRixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sbUJBQW1CO0dBQ2pELFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsR0FBRyxNQUFNO0lBQ2YsSUFBSSxLQUFLLE1BQU0sbUJBQW1CO0tBQ2hDLE1BQU0sSUFBSSxLQUFLLGtCQUFrQixDQUFDO0tBQ2xDLEtBQUssTUFBTSxrQkFBa0IsR0FBRyxHQUFHLENBQUM7SUFDdEM7R0FDRjtFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSx3QkFBd0I7R0FDdEQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsUUFBUSxHQUFHLE1BQU07SUFDZixJQUFJLEtBQUssTUFBTSxtQkFBbUI7S0FDaEMsTUFBTSxJQUFJLEtBQUssa0JBQWtCLENBQUM7S0FDbEMsS0FBSyxNQUFNLGtCQUFrQixHQUFHLEdBQUcsQ0FBQztJQUN0QztHQUNGO0VBQ0YsQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLDRCQUE0QjtHQUMxRCxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxRQUFRLE1BQU07SUFDWixNQUFNLEVBQUUsVUFBVSxHQUFHLFFBQVEsTUFBTSxLQUFLLE9BQU8sRUFBRSxPQUFPLEdBQUcsaUJBQWlCLEdBQUcsZUFBZSxNQUFNLEtBQUssT0FBTyxFQUFFLFNBQVMsTUFBTSxFQUFFO0lBQ25JLElBQUksSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDNUIsT0FBTyxJQUFJLEtBQUssTUFBTSxJQUFJLENBQUMsSUFBSSxHQUFHO0dBQ3BDO0VBQ0YsQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLHFCQUFxQjtHQUNuRCxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxRQUFRLE1BQU07SUFDWixNQUFNLEVBQUUsT0FBTyxHQUFHLGtCQUFrQixHQUFHLGdCQUFnQixNQUFNLEtBQUssT0FBTyxJQUFJLEtBQUssTUFBTSxVQUFvQyxFQUFFLE1BQU0sTUFBOUIsS0FBSyxnQkFBaUMsc0JBQXNCLEdBQXVDLE1BQS9CLEVBQUUsVUFBVSxLQUFLLEtBQU8sSUFBSTtJQUN0TSxJQUFJLElBQUksS0FBSyxNQUFNLElBQUksRUFBRTtJQUN6QixPQUFPLElBQUksS0FBSyxNQUFNLElBQUksQ0FBQyxJQUFJLEdBQUc7R0FDcEM7RUFDRixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sWUFBWTtHQUMxQyxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxRQUFRLEdBQUcsR0FBRyxNQUFNO0lBQ2xCLE1BQU0sSUFBSSxLQUFLLE1BQU0sT0FBTyxJQUFJLElBQUksS0FBSyxNQUFNO0lBQy9DLEtBQUssU0FBUztLQUNaLGNBQWM7S0FDZCxVQUFVO0tBQ1YsZUFBZTtLQUNmLGdCQUFnQixJQUFJLEVBQUUsR0FBRyxFQUFFLGFBQWEsSUFBSTtJQUM5QyxDQUFDLEdBQUcsS0FBSyxhQUFhO0tBQ3BCLFdBQVc7S0FDWCxRQUFRO0tBQ1IsTUFBTTtLQUNOLGVBQWU7SUFDakIsQ0FBQztHQUNIO0VBQ0YsQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLFlBQVk7R0FDMUMsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsUUFBUSxHQUFHLEdBQUcsTUFBTTtJQUNsQixLQUFLLFNBQVM7S0FBRSxjQUFjO0tBQU0sVUFBVTtLQUFNLGdCQUFnQjtJQUFLLENBQUMsR0FBRyxLQUFLLE1BQU0sY0FBYyxLQUFLLE1BQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQztHQUNySTtFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxnQkFBZ0I7R0FDOUMsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsUUFBUSxHQUFHLEdBQUcsTUFBTTtJQUNsQixLQUFLLFNBQVM7S0FDWixjQUFjO0tBQ2QsY0FBYztLQUNkLFlBQVk7SUFDZCxDQUFDLEdBQUcsS0FBSyxhQUFhO0tBQ3BCLFdBQVc7S0FDWCxRQUFRO0tBQ1IsTUFBTTtLQUNOLE1BQU0sS0FBSyxLQUFLO0lBQ2xCLENBQUM7R0FDSDtFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxlQUFlO0dBQzdDLFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsR0FBRyxHQUFHLEdBQUcsTUFBTTtJQUNyQixLQUFLLFNBQVM7S0FBRSxjQUFjO0tBQU0sY0FBYztLQUFNLFlBQVk7SUFBSyxDQUFDLEdBQUcsS0FBSyxNQUFNLGdCQUFnQixNQUFNLEtBQUssS0FBSyxNQUFNLGFBQWEsR0FBRyxHQUFHLENBQUM7R0FDcEo7RUFDRixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sZ0JBQWdCO0dBQzlDLFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsRUFBRSxXQUFXLEdBQUcsUUFBUSxHQUFHLE1BQU0sR0FBRyxNQUFNLEdBQUcsZUFBZSxRQUFRO0lBQzFFLEtBQUssTUFBTSxlQUFlLE1BQU0sU0FBUyxLQUFLLE1BQU0sV0FBVztLQUM3RCxXQUFXO0tBQ1gsUUFBUTtLQUNSLE1BQU07S0FDTixlQUFlO0lBQ2pCLENBQUMsSUFBSSxLQUFLLE1BQU0sV0FBVztLQUN6QixXQUFXO0tBQ1gsUUFBUTtLQUNSLE1BQU07S0FDTixNQUFNO0lBQ1IsQ0FBQztHQUNIO0VBQ0YsQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLGtCQUFrQjtHQUNoRCxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxRQUFRLEdBQUcsTUFBTTtJQUNmLElBQUksS0FBSyxnQkFBZ0IsS0FBSyxLQUFLLFdBQVcsTUFBTSxTQUFTLENBQUMsR0FBRyxLQUFLLE1BQU0saUJBQWlCLE1BQzNGO0lBQ0YsTUFBTSxJQUFJLEtBQUsseUJBQXlCLENBQUMsR0FBRyxJQUFJLEVBQUUsS0FBSyxNQUFNLE9BQU8sSUFBSSxLQUFLLE1BQU0sS0FBSyxVQUFVO0lBQ2xHLEtBQUssTUFBTSxjQUFjLEdBQUcsR0FBRyxDQUFDO0dBQ2xDO0VBQ0YsQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLHdCQUF3QjtHQUN0RCxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxRQUFRLEdBQUcsTUFBTTtJQUNmLElBQUksS0FBSyxNQUFNLHVCQUF1QixNQUNwQztJQUNGLE1BQU0sSUFBSSxLQUFLLHlCQUF5QixDQUFDLEdBQUcsSUFBSSxFQUFFLEtBQUssTUFBTSxPQUFPLElBQUksS0FBSyxNQUFNLEtBQUssVUFBVTtJQUNsRyxLQUFLLE1BQU0sb0JBQW9CLEdBQUcsR0FBRyxDQUFDO0dBQ3hDO0VBQ0YsQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLDJCQUEyQjtHQUN6RCxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxRQUFRLEdBQUcsTUFBTTtJQUNmLElBQUksS0FBSyxNQUFNLHVCQUF1QixNQUNwQztJQUNGLE1BQU0sSUFBSSxLQUFLLHlCQUF5QixDQUFDLEdBQUcsSUFBSSxFQUFFLEtBQUssTUFBTSxPQUFPLElBQUksS0FBSyxNQUFNLEtBQUssVUFBVTtJQUNsRyxLQUFLLE1BQU0sd0JBQXdCLEVBQUUsZUFBZSxHQUFHLEtBQUssTUFBTSxvQkFBb0IsR0FBRyxHQUFHLENBQUM7R0FDL0Y7RUFDRixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sbUJBQW1CO0dBQ2pELFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLFFBQVEsTUFBTTtJQUNaLEtBQUssa0JBQWtCLEdBQUcsS0FBSyxNQUFNLGFBQWEsS0FBSyxNQUFNLFVBQVUsQ0FBQztHQUMxRTtFQUNGLENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSxvQkFBb0I7R0FDbEQsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsUUFBUSxNQUFNLEVBQUUsU0FBUyxLQUFLLElBQUksQ0FBQyxJQUFJLEVBQUUsS0FBSyxjQUFjLEdBQUc7RUFDakUsQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLGlCQUFpQjtHQUMvQyxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxhQUFhO0lBQ1gsSUFBSSxLQUFLLE1BQU0sVUFBVTtLQUN2QixJQUFJO0tBQ0osSUFBQSxhQUFNLFNBQVMsSUFBSSxLQUFLLE1BQU0sV0FBVyxNQUFNO01BQzdDLEtBQUssaUJBQWlCLENBQUMsTUFBTSxJQUFJO0tBQ25DLENBQUMsR0FBRyxHQUNGLE9BQU87SUFDWDtJQUNBLFFBQUEsR0FBT0UsbUJBQUFBLEtBQUFBLENBQUcsSUFBSSxFQUFFLFVBQVUsRUFBQSxHQUFDTCxtQkFBQUEsSUFBQUEsQ0FBRSxJQUFJLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQyxJQUFBLEdBQUdBLG1CQUFBQSxJQUFBQSxDQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0dBQzNFO0VBQ0YsQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLHVCQUF1QjtHQUNyRCxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxRQUFRLE1BQU07SUFDWixLQUFLLE1BQU0sYUFBYSxLQUFLLE1BQU0sVUFBVSxDQUFDLEdBQUcsS0FBSyxrQkFBa0I7R0FDMUU7RUFDRixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sYUFBYTtHQUMzQyxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxPQUFBLGFBQVMsVUFBVTtFQUNyQixDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0seUJBQXlCO0dBQ3ZELFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLGFBQWEsS0FBSyxnQkFBZ0Isc0JBQXNCO0VBQzFELENBQUMsR0FBRyxPQUFPLGVBQWUsTUFBTSwwQ0FBMEM7R0FDeEUsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsUUFBUSxHQUFHLE1BQU07SUFDZixNQUFNLElBQUksR0FBRyxLQUFLLE1BQU0sT0FBTyxLQUFLLE1BQU0sTUFBTSxHQUFHLElBQUksR0FBRyxLQUFLLE1BQU0saUJBQWlCLEtBQUssTUFBTSxlQUFlLENBQUMsR0FBRyxJQUFJLEdBQUcsS0FBSyxlQUFlLENBQUMsQ0FBQyxZQUFZLElBQUksR0FBRyxLQUFLLGVBQWUsR0FBRyxLQUFLLElBQUksSUFBSSxFQUFFLGNBQWMsSUFBSSxLQUFLLE1BQU07SUFDdk8sSUFBSSxJQUFJO0lBQ1IsS0FBSyxNQUFNLEtBQUssS0FBSyxNQUFNLFdBQ3pCLElBQUksSUFBSSxPQUFPLENBQUMsR0FDZCxJQUFJLEtBQUssTUFBTSxVQUFVLFFBQVEsQ0FBQztTQUVsQztJQUNKLElBQUksQ0FBQyxLQUFLLE1BQU0sVUFDZCxPQUFPO0tBQUUsTUFBTTtLQUFHLFlBQVk7SUFBRTtJQUNsQyxNQUFNLEtBQUEsR0FBSUMsaUJBQUFBLFFBQUFBLENBQUcsQ0FBQyxDQUFDLFVBQVUsSUFBSSxLQUFLO0lBQ2xDLE9BQU87S0FDTCxNQUFNLEtBQUssTUFBTSxJQUFJLEtBQUssTUFBTSxRQUFRLElBQUksS0FBSyxNQUFNLFdBQVcsSUFBSSxLQUFLLE1BQU07S0FDakYsWUFBWTtJQUNkO0dBQ0Y7RUFDRixDQUFDLEdBQUcsS0FBSyxjQUFjLEtBQUssWUFBWSxLQUFLLElBQUksR0FBRyxLQUFLLGtCQUFrQixLQUFLLGdCQUFnQixLQUFLLElBQUksR0FBRyxLQUFLLGlCQUFpQixLQUFLLGVBQWUsS0FBSyxJQUFJO0VBQy9KLElBQUksSUFBSSxNQUFNLElBQUk7RUFDbEIsSUFBSSxLQUFLLE1BQU0sb0JBQW9CLEtBQUssTUFBTSxnQkFDNUMsSUFBSSxLQUFLLE1BQU0sa0JBQWtCLElBQUksS0FBSyxNQUFNO09BQzdDLElBQUksS0FBSyxNQUFNLG9CQUFvQixLQUFLLE1BQU0sZ0JBQ2pELElBQUksS0FBSyxNQUFNLGtCQUFrQixJQUFJLEtBQUssTUFBTTtPQUVoRCxNQUFNLElBQUksTUFBTSwrSUFBdUk7RUFDekosTUFBTSxDQUFDLEdBQUcsS0FBSyxHQUFHLEdBQUcsR0FBRyxFQUFFLE1BQU0sR0FBRyxJQUFJO0dBQ3JDLE9BQU87R0FDUCxrQkFBa0I7R0FDbEIsZ0JBQWdCO0dBQ2hCLGlCQUFpQjtHQUNqQixlQUFlO0dBQ2YsY0FBYztHQUNkLFVBQVU7R0FDVixnQkFBZ0I7R0FDaEIsWUFBWTtHQUNaLGNBQWM7R0FDZCxjQUFjO0dBQ2QsZUFBZTtFQUVqQixHQUFHLElBQUksR0FBRyxFQUFFLE9BQU8sRUFBRSxNQUFNLEdBQUcsRUFBRSxnQkFBZ0IsR0FBRyxRQUFRLEdBQUcsY0FBYyxHQUFHLFdBQVcsTUFBTSxHQUFHLEVBQUUsT0FBTyxFQUFFLFFBQVEsR0FBRyxFQUFFLGlCQUFpQixFQUFFLGVBQWUsRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFFLGlCQUFpQixFQUFFLFlBQVksRUFBRSxjQUFjLEVBQUUsY0FBYyxFQUFFLFVBQVUsRUFBRSxjQUFjLEVBQUUsWUFBWSxFQUFFLGVBQWUsRUFBRSxlQUFlO0VBQ2hVLEVBQUUsaUJBQWlCLEdBQUcsRUFBRSxTQUFTLEdBQUcsRUFBRSxlQUFlLEdBQUcsRUFBRSxZQUFZLEdBQUcsS0FBSyxRQUFRO0NBQ3hGO0NBQ0Esb0JBQW9CO0VBQ2xCLEtBQUssT0FBTyxLQUFLLEtBQUssR0FBRyxLQUFLLE1BQU0sa0JBQWtCLEtBQUssTUFBTSxlQUFlLGVBQWUsS0FBSyxNQUFNLGVBQWUsWUFBWSxJQUFJLEdBQUcsR0FBRyxZQUFZLElBQUk7Q0FDaks7Q0FDQSx1QkFBdUI7RUFDckIsS0FBSyxNQUFNLGtCQUFrQixLQUFLLE1BQU0sZUFBZSxlQUFlLEtBQUssTUFBTSxlQUFlLGVBQWUsSUFBSSxHQUFHLEdBQUcsZUFBZSxJQUFJO0NBQzlJO0NBQ0EsT0FBTyx5QkFBeUIsR0FBRyxHQUFHO0VBQ3BDLE1BQU0sRUFBRSxrQkFBa0IsR0FBRyxnQkFBZ0IsR0FBRyxPQUFPLEdBQUcsUUFBUSxNQUFNLEdBQUcsSUFBSTtHQUFFLE9BQU87R0FBRyxRQUFRO0VBQUUsR0FBRyxJQUFJLE1BQU0sRUFBRSxTQUFTLE1BQU0sRUFBRTtFQUNySSxJQUFJLEtBQUssR0FDUCxPQUFPLE9BQU8sR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQztPQUNyQyxJQUFJLEdBQUc7R0FDVixNQUFNLElBQUksR0FBRyxFQUFFLE9BQU8sRUFBRSxNQUFNO0dBQzlCLE9BQU8sT0FBTyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxpQkFBaUIsRUFBRSxlQUFlLEVBQUUsTUFBTSxFQUFFLFlBQVksRUFBRSxpQkFBaUIsRUFBRSxZQUFZLEVBQUUsY0FBYyxFQUFFLGNBQWMsRUFBRSxVQUFVLEVBQUUsY0FBYyxFQUFFLFlBQVksRUFBRSxlQUFlLEVBQUUsZUFBZSxDQUFDO0VBQ3ZPO0VBQ0EsT0FBTztDQUNUO0NBQ0EsbUJBQW1CLEdBQUcsR0FBRztFQUN2QixNQUFNLElBQUksS0FBSyxNQUFNLGlCQUFpQixLQUFLLE1BQU0sa0JBQWtCLElBQUksRUFBRSxpQkFBaUIsRUFBRTtFQUM1RixLQUFLLE1BQU0sVUFBVSxNQUFNLEtBQUssS0FBSyxNQUFNLE9BQU8sS0FBSyxtQkFBbUIsR0FBRyxLQUFLLGdCQUFnQixDQUFDLEdBQUcsS0FBSyxNQUFNLGtCQUFrQixLQUFLLE1BQU0sb0JBQW9CLEVBQUUsbUJBQW1CLEtBQUssTUFBTSxlQUFlLEtBQUssTUFBTSxpQkFBaUIsS0FBSyxNQUFNLGtCQUFrQixJQUFJLENBQUM7RUFDL1EsTUFBTSxJQUFJLEtBQUssTUFBTSxLQUFLLE1BQU0sU0FBUyxLQUFLLE1BQU0sbUJBQW1CLEtBQUssTUFBTSxtQkFBbUIsQ0FBQztFQUN0RyxDQUFDLEtBQUssTUFBTSxFQUFFLFNBQVMsRUFBRSxtQkFBbUIsRUFBRSxtQkFBbUIsQ0FBQyxNQUFNLEtBQUssS0FBSyxnQkFBZ0IsZUFBZSxPQUFPLEtBQUssZ0JBQWdCLGFBQWEsR0FBRyxLQUFLLGdCQUFnQixhQUFhO0NBQ2pNO0NBQ0EsUUFBUSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRztFQUN4QixJQUFJO0VBQ0osUUFBQSxHQUFPRCxtQkFBQUEsSUFBQUEsQ0FBRSxJQUFJO0dBQUUsaUJBQWlCO0dBQUcsZUFBZTtHQUFHLGFBQWE7R0FBRyxhQUFhLElBQUksS0FBSyxNQUFNLFdBQVcsT0FBTyxLQUFLLElBQUksRUFBRSxXQUFXO0dBQUcsU0FBUztHQUFHLFdBQVc7R0FBRyxRQUFRO0dBQUcsK0JBQStCLEtBQUssTUFBTTtFQUE4QixDQUFDO0NBQzVQO0NBQ0EsS0FBSyxHQUFHLEdBQUcsR0FBRztFQUNaLElBQUk7RUFDSixRQUFBLEdBQU9BLG1CQUFBQSxJQUFBQSxDQUFFLElBQUk7R0FBRSxRQUFRO0dBQUcsYUFBYTtHQUFHLGFBQWEsSUFBSSxLQUFLLE1BQU0sV0FBVyxPQUFPLEtBQUssSUFBSSxFQUFFLFdBQVc7R0FBRyxjQUFjO0dBQUcsZ0JBQWdCLEtBQUssTUFBTTtHQUFnQixZQUFZLEtBQUs7R0FBZ0Isa0JBQWtCLEtBQUs7R0FBc0Isa0NBQWtDLEtBQUssTUFBTTtHQUFrQyxtQkFBbUIsS0FBSztFQUF3QixDQUFDO0NBQzdYO0NBQ0EsTUFBTSxFQUFFLGlCQUFpQixHQUFHLGVBQWUsR0FBRyxhQUFhLEdBQUcsZ0JBQWdCLEdBQUcsV0FBVyxLQUFLO0VBQy9GLFFBQUEsR0FBT0EsbUJBQUFBLElBQUFBLENBQUUsSUFBSTtHQUFFLGlCQUFpQjtHQUFHLGVBQWU7R0FBRyxhQUFhO0dBQUcsZ0JBQWdCO0dBQUcsV0FBVztHQUFHLE9BQU8sS0FBSyxNQUFNO0dBQU8sUUFBUSxLQUFLLE1BQU07R0FBUSxNQUFNLEtBQUssTUFBTTtHQUFNLGNBQWMsS0FBSyxNQUFNLGdCQUFnQixLQUFLO0dBQUcsVUFBVSxLQUFLLE1BQU07R0FBVSxnQkFBZ0IsS0FBSyxNQUFNO0dBQWdCLGdCQUFnQixLQUFLLE1BQU07R0FBZ0IsU0FBUyxLQUFLLE1BQU07R0FBUyxXQUFXLEtBQUssTUFBTTtHQUFXLGlCQUFpQixLQUFLLE1BQU07R0FBaUIsV0FBVyxLQUFLLE1BQU07R0FBVyxxQkFBcUIsS0FBSyxNQUFNO0dBQXFCLFlBQVksS0FBSztHQUFZLFVBQVUsS0FBSztHQUFVLFVBQVUsS0FBSztHQUFVLG1CQUFtQixLQUFLO0dBQWlCLG1CQUFtQixLQUFLLE1BQU0sb0JBQW9CLEtBQUssdUJBQXVCLEtBQUs7R0FBRyxjQUFjLEtBQUs7R0FBYyxhQUFhLEtBQUs7R0FBYSxjQUFjLEtBQUssTUFBTTtHQUFjLFVBQVUsS0FBSyxNQUFNO0dBQVUsV0FBVyxLQUFLO0VBQWdCLENBQUM7Q0FDLzRCO0NBQ0EsUUFBUSxHQUFHLEdBQUc7RUFDWixNQUFNLEVBQUUsY0FBYyxNQUFNLEtBQUs7RUFDakMsT0FBTyxNQUFBLEdBQUtBLG1CQUFBQSxJQUFBQSxDQUFFLElBQUk7R0FBRSxRQUFRLEtBQUssTUFBTTtHQUFRLGVBQWUsS0FBSyxNQUFNO0dBQWUsTUFBTSxLQUFLLE1BQU07R0FBTSxPQUFPO0dBQUcsY0FBYztHQUFHLFFBQVE7RUFBRSxDQUFDO0NBQ3ZKO0NBQ0EsYUFBYSxHQUFHLEdBQUc7RUFDakIsTUFBTSxFQUFFLG1CQUFtQixNQUFNLEtBQUs7RUFDdEMsT0FBTyxNQUFBLEdBQUtBLG1CQUFBQSxJQUFBQSxDQUFFLElBQUk7R0FBRSxRQUFRLEtBQUssTUFBTTtHQUFRLE1BQU0sS0FBSyxNQUFNO0dBQU0sZUFBZSxLQUFLLE1BQU07R0FBZSxnQkFBZ0IsQ0FBQztHQUFHLE9BQU87R0FBRyxjQUFjO0dBQUcsUUFBUTtFQUFFLENBQUM7Q0FDM0s7Q0FDQSxrQkFBa0IsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0VBQ2pELElBQUksQ0FBQyxLQUFLLE1BQU0sVUFDZCxPQUFPO0VBQ1QsTUFBTSxJQUFJLE1BQU0sUUFBUSxLQUFLLE1BQU0sUUFBUSxJQUFJLEtBQUssTUFBTSxTQUFTLFFBQVEsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLE1BQU0sUUFBUSxHQUFHLElBQUk7R0FDL0csaUJBQWlCO0dBQ2pCLGVBQWU7R0FDZixhQUFhO0dBQ2Isa0JBQWtCO0dBQ2xCLGdCQUFnQjtHQUNoQixnQkFBZ0I7R0FDaEIsT0FBTyxLQUFLLE1BQU07R0FDbEIsUUFBUSxLQUFLLE1BQU07R0FDbkIsTUFBTSxLQUFLLE1BQU07R0FDakIsY0FBYztHQUNkLFdBQVc7R0FDWCxVQUFVLEtBQUssWUFBWTtHQUMzQixRQUFRO0dBQ1IsU0FBUztHQUNULFdBQVc7RUFDYjtFQUNBLE9BQUEsYUFBUyxTQUFTLElBQUksSUFBSSxNQUFNLEtBQUssaUJBQWlCLENBQUMsSUFBSSxPQUFBLGFBQVMsYUFBYSxHQUFHLENBQUMsQ0FBQztDQUN4RjtDQUNBLGNBQWM7RUFDWixPQUFPLEtBQUssTUFBTSxnQkFBZ0IsQ0FBQyxLQUFLLE1BQU0sV0FBVyxDQUFDLEtBQUssTUFBTSxZQUFZLElBQUksS0FBSyxNQUFNLFlBQVksQ0FBQztDQUMvRztDQUNBLGtCQUFrQjtFQUNoQixPQUFPLE1BQU0sUUFBUSxLQUFLLE1BQU0sUUFBUSxJQUFJLEtBQUssTUFBTSxTQUFTLFNBQVMsSUFBSSxDQUFDLENBQUMsS0FBSyxNQUFNO0NBQzVGO0NBQ0EsZUFBZSxHQUFHO0VBQ2hCLE9BQU8sS0FBSyxZQUFZLENBQUMsQ0FBQyxNQUFNLE1BQU0sTUFBTSxDQUFDO0NBQy9DO0NBQ0EsU0FBUztFQUNQLE1BQU0sRUFBRSxPQUFPLEdBQUcsUUFBUSxHQUFHLGNBQWMsR0FBRyxtQkFBbUIsR0FBRyxXQUFXLEdBQUcsaUJBQWlCLEdBQUcsUUFBUSxNQUFNLEtBQUssT0FBTyxFQUFFLGNBQWMsR0FBRyxjQUFjLEdBQUcsT0FBTyxHQUFHLGtCQUFrQixHQUFHLGdCQUFnQixHQUFHLGlCQUFpQixHQUFHLGVBQWUsTUFBTSxLQUFLO0VBQ3BRLElBQUksRUFBRSxnQkFBZ0IsR0FBRyxRQUFRLEdBQUcsY0FBYyxHQUFHLFdBQVcsTUFBTSxLQUFLO0VBQzNFLE1BQU0sSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEdBQUcsQ0FBQyxHQUFHLElBQUksR0FBRyxHQUFHLEdBQUcsQ0FBQztFQUM3QyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHO0dBQ2QsTUFBTSxLQUFLLEdBQUcsR0FBRyxHQUFHLEdBQUcsS0FBSyxNQUFNLGlCQUFpQixLQUFLLE1BQU0sZUFBZSxLQUFLLE1BQU0sTUFBTSxLQUFLLE1BQU0sWUFBWSxLQUFLLE1BQU0saUJBQWlCLEtBQUssTUFBTSxZQUFZLEtBQUssTUFBTSxjQUFjLEtBQUssTUFBTSxjQUFjLEtBQUssTUFBTSxVQUFVLEtBQUssTUFBTSxjQUFjLEtBQUssTUFBTSxZQUFZLEtBQUssTUFBTSxlQUFlLEtBQUssTUFBTSxlQUFlO0dBQ25WLElBQUksR0FBRyxnQkFBZ0IsSUFBSSxHQUFHLFFBQVEsSUFBSSxHQUFHLGNBQWMsSUFBSSxHQUFHO0VBQ3BFO0VBQ0EsTUFBTSxJQUFJLEVBQ1IsUUFBUSxHQUFHLEVBQUUsSUFDZjtFQUNBLFFBQUEsR0FBT0EsbUJBQUFBLElBQUFBLENBQUUsSUFBSTtHQUFFLGtCQUFrQjtHQUFHLGdCQUFnQjtHQUFHLGlCQUFpQjtHQUFHLGVBQWU7R0FBRyxhQUFhO0dBQUcsWUFBWSxLQUFLO0dBQVksY0FBYztHQUFHLGVBQWUsS0FBSyxNQUFNO0dBQU8sV0FBQSxHQUFVQSxtQkFBQUEsSUFBQUEsQ0FBRSxJQUFJLEVBQUUsV0FBQSxHQUFVQSxtQkFBQUEsSUFBQUEsQ0FBRSxJQUFJO0lBQUUsZ0JBQWdCLEtBQUs7SUFBaUIsV0FBVztJQUFHLGtCQUFrQixLQUFLLE1BQU07SUFBYyxtQkFBbUIsS0FBSyxNQUFNO0lBQW1CLFdBQUEsR0FBVUssbUJBQUFBLEtBQUFBLENBQUcsT0FBTztLQUFFLE9BQU8sS0FBSyxNQUFNO0tBQU8sS0FBSyxLQUFLO0tBQVcsV0FBVywyQkFBMkIsS0FBSyxNQUFNO0tBQWEsVUFBVSxDQUFDLEtBQUssY0FBYyxJQUFBLEdBQUdBLG1CQUFBQSxLQUFBQSxDQUFHLE9BQU87TUFBRSxPQUFPO01BQUcsV0FBVztNQUFhLFVBQVU7T0FBQyxJQUFJLElBQUksS0FBSyxRQUFRLEdBQUcsQ0FBQyxJQUFJO1FBQU1MLEdBQUFBLG1CQUFBQSxJQUFBQSxDQUFFLElBQUk7UUFBRSxXQUFXLEtBQUs7UUFBcUIsT0FBTztRQUFHLFFBQVE7UUFBRyxRQUFRLEtBQUs7UUFBWSxhQUFhLEtBQUs7UUFBaUIsaUJBQWlCLENBQUMsQ0FBQztRQUFHLFVBQVUsS0FBSztRQUFVLFdBQUEsR0FBVUssbUJBQUFBLEtBQUFBLENBQUcsSUFBSSxFQUFFLFVBQVU7U0FBQyxLQUFLLFFBQVEsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUM7U0FBRyxLQUFLLEtBQUssR0FBRyxHQUFHLENBQUM7U0FBRyxLQUFLLE1BQU07VUFDdjNCLGlCQUFpQjtVQUNqQixlQUFlO1VBQ2YsYUFBYTtVQUNiLGdCQUFnQjtVQUNoQixXQUFXO1NBQ2IsQ0FBQztTQUFHLEtBQUssa0JBQWtCLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQztRQUFDLEVBQUUsQ0FBQztPQUFFLENBQUM7T0FBRyxJQUFJLElBQUksS0FBSyxhQUFhLEdBQUcsQ0FBQyxJQUFJO01BQUk7S0FBRSxDQUFDLENBQUM7SUFBRSxDQUFDO0dBQUUsQ0FBQyxFQUFFLENBQUM7RUFBRSxDQUFDO0NBQzVIO0FBQ0Y7QUFDQSxPQUFPLGVBQWUsSUFBSSxrQkFBa0I7Q0FDMUMsWUFBWSxDQUFDO0NBQ2IsY0FBYyxDQUFDO0NBQ2YsVUFBVSxDQUFDO0NBQ1gsT0FBT0osaUJBQUFBLFFBQUc7QUFDWixDQUFDO0FBQ0QsT0FBTyxlQUFlLElBQUksZ0JBQWdCO0NBQ3hDLFlBQVksQ0FBQztDQUNiLGNBQWMsQ0FBQztDQUNmLFVBQVUsQ0FBQztDQUNYLE9BQU87RUFDTCxjQUFjO0VBQ2QsbUJBQW1CO0VBQ25CLFVBQVU7RUFFVixnQkFBZ0I7RUFDaEIsWUFBWTtFQUNaLGlCQUFpQjtFQUNqQixRQUFRO0VBQ1IsU0FBUztFQUVULFNBQVM7RUFFVCxnQkFBZ0I7RUFFaEIsZ0JBQWdCLENBQUM7RUFDakIsU0FBUyxDQUFDO0VBQ1YsV0FBVztFQUNYLGlCQUFpQixDQUFDO0VBQ2xCLFdBQVcsQ0FBQztFQUNaLFlBQVksQ0FBQztFQUNiLGlCQUFpQixDQUFDO0VBQ2xCLGtDQUFrQztFQUNsQyxZQUFZO0VBQ1osY0FBYztFQUNkLGFBQWE7RUFDYixjQUFjO0VBQ2QsZ0JBQWdCO0VBQ2hCLFlBQVk7RUFDWixlQUFlO0VBQ2YsbUJBQW1CO0VBQ25CLG1CQUFtQjtFQUNuQixRQUFRO0VBQ1IsK0JBQStCO0VBQy9CLHFCQUFxQjtFQUNyQixlQUFlO0VBQ2Ysa0JBQWtCO0VBQ2xCLGdCQUFnQjtFQUNoQixxQkFBcUIsQ0FBQztFQUN0QixPQUFPLENBQUM7RUFDUixXQUFXO0VBQ1gsTUFBTTtFQUNOLFdBQVc7RUFDWCxpQkFBaUIsQ0FDakI7RUFDQSxpQkFBaUIsQ0FDakI7RUFHQSxrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLGNBQWMsU0FBUyxHQUFHLEdBQUcsR0FBRztHQUM5QixFQUFFLEdBQUcsQ0FBQztFQUNSO0VBRUEsZ0JBQWdCO0VBQ2hCLFVBQVU7RUFDVixVQUFVO0NBQ1o7QUFDRixDQUFDO0FBQ0QsSUFBTSxNQUFNLE1BQU0sRUFBRSxZQUFZO0FBQ2hDLElBQU0sS0FBTixjQUFBLGFBQW1CLFVBQVU7Q0FDM0IsY0FBYztFQUNaLE1BQU0sR0FBRyxTQUFTLEdBQUcsT0FBTyxlQUFlLE1BQU0sZUFBZTtHQUM5RCxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxPQUFPO0VBQ1QsQ0FBQyxHQUFHLE9BQU8sZUFBZSxNQUFNLGFBQWE7R0FDM0MsWUFBWSxDQUFDO0dBQ2IsY0FBYyxDQUFDO0dBQ2YsVUFBVSxDQUFDO0dBQ1gsT0FBTztFQUNULENBQUM7Q0FDSDtDQUNBLG9CQUFvQjtFQUNsQixNQUFNLEVBQUUsYUFBYSxHQUFHLFdBQVcsTUFBTSxLQUFLLE1BQU0sZ0JBQWdCO0dBQ2xFLE1BQU0sR0FBRztHQUNULFVBQVUsS0FBSyxNQUFNO0dBQ3JCLFVBQVUsS0FBSyxNQUFNO0VBQ3ZCLENBQUM7RUFDRCxLQUFLLGNBQWMsR0FBRyxLQUFLLFlBQVk7Q0FDekM7Q0FDQSx1QkFBdUI7RUFDckIsS0FBSyxlQUFlLFNBQVMsS0FBSyxZQUFZLEdBQUcsS0FBSyxjQUFjO0NBQ3RFO0NBQ0EsbUJBQW1CLEdBQUc7RUFDcEIsSUFBSSxFQUFFLGFBQWEsS0FBSyxNQUFNLFlBQVksS0FBSyxXQUFXO0dBQ3hELE1BQU0sSUFBSSxLQUFLLFVBQVU7R0FDekIsS0FBSyxNQUFNLGFBQWE7SUFDdEIsR0FBRztJQUNILFVBQVUsS0FBSyxNQUFNO0dBQ3ZCLENBQUM7RUFDSDtDQUNGO0NBQ0EsU0FBUztFQUNQLE9BQU87Q0FDVDtBQUNGO0FBQ0EsT0FBTyxlQUFlLElBQUksZ0JBQWdCO0NBQ3hDLFlBQVksQ0FBQztDQUNiLGNBQWMsQ0FBQztDQUNmLFVBQVUsQ0FBQztDQUNYLE9BQU8sRUFDTCxVQUFVLElBRVo7QUFDRixDQUFDO0FBQ0QsSUFBTSxNQUFNLE9BQUEsR0FBTUQsbUJBQUFBLElBQUFBLENBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxpQkFBaUIsR0FBRyxjQUFjLFNBQUEsR0FBUUEsbUJBQUFBLElBQUFBLENBQUUsSUFBSTtDQUFFLGlCQUFpQjtDQUFHLGNBQWM7Q0FBRyxHQUFHO0FBQUUsQ0FBQyxFQUFFLENBQUM7QUFDdkksR0FBRyxjQUFjO0FBQ2pCLElBQU0sS0FBTixjQUFpQkcsYUFBQUEsVUFBRztDQUNsQixjQUFjO0VBQ1osTUFBTSxHQUFHLFNBQVMsR0FBRyxPQUFPLGVBQWUsTUFBTSxlQUFlO0dBQzlELFlBQVksQ0FBQztHQUNiLGNBQWMsQ0FBQztHQUNmLFVBQVUsQ0FBQztHQUNYLE9BQU87RUFDVCxDQUFDLEdBQUcsT0FBTyxlQUFlLE1BQU0sYUFBYTtHQUMzQyxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxPQUFPO0VBQ1QsQ0FBQztDQUNIO0NBQ0EsbUJBQW1CLEdBQUc7RUFDcEIsSUFBSSxFQUFFLFNBQVMsS0FBSyxNQUFNLFFBQVEsS0FBSyxXQUFXO0dBQ2hELE1BQU0sSUFBSSxLQUFLLFVBQVU7R0FDekIsS0FBSyxNQUFNLGFBQWE7SUFBRSxHQUFHO0lBQUcsTUFBTSxLQUFLLE1BQU07R0FBSyxDQUFDO0VBQ3pEO0NBQ0Y7Q0FDQSxvQkFBb0I7RUFDbEIsTUFBTSxFQUFFLGFBQWEsR0FBRyxXQUFXLE1BQU0sS0FBSyxNQUFNLGdCQUFnQjtHQUNsRSxNQUFNLEdBQUc7R0FDVCxVQUFVLEtBQUssTUFBTTtHQUNyQixNQUFNLEtBQUssTUFBTTtFQUNuQixDQUFDO0VBQ0QsS0FBSyxjQUFjLEdBQUcsS0FBSyxZQUFZO0NBQ3pDO0NBQ0EsdUJBQXVCO0VBQ3JCLEtBQUssZUFBZSxTQUFTLEtBQUssWUFBWSxHQUFHLEtBQUssY0FBYztDQUN0RTtDQUNBLFNBQVM7RUFDUCxPQUFPO0NBQ1Q7QUFDRjtBQUNBLElBQU0sTUFBTSxPQUFBLEdBQU1ILG1CQUFBQSxJQUFBQSxDQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsaUJBQWlCLEdBQUcsY0FBYyxTQUFBLEdBQVFBLG1CQUFBQSxJQUFBQSxDQUFFLElBQUk7Q0FBRSxpQkFBaUI7Q0FBRyxjQUFjO0NBQUcsR0FBRztBQUFFLENBQUMsRUFBRSxDQUFDO0FBQ3ZJLEdBQUcsY0FBYztBQUNqQixJQUFNLEtBQU4sY0FBaUJHLGFBQUFBLFVBQUc7Q0FDbEIsY0FBYztFQUNaLE1BQU0sR0FBRyxTQUFTLEdBQUcsT0FBTyxlQUFlLE1BQU0sZUFBZTtHQUM5RCxZQUFZLENBQUM7R0FDYixjQUFjLENBQUM7R0FDZixVQUFVLENBQUM7R0FDWCxPQUFPO0VBQ1QsQ0FBQztDQUNIO0NBQ0Esb0JBQW9CO0VBQ2xCLE1BQU0sRUFBRSxhQUFhLE1BQU0sS0FBSyxNQUFNLGdCQUFnQjtHQUNwRCxNQUFNLEdBQUc7R0FDVCxVQUFVLEtBQUssTUFBTTtFQUN2QixDQUFDO0VBQ0QsS0FBSyxjQUFjO0NBQ3JCO0NBQ0EsdUJBQXVCO0VBQ3JCLEtBQUssZUFBZSxTQUFTLEtBQUssWUFBWSxHQUFHLEtBQUssY0FBYztDQUN0RTtDQUNBLFNBQVM7RUFDUCxPQUFPO0NBQ1Q7QUFDRjtBQUNBLElBQU0sTUFBTSxPQUFBLEdBQU1ILG1CQUFBQSxJQUFBQSxDQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsaUJBQWlCLFNBQUEsR0FBUUEsbUJBQUFBLElBQUFBLENBQUUsSUFBSTtDQUFFLGlCQUFpQjtDQUFHLEdBQUc7QUFBRSxDQUFDLEVBQUUsQ0FBQztBQUNyRyxHQUFHLGNBQWMiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxXX0=
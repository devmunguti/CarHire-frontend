import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/bookings/BookingWizard.tsx");const useCallback = __vite__cjsImport2_react["useCallback"]; const useEffect = __vite__cjsImport2_react["useEffect"]; const useMemo = __vite__cjsImport2_react["useMemo"]; const useState = __vite__cjsImport2_react["useState"];const _jsxDEV = __vite__cjsImport14_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport14_react_jsxDevRuntime["Fragment"];import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=8b23c0c4";
import { useMutation } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=8b23c0c4";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=8b23c0c4";
import { Controller, useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=8b23c0c4";
import { useNavigate, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=8b23c0c4";
import { z } from "/node_modules/.vite/deps/zod.js?v=8b23c0c4";
import { ApiError, apiClient } from "/src/api/client.ts";
import { useAvailableVehicles, useCreateBooking } from "/src/api/queries.ts";
import { Button, DateTimeRangePicker, Input, PhoneInput, Select, Stepper } from "/src/components/ui/index.ts";
import { useAuth } from "/src/hooks/AuthContext.tsx";
import { t } from "/src/i18n/index.ts";
import { formatEat, formatKes, isKenyanPhone, normalisePhone } from "/src/lib/index.ts";
import { QuoteBuilder, QuoteBreakdown } from "/src/features/bookings/QuoteBuilder.tsx";
import { PaymentStatus } from "/src/features/bookings/PaymentStatus.tsx";
var _jsxFileName = "C:/CarHire/Frontend/src/features/bookings/BookingWizard.tsx";
import __vite__cjsImport14_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b23c0c4";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const customerSchema = z.object({
	customerName: z.string().trim().min(2, t("booking.stepRequired")),
	customerPhone: z.string().refine(isKenyanPhone, t("booking.phoneInvalid")),
	customerEmail: z.string().trim().email(t("auth.emailInvalid")),
	customerIdNumber: z.string().trim().min(4, t("booking.stepRequired"))
});
function VehiclePrice({ vehicle, request, onSelect, selected }) {
	_s();
	const [quote, setQuote] = useState(null);
	const { mutateAsync } = useMutation({ mutationFn: (payload) => apiClient.post("/quotes/calculate", payload) });
	const requestKey = JSON.stringify(request);
	const payload = useMemo(() => ({
		...JSON.parse(requestKey),
		vehicleId: vehicle.id
	}), [requestKey, vehicle.id]);
	useEffect(() => {
		let active = true;
		void mutateAsync(payload).then((result) => {
			if (active) setQuote(result);
		}).catch(() => {
			if (active) setQuote(null);
		});
		return () => {
			active = false;
		};
	}, [mutateAsync, payload]);
	return /* @__PURE__ */ _jsxDEV("button", {
		"aria-pressed": selected,
		className: `vehicle-choice${selected ? " is-selected" : ""}`,
		onClick: onSelect,
		type: "button",
		children: [/* @__PURE__ */ _jsxDEV("span", {
			className: "vehicle-choice__details",
			children: [/* @__PURE__ */ _jsxDEV("b", { children: [
				vehicle.make,
				" ",
				vehicle.model
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 49
			}, this), /* @__PURE__ */ _jsxDEV("small", { children: [
				vehicle.registration,
				" · ",
				vehicle.seats,
				" ",
				t("styleguide.seats")
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 86
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 44,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("span", {
			className: "vehicle-choice__price",
			children: quote ? formatKes(quote.pricingSnapshot.totalDueKes) : t("booking.calculating")
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 45,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 43,
		columnNumber: 5
	}, this);
}
_s(VehiclePrice, "1qG0wE7bUv0XZJ+3roGgtlxe8mY=", false, function() {
	return [useMutation];
});
_c = VehiclePrice;
export function BookingWizard() {
	_s2();
	const navigate = useNavigate();
	const [searchParams] = useSearchParams();
	const { user } = useAuth();
	const [step, setStep] = useState(0);
	const [mode, setMode] = useState("self_drive");
	const [paymentMethod, setPaymentMethod] = useState("mpesa_online");
	const [request, setRequest] = useState(() => ({
		vehicleId: searchParams.get("vehicleId") ?? "",
		pickupAt: searchParams.get("pickupAt") ?? "",
		returnAt: searchParams.get("returnAt") ?? "",
		pickupLocation: "",
		mode: "self_drive",
		extras: []
	}));
	const [quote, setQuote] = useState(null);
	const [conflict, setConflict] = useState(false);
	const [paymentBooking, setPaymentBooking] = useState(null);
	const [dateError, setDateError] = useState(null);
	const form = useForm({
		resolver: zodResolver(customerSchema),
		mode: "onTouched",
		defaultValues: {
			customerName: "",
			customerPhone: "",
			customerEmail: "",
			customerIdNumber: ""
		}
	});
	const availableVehicles = useAvailableVehicles(request.pickupAt, request.returnAt);
	const createBooking = useCreateBooking();
	const handleQuoteChange = useCallback((value) => setQuote(value), []);
	const handleRequestChange = useCallback((value) => {
		setRequest(value);
		setMode(value.mode);
		setConflict(false);
	}, []);
	async function validateStep() {
		if (step === 0) return form.trigger();
		if (step === 1) {
			if (!request.pickupAt || !request.returnAt || !request.pickupLocation.trim()) return false;
			if (Date.parse(request.pickupAt) < Date.now()) {
				setDateError("booking.pickupPast");
				return false;
			}
			if (Date.parse(request.returnAt) <= Date.parse(request.pickupAt)) {
				setDateError("booking.returnAfterPickup");
				return false;
			}
			setDateError(null);
			return true;
		}
		if (step === 2) return Boolean(request.vehicleId);
		if (step === 3) return Boolean(quote);
		return true;
	}
	async function continueStep() {
		if (step === 4) {
			await form.handleSubmit(async (customer) => {
				if (!quote || !request.vehicleId) return;
				try {
					const booking = await createBooking.mutateAsync({
						...request,
						...customer,
						customerPhone: normalisePhone(customer.customerPhone),
						paymentMethod,
						createdById: user?.id ?? ""
					});
					if (paymentMethod === "mpesa_online") setPaymentBooking(booking);
					else navigate(`/admin/bookings/${booking.id}`);
				} catch (error) {
					if (error instanceof ApiError && error.status === 409) {
						setConflict(true);
						await availableVehicles.refetch();
					}
				}
			})();
			return;
		}
		if (await validateStep()) setStep((current) => Math.min(4, current + 1));
	}
	const updateDates = (range) => {
		setRequest((current) => ({
			...current,
			pickupAt: range.startUtc,
			returnAt: range.endUtc
		}));
		setConflict(false);
		setDateError(null);
	};
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "booking-wizard",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "booking-wizard__header",
				children: [/* @__PURE__ */ _jsxDEV("p", { children: t("booking.listTitle") }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 134,
					columnNumber: 50
				}, this), /* @__PURE__ */ _jsxDEV("h2", { children: t("booking.createFirst") }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 134,
					columnNumber: 81
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 134,
				columnNumber: 7
			}, this),
			!paymentBooking && /* @__PURE__ */ _jsxDEV(Stepper, {
				activeStep: step,
				steps: [
					t("booking.steps.customer"),
					t("booking.steps.dates"),
					t("booking.steps.vehicle"),
					t("booking.steps.extras"),
					t("booking.steps.review")
				]
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 135,
				columnNumber: 27
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "booking-wizard__body",
				children: [paymentBooking && /* @__PURE__ */ _jsxDEV("div", {
					className: "booking-payment-step",
					children: [
						/* @__PURE__ */ _jsxDEV("h3", { children: "Reservation created" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 142,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: "Complete the M-Pesa request to confirm this booking." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 143,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(PaymentStatus, {
							amountDueKes: paymentBooking.totalKes,
							bookingId: paymentBooking.id,
							initialPhone: normalisePhone(form.getValues("customerPhone")),
							onConfirmed: () => navigate(`/admin/bookings/${paymentBooking.id}`)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 141,
					columnNumber: 28
				}, this), !paymentBooking && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
					step === 0 && /* @__PURE__ */ _jsxDEV("div", {
						className: "booking-form-grid",
						children: [
							/* @__PURE__ */ _jsxDEV(Input, {
								error: form.formState.errors.customerName?.message,
								label: t("booking.customerName"),
								...form.register("customerName")
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 153,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV(Controller, {
								control: form.control,
								name: "customerPhone",
								render: ({ field }) => /* @__PURE__ */ _jsxDEV(PhoneInput, {
									error: form.formState.errors.customerPhone?.message,
									label: t("booking.customerPhone"),
									onChange: field.onChange,
									value: field.value
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 154,
									columnNumber: 90
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 154,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV(Input, {
								error: form.formState.errors.customerEmail?.message,
								label: t("booking.customerEmail"),
								type: "email",
								...form.register("customerEmail")
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 155,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV(Input, {
								error: form.formState.errors.customerIdNumber?.message,
								label: t("booking.customerId"),
								...form.register("customerIdNumber")
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 156,
								columnNumber: 11
							}, this),
							mode === "self_drive" && /* @__PURE__ */ _jsxDEV("label", {
								className: "field",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "field__label",
									children: t("booking.uploadLicence")
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 157,
									columnNumber: 62
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									accept: "image/*,.pdf",
									className: "control",
									type: "file"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 157,
									columnNumber: 128
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 157,
								columnNumber: 37
							}, this),
							/* @__PURE__ */ _jsxDEV("label", {
								className: "field",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "field__label",
									children: t("booking.uploadId")
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 158,
									columnNumber: 36
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									accept: "image/*,.pdf",
									className: "control",
									type: "file"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 158,
									columnNumber: 97
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 158,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 152,
						columnNumber: 24
					}, this),
					step === 1 && /* @__PURE__ */ _jsxDEV("div", {
						className: "booking-date-step",
						children: [
							/* @__PURE__ */ _jsxDEV(DateTimeRangePicker, {
								endUtc: request.returnAt,
								label: t("booking.dateRange"),
								onChange: updateDates,
								startUtc: request.pickupAt
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 162,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV(Input, {
								label: t("booking.pickupLocation"),
								onChange: (event) => setRequest((current) => ({
									...current,
									pickupLocation: event.target.value
								})),
								placeholder: t("booking.pickupPlaceholder"),
								value: request.pickupLocation
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 163,
								columnNumber: 11
							}, this),
							dateError && /* @__PURE__ */ _jsxDEV("p", {
								className: "field__error",
								role: "alert",
								children: t(dateError)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 164,
								columnNumber: 25
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 161,
						columnNumber: 24
					}, this),
					step === 2 && /* @__PURE__ */ _jsxDEV("div", {
						className: "vehicle-picker-step",
						children: [
							/* @__PURE__ */ _jsxDEV("h3", { children: t("booking.availableVehicles") }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 168,
								columnNumber: 11
							}, this),
							availableVehicles.isLoading && /* @__PURE__ */ _jsxDEV("div", {
								className: "vehicle-choice-list",
								children: [/* @__PURE__ */ _jsxDEV("span", { className: "skeleton" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 169,
									columnNumber: 80
								}, this), /* @__PURE__ */ _jsxDEV("span", { className: "skeleton" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 169,
									columnNumber: 109
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 169,
								columnNumber: 43
							}, this),
							availableVehicles.isError && /* @__PURE__ */ _jsxDEV("p", {
								className: "field__error",
								role: "alert",
								children: t("booking.actionError")
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 170,
								columnNumber: 41
							}, this),
							availableVehicles.data?.length === 0 && /* @__PURE__ */ _jsxDEV("p", { children: t("booking.noAvailableVehicles") }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 171,
								columnNumber: 52
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "vehicle-choice-list",
								children: (availableVehicles.data ?? []).map((vehicle) => /* @__PURE__ */ _jsxDEV(VehiclePrice, {
									onSelect: () => setRequest((current) => ({
										...current,
										vehicleId: vehicle.id
									})),
									request,
									selected: request.vehicleId === vehicle.id,
									vehicle
								}, vehicle.id, false, {
									fileName: _jsxFileName,
									lineNumber: 173,
									columnNumber: 62
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 172,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 167,
						columnNumber: 24
					}, this),
					step === 3 && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(QuoteBuilder, {
						onChange: handleRequestChange,
						onQuoteChange: handleQuoteChange,
						request,
						showDates: false,
						showPickupLocation: false
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 178,
						columnNumber: 11
					}, this), conflict && /* @__PURE__ */ _jsxDEV("p", {
						className: "quote-conflict",
						role: "alert",
						children: t("booking.reserveConflict")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 179,
						columnNumber: 24
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 177,
						columnNumber: 24
					}, this),
					step === 4 && /* @__PURE__ */ _jsxDEV("div", {
						className: "booking-review",
						children: [
							/* @__PURE__ */ _jsxDEV("section", { children: [/* @__PURE__ */ _jsxDEV("h3", { children: t("booking.review") }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 183,
								columnNumber: 20
							}, this), /* @__PURE__ */ _jsxDEV("dl", {
								className: "booking-review__customer",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: t("booking.customerName") }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 184,
										columnNumber: 18
									}, this), /* @__PURE__ */ _jsxDEV("dd", { children: form.getValues("customerName") }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 184,
										columnNumber: 54
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 184,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: t("booking.customerPhone") }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 185,
										columnNumber: 18
									}, this), /* @__PURE__ */ _jsxDEV("dd", { children: normalisePhone(form.getValues("customerPhone")) }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 185,
										columnNumber: 55
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 185,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: t("booking.customerEmail") }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 186,
										columnNumber: 18
									}, this), /* @__PURE__ */ _jsxDEV("dd", { children: form.getValues("customerEmail") }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 186,
										columnNumber: 55
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 186,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: t("booking.pickup") }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 187,
										columnNumber: 18
									}, this), /* @__PURE__ */ _jsxDEV("dd", { children: request.pickupAt ? formatEat(request.pickupAt) : "—" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 187,
										columnNumber: 48
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 187,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: t("booking.return") }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 188,
										columnNumber: 18
									}, this), /* @__PURE__ */ _jsxDEV("dd", { children: request.returnAt ? formatEat(request.returnAt) : "—" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 188,
										columnNumber: 48
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 188,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 183,
								columnNumber: 50
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 183,
								columnNumber: 11
							}, this),
							quote && /* @__PURE__ */ _jsxDEV(QuoteBreakdown, { quote }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 190,
								columnNumber: 21
							}, this),
							/* @__PURE__ */ _jsxDEV(Select, {
								label: t("booking.paymentMethod"),
								onChange: (event) => setPaymentMethod(event.target.value),
								options: [
									{
										value: "mpesa_online",
										label: t("booking.mpesaOnline")
									},
									{
										value: "mpesa_manual",
										label: t("booking.mpesaManual")
									},
									{
										value: "cash",
										label: t("booking.cash")
									},
									{
										value: "bank",
										label: t("booking.bank")
									},
									{
										value: "corporate",
										label: t("booking.corporate")
									}
								],
								value: paymentMethod
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 191,
								columnNumber: 11
							}, this),
							conflict && /* @__PURE__ */ _jsxDEV("p", {
								className: "quote-conflict",
								role: "alert",
								children: t("booking.reserveConflict")
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 195,
								columnNumber: 24
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 182,
						columnNumber: 24
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 151,
					columnNumber: 29
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 140,
				columnNumber: 7
			}, this),
			!paymentBooking && /* @__PURE__ */ _jsxDEV("footer", {
				className: "booking-wizard__actions",
				children: [/* @__PURE__ */ _jsxDEV(Button, {
					disabled: step === 0,
					onClick: () => setStep((current) => Math.max(0, current - 1)),
					variant: "secondary",
					children: t("booking.back")
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 201,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV(Button, {
					disabled: createBooking.isPending || availableVehicles.isLoading || step >= 3 && !quote,
					onClick: () => void continueStep(),
					children: step === 4 ? t(createBooking.isPending ? "booking.calculating" : "booking.create") : t("booking.next")
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 202,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 200,
				columnNumber: 27
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 133,
		columnNumber: 5
	}, this);
}
_s2(BookingWizard, "hV6rnf1TrNaeYEu7+jfYwzdQkZ8=", false, function() {
	return [
		useNavigate,
		useSearchParams,
		useAuth,
		useForm,
		useAvailableVehicles,
		useCreateBooking
	];
});
_c2 = BookingWizard;
var _c, _c2;
$RefreshReg$(_c, "VehiclePrice");
$RefreshReg$(_c2, "BookingWizard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/bookings/BookingWizard.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/CarHire/Frontend/src/features/bookings/BookingWizard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/CarHire/Frontend/src/features/bookings/BookingWizard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/CarHire/Frontend/src/features/bookings/BookingWizard.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxhQUFhLFdBQVcsU0FBUyxnQkFBZ0I7QUFDMUQsU0FBUyxZQUFZLGVBQWU7QUFDcEMsU0FBUyxhQUFhLHVCQUF1QjtBQUM3QyxTQUFTLFNBQVM7QUFDbEIsU0FBUyxVQUFVLGlCQUFpQjtBQUNwQyxTQUFTLHNCQUFzQix3QkFBd0I7QUFFdkQsU0FBUyxRQUFRLHFCQUFxQixPQUFPLFlBQVksUUFBUSxlQUFlO0FBQ2hGLFNBQVMsZUFBZTtBQUN4QixTQUFTLFNBQVM7QUFDbEIsU0FBUyxXQUFXLFdBQVcsZUFBZSxzQkFBc0I7QUFDcEUsU0FBUyxjQUFjLHNCQUFzQjtBQUM3QyxTQUFTLHFCQUFxQjs7OztBQUU5QixNQUFNLGlCQUFpQixFQUFFLE9BQU87Q0FDOUIsY0FBYyxFQUFFLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksR0FBRyxFQUFFLHNCQUFzQixDQUFDO0NBQ2hFLGVBQWUsRUFBRSxPQUFPLENBQUMsQ0FBQyxPQUFPLGVBQWUsRUFBRSxzQkFBc0IsQ0FBQztDQUN6RSxlQUFlLEVBQUUsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxFQUFFLG1CQUFtQixDQUFDO0NBQzdELGtCQUFrQixFQUFFLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksR0FBRyxFQUFFLHNCQUFzQixDQUFDO0FBQ3RFLENBQUM7QUFJRCxTQUFTLGFBQWEsRUFBRSxTQUFTLFNBQVMsVUFBVSxZQUFrRzs7Q0FDcEosTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUErQixJQUFJO0NBQzdELE1BQU0sRUFBRSxnQkFBZ0IsWUFBWSxFQUFFLGFBQWEsWUFBMEIsVUFBVSxLQUFvQixxQkFBcUIsT0FBTyxFQUFFLENBQUM7Q0FDMUksTUFBTSxhQUFhLEtBQUssVUFBVSxPQUFPO0NBQ3pDLE1BQU0sVUFBVSxlQUFlO0VBQUUsR0FBRyxLQUFLLE1BQU0sVUFBVTtFQUFtQixXQUFXLFFBQVE7Q0FBRyxJQUFJLENBQUMsWUFBWSxRQUFRLEVBQUUsQ0FBQztDQUU5SCxnQkFBZ0I7RUFDZCxJQUFJLFNBQVM7RUFDYixLQUFLLFlBQVksT0FBTyxDQUFDLENBQUMsTUFBTSxXQUFXO0dBQ3pDLElBQUksUUFBUSxTQUFTLE1BQU07RUFDN0IsQ0FBQyxDQUFDLENBQUMsWUFBWTtHQUNiLElBQUksUUFBUSxTQUFTLElBQUk7RUFDM0IsQ0FBQztFQUNELGFBQWE7R0FBRSxTQUFTO0VBQU07Q0FDaEMsR0FBRyxDQUFDLGFBQWEsT0FBTyxDQUFDO0NBRXpCLE9BQ0Usd0JBQUMsVUFBRDtFQUFRLGdCQUFjO0VBQVUsV0FBVyxpQkFBaUIsV0FBVyxpQkFBaUI7RUFBTSxTQUFTO0VBQVUsTUFBSztZQUF0SCxDQUNFLHdCQUFDLFFBQUQ7R0FBTSxXQUFVO2FBQWhCLENBQTBDLHdCQUFDLEtBQUQ7SUFBSSxRQUFRO0lBQUs7SUFBRSxRQUFRO0dBQVM7Ozs7YUFBQyx3QkFBQyxTQUFEO0lBQVEsUUFBUTtJQUFhO0lBQUksUUFBUTtJQUFNO0lBQUUsRUFBRSxrQkFBa0I7R0FBUzs7OztXQUFPOzs7OztZQUNwSyx3QkFBQyxRQUFEO0dBQU0sV0FBVTthQUF5QixRQUFRLFVBQVUsTUFBTSxnQkFBZ0IsV0FBVyxJQUFJLEVBQUUscUJBQXFCO0VBQVE7Ozs7VUFDekg7Ozs7OztBQUVaOzs7OztBQUVBLE9BQU8sU0FBUyxnQkFBZ0I7O0NBQzlCLE1BQU0sV0FBVyxZQUFZO0NBQzdCLE1BQU0sQ0FBQyxnQkFBZ0IsZ0JBQWdCO0NBQ3ZDLE1BQU0sRUFBRSxTQUFTLFFBQVE7Q0FDekIsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLENBQUM7Q0FDbEMsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFvQixZQUFZO0NBQ3hELE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUEwRSxjQUFjO0NBQ2xJLE1BQU0sQ0FBQyxTQUFTLGNBQWMsZ0JBQThCO0VBQzFELFdBQVcsYUFBYSxJQUFJLFdBQVcsS0FBSztFQUM1QyxVQUFVLGFBQWEsSUFBSSxVQUFVLEtBQUs7RUFDMUMsVUFBVSxhQUFhLElBQUksVUFBVSxLQUFLO0VBQzFDLGdCQUFnQjtFQUNoQixNQUFNO0VBQ04sUUFBUSxDQUFDO0NBQ1gsRUFBRTtDQUNGLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBK0IsSUFBSTtDQUM3RCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsS0FBSztDQUM5QyxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUF5QixJQUFJO0NBQ3pFLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUF3QixJQUFJO0NBQzlELE1BQU0sT0FBTyxRQUF3QjtFQUFFLFVBQVUsWUFBWSxjQUFjO0VBQUcsTUFBTTtFQUFhLGVBQWU7R0FBRSxjQUFjO0dBQUksZUFBZTtHQUFJLGVBQWU7R0FBSSxrQkFBa0I7RUFBRztDQUFFLENBQUM7Q0FDbE0sTUFBTSxvQkFBb0IscUJBQXFCLFFBQVEsVUFBVSxRQUFRLFFBQVE7Q0FDakYsTUFBTSxnQkFBZ0IsaUJBQWlCO0NBRXZDLE1BQU0sb0JBQW9CLGFBQWEsVUFBZ0MsU0FBUyxLQUFLLEdBQUcsQ0FBQyxDQUFDO0NBQzFGLE1BQU0sc0JBQXNCLGFBQWEsVUFBd0I7RUFDL0QsV0FBVyxLQUFLO0VBQ2hCLFFBQVEsTUFBTSxJQUFJO0VBQ2xCLFlBQVksS0FBSztDQUNuQixHQUFHLENBQUMsQ0FBQztDQUVMLGVBQWUsZUFBZTtFQUM1QixJQUFJLFNBQVMsR0FBRyxPQUFPLEtBQUssUUFBUTtFQUNwQyxJQUFJLFNBQVMsR0FBRztHQUNkLElBQUksQ0FBQyxRQUFRLFlBQVksQ0FBQyxRQUFRLFlBQVksQ0FBQyxRQUFRLGVBQWUsS0FBSyxHQUFHLE9BQU87R0FDckYsSUFBSSxLQUFLLE1BQU0sUUFBUSxRQUFRLElBQUksS0FBSyxJQUFJLEdBQUc7SUFDN0MsYUFBYSxvQkFBb0I7SUFDakMsT0FBTztHQUNUO0dBQ0EsSUFBSSxLQUFLLE1BQU0sUUFBUSxRQUFRLEtBQUssS0FBSyxNQUFNLFFBQVEsUUFBUSxHQUFHO0lBQ2hFLGFBQWEsMkJBQTJCO0lBQ3hDLE9BQU87R0FDVDtHQUNBLGFBQWEsSUFBSTtHQUNqQixPQUFPO0VBQ1Q7RUFDQSxJQUFJLFNBQVMsR0FBRyxPQUFPLFFBQVEsUUFBUSxTQUFTO0VBQ2hELElBQUksU0FBUyxHQUFHLE9BQU8sUUFBUSxLQUFLO0VBQ3BDLE9BQU87Q0FDVDtDQUVBLGVBQWUsZUFBZTtFQUM1QixJQUFJLFNBQVMsR0FBRztHQUNkLE1BQU0sS0FBSyxhQUFhLE9BQU8sYUFBYTtJQUMxQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsV0FBVztJQUNsQyxJQUFJO0tBQ0YsTUFBTSxVQUFVLE1BQU0sY0FBYyxZQUFZO01BQzlDLEdBQUc7TUFDSCxHQUFHO01BQ0gsZUFBZSxlQUFlLFNBQVMsYUFBYTtNQUNwRDtNQUNBLGFBQWEsTUFBTSxNQUFNO0tBQzNCLENBQUM7S0FDRCxJQUFJLGtCQUFrQixnQkFBZ0Isa0JBQWtCLE9BQU87VUFDMUQsU0FBUyxtQkFBbUIsUUFBUSxJQUFJO0lBQy9DLFNBQVMsT0FBTztLQUNkLElBQUksaUJBQWlCLFlBQVksTUFBTSxXQUFXLEtBQUs7TUFDckQsWUFBWSxJQUFJO01BQ2hCLE1BQU0sa0JBQWtCLFFBQVE7S0FDbEM7SUFDRjtHQUNGLENBQUMsQ0FBQyxDQUFDO0dBQ0g7RUFDRjtFQUNBLElBQUksTUFBTSxhQUFhLEdBQUcsU0FBUyxZQUFZLEtBQUssSUFBSSxHQUFHLFVBQVUsQ0FBQyxDQUFDO0NBQ3pFO0NBRUEsTUFBTSxlQUFlLFVBQWdEO0VBQ25FLFlBQVksYUFBYTtHQUFFLEdBQUc7R0FBUyxVQUFVLE1BQU07R0FBVSxVQUFVLE1BQU07RUFBTyxFQUFFO0VBQzFGLFlBQVksS0FBSztFQUNqQixhQUFhLElBQUk7Q0FDbkI7Q0FFQSxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQW5CO0dBQ0Usd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FBbEIsQ0FBMkMsd0JBQUMsS0FBRCxZQUFJLEVBQUUsbUJBQW1CLEVBQUs7Ozs7Y0FBQyx3QkFBQyxNQUFELFlBQUssRUFBRSxxQkFBcUIsRUFBTTs7OztZQUFTOzs7Ozs7R0FDcEgsQ0FBQyxrQkFBa0Isd0JBQUMsU0FBRDtJQUFTLFlBQVk7SUFBTSxPQUFPO0tBQ3BELEVBQUUsd0JBQXdCO0tBQUcsRUFBRSxxQkFBcUI7S0FBRyxFQUFFLHVCQUF1QjtLQUNoRixFQUFFLHNCQUFzQjtLQUFHLEVBQUUsc0JBQXNCO0lBQ3JEO0dBQUk7Ozs7O0dBRUosd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNHLGtCQUFrQix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ2pCLHdCQUFDLE1BQUQsWUFBSSxzQkFBdUI7Ozs7O01BQzNCLHdCQUFDLEtBQUQsWUFBRyx1REFBdUQ7Ozs7O01BQzFELHdCQUFDLGVBQUQ7T0FDRSxjQUFjLGVBQWU7T0FDN0IsV0FBVyxlQUFlO09BQzFCLGNBQWMsZUFBZSxLQUFLLFVBQVUsZUFBZSxDQUFDO09BQzVELG1CQUFtQixTQUFTLG1CQUFtQixlQUFlLElBQUk7TUFDbkU7Ozs7O0tBQ0U7Ozs7O2NBQ0osQ0FBQyxrQkFBa0I7S0FDbkIsU0FBUyxLQUFLLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ2Isd0JBQUMsT0FBRDtRQUFPLE9BQU8sS0FBSyxVQUFVLE9BQU8sY0FBYztRQUFTLE9BQU8sRUFBRSxzQkFBc0I7UUFBRyxHQUFJLEtBQUssU0FBUyxjQUFjO09BQUk7Ozs7O09BQ2pJLHdCQUFDLFlBQUQ7UUFBWSxTQUFTLEtBQUs7UUFBUyxNQUFLO1FBQWdCLFNBQVMsRUFBRSxZQUFZLHdCQUFDLFlBQUQ7U0FBWSxPQUFPLEtBQUssVUFBVSxPQUFPLGVBQWU7U0FBUyxPQUFPLEVBQUUsdUJBQXVCO1NBQUcsVUFBVSxNQUFNO1NBQVUsT0FBTyxNQUFNO1FBQVE7Ozs7O09BQUk7Ozs7O09BQ3RPLHdCQUFDLE9BQUQ7UUFBTyxPQUFPLEtBQUssVUFBVSxPQUFPLGVBQWU7UUFBUyxPQUFPLEVBQUUsdUJBQXVCO1FBQUcsTUFBSztRQUFRLEdBQUksS0FBSyxTQUFTLGVBQWU7T0FBSTs7Ozs7T0FDakosd0JBQUMsT0FBRDtRQUFPLE9BQU8sS0FBSyxVQUFVLE9BQU8sa0JBQWtCO1FBQVMsT0FBTyxFQUFFLG9CQUFvQjtRQUFHLEdBQUksS0FBSyxTQUFTLGtCQUFrQjtPQUFJOzs7OztPQUN0SSxTQUFTLGdCQUFnQix3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBakIsQ0FBeUIsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWdCLEVBQUUsdUJBQXVCO1FBQVE7Ozs7a0JBQUMsd0JBQUMsU0FBRDtTQUFPLFFBQU87U0FBZSxXQUFVO1NBQVUsTUFBSztRQUFROzs7O2dCQUFROzs7Ozs7T0FDM0wsd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWpCLENBQXlCLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFnQixFQUFFLGtCQUFrQjtRQUFROzs7O2tCQUFDLHdCQUFDLFNBQUQ7U0FBTyxRQUFPO1NBQWUsV0FBVTtTQUFVLE1BQUs7UUFBUTs7OztnQkFBUTs7Ozs7O01BQ3pKOzs7Ozs7S0FFSixTQUFTLEtBQUssd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDYix3QkFBQyxxQkFBRDtRQUFxQixRQUFRLFFBQVE7UUFBVSxPQUFPLEVBQUUsbUJBQW1CO1FBQUcsVUFBVTtRQUFhLFVBQVUsUUFBUTtPQUFXOzs7OztPQUNsSSx3QkFBQyxPQUFEO1FBQU8sT0FBTyxFQUFFLHdCQUF3QjtRQUFHLFdBQVcsVUFBVSxZQUFZLGFBQWE7U0FBRSxHQUFHO1NBQVMsZ0JBQWdCLE1BQU0sT0FBTztRQUFNLEVBQUU7UUFBRyxhQUFhLEVBQUUsMkJBQTJCO1FBQUcsT0FBTyxRQUFRO09BQWlCOzs7OztPQUMzTixhQUFhLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO1FBQWUsTUFBSztrQkFBUyxFQUFFLFNBQVM7T0FBSzs7Ozs7TUFDckU7Ozs7OztLQUVKLFNBQVMsS0FBSyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNiLHdCQUFDLE1BQUQsWUFBSyxFQUFFLDJCQUEyQixFQUFNOzs7OztPQUN2QyxrQkFBa0IsYUFBYSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUFxQyx3QkFBQyxRQUFELEVBQU0sV0FBVSxXQUFZOzs7O2tCQUFDLHdCQUFDLFFBQUQsRUFBTSxXQUFVLFdBQVk7Ozs7Z0JBQU07Ozs7OztPQUNuSSxrQkFBa0IsV0FBVyx3QkFBQyxLQUFEO1FBQUcsV0FBVTtRQUFlLE1BQUs7a0JBQVMsRUFBRSxxQkFBcUI7T0FBSzs7Ozs7T0FDbkcsa0JBQWtCLE1BQU0sV0FBVyxLQUFLLHdCQUFDLEtBQUQsWUFBSSxFQUFFLDZCQUE2QixFQUFLOzs7OztPQUNqRix3QkFBQyxPQUFEO1FBQUssV0FBVTttQkFDWCxrQkFBa0IsUUFBUSxDQUFDLEVBQUMsQ0FBRSxLQUFLLFlBQVksd0JBQUMsY0FBRDtTQUErQixnQkFBZ0IsWUFBWSxhQUFhO1VBQUUsR0FBRztVQUFTLFdBQVcsUUFBUTtTQUFHLEVBQUU7U0FBWTtTQUFTLFVBQVUsUUFBUSxjQUFjLFFBQVE7U0FBYTtRQUFVLEdBQS9LLFFBQVE7Ozs7ZUFBdUssQ0FBQztPQUNqUDs7Ozs7TUFDRjs7Ozs7O0tBRUosU0FBUyxLQUFLLGdEQUNiLHdCQUFDLGNBQUQ7TUFBYyxVQUFVO01BQXFCLGVBQWU7TUFBNEI7TUFBUyxXQUFXO01BQU8sb0JBQW9CO0tBQVE7Ozs7ZUFDOUksWUFBWSx3QkFBQyxLQUFEO01BQUcsV0FBVTtNQUFpQixNQUFLO2dCQUFTLEVBQUUseUJBQXlCO0tBQUs7Ozs7YUFDekY7Ozs7O0tBRUQsU0FBUyxLQUFLLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ2Isd0JBQUMsV0FBRCxhQUFTLHdCQUFDLE1BQUQsWUFBSyxFQUFFLGdCQUFnQixFQUFNOzs7O2lCQUFDLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFkO1NBQ3JDLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxNQUFELFlBQUssRUFBRSxzQkFBc0IsRUFBTTs7OzttQkFBQyx3QkFBQyxNQUFELFlBQUssS0FBSyxVQUFVLGNBQWMsRUFBTTs7OztpQkFBTTs7Ozs7U0FDdkYsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLE1BQUQsWUFBSyxFQUFFLHVCQUF1QixFQUFNOzs7O21CQUFDLHdCQUFDLE1BQUQsWUFBSyxlQUFlLEtBQUssVUFBVSxlQUFlLENBQUMsRUFBTTs7OztpQkFBTTs7Ozs7U0FDekcsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLE1BQUQsWUFBSyxFQUFFLHVCQUF1QixFQUFNOzs7O21CQUFDLHdCQUFDLE1BQUQsWUFBSyxLQUFLLFVBQVUsZUFBZSxFQUFNOzs7O2lCQUFNOzs7OztTQUN6Rix3QkFBQyxPQUFELGFBQUssd0JBQUMsTUFBRCxZQUFLLEVBQUUsZ0JBQWdCLEVBQU07Ozs7bUJBQUMsd0JBQUMsTUFBRCxZQUFLLFFBQVEsV0FBVyxVQUFVLFFBQVEsUUFBUSxJQUFJLElBQVE7Ozs7aUJBQU07Ozs7O1NBQ3ZHLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxNQUFELFlBQUssRUFBRSxnQkFBZ0IsRUFBTTs7OzttQkFBQyx3QkFBQyxNQUFELFlBQUssUUFBUSxXQUFXLFVBQVUsUUFBUSxRQUFRLElBQUksSUFBUTs7OztpQkFBTTs7Ozs7UUFDckc7Ozs7O2VBQVU7Ozs7O09BQ2IsU0FBUyx3QkFBQyxnQkFBRCxFQUF1QixNQUFROzs7OztPQUN6Qyx3QkFBQyxRQUFEO1FBQVEsT0FBTyxFQUFFLHVCQUF1QjtRQUFHLFdBQVcsVUFBVSxpQkFBaUIsTUFBTSxPQUFPLEtBQTZCO1FBQUcsU0FBUztTQUNySTtVQUFFLE9BQU87VUFBZ0IsT0FBTyxFQUFFLHFCQUFxQjtTQUFFO1NBQUc7VUFBRSxPQUFPO1VBQWdCLE9BQU8sRUFBRSxxQkFBcUI7U0FBRTtTQUNySDtVQUFFLE9BQU87VUFBUSxPQUFPLEVBQUUsY0FBYztTQUFFO1NBQUc7VUFBRSxPQUFPO1VBQVEsT0FBTyxFQUFFLGNBQWM7U0FBRTtTQUFHO1VBQUUsT0FBTztVQUFhLE9BQU8sRUFBRSxtQkFBbUI7U0FBRTtRQUNoSjtRQUFHLE9BQU87T0FBZ0I7Ozs7O09BQ3pCLFlBQVksd0JBQUMsS0FBRDtRQUFHLFdBQVU7UUFBaUIsTUFBSztrQkFBUyxFQUFFLHlCQUF5QjtPQUFLOzs7OztNQUN0Rjs7Ozs7O0lBQ0g7Ozs7WUFDQzs7Ozs7O0dBRUosQ0FBQyxrQkFBa0Isd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FBbEIsQ0FDbEIsd0JBQUMsUUFBRDtLQUFRLFVBQVUsU0FBUztLQUFHLGVBQWUsU0FBUyxZQUFZLEtBQUssSUFBSSxHQUFHLFVBQVUsQ0FBQyxDQUFDO0tBQUcsU0FBUTtlQUFhLEVBQUUsY0FBYztJQUFVOzs7O2NBQzVJLHdCQUFDLFFBQUQ7S0FBUSxVQUFVLGNBQWMsYUFBYSxrQkFBa0IsYUFBYyxRQUFRLEtBQUssQ0FBQztLQUFRLGVBQWUsS0FBSyxhQUFhO2VBQ2pJLFNBQVMsSUFBSSxFQUFFLGNBQWMsWUFBWSx3QkFBd0IsZ0JBQWdCLElBQUksRUFBRSxjQUFjO0lBQ2hHOzs7O1lBQ0Y7Ozs7OztFQUNEOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJCb29raW5nV2l6YXJkLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB6b2RSZXNvbHZlciB9IGZyb20gJ0Bob29rZm9ybS9yZXNvbHZlcnMvem9kJ1xyXG5pbXBvcnQgeyB1c2VNdXRhdGlvbiB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcclxuaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgQ29udHJvbGxlciwgdXNlRm9ybSB9IGZyb20gJ3JlYWN0LWhvb2stZm9ybSdcclxuaW1wb3J0IHsgdXNlTmF2aWdhdGUsIHVzZVNlYXJjaFBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXHJcbmltcG9ydCB7IHogfSBmcm9tICd6b2QnXHJcbmltcG9ydCB7IEFwaUVycm9yLCBhcGlDbGllbnQgfSBmcm9tICcuLi8uLi9hcGkvY2xpZW50J1xyXG5pbXBvcnQgeyB1c2VBdmFpbGFibGVWZWhpY2xlcywgdXNlQ3JlYXRlQm9va2luZyB9IGZyb20gJy4uLy4uL2FwaS9xdWVyaWVzJ1xyXG5pbXBvcnQgdHlwZSB7IEJvb2tpbmcsIERyaXZlTW9kZSwgUXVvdGVSZXF1ZXN0LCBRdW90ZVJlc3BvbnNlLCBWZWhpY2xlIH0gZnJvbSAnLi4vLi4vYXBpL3R5cGVzJ1xyXG5pbXBvcnQgeyBCdXR0b24sIERhdGVUaW1lUmFuZ2VQaWNrZXIsIElucHV0LCBQaG9uZUlucHV0LCBTZWxlY3QsIFN0ZXBwZXIgfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL3VpJ1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vaG9va3MvQXV0aENvbnRleHQnXHJcbmltcG9ydCB7IHQgfSBmcm9tICcuLi8uLi9pMThuJ1xyXG5pbXBvcnQgeyBmb3JtYXRFYXQsIGZvcm1hdEtlcywgaXNLZW55YW5QaG9uZSwgbm9ybWFsaXNlUGhvbmUgfSBmcm9tICcuLi8uLi9saWInXHJcbmltcG9ydCB7IFF1b3RlQnVpbGRlciwgUXVvdGVCcmVha2Rvd24gfSBmcm9tICcuL1F1b3RlQnVpbGRlcidcclxuaW1wb3J0IHsgUGF5bWVudFN0YXR1cyB9IGZyb20gJy4vUGF5bWVudFN0YXR1cydcclxuXHJcbmNvbnN0IGN1c3RvbWVyU2NoZW1hID0gei5vYmplY3Qoe1xyXG4gIGN1c3RvbWVyTmFtZTogei5zdHJpbmcoKS50cmltKCkubWluKDIsIHQoJ2Jvb2tpbmcuc3RlcFJlcXVpcmVkJykpLFxyXG4gIGN1c3RvbWVyUGhvbmU6IHouc3RyaW5nKCkucmVmaW5lKGlzS2VueWFuUGhvbmUsIHQoJ2Jvb2tpbmcucGhvbmVJbnZhbGlkJykpLFxyXG4gIGN1c3RvbWVyRW1haWw6IHouc3RyaW5nKCkudHJpbSgpLmVtYWlsKHQoJ2F1dGguZW1haWxJbnZhbGlkJykpLFxyXG4gIGN1c3RvbWVySWROdW1iZXI6IHouc3RyaW5nKCkudHJpbSgpLm1pbig0LCB0KCdib29raW5nLnN0ZXBSZXF1aXJlZCcpKSxcclxufSlcclxuXHJcbnR5cGUgQ3VzdG9tZXJWYWx1ZXMgPSB6LmluZmVyPHR5cGVvZiBjdXN0b21lclNjaGVtYT5cclxuXHJcbmZ1bmN0aW9uIFZlaGljbGVQcmljZSh7IHZlaGljbGUsIHJlcXVlc3QsIG9uU2VsZWN0LCBzZWxlY3RlZCB9OiB7IHZlaGljbGU6IFZlaGljbGU7IHJlcXVlc3Q6IFF1b3RlUmVxdWVzdDsgb25TZWxlY3Q6ICgpID0+IHZvaWQ7IHNlbGVjdGVkOiBib29sZWFuIH0pIHtcclxuICBjb25zdCBbcXVvdGUsIHNldFF1b3RlXSA9IHVzZVN0YXRlPFF1b3RlUmVzcG9uc2UgfCBudWxsPihudWxsKVxyXG4gIGNvbnN0IHsgbXV0YXRlQXN5bmMgfSA9IHVzZU11dGF0aW9uKHsgbXV0YXRpb25GbjogKHBheWxvYWQ6IFF1b3RlUmVxdWVzdCkgPT4gYXBpQ2xpZW50LnBvc3Q8UXVvdGVSZXNwb25zZT4oJy9xdW90ZXMvY2FsY3VsYXRlJywgcGF5bG9hZCkgfSlcclxuICBjb25zdCByZXF1ZXN0S2V5ID0gSlNPTi5zdHJpbmdpZnkocmVxdWVzdClcclxuICBjb25zdCBwYXlsb2FkID0gdXNlTWVtbygoKSA9PiAoeyAuLi5KU09OLnBhcnNlKHJlcXVlc3RLZXkpIGFzIFF1b3RlUmVxdWVzdCwgdmVoaWNsZUlkOiB2ZWhpY2xlLmlkIH0pLCBbcmVxdWVzdEtleSwgdmVoaWNsZS5pZF0pXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBsZXQgYWN0aXZlID0gdHJ1ZVxyXG4gICAgdm9pZCBtdXRhdGVBc3luYyhwYXlsb2FkKS50aGVuKChyZXN1bHQpID0+IHtcclxuICAgICAgaWYgKGFjdGl2ZSkgc2V0UXVvdGUocmVzdWx0KVxyXG4gICAgfSkuY2F0Y2goKCkgPT4ge1xyXG4gICAgICBpZiAoYWN0aXZlKSBzZXRRdW90ZShudWxsKVxyXG4gICAgfSlcclxuICAgIHJldHVybiAoKSA9PiB7IGFjdGl2ZSA9IGZhbHNlIH1cclxuICB9LCBbbXV0YXRlQXN5bmMsIHBheWxvYWRdKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGJ1dHRvbiBhcmlhLXByZXNzZWQ9e3NlbGVjdGVkfSBjbGFzc05hbWU9e2B2ZWhpY2xlLWNob2ljZSR7c2VsZWN0ZWQgPyAnIGlzLXNlbGVjdGVkJyA6ICcnfWB9IG9uQ2xpY2s9e29uU2VsZWN0fSB0eXBlPVwiYnV0dG9uXCI+XHJcbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInZlaGljbGUtY2hvaWNlX19kZXRhaWxzXCI+PGI+e3ZlaGljbGUubWFrZX0ge3ZlaGljbGUubW9kZWx9PC9iPjxzbWFsbD57dmVoaWNsZS5yZWdpc3RyYXRpb259IMK3IHt2ZWhpY2xlLnNlYXRzfSB7dCgnc3R5bGVndWlkZS5zZWF0cycpfTwvc21hbGw+PC9zcGFuPlxyXG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJ2ZWhpY2xlLWNob2ljZV9fcHJpY2VcIj57cXVvdGUgPyBmb3JtYXRLZXMocXVvdGUucHJpY2luZ1NuYXBzaG90LnRvdGFsRHVlS2VzKSA6IHQoJ2Jvb2tpbmcuY2FsY3VsYXRpbmcnKX08L3NwYW4+XHJcbiAgICA8L2J1dHRvbj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBCb29raW5nV2l6YXJkKCkge1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxyXG4gIGNvbnN0IFtzZWFyY2hQYXJhbXNdID0gdXNlU2VhcmNoUGFyYW1zKClcclxuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKVxyXG4gIGNvbnN0IFtzdGVwLCBzZXRTdGVwXSA9IHVzZVN0YXRlKDApXHJcbiAgY29uc3QgW21vZGUsIHNldE1vZGVdID0gdXNlU3RhdGU8RHJpdmVNb2RlPignc2VsZl9kcml2ZScpXHJcbiAgY29uc3QgW3BheW1lbnRNZXRob2QsIHNldFBheW1lbnRNZXRob2RdID0gdXNlU3RhdGU8J21wZXNhX29ubGluZScgfCAnbXBlc2FfbWFudWFsJyB8ICdjYXNoJyB8ICdiYW5rJyB8ICdjb3Jwb3JhdGUnPignbXBlc2Ffb25saW5lJylcclxuICBjb25zdCBbcmVxdWVzdCwgc2V0UmVxdWVzdF0gPSB1c2VTdGF0ZTxRdW90ZVJlcXVlc3Q+KCgpID0+ICh7XHJcbiAgICB2ZWhpY2xlSWQ6IHNlYXJjaFBhcmFtcy5nZXQoJ3ZlaGljbGVJZCcpID8/ICcnLFxyXG4gICAgcGlja3VwQXQ6IHNlYXJjaFBhcmFtcy5nZXQoJ3BpY2t1cEF0JykgPz8gJycsXHJcbiAgICByZXR1cm5BdDogc2VhcmNoUGFyYW1zLmdldCgncmV0dXJuQXQnKSA/PyAnJyxcclxuICAgIHBpY2t1cExvY2F0aW9uOiAnJyxcclxuICAgIG1vZGU6ICdzZWxmX2RyaXZlJyxcclxuICAgIGV4dHJhczogW10sXHJcbiAgfSkpXHJcbiAgY29uc3QgW3F1b3RlLCBzZXRRdW90ZV0gPSB1c2VTdGF0ZTxRdW90ZVJlc3BvbnNlIHwgbnVsbD4obnVsbClcclxuICBjb25zdCBbY29uZmxpY3QsIHNldENvbmZsaWN0XSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gIGNvbnN0IFtwYXltZW50Qm9va2luZywgc2V0UGF5bWVudEJvb2tpbmddID0gdXNlU3RhdGU8Qm9va2luZyB8IG51bGw+KG51bGwpXHJcbiAgY29uc3QgW2RhdGVFcnJvciwgc2V0RGF0ZUVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpXHJcbiAgY29uc3QgZm9ybSA9IHVzZUZvcm08Q3VzdG9tZXJWYWx1ZXM+KHsgcmVzb2x2ZXI6IHpvZFJlc29sdmVyKGN1c3RvbWVyU2NoZW1hKSwgbW9kZTogJ29uVG91Y2hlZCcsIGRlZmF1bHRWYWx1ZXM6IHsgY3VzdG9tZXJOYW1lOiAnJywgY3VzdG9tZXJQaG9uZTogJycsIGN1c3RvbWVyRW1haWw6ICcnLCBjdXN0b21lcklkTnVtYmVyOiAnJyB9IH0pXHJcbiAgY29uc3QgYXZhaWxhYmxlVmVoaWNsZXMgPSB1c2VBdmFpbGFibGVWZWhpY2xlcyhyZXF1ZXN0LnBpY2t1cEF0LCByZXF1ZXN0LnJldHVybkF0KVxyXG4gIGNvbnN0IGNyZWF0ZUJvb2tpbmcgPSB1c2VDcmVhdGVCb29raW5nKClcclxuXHJcbiAgY29uc3QgaGFuZGxlUXVvdGVDaGFuZ2UgPSB1c2VDYWxsYmFjaygodmFsdWU6IFF1b3RlUmVzcG9uc2UgfCBudWxsKSA9PiBzZXRRdW90ZSh2YWx1ZSksIFtdKVxyXG4gIGNvbnN0IGhhbmRsZVJlcXVlc3RDaGFuZ2UgPSB1c2VDYWxsYmFjaygodmFsdWU6IFF1b3RlUmVxdWVzdCkgPT4ge1xyXG4gICAgc2V0UmVxdWVzdCh2YWx1ZSlcclxuICAgIHNldE1vZGUodmFsdWUubW9kZSlcclxuICAgIHNldENvbmZsaWN0KGZhbHNlKVxyXG4gIH0sIFtdKVxyXG5cclxuICBhc3luYyBmdW5jdGlvbiB2YWxpZGF0ZVN0ZXAoKSB7XHJcbiAgICBpZiAoc3RlcCA9PT0gMCkgcmV0dXJuIGZvcm0udHJpZ2dlcigpXHJcbiAgICBpZiAoc3RlcCA9PT0gMSkge1xyXG4gICAgICBpZiAoIXJlcXVlc3QucGlja3VwQXQgfHwgIXJlcXVlc3QucmV0dXJuQXQgfHwgIXJlcXVlc3QucGlja3VwTG9jYXRpb24udHJpbSgpKSByZXR1cm4gZmFsc2VcclxuICAgICAgaWYgKERhdGUucGFyc2UocmVxdWVzdC5waWNrdXBBdCkgPCBEYXRlLm5vdygpKSB7XHJcbiAgICAgICAgc2V0RGF0ZUVycm9yKCdib29raW5nLnBpY2t1cFBhc3QnKVxyXG4gICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICB9XHJcbiAgICAgIGlmIChEYXRlLnBhcnNlKHJlcXVlc3QucmV0dXJuQXQpIDw9IERhdGUucGFyc2UocmVxdWVzdC5waWNrdXBBdCkpIHtcclxuICAgICAgICBzZXREYXRlRXJyb3IoJ2Jvb2tpbmcucmV0dXJuQWZ0ZXJQaWNrdXAnKVxyXG4gICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICB9XHJcbiAgICAgIHNldERhdGVFcnJvcihudWxsKVxyXG4gICAgICByZXR1cm4gdHJ1ZVxyXG4gICAgfVxyXG4gICAgaWYgKHN0ZXAgPT09IDIpIHJldHVybiBCb29sZWFuKHJlcXVlc3QudmVoaWNsZUlkKVxyXG4gICAgaWYgKHN0ZXAgPT09IDMpIHJldHVybiBCb29sZWFuKHF1b3RlKVxyXG4gICAgcmV0dXJuIHRydWVcclxuICB9XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGNvbnRpbnVlU3RlcCgpIHtcclxuICAgIGlmIChzdGVwID09PSA0KSB7XHJcbiAgICAgIGF3YWl0IGZvcm0uaGFuZGxlU3VibWl0KGFzeW5jIChjdXN0b21lcikgPT4ge1xyXG4gICAgICAgIGlmICghcXVvdGUgfHwgIXJlcXVlc3QudmVoaWNsZUlkKSByZXR1cm5cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgY29uc3QgYm9va2luZyA9IGF3YWl0IGNyZWF0ZUJvb2tpbmcubXV0YXRlQXN5bmMoe1xyXG4gICAgICAgICAgICAuLi5yZXF1ZXN0LFxyXG4gICAgICAgICAgICAuLi5jdXN0b21lcixcclxuICAgICAgICAgICAgY3VzdG9tZXJQaG9uZTogbm9ybWFsaXNlUGhvbmUoY3VzdG9tZXIuY3VzdG9tZXJQaG9uZSksXHJcbiAgICAgICAgICAgIHBheW1lbnRNZXRob2QsXHJcbiAgICAgICAgICAgIGNyZWF0ZWRCeUlkOiB1c2VyPy5pZCA/PyAnJyxcclxuICAgICAgICAgIH0pXHJcbiAgICAgICAgICBpZiAocGF5bWVudE1ldGhvZCA9PT0gJ21wZXNhX29ubGluZScpIHNldFBheW1lbnRCb29raW5nKGJvb2tpbmcpXHJcbiAgICAgICAgICBlbHNlIG5hdmlnYXRlKGAvYWRtaW4vYm9va2luZ3MvJHtib29raW5nLmlkfWApXHJcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIEFwaUVycm9yICYmIGVycm9yLnN0YXR1cyA9PT0gNDA5KSB7XHJcbiAgICAgICAgICAgIHNldENvbmZsaWN0KHRydWUpXHJcbiAgICAgICAgICAgIGF3YWl0IGF2YWlsYWJsZVZlaGljbGVzLnJlZmV0Y2goKVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSkoKVxyXG4gICAgICByZXR1cm5cclxuICAgIH1cclxuICAgIGlmIChhd2FpdCB2YWxpZGF0ZVN0ZXAoKSkgc2V0U3RlcCgoY3VycmVudCkgPT4gTWF0aC5taW4oNCwgY3VycmVudCArIDEpKVxyXG4gIH1cclxuXHJcbiAgY29uc3QgdXBkYXRlRGF0ZXMgPSAocmFuZ2U6IHsgc3RhcnRVdGM6IHN0cmluZzsgZW5kVXRjOiBzdHJpbmcgfSkgPT4ge1xyXG4gICAgc2V0UmVxdWVzdCgoY3VycmVudCkgPT4gKHsgLi4uY3VycmVudCwgcGlja3VwQXQ6IHJhbmdlLnN0YXJ0VXRjLCByZXR1cm5BdDogcmFuZ2UuZW5kVXRjIH0pKVxyXG4gICAgc2V0Q29uZmxpY3QoZmFsc2UpXHJcbiAgICBzZXREYXRlRXJyb3IobnVsbClcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJib29raW5nLXdpemFyZFwiPlxyXG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImJvb2tpbmctd2l6YXJkX19oZWFkZXJcIj48cD57dCgnYm9va2luZy5saXN0VGl0bGUnKX08L3A+PGgyPnt0KCdib29raW5nLmNyZWF0ZUZpcnN0Jyl9PC9oMj48L2hlYWRlcj5cclxuICAgICAgeyFwYXltZW50Qm9va2luZyAmJiA8U3RlcHBlciBhY3RpdmVTdGVwPXtzdGVwfSBzdGVwcz17W1xyXG4gICAgICAgIHQoJ2Jvb2tpbmcuc3RlcHMuY3VzdG9tZXInKSwgdCgnYm9va2luZy5zdGVwcy5kYXRlcycpLCB0KCdib29raW5nLnN0ZXBzLnZlaGljbGUnKSxcclxuICAgICAgICB0KCdib29raW5nLnN0ZXBzLmV4dHJhcycpLCB0KCdib29raW5nLnN0ZXBzLnJldmlldycpLFxyXG4gICAgICBdfSAvPn1cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9va2luZy13aXphcmRfX2JvZHlcIj5cclxuICAgICAgICB7cGF5bWVudEJvb2tpbmcgJiYgPGRpdiBjbGFzc05hbWU9XCJib29raW5nLXBheW1lbnQtc3RlcFwiPlxyXG4gICAgICAgICAgPGgzPlJlc2VydmF0aW9uIGNyZWF0ZWQ8L2gzPlxyXG4gICAgICAgICAgPHA+Q29tcGxldGUgdGhlIE0tUGVzYSByZXF1ZXN0IHRvIGNvbmZpcm0gdGhpcyBib29raW5nLjwvcD5cclxuICAgICAgICAgIDxQYXltZW50U3RhdHVzXHJcbiAgICAgICAgICAgIGFtb3VudER1ZUtlcz17cGF5bWVudEJvb2tpbmcudG90YWxLZXN9XHJcbiAgICAgICAgICAgIGJvb2tpbmdJZD17cGF5bWVudEJvb2tpbmcuaWR9XHJcbiAgICAgICAgICAgIGluaXRpYWxQaG9uZT17bm9ybWFsaXNlUGhvbmUoZm9ybS5nZXRWYWx1ZXMoJ2N1c3RvbWVyUGhvbmUnKSl9XHJcbiAgICAgICAgICAgIG9uQ29uZmlybWVkPXsoKSA9PiBuYXZpZ2F0ZShgL2FkbWluL2Jvb2tpbmdzLyR7cGF5bWVudEJvb2tpbmcuaWR9YCl9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2Pn1cclxuICAgICAgICB7IXBheW1lbnRCb29raW5nICYmIDw+XHJcbiAgICAgICAge3N0ZXAgPT09IDAgJiYgPGRpdiBjbGFzc05hbWU9XCJib29raW5nLWZvcm0tZ3JpZFwiPlxyXG4gICAgICAgICAgPElucHV0IGVycm9yPXtmb3JtLmZvcm1TdGF0ZS5lcnJvcnMuY3VzdG9tZXJOYW1lPy5tZXNzYWdlfSBsYWJlbD17dCgnYm9va2luZy5jdXN0b21lck5hbWUnKX0gey4uLmZvcm0ucmVnaXN0ZXIoJ2N1c3RvbWVyTmFtZScpfSAvPlxyXG4gICAgICAgICAgPENvbnRyb2xsZXIgY29udHJvbD17Zm9ybS5jb250cm9sfSBuYW1lPVwiY3VzdG9tZXJQaG9uZVwiIHJlbmRlcj17KHsgZmllbGQgfSkgPT4gPFBob25lSW5wdXQgZXJyb3I9e2Zvcm0uZm9ybVN0YXRlLmVycm9ycy5jdXN0b21lclBob25lPy5tZXNzYWdlfSBsYWJlbD17dCgnYm9va2luZy5jdXN0b21lclBob25lJyl9IG9uQ2hhbmdlPXtmaWVsZC5vbkNoYW5nZX0gdmFsdWU9e2ZpZWxkLnZhbHVlfSAvPn0gLz5cclxuICAgICAgICAgIDxJbnB1dCBlcnJvcj17Zm9ybS5mb3JtU3RhdGUuZXJyb3JzLmN1c3RvbWVyRW1haWw/Lm1lc3NhZ2V9IGxhYmVsPXt0KCdib29raW5nLmN1c3RvbWVyRW1haWwnKX0gdHlwZT1cImVtYWlsXCIgey4uLmZvcm0ucmVnaXN0ZXIoJ2N1c3RvbWVyRW1haWwnKX0gLz5cclxuICAgICAgICAgIDxJbnB1dCBlcnJvcj17Zm9ybS5mb3JtU3RhdGUuZXJyb3JzLmN1c3RvbWVySWROdW1iZXI/Lm1lc3NhZ2V9IGxhYmVsPXt0KCdib29raW5nLmN1c3RvbWVySWQnKX0gey4uLmZvcm0ucmVnaXN0ZXIoJ2N1c3RvbWVySWROdW1iZXInKX0gLz5cclxuICAgICAgICAgIHttb2RlID09PSAnc2VsZl9kcml2ZScgJiYgPGxhYmVsIGNsYXNzTmFtZT1cImZpZWxkXCI+PHNwYW4gY2xhc3NOYW1lPVwiZmllbGRfX2xhYmVsXCI+e3QoJ2Jvb2tpbmcudXBsb2FkTGljZW5jZScpfTwvc3Bhbj48aW5wdXQgYWNjZXB0PVwiaW1hZ2UvKiwucGRmXCIgY2xhc3NOYW1lPVwiY29udHJvbFwiIHR5cGU9XCJmaWxlXCIgLz48L2xhYmVsPn1cclxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmaWVsZFwiPjxzcGFuIGNsYXNzTmFtZT1cImZpZWxkX19sYWJlbFwiPnt0KCdib29raW5nLnVwbG9hZElkJyl9PC9zcGFuPjxpbnB1dCBhY2NlcHQ9XCJpbWFnZS8qLC5wZGZcIiBjbGFzc05hbWU9XCJjb250cm9sXCIgdHlwZT1cImZpbGVcIiAvPjwvbGFiZWw+XHJcbiAgICAgICAgPC9kaXY+fVxyXG5cclxuICAgICAgICB7c3RlcCA9PT0gMSAmJiA8ZGl2IGNsYXNzTmFtZT1cImJvb2tpbmctZGF0ZS1zdGVwXCI+XHJcbiAgICAgICAgICA8RGF0ZVRpbWVSYW5nZVBpY2tlciBlbmRVdGM9e3JlcXVlc3QucmV0dXJuQXR9IGxhYmVsPXt0KCdib29raW5nLmRhdGVSYW5nZScpfSBvbkNoYW5nZT17dXBkYXRlRGF0ZXN9IHN0YXJ0VXRjPXtyZXF1ZXN0LnBpY2t1cEF0fSAvPlxyXG4gICAgICAgICAgPElucHV0IGxhYmVsPXt0KCdib29raW5nLnBpY2t1cExvY2F0aW9uJyl9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFJlcXVlc3QoKGN1cnJlbnQpID0+ICh7IC4uLmN1cnJlbnQsIHBpY2t1cExvY2F0aW9uOiBldmVudC50YXJnZXQudmFsdWUgfSkpfSBwbGFjZWhvbGRlcj17dCgnYm9va2luZy5waWNrdXBQbGFjZWhvbGRlcicpfSB2YWx1ZT17cmVxdWVzdC5waWNrdXBMb2NhdGlvbn0gLz5cclxuICAgICAgICAgIHtkYXRlRXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwiZmllbGRfX2Vycm9yXCIgcm9sZT1cImFsZXJ0XCI+e3QoZGF0ZUVycm9yKX08L3A+fVxyXG4gICAgICAgIDwvZGl2Pn1cclxuXHJcbiAgICAgICAge3N0ZXAgPT09IDIgJiYgPGRpdiBjbGFzc05hbWU9XCJ2ZWhpY2xlLXBpY2tlci1zdGVwXCI+XHJcbiAgICAgICAgICA8aDM+e3QoJ2Jvb2tpbmcuYXZhaWxhYmxlVmVoaWNsZXMnKX08L2gzPlxyXG4gICAgICAgICAge2F2YWlsYWJsZVZlaGljbGVzLmlzTG9hZGluZyAmJiA8ZGl2IGNsYXNzTmFtZT1cInZlaGljbGUtY2hvaWNlLWxpc3RcIj48c3BhbiBjbGFzc05hbWU9XCJza2VsZXRvblwiIC8+PHNwYW4gY2xhc3NOYW1lPVwic2tlbGV0b25cIiAvPjwvZGl2Pn1cclxuICAgICAgICAgIHthdmFpbGFibGVWZWhpY2xlcy5pc0Vycm9yICYmIDxwIGNsYXNzTmFtZT1cImZpZWxkX19lcnJvclwiIHJvbGU9XCJhbGVydFwiPnt0KCdib29raW5nLmFjdGlvbkVycm9yJyl9PC9wPn1cclxuICAgICAgICAgIHthdmFpbGFibGVWZWhpY2xlcy5kYXRhPy5sZW5ndGggPT09IDAgJiYgPHA+e3QoJ2Jvb2tpbmcubm9BdmFpbGFibGVWZWhpY2xlcycpfTwvcD59XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInZlaGljbGUtY2hvaWNlLWxpc3RcIj5cclxuICAgICAgICAgICAgeyhhdmFpbGFibGVWZWhpY2xlcy5kYXRhID8/IFtdKS5tYXAoKHZlaGljbGUpID0+IDxWZWhpY2xlUHJpY2Uga2V5PXt2ZWhpY2xlLmlkfSBvblNlbGVjdD17KCkgPT4gc2V0UmVxdWVzdCgoY3VycmVudCkgPT4gKHsgLi4uY3VycmVudCwgdmVoaWNsZUlkOiB2ZWhpY2xlLmlkIH0pKX0gcmVxdWVzdD17cmVxdWVzdH0gc2VsZWN0ZWQ9e3JlcXVlc3QudmVoaWNsZUlkID09PSB2ZWhpY2xlLmlkfSB2ZWhpY2xlPXt2ZWhpY2xlfSAvPil9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj59XHJcblxyXG4gICAgICAgIHtzdGVwID09PSAzICYmIDw+XHJcbiAgICAgICAgICA8UXVvdGVCdWlsZGVyIG9uQ2hhbmdlPXtoYW5kbGVSZXF1ZXN0Q2hhbmdlfSBvblF1b3RlQ2hhbmdlPXtoYW5kbGVRdW90ZUNoYW5nZX0gcmVxdWVzdD17cmVxdWVzdH0gc2hvd0RhdGVzPXtmYWxzZX0gc2hvd1BpY2t1cExvY2F0aW9uPXtmYWxzZX0gLz5cclxuICAgICAgICAgIHtjb25mbGljdCAmJiA8cCBjbGFzc05hbWU9XCJxdW90ZS1jb25mbGljdFwiIHJvbGU9XCJhbGVydFwiPnt0KCdib29raW5nLnJlc2VydmVDb25mbGljdCcpfTwvcD59XHJcbiAgICAgICAgPC8+fVxyXG5cclxuICAgICAgICB7c3RlcCA9PT0gNCAmJiA8ZGl2IGNsYXNzTmFtZT1cImJvb2tpbmctcmV2aWV3XCI+XHJcbiAgICAgICAgICA8c2VjdGlvbj48aDM+e3QoJ2Jvb2tpbmcucmV2aWV3Jyl9PC9oMz48ZGwgY2xhc3NOYW1lPVwiYm9va2luZy1yZXZpZXdfX2N1c3RvbWVyXCI+XHJcbiAgICAgICAgICAgIDxkaXY+PGR0Pnt0KCdib29raW5nLmN1c3RvbWVyTmFtZScpfTwvZHQ+PGRkPntmb3JtLmdldFZhbHVlcygnY3VzdG9tZXJOYW1lJyl9PC9kZD48L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj48ZHQ+e3QoJ2Jvb2tpbmcuY3VzdG9tZXJQaG9uZScpfTwvZHQ+PGRkPntub3JtYWxpc2VQaG9uZShmb3JtLmdldFZhbHVlcygnY3VzdG9tZXJQaG9uZScpKX08L2RkPjwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2PjxkdD57dCgnYm9va2luZy5jdXN0b21lckVtYWlsJyl9PC9kdD48ZGQ+e2Zvcm0uZ2V0VmFsdWVzKCdjdXN0b21lckVtYWlsJyl9PC9kZD48L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj48ZHQ+e3QoJ2Jvb2tpbmcucGlja3VwJyl9PC9kdD48ZGQ+e3JlcXVlc3QucGlja3VwQXQgPyBmb3JtYXRFYXQocmVxdWVzdC5waWNrdXBBdCkgOiAn4oCUJ308L2RkPjwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2PjxkdD57dCgnYm9va2luZy5yZXR1cm4nKX08L2R0PjxkZD57cmVxdWVzdC5yZXR1cm5BdCA/IGZvcm1hdEVhdChyZXF1ZXN0LnJldHVybkF0KSA6ICfigJQnfTwvZGQ+PC9kaXY+XHJcbiAgICAgICAgICA8L2RsPjwvc2VjdGlvbj5cclxuICAgICAgICAgIHtxdW90ZSAmJiA8UXVvdGVCcmVha2Rvd24gcXVvdGU9e3F1b3RlfSAvPn1cclxuICAgICAgICAgIDxTZWxlY3QgbGFiZWw9e3QoJ2Jvb2tpbmcucGF5bWVudE1ldGhvZCcpfSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRQYXltZW50TWV0aG9kKGV2ZW50LnRhcmdldC52YWx1ZSBhcyB0eXBlb2YgcGF5bWVudE1ldGhvZCl9IG9wdGlvbnM9e1tcclxuICAgICAgICAgICAgeyB2YWx1ZTogJ21wZXNhX29ubGluZScsIGxhYmVsOiB0KCdib29raW5nLm1wZXNhT25saW5lJykgfSwgeyB2YWx1ZTogJ21wZXNhX21hbnVhbCcsIGxhYmVsOiB0KCdib29raW5nLm1wZXNhTWFudWFsJykgfSxcclxuICAgICAgICAgICAgeyB2YWx1ZTogJ2Nhc2gnLCBsYWJlbDogdCgnYm9va2luZy5jYXNoJykgfSwgeyB2YWx1ZTogJ2JhbmsnLCBsYWJlbDogdCgnYm9va2luZy5iYW5rJykgfSwgeyB2YWx1ZTogJ2NvcnBvcmF0ZScsIGxhYmVsOiB0KCdib29raW5nLmNvcnBvcmF0ZScpIH0sXHJcbiAgICAgICAgICBdfSB2YWx1ZT17cGF5bWVudE1ldGhvZH0gLz5cclxuICAgICAgICAgIHtjb25mbGljdCAmJiA8cCBjbGFzc05hbWU9XCJxdW90ZS1jb25mbGljdFwiIHJvbGU9XCJhbGVydFwiPnt0KCdib29raW5nLnJlc2VydmVDb25mbGljdCcpfTwvcD59XHJcbiAgICAgICAgPC9kaXY+fVxyXG4gICAgICAgIDwvPn1cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7IXBheW1lbnRCb29raW5nICYmIDxmb290ZXIgY2xhc3NOYW1lPVwiYm9va2luZy13aXphcmRfX2FjdGlvbnNcIj5cclxuICAgICAgICA8QnV0dG9uIGRpc2FibGVkPXtzdGVwID09PSAwfSBvbkNsaWNrPXsoKSA9PiBzZXRTdGVwKChjdXJyZW50KSA9PiBNYXRoLm1heCgwLCBjdXJyZW50IC0gMSkpfSB2YXJpYW50PVwic2Vjb25kYXJ5XCI+e3QoJ2Jvb2tpbmcuYmFjaycpfTwvQnV0dG9uPlxyXG4gICAgICAgIDxCdXR0b24gZGlzYWJsZWQ9e2NyZWF0ZUJvb2tpbmcuaXNQZW5kaW5nIHx8IGF2YWlsYWJsZVZlaGljbGVzLmlzTG9hZGluZyB8fCAoc3RlcCA+PSAzICYmICFxdW90ZSl9IG9uQ2xpY2s9eygpID0+IHZvaWQgY29udGludWVTdGVwKCl9PlxyXG4gICAgICAgICAge3N0ZXAgPT09IDQgPyB0KGNyZWF0ZUJvb2tpbmcuaXNQZW5kaW5nID8gJ2Jvb2tpbmcuY2FsY3VsYXRpbmcnIDogJ2Jvb2tpbmcuY3JlYXRlJykgOiB0KCdib29raW5nLm5leHQnKX1cclxuICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgPC9mb290ZXI+fVxyXG4gICAgPC9zZWN0aW9uPlxyXG4gIClcclxufSJdfQ==
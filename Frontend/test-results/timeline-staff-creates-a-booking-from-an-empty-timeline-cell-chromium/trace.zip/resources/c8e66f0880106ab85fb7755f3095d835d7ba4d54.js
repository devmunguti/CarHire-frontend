import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/timeline/TimelinePage.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=8b23c0c4";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=8b23c0c4";
import Timeline, { DateHeader, SidebarHeader, TimelineHeaders } from "/node_modules/.vite/deps/react-calendar-timeline.js?v=8b23c0c4";
import "/node_modules/react-calendar-timeline/dist/style.css";
import { AlertTriangle, CalendarDays, Clock3 } from "/node_modules/.vite/deps/lucide-react.js?v=8b23c0c4";
import { useBookingList, useIncidents, useMaintenanceWindows, useVehicles } from "/src/api/queries.ts";
import { Button, Drawer, EmptyState, ErrorState, Skeleton } from "/src/components/ui/index.ts";
import { formatEat, formatKes } from "/src/lib/index.ts";
import { buildBookingPrefillUrl, buildTimelineItems, getTimelineStatusColor } from "/src/features/timeline/timelineModel.ts";
var _jsxFileName = "C:/CarHire/Frontend/src/features/timeline/TimelinePage.tsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b23c0c4";
var _s = $RefreshSig$();
const DAY_MS = 24 * 60 * 60 * 1e3;
function todayStart() {
	const date = new Date();
	date.setHours(0, 0, 0, 0);
	return date.getTime();
}
const statusLegend = [
	{
		status: "reserved",
		label: "Reserved"
	},
	{
		status: "confirmed",
		label: "Confirmed"
	},
	{
		status: "checked_out",
		label: "Checked out"
	},
	{
		status: "overdue",
		label: "Overdue"
	}
];
export function TimelinePage() {
	_s();
	const [rangeDays, setRangeDays] = useState(7);
	const [visibleRange, setVisibleRange] = useState(() => {
		const start = todayStart();
		return {
			start,
			end: start + 7 * DAY_MS
		};
	});
	const [selectedBooking, setSelectedBooking] = useState(null);
	const navigate = useNavigate();
	const rangeStart = visibleRange.start;
	const rangeEnd = visibleRange.end;
	const from = new Date(rangeStart).toISOString();
	const to = new Date(rangeEnd).toISOString();
	const bookingsQuery = useBookingList(new URLSearchParams({
		from,
		to
	}).toString());
	const vehiclesQuery = useVehicles();
	const maintenanceQuery = useMaintenanceWindows(from, to);
	const incidentsQuery = useIncidents();
	const bookings = bookingsQuery.data ?? [];
	const vehicles = vehiclesQuery.data ?? [];
	const incidents = incidentsQuery.data ?? [];
	const items = buildTimelineItems(bookings, maintenanceQuery.data ?? [], undefined, incidents);
	const groups = vehicles.map((vehicle) => ({
		id: vehicle.id,
		title: /* @__PURE__ */ _jsxDEV("span", {
			className: "fleet-timeline__vehicle",
			children: [/* @__PURE__ */ _jsxDEV("strong", { children: vehicle.registration }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 49,
				columnNumber: 54
			}, this), /* @__PURE__ */ _jsxDEV("small", { children: [
				vehicle.make,
				" ",
				vehicle.model
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 49,
				columnNumber: 93
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 49,
			columnNumber: 12
		}, this),
		stackItems: true,
		height: 54
	}));
	function chooseRange(days) {
		setRangeDays(days);
		const start = todayStart();
		setVisibleRange({
			start,
			end: start + days * DAY_MS
		});
	}
	function handleCanvasClick(groupId, time) {
		setSelectedBooking(null);
		navigate(buildBookingPrefillUrl(groupId, time));
	}
	function handleItemClick(itemId) {
		const item = items.find((entry) => entry.id === itemId);
		if (item?.kind === "incident_warning" && item.incidentId) {
			navigate(`/admin/incidents?incidentId=${encodeURIComponent(item.incidentId)}`);
			return;
		}
		if (item?.kind !== "booking" || !item.bookingId) return;
		setSelectedBooking(bookings.find((booking) => booking.id === item.bookingId) ?? null);
	}
	const isLoading = bookingsQuery.isLoading || vehiclesQuery.isLoading || maintenanceQuery.isLoading || incidentsQuery.isLoading;
	const hasError = bookingsQuery.isError || vehiclesQuery.isError || maintenanceQuery.isError || incidentsQuery.isError;
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "fleet-timeline-page",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "fleet-timeline-page__header",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("p", {
						className: "eyebrow",
						children: "Fleet operations"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 14
					}, this),
					/* @__PURE__ */ _jsxDEV("h1", { children: "Fleet timeline" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 57
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: "Bookings, turnaround time and maintenance by vehicle." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 80
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 81,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					"aria-label": "Timeline range",
					className: "timeline-range",
					role: "group",
					children: [/* @__PURE__ */ _jsxDEV(Button, {
						"aria-pressed": rangeDays === 7,
						onClick: () => chooseRange(7),
						variant: rangeDays === 7 ? "primary" : "secondary",
						children: [/* @__PURE__ */ _jsxDEV(CalendarDays, {
							"aria-hidden": "true",
							size: 16
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 83,
							columnNumber: 133
						}, this), " 7 days"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 83,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						"aria-pressed": rangeDays === 30,
						onClick: () => chooseRange(30),
						variant: rangeDays === 30 ? "primary" : "secondary",
						children: [/* @__PURE__ */ _jsxDEV(CalendarDays, {
							"aria-hidden": "true",
							size: 16
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 84,
							columnNumber: 136
						}, this), " 30 days"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 82,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				"aria-label": "Booking status legend",
				className: "fleet-timeline-legend",
				children: [
					statusLegend.map(({ status, label }) => /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("i", { style: { backgroundColor: getTimelineStatusColor(status) } }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 69
					}, this), label] }, status, true, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 50
					}, this)),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "fleet-timeline-legend__buffer",
						children: [/* @__PURE__ */ _jsxDEV("i", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 90,
							columnNumber: 57
						}, this), "Turnaround buffer"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "fleet-timeline-legend__maintenance",
						children: [
							/* @__PURE__ */ _jsxDEV("i", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 91,
								columnNumber: 62
							}, this),
							/* @__PURE__ */ _jsxDEV(AlertTriangle, {
								"aria-hidden": "true",
								size: 14
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 91,
								columnNumber: 67
							}, this),
							"Maintenance"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 91,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 88,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("details", {
				className: "fleet-timeline-alternative",
				children: [/* @__PURE__ */ _jsxDEV("summary", { children: "Keyboard-accessible bookings and vehicle actions" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 95,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("ul", { children: [items.filter((item) => item.kind === "booking" && item.bookingId).map((item) => {
					const booking = bookings.find((entry) => entry.id === item.bookingId);
					if (!booking) return null;
					return /* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => handleItemClick(item.id),
						type: "button",
						children: [
							"View booking ",
							booking.reference,
							": ",
							booking.status.replaceAll("_", " ")
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 101,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
						vehicles.find((vehicle) => vehicle.id === booking.vehicleId)?.registration ?? booking.vehicleId,
						" · ",
						formatEat(booking.pickupAt),
						"–",
						formatEat(booking.returnAt)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 102,
						columnNumber: 15
					}, this)] }, item.id, true, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 20
					}, this);
				}), vehicles.map((vehicle) => /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
					to: buildBookingPrefillUrl(vehicle.id, rangeStart),
					children: ["Create booking for ", vehicle.registration]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 106,
					columnNumber: 13
				}, this) }, `create-${vehicle.id}`, false, {
					fileName: _jsxFileName,
					lineNumber: 105,
					columnNumber: 38
				}, this))] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 96,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 94,
				columnNumber: 7
			}, this),
			isLoading && /* @__PURE__ */ _jsxDEV(Skeleton, { rows: 5 }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 111,
				columnNumber: 21
			}, this),
			hasError && /* @__PURE__ */ _jsxDEV(ErrorState, {
				onRetry: () => {
					void bookingsQuery.refetch();
					void vehiclesQuery.refetch();
					void maintenanceQuery.refetch();
					void incidentsQuery.refetch();
				},
				retryLabel: "Retry",
				title: "Timeline data could not be loaded"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 112,
				columnNumber: 20
			}, this),
			!isLoading && !hasError && vehicles.length === 0 && /* @__PURE__ */ _jsxDEV(EmptyState, {
				description: "Add vehicles to see their bookings here.",
				title: "No vehicles found"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 113,
				columnNumber: 60
			}, this),
			!isLoading && !hasError && vehicles.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
				className: "fleet-timeline-scroll",
				"data-testid": "fleet-timeline",
				children: /* @__PURE__ */ _jsxDEV(Timeline, {
					canMove: false,
					canResize: false,
					defaultTimeEnd: rangeEnd,
					defaultTimeStart: rangeStart,
					groups,
					itemHeightRatio: .78,
					items,
					maxZoom: 30 * DAY_MS,
					minZoom: 7 * DAY_MS,
					onCanvasClick: handleCanvasClick,
					onItemClick: handleItemClick,
					onItemSelect: handleItemClick,
					onTimeChange: (start, end, updateScrollCanvas) => {
						setVisibleRange({
							start,
							end
						});
						updateScrollCanvas(start, end);
					},
					sidebarWidth: 170,
					stackItems: true,
					timeSteps: {
						second: 60,
						minute: 30,
						hour: 1,
						day: 1,
						month: 1,
						year: 1
					},
					visibleTimeEnd: rangeEnd,
					visibleTimeStart: rangeStart,
					children: /* @__PURE__ */ _jsxDEV(TimelineHeaders, { children: [
						/* @__PURE__ */ _jsxDEV(SidebarHeader, { children: ({ getRootProps }) => /* @__PURE__ */ _jsxDEV("div", {
							...getRootProps({ style: {} }),
							children: /* @__PURE__ */ _jsxDEV("span", {
								className: "fleet-timeline__sidebar-title",
								children: "Vehicle"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 89
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 139,
							columnNumber: 51
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 139,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(DateHeader, { unit: "primaryHeader" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 140,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(DateHeader, { unit: "day" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 141,
							columnNumber: 13
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 138,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 115,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 114,
				columnNumber: 58
			}, this),
			selectedBooking && /* @__PURE__ */ _jsxDEV(Drawer, {
				open: true,
				title: selectedBooking.reference,
				onClose: () => setSelectedBooking(null),
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "fleet-timeline-drawer",
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: `fleet-timeline-drawer__status fleet-timeline-drawer__status--${selectedBooking.status}`,
							children: [selectedBooking.status === "overdue" && /* @__PURE__ */ _jsxDEV(AlertTriangle, {
								"aria-hidden": "true",
								size: 15
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 54
							}, this), selectedBooking.status === "overdue" ? "Overdue" : selectedBooking.status.replaceAll("_", " ")]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 148,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("dl", { children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Customer" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 153,
								columnNumber: 18
							}, this), /* @__PURE__ */ _jsxDEV("dd", { children: selectedBooking.customerName ?? "—" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 153,
								columnNumber: 35
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 153,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Vehicle" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 154,
								columnNumber: 18
							}, this), /* @__PURE__ */ _jsxDEV("dd", { children: vehicles.find((vehicle) => vehicle.id === selectedBooking.vehicleId)?.registration ?? selectedBooking.vehicleId }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 154,
								columnNumber: 34
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 154,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Pickup" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 155,
								columnNumber: 18
							}, this), /* @__PURE__ */ _jsxDEV("dd", { children: formatEat(selectedBooking.pickupAt) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 155,
								columnNumber: 33
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 155,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Return" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 156,
								columnNumber: 18
							}, this), /* @__PURE__ */ _jsxDEV("dd", { children: formatEat(selectedBooking.returnAt) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 156,
								columnNumber: 33
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 156,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Amount" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 157,
								columnNumber: 18
							}, this), /* @__PURE__ */ _jsxDEV("dd", { children: formatKes(selectedBooking.totalKes) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 157,
								columnNumber: 33
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 157,
								columnNumber: 13
							}, this),
							selectedBooking.status === "overdue" && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Late fees" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 158,
								columnNumber: 59
							}, this), /* @__PURE__ */ _jsxDEV("dd", {
								className: "fleet-timeline-drawer__danger",
								children: [
									/* @__PURE__ */ _jsxDEV(Clock3, {
										"aria-hidden": "true",
										size: 15
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 158,
										columnNumber: 123
									}, this),
									" ",
									formatKes(selectedBooking.accruedLateFeeKes ?? 0)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 158,
								columnNumber: 77
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 158,
								columnNumber: 54
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 152,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(Link, {
							className: "button button--primary",
							to: `/admin/bookings/${selectedBooking.id}`,
							children: "Open booking"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 160,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 147,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 146,
				columnNumber: 27
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 79,
		columnNumber: 5
	}, this);
}
_s(TimelinePage, "nIKy0+SdJXnP2TEoTwDkG6NlNEc=", false, function() {
	return [
		useNavigate,
		useBookingList,
		useVehicles,
		useMaintenanceWindows,
		useIncidents
	];
});
_c = TimelinePage;
var _c;
$RefreshReg$(_c, "TimelinePage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/timeline/TimelinePage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/CarHire/Frontend/src/features/timeline/TimelinePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/CarHire/Frontend/src/features/timeline/TimelinePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/CarHire/Frontend/src/features/timeline/TimelinePage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxNQUFNLG1CQUFtQjtBQUNsQyxPQUFPLFlBQVksWUFBWSxlQUFlLHVCQUF1QjtBQUNyRSxPQUFPO0FBQ1AsU0FBUyxlQUFlLGNBQWMsY0FBYztBQUNwRCxTQUFTLGdCQUFnQixjQUFjLHVCQUF1QixtQkFBbUI7QUFFakYsU0FBUyxRQUFRLFFBQVEsWUFBWSxZQUFZLGdCQUFnQjtBQUNqRSxTQUFTLFdBQVcsaUJBQWlCO0FBQ3JDLFNBQVMsd0JBQXdCLG9CQUFvQiw4QkFBc0Q7Ozs7QUFFM0csTUFBTSxTQUFTLEtBQUssS0FBSyxLQUFLO0FBRTlCLFNBQVMsYUFBYTtDQUNwQixNQUFNLE9BQU8sSUFBSSxLQUFLO0NBQ3RCLEtBQUssU0FBUyxHQUFHLEdBQUcsR0FBRyxDQUFDO0NBQ3hCLE9BQU8sS0FBSyxRQUFRO0FBQ3RCO0FBRUEsTUFBTSxlQUErRDtDQUNuRTtFQUFFLFFBQVE7RUFBWSxPQUFPO0NBQVc7Q0FDeEM7RUFBRSxRQUFRO0VBQWEsT0FBTztDQUFZO0NBQzFDO0VBQUUsUUFBUTtFQUFlLE9BQU87Q0FBYztDQUM5QztFQUFFLFFBQVE7RUFBVyxPQUFPO0NBQVU7QUFDeEM7QUFFQSxPQUFPLFNBQVMsZUFBZTs7Q0FDN0IsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQWlCLENBQUM7Q0FDcEQsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLGVBQWU7RUFDckQsTUFBTSxRQUFRLFdBQVc7RUFDekIsT0FBTztHQUFFO0dBQU8sS0FBSyxRQUFRLElBQUk7RUFBTztDQUMxQyxDQUFDO0NBQ0QsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBeUIsSUFBSTtDQUMzRSxNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLGFBQWEsYUFBYTtDQUNoQyxNQUFNLFdBQVcsYUFBYTtDQUM5QixNQUFNLE9BQU8sSUFBSSxLQUFLLFVBQVUsQ0FBQyxDQUFDLFlBQVk7Q0FDOUMsTUFBTSxLQUFLLElBQUksS0FBSyxRQUFRLENBQUMsQ0FBQyxZQUFZO0NBQzFDLE1BQU0sZ0JBQWdCLGVBQWUsSUFBSSxnQkFBZ0I7RUFBRTtFQUFNO0NBQUcsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO0NBQ2pGLE1BQU0sZ0JBQWdCLFlBQVk7Q0FDbEMsTUFBTSxtQkFBbUIsc0JBQXNCLE1BQU0sRUFBRTtDQUN2RCxNQUFNLGlCQUFpQixhQUFhO0NBQ3BDLE1BQU0sV0FBVyxjQUFjLFFBQVEsQ0FBQztDQUN4QyxNQUFNLFdBQVcsY0FBYyxRQUFRLENBQUM7Q0FDeEMsTUFBTSxZQUFZLGVBQWUsUUFBUSxDQUFDO0NBQzFDLE1BQU0sUUFBUSxtQkFBbUIsVUFBVSxpQkFBaUIsUUFBUSxDQUFDLEdBQUcsV0FBVyxTQUFTO0NBQzVGLE1BQU0sU0FBUyxTQUFTLEtBQUssYUFBYTtFQUN4QyxJQUFJLFFBQVE7RUFDWixPQUFPLHdCQUFDLFFBQUQ7R0FBTSxXQUFVO2FBQWhCLENBQTBDLHdCQUFDLFVBQUQsWUFBUyxRQUFRLGFBQXFCOzs7O2FBQUMsd0JBQUMsU0FBRDtJQUFRLFFBQVE7SUFBSztJQUFFLFFBQVE7R0FBYTs7OztXQUFPOzs7Ozs7RUFDM0ksWUFBWTtFQUNaLFFBQVE7Q0FDVixFQUFFO0NBRUYsU0FBUyxZQUFZLE1BQWM7RUFDakMsYUFBYSxJQUFJO0VBQ2pCLE1BQU0sUUFBUSxXQUFXO0VBQ3pCLGdCQUFnQjtHQUFFO0dBQU8sS0FBSyxRQUFRLE9BQU87RUFBTyxDQUFDO0NBQ3ZEO0NBRUEsU0FBUyxrQkFBa0IsU0FBMEIsTUFBYztFQUNqRSxtQkFBbUIsSUFBSTtFQUN2QixTQUFTLHVCQUF1QixTQUFTLElBQUksQ0FBQztDQUNoRDtDQUVBLFNBQVMsZ0JBQWdCLFFBQXlCO0VBQ2hELE1BQU0sT0FBTyxNQUFNLE1BQU0sVUFBVSxNQUFNLE9BQU8sTUFBTTtFQUN0RCxJQUFJLE1BQU0sU0FBUyxzQkFBc0IsS0FBSyxZQUFZO0dBQ3hELFNBQVMsK0JBQStCLG1CQUFtQixLQUFLLFVBQVUsR0FBRztHQUM3RTtFQUNGO0VBQ0EsSUFBSSxNQUFNLFNBQVMsYUFBYSxDQUFDLEtBQUssV0FBVztFQUNqRCxtQkFBbUIsU0FBUyxNQUFNLFlBQVksUUFBUSxPQUFPLEtBQUssU0FBUyxLQUFLLElBQUk7Q0FDdEY7Q0FFQSxNQUFNLFlBQVksY0FBYyxhQUFhLGNBQWMsYUFBYSxpQkFBaUIsYUFBYSxlQUFlO0NBQ3JILE1BQU0sV0FBVyxjQUFjLFdBQVcsY0FBYyxXQUFXLGlCQUFpQixXQUFXLGVBQWU7Q0FFOUcsT0FDRSx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQjtHQUNFLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO2NBQWxCLENBQ0Usd0JBQUMsT0FBRDtLQUFLLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFVO0tBQW1COzs7OztLQUFDLHdCQUFDLE1BQUQsWUFBSSxpQkFBa0I7Ozs7O0tBQUMsd0JBQUMsS0FBRCxZQUFHLHdEQUF3RDs7Ozs7SUFBTTs7OztjQUN4SSx3QkFBQyxPQUFEO0tBQUssY0FBVztLQUFpQixXQUFVO0tBQWlCLE1BQUs7ZUFBakUsQ0FDRSx3QkFBQyxRQUFEO01BQVEsZ0JBQWMsY0FBYztNQUFHLGVBQWUsWUFBWSxDQUFDO01BQUcsU0FBUyxjQUFjLElBQUksWUFBWTtnQkFBN0csQ0FBMEgsd0JBQUMsY0FBRDtPQUFjLGVBQVk7T0FBTyxNQUFNO01BQUs7Ozs7Z0JBQUMsU0FBZTs7Ozs7ZUFDdEwsd0JBQUMsUUFBRDtNQUFRLGdCQUFjLGNBQWM7TUFBSSxlQUFlLFlBQVksRUFBRTtNQUFHLFNBQVMsY0FBYyxLQUFLLFlBQVk7Z0JBQWhILENBQTZILHdCQUFDLGNBQUQ7T0FBYyxlQUFZO09BQU8sTUFBTTtNQUFLOzs7O2dCQUFDLFVBQWdCOzs7OzthQUN2TDs7Ozs7WUFDQzs7Ozs7O0dBRVIsd0JBQUMsT0FBRDtJQUFLLGNBQVc7SUFBd0IsV0FBVTtjQUFsRDtLQUNHLGFBQWEsS0FBSyxFQUFFLFFBQVEsWUFBWSx3QkFBQyxRQUFELGFBQW1CLHdCQUFDLEtBQUQsRUFBRyxPQUFPLEVBQUUsaUJBQWlCLHVCQUF1QixNQUFNLEVBQUUsRUFBSTs7OztlQUFFLEtBQVksS0FBdEY7Ozs7WUFBc0YsQ0FBQztLQUMzSSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaEIsQ0FBZ0Qsd0JBQUMsS0FBRCxDQUFJOzs7O2dCQUFDLG1CQUF1Qjs7Ozs7O0tBQzVFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFoQjtPQUFxRCx3QkFBQyxLQUFELENBQUk7Ozs7O09BQUMsd0JBQUMsZUFBRDtRQUFlLGVBQVk7UUFBTyxNQUFNO09BQUs7Ozs7O09BQUM7TUFBaUI7Ozs7OztJQUN0SDs7Ozs7O0dBRUwsd0JBQUMsV0FBRDtJQUFTLFdBQVU7Y0FBbkIsQ0FDRSx3QkFBQyxXQUFELFlBQVMsbURBQXlEOzs7O2NBQ2xFLHdCQUFDLE1BQUQsYUFDRyxNQUFNLFFBQVEsU0FBUyxLQUFLLFNBQVMsYUFBYSxLQUFLLFNBQVMsQ0FBQyxDQUFDLEtBQUssU0FBUztLQUMvRSxNQUFNLFVBQVUsU0FBUyxNQUFNLFVBQVUsTUFBTSxPQUFPLEtBQUssU0FBUztLQUNwRSxJQUFJLENBQUMsU0FBUyxPQUFPO0tBQ3JCLE9BQU8sd0JBQUMsTUFBRCxhQUNMLHdCQUFDLFVBQUQ7TUFBUSxlQUFlLGdCQUFnQixLQUFLLEVBQUU7TUFBRyxNQUFLO2dCQUF0RDtPQUErRDtPQUFjLFFBQVE7T0FBVTtPQUFHLFFBQVEsT0FBTyxXQUFXLEtBQUssR0FBRztNQUFVOzs7OztlQUM5SSx3QkFBQyxRQUFEO01BQU8sU0FBUyxNQUFNLFlBQVksUUFBUSxPQUFPLFFBQVEsU0FBUyxDQUFDLEVBQUUsZ0JBQWdCLFFBQVE7TUFBVTtNQUFJLFVBQVUsUUFBUSxRQUFRO01BQUU7TUFBRSxVQUFVLFFBQVEsUUFBUTtLQUFROzs7O2FBQ3pLLEtBSFksS0FBSzs7OztZQUdqQjtJQUNOLENBQUMsR0FDQSxTQUFTLEtBQUssWUFBWSx3QkFBQyxNQUFELFlBQ3pCLHdCQUFDLE1BQUQ7S0FBTSxJQUFJLHVCQUF1QixRQUFRLElBQUksVUFBVTtlQUF2RCxDQUEwRCx1QkFBb0IsUUFBUSxZQUFtQjs7Ozs7YUFDdkcsR0FGZ0MsVUFBVSxRQUFROzs7O1dBRWxELENBQUMsQ0FDSDs7OztZQUNHOzs7Ozs7R0FFUixhQUFhLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEVBQUk7Ozs7O0dBQ2pDLFlBQVksd0JBQUMsWUFBRDtJQUFZLGVBQWU7S0FBRSxLQUFLLGNBQWMsUUFBUTtLQUFHLEtBQUssY0FBYyxRQUFRO0tBQUcsS0FBSyxpQkFBaUIsUUFBUTtLQUFHLEtBQUssZUFBZSxRQUFRO0lBQUU7SUFBRyxZQUFXO0lBQVEsT0FBTTtHQUFxQzs7Ozs7R0FDck8sQ0FBQyxhQUFhLENBQUMsWUFBWSxTQUFTLFdBQVcsS0FBSyx3QkFBQyxZQUFEO0lBQVksYUFBWTtJQUEyQyxPQUFNO0dBQXFCOzs7OztHQUNsSixDQUFDLGFBQWEsQ0FBQyxZQUFZLFNBQVMsU0FBUyxLQUFLLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO0lBQXdCLGVBQVk7Y0FDcEcsd0JBQUMsVUFBRDtLQUNFLFNBQVM7S0FDVCxXQUFXO0tBQ1gsZ0JBQWdCO0tBQ2hCLGtCQUFrQjtLQUNWO0tBQ1IsaUJBQWlCO0tBQ1Y7S0FDUCxTQUFTLEtBQUs7S0FDZCxTQUFTLElBQUk7S0FDYixlQUFlO0tBQ2YsYUFBYTtLQUNiLGNBQWM7S0FDZCxlQUFlLE9BQU8sS0FBSyx1QkFBdUI7TUFDaEQsZ0JBQWdCO09BQUU7T0FBTztNQUFJLENBQUM7TUFDOUIsbUJBQW1CLE9BQU8sR0FBRztLQUMvQjtLQUNBLGNBQWM7S0FDZDtLQUNBLFdBQVc7TUFBRSxRQUFRO01BQUksUUFBUTtNQUFJLE1BQU07TUFBRyxLQUFLO01BQUcsT0FBTztNQUFHLE1BQU07S0FBRTtLQUN4RSxnQkFBZ0I7S0FDaEIsa0JBQWtCO2VBRWxCLHdCQUFDLGlCQUFEO01BQ0Usd0JBQUMsZUFBRCxhQUFpQixFQUFFLG1CQUFtQix3QkFBQyxPQUFEO09BQUssR0FBSSxhQUFhLEVBQUUsT0FBTyxDQUFDLEVBQUUsQ0FBQztpQkFBRyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBZ0M7T0FBYTs7Ozs7TUFBTTs7OztlQUFpQjs7Ozs7TUFDaEssd0JBQUMsWUFBRCxFQUFZLE1BQUssZ0JBQWlCOzs7OztNQUNsQyx3QkFBQyxZQUFELEVBQVksTUFBSyxNQUFPOzs7OztLQUNUOzs7OztJQUNUOzs7OztHQUNQOzs7OztHQUVKLG1CQUFtQix3QkFBQyxRQUFEO0lBQVE7SUFBSyxPQUFPLGdCQUFnQjtJQUFXLGVBQWUsbUJBQW1CLElBQUk7Y0FDdkcsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFXLGdFQUFnRSxnQkFBZ0I7aUJBQWpHLENBQ0csZ0JBQWdCLFdBQVcsYUFBYSx3QkFBQyxlQUFEO1FBQWUsZUFBWTtRQUFPLE1BQU07T0FBSzs7OztpQkFDckYsZ0JBQWdCLFdBQVcsWUFBWSxZQUFZLGdCQUFnQixPQUFPLFdBQVcsS0FBSyxHQUFHLENBQzFGOzs7Ozs7TUFDTix3QkFBQyxNQUFEO09BQ0Usd0JBQUMsT0FBRCxhQUFLLHdCQUFDLE1BQUQsWUFBSSxXQUFZOzs7O2lCQUFDLHdCQUFDLE1BQUQsWUFBSyxnQkFBZ0IsZ0JBQWdCLElBQVE7Ozs7ZUFBTTs7Ozs7T0FDekUsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLE1BQUQsWUFBSSxVQUFXOzs7O2lCQUFDLHdCQUFDLE1BQUQsWUFBSyxTQUFTLE1BQU0sWUFBWSxRQUFRLE9BQU8sZ0JBQWdCLFNBQVMsQ0FBQyxFQUFFLGdCQUFnQixnQkFBZ0IsVUFBYzs7OztlQUFNOzs7OztPQUNwSix3QkFBQyxPQUFELGFBQUssd0JBQUMsTUFBRCxZQUFJLFNBQVU7Ozs7aUJBQUMsd0JBQUMsTUFBRCxZQUFLLFVBQVUsZ0JBQWdCLFFBQVEsRUFBTTs7OztlQUFNOzs7OztPQUN2RSx3QkFBQyxPQUFELGFBQUssd0JBQUMsTUFBRCxZQUFJLFNBQVU7Ozs7aUJBQUMsd0JBQUMsTUFBRCxZQUFLLFVBQVUsZ0JBQWdCLFFBQVEsRUFBTTs7OztlQUFNOzs7OztPQUN2RSx3QkFBQyxPQUFELGFBQUssd0JBQUMsTUFBRCxZQUFJLFNBQVU7Ozs7aUJBQUMsd0JBQUMsTUFBRCxZQUFLLFVBQVUsZ0JBQWdCLFFBQVEsRUFBTTs7OztlQUFNOzs7OztPQUN0RSxnQkFBZ0IsV0FBVyxhQUFhLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxNQUFELFlBQUksWUFBYTs7OztpQkFBQyx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZDtTQUE4Qyx3QkFBQyxRQUFEO1VBQVEsZUFBWTtVQUFPLE1BQU07U0FBSzs7Ozs7U0FBQztTQUFFLFVBQVUsZ0JBQWdCLHFCQUFxQixDQUFDO1FBQU07Ozs7O2VBQU07Ozs7O01BQ2pOOzs7OztNQUNKLHdCQUFDLE1BQUQ7T0FBTSxXQUFVO09BQXlCLElBQUksbUJBQW1CLGdCQUFnQjtpQkFBTTtNQUFrQjs7Ozs7S0FDckc7Ozs7OztHQUNDOzs7OztFQUNEOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJUaW1lbGluZVBhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IExpbmssIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcclxuaW1wb3J0IFRpbWVsaW5lLCB7IERhdGVIZWFkZXIsIFNpZGViYXJIZWFkZXIsIFRpbWVsaW5lSGVhZGVycyB9IGZyb20gJ3JlYWN0LWNhbGVuZGFyLXRpbWVsaW5lJ1xyXG5pbXBvcnQgJ3JlYWN0LWNhbGVuZGFyLXRpbWVsaW5lL3N0eWxlLmNzcydcclxuaW1wb3J0IHsgQWxlcnRUcmlhbmdsZSwgQ2FsZW5kYXJEYXlzLCBDbG9jazMgfSBmcm9tICdsdWNpZGUtcmVhY3QnXHJcbmltcG9ydCB7IHVzZUJvb2tpbmdMaXN0LCB1c2VJbmNpZGVudHMsIHVzZU1haW50ZW5hbmNlV2luZG93cywgdXNlVmVoaWNsZXMgfSBmcm9tICcuLi8uLi9hcGkvcXVlcmllcydcclxuaW1wb3J0IHR5cGUgeyBCb29raW5nIH0gZnJvbSAnLi4vLi4vYXBpL3R5cGVzJ1xyXG5pbXBvcnQgeyBCdXR0b24sIERyYXdlciwgRW1wdHlTdGF0ZSwgRXJyb3JTdGF0ZSwgU2tlbGV0b24gfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL3VpJ1xyXG5pbXBvcnQgeyBmb3JtYXRFYXQsIGZvcm1hdEtlcyB9IGZyb20gJy4uLy4uL2xpYidcclxuaW1wb3J0IHsgYnVpbGRCb29raW5nUHJlZmlsbFVybCwgYnVpbGRUaW1lbGluZUl0ZW1zLCBnZXRUaW1lbGluZVN0YXR1c0NvbG9yLCB0eXBlIEZsZWV0VGltZWxpbmVJdGVtIH0gZnJvbSAnLi90aW1lbGluZU1vZGVsJ1xyXG5cclxuY29uc3QgREFZX01TID0gMjQgKiA2MCAqIDYwICogMTAwMFxyXG5cclxuZnVuY3Rpb24gdG9kYXlTdGFydCgpIHtcclxuICBjb25zdCBkYXRlID0gbmV3IERhdGUoKVxyXG4gIGRhdGUuc2V0SG91cnMoMCwgMCwgMCwgMClcclxuICByZXR1cm4gZGF0ZS5nZXRUaW1lKClcclxufVxyXG5cclxuY29uc3Qgc3RhdHVzTGVnZW5kOiB7IHN0YXR1czogQm9va2luZ1snc3RhdHVzJ107IGxhYmVsOiBzdHJpbmcgfVtdID0gW1xyXG4gIHsgc3RhdHVzOiAncmVzZXJ2ZWQnLCBsYWJlbDogJ1Jlc2VydmVkJyB9LFxyXG4gIHsgc3RhdHVzOiAnY29uZmlybWVkJywgbGFiZWw6ICdDb25maXJtZWQnIH0sXHJcbiAgeyBzdGF0dXM6ICdjaGVja2VkX291dCcsIGxhYmVsOiAnQ2hlY2tlZCBvdXQnIH0sXHJcbiAgeyBzdGF0dXM6ICdvdmVyZHVlJywgbGFiZWw6ICdPdmVyZHVlJyB9LFxyXG5dXHJcblxyXG5leHBvcnQgZnVuY3Rpb24gVGltZWxpbmVQYWdlKCkge1xyXG4gIGNvbnN0IFtyYW5nZURheXMsIHNldFJhbmdlRGF5c10gPSB1c2VTdGF0ZTw3IHwgMzA+KDcpXHJcbiAgY29uc3QgW3Zpc2libGVSYW5nZSwgc2V0VmlzaWJsZVJhbmdlXSA9IHVzZVN0YXRlKCgpID0+IHtcclxuICAgIGNvbnN0IHN0YXJ0ID0gdG9kYXlTdGFydCgpXHJcbiAgICByZXR1cm4geyBzdGFydCwgZW5kOiBzdGFydCArIDcgKiBEQVlfTVMgfVxyXG4gIH0pXHJcbiAgY29uc3QgW3NlbGVjdGVkQm9va2luZywgc2V0U2VsZWN0ZWRCb29raW5nXSA9IHVzZVN0YXRlPEJvb2tpbmcgfCBudWxsPihudWxsKVxyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxyXG4gIGNvbnN0IHJhbmdlU3RhcnQgPSB2aXNpYmxlUmFuZ2Uuc3RhcnRcclxuICBjb25zdCByYW5nZUVuZCA9IHZpc2libGVSYW5nZS5lbmRcclxuICBjb25zdCBmcm9tID0gbmV3IERhdGUocmFuZ2VTdGFydCkudG9JU09TdHJpbmcoKVxyXG4gIGNvbnN0IHRvID0gbmV3IERhdGUocmFuZ2VFbmQpLnRvSVNPU3RyaW5nKClcclxuICBjb25zdCBib29raW5nc1F1ZXJ5ID0gdXNlQm9va2luZ0xpc3QobmV3IFVSTFNlYXJjaFBhcmFtcyh7IGZyb20sIHRvIH0pLnRvU3RyaW5nKCkpXHJcbiAgY29uc3QgdmVoaWNsZXNRdWVyeSA9IHVzZVZlaGljbGVzKClcclxuICBjb25zdCBtYWludGVuYW5jZVF1ZXJ5ID0gdXNlTWFpbnRlbmFuY2VXaW5kb3dzKGZyb20sIHRvKVxyXG4gIGNvbnN0IGluY2lkZW50c1F1ZXJ5ID0gdXNlSW5jaWRlbnRzKClcclxuICBjb25zdCBib29raW5ncyA9IGJvb2tpbmdzUXVlcnkuZGF0YSA/PyBbXVxyXG4gIGNvbnN0IHZlaGljbGVzID0gdmVoaWNsZXNRdWVyeS5kYXRhID8/IFtdXHJcbiAgY29uc3QgaW5jaWRlbnRzID0gaW5jaWRlbnRzUXVlcnkuZGF0YSA/PyBbXVxyXG4gIGNvbnN0IGl0ZW1zID0gYnVpbGRUaW1lbGluZUl0ZW1zKGJvb2tpbmdzLCBtYWludGVuYW5jZVF1ZXJ5LmRhdGEgPz8gW10sIHVuZGVmaW5lZCwgaW5jaWRlbnRzKVxyXG4gIGNvbnN0IGdyb3VwcyA9IHZlaGljbGVzLm1hcCgodmVoaWNsZSkgPT4gKHtcclxuICAgIGlkOiB2ZWhpY2xlLmlkLFxyXG4gICAgdGl0bGU6IDxzcGFuIGNsYXNzTmFtZT1cImZsZWV0LXRpbWVsaW5lX192ZWhpY2xlXCI+PHN0cm9uZz57dmVoaWNsZS5yZWdpc3RyYXRpb259PC9zdHJvbmc+PHNtYWxsPnt2ZWhpY2xlLm1ha2V9IHt2ZWhpY2xlLm1vZGVsfTwvc21hbGw+PC9zcGFuPixcclxuICAgIHN0YWNrSXRlbXM6IHRydWUsXHJcbiAgICBoZWlnaHQ6IDU0LFxyXG4gIH0pKVxyXG5cclxuICBmdW5jdGlvbiBjaG9vc2VSYW5nZShkYXlzOiA3IHwgMzApIHtcclxuICAgIHNldFJhbmdlRGF5cyhkYXlzKVxyXG4gICAgY29uc3Qgc3RhcnQgPSB0b2RheVN0YXJ0KClcclxuICAgIHNldFZpc2libGVSYW5nZSh7IHN0YXJ0LCBlbmQ6IHN0YXJ0ICsgZGF5cyAqIERBWV9NUyB9KVxyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gaGFuZGxlQ2FudmFzQ2xpY2soZ3JvdXBJZDogc3RyaW5nIHwgbnVtYmVyLCB0aW1lOiBudW1iZXIpIHtcclxuICAgIHNldFNlbGVjdGVkQm9va2luZyhudWxsKVxyXG4gICAgbmF2aWdhdGUoYnVpbGRCb29raW5nUHJlZmlsbFVybChncm91cElkLCB0aW1lKSlcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIGhhbmRsZUl0ZW1DbGljayhpdGVtSWQ6IHN0cmluZyB8IG51bWJlcikge1xyXG4gICAgY29uc3QgaXRlbSA9IGl0ZW1zLmZpbmQoKGVudHJ5KSA9PiBlbnRyeS5pZCA9PT0gaXRlbUlkKVxyXG4gICAgaWYgKGl0ZW0/LmtpbmQgPT09ICdpbmNpZGVudF93YXJuaW5nJyAmJiBpdGVtLmluY2lkZW50SWQpIHtcclxuICAgICAgbmF2aWdhdGUoYC9hZG1pbi9pbmNpZGVudHM/aW5jaWRlbnRJZD0ke2VuY29kZVVSSUNvbXBvbmVudChpdGVtLmluY2lkZW50SWQpfWApXHJcbiAgICAgIHJldHVyblxyXG4gICAgfVxyXG4gICAgaWYgKGl0ZW0/LmtpbmQgIT09ICdib29raW5nJyB8fCAhaXRlbS5ib29raW5nSWQpIHJldHVyblxyXG4gICAgc2V0U2VsZWN0ZWRCb29raW5nKGJvb2tpbmdzLmZpbmQoKGJvb2tpbmcpID0+IGJvb2tpbmcuaWQgPT09IGl0ZW0uYm9va2luZ0lkKSA/PyBudWxsKVxyXG4gIH1cclxuXHJcbiAgY29uc3QgaXNMb2FkaW5nID0gYm9va2luZ3NRdWVyeS5pc0xvYWRpbmcgfHwgdmVoaWNsZXNRdWVyeS5pc0xvYWRpbmcgfHwgbWFpbnRlbmFuY2VRdWVyeS5pc0xvYWRpbmcgfHwgaW5jaWRlbnRzUXVlcnkuaXNMb2FkaW5nXHJcbiAgY29uc3QgaGFzRXJyb3IgPSBib29raW5nc1F1ZXJ5LmlzRXJyb3IgfHwgdmVoaWNsZXNRdWVyeS5pc0Vycm9yIHx8IG1haW50ZW5hbmNlUXVlcnkuaXNFcnJvciB8fCBpbmNpZGVudHNRdWVyeS5pc0Vycm9yXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJmbGVldC10aW1lbGluZS1wYWdlXCI+XHJcbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiZmxlZXQtdGltZWxpbmUtcGFnZV9faGVhZGVyXCI+XHJcbiAgICAgICAgPGRpdj48cCBjbGFzc05hbWU9XCJleWVicm93XCI+RmxlZXQgb3BlcmF0aW9uczwvcD48aDE+RmxlZXQgdGltZWxpbmU8L2gxPjxwPkJvb2tpbmdzLCB0dXJuYXJvdW5kIHRpbWUgYW5kIG1haW50ZW5hbmNlIGJ5IHZlaGljbGUuPC9wPjwvZGl2PlxyXG4gICAgICAgIDxkaXYgYXJpYS1sYWJlbD1cIlRpbWVsaW5lIHJhbmdlXCIgY2xhc3NOYW1lPVwidGltZWxpbmUtcmFuZ2VcIiByb2xlPVwiZ3JvdXBcIj5cclxuICAgICAgICAgIDxCdXR0b24gYXJpYS1wcmVzc2VkPXtyYW5nZURheXMgPT09IDd9IG9uQ2xpY2s9eygpID0+IGNob29zZVJhbmdlKDcpfSB2YXJpYW50PXtyYW5nZURheXMgPT09IDcgPyAncHJpbWFyeScgOiAnc2Vjb25kYXJ5J30+PENhbGVuZGFyRGF5cyBhcmlhLWhpZGRlbj1cInRydWVcIiBzaXplPXsxNn0gLz4gNyBkYXlzPC9CdXR0b24+XHJcbiAgICAgICAgICA8QnV0dG9uIGFyaWEtcHJlc3NlZD17cmFuZ2VEYXlzID09PSAzMH0gb25DbGljaz17KCkgPT4gY2hvb3NlUmFuZ2UoMzApfSB2YXJpYW50PXtyYW5nZURheXMgPT09IDMwID8gJ3ByaW1hcnknIDogJ3NlY29uZGFyeSd9PjxDYWxlbmRhckRheXMgYXJpYS1oaWRkZW49XCJ0cnVlXCIgc2l6ZT17MTZ9IC8+IDMwIGRheXM8L0J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9oZWFkZXI+XHJcblxyXG4gICAgICA8ZGl2IGFyaWEtbGFiZWw9XCJCb29raW5nIHN0YXR1cyBsZWdlbmRcIiBjbGFzc05hbWU9XCJmbGVldC10aW1lbGluZS1sZWdlbmRcIj5cclxuICAgICAgICB7c3RhdHVzTGVnZW5kLm1hcCgoeyBzdGF0dXMsIGxhYmVsIH0pID0+IDxzcGFuIGtleT17c3RhdHVzfT48aSBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IGdldFRpbWVsaW5lU3RhdHVzQ29sb3Ioc3RhdHVzKSB9fSAvPntsYWJlbH08L3NwYW4+KX1cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGVldC10aW1lbGluZS1sZWdlbmRfX2J1ZmZlclwiPjxpIC8+VHVybmFyb3VuZCBidWZmZXI8L3NwYW4+XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxlZXQtdGltZWxpbmUtbGVnZW5kX19tYWludGVuYW5jZVwiPjxpIC8+PEFsZXJ0VHJpYW5nbGUgYXJpYS1oaWRkZW49XCJ0cnVlXCIgc2l6ZT17MTR9IC8+TWFpbnRlbmFuY2U8L3NwYW4+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRldGFpbHMgY2xhc3NOYW1lPVwiZmxlZXQtdGltZWxpbmUtYWx0ZXJuYXRpdmVcIj5cclxuICAgICAgICA8c3VtbWFyeT5LZXlib2FyZC1hY2Nlc3NpYmxlIGJvb2tpbmdzIGFuZCB2ZWhpY2xlIGFjdGlvbnM8L3N1bW1hcnk+XHJcbiAgICAgICAgPHVsPlxyXG4gICAgICAgICAge2l0ZW1zLmZpbHRlcigoaXRlbSkgPT4gaXRlbS5raW5kID09PSAnYm9va2luZycgJiYgaXRlbS5ib29raW5nSWQpLm1hcCgoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBib29raW5nID0gYm9va2luZ3MuZmluZCgoZW50cnkpID0+IGVudHJ5LmlkID09PSBpdGVtLmJvb2tpbmdJZClcclxuICAgICAgICAgICAgaWYgKCFib29raW5nKSByZXR1cm4gbnVsbFxyXG4gICAgICAgICAgICByZXR1cm4gPGxpIGtleT17aXRlbS5pZH0+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVJdGVtQ2xpY2soaXRlbS5pZCl9IHR5cGU9XCJidXR0b25cIj5WaWV3IGJvb2tpbmcge2Jvb2tpbmcucmVmZXJlbmNlfToge2Jvb2tpbmcuc3RhdHVzLnJlcGxhY2VBbGwoJ18nLCAnICcpfTwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxzcGFuPnt2ZWhpY2xlcy5maW5kKCh2ZWhpY2xlKSA9PiB2ZWhpY2xlLmlkID09PSBib29raW5nLnZlaGljbGVJZCk/LnJlZ2lzdHJhdGlvbiA/PyBib29raW5nLnZlaGljbGVJZH0gwrcge2Zvcm1hdEVhdChib29raW5nLnBpY2t1cEF0KX3igJN7Zm9ybWF0RWF0KGJvb2tpbmcucmV0dXJuQXQpfTwvc3Bhbj5cclxuICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgIH0pfVxyXG4gICAgICAgICAge3ZlaGljbGVzLm1hcCgodmVoaWNsZSkgPT4gPGxpIGtleT17YGNyZWF0ZS0ke3ZlaGljbGUuaWR9YH0+XHJcbiAgICAgICAgICAgIDxMaW5rIHRvPXtidWlsZEJvb2tpbmdQcmVmaWxsVXJsKHZlaGljbGUuaWQsIHJhbmdlU3RhcnQpfT5DcmVhdGUgYm9va2luZyBmb3Ige3ZlaGljbGUucmVnaXN0cmF0aW9ufTwvTGluaz5cclxuICAgICAgICAgIDwvbGk+KX1cclxuICAgICAgICA8L3VsPlxyXG4gICAgICA8L2RldGFpbHM+XHJcblxyXG4gICAgICB7aXNMb2FkaW5nICYmIDxTa2VsZXRvbiByb3dzPXs1fSAvPn1cclxuICAgICAge2hhc0Vycm9yICYmIDxFcnJvclN0YXRlIG9uUmV0cnk9eygpID0+IHsgdm9pZCBib29raW5nc1F1ZXJ5LnJlZmV0Y2goKTsgdm9pZCB2ZWhpY2xlc1F1ZXJ5LnJlZmV0Y2goKTsgdm9pZCBtYWludGVuYW5jZVF1ZXJ5LnJlZmV0Y2goKTsgdm9pZCBpbmNpZGVudHNRdWVyeS5yZWZldGNoKCkgfX0gcmV0cnlMYWJlbD1cIlJldHJ5XCIgdGl0bGU9XCJUaW1lbGluZSBkYXRhIGNvdWxkIG5vdCBiZSBsb2FkZWRcIiAvPn1cclxuICAgICAgeyFpc0xvYWRpbmcgJiYgIWhhc0Vycm9yICYmIHZlaGljbGVzLmxlbmd0aCA9PT0gMCAmJiA8RW1wdHlTdGF0ZSBkZXNjcmlwdGlvbj1cIkFkZCB2ZWhpY2xlcyB0byBzZWUgdGhlaXIgYm9va2luZ3MgaGVyZS5cIiB0aXRsZT1cIk5vIHZlaGljbGVzIGZvdW5kXCIgLz59XHJcbiAgICAgIHshaXNMb2FkaW5nICYmICFoYXNFcnJvciAmJiB2ZWhpY2xlcy5sZW5ndGggPiAwICYmIDxkaXYgY2xhc3NOYW1lPVwiZmxlZXQtdGltZWxpbmUtc2Nyb2xsXCIgZGF0YS10ZXN0aWQ9XCJmbGVldC10aW1lbGluZVwiPlxyXG4gICAgICAgIDxUaW1lbGluZTxGbGVldFRpbWVsaW5lSXRlbT5cclxuICAgICAgICAgIGNhbk1vdmU9e2ZhbHNlfVxyXG4gICAgICAgICAgY2FuUmVzaXplPXtmYWxzZX1cclxuICAgICAgICAgIGRlZmF1bHRUaW1lRW5kPXtyYW5nZUVuZH1cclxuICAgICAgICAgIGRlZmF1bHRUaW1lU3RhcnQ9e3JhbmdlU3RhcnR9XHJcbiAgICAgICAgICBncm91cHM9e2dyb3Vwc31cclxuICAgICAgICAgIGl0ZW1IZWlnaHRSYXRpbz17MC43OH1cclxuICAgICAgICAgIGl0ZW1zPXtpdGVtc31cclxuICAgICAgICAgIG1heFpvb209ezMwICogREFZX01TfVxyXG4gICAgICAgICAgbWluWm9vbT17NyAqIERBWV9NU31cclxuICAgICAgICAgIG9uQ2FudmFzQ2xpY2s9e2hhbmRsZUNhbnZhc0NsaWNrfVxyXG4gICAgICAgICAgb25JdGVtQ2xpY2s9e2hhbmRsZUl0ZW1DbGlja31cclxuICAgICAgICAgIG9uSXRlbVNlbGVjdD17aGFuZGxlSXRlbUNsaWNrfVxyXG4gICAgICAgICAgb25UaW1lQ2hhbmdlPXsoc3RhcnQsIGVuZCwgdXBkYXRlU2Nyb2xsQ2FudmFzKSA9PiB7XHJcbiAgICAgICAgICAgIHNldFZpc2libGVSYW5nZSh7IHN0YXJ0LCBlbmQgfSlcclxuICAgICAgICAgICAgdXBkYXRlU2Nyb2xsQ2FudmFzKHN0YXJ0LCBlbmQpXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgICAgc2lkZWJhcldpZHRoPXsxNzB9XHJcbiAgICAgICAgICBzdGFja0l0ZW1zXHJcbiAgICAgICAgICB0aW1lU3RlcHM9e3sgc2Vjb25kOiA2MCwgbWludXRlOiAzMCwgaG91cjogMSwgZGF5OiAxLCBtb250aDogMSwgeWVhcjogMSB9fVxyXG4gICAgICAgICAgdmlzaWJsZVRpbWVFbmQ9e3JhbmdlRW5kfVxyXG4gICAgICAgICAgdmlzaWJsZVRpbWVTdGFydD17cmFuZ2VTdGFydH1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8VGltZWxpbmVIZWFkZXJzPlxyXG4gICAgICAgICAgICA8U2lkZWJhckhlYWRlcj57KHsgZ2V0Um9vdFByb3BzIH0pID0+IDxkaXYgey4uLmdldFJvb3RQcm9wcyh7IHN0eWxlOiB7fSB9KX0+PHNwYW4gY2xhc3NOYW1lPVwiZmxlZXQtdGltZWxpbmVfX3NpZGViYXItdGl0bGVcIj5WZWhpY2xlPC9zcGFuPjwvZGl2Pn08L1NpZGViYXJIZWFkZXI+XHJcbiAgICAgICAgICAgIDxEYXRlSGVhZGVyIHVuaXQ9XCJwcmltYXJ5SGVhZGVyXCIgLz5cclxuICAgICAgICAgICAgPERhdGVIZWFkZXIgdW5pdD1cImRheVwiIC8+XHJcbiAgICAgICAgICA8L1RpbWVsaW5lSGVhZGVycz5cclxuICAgICAgICA8L1RpbWVsaW5lPlxyXG4gICAgICA8L2Rpdj59XHJcblxyXG4gICAgICB7c2VsZWN0ZWRCb29raW5nICYmIDxEcmF3ZXIgb3BlbiB0aXRsZT17c2VsZWN0ZWRCb29raW5nLnJlZmVyZW5jZX0gb25DbG9zZT17KCkgPT4gc2V0U2VsZWN0ZWRCb29raW5nKG51bGwpfT5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZWV0LXRpbWVsaW5lLWRyYXdlclwiPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgZmxlZXQtdGltZWxpbmUtZHJhd2VyX19zdGF0dXMgZmxlZXQtdGltZWxpbmUtZHJhd2VyX19zdGF0dXMtLSR7c2VsZWN0ZWRCb29raW5nLnN0YXR1c31gfT5cclxuICAgICAgICAgICAge3NlbGVjdGVkQm9va2luZy5zdGF0dXMgPT09ICdvdmVyZHVlJyAmJiA8QWxlcnRUcmlhbmdsZSBhcmlhLWhpZGRlbj1cInRydWVcIiBzaXplPXsxNX0gLz59XHJcbiAgICAgICAgICAgIHtzZWxlY3RlZEJvb2tpbmcuc3RhdHVzID09PSAnb3ZlcmR1ZScgPyAnT3ZlcmR1ZScgOiBzZWxlY3RlZEJvb2tpbmcuc3RhdHVzLnJlcGxhY2VBbGwoJ18nLCAnICcpfVxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPGRsPlxyXG4gICAgICAgICAgICA8ZGl2PjxkdD5DdXN0b21lcjwvZHQ+PGRkPntzZWxlY3RlZEJvb2tpbmcuY3VzdG9tZXJOYW1lID8/ICfigJQnfTwvZGQ+PC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXY+PGR0PlZlaGljbGU8L2R0PjxkZD57dmVoaWNsZXMuZmluZCgodmVoaWNsZSkgPT4gdmVoaWNsZS5pZCA9PT0gc2VsZWN0ZWRCb29raW5nLnZlaGljbGVJZCk/LnJlZ2lzdHJhdGlvbiA/PyBzZWxlY3RlZEJvb2tpbmcudmVoaWNsZUlkfTwvZGQ+PC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXY+PGR0PlBpY2t1cDwvZHQ+PGRkPntmb3JtYXRFYXQoc2VsZWN0ZWRCb29raW5nLnBpY2t1cEF0KX08L2RkPjwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2PjxkdD5SZXR1cm48L2R0PjxkZD57Zm9ybWF0RWF0KHNlbGVjdGVkQm9va2luZy5yZXR1cm5BdCl9PC9kZD48L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj48ZHQ+QW1vdW50PC9kdD48ZGQ+e2Zvcm1hdEtlcyhzZWxlY3RlZEJvb2tpbmcudG90YWxLZXMpfTwvZGQ+PC9kaXY+XHJcbiAgICAgICAgICAgIHtzZWxlY3RlZEJvb2tpbmcuc3RhdHVzID09PSAnb3ZlcmR1ZScgJiYgPGRpdj48ZHQ+TGF0ZSBmZWVzPC9kdD48ZGQgY2xhc3NOYW1lPVwiZmxlZXQtdGltZWxpbmUtZHJhd2VyX19kYW5nZXJcIj48Q2xvY2szIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHNpemU9ezE1fSAvPiB7Zm9ybWF0S2VzKHNlbGVjdGVkQm9va2luZy5hY2NydWVkTGF0ZUZlZUtlcyA/PyAwKX08L2RkPjwvZGl2Pn1cclxuICAgICAgICAgIDwvZGw+XHJcbiAgICAgICAgICA8TGluayBjbGFzc05hbWU9XCJidXR0b24gYnV0dG9uLS1wcmltYXJ5XCIgdG89e2AvYWRtaW4vYm9va2luZ3MvJHtzZWxlY3RlZEJvb2tpbmcuaWR9YH0+T3BlbiBib29raW5nPC9MaW5rPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L0RyYXdlcj59XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKVxyXG59Il19
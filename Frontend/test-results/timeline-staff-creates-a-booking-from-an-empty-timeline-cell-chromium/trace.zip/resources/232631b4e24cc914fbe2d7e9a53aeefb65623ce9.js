import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/bookings/HoldCountdown.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { useCountdown } from "/src/hooks/useCountdown.ts";
import { t } from "/src/i18n/index.ts";
var _jsxFileName = "C:/CarHire/Frontend/src/features/bookings/HoldCountdown.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b23c0c4";
var _s = $RefreshSig$();
function renderTime(secondsLeft) {
	const minutes = Math.floor(secondsLeft / 60);
	const seconds = secondsLeft % 60;
	return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}
export function HoldCountdown({ holdExpiresAt, onExpire }) {
	_s();
	const { secondsLeft, expired } = useCountdown(holdExpiresAt, onExpire);
	if (!holdExpiresAt) return null;
	return /* @__PURE__ */ _jsxDEV("span", {
		"aria-live": "polite",
		className: `hold-countdown${expired ? " is-expired" : secondsLeft < 300 ? " is-urgent" : ""}`,
		role: "status",
		children: expired ? t("booking.holdExpired") : `${t("booking.holdExpires")} ${renderTime(secondsLeft)}`
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 5
	}, this);
}
_s(HoldCountdown, "aBPgqCXS2zxnXuQecJD1jGstvw8=", false, function() {
	return [useCountdown];
});
_c = HoldCountdown;
var _c;
$RefreshReg$(_c, "HoldCountdown");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/bookings/HoldCountdown.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/CarHire/Frontend/src/features/bookings/HoldCountdown.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/CarHire/Frontend/src/features/bookings/HoldCountdown.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/CarHire/Frontend/src/features/bookings/HoldCountdown.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxTQUFTOzs7O0FBRWxCLFNBQVMsV0FBVyxhQUFxQjtDQUN2QyxNQUFNLFVBQVUsS0FBSyxNQUFNLGNBQWMsRUFBRTtDQUMzQyxNQUFNLFVBQVUsY0FBYztDQUM5QixPQUFPLEdBQUcsT0FBTyxPQUFPLENBQUMsQ0FBQyxTQUFTLEdBQUcsR0FBRyxFQUFFLEdBQUcsT0FBTyxPQUFPLENBQUMsQ0FBQyxTQUFTLEdBQUcsR0FBRztBQUMvRTtBQUVBLE9BQU8sU0FBUyxjQUFjLEVBQUUsZUFBZSxZQUErRDs7Q0FDNUcsTUFBTSxFQUFFLGFBQWEsWUFBWSxhQUFhLGVBQWUsUUFBUTtDQUNyRSxJQUFJLENBQUMsZUFBZSxPQUFPO0NBQzNCLE9BQ0Usd0JBQUMsUUFBRDtFQUFNLGFBQVU7RUFBUyxXQUFXLGlCQUFpQixVQUFVLGdCQUFnQixjQUFjLE1BQU0sZUFBZTtFQUFNLE1BQUs7WUFDMUgsVUFBVSxFQUFFLHFCQUFxQixJQUFJLEdBQUcsRUFBRSxxQkFBcUIsRUFBRSxHQUFHLFdBQVcsV0FBVztDQUN2Rjs7Ozs7QUFFViIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJIb2xkQ291bnRkb3duLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VDb3VudGRvd24gfSBmcm9tICcuLi8uLi9ob29rcy91c2VDb3VudGRvd24nXHJcbmltcG9ydCB7IHQgfSBmcm9tICcuLi8uLi9pMThuJ1xyXG5cclxuZnVuY3Rpb24gcmVuZGVyVGltZShzZWNvbmRzTGVmdDogbnVtYmVyKSB7XHJcbiAgY29uc3QgbWludXRlcyA9IE1hdGguZmxvb3Ioc2Vjb25kc0xlZnQgLyA2MClcclxuICBjb25zdCBzZWNvbmRzID0gc2Vjb25kc0xlZnQgJSA2MFxyXG4gIHJldHVybiBgJHtTdHJpbmcobWludXRlcykucGFkU3RhcnQoMiwgJzAnKX06JHtTdHJpbmcoc2Vjb25kcykucGFkU3RhcnQoMiwgJzAnKX1gXHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBIb2xkQ291bnRkb3duKHsgaG9sZEV4cGlyZXNBdCwgb25FeHBpcmUgfTogeyBob2xkRXhwaXJlc0F0Pzogc3RyaW5nOyBvbkV4cGlyZT86ICgpID0+IHZvaWQgfSkge1xyXG4gIGNvbnN0IHsgc2Vjb25kc0xlZnQsIGV4cGlyZWQgfSA9IHVzZUNvdW50ZG93bihob2xkRXhwaXJlc0F0LCBvbkV4cGlyZSlcclxuICBpZiAoIWhvbGRFeHBpcmVzQXQpIHJldHVybiBudWxsXHJcbiAgcmV0dXJuIChcclxuICAgIDxzcGFuIGFyaWEtbGl2ZT1cInBvbGl0ZVwiIGNsYXNzTmFtZT17YGhvbGQtY291bnRkb3duJHtleHBpcmVkID8gJyBpcy1leHBpcmVkJyA6IHNlY29uZHNMZWZ0IDwgMzAwID8gJyBpcy11cmdlbnQnIDogJyd9YH0gcm9sZT1cInN0YXR1c1wiPlxyXG4gICAgICB7ZXhwaXJlZCA/IHQoJ2Jvb2tpbmcuaG9sZEV4cGlyZWQnKSA6IGAke3QoJ2Jvb2tpbmcuaG9sZEV4cGlyZXMnKX0gJHtyZW5kZXJUaW1lKHNlY29uZHNMZWZ0KX1gfVxyXG4gICAgPC9zcGFuPlxyXG4gIClcclxufSJdfQ==
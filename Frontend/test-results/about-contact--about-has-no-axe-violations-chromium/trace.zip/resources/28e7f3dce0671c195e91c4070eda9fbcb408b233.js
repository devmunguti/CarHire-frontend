import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/about/AboutPage.tsx");import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false};const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport8_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=8b23c0c4";
import { Check, ChevronDown, Play, Quote } from "/node_modules/.vite/deps/lucide-react.js?v=8b23c0c4";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=8b23c0c4";
import { Modal } from "/src/components/ui/overlays.tsx";
import { company } from "/src/config/company.ts";
import { APP_PROMO } from "/src/features/home/homeConfig.ts";
import { rentalQuestions, testimonials } from "/src/features/about/aboutConfig.ts";
import { t, useTranslation } from "/src/i18n/index.ts";
var _jsxFileName = "C:/CarHire/Frontend/src/features/about/AboutPage.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b23c0c4";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const features = [
	{
		title: "about.feature.choice",
		copy: "about.feature.choiceCopy"
	},
	{
		title: "about.feature.support",
		copy: "about.feature.supportCopy"
	},
	{
		title: "about.feature.freedom",
		copy: "about.feature.freedomCopy"
	},
	{
		title: "about.feature.flexibility",
		copy: "about.feature.flexibilityCopy"
	}
];
const memoryChecklist = [
	"about.memory.car",
	"about.memory.booking",
	"about.memory.support",
	"about.memory.freedom"
];
function PageHeading() {
	return /* @__PURE__ */ _jsxDEV("header", {
		className: "story-heading",
		children: [/* @__PURE__ */ _jsxDEV("h1", { children: t("about.title") }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 26,
			columnNumber: 5
		}, this), /* @__PURE__ */ _jsxDEV("nav", {
			"aria-label": t("about.breadcrumb.label"),
			children: /* @__PURE__ */ _jsxDEV("ol", { children: [/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
				to: "/",
				children: t("about.breadcrumb.home")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 59
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 55
			}, this), /* @__PURE__ */ _jsxDEV("li", {
				"aria-current": "page",
				children: t("about.title")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 112
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 51
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 5
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 25,
		columnNumber: 10
	}, this);
}
_c = PageHeading;
function AboutVideo() {
	_s();
	const [open, setOpen] = useState(false);
	const videoUrl = import.meta.env.VITE_ABOUT_VIDEO_URL ?? "";
	if (!videoUrl) return null;
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("section", {
		"aria-label": t("about.video.label"),
		className: "about-video",
		children: /* @__PURE__ */ _jsxDEV("button", {
			"aria-label": t("about.video.play"),
			className: "about-video__play",
			onClick: () => setOpen(true),
			type: "button",
			children: /* @__PURE__ */ _jsxDEV(Play, {
				"aria-hidden": "true",
				fill: "currentColor",
				size: 26
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 37,
				columnNumber: 124
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 37,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 36,
		columnNumber: 5
	}, this), /* @__PURE__ */ _jsxDEV(Modal, {
		onClose: () => setOpen(false),
		open,
		title: t("about.video.title"),
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "about-video__embed",
			children: /* @__PURE__ */ _jsxDEV("iframe", {
				allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
				allowFullScreen: true,
				src: videoUrl,
				title: t("about.video.iframeTitle")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 40,
				columnNumber: 43
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 40,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 39,
		columnNumber: 5
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 35,
		columnNumber: 10
	}, this);
}
_s(AboutVideo, "xG1TONbKtDWtdOTrXaTAsNhPg/Q=");
_c2 = AboutVideo;
export function AboutPage() {
	_s2();
	useTranslation();
	const [openQuestion, setOpenQuestion] = useState(0);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "story-page about-page",
		children: [
			/* @__PURE__ */ _jsxDEV(PageHeading, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 50,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				"aria-labelledby": "about-features-title",
				className: "about-features story-width",
				children: [/* @__PURE__ */ _jsxDEV("h2", {
					id: "about-features-title",
					children: t("about.features.title")
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 7
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "about-features__grid",
					children: features.map((feature) => /* @__PURE__ */ _jsxDEV("article", { children: [/* @__PURE__ */ _jsxDEV("h3", { children: t(feature.title) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 65
					}, this), /* @__PURE__ */ _jsxDEV("p", { children: t(feature.copy) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 92
					}, this)] }, feature.title, true, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 36
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 7
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 51,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "story-width",
				children: /* @__PURE__ */ _jsxDEV(AboutVideo, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 58,
					columnNumber: 34
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				"aria-label": t("about.stats.label"),
				className: "about-stats story-width",
				children: [
					/* @__PURE__ */ _jsxDEV("article", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: company.stats.customers }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 16
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: t("about.stats.customers") }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 58
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("article", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: company.stats.cars }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 16
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: t("about.stats.cars") }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 53
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("article", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: company.stats.years }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 16
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: t("about.stats.years") }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 54
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 7
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 60,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				"aria-labelledby": "about-memories-title",
				className: "about-memories story-width",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "about-memories__copy",
					children: [
						/* @__PURE__ */ _jsxDEV("h2", {
							id: "about-memories-title",
							children: t("about.memories.title")
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 9
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: t("about.memories.copy") }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 69,
							columnNumber: 9
						}, this),
						/* @__PURE__ */ _jsxDEV("ul", { children: memoryChecklist.map((item) => /* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("span", { children: /* @__PURE__ */ _jsxDEV(Check, {
							"aria-hidden": "true",
							size: 14
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 70,
							columnNumber: 65
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 70,
							columnNumber: 59
						}, this), t(item)] }, item, true, {
							fileName: _jsxFileName,
							lineNumber: 70,
							columnNumber: 44
						}, this)) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 70,
							columnNumber: 9
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 67,
					columnNumber: 7
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					"aria-label": t("about.image.travel"),
					className: "story-image story-image--memories",
					role: "img"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 7
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 66,
				columnNumber: 5
			}, this),
			APP_PROMO && /* @__PURE__ */ _jsxDEV("section", {
				"aria-labelledby": "about-app-title",
				className: "about-app story-width",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("p", {
						className: "eyebrow",
						children: "AutoHire KE"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 76,
						columnNumber: 12
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", {
						id: "about-app-title",
						children: t("about.app.title")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 76,
						columnNumber: 50
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: t("about.app.copy") }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 76,
						columnNumber: 102
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "about-app__badges",
						children: [/* @__PURE__ */ _jsxDEV("a", {
							href: "#app-store",
							children: t("footer.appStore")
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 76,
							columnNumber: 165
						}, this), /* @__PURE__ */ _jsxDEV("a", {
							href: "#google-play",
							children: t("footer.googlePlay")
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 76,
							columnNumber: 212
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 76,
						columnNumber: 130
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 7
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					"aria-label": t("about.image.app"),
					className: "about-app__phone",
					role: "img"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 77,
					columnNumber: 7
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 19
			}, this),
			testimonials.length > 0 && /* @__PURE__ */ _jsxDEV("section", {
				"aria-labelledby": "about-reviews-title",
				className: "about-reviews story-width",
				children: [/* @__PURE__ */ _jsxDEV("h2", {
					id: "about-reviews-title",
					children: t("about.reviews.title")
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 81,
					columnNumber: 7
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "about-reviews__grid",
					children: testimonials.map((review) => /* @__PURE__ */ _jsxDEV("article", {
						className: "review-card",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "review-card__quote",
							children: [/* @__PURE__ */ _jsxDEV(Quote, {
								"aria-hidden": "true",
								size: 25
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 83,
								columnNumber: 45
							}, this), /* @__PURE__ */ _jsxDEV("blockquote", { children: review.quote }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 83,
								columnNumber: 83
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 83,
							columnNumber: 9
						}, this), /* @__PURE__ */ _jsxDEV("footer", { children: [/* @__PURE__ */ _jsxDEV("span", {
							"aria-label": review.avatar,
							className: "review-card__avatar",
							role: "img"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 84,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", { children: review.company }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 84,
							columnNumber: 100
						}, this), /* @__PURE__ */ _jsxDEV("strong", { children: review.name }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 84,
							columnNumber: 129
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 84,
							columnNumber: 95
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 84,
							columnNumber: 9
						}, this)]
					}, review.id, true, {
						fileName: _jsxFileName,
						lineNumber: 82,
						columnNumber: 74
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 82,
					columnNumber: 7
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 33
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				"aria-labelledby": "about-faq-title",
				className: "about-faq story-width",
				children: [/* @__PURE__ */ _jsxDEV("h2", {
					id: "about-faq-title",
					children: t("about.faq.title")
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 89,
					columnNumber: 7
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "about-faq__list",
					children: rentalQuestions.map(({ question, answer }, index) => {
						const expanded = openQuestion === index;
						const answerId = `rental-answer-${index}`;
						return /* @__PURE__ */ _jsxDEV("article", {
							className: "about-faq__item",
							children: [/* @__PURE__ */ _jsxDEV("h3", { children: /* @__PURE__ */ _jsxDEV("button", {
								"aria-controls": answerId,
								"aria-expanded": expanded,
								onClick: () => setOpenQuestion(expanded ? null : index),
								type: "button",
								children: [t(question), /* @__PURE__ */ _jsxDEV(ChevronDown, {
									"aria-hidden": "true",
									className: expanded ? "is-open" : "",
									size: 19
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 94,
									columnNumber: 157
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 94,
								columnNumber: 15
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 94,
								columnNumber: 11
							}, this), expanded && /* @__PURE__ */ _jsxDEV("div", {
								className: "about-faq__answer",
								id: answerId,
								role: "region",
								children: /* @__PURE__ */ _jsxDEV("p", { children: t(answer) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 95,
									columnNumber: 87
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 95,
								columnNumber: 24
							}, this)]
						}, question, true, {
							fileName: _jsxFileName,
							lineNumber: 93,
							columnNumber: 16
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 90,
					columnNumber: 7
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 88,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				"aria-labelledby": "about-cta-title",
				className: "about-cta story-width",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("h2", {
						id: "about-cta-title",
						children: t("about.cta.title")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 101,
						columnNumber: 12
					}, this),
					/* @__PURE__ */ _jsxDEV("a", {
						href: `tel:${company.phone.replace(/\D/g, "")}`,
						children: company.phone
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 101,
						columnNumber: 64
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: t("about.cta.copy") }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 101,
						columnNumber: 135
					}, this),
					/* @__PURE__ */ _jsxDEV(Link, {
						className: "about-cta__button",
						to: "/vehicles",
						children: t("about.cta.book")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 101,
						columnNumber: 163
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 101,
					columnNumber: 7
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					"aria-label": t("about.image.car"),
					className: "about-cta__car",
					role: "img"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 102,
					columnNumber: 7
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 100,
				columnNumber: 5
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 49,
		columnNumber: 10
	}, this);
}
_s2(AboutPage, "65+qiq2MKRsh7GJnwoJpJvJDBU0=", false, function() {
	return [useTranslation];
});
_c3 = AboutPage;
var _c, _c2, _c3;
$RefreshReg$(_c, "PageHeading");
$RefreshReg$(_c2, "AboutVideo");
$RefreshReg$(_c3, "AboutPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/about/AboutPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/CarHire/Frontend/src/features/about/AboutPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/CarHire/Frontend/src/features/about/AboutPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/CarHire/Frontend/src/features/about/AboutPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxPQUFPLGFBQWEsTUFBTSxhQUFhO0FBQ2hELFNBQVMsWUFBWTtBQUNyQixTQUFTLGFBQWE7QUFDdEIsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsaUJBQWlCO0FBQzFCLFNBQVMsaUJBQWlCLG9CQUFvQjtBQUM5QyxTQUFTLEdBQUcsc0JBQXNCOzs7O0FBRWxDLE1BQU0sV0FBVztDQUNmO0VBQUUsT0FBTztFQUF3QixNQUFNO0NBQTJCO0NBQ2xFO0VBQUUsT0FBTztFQUF5QixNQUFNO0NBQTRCO0NBQ3BFO0VBQUUsT0FBTztFQUF5QixNQUFNO0NBQTRCO0NBQ3BFO0VBQUUsT0FBTztFQUE2QixNQUFNO0NBQWdDO0FBQzlFO0FBRUEsTUFBTSxrQkFBa0I7Q0FDdEI7Q0FDQTtDQUNBO0NBQ0E7QUFDRjtBQUVBLFNBQVMsY0FBYztDQUNyQixPQUFPLHdCQUFDLFVBQUQ7RUFBUSxXQUFVO1lBQWxCLENBQ0wsd0JBQUMsTUFBRCxZQUFLLEVBQUUsYUFBYSxFQUFNOzs7O1lBQzFCLHdCQUFDLE9BQUQ7R0FBSyxjQUFZLEVBQUUsd0JBQXdCO2FBQUcsd0JBQUMsTUFBRCxhQUFJLHdCQUFDLE1BQUQsWUFBSSx3QkFBQyxNQUFEO0lBQU0sSUFBRztjQUFLLEVBQUUsdUJBQXVCO0dBQVE7Ozs7WUFBSzs7OzthQUFDLHdCQUFDLE1BQUQ7SUFBSSxnQkFBYTtjQUFRLEVBQUUsYUFBYTtHQUFNOzs7O1dBQUs7Ozs7O0VBQU07Ozs7VUFDOUo7Ozs7OztBQUNWOztBQUVBLFNBQVMsYUFBYTs7Q0FDcEIsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLEtBQUs7Q0FDdEMsTUFBTSxXQUFXLFlBQVksSUFBSSx3QkFBd0I7Q0FDekQsSUFBSSxDQUFDLFVBQVUsT0FBTztDQUN0QixPQUFPLGdEQUNMLHdCQUFDLFdBQUQ7RUFBUyxjQUFZLEVBQUUsbUJBQW1CO0VBQUcsV0FBVTtZQUNyRCx3QkFBQyxVQUFEO0dBQVEsY0FBWSxFQUFFLGtCQUFrQjtHQUFHLFdBQVU7R0FBb0IsZUFBZSxRQUFRLElBQUk7R0FBRyxNQUFLO2FBQVMsd0JBQUMsTUFBRDtJQUFNLGVBQVk7SUFBTyxNQUFLO0lBQWUsTUFBTTtHQUFLOzs7OztFQUFTOzs7OztDQUMvSzs7OztXQUNULHdCQUFDLE9BQUQ7RUFBTyxlQUFlLFFBQVEsS0FBSztFQUFTO0VBQU0sT0FBTyxFQUFFLG1CQUFtQjtZQUM1RSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFxQix3QkFBQyxVQUFEO0lBQVEsT0FBTTtJQUEyRjtJQUFnQixLQUFLO0lBQVUsT0FBTyxFQUFFLHlCQUF5QjtHQUFJOzs7OztFQUFNOzs7OztDQUNuTjs7OztTQUNQOzs7OztBQUNKOzs7QUFFQSxPQUFPLFNBQVMsWUFBWTs7Q0FDMUIsZUFBZTtDQUNmLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUF3QixDQUFDO0NBRWpFLE9BQU8sd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNMLHdCQUFDLGFBQUQsQ0FBYzs7Ozs7R0FDZCx3QkFBQyxXQUFEO0lBQVMsbUJBQWdCO0lBQXVCLFdBQVU7Y0FBMUQsQ0FDRSx3QkFBQyxNQUFEO0tBQUksSUFBRztlQUF3QixFQUFFLHNCQUFzQjtJQUFNOzs7O2NBQzdELHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osU0FBUyxLQUFLLFlBQVksd0JBQUMsV0FBRCxhQUE2Qix3QkFBQyxNQUFELFlBQUssRUFBRSxRQUFRLEtBQUssRUFBTTs7OztlQUFDLHdCQUFDLEtBQUQsWUFBSSxFQUFFLFFBQVEsSUFBSSxFQUFLOzs7O2FBQVUsS0FBM0UsUUFBUTs7OztZQUFtRSxDQUFDO0lBQ2xIOzs7O1lBQ0U7Ozs7OztHQUVULHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWMsd0JBQUMsWUFBRCxDQUFhOzs7OztHQUFNOzs7OztHQUVoRCx3QkFBQyxXQUFEO0lBQVMsY0FBWSxFQUFFLG1CQUFtQjtJQUFHLFdBQVU7Y0FBdkQ7S0FDRSx3QkFBQyxXQUFELGFBQVMsd0JBQUMsVUFBRCxZQUFTLFFBQVEsTUFBTSxVQUFrQjs7OztlQUFDLHdCQUFDLFFBQUQsWUFBTyxFQUFFLHVCQUF1QixFQUFROzs7O2FBQVU7Ozs7O0tBQ3JHLHdCQUFDLFdBQUQsYUFBUyx3QkFBQyxVQUFELFlBQVMsUUFBUSxNQUFNLEtBQWE7Ozs7ZUFBQyx3QkFBQyxRQUFELFlBQU8sRUFBRSxrQkFBa0IsRUFBUTs7OzthQUFVOzs7OztLQUMzRix3QkFBQyxXQUFELGFBQVMsd0JBQUMsVUFBRCxZQUFTLFFBQVEsTUFBTSxNQUFjOzs7O2VBQUMsd0JBQUMsUUFBRCxZQUFPLEVBQUUsbUJBQW1CLEVBQVE7Ozs7YUFBVTs7Ozs7SUFDdEY7Ozs7OztHQUVULHdCQUFDLFdBQUQ7SUFBUyxtQkFBZ0I7SUFBdUIsV0FBVTtjQUExRCxDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxNQUFEO09BQUksSUFBRztpQkFBd0IsRUFBRSxzQkFBc0I7TUFBTTs7Ozs7TUFDN0Qsd0JBQUMsS0FBRCxZQUFJLEVBQUUscUJBQXFCLEVBQUs7Ozs7O01BQ2hDLHdCQUFDLE1BQUQsWUFBSyxnQkFBZ0IsS0FBSyxTQUFTLHdCQUFDLE1BQUQsYUFBZSx3QkFBQyxRQUFELFlBQU0sd0JBQUMsT0FBRDtPQUFPLGVBQVk7T0FBTyxNQUFNO01BQUs7Ozs7ZUFBTzs7OztnQkFBRSxFQUFFLElBQUksQ0FBTSxLQUF0RTs7OzthQUFzRSxDQUFDLEVBQU07Ozs7O0tBQ3RIOzs7OztjQUNMLHdCQUFDLE9BQUQ7S0FBSyxjQUFZLEVBQUUsb0JBQW9CO0tBQUcsV0FBVTtLQUFvQyxNQUFLO0lBQU87Ozs7WUFDN0Y7Ozs7OztHQUVSLGFBQWEsd0JBQUMsV0FBRDtJQUFTLG1CQUFnQjtJQUFrQixXQUFVO2NBQXJELENBQ1osd0JBQUMsT0FBRDtLQUFLLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFVO0tBQWM7Ozs7O0tBQUMsd0JBQUMsTUFBRDtNQUFJLElBQUc7Z0JBQW1CLEVBQUUsaUJBQWlCO0tBQU07Ozs7O0tBQUMsd0JBQUMsS0FBRCxZQUFJLEVBQUUsZ0JBQWdCLEVBQUs7Ozs7O0tBQUMsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FBbUMsd0JBQUMsS0FBRDtPQUFHLE1BQUs7aUJBQWMsRUFBRSxpQkFBaUI7TUFBSzs7OztnQkFBQyx3QkFBQyxLQUFEO09BQUcsTUFBSztpQkFBZ0IsRUFBRSxtQkFBbUI7TUFBSzs7OztjQUFNOzs7Ozs7SUFBTTs7OztjQUMzUSx3QkFBQyxPQUFEO0tBQUssY0FBWSxFQUFFLGlCQUFpQjtLQUFHLFdBQVU7S0FBbUIsTUFBSztJQUFPOzs7O1lBQ3pFOzs7Ozs7R0FFUixhQUFhLFNBQVMsS0FBSyx3QkFBQyxXQUFEO0lBQVMsbUJBQWdCO0lBQXNCLFdBQVU7Y0FBekQsQ0FDMUIsd0JBQUMsTUFBRDtLQUFJLElBQUc7ZUFBdUIsRUFBRSxxQkFBcUI7SUFBTTs7OztjQUMzRCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUF1QixhQUFhLEtBQUssV0FBVyx3QkFBQyxXQUFEO01BQVMsV0FBVTtnQkFBbkIsQ0FDakUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FBb0Msd0JBQUMsT0FBRDtRQUFPLGVBQVk7UUFBTyxNQUFNO09BQUs7Ozs7aUJBQUMsd0JBQUMsY0FBRCxZQUFhLE9BQU8sTUFBa0I7Ozs7ZUFBTTs7Ozs7Z0JBQ3RILHdCQUFDLFVBQUQsYUFBUSx3QkFBQyxRQUFEO09BQU0sY0FBWSxPQUFPO09BQVEsV0FBVTtPQUFzQixNQUFLO01BQU87Ozs7Z0JBQUMsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFFBQUQsWUFBTyxPQUFPLFFBQWM7Ozs7Z0JBQUMsd0JBQUMsVUFBRCxZQUFTLE9BQU8sS0FBYTs7OztjQUFNOzs7O2NBQVM7Ozs7Y0FDN0o7UUFIZ0csT0FBTzs7OztZQUd2RyxDQUFDO0lBQU87Ozs7WUFDVjs7Ozs7O0dBRVQsd0JBQUMsV0FBRDtJQUFTLG1CQUFnQjtJQUFrQixXQUFVO2NBQXJELENBQ0Usd0JBQUMsTUFBRDtLQUFJLElBQUc7ZUFBbUIsRUFBRSxpQkFBaUI7SUFBTTs7OztjQUNuRCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFtQixnQkFBZ0IsS0FBSyxFQUFFLFVBQVUsVUFBVSxVQUFVO01BQ3JGLE1BQU0sV0FBVyxpQkFBaUI7TUFDbEMsTUFBTSxXQUFXLGlCQUFpQjtNQUNsQyxPQUFPLHdCQUFDLFdBQUQ7T0FBUyxXQUFVO2lCQUFuQixDQUNMLHdCQUFDLE1BQUQsWUFBSSx3QkFBQyxVQUFEO1FBQVEsaUJBQWU7UUFBVSxpQkFBZTtRQUFVLGVBQWUsZ0JBQWdCLFdBQVcsT0FBTyxLQUFLO1FBQUcsTUFBSztrQkFBeEgsQ0FBa0ksRUFBRSxRQUFRLEdBQUUsd0JBQUMsYUFBRDtTQUFhLGVBQVk7U0FBTyxXQUFXLFdBQVcsWUFBWTtTQUFJLE1BQU07UUFBSzs7OztnQkFBUzs7Ozs7Z0JBQUs7Ozs7aUJBQ2hQLFlBQVksd0JBQUMsT0FBRDtRQUFLLFdBQVU7UUFBb0IsSUFBSTtRQUFVLE1BQUs7a0JBQVMsd0JBQUMsS0FBRCxZQUFJLEVBQUUsTUFBTSxFQUFLOzs7OztPQUFNOzs7O2VBQzVGO1NBSHdDOzs7O2FBR3hDO0tBQ1gsQ0FBQztJQUFPOzs7O1lBQ0Q7Ozs7OztHQUVULHdCQUFDLFdBQUQ7SUFBUyxtQkFBZ0I7SUFBa0IsV0FBVTtjQUFyRCxDQUNFLHdCQUFDLE9BQUQ7S0FBSyx3QkFBQyxNQUFEO01BQUksSUFBRztnQkFBbUIsRUFBRSxpQkFBaUI7S0FBTTs7Ozs7S0FBQyx3QkFBQyxLQUFEO01BQUcsTUFBTSxPQUFPLFFBQVEsTUFBTSxRQUFRLE9BQU8sRUFBRTtnQkFBTSxRQUFRO0tBQVM7Ozs7O0tBQUMsd0JBQUMsS0FBRCxZQUFJLEVBQUUsZ0JBQWdCLEVBQUs7Ozs7O0tBQUMsd0JBQUMsTUFBRDtNQUFNLFdBQVU7TUFBb0IsSUFBRztnQkFBYSxFQUFFLGdCQUFnQjtLQUFROzs7OztJQUFNOzs7O2NBQ2hQLHdCQUFDLE9BQUQ7S0FBSyxjQUFZLEVBQUUsaUJBQWlCO0tBQUcsV0FBVTtLQUFpQixNQUFLO0lBQU87Ozs7WUFDdkU7Ozs7OztFQUNOOzs7Ozs7QUFDUCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBYm91dFBhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IENoZWNrLCBDaGV2cm9uRG93biwgUGxheSwgUXVvdGUgfSBmcm9tICdsdWNpZGUtcmVhY3QnXHJcbmltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xyXG5pbXBvcnQgeyBNb2RhbCB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvdWkvb3ZlcmxheXMnXHJcbmltcG9ydCB7IGNvbXBhbnkgfSBmcm9tICcuLi8uLi9jb25maWcvY29tcGFueSdcclxuaW1wb3J0IHsgQVBQX1BST01PIH0gZnJvbSAnLi4vaG9tZS9ob21lQ29uZmlnJ1xyXG5pbXBvcnQgeyByZW50YWxRdWVzdGlvbnMsIHRlc3RpbW9uaWFscyB9IGZyb20gJy4vYWJvdXRDb25maWcnXHJcbmltcG9ydCB7IHQsIHVzZVRyYW5zbGF0aW9uIH0gZnJvbSAnLi4vLi4vaTE4bidcclxuXHJcbmNvbnN0IGZlYXR1cmVzID0gW1xyXG4gIHsgdGl0bGU6ICdhYm91dC5mZWF0dXJlLmNob2ljZScsIGNvcHk6ICdhYm91dC5mZWF0dXJlLmNob2ljZUNvcHknIH0sXHJcbiAgeyB0aXRsZTogJ2Fib3V0LmZlYXR1cmUuc3VwcG9ydCcsIGNvcHk6ICdhYm91dC5mZWF0dXJlLnN1cHBvcnRDb3B5JyB9LFxyXG4gIHsgdGl0bGU6ICdhYm91dC5mZWF0dXJlLmZyZWVkb20nLCBjb3B5OiAnYWJvdXQuZmVhdHVyZS5mcmVlZG9tQ29weScgfSxcclxuICB7IHRpdGxlOiAnYWJvdXQuZmVhdHVyZS5mbGV4aWJpbGl0eScsIGNvcHk6ICdhYm91dC5mZWF0dXJlLmZsZXhpYmlsaXR5Q29weScgfSxcclxuXVxyXG5cclxuY29uc3QgbWVtb3J5Q2hlY2tsaXN0ID0gW1xyXG4gICdhYm91dC5tZW1vcnkuY2FyJyxcclxuICAnYWJvdXQubWVtb3J5LmJvb2tpbmcnLFxyXG4gICdhYm91dC5tZW1vcnkuc3VwcG9ydCcsXHJcbiAgJ2Fib3V0Lm1lbW9yeS5mcmVlZG9tJyxcclxuXVxyXG5cclxuZnVuY3Rpb24gUGFnZUhlYWRpbmcoKSB7XHJcbiAgcmV0dXJuIDxoZWFkZXIgY2xhc3NOYW1lPVwic3RvcnktaGVhZGluZ1wiPlxyXG4gICAgPGgxPnt0KCdhYm91dC50aXRsZScpfTwvaDE+XHJcbiAgICA8bmF2IGFyaWEtbGFiZWw9e3QoJ2Fib3V0LmJyZWFkY3J1bWIubGFiZWwnKX0+PG9sPjxsaT48TGluayB0bz1cIi9cIj57dCgnYWJvdXQuYnJlYWRjcnVtYi5ob21lJyl9PC9MaW5rPjwvbGk+PGxpIGFyaWEtY3VycmVudD1cInBhZ2VcIj57dCgnYWJvdXQudGl0bGUnKX08L2xpPjwvb2w+PC9uYXY+XHJcbiAgPC9oZWFkZXI+XHJcbn1cclxuXHJcbmZ1bmN0aW9uIEFib3V0VmlkZW8oKSB7XHJcbiAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgY29uc3QgdmlkZW9VcmwgPSBpbXBvcnQubWV0YS5lbnYuVklURV9BQk9VVF9WSURFT19VUkwgPz8gJydcclxuICBpZiAoIXZpZGVvVXJsKSByZXR1cm4gbnVsbFxyXG4gIHJldHVybiA8PlxyXG4gICAgPHNlY3Rpb24gYXJpYS1sYWJlbD17dCgnYWJvdXQudmlkZW8ubGFiZWwnKX0gY2xhc3NOYW1lPVwiYWJvdXQtdmlkZW9cIj5cclxuICAgICAgPGJ1dHRvbiBhcmlhLWxhYmVsPXt0KCdhYm91dC52aWRlby5wbGF5Jyl9IGNsYXNzTmFtZT1cImFib3V0LXZpZGVvX19wbGF5XCIgb25DbGljaz17KCkgPT4gc2V0T3Blbih0cnVlKX0gdHlwZT1cImJ1dHRvblwiPjxQbGF5IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIGZpbGw9XCJjdXJyZW50Q29sb3JcIiBzaXplPXsyNn0gLz48L2J1dHRvbj5cclxuICAgIDwvc2VjdGlvbj5cclxuICAgIDxNb2RhbCBvbkNsb3NlPXsoKSA9PiBzZXRPcGVuKGZhbHNlKX0gb3Blbj17b3Blbn0gdGl0bGU9e3QoJ2Fib3V0LnZpZGVvLnRpdGxlJyl9PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImFib3V0LXZpZGVvX19lbWJlZFwiPjxpZnJhbWUgYWxsb3c9XCJhY2NlbGVyb21ldGVyOyBhdXRvcGxheTsgY2xpcGJvYXJkLXdyaXRlOyBlbmNyeXB0ZWQtbWVkaWE7IGd5cm9zY29wZTsgcGljdHVyZS1pbi1waWN0dXJlXCIgYWxsb3dGdWxsU2NyZWVuIHNyYz17dmlkZW9Vcmx9IHRpdGxlPXt0KCdhYm91dC52aWRlby5pZnJhbWVUaXRsZScpfSAvPjwvZGl2PlxyXG4gICAgPC9Nb2RhbD5cclxuICA8Lz5cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIEFib3V0UGFnZSgpIHtcclxuICB1c2VUcmFuc2xhdGlvbigpXHJcbiAgY29uc3QgW29wZW5RdWVzdGlvbiwgc2V0T3BlblF1ZXN0aW9uXSA9IHVzZVN0YXRlPG51bWJlciB8IG51bGw+KDApXHJcblxyXG4gIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInN0b3J5LXBhZ2UgYWJvdXQtcGFnZVwiPlxyXG4gICAgPFBhZ2VIZWFkaW5nIC8+XHJcbiAgICA8c2VjdGlvbiBhcmlhLWxhYmVsbGVkYnk9XCJhYm91dC1mZWF0dXJlcy10aXRsZVwiIGNsYXNzTmFtZT1cImFib3V0LWZlYXR1cmVzIHN0b3J5LXdpZHRoXCI+XHJcbiAgICAgIDxoMiBpZD1cImFib3V0LWZlYXR1cmVzLXRpdGxlXCI+e3QoJ2Fib3V0LmZlYXR1cmVzLnRpdGxlJyl9PC9oMj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYm91dC1mZWF0dXJlc19fZ3JpZFwiPlxyXG4gICAgICAgIHtmZWF0dXJlcy5tYXAoKGZlYXR1cmUpID0+IDxhcnRpY2xlIGtleT17ZmVhdHVyZS50aXRsZX0+PGgzPnt0KGZlYXR1cmUudGl0bGUpfTwvaDM+PHA+e3QoZmVhdHVyZS5jb3B5KX08L3A+PC9hcnRpY2xlPil9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9zZWN0aW9uPlxyXG5cclxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3Rvcnktd2lkdGhcIj48QWJvdXRWaWRlbyAvPjwvZGl2PlxyXG5cclxuICAgIDxzZWN0aW9uIGFyaWEtbGFiZWw9e3QoJ2Fib3V0LnN0YXRzLmxhYmVsJyl9IGNsYXNzTmFtZT1cImFib3V0LXN0YXRzIHN0b3J5LXdpZHRoXCI+XHJcbiAgICAgIDxhcnRpY2xlPjxzdHJvbmc+e2NvbXBhbnkuc3RhdHMuY3VzdG9tZXJzfTwvc3Ryb25nPjxzcGFuPnt0KCdhYm91dC5zdGF0cy5jdXN0b21lcnMnKX08L3NwYW4+PC9hcnRpY2xlPlxyXG4gICAgICA8YXJ0aWNsZT48c3Ryb25nPntjb21wYW55LnN0YXRzLmNhcnN9PC9zdHJvbmc+PHNwYW4+e3QoJ2Fib3V0LnN0YXRzLmNhcnMnKX08L3NwYW4+PC9hcnRpY2xlPlxyXG4gICAgICA8YXJ0aWNsZT48c3Ryb25nPntjb21wYW55LnN0YXRzLnllYXJzfTwvc3Ryb25nPjxzcGFuPnt0KCdhYm91dC5zdGF0cy55ZWFycycpfTwvc3Bhbj48L2FydGljbGU+XHJcbiAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgPHNlY3Rpb24gYXJpYS1sYWJlbGxlZGJ5PVwiYWJvdXQtbWVtb3JpZXMtdGl0bGVcIiBjbGFzc05hbWU9XCJhYm91dC1tZW1vcmllcyBzdG9yeS13aWR0aFwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImFib3V0LW1lbW9yaWVzX19jb3B5XCI+XHJcbiAgICAgICAgPGgyIGlkPVwiYWJvdXQtbWVtb3JpZXMtdGl0bGVcIj57dCgnYWJvdXQubWVtb3JpZXMudGl0bGUnKX08L2gyPlxyXG4gICAgICAgIDxwPnt0KCdhYm91dC5tZW1vcmllcy5jb3B5Jyl9PC9wPlxyXG4gICAgICAgIDx1bD57bWVtb3J5Q2hlY2tsaXN0Lm1hcCgoaXRlbSkgPT4gPGxpIGtleT17aXRlbX0+PHNwYW4+PENoZWNrIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHNpemU9ezE0fSAvPjwvc3Bhbj57dChpdGVtKX08L2xpPil9PC91bD5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgYXJpYS1sYWJlbD17dCgnYWJvdXQuaW1hZ2UudHJhdmVsJyl9IGNsYXNzTmFtZT1cInN0b3J5LWltYWdlIHN0b3J5LWltYWdlLS1tZW1vcmllc1wiIHJvbGU9XCJpbWdcIiAvPlxyXG4gICAgPC9zZWN0aW9uPlxyXG5cclxuICAgIHtBUFBfUFJPTU8gJiYgPHNlY3Rpb24gYXJpYS1sYWJlbGxlZGJ5PVwiYWJvdXQtYXBwLXRpdGxlXCIgY2xhc3NOYW1lPVwiYWJvdXQtYXBwIHN0b3J5LXdpZHRoXCI+XHJcbiAgICAgIDxkaXY+PHAgY2xhc3NOYW1lPVwiZXllYnJvd1wiPkF1dG9IaXJlIEtFPC9wPjxoMiBpZD1cImFib3V0LWFwcC10aXRsZVwiPnt0KCdhYm91dC5hcHAudGl0bGUnKX08L2gyPjxwPnt0KCdhYm91dC5hcHAuY29weScpfTwvcD48ZGl2IGNsYXNzTmFtZT1cImFib3V0LWFwcF9fYmFkZ2VzXCI+PGEgaHJlZj1cIiNhcHAtc3RvcmVcIj57dCgnZm9vdGVyLmFwcFN0b3JlJyl9PC9hPjxhIGhyZWY9XCIjZ29vZ2xlLXBsYXlcIj57dCgnZm9vdGVyLmdvb2dsZVBsYXknKX08L2E+PC9kaXY+PC9kaXY+XHJcbiAgICAgIDxkaXYgYXJpYS1sYWJlbD17dCgnYWJvdXQuaW1hZ2UuYXBwJyl9IGNsYXNzTmFtZT1cImFib3V0LWFwcF9fcGhvbmVcIiByb2xlPVwiaW1nXCIgLz5cclxuICAgIDwvc2VjdGlvbj59XHJcblxyXG4gICAge3Rlc3RpbW9uaWFscy5sZW5ndGggPiAwICYmIDxzZWN0aW9uIGFyaWEtbGFiZWxsZWRieT1cImFib3V0LXJldmlld3MtdGl0bGVcIiBjbGFzc05hbWU9XCJhYm91dC1yZXZpZXdzIHN0b3J5LXdpZHRoXCI+XHJcbiAgICAgIDxoMiBpZD1cImFib3V0LXJldmlld3MtdGl0bGVcIj57dCgnYWJvdXQucmV2aWV3cy50aXRsZScpfTwvaDI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJvdXQtcmV2aWV3c19fZ3JpZFwiPnt0ZXN0aW1vbmlhbHMubWFwKChyZXZpZXcpID0+IDxhcnRpY2xlIGNsYXNzTmFtZT1cInJldmlldy1jYXJkXCIga2V5PXtyZXZpZXcuaWR9PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmV2aWV3LWNhcmRfX3F1b3RlXCI+PFF1b3RlIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHNpemU9ezI1fSAvPjxibG9ja3F1b3RlPntyZXZpZXcucXVvdGV9PC9ibG9ja3F1b3RlPjwvZGl2PlxyXG4gICAgICAgIDxmb290ZXI+PHNwYW4gYXJpYS1sYWJlbD17cmV2aWV3LmF2YXRhcn0gY2xhc3NOYW1lPVwicmV2aWV3LWNhcmRfX2F2YXRhclwiIHJvbGU9XCJpbWdcIiAvPjxkaXY+PHNwYW4+e3Jldmlldy5jb21wYW55fTwvc3Bhbj48c3Ryb25nPntyZXZpZXcubmFtZX08L3N0cm9uZz48L2Rpdj48L2Zvb3Rlcj5cclxuICAgICAgPC9hcnRpY2xlPil9PC9kaXY+XHJcbiAgICA8L3NlY3Rpb24+fVxyXG5cclxuICAgIDxzZWN0aW9uIGFyaWEtbGFiZWxsZWRieT1cImFib3V0LWZhcS10aXRsZVwiIGNsYXNzTmFtZT1cImFib3V0LWZhcSBzdG9yeS13aWR0aFwiPlxyXG4gICAgICA8aDIgaWQ9XCJhYm91dC1mYXEtdGl0bGVcIj57dCgnYWJvdXQuZmFxLnRpdGxlJyl9PC9oMj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYm91dC1mYXFfX2xpc3RcIj57cmVudGFsUXVlc3Rpb25zLm1hcCgoeyBxdWVzdGlvbiwgYW5zd2VyIH0sIGluZGV4KSA9PiB7XHJcbiAgICAgICAgY29uc3QgZXhwYW5kZWQgPSBvcGVuUXVlc3Rpb24gPT09IGluZGV4XHJcbiAgICAgICAgY29uc3QgYW5zd2VySWQgPSBgcmVudGFsLWFuc3dlci0ke2luZGV4fWBcclxuICAgICAgICByZXR1cm4gPGFydGljbGUgY2xhc3NOYW1lPVwiYWJvdXQtZmFxX19pdGVtXCIga2V5PXtxdWVzdGlvbn0+XHJcbiAgICAgICAgICA8aDM+PGJ1dHRvbiBhcmlhLWNvbnRyb2xzPXthbnN3ZXJJZH0gYXJpYS1leHBhbmRlZD17ZXhwYW5kZWR9IG9uQ2xpY2s9eygpID0+IHNldE9wZW5RdWVzdGlvbihleHBhbmRlZCA/IG51bGwgOiBpbmRleCl9IHR5cGU9XCJidXR0b25cIj57dChxdWVzdGlvbil9PENoZXZyb25Eb3duIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIGNsYXNzTmFtZT17ZXhwYW5kZWQgPyAnaXMtb3BlbicgOiAnJ30gc2l6ZT17MTl9IC8+PC9idXR0b24+PC9oMz5cclxuICAgICAgICAgIHtleHBhbmRlZCAmJiA8ZGl2IGNsYXNzTmFtZT1cImFib3V0LWZhcV9fYW5zd2VyXCIgaWQ9e2Fuc3dlcklkfSByb2xlPVwicmVnaW9uXCI+PHA+e3QoYW5zd2VyKX08L3A+PC9kaXY+fVxyXG4gICAgICAgIDwvYXJ0aWNsZT5cclxuICAgICAgfSl9PC9kaXY+XHJcbiAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgPHNlY3Rpb24gYXJpYS1sYWJlbGxlZGJ5PVwiYWJvdXQtY3RhLXRpdGxlXCIgY2xhc3NOYW1lPVwiYWJvdXQtY3RhIHN0b3J5LXdpZHRoXCI+XHJcbiAgICAgIDxkaXY+PGgyIGlkPVwiYWJvdXQtY3RhLXRpdGxlXCI+e3QoJ2Fib3V0LmN0YS50aXRsZScpfTwvaDI+PGEgaHJlZj17YHRlbDoke2NvbXBhbnkucGhvbmUucmVwbGFjZSgvXFxEL2csICcnKX1gfT57Y29tcGFueS5waG9uZX08L2E+PHA+e3QoJ2Fib3V0LmN0YS5jb3B5Jyl9PC9wPjxMaW5rIGNsYXNzTmFtZT1cImFib3V0LWN0YV9fYnV0dG9uXCIgdG89XCIvdmVoaWNsZXNcIj57dCgnYWJvdXQuY3RhLmJvb2snKX08L0xpbms+PC9kaXY+XHJcbiAgICAgIDxkaXYgYXJpYS1sYWJlbD17dCgnYWJvdXQuaW1hZ2UuY2FyJyl9IGNsYXNzTmFtZT1cImFib3V0LWN0YV9fY2FyXCIgcm9sZT1cImltZ1wiIC8+XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgPC9kaXY+XHJcbn1cclxuIl19